package com.yaolong.session1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyBankBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
