create table users(username varchar(50) not null primary key,password varchar(500) not null,enabled boolean not null);
create table authorities (username varchar(50) not null,authority varchar(50) not null,constraint fk_authorities_users foreign key(username) references users(username));
create unique index ix_auth_username on authorities (username,authority);

INSERT INTO test_db.users
(username, password, enabled)
VALUES('user', '{noop}12345', 1);

INSERT INTO test_db.authorities
(username, authority)
VALUES('user', 'read');


INSERT INTO test_db.users
(username, password, enabled)
VALUES('admin', '{bcrypt}$2a$12$6.sSaP/76gJ2z.Ub7.aFBu5F9F51Hx.KBDW1ynCQOVvsg3mp9j7Oy', 1);

INSERT INTO test_db.authorities
(username, authority)
VALUES('admin', 'admin');

CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(45) NOT NULL,
  `pwd` varchar(200) NOT NULL,
  `role` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
);

INSERT  INTO `customer` (`email`, `pwd`, `role`) VALUES ('happy@example.com', '{noop}12345', 'read');
INSERT  INTO `customer` (`email`, `pwd`, `role`) VALUES ('admin@example.com', '{bcrypt}$2a$12$6.sSaP/76gJ2z.Ub7.aFBu5F9F51Hx.KBDW1ynCQOVvsg3mp9j7Oy', 'admin');

select * from customer;