#### 通用状态
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
0| Success | 成功
59999 | System Error | 系统发生意外错误，请稍后再试~

#### 业务异常
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
51001 | tenantId is incorrect | 客官您的tenantId填写有错误~
51002 | channelId is incorrect | 客官您的channelId填写有错误~
51006 | mobile format is error | 客官您的手机号填写有错误~
51007 | email format is error| 客官您的email填写有错误~
51302 | mobile is exist | 客官您的手机号已存在
51303 | email is exist | 客官您的email已存在
51306 | optId is not exist or repeat optId | 客官您的optId重复或不存在~
51308 | account not exist | 客官您的账户不存在
51317 | subscription type does not exist | 客官您的订阅类型不存在
51320 | bind data does not exist | 客官您的绑定数据不存在
51322 | bind data conflict | 客官您的账号存在冲突，请走解决冲突流程或联系客服
51333 | user attribute data exists | 客官您的用户属性不存在~
51339 | many babies have birthdays less than a year apart or on different days | 系统开小差了，请稍后再试
51340 | baby's birthday is incorrect | 婴儿的生日填写不正确
51341 | customization error | 客官您的定制有错误
51343 | parameter error | 客官您的参数有错误
51344 | account data conflict | 客官您的账号存在冲突，请走解决冲突流程或联系客服~
51444 | account data error | 客官您的账号有错误
51445 | account no conflict | 客官您的账号不存在冲突

#### 自定义注解
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
51034 | query fields is error | 客官您的查询字段错误
51035 | query type not exist | 客官请填写查询类型
51042 | relationship and sequence must be unique | 客官请填写唯一的关系和顺序
51336 | user is under the age of 18 and is not an adult | 客官您未满18岁
51337 | user attribute data type is incorrect | 客官您的的属性不正确
51328 | query parameters are incorrect | 客官您的参数不正确
51011 | incorrect user attribute information content | 客官您的属性信息不正确

#### 系统配置问题
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
52001 | tenant config is not exist | 系统开小差了，请稍后再试
52002 | channel config is not exist | 系统开小差了，请稍后再试
52003 | source config is not exist | 系统开小差了，请稍后再试
52004 | system config is not exist | 系统开小差了，请稍后再试
52005 | system config is error | 系统开小差了，请稍后再试

#### 外部系统异常
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
53001 | address microservice error | 系统繁忙，请稍后再试
53002 | ACL/MINI_ACL microservice error | 系统繁忙，请稍后再试
53003 | ACL/MINI_ACL unionId not exist | 系统繁忙，请稍后再试
53004 | award microservice error | 系统繁忙，请稍后再试
53005 | loyalty microservice error | 系统繁忙，请稍后再试
53006 | sms microservice error | 系统繁忙，请稍后再试

#### 底层与组件的异常
| CODE | MESSAGE | FRONT_MESSAGE |
| :---: | :---: | :---: |
54001 | db error | 系统繁忙，请稍后再试
54002 | redis service error | 系统繁忙，请稍后再试
54003 | baiDu snowflake algorithm error | 系统繁忙，请稍后再试
54004 | service bus error | 系统繁忙，请稍后再试
54005 | event hub error | 系统繁忙，请稍后再试
54006 | mq error | 系统繁忙，请稍后再试
54007 | table Storage error | 系统繁忙，请稍后再试