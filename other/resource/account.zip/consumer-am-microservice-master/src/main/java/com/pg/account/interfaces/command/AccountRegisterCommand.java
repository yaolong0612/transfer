package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.REGISTER_ROUTE_PATTERN;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "AccountRegisterCommand_V1", description = "V1 interface AccountRegisterCommand")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccountRegisterCommand implements Serializable {

    private static final long serialVersionUID = -1486307835859533936L;
    @ApiModelProperty(value = "租户ID，需要申请配置", example = "10003", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    public Long tenantId;
    @ApiModelProperty(value = "渠道ID，需要申请配置", example = "20", required = true)
    @NotNull(message = "channel is not exist")
    public Long channelId;
    @ApiModelProperty(value = "用户名（手机号码|邮箱）", example = "13062661723", required = true)
    @NotBlank(message = "missing username")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String username;
    @ApiModelProperty(value = "密码", example = "123456", required = true)
    @NotBlank(message = "missing password")
    @Length(min = 6, message = "password length less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String password;
    @ApiModelProperty(value = "注册来源，需要申请配置", example = "OTT", required = true)
    @NotBlank(message = "missing source")
    private String source;
    @ApiModelProperty(value = "注册店铺", example = "SMART")
    private String regStore;
    @ApiModelProperty(value = "顾客,和AM对接时申请", example = "PG")
    private String customer;
    @ApiModelProperty(value = "用户信息")
    @Valid
    private ProfileCommand profile;
    @ApiModelProperty(value = "设备信息")
    private DeviceCommand device;
    @ApiModelProperty(value = "柜台信息")
    private CounterCommand counter;
    @ApiModelProperty(value = "地址信息集合")
    @Valid
    @Size(max = 1, message = "地址信息只能添加一条")
    private List<AddressCommand> addresses;
    @ApiModelProperty(value = "订阅信息集合")
    @Valid
    private List<SubscriptionCommand> subscriptions;
    @ApiModelProperty(value = "用户属性信息集合")
    @Valid
    private List<AttrCommand> attrs;
    @ApiModelProperty(value = "注册的路由规则,手机号Mobile=M,邮箱Email=E", example = "M")
    @Pattern(regexp = REGISTER_ROUTE_PATTERN, message = "registerRoute format error")
    private String registerRoute;
    /**
     * 判断是否加积分，为空加积分，为Y加积分，为N不加积分
     */
    @ApiModelProperty(value = "是否需要加积分", example = "Y")
    private String isAward;


    public String gotFullName() {
        if (null != this.addresses && !this.addresses.isEmpty()) {
            return this.addresses.get(0).getFullName();
        }
        return null;
    }

    /**
     * 判断地址是否传入手机号，如果没传入手机号则将username赋值给手机号
     */
    public void specifyAddressCellphone() {
        Optional.ofNullable(this.addresses)
                .filter(addressCommands -> !addressCommands.isEmpty())
                .ifPresent(addressCommands -> addressCommands.forEach(addressCommand -> {
                    if (StringUtils.isBlank(addressCommand.getCellphone())) {
                        addressCommand.setCellphone(this.username);
                    }
                }));
    }
}
