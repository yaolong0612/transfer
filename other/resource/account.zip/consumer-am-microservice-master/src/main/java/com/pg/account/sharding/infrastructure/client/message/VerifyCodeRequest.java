package com.pg.account.sharding.infrastructure.client.message;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Jack
 * @date 2021-04-21 21:12
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class VerifyCodeRequest implements Serializable {
    private static final long serialVersionUID = 861912447169901073L;
    private String apiKey;
    private String brand;
    private String code;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    private String signature;
    private String templateCode;
    private String timeStamp;
}
