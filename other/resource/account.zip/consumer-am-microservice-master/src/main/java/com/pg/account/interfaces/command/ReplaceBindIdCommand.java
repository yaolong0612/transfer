package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.NUMBER_PATTERN;

/**
 * @author Jack Sun
 * @date 2019-5-8 9:44
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReplaceBindIdCommand implements Serializable {
    private static final long serialVersionUID = -472356753796772272L;
    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12")
    @NotNull(message = "channel is not exist")
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234")
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @NotBlank(message = "missing member ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @NotBlank(message = "missing binding ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY")
    @NotBlank(message = "missing UNION_ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
}
