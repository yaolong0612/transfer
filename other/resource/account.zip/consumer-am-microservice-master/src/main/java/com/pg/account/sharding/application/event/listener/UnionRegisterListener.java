package com.pg.account.sharding.application.event.listener;

import com.microsoft.azure.storage.ResultSegment;
import com.pg.account.infrastructure.common.utils.UUIDUtils;
import com.pg.account.sharding.application.event.RegisterEvent;
import com.pg.account.sharding.application.event.SignUpEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils;
import com.pg.account.sharding.infrastructure.tablestorage.UnionRegisterDirEntity;
import com.pg.account.sharding.infrastructure.tablestorage.UnionRegisterEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Optional;

/**
 * @author YJ
 * @date 2022/10/8
 */
@Component
@Slf4j
public class UnionRegisterListener {

    public static final String UNION_REGISTER_DIR = "UnionRegisterDir";
    public static final String SKII = "10001";
    private final TableStorageUtils<UnionRegisterDirEntity> unionRegisterDirUtils;
    private final TableStorageUtils<UnionRegisterEntity> unionRegisterUtils;
    public static final String LA = "10004";

    public UnionRegisterListener(TableStorageUtils<UnionRegisterDirEntity> unionRegisterDirUtils, TableStorageUtils<UnionRegisterEntity> unionRegisterUtils) {
        this.unionRegisterDirUtils = unionRegisterDirUtils;
        this.unionRegisterUtils = unionRegisterUtils;
    }


    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplication(RegisterEvent registerEvent) {
        if (Optional.ofNullable(registerEvent).isPresent()) {
            this.unionRegisterEvent(registerEvent.getAccount());
        }
    }


    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplication(SignUpEvent signUpEvent) {
        if (Optional.ofNullable(signUpEvent).isPresent()) {
            this.unionRegisterEvent(signUpEvent.getAccount());
        }
    }

    private void unionRegisterEvent(Account account) {
        if (!LA.equals(account.getTenantId()) && !SKII.equals(account.getTenantId()) && !account.getMobile().isEmpty()) {
            boolean sendFlag = false;
            int sendCount = 0;
            Calendar now = Calendar.getInstance();
            int month = now.get(Calendar.MONTH) + 1;
            int day = now.get(Calendar.DATE);
            String date = now.get(Calendar.YEAR) + "" + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day);
            String name = "UnionRegister" + date;
            String tableName = name.replace("_", "");
            UnionRegisterEntity unionRegisterEntity = new UnionRegisterEntity(date, UUIDUtils.generateUuid(), account.getTenantId(),
                    account.getRegisterChannelId(), account.getMobile(), account.getAccountId(), account.getRegistration().getSource(), account.getRegistration().getCustomer().getName(), String.valueOf(false), 0, null);
            try {
                unionRegisterDirUtils.createTableIfNotExist(UNION_REGISTER_DIR);
                ResultSegment<UnionRegisterDirEntity> dirName = unionRegisterDirUtils.queryByPartitionKey(UNION_REGISTER_DIR, UnionRegisterDirEntity.class, date);
                UnionRegisterDirEntity result;
                if (dirName.getResults().isEmpty()) {
                    result = new UnionRegisterDirEntity(date, UUIDUtils.generateUuid(), tableName, DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), String.valueOf(false));
                } else {
                    result = dirName.getResults().get(0);
                    result.setStatus(String.valueOf(false));
                }
                while (!sendFlag) {
                    try {
                        unionRegisterDirUtils.saveOrUpdate(UNION_REGISTER_DIR, result);
                        unionRegisterUtils.createTableIfNotExist(tableName);
                        unionRegisterUtils.save(tableName, unionRegisterEntity);
                        sendFlag = true;
                    } catch (Exception e) {
                        sendCount++;
                        log.info("第{}次发送UnionRegister信息到TS失败：tenantId：{},accountId：{}", sendCount, account.getTenantId(), account.getAccountId(), e);
                        if (sendCount > 3) {
                            throw new Exception(e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                log.info("UnionRegister存入TS失败,data:{},tenantId：{},accountId：{}", date, account.getTenantId(), account.getAccountId(), e);
            }
        }
    }
}
