package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 * @date 2017/2/10
 */
@ApiModel(value = "QueryAttributesDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryAttributesDTO implements Serializable {
    private static final long serialVersionUID = 9155725033300227862L;

    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "用户属性集合")
    private List<AttrDTO> attrs;
}
