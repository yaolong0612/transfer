package com.pg.account.sharding.application.cmdservice.impl;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.sharding.application.cmdservice.ModifySubscriptionService;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.UpdateSubscriptionEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.service.FetchAccountService;
import com.pg.account.sharding.domain.service.SubscriptionsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * @author lfx
 * @date 2022/2/11 14:35
 */
@Service
public class ModifySubscriptionServiceImpl implements ModifySubscriptionService {

    private final SubscriptionsService subscriptionsService;
    private final FetchAccountService fetchAccountService;

    @Autowired
    public ModifySubscriptionServiceImpl(SubscriptionsService subscriptionsService, FetchAccountService fetchAccountService) {
        this.subscriptionsService = subscriptionsService;
        this.fetchAccountService = fetchAccountService;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void modifySubscription(ShardSubscription subscription) {
        Account account = fetchAccountService.fetchActiveAccount(subscription.tenantId(), subscription.accountId());
        subscriptionsService.subscribe(subscription);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UpdateSubscriptionEvent updateSubscriptionEvent = new UpdateSubscriptionEvent(this, subscription);
                SpringContextUtil.getApplicationContext().publishEvent(updateSubscriptionEvent);
            }
        });

    }
}
