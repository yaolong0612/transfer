package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.Registration;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.service.LoyaltyService;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.log.DataStreamDao;
import com.pg.account.sharding.infrastructure.jpa.log.LogId;
import com.pg.account.sharding.infrastructure.jpa.log.ShardDataStream;
import com.pg.account.sharding.infrastructure.servicebus.LoyaltyServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.servicebus.LoyaltyServiceBusTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.PRODUCER_EVENT_HUB;
import static java.lang.String.valueOf;

/**
 * @author Jack
 * @date 2021-04-20 21:49
 */
@Slf4j
@Component("shardLoyaltyServiceImpl")
public class LoyaltyServiceImpl implements LoyaltyService {
    public static final String JSON_OBJECT = "jsonObject";
    /**
     * loyalty 创建积分账号所需常量
     */
    public static final String REGION = "ML";
    private final DataStreamDao dataStreamDao;
    private final UidGenerator uidGenerator;
    private final LoyaltyServiceBusTemplate loyaltyServiceBusTemplate;
    @Value("${event_hub.amLoyaltyAwardEventTypeId}")
    private String amLoyaltyAwardEventTypeId;
    @Value("${event_hub.amLoyaltyModifyAwardEventTypeId}")
    private String amLoyaltyModifyAwardEventTypeId;
    @Value("${event_hub.retryCount}")
    private int retryCount;

    @Autowired
    public LoyaltyServiceImpl(DataStreamDao dataStreamDao, UidGenerator uidGenerator, LoyaltyServiceBusTemplate loyaltyServiceBusTemplate) {
        this.dataStreamDao = dataStreamDao;
        this.uidGenerator = uidGenerator;
        this.loyaltyServiceBusTemplate = loyaltyServiceBusTemplate;
    }

    @Override
    public void enrollAccount(Account account, ShardSocialAccount shardSocialAccount, String registerType) {
        if (null != account && StringUtils.isNotBlank(registerType)) {
            String eventTypeId = amLoyaltyAwardEventTypeId;
            final String eventType = "amLoyaltyAwardEventTypeId";
            EnrollAccountRequest request = new EnrollAccountRequest();
            //查询品牌
            String brand = LocalCacheConfigUtils.getTenant(account.getTenantId());
            //查询渠道
            String channel = LocalCacheConfigUtils.getChannel(account.getTenantId(), Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelId).orElse(""));
            if (StringUtils.isNoneBlank(brand) && StringUtils.isNoneBlank(channel)) {
                //判断channel是否在枚举类型中
                String realChannel = ChannelEnum.fromValue(channel);
                request.setMemberId(account.getAccountId());
                if (Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getSocialAccountList).isPresent() && !shardSocialAccount.getSocialAccountList().isEmpty()) {
                    Optional<SocialAccountItem> socialAccount = shardSocialAccount.getSocialAccountList().stream().findFirst();
                    socialAccount.ifPresent(value -> request.setBindId(value.getBindId()));
                }
                request.setBrand(brand);
                request.setChannel(realChannel);
                request.setRegion(REGION);
                request.setRegisterType(registerType);
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(JSON_OBJECT, request);
                sendServiceBus(account, eventTypeId, eventType, jsonObject,LoyaltyServiceBusQueueTopicEnum.Q_ASYNC_ENROLL_ACCOUNT);
            }
        } else {
            log.info("积分消息为空");
        }
    }

    @Override
    public void addInteraction(Account account, String pointType) {
        if (null != account && StringUtils.isNotBlank(pointType)) {
            String eventTypeId = amLoyaltyModifyAwardEventTypeId;
            final String eventType = "amLoyaltyModifyAwardEventTypeId";
            AddInteractionRequest request = new AddInteractionRequest();
            //查询品牌
            String brand = LocalCacheConfigUtils.getTenant(account.getTenantId());
            //查询渠道
            String channel = LocalCacheConfigUtils.getChannel(account.getTenantId(), account.getRegistration().getChannel().getChannelId());
            if (StringUtils.isNoneBlank(brand) && StringUtils.isNoneBlank(channel)) {
                //判断channel是否在枚举类型中
                String realChannel = ChannelEnum.fromValue(channel);
                request.setMemberId(account.getAccountId());
                request.setBrand(brand);
                request.setChannel(realChannel);
                request.setRegion(REGION);
                request.setPointType(pointType);
                JSONObject jsonObject = new JSONObject();
                jsonObject.put(JSON_OBJECT, request);
                sendServiceBus(account, eventTypeId, eventType, jsonObject,LoyaltyServiceBusQueueTopicEnum.Q_ASYNC_ADD_INTERACTION_POINT);
            }
        } else {
            log.info("积分消息为空");
        }
    }

    /**
     * 发送Loyalty ServiceBus消息
     *
     * @param account     account
     * @param eventTypeId eventTypeId
     * @param eventType   eventType
     * @param jsonObject  jsonObject
     */
    private void sendServiceBus(Account account, String eventTypeId, String eventType, JSONObject jsonObject,LoyaltyServiceBusQueueTopicEnum loyaltyServiceBusQueueTopicEnum) {
        boolean result = false;
        String errorMessage = null;
        String eventMessage = jsonObject.toJSONString();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                result = loyaltyServiceBusTemplate.sendQueueMessage(loyaltyServiceBusQueueTopicEnum, eventMessage);
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        LogId logId = new LogId(uidGenerator.getUid(), LocalDateTime.now());
        ShardDataStream shardDataStream = new ShardDataStream(logId, account.getTenantId(), account.getAccountId(), PRODUCER_EVENT_HUB, eventTypeId, eventType, null, null, eventMessage, errorMessage, valueOf(result), valueOf(count));
        dataStreamDao.save(shardDataStream);
    }
}
