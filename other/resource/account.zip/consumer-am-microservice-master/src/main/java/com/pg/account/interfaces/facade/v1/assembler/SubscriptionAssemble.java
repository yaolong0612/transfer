package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.SubscriptionCommand;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;


/**
 * @author lfx
 * @date 2021/6/16 9:45
 */
@Component
public class SubscriptionAssemble {
    /**
     * 将SubscriptionCommand转入订阅聚合根
     *
     * @param tenantId                tenantId
     * @param channelId               channelId
     * @param subscriptionCommandList subscriptionCommandList
     * @author xusheng
     * @date 2021/6/17 16:31
     */
    public ShardSubscription toShardSubscription(Long tenantId, Long channelId, String memberId, List<SubscriptionCommand> subscriptionCommandList) {
        String result = LocalCacheConfigUtils.getChannelId(tenantId.toString());
        String[] x = result.split(COMMA);
        boolean flag = Stream.of(x).anyMatch(s -> s.equals(channelId.toString()));
        if (!flag) {
            throw new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage());
        }
        ShardSubscription.ShardSubscriptionBuilder shardSubscriptionBuilder = ShardSubscription.ShardSubscriptionBuilder
                .aShardSubscription()
                .tenantId(tenantId.toString())
                .accountId(memberId);
        List<SubscriptionItem> subscriptionItems = new ArrayList<>();
        if (Optional.ofNullable(subscriptionCommandList)
                .filter(subscriptionCommands -> !subscriptionCommands.isEmpty())
                .isPresent()) {
            toSubscriptionItem(channelId, subscriptionCommandList, subscriptionItems);
        } else {
            SubscriptionItem subscriptionItem = new SubscriptionItem();
            subscriptionItem.setChannelId(channelId.toString());
            subscriptionItems.add(subscriptionItem);
        }
        return shardSubscriptionBuilder.subscriptionList(subscriptionItems).build();
    }

    /**
     * 组装subcriptionItemList
     *
     * @param channelId               channelId
     * @param subscriptionCommandList subscriptionCommandList
     * @param subscriptionList        subscriptionList
     */
    private void toSubscriptionItem(Long channelId, List<SubscriptionCommand> subscriptionCommandList, List<SubscriptionItem> subscriptionList) {
        subscriptionCommandList.forEach(subscriptionCommand -> {
            SubscriptionItem subscriptionItem = new SubscriptionItem();
            subscriptionItem.build(subscriptionCommand.getOptId(), null, subscriptionCommand.getOptStatus(), null);
            subscriptionItem.setChannelId(channelId.toString());
            subscriptionList.add(subscriptionItem);
        });
    }

}
