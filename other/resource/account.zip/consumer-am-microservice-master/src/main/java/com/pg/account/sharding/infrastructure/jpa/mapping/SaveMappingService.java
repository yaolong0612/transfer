package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.infrastructure.component.uid.UidGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * @author lfx
 * @date 2022/1/20 9:17
 */
@Service
public class SaveMappingService {
    private final BindIdMappingDao bindIdMappingDao;
    private final EmailMappingDao emailMappingDao;
    private final MobileMappingDao mobileMappingDao;
    private final OpenUidMappingDao openUidMappingDao;
    private final UnionIdMappingDao unionIdMappingDao;
    private final UidGenerator uidGenerator;

    @Autowired
    public SaveMappingService(BindIdMappingDao bindIdMappingDao, EmailMappingDao emailMappingDao, MobileMappingDao mobileMappingDao, OpenUidMappingDao openUidMappingDao, UnionIdMappingDao unionIdMappingDao, UidGenerator uidGenerator) {
        this.bindIdMappingDao = bindIdMappingDao;
        this.emailMappingDao = emailMappingDao;
        this.mobileMappingDao = mobileMappingDao;
        this.openUidMappingDao = openUidMappingDao;
        this.unionIdMappingDao = unionIdMappingDao;
        this.uidGenerator = uidGenerator;
    }

    /**
     * 保存mobileMapping
     *
     * @param tenant    tenant
     * @param mobile    mobile
     * @param accountId accountId
     */
    public void saveMobileMapping(String tenant, String mobile, String accountId) {
        MobileMapping mobileMapping = new MobileMapping();
        mobileMapping.setId(uidGenerator.getUid());
        mobileMapping.setAccountId(accountId);
        mobileMapping.setMobileMapId(new MobileMapId(tenant, mobile));
        mobileMapping.setCreatedTime(LocalDateTime.now());
        mobileMapping.setUpdatedTime(LocalDateTime.now());
        mobileMappingDao.save(mobileMapping);
    }

    /**
     * 保存BindMapping
     *
     * @param tenant    tenant
     * @param channel   channel
     * @param accountId accountId
     */
    public void saveBindMapping(String tenant, String channel, String bindId, String accountId) {
        BindIdMapping bindIdMapping = new BindIdMapping();
        BindIdMapId bindIdMapId = new BindIdMapId();
        bindIdMapId.setTenantId(tenant);
        bindIdMapId.setBindId(bindId);
        bindIdMapId.setChannelId(channel);
        bindIdMapping.setId(uidGenerator.getUid());
        bindIdMapping.setBindIdMapId(bindIdMapId);
        bindIdMapping.setAccountId(accountId);
        bindIdMapping.setCreatedTime(LocalDateTime.now());
        bindIdMapping.setUpdatedTime(LocalDateTime.now());
        bindIdMappingDao.save(bindIdMapping);
    }

    /**
     * 保存unionIdMapping
     *
     * @param tenant    tenant
     * @param accountId accountId
     */
    public void saveUnionIdMapping(String tenant, String unionType, String unionId, String accountId) {
        UnionIdMapping unionIdMapping = new UnionIdMapping();
        unionIdMapping.setAccountId(accountId);
        UnionIdMapId unionIdMapId = new UnionIdMapId();
        unionIdMapId.setTenantId(tenant);
        unionIdMapId.setUnionId(unionId);
        unionIdMapId.setChannel(unionType);
        unionIdMapping.setUnionIdMapId(unionIdMapId);
        unionIdMapping.setId(uidGenerator.getUid());
        unionIdMapping.setCreatedTime(LocalDateTime.now());
        unionIdMapping.setUpdatedTime(LocalDateTime.now());
        unionIdMappingDao.save(unionIdMapping);
    }
}
