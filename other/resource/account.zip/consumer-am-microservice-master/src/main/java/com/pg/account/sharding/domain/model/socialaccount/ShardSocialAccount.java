package com.pg.account.sharding.domain.model.socialaccount;

import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.shared.Entity;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterSocialAccountListJson;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 绑定类
 *
 * @author Jack
 * @date 2021/5/27 13:34
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_SOCIAL_ACCOUNT")
@DynamicUpdate
@DynamicInsert
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShardSocialAccount extends BaseEntity implements Entity<ShardSocialAccount>, Serializable {
    private static final long serialVersionUID = -3523847918671882524L;
    @Column(name = "id")
    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterSocialAccountListJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private List<SocialAccountItem> socialAccountList;

    public ShardSocialAccount(IdentityId identityId, List<SocialAccountItem> socialAccountList) {
        this.identityId = identityId;
        this.socialAccountList = socialAccountList;
    }

    @JSONField(serialize = false)
    public String getTenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElseThrow(() -> new BusinessException(ResultEnum.TENANT_CONFIG_NOT_EXIST.getCode(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getMessage()));
    }

    @JSONField(serialize = false)
    public String getAccountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
    }

    @JSONField(serialize = false)
    public String getChannelId() {
        return Optional.ofNullable(socialAccountList).flatMap(a -> a.stream().findFirst()).map(SocialAccountItem::getChannel).map(Channel::getChannelId).orElse(null);
    }

    @JSONField(serialize = false)
    public Channel getChannel() {
        return Optional.ofNullable(socialAccountList).flatMap(a -> a.stream().findFirst()).map(SocialAccountItem::getChannel).orElse(null);
    }

    @JSONField(serialize = false)
    public String getBindId() {
        return Optional.ofNullable(socialAccountList).flatMap(a -> a.stream().findFirst()).map(SocialAccountItem::getBindId).orElse(null);
    }

    @JSONField(serialize = false)
    public String getUnionId() {
        return Optional.ofNullable(socialAccountList).flatMap(a -> a.stream().findFirst()).map(SocialAccountItem::getUnionId).orElse(null);

    }

    public List<SocialAccountItem> getSocialAccountList() {
        return Optional.ofNullable(this.socialAccountList).filter(socialAccountItems -> !socialAccountItems.isEmpty()).orElse(null);
    }

    /**
     * 将accountId赋值到订阅信息中
     */
    public void specialIdentityId(IdentityId identityId) {
        Validate.notNull(identityId, "identityId is null");
        Validate.notNull(identityId.getAccountId(), "accountId is null");
        this.identityId.specialAccountId(identityId.getAccountId());
    }

    @Override
    public boolean sameIdentityAs(ShardSocialAccount other) {
        return other != null && this.identityId.getAccountId().equals(other.getIdentityId().getAccountId());
    }

    public void build(IdentityId identityId, List<SocialAccountItem> socialAccountItemList) {
        this.identityId = identityId;
        super.addCreateTime();
        this.socialAccountList = socialAccountItemList;
    }

    public String tenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElse(null);
    }

    public String accountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElse(null);
    }

    public static final class ShardSocialAccountBuilder {
        private final IdentityId.IdentityIdBuilder identityIdBuilder = IdentityId.IdentityIdBuilder.anIdentityId();
        protected LocalDateTime createdTime;
        protected LocalDateTime updatedTime;
        private Long id;
        private IdentityId identityId;
        private List<SocialAccountItem> socialAccountList;


        private ShardSocialAccountBuilder() {
        }

        public static ShardSocialAccountBuilder aShardSocialAccount() {
            return new ShardSocialAccountBuilder();
        }

        public ShardSocialAccountBuilder id(Long id) {
            this.id = id;
            return this;
        }

        public ShardSocialAccountBuilder identityId(IdentityId identityId) {
            this.identityId = identityId;
            return this;
        }

        public ShardSocialAccountBuilder socialAccountList(List<SocialAccountItem> socialAccountList) {
            this.socialAccountList = socialAccountList;
            return this;
        }

        public ShardSocialAccountBuilder createdTime(LocalDateTime createdTime) {
            this.createdTime = createdTime;
            return this;
        }

        public ShardSocialAccountBuilder updatedTime(LocalDateTime updatedTime) {
            this.updatedTime = updatedTime;
            return this;
        }

        public ShardSocialAccount.ShardSocialAccountBuilder tenantId(String tenantId) {
            Validate.notNull(tenantId, "tenantId is null");
            this.identityId = identityIdBuilder.tenantId(tenantId).build();
            return this;
        }

        public ShardSocialAccount.ShardSocialAccountBuilder accountId(String accountId) {
            this.identityId = identityIdBuilder.accountId(accountId).build();
            return this;
        }

        public ShardSocialAccount build() {
            ShardSocialAccount shardSocialAccount = new ShardSocialAccount();
            shardSocialAccount.setId(id);
            shardSocialAccount.setIdentityId(identityId);
            shardSocialAccount.setSocialAccountList(socialAccountList);
            shardSocialAccount.setCreatedTime(createdTime);
            shardSocialAccount.setUpdatedTime(updatedTime);
            return shardSocialAccount;
        }
    }
}
