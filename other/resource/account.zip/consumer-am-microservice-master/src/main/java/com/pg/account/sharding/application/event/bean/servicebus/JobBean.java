package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 工作信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobBean implements Serializable {
    private static final long serialVersionUID = -3780191504050764058L;
    @JSONField(ordinal = 1)
    private String relationType;
    @JSONField(ordinal = 2)
    private String relationSeq;
    @JSONField(ordinal = 3)
    private String province;
    @JSONField(ordinal = 4)
    private String city;
    @JSONField(ordinal = 5)
    private String district;
    @JSONField(ordinal = 6)
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @JSONField(ordinal = 7)
    private String zipCode;
    @JSONField(ordinal = 8)
    private String name;
    @JSONField(ordinal = 9)
    private String category;
    @JSONField(ordinal = 10)
    private String profession;
    @JSONField(ordinal = 11)
    private Timestamp createTime;
    @JSONField(ordinal = 12)
    private Timestamp modifyTime;
}
