package com.pg.account.sharding.infrastructure.jpa.config;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author Jack
 * @date 2021/6/2 21:42
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_CONFIGURATION")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardConfiguration extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -2581485591512262006L;
    @Id
    private Long id;
    private String tenantId;
    private String configKey;
    private String configValue;
    private String channelId;
    private String createBy;
    private String modifyBy;
    private Byte status;
}
