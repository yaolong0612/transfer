package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.UserBasicInfo;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.infrastructure.jpa.mapping.EmailMappingDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMappingDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.OpenUidMappingDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author lfx
 * @date 2021/6/10 23:52
 */
@Service
public class CancelService {
    private final EmailMappingDao emailMappingDao;
    private final MobileMappingDao mobileMappingDao;
    private final OpenUidMappingDao openUidMappingDao;
    private final ShardSocialAccountRepository socialAccountRepository;
    private final AccountRepository accountRepository;

    @Autowired
    public CancelService(EmailMappingDao emailMappingDao, MobileMappingDao mobileMappingDao, OpenUidMappingDao openUidMappingDao, AccountRepository accountRepository, ShardSocialAccountRepository socialAccountRepository) {
        this.emailMappingDao = emailMappingDao;
        this.mobileMappingDao = mobileMappingDao;
        this.openUidMappingDao = openUidMappingDao;
        this.socialAccountRepository = socialAccountRepository;
        this.accountRepository = accountRepository;
    }

    /**
     * 將account的郵箱手機號置空
     *
     * @param account account
     */
    public void cancellation(Account account) {
        ShardSocialAccount socialAccount = socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.getTenantId(), account.getAccountId());
        if (Optional.ofNullable(socialAccount).map(ShardSocialAccount::getSocialAccountList).filter(s -> !s.isEmpty()).isPresent()) {
            throw new BusinessException(ResultEnum.BIND_DATA_TYPE_CONFLICT.getCode(), ResultEnum.BIND_DATA_TYPE_CONFLICT.getV2Code(), ResultEnum.BIND_DATA_TYPE_CONFLICT.getMessage());
        }
        account.inActiveStatus();
        UserBasicInfo.UserBasicInfoBuilder userBasicInfoBuilder = UserBasicInfo.UserBasicInfoBuilder.anUserBasicInfo();
        Optional.ofNullable(account.getUserBasicInfo()).ifPresent(u -> {
            userBasicInfoBuilder.fullName(u.getFullName());
            userBasicInfoBuilder.nickName(u.getNickName());
            userBasicInfoBuilder.birthday(u.getBirthday());
            userBasicInfoBuilder.gender(u.getGender());
        });
        mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(account.getTenantId(), account.getMobile());
        emailMappingDao.deleteByEmailMapId_TenantIdAndEmailMapId_Email(account.getTenantId(), account.getEmail());
        openUidMappingDao.deleteByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(account.getTenantId(), account.getOpenUid());
        account.setUserBasicInfo(userBasicInfoBuilder.build());
        //更新accountInfo
        accountRepository.saveAccountInfo(account);
    }
}
