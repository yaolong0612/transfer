package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.UnionIdValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author lfx
 * @date 2021/11/29 14:28
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = UnionIdValidator.class)
public @interface UnionIdIsNecessary {

    String message() default "unionId must not be null";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
