package com.pg.account.infrastructure.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD;

/**
 * 时间工具类
 *
 * @author JackSun
 */
@Slf4j
public class DateUtil extends DateUtils {
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    private static final String DATE_PATTERN = "yyyy-MM-dd";

    /**
     * 获取当前的timestamp
     */
    public static Timestamp getCurrentTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * 取得指定日期格式的字符串
     *
     * @param date   时间
     * @param format 格式
     * @return String
     */
    public static String formatDate(Date date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    public static String formatLocalDateTime(LocalDateTime date) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(YYYY_MM_DD_HH_MM_SS);
        return date.format(dtf);
    }

    /**
     * 获取当前月份
     *
     * @param date 时间
     * @return int
     */
    public static int getNowMonth(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MONTH) + 1;
    }

    /**
     * 获取当前日
     *
     * @param date 时间
     * @return int
     */
    public static int getNowDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.DATE);
    }

    /**
     * 获取昨日的日期格式串
     *
     * @return Date
     */
    public static String getYesterday() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1);
        return formatDate(calendar.getTime(), YYYY_MM_DD);
    }

    /**
     * 计算 minute 分钟后的时间
     *
     * @param date   时间
     * @param minute 分
     * @return Date
     */
    public static Date addMinute(Date date, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MINUTE, minute);
        return calendar.getTime();
    }

    /**
     * 计算 hour 小时后的时间
     *
     * @param date 时间
     * @param hour 小时
     * @return Date
     */
    public static Date addHour(Date date, int hour) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR, hour);
        return calendar.getTime();
    }

    /**
     * 计算 day 天后的时间
     *
     * @param date 时间
     * @param day  天
     * @return Date
     */
    public static Date addDay(Date date, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        return calendar.getTime();
    }

    /**
     * 获取某月的最后一天
     *
     * @param date 时间
     * @return Date
     */
    public static Date getMonthLastDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, 1);
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        return calendar.getTime();
    }

    /**
     * 时间格式转换
     *
     * @param dt   时间
     * @param sFmt 格式
     * @return String
     */
    public static String toString(Date dt, String sFmt) {
        if (dt == null || sFmt == null || "".equals(sFmt)) {
            return "";
        }
        return toString(dt, new SimpleDateFormat(sFmt));
    }

    /**
     * 时间格式转换
     *
     * @param dt        时间
     * @param formatter 格式
     * @return String
     */
    private static String toString(Date dt, SimpleDateFormat formatter) {
        String sRet;
        try {
            sRet = formatter.format(dt);
        } catch (Exception e) {
            log.warn("原始异常", e);
            sRet = null;
        }
        return sRet;
    }

    /**
     * 时间字符串转化成日期格式
     *
     * @param date 时间
     * @return Date
     */
    public static Date fromMysqlDate(String date) {
        DateFormat fmt = new SimpleDateFormat(YYYY_MM_DD);
        try {
            return fmt.parse(date);
        } catch (ParseException e) {
            throw new RuntimeException();
        }
    }

    /**
     * 时间字符串转化成日期格式
     *
     * @param date 时间
     * @param form 格式
     * @return Date
     */
    public static Date formDate(String date, String form) {
        DateFormat fmt = new SimpleDateFormat(form);
        try {
            return fmt.parse(date);
        } catch (ParseException e) {
            log.warn("日期解析异常:{}", e.getMessage());
            return null;
        }
    }

    /**
     * 获取两个月份中间相差几个月，会自动使用最大月份减最小月份
     *
     * @param start 开始
     * @param end   结束
     * @return int
     */
    public static int getDifferenceMonth(Date start, Date end) {
        if (start.after(end)) {
            Date t = start;
            start = end;
            end = t;
        }
        Calendar startCalendar = Calendar.getInstance();
        startCalendar.setTime(start);
        Calendar endCalendar = Calendar.getInstance();
        endCalendar.setTime(end);
        Calendar temp = Calendar.getInstance();
        temp.setTime(end);
        temp.add(Calendar.DATE, 1);

        int year = endCalendar.get(Calendar.YEAR)
                - startCalendar.get(Calendar.YEAR);
        int month = endCalendar.get(Calendar.MONTH)
                - startCalendar.get(Calendar.MONTH);

        if ((startCalendar.get(Calendar.DATE) == 1)
                && (temp.get(Calendar.DATE) == 1)) {
            return year * 12 + month + 1;
        } else if ((startCalendar.get(Calendar.DATE) != 1)
                && (temp.get(Calendar.DATE) == 1)) {
            return year * 12 + month;
        } else if ((startCalendar.get(Calendar.DATE) == 1)
                && (temp.get(Calendar.DATE) != 1)) {
            return year * 12 + month;
        } else {
            return (year * 12 + month - 1) < 0 ? 0 : (year * 12 + month);
        }
    }

    /**
     * date类型转换为long类型
     * date要转换的date类型的时间
     *
     * @param date 时间
     * @return long
     */
    public static long dateToLong(Date date) {
        return date.getTime();
    }

    /**
     * 获取当前星期数
     *
     * @param date 时间
     * @return String
     */
    public static String getDayOfWeek(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        switch (c.get(Calendar.DAY_OF_WEEK)) {
            case 1:
                return "周日";
            case 2:
                return "周一";
            case 3:
                return "周二";
            case 4:
                return "周三";
            case 5:
                return "周四";
            case 6:
                return "周五";
            case 7:
                return "周六";
            default:
                return "未知日期";
        }
    }

    /**
     * 时间相减
     *
     * @param date1 时间
     * @param date2 时间
     * @return long
     */
    public static long getDateDiff(Date date1, Date date2) {
        if (date1 == null || date2 == null) {
            throw new IllegalArgumentException("date1 and date2 must not be null");
        }
        return (date1.getTime() - date2.getTime()) / (24 * 60 * 60 * 1000) > 0 ? (date1.getTime() - date2
                .getTime()) / (24 * 60 * 60 * 1000) : (date2.getTime() - date1.getTime()) / (24 * 60 * 60 * 1000);
    }

    /**
     * 获取剩余时间=limitTime-(当前时间-startTime)
     *
     * @param limitTime 限制时间点，例如30分钟
     * @param startTime 开始时间
     * @return 返回剩余时间，如果当前时间-startTime>=limitTime返回0， 否则返回剩余时间的毫秒数
     */
    public static long getRemainingTime(long limitTime, Date startTime) {
        if (startTime == null) {
            return 0L;
        }
        // 当前时间  - 起始时间
        long diffTime = System.currentTimeMillis() - startTime.getTime();
        // 如果超过限制时间，则返回0
        if (diffTime >= limitTime) {
            return 0L;
        }
        return limitTime - diffTime;
    }


    public static String getDatePattern() {
        return DATE_PATTERN;
    }

    public static String getShortDateTimePattern() {
        return getDatePattern() + " HH:mm:ss";
    }

    /**
     * 时间格式化
     *
     * @param aDate 时间
     * @return String
     */
    public static String getDate(Date aDate) {
        SimpleDateFormat df;
        String returnValue = null;
        if (aDate != null) {
            df = new SimpleDateFormat(getShortDateTimePattern());
            returnValue = df.format(aDate);
        }
        return returnValue;
    }


}
