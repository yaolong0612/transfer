package com.pg.account.infrastructure.common.exception;

/**
 * ExternalSystemException
 *
 * @author Jack Sun
 * @date 2019-11-25 16:24
 */
public class ExternalSystemException extends ResultException {


    private static final long serialVersionUID = -741390483767471358L;

    /**
     * 外部系统异常
     *
     * @param code    code
     * @param v2Code  v2Code
     * @param message message
     */
    public ExternalSystemException(Integer code, Integer v2Code, String message) {
        super(code, v2Code, message);
    }
}
