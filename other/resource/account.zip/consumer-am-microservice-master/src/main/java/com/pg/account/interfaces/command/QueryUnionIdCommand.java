package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author Jack Sun
 * @date 2019-4-30 13:18
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryUnionIdCommand implements Serializable {
    private static final long serialVersionUID = 4108883358081916339L;
    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY")
    @NotBlank(message = "missing UNION_ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    private String unionType;
}
