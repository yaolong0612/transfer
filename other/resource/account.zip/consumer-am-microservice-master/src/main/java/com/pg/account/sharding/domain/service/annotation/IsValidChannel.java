//package com.pg.account.sharding.domain.service.annotation;
//
//import com.pg.account.sharding.domain.service.StringValidator;
//
//import javax.validation.Constraint;
//import javax.validation.Payload;
//import java.lang.annotation.Documented;
//import java.lang.annotation.Retention;
//import java.lang.annotation.RetentionPolicy;
//import java.lang.annotation.Target;
//
//import static java.lang.annotation.ElementType.*;
//
///**
// * @author lfx
// * @date 2022/1/5 11:11
// */
//@Documented
//@Retention(RetentionPolicy.RUNTIME)
//@Target({FIELD, METHOD, PARAMETER})
//@Constraint(validatedBy = StringValidator.ChannelValid.class)
//public @interface IsValidChannel {
//    String message() default "channel is not exist";
//
//    Class<?>[] groups() default {};
//
//    Class<? extends Payload>[] payload() default {};
//}
