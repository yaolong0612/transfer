package com.pg.account.sharding.domain.model.socialaccount;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.interfaces.dto.BindDTO;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.Customer;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

import static java.lang.Long.parseLong;

/**
 * 绑定信息类
 *
 * @author dell
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SocialAccountItem implements ValueObject<SocialAccountItem> {
    private static final long serialVersionUID = -8416936270553676457L;

    private Channel channel;
    private String source;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    private Customer customer;

    private LocalDateTime bindTime;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    @Override
    public boolean sameValueAs(SocialAccountItem other) {
        return this.equals(other);
    }

    public void build(Channel channel, String source, String bindId, String unionId) {
        this.channel = channel;
        this.source = source;
        this.bindId = bindId;
        this.unionId = unionId;
        this.bindTime = LocalDateTime.now();
        this.createTime = LocalDateTime.now();
        this.updateTime = LocalDateTime.now();
    }

    public void buildCustomer(String customer,String regStore){
        if(!Optional.ofNullable(this.customer).isPresent()){
            this.customer = new Customer();
        }
        this.customer.setName(customer);
        this.customer.setRegStore(regStore);
    }

    /**
     * 获取channelId
     */
    @JSONField(serialize = false)
    public String getUnionType() {
        return Optional.ofNullable(this.channel).map(Channel::getUnionType).orElse(null);
    }

    /**
     * 获取unionIdType
     */
    @JSONField(serialize = false)
    public String getChannelId() {
        return Optional.ofNullable(this.channel).map(Channel::getChannelId).orElse(null);
    }

    /**
     * 获取bindId
     */
    public String getBindId() {
        return Optional.ofNullable(this.bindId).orElse(null);
    }

    /**
     * 获取unionId
     */
    public String getUnionId() {
        return Optional.ofNullable(this.unionId).orElse(null);
    }

    public BindDTO build() {
        BindDTO bindDTO = new BindDTO();
        bindDTO.setChannelId(parseLong(this.channel.getChannelId()));
        bindDTO.setBindId(this.bindId);
        bindDTO.setUnionId(this.unionId);
        return bindDTO;
    }

    public void buildFromDb(SocialAccountItem db) {
        Optional.ofNullable(db).ifPresent(s -> {
            if (Optional.ofNullable(this.getChannel()).isPresent()) {
                this.channel.buildFromDb(Optional.ofNullable(db.channel).orElse(null));
            } else {
                Channel channelNew = new Channel();
                channelNew.buildFromDb(Optional.ofNullable(db.channel).orElse(null));
                this.channel = channelNew;
            }
            this.source = Optional.ofNullable(this.source).orElse(db.source);
            this.bindId = Optional.ofNullable(this.bindId).orElse(db.bindId);
            this.unionId = Optional.ofNullable(this.unionId).orElse(db.unionId);
            this.bindTime = Optional.ofNullable(this.bindTime).orElse(db.bindTime);
            this.createTime = Optional.ofNullable(this.createTime).orElse(db.createTime);
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(db.updateTime);
        });
    }

}
