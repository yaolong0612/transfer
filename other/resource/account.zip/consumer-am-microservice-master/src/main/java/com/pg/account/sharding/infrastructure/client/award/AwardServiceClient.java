package com.pg.account.sharding.infrastructure.client.award;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * AwardFeignClient
 *
 * @author Jack Sun
 * @date 2019-6-24 15:50
 */
@FeignClient(name = "cms-loyalty")
public interface AwardServiceClient {

    /**
     * 统一加积分
     *
     * @param url     请求地址
     * @param request 请求信息
     * @return JSON
     */
    @PostMapping(value = "{url}", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> addAward(@PathVariable("url") String url, @RequestBody String request);
}
