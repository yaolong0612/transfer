package com.pg.account.sharding.infrastructure.job;

import cn.com.pg.paas.monitor.infrastructure.StreamingUtil;
import com.github.benmanes.caffeine.cache.Cache;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.interceptor.RequestIdConverter;
import com.pg.account.sharding.infrastructure.redis.RedisBaseUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.concurrent.ConcurrentMap;


/**
 * @author leiyingbin
 */
@Slf4j
@Service
public class UpdateLocalCacheConfigJob {

    public static final String UPDATE_REDIS_TAG = "redisConfigurationPropertyUpdateTag";
    public static final String SUC_FLAG = "success";

    public static final String ERROR_CODE = "error_code";
    public static final String ERROR_MSG = "error_msg";
    public static final String REQUEST_ID = "request_id";

    @Autowired
    Cache<String, Object> caffeineCache;

    @Autowired
    RedisBaseUtils redisBaseUtils;

    @Autowired
    StreamingUtil streamingUtil;

    @Scheduled(cron = "0 0/10 * * * ? ")
    public void execute() {
        String updateTag = (String) retryCallRedis(UPDATE_REDIS_TAG);
        if (StringUtils.isEmpty(updateTag) || !updateTag.equals(SUC_FLAG)) {
            return;
        }

        ConcurrentMap<String, Object> map = caffeineCache.asMap();
        map.keySet().forEach(key -> {
            if (redisBaseUtils.exists(key)) {
                Object object = retryCallRedis(key);
                caffeineCache.put(key, object);
            } else {
                caffeineCache.invalidate(key);
            }
        });
    }

    /**
     * kpi日志推送
     *
     * @param e
     */
    public void sendKpi(Exception e) {
        HashMap<String, Object> object = new HashMap<>(6);
        object.put(REQUEST_ID, RequestIdConverter.getRequestId());
        object.put(ERROR_CODE, ResultEnum.REDIS_ERROR.getCode());
        object.put(ERROR_MSG, e.getMessage());
        streamingUtil.sendKpiEventhub(object);
    }

    /**
     * redis重试3次
     *
     * @param key
     * @return
     */
    public Object retryCallRedis(String key) {
        int retryCount = 0;
        while (true) {
            retryCount++;
            try {
                return redisBaseUtils.get(key);
            } catch (Exception e) {
                if (retryCount >= 3) {
                    log.error("redis操作失败.", e);
                    sendKpi(e);
                    throw e;
                }
            }
        }
    }
}