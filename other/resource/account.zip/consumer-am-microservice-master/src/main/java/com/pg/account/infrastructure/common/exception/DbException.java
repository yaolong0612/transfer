package com.pg.account.infrastructure.common.exception;

/**
 * DbException
 *
 * @author Jack Sun
 * @date 2019-11-25 16:23
 */
public class DbException extends ResultException {


    private static final long serialVersionUID = -4523946083807680489L;

    /**
     * 数据库异常
     *
     * @param code    code
     * @param v2Code  v2Code
     * @param message message
     */
    public DbException(Integer code, Integer v2Code, String message) {
        super(code, v2Code, message);
    }
}
