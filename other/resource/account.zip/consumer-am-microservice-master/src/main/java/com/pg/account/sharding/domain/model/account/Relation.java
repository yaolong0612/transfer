package com.pg.account.sharding.domain.model.account;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.Data;

import java.util.Arrays;
import java.util.Optional;

/**
 * 关系信息类
 *
 * @author dell1
 */
@Data
public class Relation implements ValueObject<Relation> {

    private static final long serialVersionUID = -1289336938727041789L;
    private RelationType relationType;
    private String sequence;

    @Override
    public boolean sameValueAs(Relation other) {
        return this.equals(other);
    }

    public void relationType(RelationType relationType) {
        this.relationType = relationType;
    }

    public void sequence(String sequence) {
        this.sequence = sequence;
    }


    public void builder(Relation db) {
        Optional.ofNullable(db).ifPresent(r -> {
            this.relationType = Optional.ofNullable(this.relationType).orElse(db.getRelationType());
            this.sequence = Optional.ofNullable(this.sequence).orElse(db.getSequence());
        });
    }
}
