package com.pg.account.sharding.domain.model.account;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.PasswordUtils;
import com.pg.account.infrastructure.common.utils.UUIDUtils;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 安全信息类
 *
 * @author Jack
 * @date 2021/5/27 13:49
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Security implements ValueObject<Security> {
    private static final long serialVersionUID = -7757433392739644704L;
    private SecurityType type;
    private String encryptedCode;
    private String salt;

    private LocalDateTime expiredTime;

    public static Security registerFrom(String salt, String encryptedCode, LocalDateTime expiredTime) {
        return new Security(null, encryptedCode, salt, expiredTime);
    }

    @Override
    public boolean sameValueAs(Security other) {
        return this.equals(other);
    }

    /**
     * encryption
     */
    public void encryptPassword(String logonPassword) {
        this.salt = UUIDUtils.generateUuid();
        this.encryptedCode = PasswordUtils.encrypt(logonPassword.concat(this.salt));
        this.expiredTime = LocalDateTime.now();
    }

    /**
     * 校验密码
     *
     * @param password password
     */
    public void checkPassword(String password) {
        if (Optional.ofNullable(this.salt).isPresent()) {
            if (!this.encryptedCode.equals(PasswordUtils.encrypt(password.concat(this.salt)))) {
                throw new BusinessException(ResultEnum.INCORRECT_PASSWORD.getCode(), ResultEnum.INCORRECT_PASSWORD.getV2Code(), ResultEnum.INCORRECT_PASSWORD.getMessage());
            }
        } else {
            if (!this.encryptedCode.equals(PasswordUtils.encrypt(password))) {
                throw new BusinessException(ResultEnum.INCORRECT_PASSWORD.getCode(), ResultEnum.INCORRECT_PASSWORD.getV2Code(), ResultEnum.INCORRECT_PASSWORD.getMessage());
            }
        }
    }

    public static final class SecurityBuilder {
        private SecurityType type;
        private String encryptedCode;
        private String salt;
        private LocalDateTime expiredTime;

        private SecurityBuilder() {
        }

        public static SecurityBuilder aSecurity() {
            return new SecurityBuilder();
        }

        public SecurityBuilder type(SecurityType type) {
            this.type = type;
            return this;
        }

        public SecurityBuilder encryptedCode(String encryptedCode) {
            this.encryptedCode = encryptedCode;
            return this;
        }

        public SecurityBuilder salt(String salt) {
            this.salt = salt;
            return this;
        }

        public String getSalt() {
            return this.salt;
        }

        public void encryptPassword(String logonPassword) {
            this.salt = UUIDUtils.generateUuid();
            this.encryptedCode = PasswordUtils.encrypt(logonPassword.concat(this.salt));
            this.expiredTime = LocalDateTime.now();
        }

        public SecurityBuilder expiredTime(LocalDateTime expiredTime) {
            this.expiredTime = expiredTime;
            return this;
        }

        public Security build() {
            Security security = new Security();
            security.setType(type);
            security.setEncryptedCode(encryptedCode);
            security.setSalt(salt);
            security.setExpiredTime(expiredTime);
            return security;
        }
    }
}
