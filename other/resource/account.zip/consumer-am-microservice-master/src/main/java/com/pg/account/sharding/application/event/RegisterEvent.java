package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class RegisterEvent extends ApplicationEvent {

    private static final long serialVersionUID = 8349731597965870674L;
    private final String flag = "new";
    private Account account;
    private ShardSubscription shardSubscription;

    public RegisterEvent(Object source) {
        super(source);
    }

    public RegisterEvent(Object source, Account account, ShardSubscription shardSubscription) {
        super(source);
        this.account = account;
        this.shardSubscription = shardSubscription;
    }
}
