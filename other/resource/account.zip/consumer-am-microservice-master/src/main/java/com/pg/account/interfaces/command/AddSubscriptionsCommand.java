package com.pg.account.interfaces.command;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.NUMBER_PATTERN;

/**
 * @author JackSun
 * @date 2017/2/10
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddSubscriptionsCommand implements Serializable {
    private static final long serialVersionUID = 996145355048912920L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12", required = true)
    @NotNull(message = "channel is not exist")
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @NotBlank(message = "missing memberId")
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "订阅信息集合", required = true)
    @Valid
    @NotNull(message = "missing subscription")
    @Size(min = 1, message = "missing subscription")
    private List<SubscriptionCommand> subscriptions;
}
