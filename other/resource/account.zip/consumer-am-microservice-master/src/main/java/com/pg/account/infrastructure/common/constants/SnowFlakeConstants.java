package com.pg.account.infrastructure.common.constants;

/**
 * 雪花算法常量
 *
 * @author xusheng
 * @date 2019/12/12 <br>
 */
public class SnowFlakeConstants {

    /**
     * 起始的时间戳
     */
    public static final long START_STAMP = 1480166465631L;
    /**
     * 序列号占用的位数
     */
    public static final long SEQUENCE_BIT = 12;
    /**
     * 机器标识占用的位数
     */
    public static final long MACHINE_BIT = 5;
    /**
     * 数据中心占用的位数
     */
    public static final long DATACENTER_BIT = 5;
    /**
     * 数据中心最大值
     */
    public static final long MAX_DATACENTER_NUM = -1L ^ (-1L << DATACENTER_BIT);
    /**
     * 机器标识占用最大值
     */
    public static final long MAX_MACHINE_NUM = -1L ^ (-1L << MACHINE_BIT);
    /**
     * 序列占用最大值
     */
    public static final long MAX_SEQUENCE = -1L ^ (-1L << SEQUENCE_BIT);
    /**
     * 机器标识左移位数=12
     */
    public static final long MACHINE_LEFT = SEQUENCE_BIT;
    /**
     * 数据中心左移位数=17
     */
    public static final long DATACENTER_LEFT = SEQUENCE_BIT + MACHINE_BIT;
    /**
     * 时间戳左移位数=22
     */
    public static final long TIMESTMP_LEFT = DATACENTER_LEFT + DATACENTER_BIT;

    private SnowFlakeConstants() {
        //私有构造方法
    }

}
