package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Set;

/**
 * @author Jack Sun
 * @date 2020-8-31 14:47
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountSubscriptionsModifyCommand implements Serializable {
    private static final long serialVersionUID = -9160815684712729103L;

    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @NotBlank(message = "missing openId")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
    @ApiModelProperty(value = "Subscriptions Information", name = "Subscriptions")
    @Valid
    @NotNull(message = "subscriptions must not null")
    private Set<SubscriptionCommand> subscriptions;
}
