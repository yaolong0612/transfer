package com.pg.account.infrastructure.common.enums;

/**
 * @author JackSun
 * @date 2017/2/10
 */
public enum IsPrimaryEnum {
    /**
     * 是否主地址
     */
    YES("1"), NO("0");
    private final String value;

    IsPrimaryEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
