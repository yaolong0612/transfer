package com.pg.account.interfaces.dto.v2;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * com.pg.account.interfaces.dto
 * SubscriptionQueryDTO
 *
 * @author Jack Sun
 * @date 2020-8-31 17:02
 * <p>
 * 2020-8-31 17:02
 */
@ApiModel(value = "SubscriptionDTO_V2")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionDTO implements Serializable {
    private static final long serialVersionUID = -2403281739555377920L;

    @ApiModelProperty(value = "Subscription id", name = "optId", example = "103", required = true)
    private String optId;
    @ApiModelProperty(value = "Subscription name", name = "optName", example = "短信彩信", required = true)
    private String optName;
    @ApiModelProperty(value = "Subscription status I or O (I, subscription, O, unsubscribe)", name = "optStatus", example = "I", required = true)
    private String optStatus;

    public SubscriptionDTO(String optId, String optStatus) {
        this.optId = optId;
        this.optStatus = optStatus;
    }
}
