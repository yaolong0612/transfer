package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.StringValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

/**
 * @author lfx
 * @date 2021/12/31 13:19
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({FIELD, METHOD, PARAMETER})
@Constraint(validatedBy = StringValidator.TenantValid.class)
public @interface IsValidTenant {
    String message() default "tenant is not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
