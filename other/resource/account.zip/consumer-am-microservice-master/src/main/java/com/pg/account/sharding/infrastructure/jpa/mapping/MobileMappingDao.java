package com.pg.account.sharding.infrastructure.jpa.mapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author lfx
 * @date 2021/5/31 14:48
 */
public interface MobileMappingDao extends JpaRepository<MobileMapping, Long> {

    /**
     * 根据手机号查询map关系
     *
     * @param tenantId tenantId
     * @param mobile   mobile
     * @return MobileMapping
     */
    MobileMapping findByMobileMapId_TenantIdAndMobileMapId_Mobile(String tenantId, String mobile);

    /**
     * 根据tenantId和mobile删除映射关系
     *
     * @param tenantId tenantId
     * @param mobile   mobile
     */
    @Modifying
    @Transactional
    int deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(String tenantId, String mobile);


}
