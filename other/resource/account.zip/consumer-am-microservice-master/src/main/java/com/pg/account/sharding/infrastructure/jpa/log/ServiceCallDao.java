package com.pg.account.sharding.infrastructure.jpa.log;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author yj
 */
public interface ServiceCallDao extends JpaRepository<ShardServiceCall, Long> {

}
