package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.concurrent.BasicThreadFactory;
import org.springframework.stereotype.Service;

import java.lang.ref.WeakReference;
import java.time.LocalDateTime;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author YJ
 */
@Service
@Slf4j
public class WatchDog {


    public static final String SHARD_SYNC_LOCK = "shard_sync_lock";
    public static final String OLD_SYNC_LOCK = "old_sync_lock";
    public static final String EXPIRE_TIME = "expireTime";

    private static ConcurrentHashMap<String, WeakReference<Thread>> map = new ConcurrentHashMap();

    /**
     * 每15秒定时执行延长过期时间操作
     */
    public static void executeFixedRate() {
        ScheduledExecutorService scheduledExecutorService = new ScheduledThreadPoolExecutor(1,
                new BasicThreadFactory.Builder().namingPattern("example-schedule-pool-%d").daemon(true).build());
        //定时线程池 每过15秒执行一次
        scheduledExecutorService.scheduleAtFixedRate(() -> {
            Enumeration<String> keys = map.keys();
            while (keys.hasMoreElements()) {
                //有key开始判断
                String nextElement = keys.nextElement();
                WeakReference<Thread> threadWeakReference = map.get(nextElement);
                if (threadWeakReference.get() != null && nextElement.equals("old")) {
                    //获取redis锁的值
                    String value = (String) RedisConfigUtils.getValue(OLD_SYNC_LOCK);
                    //锁里面的值
                    JSONObject parse = JSON.parseObject(value);
                    LocalDateTime expireTime = LocalDateTime.now().plusMinutes(1L);
                    if (value != null) {
                        parse.put(EXPIRE_TIME, expireTime);
                        String s = parse.toString();
                        //如果存在key 则塞入value
                        RedisConfigUtils.setIfPresent(OLD_SYNC_LOCK, s);
                    }
                } else if (threadWeakReference.get() != null && nextElement.equals("new")) {
                    //获取redis锁的值
                    String value = (String) RedisConfigUtils.getValue(SHARD_SYNC_LOCK);
                    //锁里面的值
                    JSONObject parse = JSON.parseObject(value);
                    LocalDateTime expireTime = LocalDateTime.now().plusMinutes(1L);
                    if (value != null) {
                        parse.put(EXPIRE_TIME, expireTime);
                        String s = parse.toString();
                        //如果存在key 则塞入value
                        RedisConfigUtils.setIfPresent(SHARD_SYNC_LOCK, s);
                    }
                } else {
                    //删除key
                    if (null == threadWeakReference.get()) {
                        map.remove(nextElement);
                    }
                }
            }

        }, 0, 15, TimeUnit.SECONDS);
    }

    public void watch(Thread thread, String flag) {
        map.put(flag, new WeakReference<>(thread));
    }

}
