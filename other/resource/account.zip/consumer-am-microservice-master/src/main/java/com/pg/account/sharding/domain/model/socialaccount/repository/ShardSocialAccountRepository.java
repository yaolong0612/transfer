package com.pg.account.sharding.domain.model.socialaccount.repository;

import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author yj
 */
public interface ShardSocialAccountRepository extends JpaRepository<ShardSocialAccount, Long> {


    /**
     * 根据accountIdId和tenantId查询绑定信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return SocialAccountInfo
     */
    ShardSocialAccount findByIdentityIdTenantIdAndIdentityIdAccountId(String tenantId, String accountId);

    /**
     * 根据租户和会员删除
     *
     * @param tenantId   tenantId
     * @param accountId accountId
     */
    @Modifying
    @Transactional
    void deleteByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);
}
