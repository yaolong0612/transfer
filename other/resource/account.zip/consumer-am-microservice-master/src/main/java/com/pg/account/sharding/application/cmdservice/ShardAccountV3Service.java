package com.pg.account.sharding.application.cmdservice;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.service.annotation.MemberExistValid;
import com.pg.account.sharding.domain.service.annotation.MoreThanOneParam;
import com.pg.account.sharding.interfaces.command.AccountConflictCommand;
import com.pg.account.sharding.interfaces.dto.QueryAccountConflictDTO;
import com.pg.account.sharding.interfaces.dto.QueryBindingDTO;
import com.pg.account.sharding.interfaces.dto.QuerySubscriptionDTO;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

/**
 * @author lfx
 * @date 2021/12/31 15:00
 */
@Validated
@Service
public interface ShardAccountV3Service {

    /**
     * 查询账号
     *
     * @param tenant  tenant
     * @param type    type
     * @param channel channel
     * @param query   query
     * @return Account
     */
    JSONObject queryAccountByType(String tenant, String type, String channel, String query);

    /**
     * 查询用户个人信息
     *
     * @param tenant  tenant
     * @param channel channel
     * @param type    type
     * @param fields  fields
     * @param query   query
     * @return Account
     */
    Account queryProfile(String tenant, String channel, String type, String fields, String query);

    /**
     * 查询绑定
     *
     * @param tenant  tenant
     * @param channel channel
     * @param type    type
     * @param query   query
     * @return JSONObject
     */
    QueryBindingDTO queryBinding(String tenant, String channel, String type, String query);


    /**
     * 查询冲突
     *
     * @param tenant                 tenant
     * @param channel                channel
     * @param accountConflictCommand accountConflictCommand
     * @return list of accountDTO
     */
    QueryAccountConflictDTO queryAccountConflict(String tenant, String channel, @MoreThanOneParam AccountConflictCommand accountConflictCommand);


    /**
     * 合并查询出来的冲突信息
     *
     * @param tenant  tenant
     * @param channel channel
     * @param mobile  mobile
     * @param bindId  bindId
     * @param unionId unionId
     * @return list of 用户基础和绑定信息
     */
    JSONArray combConflictAccount(String tenant, String channel, String mobile, String bindId, String unionId);


    /**
     * 查询冲突
     *
     * @param tenant                 tenant
     * @param channel                channel
     * @param accountConflictCommand accountConflictCommand
     * @return JSONObject
     */
    JSONObject getConflictResult(String tenant, String channel, AccountConflictCommand accountConflictCommand);

    /**
     * 入会
     *
     * @param account            account
     * @param shardSocialAccount shardSocialAccount
     * @param shardSubscription  shardSubscription
     * @return accountId
     */
    JSONObject signUp(@Valid @MemberExistValid Account account, ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription);

    /**
     * 查询订阅
     *
     * @param tenant    tenant
     * @param channel   channel
     * @param accountId accountId
     * @return QuerySubscriptionDTO
     */
    QuerySubscriptionDTO querySubscription(String tenant, String channel, String accountId);

    /**
     * 关注
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     */
    void follow(String tenant, String channel, String bindId);

    /**
     * 取关
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     */
    void unfollow(String tenant, String channel, String bindId);

}
