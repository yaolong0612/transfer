package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/2/9
 */
@ApiModel(value = "AttrDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttrDTO implements Serializable {
    private static final long serialVersionUID = 8588926028567400756L;
    @ApiModelProperty(value = "用户属性编号", example = "11301")
    private String attrId;
    @ApiModelProperty(value = "用户属性内容")
    private String attrVal;
}
