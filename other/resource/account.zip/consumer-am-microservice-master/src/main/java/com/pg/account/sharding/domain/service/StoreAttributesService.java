package com.pg.account.sharding.domain.service;


import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;

/**
 * @author yj
 */
@Slf4j
@Service
public class StoreAttributesService {

    public static final String VALIDATOR = "validator";
    private static final String PATH = "com.pg.account.sharding.domain.service.";

    private final ExtraAttributeDao extraAttributeDao;

    @Autowired
    public StoreAttributesService(ExtraAttributeDao extraAttributeDao) {
        this.extraAttributeDao = extraAttributeDao;
    }

    public void storeShardExtraAttributeAssembleValidator(Account account) {
        Validate.notEmpty(account.getUserAdditionalInfo().getExtraAttributeList(), "attributes is null");
        this.attrIdValidate(account);
    }

    /**
     * @param account account
     */
    private void attrIdValidate(Account account) {
        if (!Optional.ofNullable(account.getUserAdditionalInfo().getExtraAttributeList()).filter(extraAttributeItems -> !extraAttributeItems.isEmpty()).isPresent()) {
            return;
        }
        List<String> attrIdList = account.getUserAdditionalInfo().getExtraAttributeList().stream().map(ExtraAttributeItem::getAttrId).distinct().collect(Collectors.toList());
        if (account.getUserAdditionalInfo().getExtraAttributeList().size() != attrIdList.size()) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        account.getUserAdditionalInfo().getExtraAttributeList().forEach(extraAttributeItems -> {
            boolean isTrue = false;
            // 获取租户下的所有属性id配置
            String result = Optional.ofNullable(CacheLocalConfigUtils.getAttrId(account.getTenantId())).orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
            String[] x = result.split(COMMA);
            String dataType = null;
            for (String s : x) {
                String[] a = s.split(COLON);
                if (a[0].equals(extraAttributeItems.getAttrId())) {
                    isTrue = true;
                    String[] b = a[1].split(EQUAL);
                    if (a.length == 2) {
                        dataType = b[0];
                    }
                    // 判断属性的格式是否正确
                    if (!StringValidUtil.validateDataType(dataType, extraAttributeItems.getAttrValue())) {
                        throw new BusinessException(ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getCode(), ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getV2Code(), ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getMessage());
                    }
                    if (b.length == 2) {
                        validator(extraAttributeItems, b[1]);
                    }
                    break;
                }
            }
            if (!isTrue) {
                throw new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage());
            }

        });

    }

    /**
     * 校验属性
     *
     * @param extraAttributeItem 属性参数
     * @param classPath          类路径
     */
    private void validator(ExtraAttributeItem extraAttributeItem, String classPath) {
        String validatorPath;
        validatorPath = PATH + classPath.substring(classPath.lastIndexOf('.') + 1);
        Class<?> cls;
        try {
            cls = Class.forName(validatorPath);
            Object json = SpringContextUtil.getApplicationContext().getBean(cls).getClass().getDeclaredMethod(VALIDATOR, ExtraAttributeItem.class).invoke(SpringContextUtil.getApplicationContext().getBean(cls), extraAttributeItem);
            extraAttributeItem.setAttrValue(String.valueOf(json));
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException e) {
            throw new BusinessException(ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getCode(), ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getMessage());
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof BusinessException) {
                throw new BusinessException(((BusinessException) cause).getCode(), ((BusinessException) cause).getV2Code(), cause.getMessage());
            } else {
                throw new BusinessException(ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getCode(), ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getMessage());
            }
        }
    }

    /**
     * 保存
     *
     * @param account account
     */
    public void storeShardExtraAttribute(Account account) {
        ShardExtraAttribute dbShardExtraAttribute = this.extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
        if (Optional.ofNullable(dbShardExtraAttribute).isPresent()) {
            Iterator<ExtraAttributeItem> iterator = dbShardExtraAttribute.getExtraAttributeItemList().iterator();
            while (iterator.hasNext()) {
                ExtraAttributeItem dbExtraAttributeItem = iterator.next();
                account.getUserAdditionalInfo().getExtraAttributeList().forEach(extraAttributeItem -> {
                    if (dbExtraAttributeItem.getAttrId().equals(extraAttributeItem.getAttrId())) {
                        extraAttributeItem.builder(dbExtraAttributeItem);
                        iterator.remove();
                    }
                });
            }
            dbShardExtraAttribute.getExtraAttributeItemList().addAll(account.getUserAdditionalInfo().getExtraAttributeList());
            dbShardExtraAttribute.addUpdatedTime();
        } else {
            dbShardExtraAttribute = new ShardExtraAttribute();
            dbShardExtraAttribute.build(account);
        }
        extraAttributeDao.save(dbShardExtraAttribute);
    }
}
