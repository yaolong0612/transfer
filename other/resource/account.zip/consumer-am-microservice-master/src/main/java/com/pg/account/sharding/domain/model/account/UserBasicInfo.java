package com.pg.account.sharding.domain.model.account;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;

import java.util.Optional;

/**
 * 个人基本信息类
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserBasicInfo implements ValueObject<UserBasicInfo> {
    private static final long serialVersionUID = -8372642070542324013L;
    private Contact contact;
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    private String nickName;
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;

    @Override
    public boolean sameValueAs(UserBasicInfo other) {
        return this.equals(other);
    }

    /**
     * 添加通讯信息
     */
    public void contact(Contact contact) {
        Validate.notNull(contact, "UserBasicInfo contact is null");
        this.contact = contact;
    }

    public void buildFromDb(UserBasicInfo db) {
        Optional.ofNullable(db).ifPresent(info -> {
            if (Optional.ofNullable(this.contact).isPresent()) {
                this.contact.buildFromDb(Optional.ofNullable(db.getContact()).orElse(null));
            } else {
                Contact contactNew = new Contact();
                contactNew.buildFromDb(Optional.ofNullable(db.getContact()).orElse(null));
                this.contact = contactNew;
            }
            this.fullName = Optional.ofNullable(this.fullName).orElse(db.fullName);
            this.nickName = Optional.ofNullable(this.nickName).orElse(db.nickName);
            this.birthday = Optional.ofNullable(this.birthday).orElse(db.birthday);
            this.gender = Optional.ofNullable(this.gender).orElse(db.gender);
        });
    }


    public static final class UserBasicInfoBuilder {
        private final Contact.ContactBuilder contactBuilder = Contact.ContactBuilder.aContact();
        private Contact contact;
        @Desensitized(value = DesensitizedEnum.FULL_NAME)
        private String fullName;
        private String nickName;
        private String birthday;
        private String gender;

        private UserBasicInfoBuilder() {
        }

        public static UserBasicInfoBuilder anUserBasicInfo() {
            return new UserBasicInfoBuilder();
        }

        public UserBasicInfoBuilder contact(Contact contact) {
            this.contact = contact;
            return this;
        }

        public UserBasicInfoBuilder contactMobile(String mobile) {
            this.contact = contactBuilder
                    .mobile(mobile)
                    .build();
            return this;
        }

        public UserBasicInfoBuilder contactEmail(String email) {
            this.contact = contactBuilder
                    .email(email)
                    .build();
            return this;
        }

        public UserBasicInfoBuilder fullName(String fullName) {
            this.fullName = fullName;
            return this;
        }

        public UserBasicInfoBuilder nickName(String nickName) {
            this.nickName = nickName;
            return this;
        }

        public UserBasicInfoBuilder birthday(String birthday) {
            this.birthday = birthday;
            return this;
        }

        public UserBasicInfoBuilder gender(String gender) {
            this.gender = gender;
            return this;
        }

        public UserBasicInfo build() {
            UserBasicInfo userBasicInfo = new UserBasicInfo();
            userBasicInfo.setContact(contact);
            userBasicInfo.setFullName(fullName);
            userBasicInfo.setNickName(nickName);
            userBasicInfo.setBirthday(birthday);
            userBasicInfo.setGender(gender);
            return userBasicInfo;
        }
    }
}
