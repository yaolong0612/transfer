package com.pg.account.interfaces.facade.v2.assembler;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.BIND_ID;

/**
 * 组装绑定数据
 *
 * @author xusheng
 * @date 2021/6/8 <br>
 */
@Component("BindAccountAssemble")
public class BindAccountAssemble {

    private final ChannelDao channelDao;

    @Autowired
    public BindAccountAssemble(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 封装注册绑定参数
     *
     * @return com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount
     * @author xusheng
     * @date 2021/6/8 18:17
     */
    public ShardSocialAccount toShardSocialAccount(Long tenantId, Long channelId, String memberId, String bindId, String unionId) {
        ShardChannel shardChannel = Optional.ofNullable(channelDao.findByTenantIdAndChannelId(tenantId.toString(), channelId.toString()))
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        IdentityId identityId = new IdentityId(tenantId.toString(), memberId);
        List<SocialAccountItem> socialAccountList = new ArrayList<>();
        SocialAccountItem socialAccountItem = new SocialAccountItem();
        socialAccountItem.build(channel, null, bindId, unionId);
        socialAccountList.add(socialAccountItem);
        return new ShardSocialAccount(identityId, socialAccountList);
    }

    /**
     * 根据入参判断解绑类型
     *
     * @param bindId bindId
     * @return Account
     */
    public List<String> getUnBindType(String bindId) {
        List<String> typeList = new ArrayList<>();
        if (StringUtils.isNotBlank(bindId)) {
            typeList.add(BIND_ID);
        }
        return typeList;
    }
}
