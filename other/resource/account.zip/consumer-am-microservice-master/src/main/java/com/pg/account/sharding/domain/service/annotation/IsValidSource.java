package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.AccountBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

/**
 * 判断来源是否存在
 *
 * @author lfx
 * @date 2021/4/25 15:58
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({FIELD, METHOD, PARAMETER})
@Constraint(validatedBy = AccountBaseValidator.SourceValid.class)
public @interface IsValidSource {

    String message() default "source is not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
