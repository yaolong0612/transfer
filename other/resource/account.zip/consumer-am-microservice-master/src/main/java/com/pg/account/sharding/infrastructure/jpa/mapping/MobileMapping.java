package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterMccEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Optional;

/**
 * mobile映射类
 * 用于将mobile映射成accountId
 *
 * @author LC
 */
@Data
@Table
@DynamicUpdate
@DynamicInsert
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class MobileMapping extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -4369143115951064340L;
    private Long id;
    @Column(name = "account_id")
    private String accountId;
    @EmbeddedId
    private MobileMapId mobileMapId;
    @Convert(converter = JpaConverterMccEnum.class)
    private MobileCountryCode mobileCountryCode;

    public MobileMapping(Long id) {
        this.id = id;
    }

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.accountId = account.getAccountId();
        this.mobileMapId = new MobileMapId(account.getTenantId(), account.getMobile());
        if (Optional.ofNullable(this.createdTime).isPresent()) {
            super.addUpdatedTime();
        } else {
            super.addCreateTime();
        }
    }

    public void builder(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.accountId = account.accountId();
        this.mobileMapId = new MobileMapId(account.tenantId(), account.getMobile());
        super.addCreateTime();
    }

    public String getMobile() {
        return Optional.ofNullable(this.mobileMapId).map(MobileMapId::getMobile).orElse(null);
    }
}
