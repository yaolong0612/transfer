package com.pg.account.sharding.domain.service.annotation;


import com.pg.account.sharding.domain.service.AccountBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 判断手机号是否有效（是否被他人使用）
 *
 * @author lfx
 * @date 2021/4/23 16:15
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AccountBaseValidator.MobileValid.class)
public @interface IsValidMobile {

    String message() default "mobile is exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};


}
