package com.pg.account.infrastructure.common.enums;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import lombok.Getter;

import java.util.Arrays;

/**
 * 注册类型枚举
 *
 * @author Jack Sun
 * @date 2019-11-27 16:33
 */
@Getter
public enum RegisterTypeEnum {

    /**
     * 注册类型枚举
     */
    REGISTER(1, "register"),
    REGISTER_BIND(2, "registerBind"),
    DEFAULT(3, "default");

    private final Integer key;
    private final String value;

    /**
     * 构造器
     *
     * @param key   num
     * @param value name
     */
    RegisterTypeEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public static RegisterTypeEnum getByKeyOrValue(String value) {
        return Arrays.stream(RegisterTypeEnum.values())
                .filter(msg -> msg.getValue().equalsIgnoreCase(value) || String.valueOf(msg.getKey()).equalsIgnoreCase(value))
                .findAny()
                .orElseThrow(() -> new BusinessException(ResultEnum.REGISTER_TYPE_NOT_EXIST.getCode(), ResultEnum.REGISTER_TYPE_NOT_EXIST.getV2Code(), ResultEnum.REGISTER_TYPE_NOT_EXIST.getMessage()));
    }
}
