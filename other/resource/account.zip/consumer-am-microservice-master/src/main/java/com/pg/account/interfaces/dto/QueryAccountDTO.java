package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/4/13
 */
@ApiModel(value = "QueryAccountDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryAccountDTO implements Serializable {
    private static final long serialVersionUID = 6374689291938458607L;

    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "bindId查询时检查绑定状态", example = "true")
    private boolean isBind;

    public boolean getIsBind() {
        return isBind;
    }

    public void setIsBind(boolean bind) {
        isBind = bind;
    }
}
