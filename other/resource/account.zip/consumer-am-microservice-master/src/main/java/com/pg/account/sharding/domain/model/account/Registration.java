package com.pg.account.sharding.domain.model.account;

import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 注册信息类
 *
 * @author Jack
 * @date 2021/5/27 13:46
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Registration implements ValueObject<Registration> {
    private static final long serialVersionUID = 4700539755887227435L;
    private String source;
    private Channel channel;
    private Customer customer;
    private LocalDateTime registerTime;

    @Override
    public boolean sameValueAs(Registration other) {
        return this.equals(other);
    }

    public void specialChannel(Channel channel) {
        this.channel = channel;
    }

    public void buildFromDb(Registration db) {
        Optional.ofNullable(db).ifPresent(registration -> {
            this.source = Optional.ofNullable(this.source).orElse(db.getSource());
            if (Optional.ofNullable(this.getChannel()).isPresent()) {
                this.channel.buildFromDb(Optional.ofNullable(db.getChannel()).orElse(null));
            } else {
                Channel channelNew = new Channel();
                channelNew.buildFromDb(Optional.ofNullable(db.getChannel()).orElse(null));
                this.channel = channelNew;
            }
            if (Optional.ofNullable(this.customer).isPresent()) {
                this.customer.buildFromDb(Optional.ofNullable(db.getCustomer()).orElse(null));
            } else {
                Customer customerNew = new Customer();
                customerNew.buildFromDb(Optional.ofNullable(db.getCustomer()).orElse(null));
                this.customer = customerNew;
            }
            this.registerTime = Optional.ofNullable(this.registerTime).orElse(db.getRegisterTime());
        });
    }

    public static final class RegistrationBuilder {
        private String source;
        private Channel channel;
        private Customer customer;
        private LocalDateTime registerTime;

        private RegistrationBuilder() {
        }

        public static RegistrationBuilder aRegistration() {
            return new RegistrationBuilder();
        }

        public RegistrationBuilder source(String source) {
            this.source = source;
            return this;
        }

        public RegistrationBuilder channel(Channel channel) {
            this.channel = channel;
            return this;
        }

        public RegistrationBuilder customer(Customer customer) {
            this.customer = customer;
            return this;
        }

        public RegistrationBuilder customer(String customer, String regStore) {
            this.customer = Customer.CustomerBuilder.aCustomer()
                    .name(customer)
                    .regStore(regStore)
                    .build();
            return this;
        }

        public RegistrationBuilder channelId(String channelId) {
            this.channel = Channel.ChannelBuilder.aChannel().channelId(channelId).build();
            return this;
        }

        public RegistrationBuilder registerTime(LocalDateTime registerTime) {
            this.registerTime = registerTime;
            return this;
        }

        public Registration build() {
            Registration registration = new Registration();
            registration.setSource(source);
            registration.setChannel(channel);
            registration.setCustomer(customer);
            registration.setRegisterTime(registerTime);
            return registration;
        }
    }
}
