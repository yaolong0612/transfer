//package com.pg.account.infrastructure.component.client.message;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.pg.account.domain.model.account.Account;
//import com.pg.account.domain.service.MessageService;
//import com.pg.account.infrastructure.common.exception.BusinessException;
//import com.pg.account.infrastructure.common.exception.ExternalSystemException;
//import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
//import com.pg.account.infrastructure.component.client.address.Address;
//
//import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang.Validate;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//
//import static com.pg.account.infrastructure.common.constants.AccountConstants.MEMBER_ID;
//
///**
// * @author Jack
// * @date 2021-04-21 21:07
// */
//@Slf4j
//@Component
//public class MessageServiceImpl implements MessageService {
//
//    /**
//     * Result true
//     */
//    public static final String RESULT_TRUE = "0";
//    public static final String RESULT_CODE = "resultCode";
//    public static final String ERROR_MSG = "errorMsg";
//    public static final String URL = "url";
//    public static final String API_SECRET = "apiSecret";
//    public static final String API_KEY = "apiKey";
//    public static final String TEMPLATE_CODE = "template_Register_Code";
//    public static final String FULL_NAME = "fullname";
//    public static final String MEMBER = "会员";
//    private final MessageServiceClient messageServiceClient;
//
//    @Autowired
//    public MessageServiceImpl(MessageServiceClient messageServiceClient) {
//        this.messageServiceClient = messageServiceClient;
//    }
//
//    /**
//     * 发送入会短信
//     *
//     * @param account account
//     */
//    @Override
//    public void sendMembershipSms(Account account) {
//        if (null != account) {
//            String smsTemplateRegisterCode = CacheLocalConfigUtils.getSmsTemplateRegisterCode(account.getTenantId(), account.getChannelId());
//            Validate.notNull(smsTemplateRegisterCode);
//            String brand = CacheLocalConfigUtils.getTenant(account.getTenantId());
//            Validate.notNull(brand);
//            String apiKey = getSmsApiKey(smsTemplateRegisterCode);
//            Validate.notNull(apiKey);
//            String apiSecret = getSmsApiSecret(smsTemplateRegisterCode);
//            Validate.notNull(apiSecret);
//            String templateCode = getTemplateCode(smsTemplateRegisterCode);
//            Validate.notNull(templateCode);
//            List<ParamEntity> paramEntityList = new ArrayList<>();
//            paramEntityList.add(new ParamEntity(MEMBER_ID, account.getMemberId()));
//            String fullname = null;
//            if (null != account.getAddressList() && !account.getAddressList().isEmpty()) {
//                Optional<Address> address = account.getAddressList().stream().findFirst();
//                if (address.isPresent()) {
//                    fullname = address.get().getFullName();
//                }
//            }
//            paramEntityList.add(new ParamEntity(FULL_NAME, StringUtils.isNotBlank(fullname) ? fullname : MEMBER));
//            SendMessageRequest request = new SendMessageRequest();
//            request.setParamEntityList(paramEntityList);
//            request.setApiKey(apiKey);
//            request.setBrand(brand);
//            Optional.ofNullable(account.getProfile()).ifPresent(value -> request.setMobile(value.getCellphone()));
//            request.setTemplateCode(templateCode);
//            request.setTimeStamp(String.valueOf(System.currentTimeMillis() / 1000));
//            Map<String, Object> sendMessageRequestMap = JSON.parseObject(JSON.toJSONString(request));
//            request.setSignature(SignatureGenerator.generateApiSecret(sendMessageRequestMap, apiSecret));
//            ResponseEntity<JSONObject> responseEntity;
//            try {
//                responseEntity = this.messageServiceClient.sendMessage(request);
//                log.info("MessageService sendMembershipSms request:{},responseEntity:{}", request, responseEntity);
//            } catch (Exception e) {
//                log.warn("MessageServiceImpl-sendMembershipSms.Request account:{}.Exception:", account.toString(), e);
//                throw new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage());
//            }
//            JSONObject jsonObject = Optional.ofNullable(responseEntity.getBody()).orElseThrow(() -> new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage()));
//            exceptionHandler(responseEntity.getStatusCode(), jsonObject);
//        }
//    }
//
//    /**
//     * 登录短信校验
//     *
//     * @param account      account
//     * @param templateCode templateCode
//     * @param code         code
//     * @return 短信发送状态，成功true，失败false
//     */
//    @Override
//    public boolean logonSmsVerifyCode(Account account, String templateCode, String code) {
//        if (null != account && StringUtils.isNotBlank(templateCode) && StringUtils.isNotBlank(code)) {
//            String brand = CacheLocalConfigUtils.getTenant(account.getTenantId());
//            Validate.notNull(brand);
//            String smsResult = CacheLocalConfigUtils.getSmsVerificationUrl(account.getTenantId());
//            Validate.notNull(smsResult);
//            String apiKey = getSmsApiKey(smsResult);
//            Validate.notNull(apiKey);
//            String apiSecret = getSmsApiSecret(smsResult);
//            Validate.notNull(apiSecret);
//            VerifyCodeRequest request = new VerifyCodeRequest();
//            request.setApiKey(apiKey);
//            request.setBrand(brand);
//            Optional.ofNullable(account.getProfile()).ifPresent(value -> request.setMobile(value.getCellphone()));
//            request.setCode(code);
//            request.setTemplateCode(templateCode);
//            request.setTimeStamp(String.valueOf(System.currentTimeMillis() / 1000));
//            Map<String, Object> sendMessageRequestMap = JSON.parseObject(JSON.toJSONString(request));
//            request.setSignature(SignatureGenerator.generateApiSecret(sendMessageRequestMap, apiSecret));
//            ResponseEntity<JSONObject> responseEntity;
//            try {
//                responseEntity = this.messageServiceClient.verifyCode(request);
//            } catch (Exception e) {
//                log.warn("MessageServiceImpl-logonSmsVerifyCode. Request account:{},templateCode:{},code:{}. Exception:", account.toString(), templateCode, code, e);
//                throw new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage());
//            }
//            JSONObject jsonObject = Optional.ofNullable(responseEntity.getBody()).orElseThrow(() -> new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage()));
//            exceptionHandler(responseEntity.getStatusCode(), jsonObject);
//            if (jsonObject.containsKey(RESULT_CODE)) {
//                return RESULT_TRUE.equals(jsonObject.get(RESULT_CODE));
//            }
//        }
//        return false;
//    }
//
//
//    /**
//     * 异常处理
//     *
//     * @param httpStatus httpStatus
//     * @param jsonObject jsonObject
//     */
//    private void exceptionHandler(HttpStatus httpStatus, JSONObject jsonObject) {
//        Integer code = Integer.parseInt(jsonObject.getString(RESULT_CODE));
//        String message = jsonObject.getString(ERROR_MSG);
//        if (httpStatus.is5xxServerError()) {
//            throw new ExternalSystemException(code, code, message);
//        } else if (httpStatus.is4xxClientError()) {
//            throw new BusinessException(code, code, message);
//        }
//    }
//
//    /**
//     * 获取SMS templateCode
//     *
//     * @param json result
//     * @return templateCode
//     */
//    private String getTemplateCode(String json) {
//        String templateCode = null;
//        if (StringUtils.isNotBlank(json)) {
//            JSONObject jsonObject = JSON.parseObject(json);
//            if (jsonObject.containsKey(TEMPLATE_CODE)) {
//                templateCode = jsonObject.getString(TEMPLATE_CODE);
//            }
//        }
//        return templateCode;
//    }
//
//
//    /**
//     * 获取SMS ApiKey
//     *
//     * @param json json
//     * @return ApiKey
//     */
//    private String getSmsApiKey(String json) {
//        String apiKey = null;
//        if (StringUtils.isNotBlank(json)) {
//            JSONObject jsonObject = JSON.parseObject(json);
//            if (jsonObject.containsKey(API_KEY)) {
//                apiKey = jsonObject.getString(API_KEY);
//            }
//        }
//        return apiKey;
//    }
//
//    /**
//     * 获取SMS ApiSecret
//     *
//     * @param json json
//     * @return ApiSecret
//     */
//    private String getSmsApiSecret(String json) {
//        String apiSecret = null;
//        if (StringUtils.isNotBlank(json)) {
//            JSONObject jsonObject = JSON.parseObject(json);
//            if (jsonObject.containsKey(API_SECRET)) {
//                apiSecret = jsonObject.getString(API_SECRET);
//            }
//        }
//        return apiSecret;
//    }
//}
