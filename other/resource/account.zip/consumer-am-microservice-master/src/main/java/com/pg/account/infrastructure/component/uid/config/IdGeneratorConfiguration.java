package com.pg.account.infrastructure.component.uid.config;

import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.infrastructure.component.uid.impl.CachedUidGenerator;
import com.pg.account.infrastructure.component.uid.worker.DisposableWorkerIdAssigner;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * IdGeneratorConfiguration
 *
 * @author Jack Sun
 * @date 2019-6-13 13:52
 */
@Configuration
public class IdGeneratorConfiguration {

    @Value("${uidGenerator.cached.boostPower:8192}")
    private int boostPower;
    @Value("${uidGenerator.cached.paddingFactor:50}")
    private int paddingFactor;
    @Value("${uidGenerator.cached.scheduleInterval:60}")
    private int scheduleInterval;
    @Value("${uidGenerator.cached.rejectedPutBufferHandler:}")
    private String rejectedPutBufferHandler;
    @Value("${uidGenerator.cached.rejectedTakeBufferHandler:}")
    private String rejectedTakeBufferHandler;
    @Value("${uidGenerator.cached.timeBits:31}")
    private int timeBits;
    @Value("${uidGenerator.cached.workerBits:19}")
    private int workerBits;
    @Value("${uidGenerator.cached.seqBits:13}")
    private int seqBits;
    @Value("${uidGenerator.cached.epochStr:2019-07-25}")
    private String epochStr;

    @Bean
    public DisposableWorkerIdAssigner disposableWorkerIdAssigner() {
        return new DisposableWorkerIdAssigner();
    }

    @Bean
    public UidGenerator cachedUidGenerator(DisposableWorkerIdAssigner disposableWorkerIdAssigner) {
        CachedUidGenerator cachedUidGenerator = new CachedUidGenerator();
        cachedUidGenerator.setBoostPower(boostPower);
        cachedUidGenerator.setScheduleInterval(scheduleInterval);
        cachedUidGenerator.setTimeBits(timeBits);
        cachedUidGenerator.setWorkerBits(workerBits);
        cachedUidGenerator.setSeqBits(seqBits);
        cachedUidGenerator.setEpochStr(epochStr);
        cachedUidGenerator.setWorkerIdAssigner(disposableWorkerIdAssigner);
        return cachedUidGenerator;
    }
}
