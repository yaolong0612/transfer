package com.pg.account.infrastructure.common.enums;

import com.pg.account.infrastructure.common.exception.BusinessException;
import lombok.Getter;

import java.util.Arrays;

import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.QUERY_FIELDS_ERROR;

/**
 * @author LC
 */

@Getter
public enum AccountProfileEnum {

    /**
     * 会员枚举类
     */
    PROFILE("profile"),
    ADDRESS("address"),
    ATTRIBUTE("attribute"),
    COUNTER("counter"),
    JOB("job"),
    EDUCATION("education"),
    INTERPERSONAL_RELATIONSHIP("interpersonal_relationship"),
    SUBSCRIPTION("subscription"),
    SOCIAL_ACCOUNT("socialAccount"),
    DEVICE("device"),
    DEFAULT("default"),
    ;

    private final String msg;

    AccountProfileEnum(String msg) {
        this.msg = msg;
    }

    public static AccountProfileEnum getByValue(String value) {
        return Arrays.stream(AccountProfileEnum.values())
                .filter(msg -> msg.getMsg().equalsIgnoreCase(value))
                .findAny()
                .orElseThrow(() -> new BusinessException(QUERY_FIELDS_ERROR.getCode(), QUERY_FIELDS_ERROR.getV2Code(), QUERY_FIELDS_ERROR.getMessage()));
    }

}

