package com.pg.account.infrastructure.component.client.loyalty;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AddLoyaltyInteractionRequest implements Serializable {

    private static final long serialVersionUID = -2149496239103947158L;
    @ApiModelProperty(value = "会员Id", example = "1234", required = true)
    @NotNull(message = "缺少会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;

    @ApiModelProperty(value = "绑定Id", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;

    @ApiModelProperty(value = "品牌", example = "PAMPERS", required = true)
    @NotNull(message = "缺少品牌")
    private String brand;

    @ApiModelProperty(value = "渠道ID", example = "WECHAT", required = true)
    @NotNull(message = "channel is not exist")
    private String channel;

    @ApiModelProperty(value = "注册来源(ML:大陆，TW:台湾，HK:香港)", example = "ML", required = true)
    @NotNull(message = "缺少注册来源(ML:大陆，TW:台湾，HK:香港)")
    private String region;

    @ApiModelProperty(value = "加积分类型(COMPLETE_PROFILE:修改加积分标识)", example = "COMPLETE_PROFILE", required = true)
    private String pointType;

    @ApiModelProperty(value = "Loyalty系统通常按交易类型添加积分;另外，客户可以自己定义点值。", example = "100")
    private String point;

    @ApiModelProperty(value = "Qrcode字符串，当事务类型='scan qrcode'时需要此参数", example = "16841712251206213001")
    private String qrcode;

    @ApiModelProperty(value = "这是商品的SKU。如果是扫描代码加整数，则必须发送", example = "12jhukndm")
    private String sku;

    @ApiModelProperty(value = "指示成员是新成员还是旧成员。当sku类型为whips而成员为旧成员时，添加双倍分数。", example = "false")
    private boolean newMember;

    @ApiModelProperty(value = "这就是我们加分的原因", example = "bind points")
    private String adjustReason;
}
