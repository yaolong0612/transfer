package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author mrluve
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ActiveAccountBean implements Serializable {

    @JSONField(ordinal = 1)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 2)
    private Integer mpId;
    @JSONField(ordinal = 3)
    private Character updateFlag;

    public void updated() {
        this.updateFlag = 'U';
    }
}
