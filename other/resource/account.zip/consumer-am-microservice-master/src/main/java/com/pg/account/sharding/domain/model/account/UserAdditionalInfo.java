package com.pg.account.sharding.domain.model.account;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import static java.lang.Integer.parseInt;

/**
 * @author Jack
 * @date 2021/5/28 16:17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAdditionalInfo implements ValueObject<UserAdditionalInfo> {

    private static final long serialVersionUID = -5735229761820318780L;

    private List<EducationItem> educationList;
    private List<HumanRelationItem> humanRelationList;
    private List<JobItem> jobList;
    private List<ExtraAttributeItem> extraAttributeList;
    private DeviceInfo device;

    /**
     * pomeSchool的三個域序列校驗
     *
     * @param userAdditionalInfo userAdditionalInfo
     */
    public static void sequenceUniqueValid(UserAdditionalInfo userAdditionalInfo) {
        // 如果education有值 獲取education的size，進行去重，如果去重后size變小説明有重複序列
        Optional.ofNullable(userAdditionalInfo.getEducationList()).ifPresent(UserAdditionalInfo::educationItemValid);
        Optional.ofNullable(userAdditionalInfo.getJobList()).ifPresent(UserAdditionalInfo::jobItemValid);
        Optional.ofNullable(userAdditionalInfo.getHumanRelationList()).ifPresent(UserAdditionalInfo::humanRelationValid);
    }

    /**
     * 人际关系校验
     *
     * @param h HumanRelationItemList
     */
    private static void humanRelationValid(List<HumanRelationItem> h) {
        int originSize = h.size();
        int actualSize = (int) h.stream().filter(distinctByKey(HumanRelationItem::getRelation)).count();
        h.forEach(human -> relationValid(human.getRelation(), originSize, actualSize));
    }

    /**
     * 职业校验
     *
     * @param j jobItemList
     */
    private static void jobItemValid(List<JobItem> j) {
        int originSize = j.size();
        int actualSize = (int) j.stream().filter(distinctByKey(JobItem::getRelation)).count();
        j.forEach(job -> relationValid(job.getRelation(), originSize, actualSize));
    }

    /**
     * 教育信息校验
     *
     * @param e educationItemList
     */
    private static void educationItemValid(List<EducationItem> e) {
        int originSize = e.size();
        int actualSize = (int) e.stream().filter(distinctByKey(EducationItem::getRelation)).count();
        e.forEach(edu -> relationValid(edu.getRelation(), originSize, actualSize));
    }

    /**
     * 关系校验
     *
     * @param relation   relation
     * @param actualSize actualSize
     * @param originSize originSize
     */
    private static void relationValid(Relation relation, Integer actualSize, Integer originSize) {
        Optional.ofNullable(relation).ifPresent(rel -> {
            if (parseInt(rel.getSequence()) > RelationType.getRelation(rel.getRelationType().getRelationName()).getLimit()) {
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
            }
        });
        if (actualSize < originSize) {
            throw new BusinessException(ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getCode(), ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getV2Code(), ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getMessage());
        }
    }
    /**
     * pomeSchool的三個域序列校驗
     *
     * @param userAdditionalInfo userAdditionalInfo
     */
    public static void sequenceUniqueValidate(UserAdditionalInfo userAdditionalInfo) {
        // 如果education有值 獲取education的size，進行去重，如果去重后size變小説明有重複序列
        Optional.ofNullable(userAdditionalInfo.getEducationList()).ifPresent(UserAdditionalInfo::educationItemValidate);
        Optional.ofNullable(userAdditionalInfo.getJobList()).ifPresent(UserAdditionalInfo::jobItemValidate);
        Optional.ofNullable(userAdditionalInfo.getHumanRelationList()).ifPresent(UserAdditionalInfo::humanRelationValidate);
    }

    /**
     * 人际关系校验
     *
     * @param h HumanRelationItemList
     */
    private static void humanRelationValidate(List<HumanRelationItem> h) {
        int originSize = h.size();
        int actualSize = (int) h.stream().filter(distinctByKey(HumanRelationItem::getRelation)).count();
        h.forEach(human -> relationValidate(human.getRelation(), originSize, actualSize));
    }

    /**
     * 职业校验
     *
     * @param j jobItemList
     */
    private static void jobItemValidate(List<JobItem> j) {
        int originSize = j.size();
        int actualSize = (int) j.stream().filter(distinctByKey(JobItem::getRelation)).count();
        j.forEach(job -> relationValidate(job.getRelation(), originSize, actualSize));
    }

    /**
     * 教育信息校验
     *
     * @param e educationItemList
     */
    private static void educationItemValidate(List<EducationItem> e) {
        int originSize = e.size();
        int actualSize = (int) e.stream().filter(distinctByKey(EducationItem::getRelation)).count();
        e.forEach(edu -> relationValidate(edu.getRelation(), originSize, actualSize));
    }

    /**
     * 关系校验
     *
     * @param relation   relation
     * @param actualSize actualSize
     * @param originSize originSize
     */
    private static void relationValidate(Relation relation, Integer actualSize, Integer originSize) {
        Optional.ofNullable(relation).ifPresent(rel -> {
            if (parseInt(rel.getSequence()) > RelationType.getRelation(rel.getRelationType().getRelationName()).getLimit()) {
                throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
            }
        });
        if (actualSize < originSize) {
            throw new BusinessException(V3ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getCode(), V3ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getMessage(), V3ResultEnum.RELATIONSHIP_SEQUENCE_ERROR.getFrontMessage());
        }
    }

    /**
     * 根据某个值进行去重
     *
     * @param keyExtractor key
     * @return Predicate
     */
    private static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>(8);
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    @Override
    public boolean sameValueAs(UserAdditionalInfo other) {
        return this.equals(other);
    }

    public void device(DeviceInfo device) {
        this.device = device;
    }

    public void extraAttributeList(List<ExtraAttributeItem> extraAttributeList) {
        this.extraAttributeList = extraAttributeList;
    }

    public void educationList(List<EducationItem> educationList) {
        this.educationList = educationList;
    }

    public void humanRelationList(List<HumanRelationItem> humanRelationList) {
        this.humanRelationList = humanRelationList;
    }

    public void jobList(List<JobItem> jobList) {
        this.jobList = jobList;
    }

    public static final class UserAdditionalInfoBuilder {
        private List<EducationItem> educationList;
        private List<HumanRelationItem> humanRelationList;
        private List<JobItem> jobList;
        private List<ExtraAttributeItem> extraAttributeList;
        private DeviceInfo device;

        private UserAdditionalInfoBuilder() {
        }

        public static UserAdditionalInfoBuilder anUserAdditionalInfo() {
            return new UserAdditionalInfoBuilder();
        }

        public UserAdditionalInfoBuilder educationList(List<EducationItem> educationList) {
            this.educationList = educationList;
            return this;
        }

        public UserAdditionalInfoBuilder humanRelationList(List<HumanRelationItem> humanRelationList) {
            this.humanRelationList = humanRelationList;
            return this;
        }

        public UserAdditionalInfoBuilder jobList(List<JobItem> jobList) {
            this.jobList = jobList;
            return this;
        }

        public UserAdditionalInfoBuilder extraAttributeList(List<ExtraAttributeItem> extraAttributeList) {
            this.extraAttributeList = extraAttributeList;
            return this;
        }

        public UserAdditionalInfoBuilder device(DeviceInfo device) {
            this.device = device;
            return this;
        }

        public UserAdditionalInfo build() {
            UserAdditionalInfo userAdditionalInfo = new UserAdditionalInfo();
            userAdditionalInfo.setEducationList(educationList);
            userAdditionalInfo.setHumanRelationList(humanRelationList);
            userAdditionalInfo.setJobList(jobList);
            userAdditionalInfo.setExtraAttributeList(extraAttributeList);
            userAdditionalInfo.setDevice(device);
            return userAdditionalInfo;
        }
    }
}
