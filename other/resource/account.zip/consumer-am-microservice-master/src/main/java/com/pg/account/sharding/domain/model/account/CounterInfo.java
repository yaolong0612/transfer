package com.pg.account.sharding.domain.model.account;

import com.pg.account.interfaces.command.CounterCommand;
import com.pg.account.interfaces.dto.CounterDTO;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 柜台信息表
 * 存在柜台的详细信息
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterInfo implements ValueObject<CounterInfo> {
    private static final long serialVersionUID = 3034210842708560014L;
    private String regCounterCode;
    private String regCounterName;
    private String mainCounterCode;
    private String mainCounterName;
    private String pickupCounterCode;
    private String pickupCounterName;
    private String offlineFirstPurchaseCounterCode;
    private String offlineFirstPurchaseCounterName;
    private String firstPurchaseCounterCode;
    private String firstPurchaseTime;
    private String crmPickupCounterCode;
    private String lastPurchaseCounterCode;
    private String lastPurchaseCounterName;
    private String belongToCounterCode;
    private String belongToCounterName;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public static CounterInfo toCounterInfo(CounterCommand counterCommand) {
        if (Optional.ofNullable(counterCommand).isPresent()) {
            return new CounterInfo(counterCommand.getRegCounterCode(),
                    counterCommand.getRegCounterName(),
                    counterCommand.getMainCounterCode(),
                    counterCommand.getMainCounterName(),
                    counterCommand.getPickupCounterCode(),
                    counterCommand.getPickupCounterName(),
                    counterCommand.getOfflineFirstPurchaseCounterCode(),
                    counterCommand.getOfflineFirstPurchaseCounterName(),
                    counterCommand.getFirstPurchaseCounterCode(),
                    counterCommand.getFirstPurchaseTime(),
                    counterCommand.getCrmPickupCounterCode(),
                    null,
                    null,
                    null,
                    null,
                    LocalDateTime.now(), LocalDateTime.now());
        }
        return null;
    }

    @Override
    public boolean sameValueAs(CounterInfo other) {
        return this.equals(other);
    }

    public CounterDTO builder() {
        CounterDTO counterDTO = new CounterDTO();
        counterDTO.setRegCounterCode(this.getRegCounterCode());
        counterDTO.setRegCounterName(this.getRegCounterName());
        counterDTO.setMainCounterCode(this.getMainCounterCode());
        counterDTO.setMainCounterName(this.getMainCounterName());
        counterDTO.setPickupCounterCode(this.getPickupCounterCode());
        counterDTO.setPickupCounterName(this.getPickupCounterName());
        counterDTO.setOfflineFirstPurchaseCounterCode(this.getOfflineFirstPurchaseCounterCode());
        counterDTO.setOfflineFirstPurchaseCounterName(this.getOfflineFirstPurchaseCounterName());
        counterDTO.setFirstPurchaseCounterCode(this.getFirstPurchaseCounterCode());
        counterDTO.setFirstPurchaseTime(this.getFirstPurchaseTime());
        counterDTO.setCrmPickupCounterCode(this.getCrmPickupCounterCode());
        return counterDTO;
    }

    public void buildFromDb(CounterInfo db) {
        Optional.ofNullable(db).ifPresent(d -> {
            this.regCounterCode = Optional.ofNullable(this.regCounterCode).orElse(d.regCounterCode);
            this.regCounterName = Optional.ofNullable(this.regCounterName).orElse(d.regCounterName);
            this.mainCounterCode = Optional.ofNullable(this.mainCounterCode).orElse(d.mainCounterCode);
            this.mainCounterName = Optional.ofNullable(this.mainCounterName).orElse(d.mainCounterName);
            this.pickupCounterCode = Optional.ofNullable(this.pickupCounterCode).orElse(d.pickupCounterCode);
            this.pickupCounterName = Optional.ofNullable(this.pickupCounterName).orElse(d.pickupCounterName);
            this.offlineFirstPurchaseCounterCode = Optional.ofNullable(this.offlineFirstPurchaseCounterCode).orElse(d.offlineFirstPurchaseCounterCode);
            this.offlineFirstPurchaseCounterName = Optional.ofNullable(this.offlineFirstPurchaseCounterName).orElse(d.offlineFirstPurchaseCounterName);
            this.firstPurchaseCounterCode = Optional.ofNullable(this.firstPurchaseCounterCode).orElse(d.firstPurchaseCounterCode);
            this.firstPurchaseTime = Optional.ofNullable(this.firstPurchaseTime).orElse(d.firstPurchaseTime);
            this.crmPickupCounterCode = Optional.ofNullable(this.crmPickupCounterCode).orElse(d.crmPickupCounterCode);
            this.belongToCounterCode = Optional.ofNullable(this.belongToCounterCode).orElse(d.belongToCounterCode);
            this.belongToCounterName = Optional.ofNullable(this.belongToCounterName).orElse(d.belongToCounterName);
            this.lastPurchaseCounterCode = Optional.ofNullable(this.lastPurchaseCounterCode).orElse(d.lastPurchaseCounterCode);
            this.lastPurchaseCounterName = Optional.ofNullable(this.lastPurchaseCounterName).orElse(d.lastPurchaseCounterName);
            this.createTime = d.createTime;
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(d.updateTime);
        });
    }


    public void build(CounterInfo counter) {
        Optional.ofNullable(counter).ifPresent(c -> {
            this.regCounterCode = Optional.ofNullable(c.getRegCounterCode()).orElse(this.regCounterCode);
            this.regCounterName = Optional.ofNullable(c.getRegCounterName()).orElse(this.regCounterName);
            this.mainCounterCode = Optional.ofNullable(c.getMainCounterCode()).orElse(this.mainCounterCode);
            this.mainCounterName = Optional.ofNullable(c.getMainCounterName()).orElse(this.mainCounterName);
            this.pickupCounterCode = Optional.ofNullable(c.getPickupCounterCode()).orElse(this.pickupCounterCode);
            this.pickupCounterName = Optional.ofNullable(c.getPickupCounterName()).orElse(this.pickupCounterName);
            this.offlineFirstPurchaseCounterCode = Optional.ofNullable(c.getOfflineFirstPurchaseCounterCode()).orElse(this.offlineFirstPurchaseCounterCode);
            this.offlineFirstPurchaseCounterName = Optional.ofNullable(c.getOfflineFirstPurchaseCounterName()).orElse(this.offlineFirstPurchaseCounterName);
            this.firstPurchaseCounterCode = Optional.ofNullable(c.getFirstPurchaseCounterCode()).orElse(this.firstPurchaseCounterCode);
            this.firstPurchaseTime = Optional.ofNullable(c.getFirstPurchaseTime()).orElse(this.firstPurchaseTime);
            this.belongToCounterCode = Optional.ofNullable(c.belongToCounterCode).orElse(this.belongToCounterCode);
            this.belongToCounterName = Optional.ofNullable(c.belongToCounterName).orElse(this.belongToCounterName);
            this.lastPurchaseCounterCode = Optional.ofNullable(c.lastPurchaseCounterCode).orElse(this.lastPurchaseCounterCode);
            this.lastPurchaseCounterName = Optional.ofNullable(c.lastPurchaseCounterName).orElse(this.lastPurchaseCounterName);
            this.crmPickupCounterCode = Optional.ofNullable(c.getCrmPickupCounterCode()).orElse(this.crmPickupCounterCode);
            this.belongToCounterCode = Optional.ofNullable(c.belongToCounterCode).orElse(this.belongToCounterCode);
            this.belongToCounterName = Optional.ofNullable(c.belongToCounterName).orElse(this.belongToCounterName);
            this.lastPurchaseCounterCode = Optional.ofNullable(c.lastPurchaseCounterCode).orElse(this.lastPurchaseCounterCode);
            this.lastPurchaseCounterName = Optional.ofNullable(c.lastPurchaseCounterName).orElse(this.lastPurchaseCounterName);
            this.createTime = c.createTime;
            this.updateTime = LocalDateTime.now();
        });

    }


}
