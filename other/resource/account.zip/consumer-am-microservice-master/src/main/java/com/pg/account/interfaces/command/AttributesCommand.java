package com.pg.account.interfaces.command;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.List;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.NUMBER_PATTERN;

/**
 * 增加和修改用户属性共同类
 *
 * @author JackSun
 * @date 2017/2/10
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttributesCommand implements Serializable {
    private static final long serialVersionUID = -8814804987188009014L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12", required = true)
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @NotBlank(message = "missing memberId")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @Valid
    @ApiModelProperty(value = "用户属性集合", required = true)
    private List<AttrCommand> attrs;
}
