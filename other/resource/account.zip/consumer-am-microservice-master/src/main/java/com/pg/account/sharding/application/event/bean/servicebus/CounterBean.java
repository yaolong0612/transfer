package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Jack Sun
 * @date 2019-6-19 9:15
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterBean implements Serializable {
    private static final long serialVersionUID = -5286149164431972668L;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 1)
    private Integer mpId;
    @JSONField(ordinal = 2)
    private Character updateFlag;
    @JSONField(ordinal = 5)
    private String regCounter;
    @JSONField(ordinal = 6)
    private String mainCounter;
    @JSONField(ordinal = 7)
    private String pickupCounter;
    @JSONField(ordinal = 8)
    private String offlineFirstPurchaseCounter;
    @JSONField(ordinal = 9)
    private String firstPurchaseCounter;
    @JSONField(ordinal = 10)
    private String firstPurchaseTime;
    @JSONField(ordinal = 11)
    private String crmPickupCounter;
    @JSONField(ordinal = 12)
    private String offlineLastPurchaseCounter;
    @JSONField(ordinal = 13)
    private String memberBelongToCounter;
    @JSONField(ordinal = 14)
    private Timestamp createTime;
    @JSONField(ordinal = 15)
    private Timestamp modifyTime;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
