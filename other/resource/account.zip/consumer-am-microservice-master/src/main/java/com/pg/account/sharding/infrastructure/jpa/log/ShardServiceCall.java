package com.pg.account.sharding.infrastructure.jpa.log;

import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/4/9
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "SHARD_SERVICE_CALL")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShardServiceCall extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1161228721283065386L;

    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    private String url;
    private String content;
    private String type;
    private String status;
    private String retryCount;
    private String resultCode;
    private String resultMessage;

    public ShardServiceCall(IdentityId identityId, String url, String content, String type, String status, String retryCount, String resultCode, String resultMessage) {
        this.identityId = identityId;
        this.url = url;
        this.content = content;
        this.type = type;
        this.status = status;
        this.retryCount = retryCount;
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
        super.addCreateTime();
    }


}
