package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import com.pg.account.sharding.infrastructure.datastream.servicebus.bean.SkiiAttributesBean;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import com.pg.account.sharding.infrastructure.servicebus.AbstractConsumer;
import com.pg.account.sharding.infrastructure.servicebus.ServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.switchconfig.SwitchConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * SKII通过serviceBus更新柜台数据
 *
 * @author mrluve
 */
@Slf4j
@Service
public class SkiiC2UpdateCounterConsumer extends AbstractConsumer {

    public static final String PICKUPCODE = "111000001";
    public static final String PICKUP_COUNTER_NAME = "111000003";
    public static final String REGISTER_COUNTER_NAME = "111000004";
    public static final String REGISTER_COUNTER_CODE = "111000005";
    public static final String FIRST_PURCHASE_COUNTER_CODE = "111000007";
    public static final String FIRST_PURCHASE_COUNTER_NAME = "111000008";
    private final ExtraAttributeDao extraAttributeDao;
    private final UidGenerator uidGenerator;
    private final SwitchConfiguration switchConfiguration;

    @Autowired
    public SkiiC2UpdateCounterConsumer(ExtraAttributeDao extraAttributeDao,
                                       UidGenerator uidGenerator, SwitchConfiguration switchConfiguration) {
        this.extraAttributeDao = extraAttributeDao;
        this.uidGenerator = uidGenerator;
        this.switchConfiguration = switchConfiguration;
    }

    /**
     * 接收message消息，进行skii柜台信息更新
     *
     * @param jsonObject jsonObject
     */
    private void saveSkiiDataToAttribute(JSONObject jsonObject) {
        SkiiAttributesBean skiiData = JSON.parseObject(jsonObject.toJSONString(), SkiiAttributesBean.class);
        Optional.ofNullable(skiiData).ifPresent(skiiAttributesBean -> {
            runSharding(skiiData, skiiAttributesBean, true);
        });

    }


    /**
     * 执行老库保存逻辑
     *
     * @param skiiData
     * @param skiiAttributesBean
     * @return
     */
    private void runSharding(SkiiAttributesBean skiiData, SkiiAttributesBean skiiAttributesBean, boolean flag) {
        List<ExtraAttributeItem> extraAttributeItemList = assembleAttributeItemList(skiiData);
        ShardExtraAttribute dbExtraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(skiiData.getTenantId().toString(), skiiData.getUsersId());
        if (Optional.ofNullable(dbExtraAttribute).isPresent()) {
            Iterator<ExtraAttributeItem> iterator = dbExtraAttribute.getExtraAttributeItems().iterator();
            while (iterator.hasNext()) {
                ExtraAttributeItem extraAttributeItem = iterator.next();
                extraAttributeItemList.forEach(extraAttributeItem1 -> {
                    if (extraAttributeItem.getAttrId().equals(extraAttributeItem1.getAttrId())) {
                        extraAttributeItem1.builder(extraAttributeItem);
                        iterator.remove();
                    }
                });
            }
            dbExtraAttribute.getExtraAttributeItemList().addAll(extraAttributeItemList);
            dbExtraAttribute.addUpdatedTime();
        } else {
            dbExtraAttribute = new ShardExtraAttribute();
            Account account = toAccount(skiiAttributesBean, extraAttributeItemList);
            dbExtraAttribute.build(account);
        }
        extraAttributeDao.save(dbExtraAttribute);
        if (flag) {
            //封装成新年的account
            Account account = toAccount(skiiAttributesBean, extraAttributeItemList);
            //发送DMP
            com.pg.account.sharding.application.event.UpdateAttributeToDMPEvent updateAttributeToDMPEvent = new com.pg.account.sharding.application.event.UpdateAttributeToDMPEvent(this, account);
            SpringContextUtil.getApplicationContext().publishEvent(updateAttributeToDMPEvent);
        }
    }


    /**
     * 将柜台信息封装成sharding相应的attributes信息
     *
     * @param skiiData
     * @return
     */
    private List<ExtraAttributeItem> assembleAttributeItemList(SkiiAttributesBean skiiData) {
        List<ExtraAttributeItem> extraAttributeItemList = new ArrayList<>();
        Optional.ofNullable(skiiData.getPickupCounterCode()).filter(s -> !s.isEmpty()).ifPresent(pickCode -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(PICKUPCODE);
            extraAttributeItem.setAttrValue(skiiData.getPickupCounterCode());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        Optional.ofNullable(skiiData.getPickupCounterName()).filter(s -> !s.isEmpty()).ifPresent(pickCounterName -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(PICKUP_COUNTER_NAME);
            extraAttributeItem.setAttrValue(skiiData.getPickupCounterName());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        Optional.ofNullable(skiiData.getRegistrationCounterName()).filter(s -> !s.isEmpty()).ifPresent(registrationCounterName -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(REGISTER_COUNTER_NAME);
            extraAttributeItem.setAttrValue(skiiData.getRegistrationCounterName());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        Optional.ofNullable(skiiData.getRegistrationCounterCode()).filter(s -> !s.isEmpty()).ifPresent(registrationCounterCode -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(REGISTER_COUNTER_CODE);
            extraAttributeItem.setAttrValue(skiiData.getRegistrationCounterCode());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        Optional.ofNullable(skiiData.getFirstPurchaseCounterCode()).filter(s -> !s.isEmpty()).ifPresent(firstPurchaseCounterCode -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(FIRST_PURCHASE_COUNTER_CODE);
            extraAttributeItem.setAttrValue(skiiData.getFirstPurchaseCounterCode());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        Optional.ofNullable(skiiData.getFirstPurchaseCounterName()).filter(s -> !s.isEmpty()).ifPresent(firstPurchaseCounterName -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(FIRST_PURCHASE_COUNTER_NAME);
            extraAttributeItem.setAttrValue(skiiData.getFirstPurchaseCounterName());
            extraAttributeItem.setCreateTime(skiiData.getCreateTime().toLocalDateTime());
            extraAttributeItem.setUpdateTime(skiiData.getModifyTime().toLocalDateTime());
            extraAttributeItemList.add(extraAttributeItem);
        });
        return extraAttributeItemList;
    }

    /**
     * 封装成account
     *
     * @param skiiData
     * @param extraAttributeItemList
     * @return
     */
    private Account toAccount(SkiiAttributesBean skiiData, List<ExtraAttributeItem> extraAttributeItemList) {
        Account account = new Account();
        IdentityId identityId = new IdentityId(skiiData.getTenantId().toString(), skiiData.getUsersId());
        UserAdditionalInfo userAdditionalInfo = new UserAdditionalInfo();
        userAdditionalInfo.setExtraAttributeList(extraAttributeItemList);
        account.setIdentityId(identityId);
        account.setUserAdditionalInfo(userAdditionalInfo);
        return account;
    }

    @Override
    protected void doBusiness(JSON json) {
        JSONArray bodyContent = (JSONArray) json;
        log.info("SKIIC2 consume start...,and body is:{}", bodyContent);
        bodyContent.forEach(a -> {
            JSONObject body = (JSONObject) a;
            JSONObject jsonObject = body.getJSONObject("SKIIData");
            Optional.ofNullable(jsonObject).ifPresent(this::saveSkiiDataToAttribute);
        });
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.SKII_COUNTER.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.SKII_COUNTER;
    }
}
