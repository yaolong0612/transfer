package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author Jack Sun
 * @date 2019-5-23 17:35
 */
@ApiModel(value = "ReplaceBindIdDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReplaceBindIdDTO implements Serializable {
    private static final long serialVersionUID = 8267612951858856635L;
    @ApiModelProperty(value = "替换绑定状态")
    private boolean replaceStatus;
    @ApiModelProperty(value = "解绑数据集合")
    private List<UnBindingDTO> unBindingResponseList;
}
