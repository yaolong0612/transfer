package com.pg.account.sharding.infrastructure.common.enums;

import lombok.Getter;

import java.util.Arrays;

/**
 * @author LC
 */

@Getter
public enum QueryFieldEnum {

    /**
     * 会员枚举类
     */
    PROFILE("profile"),
    ADDRESS("address"),
    ATTRIBUTE("attribute"),
    COUNTER("counter"),
    JOB("job"),
    EDUCATION("education"),
    HUMAN_RELATIONSHIP("human_relationship"),
    SUBSCRIPTION("subscription"),
    SOCIAL_ACCOUNT("socialAccount"),
    DEVICE("device"),
    ;

    private final String msg;

    QueryFieldEnum(String msg) {
        this.msg = msg;
    }

    public static QueryFieldEnum getByValue(String value) {
        return Arrays.stream(QueryFieldEnum.values())
                .filter(msg -> msg.getMsg().equalsIgnoreCase(value))
                .findAny()
                .orElse(null);
    }

}

