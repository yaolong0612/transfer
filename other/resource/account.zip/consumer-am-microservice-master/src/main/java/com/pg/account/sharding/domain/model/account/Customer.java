package com.pg.account.sharding.domain.model.account;

import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * 客户类
 *
 * @author Jack
 * @date 2021/5/27 13:50
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer implements ValueObject<Customer> {
    private static final long serialVersionUID = 8361420899199321513L;
    private String name;
    private String regStore;

    @Override
    public boolean sameValueAs(Customer other) {
        return this.equals(other);
    }

    public void buildFromDb(Customer db) {
        Optional.ofNullable(db).ifPresent(cus -> {
            this.name = Optional.ofNullable(this.name).orElse(db.getName());
            this.regStore = Optional.ofNullable(this.regStore).orElse(db.getRegStore());
        });
    }

    public static final class CustomerBuilder {
        private String name;
        private String regStore;

        private CustomerBuilder() {
        }

        public static CustomerBuilder aCustomer() {
            return new CustomerBuilder();
        }

        public CustomerBuilder name(String name) {
            this.name = name;
            return this;
        }

        public CustomerBuilder regStore(String regStore) {
            this.regStore = regStore;
            return this;
        }

        public Customer build() {
            Customer customer = new Customer();
            customer.setName(name);
            customer.setRegStore(regStore);
            return customer;
        }
    }
}
