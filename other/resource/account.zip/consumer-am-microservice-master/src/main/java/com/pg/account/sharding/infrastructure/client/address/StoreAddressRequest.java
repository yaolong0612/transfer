package com.pg.account.sharding.infrastructure.client.address;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class StoreAddressRequest implements Serializable {

    private static final long serialVersionUID = -3059635314635614504L;
    @ApiModelProperty(value = "租户ID", example = "10002", required = true)
    @NotNull(message = "tenant is not exist")
    private Long tenantId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @NotNull(message = "缺少会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @Valid
    @ApiModelProperty(value = "地址集合")
    private List<Address> addressBeanList;

}
