package com.pg.account.sharding.infrastructure.jpa.config;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author wsq
 * @date
 */
@javax.persistence.Entity
@Table(name = "SHARD_OPTION_DICTIONARY")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardOptionDictionary extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7441795740251725861L;
    @Id
    private Long id;
    private String tenantId;
    private String optId;
    private String optValue;
    private String enumType;
    private String init;
    private String createBy;
    private String modifyBy;
    private Byte status;

}
