package com.pg.account.infrastructure.validator;

import com.pg.account.infrastructure.validator.annotation.ModifyPasswordValid;
import com.pg.account.interfaces.command.ModifyPasswordCommand;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import static com.pg.account.infrastructure.common.enums.ModifyPasswordTypeEnum.MODIFY;
import static com.pg.account.infrastructure.common.enums.ModifyPasswordTypeEnum.RESET;

/**
 * @author LC
 * <p>
 * 判断修改密码的参数是否有效
 */
public class ModifyPasswordParamValid implements ConstraintValidator<ModifyPasswordValid, ModifyPasswordCommand> {


    @Override
    public boolean isValid(ModifyPasswordCommand modifyPasswordCommand, ConstraintValidatorContext constraintValidatorContext) {
        constraintValidatorContext.disableDefaultConstraintViolation();
        if (!modifyPasswordCommand.getType().equals(MODIFY.getValue()) && !modifyPasswordCommand.getType().equals(RESET.getValue())) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("password type is wrong").addConstraintViolation();
            return false;
        }
        if (modifyPasswordCommand.getType().equals(MODIFY.getValue()) && StringUtils.isBlank(modifyPasswordCommand.getOldPassword())) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("oldPassword is null").addConstraintViolation();
            return false;
        }
        if (StringUtils.isBlank(modifyPasswordCommand.getNewPassword())) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("newPassword is null").addConstraintViolation();
            return false;
        }
        return true;
    }
}