package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author JackSun
 * @date 2017/2/8
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProfileCommand implements Serializable {
    private static final long serialVersionUID = 1582296694841227387L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12")
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234")
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "手机", example = "18862661734")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "邮箱", example = "1010@qq.com")
    @Pattern(regexp = EMAIL_VALID_PATTERN, message = "email format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;

}
