package com.pg.account.infrastructure.common.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 返回参数
 *
 * @author Jack Sun
 * @date 2019-11-25
 */
@ApiModel(value = "Result_V2", description = "V2 interface returns response data")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {
    /**
     * 状态码
     */
    @ApiModelProperty(value = "code", example = "51029", required = true)
    private Integer code;
    /**
     * 提示信息
     */
    @ApiModelProperty(value = "Error message", example = "account status is invalid", required = true)
    private String msg;

}
