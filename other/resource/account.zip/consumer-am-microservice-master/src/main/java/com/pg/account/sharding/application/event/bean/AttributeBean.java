package com.pg.account.sharding.application.event.bean;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributeBean implements Serializable {

    private static final long serialVersionUID = -547384564890147688L;
    @JSONField(name = "attribute_id")
    private String attributeId;
    @JSONField(name = "attribute_sqn")
    private Long attributeSqn;
    @JSONField(name = "attribute_value")
    private String attributeValue;

}
