package com.pg.account.sharding.infrastructure.datastream.servicebus;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import java.util.concurrent.Executors;


/**
 * @author Jack
 * @description
 * @date 2021/10/2 2:03
 * @modified Jack
 */
@Configuration
public class ScheduledConfig implements SchedulingConfigurer {
    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        // 自定义调度器，设置为一个支持定时及周期性的任务执行的线程池，这里初始3个线程
        taskRegistrar.setScheduler(Executors.newScheduledThreadPool(2));
    }
}
