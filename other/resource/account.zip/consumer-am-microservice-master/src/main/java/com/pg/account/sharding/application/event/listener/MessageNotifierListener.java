package com.pg.account.sharding.application.event.listener;

import com.pg.account.sharding.application.event.RegisterEvent;
import com.pg.account.sharding.application.event.SignUpEvent;
import com.pg.account.sharding.domain.service.SendMessageService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author Jack
 * @date 2021-04-28 20:58
 */
@Slf4j
@Component("shardMessageNotifierListener")
public class MessageNotifierListener {

    private final SendMessageService messageService;

    @Autowired
    public MessageNotifierListener(SendMessageService messageService) {
        this.messageService = messageService;
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onSendMembershipSmsEvent(RegisterEvent event) {
        Validate.notNull(event.getAccount(), "RegisterEvent account is null");
        messageService.sendMembershipSms(event.getAccount().getTenantId(), event.getAccount().getRegisterChannelId(), event.getAccount().getAccountId(), event.getAccount().getMobile(), event.getAccount().getUserBasicInfo().getFullName());
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onSendMembershipSmsEvent(SignUpEvent event) {
        Validate.notNull(event.getAccount(), "RegisterEvent account is null");
        messageService.sendMembershipSms(event.getAccount().tenantId(), event.getAccount().getRegisterChannelId(), event.getAccount().accountId(), event.getAccount().getMobile(), event.getAccount().getUserBasicInfo().getFullName());
    }
}
