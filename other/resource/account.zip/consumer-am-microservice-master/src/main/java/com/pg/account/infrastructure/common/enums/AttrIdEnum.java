package com.pg.account.infrastructure.common.enums;

/**
 * @Author wsq
 * @Description 判断首次加积分的attrId
 * @Date 2021/8/19 15:28
 **/

public enum AttrIdEnum {
    /**
     * 每个渠道的首次加积分的attrId
     */
    WEBSITE("122000001"),
    WECHAT("122000002"),
    TMALL("122000003");

    private final String msg;

    AttrIdEnum(String msg) {
        this.msg = msg;
    }

    public static boolean isInclude(String value) {
        boolean include = false;
        for (AttrIdEnum e : AttrIdEnum.values()) {
            if (e.getValue().equals(value)) {
                include = true;
                break;
            }
        }
        return include;
    }

    public String getValue() {
        return msg;
    }

}
