package com.pg.account.infrastructure.component.client.message;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author Jack
 * @date 2021-04-21 21:15
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ParamEntity implements Serializable {
    private static final long serialVersionUID = -7317127162115686597L;
    private String paramName;
    private String paramValue;
}
