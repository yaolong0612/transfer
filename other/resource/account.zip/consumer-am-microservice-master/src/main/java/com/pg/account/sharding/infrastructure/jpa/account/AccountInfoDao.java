package com.pg.account.sharding.infrastructure.jpa.account;

import com.pg.account.sharding.domain.model.account.AccountStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Jack
 * @date 2021/5/31 13:37
 */
public interface AccountInfoDao extends JpaRepository<ShardAccountInfo, Long> {
    /**
     * 根据租户和openId查询注册信息
     *
     * @param tenantId  租户id
     * @param accountId 会员Id
     * @return com.pg.account.sharding.domain.model.account
     * @author yj
     * @date 2021/5/28 13:19
     */
    ShardAccountInfo findByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);


    /**
     * 根据租户和openId查询注册信息
     *
     * @param tenantId 租户Id
     * @param openUid  openId
     * @return com.pg.account.sharding.domain.model.account
     * @author yj
     * @date 2021/5/28 14:00
     */
    ShardAccountInfo findByIdentityId_TenantIdAndOpenUid(String tenantId, String openUid);

    /**
     * 通过tenantId和usersId获取有效的AccountInfo
     *
     * @param tenantId      tenantId
     * @param accountId     accountId
     * @param accountStatus accountStatus
     * @return AccountInfo
     * @author yj
     * @date 2021/5/28 13:19
     */
    ShardAccountInfo findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(String tenantId, String accountId, AccountStatus accountStatus);

    /**
     * 根据租户和会员删除
     *
     * @param tenantId   tenantId
     * @param accountId accountId
     */
    @Modifying
    @Transactional
    void deleteByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);
}
