package com.pg.account.infrastructure.common.utils;

import com.alibaba.fastjson.JSON;
import com.pg.account.infrastructure.common.enums.AttrDicDataTypeEnum;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD;


/**
 * @author JackSun
 * @date 2017/1/3
 */
@Slf4j
public class StringValidUtil {

    public static final String EMAIL_VALID_PATTERN = "^[\\w_-]+(?:\\.[\\w_-]+)*@(?:[\\w](?:[\\w-]*[\\w])?\\.)+[\\w](?:[\\w-]*[\\w])?";

    public static final String MOBILE_PATTERN = "^(1[3|4|5|6|7|8|9][0-9]{9})$";

    public static final String MOBILE_LENGTH = "^\\d{11}$";

    public static final String NUMBER_PATTERN = "^[0-9]\\d*$";

    public static final String DIGITAL_PATTERN = "^([1-9][0-9]*)$";

    public static final String POSTAL_CODE_PATTERN = "^[0-9]{6}$";

    public static final String SPECIAL_CHARACTER_FILTERING_PATTERN = "^[\\u3400-\\u9FFFA-Za-z\\d\\(\\)\\（\\）\\　\\ \\-\\_\\#]+$";

    public static final String CH_EN_PATTERN = "^[\\u3400-\\u9FFFA-Za-z\\d]+$";

    public static final String BIRTHDAY_VALID_PATTERN = "^(?:((?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29)\\s+([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9])$|^(?:(?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29)$";

    public static final String GENDER_PATTERN = "^[U|F|M]$";

    public static final String FULL_NAME_VALID_PATTERN = "^[\\u3400-\\u9FFFA-Za-z\\d][\\ \\　\\ \\u3400-\\u9FFFA-Za-z\\d]*[\\u3400-\\u9FFFA-Za-z\\d]|[\\u3400-\\u9FFFA-Za-z\\d]+$";

    public static final String HOME_PHONE_PATTERN = "(^(1[3|4|5|6|7|8|9][0-9]{9})$)|^(\\d{3,4}-)\\d{7,8}$";

    public static final String CHINESE_PATTERN = "^[\\u3400-\\u9FFF]+$";

    public static final String POSITIVE_PATTERN = "[1-9]\\d*";

    public static final String Y_N_PATTERN = "^[Y|N]$";

    public static final String I_O_PATTERN = "^[I|O]{1}$";

    public static final String REGISTER_TYPE_PATTERN = "^(register)|(registerBind)|[1|2]$";

    public static final String IS_PRIMARY_PATTERN = "^[0|1]{1}$";

    public static final String ADDRESS_TYPE_PATTERN = "^[1]{1}$";

    public static final String M_R_PATTERN = "^[M|R]{1}$";

    public static final String REGISTER_ROUTE_PATTERN = "^[M|E]{1}$";

    public static final String BABY_BIRTHDAY_PATTERN = "^(?:((?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29)\\s+([0][0-2]):[0][0]:[0][0])$|^(?:(?!0000)[0-9]{4}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])-(?:29|30)|(?:0[13578]|1[02])-31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)-02-29)$";

    public static final String CELLPHONE_OR_EMAIL_PATTERN = "(^(1[3|4|5|6|7|8|9][0-9]{9})$)|(^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$)|(^[0-9]\\d*$)";

    public StringValidUtil() {
        //空构造函数
    }

    /**
     * 是否为邮箱
     *
     * @param email 邮箱
     * @return Boolean
     */
    public static boolean isEmail(String email) {
        Pattern pattern = Pattern.compile(EMAIL_VALID_PATTERN);
        Matcher mat = pattern.matcher(email);
        return mat.find();
    }

    /**
     * 是否为手机
     *
     * @param mobile 手机
     * @return Boolean
     */
    public static boolean isMobile(String mobile) {
        Pattern pattern = Pattern.compile(MOBILE_PATTERN);
        Matcher mat = pattern.matcher(mobile);
        return mat.find();
    }

    /**
     * 是否为11位
     *
     * @param mobile 手机号
     * @return boolean
     */
    public static boolean isMobileLength(String mobile) {
        Pattern pattern = Pattern.compile(MOBILE_LENGTH);
        Matcher mat = pattern.matcher(mobile);
        return mat.find();
    }

    /**
     * 是否数字
     *
     * @param number 内容
     * @return Boolean
     */
    public static boolean isNumber(String number) {
        Pattern pattern = Pattern.compile(NUMBER_PATTERN);
        Matcher mat = pattern.matcher(number);
        return mat.find();
    }

    /**
     * 验证邮政编码
     *
     * @param postalCode 邮编
     * @return Boolean
     */
    public static boolean isPostalCode(String postalCode) {
        Pattern pattern = Pattern.compile(POSTAL_CODE_PATTERN);
        Matcher mat = pattern.matcher(postalCode);
        return mat.find();
    }

    /**
     * 是否纯数字
     *
     * @param str 内容
     * @return Boolean
     */
    public static boolean isDigital(String str) {
        Pattern pattern = Pattern.compile(DIGITAL_PATTERN);
        Matcher mat = pattern.matcher(str);
        return mat.find();
    }

    /**
     * 生日
     *
     * @param str 内容
     * @return Boolean
     */
    public static boolean isBirthday(String str) {
        Pattern p = Pattern.compile(BIRTHDAY_VALID_PATTERN);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 地址校验
     *
     * @param str 内容
     * @return Boolean
     */
    public static boolean isAddress(String str) {
        Pattern p = Pattern.compile(SPECIAL_CHARACTER_FILTERING_PATTERN);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 姓名校验
     *
     * @param str 内容
     * @return Boolean
     */
    public static boolean isName(String str) {
        Pattern p = Pattern.compile(CH_EN_PATTERN);
        Matcher m = p.matcher(str);
        return m.matches();
    }

    /**
     * 验证生日大于等于18周岁
     *
     * @param str 生日
     * @return Boolean
     */
    public static boolean isAdult(String str) {
        SimpleDateFormat fmt = new SimpleDateFormat(YYYY_MM_DD);
        Date date = null;
        try {
            date = fmt.parse(str);
        } catch (ParseException e) {
            log.warn("原始异常", e);
            return false;
        }
        Calendar birthdayDate = Calendar.getInstance();
        birthdayDate.setTime(date);
        //可以对每个时间域单独修改
        Calendar cmp = Calendar.getInstance();
        cmp.add(Calendar.YEAR, -18);
        cmp.set(Calendar.HOUR_OF_DAY, 0);
        cmp.set(Calendar.SECOND, 0);
        cmp.set(Calendar.MINUTE, 0);
        return birthdayDate.before(cmp) || fmt.format(birthdayDate.getTime()).equals(fmt.format(cmp.getTime()));
    }

    /**
     * @param datatype 数据格式
     * @param value    内容
     * @return boolean
     */
    public static boolean validateDataType(String datatype, String value) {
        boolean flag = false;
        if (AttrDicDataTypeEnum.STRING.getDataType().equalsIgnoreCase(datatype)) {
            flag = true;
        } else if (AttrDicDataTypeEnum.OBJECT_JSON.getDataType().equalsIgnoreCase(datatype)) {
            try {
                JSON.parseObject(value);
                flag = true;
            } catch (Exception e) {
                log.warn("parseObject原始异常", e);
                return false;
            }
        } else if (AttrDicDataTypeEnum.ARRAY_JSON.getDataType().equalsIgnoreCase(datatype)) {
            try {
                parseArray(value);
                flag = true;
            } catch (Exception e) {
                log.warn("parseArray原始异常", e);
                return false;
            }
        } else if (AttrDicDataTypeEnum.TIMESTAMP.getDataType().equalsIgnoreCase(datatype)) {
            flag = isBirthday(value);
        }
        return flag;
    }

    /**
     * 宝宝年龄校验
     *
     * @param str 生日
     * @return boolean
     */
    public static boolean isValidateBabyBirthday(String str) {
        SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD);
        try {
            Date date = df.parse(str);
            Calendar now = Calendar.getInstance();
            now.setTime(date);
            Calendar before = Calendar.getInstance();
            before.set(Calendar.YEAR, before.get(Calendar.YEAR) - 13);
            Calendar after = Calendar.getInstance();
            after.set(Calendar.MONTH, before.get(Calendar.MONTH) + 6);
            if ((now.after(before)) && now.before(after)) {
                return true;
            }
        } catch (ParseException e) {
            log.warn("原始异常", e);
        }
        return false;
    }

}
