//package com.pg.account.sharding.application.event.listener;
//
//import cn.com.pg.paas.stream.framework.StreamTemplate;
//import com.alibaba.fastjson.JSONObject;
//import com.pg.account.infrastructure.component.uid.UidGenerator;
//import com.pg.account.sharding.application.event.RegisterBindEvent;
//import com.pg.account.sharding.application.event.RegisterEvent;
//import com.pg.account.sharding.domain.model.account.Account;
//import com.pg.account.sharding.infrastructure.jpa.config.CopyConfigDao;
//import com.pg.account.sharding.infrastructure.jpa.config.ShardCopyConfig;
//import com.pg.account.sharding.infrastructure.jpa.log.DataStreamDao;
//import com.pg.account.sharding.infrastructure.jpa.log.LogId;
//import com.pg.account.sharding.infrastructure.jpa.log.ShardDataStream;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.event.EventListener;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.stereotype.Component;
//
//import java.time.LocalDateTime;
//import java.util.Optional;
//
//import static com.alibaba.fastjson.JSON.toJSONString;
//import static com.pg.account.infrastructure.common.constants.AccountConstants.PRODUCER_EVENT_HUB;
//import static jdk.nashorn.internal.objects.NativeString.valueOf;
//
///**
// * @author Jack
// * @date 2021-05-06 13:38
// */
//@Component
//@Slf4j
//public class CooperActionOptInListener {
//
//    public static final String AM_SHARDING_COOPER_OPT_IN_EVENT_TYPE = "AM_SHARDING_COOPER_OPT_IN_EVENT_TYPE";
//    public static final String ACCOUNT = "account";
//
//
//    @Value("${service_bus.amCooperActionOptInEventTypeId}")
//    private String amCooperActionOptInEventTypeId;
//    @Value("${event_hub.retryCount}")
//    private int retryCount;
//
//    private final StreamTemplate streamTemplate;
//    private final DataStreamDao dataStreamDao;
//    private final CopyConfigDao copyConfigDao;
//    private final UidGenerator uidGenerator;
//
//    public CooperActionOptInListener(StreamTemplate streamTemplate, DataStreamDao dataStreamDao,
//                                     CopyConfigDao copyConfigDao, UidGenerator uidGenerator
//    ) {
//        this.streamTemplate = streamTemplate;
//        this.dataStreamDao = dataStreamDao;
//        this.copyConfigDao = copyConfigDao;
//        this.uidGenerator = uidGenerator;
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterEvent event) {
//        if (Optional.ofNullable(event.getAccount()).isPresent()) {
//            this.cooperActionOptInEvent(event.getAccount());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterBindEvent event) {
//        if (Optional.ofNullable(event.getAccount()).isPresent()) {
//            this.cooperActionOptInEvent(event.getAccount());
//        }
//    }
//
//    /**
//     * 判断注册数据是否需要同步到生活家
//     *
//     * @param account account
//     * @author xusheng
//     * @date 2021/6/21 19:24
//     */
//    private void cooperActionOptInEvent(Account account) {
//        boolean result = false;
//        String errorMessage = null;
//        String copyOptInStr = null;
//        String eventTypeId = amCooperActionOptInEventTypeId;
//        int count = 0;
//        //判断是否有cooperActionOptIn配置
//        ShardCopyConfig copyConfig = copyConfigDao.findByOldTenantIdAndOldChannelId(account.getTenantId(), account.getRegisterChannelId());
//        if (!Optional.ofNullable(copyConfig).isPresent()) {
//            return;
//        }
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(ACCOUNT, account);
//                jsonObject.put("flag", "sharding");
//                jsonObject.put("copyConfig", copyConfig);
//                copyOptInStr = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, copyOptInStr);
//            } catch (Exception e) {
//                log.warn("copyOptInEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, copyOptInStr, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 记录失败日志
//     *
//     * @param account      账号聚合根
//     * @param eventTypeId  事件类型Id
//     * @param eventMessage 事件消息
//     * @param status       状态
//     * @param errorMessage 错误信息
//     * @param retryCount   重试次数
//     */
//    private void writeLog(Account account, String eventTypeId, String eventMessage, String status, String errorMessage, String retryCount) {
//        LogId logId = new LogId(uidGenerator.getUid(), LocalDateTime.now());
//        ShardDataStream dataStream = new ShardDataStream(logId,account.getTenantId(),account.getAccountId(),PRODUCER_EVENT_HUB,eventTypeId, AM_SHARDING_COOPER_OPT_IN_EVENT_TYPE,null,null,eventMessage,errorMessage,status,retryCount);
//        dataStreamDao.save(dataStream);
//    }
//}
