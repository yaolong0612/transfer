package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.account.AccountStatus;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.service.annotation.IsExistMember;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Valid;
import java.lang.annotation.Annotation;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * 注解校验实现类
 *
 * @author wsq
 * @date 2021/6/16 9:54
 */
@Slf4j
public class SubscriptionValidator<T extends Annotation> implements ConstraintValidator<T, @Valid ShardSubscription> {


    protected Predicate<ShardSubscription> predicate = c -> true;
    @Autowired
    protected FetchMappingService fetchMappingService;
    @Autowired
    protected AccountInfoDao accountInfoDao;

    @Override
    public boolean isValid(ShardSubscription shardSubscription, ConstraintValidatorContext constraintValidatorContext) {
        return predicate.test(shardSubscription);
    }

    /**
     * 判断是否存在会员
     */
    public static class MemberIsExist extends SubscriptionValidator<IsExistMember> {
        @Override
        public void initialize(IsExistMember constraintAnnotation) {
            predicate = shardSubscription -> {
                if (Optional.ofNullable(shardSubscription.getIdentityId()).map(IdentityId::getAccountId).isPresent()) {
                    return Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(shardSubscription.getIdentityId().getTenantId(), shardSubscription.getIdentityId().getAccountId(), AccountStatus.ACTIVE)).isPresent();
                }
                return true;
            };
        }
    }
}