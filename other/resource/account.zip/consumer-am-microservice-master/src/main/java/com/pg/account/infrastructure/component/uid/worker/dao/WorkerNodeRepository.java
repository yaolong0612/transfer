package com.pg.account.infrastructure.component.uid.worker.dao;

import com.pg.account.infrastructure.component.uid.worker.entity.WorkerNodeEntity;
import org.springframework.data.jpa.repository.JpaRepository;


/**
 * @author Jack
 * @date 2021-04-30 16:12
 */
public interface WorkerNodeRepository extends JpaRepository<WorkerNodeEntity, Long> {
    /**
     * 根据ip和端口查询workernode是否存在记录
     *
     * @param hostName hostName
     * @param port     port
     * @return WorkerNodeEntity
     */
    WorkerNodeEntity findAllByHostNameAndPort(String hostName, String port);
}
