package com.pg.account.infrastructure.component.datastream.channel;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

import static com.pg.account.infrastructure.component.datastream.servicebus.ServiceBusConstants.*;

/**
 * @author Jack Sun
 * @date 2019-7-15 14:14
 */
public interface ServiceBusChannelConfig {


//    /**
//     * Olay Loyalty ServiceBus
//     *
//     * @return SubscribableChannel
//     */
//    @Input(LOYALTY_FIRST_PURCHASE_QUEUE_INPUT_CHANNEL)
//    SubscribableChannel loyaltyFirstPurchaseQueueInputChannel();
//
//
//    /**
//     * Olay Loyalty ServiceBus
//     *
//     * @return SubscribableChannel
//     */
//    @Input(MESSAGE_OPT_UPDATE_TOPIC_INPUT_CHANNEL)
//    SubscribableChannel smsOptInOrOptOutQueueInputChannel();
//
//    /**
//     * Olay 批量更新C2柜台信息
//     *
//     * @return SubscribableChannel
//     */
//    @Input(OLAY_C2_BATCH_UPDATE_COUNTER)
//    SubscribableChannel olayCounterInputChannel();
//
//    /**
//     * SKII 批量更新C2柜台信息
//     *
//     * @return SubscribableChannel
//     */
//    @Input(SKII_C2_BATCH_UPDATE_COUNTER)
//    SubscribableChannel skiiCounterInputChannel();

//    /**
//     * AM联合入会
//     *
//     * @return SubscribableChannel
//     */
//    @Input(COOPERATION_OPT_IN)
//    SubscribableChannel cooperationoptinInputChannel();

    /**
     * 分片新老数据接口操作同步
     *
     * @return SubscribableChannel
     */
    @Input(AM_SHARDING_SYNC)
    SubscribableChannel shardingSyncInputChannel();


}
