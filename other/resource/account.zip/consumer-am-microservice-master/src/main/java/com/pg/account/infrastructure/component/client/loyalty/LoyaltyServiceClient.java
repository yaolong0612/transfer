package com.pg.account.infrastructure.component.client.loyalty;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * AddressFeignClient
 *
 * @author Jack Sun
 * @date 2019-6-20 13:31
 */
@FeignClient(name = "cms-loyalty-service")
public interface LoyaltyServiceClient {


    /**
     * 调用loyalty service加积分
     *
     * @param addLoyaltyInteractionRequest 加积分参数
     * @return result返回参
     */
    @PostMapping(value = "/transactions/interactions", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> addInteraction(@RequestBody AddLoyaltyInteractionRequest addLoyaltyInteractionRequest);

}
