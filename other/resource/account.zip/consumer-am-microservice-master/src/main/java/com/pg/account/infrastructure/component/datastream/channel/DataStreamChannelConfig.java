package com.pg.account.infrastructure.component.datastream.channel;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

import static com.pg.account.infrastructure.common.constants.DataStreamConstants.DMP_INPUT_CHANNEL;
import static com.pg.account.infrastructure.common.constants.DataStreamConstants.WE_INPUT_CHANNEL;


/**
 * @author Jack
 * @date 2018-7-10
 */
public interface DataStreamChannelConfig {
    /**
     * DMP input 渠道
     *
     * @return SubscribableChannel
     */
    @Input(DMP_INPUT_CHANNEL)
    SubscribableChannel dmpInputChannel();


    /**
     * WE input 渠道
     *
     * @return SubscribableChannel
     */
    @Input(WE_INPUT_CHANNEL)
    SubscribableChannel weInputChannel();
}
