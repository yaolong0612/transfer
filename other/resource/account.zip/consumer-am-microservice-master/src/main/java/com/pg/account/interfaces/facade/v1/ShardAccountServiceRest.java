package com.pg.account.interfaces.facade.v1;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.validator.annotation.ModifyPasswordValid;
import com.pg.account.interfaces.command.*;
import com.pg.account.interfaces.dto.*;
import com.pg.account.interfaces.facade.v1.assembler.*;
import com.pg.account.interfaces.vo.Result;
import com.pg.account.sharding.application.AccountAppService;
import com.pg.account.sharding.application.event.LogonEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.service.FetchAccountService;
import com.pg.account.sharding.infrastructure.common.constants.AccountConstants;
import com.pg.account.sharding.infrastructure.jpa.mapping.EmailMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;
import java.util.Optional;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.pg.account.infrastructure.common.constants.AccountConstants.BIND_DTO_LIST;
import static com.pg.account.infrastructure.common.constants.AccountConstants.NEW_REGISTER;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.INCORRECT_QUERY_PARAM;
import static com.pg.account.interfaces.facade.v1.assembler.QueryProfileAssembler.fromAccountDTO;


/**
 * @author JackSun
 * @date 2017/1/13
 */
@RestController
@RequestMapping("/AccountServiceRest")
@Api(tags = {"V1接口，2020年之前的老租户可以使用，新租户请走V2接口"})
@Slf4j
@Validated
public class ShardAccountServiceRest {

    public static final String FIELDS = "address,attribute,counter,subscription,socialAccount";
    public static final String BIND_ID = "1";
    public static final String CHANNEL_ID_AND_BIND_ID = "5";
    public static final String MEMBER_ID = "4";
    public static final String ACCOUNT_ID = "accountId";
    public static final String IS_BIND = "isBind";
    private final AccountAppService accountAppService;
    private final FetchMappingService fetchMappingService;
    private final FetchAccountService fetchAccountService;

    private final ModifyProfileAssembler modifyProfileAssembler;
    private final RegisterAccountAssembler registerAccountAssembler;
    private final RegisterBindAccountAssembler registerBindAccountAssembler;
    private final QueryAttributesAssembler queryAttributesAssembler;
    private final AddAttributesAssembler addAttributesAssembler;
    private final DeleteAttributesAssembler deleteAttributesAssembler;
    private final BindAccountAssemble bindAccountAssemble;
    private final QuerySubscriptionAssembler querySubscriptionAssembler;
    private final SubscriptionAssemble subscriptionAssemble;


    @Autowired
    public ShardAccountServiceRest(AccountAppService accountAppService,
                                   FetchMappingService fetchMappingService,
                                   FetchAccountService fetchAccountService,
                                   RegisterAccountAssembler registerAccountAssembler,
                                   RegisterBindAccountAssembler registerBindAccountAssembler,
                                   QueryAttributesAssembler queryAttributesAssembler,
                                   AddAttributesAssembler addAttributesAssembler,
                                   DeleteAttributesAssembler deleteAttributesAssembler,
                                   BindAccountAssemble bindAccountAssemble,
                                   QuerySubscriptionAssembler querySubscriptionAssembler,
                                   ModifyProfileAssembler modifyProfileAssembler,
                                   SubscriptionAssemble subscriptionAssemble,
                                   QueryProfileAssembler queryProfileAssembler
    ) {
        this.accountAppService = accountAppService;
        this.fetchMappingService = fetchMappingService;
        this.fetchAccountService = fetchAccountService;
        this.registerAccountAssembler = registerAccountAssembler;
        this.registerBindAccountAssembler = registerBindAccountAssembler;
        this.queryAttributesAssembler = queryAttributesAssembler;
        this.addAttributesAssembler = addAttributesAssembler;
        this.deleteAttributesAssembler = deleteAttributesAssembler;
        this.bindAccountAssemble = bindAccountAssemble;
        this.querySubscriptionAssembler = querySubscriptionAssembler;
        this.subscriptionAssemble = subscriptionAssemble;
        this.modifyProfileAssembler = modifyProfileAssembler;
    }

    @PostMapping("/updateRedisSequence")
    @ApiOperation(value = "刷新最新索引")
    @ApiIgnore()
    public Result<String> updateRedisSequence() {
        log.info("start update RedisSequence");
        return new Result<>("0", null, "更新成功");
    }

    /**
     * get测试接口
     *
     * @return 返回参
     */
    @GetMapping("/just4Test")
    @ApiOperation(value = "Get心跳检查")
    @ApiIgnore()
    public Result<String> just4Test() {
        return new Result<>("0", null, "你好!!");
    }

    /**
     * Post测试接口
     *
     * @return 返回参
     */
    @PostMapping("/just4TestPost")
    @ApiOperation(value = "POST心跳检测")
    @ApiIgnore()
    public Result<String> just4TestPost() {
        return new Result<>("0", null, "你好!!");
    }


    @PostMapping("/clearCache")
    @ApiOperation(value = "会员缓存清除")
    @ApiIgnore()
    public Result<String> clearCache(@RequestBody @Valid ClearMemberCacheCommand clearMemberCache) {
        RedisConfigUtils.clearProfileCache(String.valueOf(clearMemberCache.getTenantId()), clearMemberCache.getMemberId());
        return new Result<>("0", null, "Member缓存清理完毕");
    }


    /**
     * Registration
     *
     * @param accountRegisterCommand input params of registration
     * @return 返回参
     */
    @PostMapping("/register")
    @ApiOperation(value = "注册", notes = "注册有两种路由规则，分别为:\n\t" +
            "1. registerRoute=M 手机注册路由规则 \n\t" +
            "2. registerRoute=E email注册路由规则\n\t" +
            "注: 默认为手机号")
    public Result<AccountRegisterDTO> register(@RequestBody @Valid AccountRegisterCommand accountRegisterCommand) {
        Account account = registerAccountAssembler.toAccount(accountRegisterCommand);
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(accountRegisterCommand.getTenantId(),
                accountRegisterCommand.getChannelId(), null, accountRegisterCommand.getSubscriptions());
        accountAppService.register(account, shardSubscription);
        AccountRegisterDTO accountResponse = new AccountRegisterDTO(account.getAccountId(), true);
        return new Result<>(null, accountResponse);
    }

    /**
     * 注册绑定
     *
     * @param accountRegisterBindCommand 入参
     * @return 返回参
     */
    @PostMapping("/registerBind")
    @ApiOperation(value = "注册绑定", notes = "注册有两种路由规则，分别为:\n\t" +
            "1. registerRoute=M 手机注册路由规则 \n\t" +
            "2. registerRoute=E email注册路由规则\n\t" +
            "3. registerRoute=B bindId注册路由规则\n\t" +
            "4. registerRoute=U unionId注册路由规则\n\t" +
            "注: 默认为手机号")
    public Result<RegisterBindAccountDTO> registerBind(@RequestBody @Valid AccountRegisterBindCommand accountRegisterBindCommand) {
        Account account = registerBindAccountAssembler.toAccount(accountRegisterBindCommand);
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(accountRegisterBindCommand.getTenantId(), accountRegisterBindCommand.getChannelId(), null, accountRegisterBindCommand.getBindId(), accountRegisterBindCommand.getUnionId());
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(accountRegisterBindCommand.getTenantId(),
                accountRegisterBindCommand.getChannelId(), null, accountRegisterBindCommand.getSubscriptions());
        JSONObject jsonObject = accountAppService.registerBind(account, shardSocialAccount, shardSubscription);
        RegisterBindAccountDTO registerBindAccountDTO = new RegisterBindAccountDTO(jsonObject.getString(AccountConstants.MEMBER_ID), jsonObject.getBoolean(NEW_REGISTER));
        return new Result<>(null, registerBindAccountDTO);
    }

    /**
     * 账号登录
     *
     * @param logonCommand 账号登入入参信息
     * @return 返回参
     */
    @PostMapping("/logon")
    @ApiOperation(value = "登陆")
    public Result<LogonDTO> logon(@RequestBody @Valid LogonCommand logonCommand) {
        Result<LogonDTO> result;
        LogonDTO response;
        response = accountAppService.logon(logonCommand);
        result = new Result<>(null, response);
        if (Optional.ofNullable(response).map(LogonDTO::getMemberId).isPresent()) {
            LogonEvent logonEvent = new LogonEvent(this, logonCommand.getTenantId().toString(), response.getMemberId(), result.getResultCode());
            SpringContextUtil.getApplicationContext().publishEvent(logonEvent);
        }
        return result;
    }

    /**
     * 账号密码修改或者重置
     *
     * @param modifyPasswordCommand 入参
     * @return 返回参
     */
    @PostMapping("/modifyPassword")
    @ApiOperation(value = "修改密码或重置密码")
    public Result<String> modifyPassword(@RequestBody @Valid @ModifyPasswordValid ModifyPasswordCommand modifyPasswordCommand) {
        accountAppService.modifyPassword(modifyPasswordCommand);
        return new Result<>(null, null);
    }

    /**
     * 检查手机号是否存在
     *
     * @param checkMobileCommand 入参
     * @return 返回参
     */
    @PostMapping("/checkMobile")
    @ApiOperation(value = "检查手机号")
    public Result<String> checkMobile(@RequestBody @Valid CheckMobileCommand checkMobileCommand) {
        MobileMapping mobileMapping = fetchMappingService.fetchMobileByTenantIdAndMobile(checkMobileCommand.getTenantId().toString(), checkMobileCommand.getMobile());
        if (Optional.ofNullable(mobileMapping).isPresent()) {
            throw new BusinessException(ResultEnum.MOBILE_EXIST.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.MOBILE_EXIST.getMessage());
        }
        return new Result<>(null, null);
    }

    /**
     * 检查邮箱是否存在
     *
     * @param checkEmailCommand 入参
     * @return 返回参
     */
    @PostMapping("/checkEmail")
    @ApiOperation(value = "检查邮箱")
    public Result<String> checkEmail(@RequestBody @Valid CheckEmailCommand checkEmailCommand) {
        EmailMapping emailMapping = fetchMappingService.fetchEmailByTenantIdAndEmail(checkEmailCommand.getTenantId().toString(), checkEmailCommand.getEmail());
        if (Optional.ofNullable(emailMapping).isPresent()) {
            throw new BusinessException(ResultEnum.EMAIL_EXIST.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.EMAIL_EXIST.getMessage());
        }
        return new Result<>(null, null);
    }

    /**
     * 查询账号
     *
     * @param queryAccountCommand 入参
     * @return 返回参
     */
    @PostMapping("/queryAccount")
    @ApiOperation(value = "查询账号",
            notes = "1、会员号查询\t\n" +
                    "2、手机号查询\t\n" +
                    "3、邮箱查询\t\n" +
                    "4、bindId查询(如果是wechat优先获取ACL的unionId查询)\t\n" +
                    "5、unionId+BindId查询(如果是wechat优先unionId查询)\t\n" +
                    "注意微信信息查询优先unionId查询，bindId不一定有mapping关系，如需根据bindId查询请调用queryBinding接口")
    public Result<QueryAccountDTO> queryAccount(@RequestBody @Valid QueryAccountCommand queryAccountCommand) {
        QueryAccountDTO queryAccountDTO = null;
        if (Optional.ofNullable(queryAccountCommand.getChannelId()).isPresent()
                && Optional.ofNullable(queryAccountCommand.getBindId()).isPresent()) {
            JSONObject jsonObject = accountAppService.fetchAccountByUnionIdAndBindId(queryAccountCommand.getTenantId().toString(), queryAccountCommand.getChannelId().toString(), queryAccountCommand.getUnionId(), queryAccountCommand.getBindId());
            queryAccountDTO = new QueryAccountDTO(jsonObject.getString(ACCOUNT_ID), jsonObject.getBoolean(IS_BIND));
        }
        if (Optional.ofNullable(queryAccountCommand.getEmail()).isPresent()) {
            Account account = fetchMappingService.fetchByTenantIdAndEmail(queryAccountCommand.getTenantId().toString(), queryAccountCommand.getEmail());
            queryAccountDTO = new QueryAccountDTO(account.getAccountId(), false);
        }
        if (Optional.ofNullable(queryAccountCommand.getMobile()).isPresent()) {
            Account account = fetchMappingService.fetchByTenantIdAndMobile(queryAccountCommand.getTenantId().toString(), queryAccountCommand.getMobile());
            queryAccountDTO = new QueryAccountDTO(account.getAccountId(), false);
        }
        if (Optional.ofNullable(queryAccountCommand.getMemberId()).isPresent()) {
            Account account = fetchAccountService.fetchAccountByTenantIdAndAccountId(queryAccountCommand.getTenantId().toString(), queryAccountCommand.getMemberId());
            account.activeStatusCheck();
            queryAccountDTO = new QueryAccountDTO(account.getAccountId(), false);
        }
        return new Result<>(null, queryAccountDTO);

    }

    /**
     * 查询用户属性
     *
     * @param queryAttributesCommand 查询用户属性请求参数
     * @return 返回参 用户属性结果
     */
    @PostMapping("/queryAttributes")
    @ApiOperation(value = "查询用户属性")
    public Result<QueryAttributesDTO> queryAttributes(@RequestBody @Valid QueryAttributesCommand queryAttributesCommand) {
        Account account = queryAttributesAssembler.toAccount(queryAttributesCommand);
        accountAppService.fetchExtraAttributeByTenantIdAndAccountId(account);
        QueryAttributesDTO response = queryAttributesAssembler.fromAccount(account);
        return new Result<>(null, response);
    }

    /**
     * 增加用户属性
     *
     * @param attributesCommand 增加用户属性请求参数
     * @return 返回参 增加用户属性结果
     */
    @PostMapping("/addAttributes")
    @ApiOperation(value = "添加用户属性")
    public Result<String> addAttributes(@RequestBody @Valid AttributesCommand attributesCommand) {
        Account account = addAttributesAssembler.toAccount(attributesCommand);
        accountAppService.storeAttributes(account);
        return new Result<>(null, null);

    }

    /**
     * 修改用户属性
     *
     * @param attributesCommand 修改用户属性请参参数
     * @return 返回参 修改用户属性结果
     */
    @PostMapping("/modifyAttributes")
    @ApiOperation(value = "修改用户属性")
    public Result<String> modifyAttributes(@RequestBody @Valid AttributesCommand attributesCommand) {
        Account account = addAttributesAssembler.toAccount(attributesCommand);
        accountAppService.storeAttributes(account);
        return new Result<>(null, null);
    }

    /**
     * 删除用户属性
     *
     * @param deleteAttributesCommand 删除用户属性请求参数
     * @return 返回参 删除用户属性结果
     */
    @PostMapping("/deleteAttributes")
    @ApiOperation(value = "删除用户属性")
    public Result<String> deleteAttributes(@RequestBody @Valid DeleteAttributesCommand deleteAttributesCommand) {
        Account account = deleteAttributesAssembler.toAccount(deleteAttributesCommand);
        accountAppService.deleteAttributes(account);
        return new Result<>(null, null);
    }

    /**
     * 将第三方账号绑定到用户上
     *
     * @param bindingCommand 绑定请求参数
     * @return 返回参 绑定结果
     */
    @PostMapping("/binding")
    @ApiOperation(value = "绑定", notes = "身份识别信息检查已经是会员，但当前的第三方社交账号信息还未绑定，请调用此接口进行绑定，第三方社交账号如：" +
            "1、WECHAT 公众号和微信小程序的openId与unionId \t\n" +
            "2、TMall openUID \t\n" +
            "3、JD PID 等，\t\n" +
            "这里需要注意WECHAT的绑定逻辑，含有额外的unionId进行公众号与小程序关联打通的，这里经常有一个场景就是同一个微信账号的公众号等信息已经注册绑定过，但是在小程序中这个人没有绑定过，首次进行小程序需要调用绑定接口进行绑定一下")
    public Result<String> binding(@RequestBody @Valid BindingCommand bindingCommand) {
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(bindingCommand.getTenantId(),
                bindingCommand.getChannelId(), bindingCommand.getMemberId(), bindingCommand.getBindId(), bindingCommand.getUnionId());
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(bindingCommand.getTenantId(),
                bindingCommand.getChannelId(), bindingCommand.getMemberId(), null);
        Account account = registerBindAccountAssembler.toAccount(bindingCommand.getTenantId(), bindingCommand.getChannelId(), bindingCommand.getMemberId(), bindingCommand.getDevice());
        accountAppService.bind(account, shardSocialAccount, shardSubscription);
        return new Result<>(null, null);
    }

    /**
     * 查询绑定信息
     *
     * @param queryBindingCommand 查询请求参数
     * @return 返回参 查询结果
     */
    @PostMapping("/queryBinding")
    @ApiOperation(value = "查询绑定信息", notes = "1、根据BindID和ChannelID，查询第三方社交账号是否已经存在绑定关系 \t\n" +
            "2、根据memberId和channelId，查询这个会员的某个渠道的绑定关系 \t\n" +
            "3、根据memberId，查询这个会员的所有绑定关系 \t\n" +
            "注tenantId必填")
    public Result<QueryBindDTO> queryBinding(@RequestBody @Valid QueryBindingCommand queryBindingCommand) {
        JSONObject jsonObject;
        String type;
        String query;
        if (StringUtils.isNotBlank(queryBindingCommand.getBindId())) {
            type = BIND_ID;
            query = queryBindingCommand.getBindId();
        } else if (StringUtils.isNotBlank(queryBindingCommand.getMemberId())) {
            if (Optional.ofNullable(queryBindingCommand.getChannelId()).isPresent()) {
                type = CHANNEL_ID_AND_BIND_ID;
            } else {
                type = MEMBER_ID;
            }
            query = queryBindingCommand.getMemberId();
        } else {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.INCORRECT_QUERY_PARAM.getMessage());
        }
        jsonObject = accountAppService.queryBinding(queryBindingCommand.getTenantId(), queryBindingCommand.getChannelId(), type, query);
        return new Result<>(null, new QueryBindDTO(jsonObject.getString(ACCOUNT_ID), parseArray(jsonObject.getString(BIND_DTO_LIST), BindDTO.class)));
    }

    /**
     * 根据unBindRoute删除第三方账号在用户上的绑定
     *
     * @param unBindingCommand 请求参数
     * @return 返回参 解除绑定结果
     */
    @PostMapping("/unBinding")
    @ApiOperation(value = "解除绑定", notes = "根据tenantId、memberId、channelId，解除这个会员指定渠道下的绑定关系 \t\n" +
            "注：如果还有其他WECHAT绑定关系，将不会解除这会员的unionId关系，只有解绑最后一条WECHAT绑定关系才会解绑unionId关系")
    public Result<String> unBinding(@RequestBody @Valid UnBindingCommand unBindingCommand) {
        //校验解绑类型是否正确
        bindAccountAssemble.checkUnBindIdRoute(unBindingCommand);
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(unBindingCommand.getTenantId(),
                unBindingCommand.getChannelId(), unBindingCommand.getMemberId(), unBindingCommand.getBindId(), unBindingCommand.getUnionId());
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(unBindingCommand.getTenantId(),
                unBindingCommand.getChannelId(), unBindingCommand.getMemberId(), null);
        accountAppService.unBind(shardSocialAccount, shardSubscription, unBindingCommand.getUnBindRoute());
        return new Result<>(null, null);
    }

    /**
     * 查询绑定信息
     *
     * @param queryUnionIdCommand 查询请求参数
     * @return 返回参 查询结果
     */
    @PostMapping("/queryUnionId")
    @ApiOperation(value = "查询绑定信息", notes = "根据unionId,查询这个unionId对应的会员编号 \t\n" +
            "注：tenantId必填")
    public Result<QueryUnionIdDTO> queryUnionId(@RequestBody @Valid QueryUnionIdCommand queryUnionIdCommand) {
        Account account = fetchMappingService.fetchByTenantIdAndUnionId(queryUnionIdCommand.getTenantId().toString(), queryUnionIdCommand.getUnionId(), Optional.ofNullable(queryUnionIdCommand.getUnionType()).orElse("WECHAT"));
        QueryUnionIdDTO bindResponse = new QueryUnionIdDTO(account.getAccountId());
        return new Result<>(null, bindResponse);
    }

    /**
     * 关注
     *
     * @param subscribeCommand 请求参数
     * @return 返回参 关注结果
     */
    @PostMapping("/subscribe")
    @ApiOperation(value = "关注")
    public Result<String> subscribe(@RequestBody @Valid SubscribeCommand subscribeCommand) {
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(subscribeCommand.getTenantId(), subscribeCommand.getChannelId(), null, subscribeCommand.getBindId(), null);
        accountAppService.subscribe(shardSocialAccount);
        return new Result<>(null, null);
    }


    /**
     * 取消关注
     *
     * @param subscribeCommand 请求参数
     * @return 返回参 取消关注结果
     */
    @PostMapping("/unSubscribe")
    @ApiOperation(value = "取消关注")
    public Result<String> unSubscribe(@RequestBody @Valid SubscribeCommand subscribeCommand) {
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(subscribeCommand.getTenantId(), subscribeCommand.getChannelId(), null, subscribeCommand.getBindId(), null);
        accountAppService.unSubscribe(shardSocialAccount);
        return new Result<>(null, null);
    }

    /**
     * 查询个人资料
     *
     * @param queryProfileCommand 查询个人资料请求参数
     * @return 返回参 查询个人资料结果
     */
    @PostMapping("/queryProfile")
    @ApiOperation(value = "查询个人资料", notes = "1、根据BindID和ChannelID，查询会员个人资料 \t\n" +
            "2、根据Email，查询会员个人资料 \t\n" +
            "3、根据Mobile，查询会员个人资料 \t\n" +
            "4、根据MemberId，查询会员个人资料 \t\n" +
            "注：tenantId必填")
    public Result<QueryProfileDTO> queryProfile(@RequestBody @Valid QueryProfileCommand queryProfileCommand) {
        int multipleCount = 0;
        JSONObject jsonObject = new JSONObject(); // 先将jsonObject创建出来
        if (Optional.ofNullable(queryProfileCommand.getChannelId()).isPresent()
                && Optional.ofNullable(queryProfileCommand.getBindId()).isPresent()) {
            multipleCount++;
            jsonObject = accountAppService.fetchProfileByUnionIdAndBindId(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getChannelId().toString(), queryProfileCommand.getUnionId(), queryProfileCommand.getBindId(), FIELDS);
        }
        if (Optional.ofNullable(queryProfileCommand.getEmail()).isPresent()) {
            multipleCount++;
            jsonObject = accountAppService.fetchProfileByTenantIdAndEmail(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getEmail(), FIELDS);
        }
        if (Optional.ofNullable(queryProfileCommand.getMobile()).isPresent()) {
            multipleCount++;
            jsonObject = accountAppService.fetchProfileByTenantIdAndMobile(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getMobile(), FIELDS);
        }
        if (Optional.ofNullable(queryProfileCommand.getMemberId()).isPresent()) {
            multipleCount++;
            jsonObject = accountAppService.fetchProfileByTenantIdAndAccountId(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getMemberId(), FIELDS);
        }
        if (multipleCount != 1) {
            throw new BusinessException(INCORRECT_QUERY_PARAM.getCode(), INCORRECT_QUERY_PARAM.getV2Code(), INCORRECT_QUERY_PARAM.getMessage());
        }
        QueryProfileDTO queryProfileDTO = fromAccountDTO(jsonObject);
        return new Result<>(null, queryProfileDTO);
    }


    /**
     * 修改个人资料
     *
     * @param command 修改个人资料请求参数
     * @return 返回参 修改个人资料结果
     */
    @PostMapping("/modifyProfile")
    @ApiOperation(value = "修改个人资料", notes = "1、根据tenantId和MemberId，修改个人资料，包含：柜台信息、用户信息、地址信息、订阅信息和用户属性信息） \t\n" +
            "注：修改的个人资料不是必传的，只修改需要变更的信息。")
    public Result<QueryProfileDTO> modifyProfile(@RequestBody @Valid ModifyProfileCommand command) {
        Account account = modifyProfileAssembler.toAccount(command);
        ShardSubscription shardSubscription = null;
        if (Optional.ofNullable(command.getSubscriptions()).isPresent()) {
            shardSubscription = subscriptionAssemble.toShardSubscription(command.getTenantId(), command.getChannelId(), command.getMemberId(), command.getSubscriptions());
        }
        QueryProfileDTO queryProfileDTO = accountAppService.modifyAccount(account, shardSubscription);
        return new Result<>(null, queryProfileDTO);
    }

    /**
     * 查询订阅信息
     *
     * @param command 入参
     * @return 返回参
     */
    @PostMapping("/querySubscriptions")
    @ApiOperation(value = "查询订阅信息", notes = "根据tenantId和memberId,查询会员订阅信息 \t\n" +
            "注：tenantId必传")
    public Result<QuerySubscriptionDTO> querySubscriptions(@RequestBody @Valid QuerySubscriptionsCommand command) {
        Account account = querySubscriptionAssembler.toAccount(command);
        QuerySubscriptionDTO querySubscriptionDTO = accountAppService.querySubscriptions(account);
        return new Result<>(null, querySubscriptionDTO);
    }

    /**
     * 添加订阅信息
     *
     * @param command 入参
     * @return 返回参
     */
    @PostMapping("/addSubscriptions")
    @ApiOperation(value = "添加订阅信息", notes = "根据tenantId、channelId和memberId,添加订阅信息 \t\n" +
            "注：optId必须是AM中已存在的")
    public Result<String> addSubscriptions(@RequestBody @Valid AddSubscriptionsCommand command) {
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(command.getTenantId(),
                command.getChannelId(), command.getMemberId(), command.getSubscriptions());
        accountAppService.storeShardSubscription(shardSubscription);
        return new Result<>(null, null);
    }

    /**
     * 修改订阅信息
     *
     * @param command 入参
     * @return 返回参
     */
    @PostMapping("/modifySubscriptions")
    @ApiOperation(value = "修改订阅信息")
    public Result<String> modifySubscriptions(@RequestBody @Valid ModifySubscriptionsCommand command) {
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(command.getTenantId(),
                command.getChannelId(), command.getMemberId(), command.getSubscriptions());
        accountAppService.storeShardSubscription(shardSubscription);
        return new Result<>(null, null);
    }
}
