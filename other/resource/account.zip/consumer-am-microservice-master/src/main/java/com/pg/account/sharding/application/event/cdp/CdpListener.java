package com.pg.account.sharding.application.event.cdp;

import com.alibaba.fastjson.JSON;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.infrastructure.retention.sb.consumer.StreamUtil;
import com.pg.account.sharding.infrastructure.servicebus.MessageEntity;
import com.pg.account.sharding.infrastructure.servicebus.ServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.servicebus.ServiceBusTemplate;
import com.pg.account.sharding.infrastructure.tablestorage.EventSendServiceBusFailedEntity;
import com.pg.account.sharding.infrastructure.tablestorage.ServiceBusLogEntity;
import com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;

import static com.pg.account.sharding.infrastructure.common.utils.StringValidUtil.underlineToHump;

/**
 * @author mrluve
 */
@Slf4j
@Component
public class CdpListener {

    private final ServiceBusTemplate serviceBusTemplate;
    private final TableStorageUtils<ServiceBusLogEntity> logUtil;
    private final TableStorageUtils<EventSendServiceBusFailedEntity> eventSendServiceBusFailedEntityTableStorageUtils;
    private final UidGenerator uidGenerator;
    private final StreamUtil streamUtil;


    @Autowired
    public CdpListener(ServiceBusTemplate serviceBusTemplate, TableStorageUtils<ServiceBusLogEntity> logUtil, TableStorageUtils<EventSendServiceBusFailedEntity> eventSendServiceBusFailedEntityTableStorageUtils, UidGenerator uidGenerator, StreamUtil streamUtil) {
        this.serviceBusTemplate = serviceBusTemplate;
        this.logUtil = logUtil;
        this.eventSendServiceBusFailedEntityTableStorageUtils = eventSendServiceBusFailedEntityTableStorageUtils;
        this.uidGenerator = uidGenerator;
        this.streamUtil = streamUtil;
    }

    /**
     * @param serviceBusQueueTopicEnum 主题或队列枚举
     * @param msg                      消息体
     * @param requestType              请求类型
     * @param count                    发送次数
     * @return 是否发送成功
     */
    public boolean send(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, Object msg, String requestType, int count) {
        //发送消息体
        MessageEntity messageEntity = new MessageEntity(msg);
        //发送serviceBus
        boolean sendStatus = sendServiceBus(serviceBusQueueTopicEnum, messageEntity, requestType);
        //执行结果写入ts   发送状态为false 执行次数为3
        int retryCount = 3;
        if (!sendStatus && count >= retryCount) {
            writeToTs(serviceBusQueueTopicEnum.queueOrTopicName(), JSON.toJSONString(messageEntity), String.valueOf(sendStatus));
        }
        return sendStatus;
    }

    /**
     * 发送serviceBus消息
     *
     * @param serviceBusQueueTopicEnum 队列或主题枚举
     * @param msg                      消息体
     * @param requestType              请求类型
     * @return 是否发送成功
     */
    private boolean sendServiceBus(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, Object msg, String requestType) {
        boolean sendStatus = serviceBusTemplate.sendTopicMsg(serviceBusQueueTopicEnum, msg);
        if (!sendStatus) {
            String errMsg = "serviceBus:" + serviceBusQueueTopicEnum.queueOrTopicName() + "发送失败," + "msgBody:" + JSON.toJSONString(msg);
            //注册事件发送service失败，发送kpi告警
            streamUtil.sendKpi(V3ResultEnum.SERVICE_BUS_ERROR.getCode(), errMsg, requestType);
        }
        return sendStatus;
    }

    /**
     * 写日志到容错Ts
     *
     * @param name name
     * @param msg  msg
     */
    private void writeToTs(String name, String msg, String status) {
        Calendar now = Calendar.getInstance();
        int month = now.get(Calendar.MONTH) + 1;
        //组装发送体  默认容错发送次数0
        ServiceBusLogEntity serviceBusLogEntity = new ServiceBusLogEntity(String.valueOf(uidGenerator.getUid()), name, msg, status, 0);
        try {
            String tableName;
            //发送成功记录到对应月份ts中
            tableName = underlineToHump(name) + now.get(Calendar.YEAR) + (month < 10 ? "0" + month : month);
            logUtil.createTableIfNotExist(tableName);
            logUtil.save(tableName, serviceBusLogEntity);
            EventSendServiceBusFailedEntity eventSendServiceBusFailedEntity = new EventSendServiceBusFailedEntity(tableName, name, "false");
            tableName = "EventSendServiceBusFailed";
            eventSendServiceBusFailedEntityTableStorageUtils.createTableIfNotExist(tableName);
            eventSendServiceBusFailedEntityTableStorageUtils.saveOrUpdate(tableName, eventSendServiceBusFailedEntity);
        } catch (Exception e) {
            String errMsg = "TableStorage:" + name + "写入失败,msgBody:" + msg;
            streamUtil.sendKpi(V3ResultEnum.TABLE_STORAGE_ERROR.getCode(), errMsg, "CdpListener_writeToTs");
        }
    }

}
