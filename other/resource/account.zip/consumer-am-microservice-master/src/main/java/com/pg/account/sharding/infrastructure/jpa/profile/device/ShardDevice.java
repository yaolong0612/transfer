package com.pg.account.sharding.infrastructure.jpa.profile.device;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.DeviceInfo;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterDeviceJson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Optional;

/**
 * 设备类
 *
 * @author Jack
 * @date 2021/5/27 19:18
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_DEVICE")
@DynamicUpdate
@DynamicInsert
@Data
public class ShardDevice extends BaseEntity implements Serializable {
    private static final long serialVersionUID = -1173983274085656734L;
    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterDeviceJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private DeviceInfo device;

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "identityId is null");
        this.identityId = account.getIdentityId();
        this.device = account.getUserAdditionalInfo().getDevice();
        super.addCreateTime();
    }

    public void buildFromAccount(Account account) {
        this.identityId = account.getIdentityId();
        this.device = account.getUserAdditionalInfo().getDevice();
        super.addUpdatedTime();
    }

    /**
     * 将入参的device和数据库的device合并
     *
     * @param db device from db
     */
    public void builder(ShardDevice db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.id = Optional.ofNullable(this.id).orElse(db.getId());
            this.identityId = Optional.ofNullable(this.identityId).orElse(db.getIdentityId());
            Optional.ofNullable(this.device)
                    .ifPresent(deviceInfo -> deviceInfo.builder(db.getDevice()));
        }
    }
}
