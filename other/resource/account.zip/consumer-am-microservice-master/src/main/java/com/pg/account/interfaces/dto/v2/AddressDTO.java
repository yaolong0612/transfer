package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 地址类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "AddressDTO_V2", description = "V2 AddressDTO接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO implements Serializable {

    private static final long serialVersionUID = 5334131549780469143L;
    @ApiModelProperty(value = "Address UUID identification code", name = "addressCode", example = "123")
    private String addressCode;
    @ApiModelProperty(value = "full Name", name = "fullName", example = "孙悟空")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "Mobile phone", name = "cellphone", example = "15061837133")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "phone", name = "phone", example = "15061837133")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "province", name = "province", example = "江苏")
    private String province;
    @ApiModelProperty(value = "city", name = "city", example = "南京")
    private String city;
    @ApiModelProperty(value = "district", name = "district", example = "江宁区")
    private String district;
    @ApiModelProperty(value = "Address details", name = "address", example = "秣陵街道胜太路77号胜泰新寓9999#1801")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "Postcode", name = "postcode", example = "230001")
    private String postcode;

}
