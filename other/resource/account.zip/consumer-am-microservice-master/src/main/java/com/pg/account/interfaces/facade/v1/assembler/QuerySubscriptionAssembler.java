package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.QuerySubscriptionsCommand;
import com.pg.account.sharding.domain.model.account.Account;
import org.springframework.stereotype.Component;

/**
 * @author wsq
 * @date 2021/6/10 16:03
 **/
@Component
public class QuerySubscriptionAssembler {

    public Account toAccount(QuerySubscriptionsCommand command) {
        return Account.AccountBuilder
                .anAccount()
                .tenantId(command.getTenantId().toString())
                .accountId(command.getMemberId())
                .build();
    }


}
