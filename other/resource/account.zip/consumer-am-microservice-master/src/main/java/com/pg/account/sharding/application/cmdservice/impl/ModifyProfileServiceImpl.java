package com.pg.account.sharding.application.cmdservice.impl;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.sharding.application.cmdservice.ModifyProfileService;
import com.pg.account.sharding.application.event.ChangeCounterEvent;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.UpdateProfileEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.domain.service.CreateAddressService;
import com.pg.account.sharding.domain.service.ModifyAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.Optional;

/**
 * @author lfx
 * @date 2022/1/5 15:14
 */
@Service
public class ModifyProfileServiceImpl implements ModifyProfileService {
    private final ModifyAccountService modifyAccountService;
    private final AccountRepository accountRepository;
    private final CreateAddressService createAddressService;

    @Autowired
    public ModifyProfileServiceImpl(ModifyAccountService modifyAccountService,
                                    AccountRepository accountRepository,
                                    CreateAddressService createAddressService
    ) {
        this.modifyAccountService = modifyAccountService;
        this.accountRepository = accountRepository;
        this.createAddressService = createAddressService;
    }


    /**
     * 修改用户信息
     *
     * @param account account
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void modifyProfile(Account account) {
        // 组合account的中的profile聚合
        Account basicAccount = modifyAccountService.accountValidate(account);
        accountRepository.save(basicAccount);
        Optional.ofNullable(account.getAddress()).ifPresent(a -> createAddressService.save(account.tenantId(), account.accountId(), account.getAddress()));
        basicAccount.setAddress(account.getAddress());
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                if (Optional.ofNullable(account.getCounter()).isPresent()) {
                    ChangeCounterEvent changeCounterEvent = new ChangeCounterEvent(this, account);
                    SpringContextUtil.getApplicationContext().publishEvent(changeCounterEvent);
                }
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UpdateProfileEvent updateProfileEvent = new UpdateProfileEvent(this, basicAccount, null);
                SpringContextUtil.getApplicationContext().publishEvent(updateProfileEvent);
            }
        });
    }
}
