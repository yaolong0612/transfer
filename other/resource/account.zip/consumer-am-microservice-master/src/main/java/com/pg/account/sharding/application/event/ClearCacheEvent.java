package com.pg.account.sharding.application.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author guye
 * @version 1.0
 * @date 2022/1/19 21:39
 */
@Getter
public class ClearCacheEvent extends ApplicationEvent {

    private String tenant;
    private String accountId;

    public ClearCacheEvent(Object source) {
        super(source);
    }

    public ClearCacheEvent(Object source,String tenant,String accountId){
        super(source);
        this.tenant = tenant;
        this.accountId = accountId;
    }
}
