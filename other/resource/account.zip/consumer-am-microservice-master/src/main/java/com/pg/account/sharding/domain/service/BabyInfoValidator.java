package com.pg.account.sharding.domain.service;

import com.alibaba.fastjson.JSON;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.alibaba.fastjson.JSON.toJSONString;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;

/**
 * @author sunliang
 */
@Component("shardBabyInfoValidator")
@Slf4j
public class BabyInfoValidator {

    private static final int BABY_BIRTHDAY_LENGTH = 10;

    /**
     * 校验宝宝信息
     *
     * @param extraAttributeItem 属性对象，宝宝信息
     */
    public String validator(ExtraAttributeItem extraAttributeItem) {
        String attrValue = extraAttributeItem.getAttrValue();
        List<BabyInfoBean> babyInfoBeanList = JSON.parseArray(attrValue, BabyInfoBean.class);
        babyInfoBeanList.forEach(this::beanValidator);
        //根据baby年龄排序从低到高
        babyInfoBeanList.sort((a, b) -> b.getBirthday().compareTo(a.getBirthday()));
        for (BabyInfoBean babyInfoBean : babyInfoBeanList) {
            if (null == babyInfoBean.getCreateTime()) {
                babyInfoBean.setCreateTime(DateFormatUtils.format(new Date(), YYYY_MM_DD_HH_MI_SS_SSS, Locale.CHINA));
            }
            if (BABY_BIRTHDAY_LENGTH == babyInfoBean.getBirthday().length()) {
                SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD);
                try {
                    Date date = sdf.parse(babyInfoBean.getBirthday());
                    String babyBirthday = DateFormatUtils.format(date, YYYY_MM_DD_HH_MI_SS, Locale.CHINA);
                    babyInfoBean.setBirthday(babyBirthday);
                } catch (ParseException e) {
                    throw new BusinessException(ResultEnum.INCORRECT_BABY_BIRTHDAY.getCode(), ResultEnum.INCORRECT_BABY_BIRTHDAY.getV2Code(), ResultEnum.INCORRECT_BABY_BIRTHDAY.getMessage());
                }
            }
        }
        //校验多个宝宝生日之间相差是否满足1岁的需求
        this.babyBirthdayValidator(babyInfoBeanList);
        return toJSONString(babyInfoBeanList);
    }

    /**
     * 宝宝生日校验
     *
     * @param babyInfoBean 宝宝信息
     */
    private void beanValidator(BabyInfoBean babyInfoBean) {
        ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
        Validator validator = vf.getValidator();
        Set<ConstraintViolation<BabyInfoBean>> validate = validator.validate(babyInfoBean);
        String error;
        for (ConstraintViolation<BabyInfoBean> cv : validate) {
            error = cv.getMessage();
            if (StringUtils.isNotBlank(error)) {
                throw new BusinessException(ResultEnum.INCORRECT_BABY_BIRTHDAY.getCode(), ResultEnum.INCORRECT_BABY_BIRTHDAY.getV2Code(), error);
            }
        }
    }

    /**
     * 宝宝生日校验
     *
     * @param babyInfoBeanList 宝宝信息集合
     */
    private void babyBirthdayValidator(List<BabyInfoBean> babyInfoBeanList) {
        //校验多个宝宝生日之间相差是否满足1岁的需求
        for (int i = 0; i < babyInfoBeanList.size(); i++) {
            String babyBirthday1 = babyInfoBeanList.get(i).getBirthday();
            int j = i + 1;
            if (j != babyInfoBeanList.size()) {
                String babyBirthday2 = babyInfoBeanList.get(j).getBirthday();
                SimpleDateFormat fmt = new SimpleDateFormat(YYYY_MM_DD);
                Date date1;
                Date date2;
                try {
                    date1 = fmt.parse(babyBirthday1);
                    date2 = fmt.parse(babyBirthday2);
                } catch (ParseException e) {
                    log.error("Baby生日错误[{},{}]", babyBirthday1, babyBirthday2);
                    throw new BusinessException(ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getCode(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getV2Code(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getMessage());
                }
                //i宝生日
                Calendar birthdayDate1 = Calendar.getInstance();
                birthdayDate1.setTime(date1);
                //j宝生日
                Calendar birthdayDate2 = Calendar.getInstance();
                birthdayDate2.setTime(date2);
                // 宝龄最小的宝宝生日减一年比下一个baby的年龄还晚或者相等则符合要求
                // 即每个宝宝年龄相隔1岁
                Calendar birthdayDate3 = Calendar.getInstance();
                birthdayDate3.setTime(date1);
                birthdayDate3.add(Calendar.YEAR, -1);
                boolean babyDayValidation = birthdayDate1.equals(birthdayDate2) || birthdayDate2.equals(birthdayDate3) || birthdayDate3.after(birthdayDate2);
                if (!babyDayValidation) {
                    log.warn("Baby生日错误,两baby之间的生日间隔不足1岁[{},{}]", babyBirthday1, babyBirthday2);
                    throw new BusinessException(ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getCode(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getV2Code(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getMessage());
                }
            }
        }
    }

    /**
     * @param account
     * @param attrId
     */
    public void runEvent(Account account, String attrId) {

    }
}
