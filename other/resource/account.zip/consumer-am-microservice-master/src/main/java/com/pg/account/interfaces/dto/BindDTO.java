package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import static java.lang.Long.parseLong;

/**
 * @author JackSun
 * @date 2017/2/17
 */
@ApiModel(value = "BindDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BindDTO implements Serializable {
    private static final long serialVersionUID = -3893947323758333144L;

    @ApiModelProperty(value = "渠道ID", example = "12")
    private Long channelId;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;

    public BindDTO builder(SocialAccountItem socialAccountItem) {
        this.channelId = parseLong(socialAccountItem.getChannel().getChannelId());
        this.bindId = socialAccountItem.getBindId();
        this.unionId = socialAccountItem.getUnionId();
        return this;
    }

}
