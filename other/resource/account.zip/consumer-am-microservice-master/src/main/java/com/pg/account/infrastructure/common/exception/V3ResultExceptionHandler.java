package com.pg.account.infrastructure.common.exception;

import cn.com.pg.guardian.client.shared.GuardianAuthenticationException;

import com.alibaba.fastjson.JSONException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.interfaces.vo.v3.V3Result;
import com.pg.account.interfaces.vo.v3.V3ResultUtil;
import com.pg.account.sharding.interfaces.facede.v3.ShardAccountServiceFacade;
import com.pg.account.sharding.interfaces.facede.v3.ShardAccountServiceProtectedFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.dao.InvalidDataAccessResourceUsageException;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import java.util.Optional;
import java.util.Set;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.exception.enums.V3ResultEnum.*;

/**
 * 全局统一异常处理器
 *
 * @author Jack Sun
 * @date 2019-11-25 16:36
 */
@ControllerAdvice(assignableTypes = {ShardAccountServiceFacade.class, ShardAccountServiceProtectedFacade.class})
@Slf4j
@ResponseBody
public class V3ResultExceptionHandler {

    /**
     * 解析BindingResult的异常信息
     *
     * @param bindingResult 表单异常信息
     * @return 表单详细错误信息
     */
    private static V3Result handleErrorMessage(BindingResult bindingResult) {
        FieldError error = bindingResult.getFieldError();
        Validate.notNull(error);
        String msg = error.getDefaultMessage();
        V3ResultEnum resultEnum = getByMsg(msg);
        log.warn(msg);
        return V3ResultUtil.error(resultEnum.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 500 - Internal Server Error
     * 拦截自定义返回异常
     *
     * @param e 自定义返回异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(ResultException.class)
    public V3Result handleResultException(ResultException e) {
        log.warn(RESULT_EXCEPTION, e);
        return V3ResultUtil.error(e.getCode(), e.getFrontMessage());
    }

    /**
     * 500 - Internal Server Error
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(DbException.class)
    public V3Result handleDbException(DbException e) {
        log.warn(DB_EXCEPTION, e);
        return V3ResultUtil.error(e.getCode(), e.getFrontMessage());
    }

    /**
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ExceptionHandler(DataAccessResourceFailureException.class)
    public V3Result handleDbException(DataAccessResourceFailureException e) {
        log.warn(DB_EXCEPTION, e);
        return V3ResultUtil.error(DB_ERROR.getCode(), DB_ERROR.getFrontMessage());
    }

    /**
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ExceptionHandler(InvalidDataAccessResourceUsageException.class)
    public V3Result handleDbException(InvalidDataAccessResourceUsageException e) {
        log.warn(DB_EXCEPTION, e);
        return V3ResultUtil.error(DB_ERROR.getCode(), DB_ERROR.getFrontMessage());
    }

    /**
     * 400 - Bad Request Error
     * 拦截入参校验失败业务异常
     *
     * @param e 业务异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BusinessException.class)
    public V3Result handleBusinessException(BusinessException e) {
        log.warn(BUSINESS_EXCEPTION, e);
        V3ResultEnum resultEnum = getByMsg(e.getMessage());
        return V3ResultUtil.error(e.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 拦截自定义外部系统异常
     *
     * @param e 外部系统异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(ExternalSystemException.class)
    public V3Result handleExternalSystemException(ExternalSystemException e) {
        log.warn(EXTERNAL_SYSTEM_EXCEPTION, e);
        V3ResultEnum resultEnum = getByMsg(e.getMessage());
        return V3ResultUtil.error(e.getCode(), resultEnum.getFrontMessage());
    }


    /**
     * 参数异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(IllegalArgumentException.class)
    public V3Result handleException(IllegalArgumentException e) {
        log.warn("IllegalArgumentException", e);
        V3ResultEnum resultEnum = getByMsg(e.getMessage());
        return V3ResultUtil.error(resultEnum.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 拦截未知的异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public V3Result handleException(Exception e) {
        log.warn("SystemErrorException", e);
        return V3ResultUtil.error(V3ResultEnum.ERROR.getCode(), V3ResultEnum.ERROR.getFrontMessage());
    }

    /**
     * 参数异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(InvalidDataAccessApiUsageException.class)
    public V3Result handleException(InvalidDataAccessApiUsageException e) {
        log.warn("InvalidDataAccessApiUsageException", e);
        return V3ResultUtil.error(V3ResultEnum.ACCOUNT_DATA_ERROR.getCode(), V3ResultEnum.ACCOUNT_DATA_ERROR.getFrontMessage());
    }

    /**
     * 400 - Bad Request
     * 拦截表单Java Validation异常
     *
     * @param e 表单参数验证异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BindException.class)
    public V3Result handleBindException(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        return handleErrorMessage(bindingResult);
    }

    /**
     * 400 - Bad Request
     * 缺少请求参数
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public String handleMissingServletRequestParameterException(MissingServletRequestParameterException e) {
        log.warn("缺少请求参数", e);
        return "缺少请求参数";
    }

    /**
     * 400 - Bad Request
     * 参数解析失败
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public V3Result handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        log.warn("参数解析失败", e);
        V3ResultEnum resultEnum = getByMsg(e.getMessage());
        return V3ResultUtil.error(resultEnum.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 400 - Bad Request
     * 方法参数无效
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public V3Result handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        BindingResult bindingResult = e.getBindingResult();
        return handleErrorMessage(bindingResult);

    }

    /**
     * 400 - Bad Request
     * 参数验证失败
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ConstraintViolationException.class)
    public V3Result handleConstraintViolationException(ConstraintViolationException e) {
        log.warn("参数验证失败,ConstraintViolationException", e);
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        ConstraintViolation<?> violation = violations.iterator().next();
        String message = violation.getMessage();
        V3ResultEnum resultEnum = getByMsg(message);
        return V3ResultUtil.error(resultEnum.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 400 - Bad Request
     * 参数验证失败
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ValidationException.class)
    public V3Result handleValidationException(ValidationException e) {
        log.warn("参数验证失败,ValidationException", e);
        V3ResultEnum resultEnum = getByMsg(e.getMessage());
        return V3ResultUtil.error(resultEnum.getCode(), resultEnum.getFrontMessage());
    }

    /**
     * 404 - Not Found
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoHandlerFoundException.class)
    public String noHandlerFoundException(NoHandlerFoundException e) {
        log.warn("Not Found", e);
        return "Not Found";
    }

    /**
     * 405 - Method Not Allowed
     */
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public String handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
        log.warn("不支持当前请求方法", e);
        return "Http Request Method Not Supported";
    }

    /**
     * 415 - Unsupported Media Type
     */
    @ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public String handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException e) {
        log.warn("不支持当前媒体类型", e);
        return "Http Media Type Not Supported";
    }

    /**
     * json解析异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(JSONException.class)
    public V3Result handleException(JSONException e) {
        log.warn("JSONException", e);
        return V3ResultUtil.error(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
    }

    /**
     * 拦截数据读取超时的异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(DataAccessException.class)
    public V3Result handleTimeoutException(DataAccessException e) {
        log.info("TimeoutException:", e);
        return V3ResultUtil.error(READ_TIMEOUT_ERROR.getCode(), READ_TIMEOUT_ERROR.getFrontMessage());
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(GuardianAuthenticationException.class)
    protected V3Result handleGuardianAuthenticationException(GuardianAuthenticationException e) {
        log.info("verifyAppGuardToken Error: {}", e.getMessage());
        return V3ResultUtil.error(APP_GUARDIAN_ERROR.getCode(), APP_GUARDIAN_ERROR.getFrontMessage());
    }
}
