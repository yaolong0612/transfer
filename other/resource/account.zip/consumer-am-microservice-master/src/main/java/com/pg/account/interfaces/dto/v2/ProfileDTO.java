package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 用户资料类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "ProfileDTO_V2")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProfileDTO implements Serializable {

    private static final long serialVersionUID = 2122233818880389418L;
    @ApiModelProperty(value = "Gender, male: M, female: F, unknown: U", name = "gender", example = "M")
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @ApiModelProperty(value = "Birthday, at least 18 years old, birthday format: yyyy-mm-dd", name = "birthday", example = "1979-01-01")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @ApiModelProperty(value = "mobile phone number", name = "mobile", example = "15061837133")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "email", name = "email", example = "test@163.com")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "full Name", name = "fullName", example = "孙悟空")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "nickname", name = "nickname", example = "孙悟空")
    private String nickname;

}
