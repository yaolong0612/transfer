package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Jack
 * @date 2018-7-8
 */
@ApiModel(value = "UnBindingDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UnBindingDTO implements Serializable {
    private static final long serialVersionUID = -7334764869474404410L;
    @ApiModelProperty(value = "租户编号", example = "10004")
    private Long tenantId;
    @ApiModelProperty(value = "渠道编号", example = "12")
    private Long channelId;
    @ApiModelProperty(value = "会员编号", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "解绑主键ID", example = "1")
    private Long userUnionIdRelId;
    @ApiModelProperty(value = "解绑主键ID", example = "2")
    private Long socialAccountId;
    @ApiModelProperty(value = "解绑状态", example = "true")
    private boolean releaseStatus;
}
