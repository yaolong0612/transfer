package com.pg.account.infrastructure.common.exception;

/**
 * BusinessException
 *
 * @author Jack Sun
 * @date 2019-11-25 16:19
 */
public class BusinessException extends ResultException {

    private static final long serialVersionUID = 7518777731406544317L;

    /**
     * 业务异常
     *
     * @param code    code
     * @param v2Code  v2Code
     * @param message message
     */
    public BusinessException(Integer code, Integer v2Code, String message) {
        super(code, v2Code, message);
    }

    /**
     * 业务异常
     *
     * @param code    code
     * @param message  message
     * @param frontMessage frontMessage
     */
    public BusinessException(Integer code, String message, String frontMessage) {
        super(code, message, frontMessage);
    }
}
