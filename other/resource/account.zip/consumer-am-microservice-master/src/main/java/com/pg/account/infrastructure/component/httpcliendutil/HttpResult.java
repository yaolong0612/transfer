package com.pg.account.infrastructure.component.httpcliendutil;

import java.util.Objects;

/**
 * @author Simon
 * @date 2016/10/19
 */
public class HttpResult {

    private int status;

    private String reason;

    private String responseBody;

    public HttpResult() {
    }

    public HttpResult(int status, String reason, String responseBody) {

        this.status = status;
        this.reason = reason;
        this.responseBody = responseBody;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        HttpResult that = (HttpResult) o;
        return status == that.status &&
                Objects.equals(reason, that.reason) &&
                Objects.equals(responseBody, that.responseBody);
    }

    @Override
    public int hashCode() {

        return Objects.hash(status, reason, responseBody);
    }

    @Override
    public String toString() {
        return "HttpResult{" +
                "status=" + status +
                ", reason='" + reason + '\'' +
                ", responseBody='" + responseBody + '\'' +
                '}';
    }
}
