package com.pg.account.sharding.application.event.bean.servicebus;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author sunliang
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OptBean implements Serializable {


    private static final long serialVersionUID = 941851686039903259L;
    @JSONField(ordinal = 1)
    private String id;
    @JSONField(ordinal = 2)
    private String value;
    @JSONField(ordinal = 3)
    private String status;
    @JSONField(ordinal = 4)
    private String version;
    @JSONField(ordinal = 5)
    private Timestamp optTime;
    @JSONField(ordinal = 6)
    private Timestamp createTime;
    @JSONField(ordinal = 7)
    private Timestamp modifyTime;

}
