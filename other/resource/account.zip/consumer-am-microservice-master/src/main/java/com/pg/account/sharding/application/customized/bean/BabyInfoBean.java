package com.pg.account.sharding.application.customized.bean;


import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.time.DateFormatUtils;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD;
import static com.pg.account.sharding.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author sunliang
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BabyInfoBean implements Serializable {

    private static final long serialVersionUID = 5223276814991046574L;
    private String certificate;
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "宝宝姓名只允许输入中文和英文,中间允许输入空格隔开")
    private String name;
    @Pattern(regexp = GENDER_PATTERN, message = "宝宝性别格式错误")
    private String gender;
    @NotBlank(message = "缺少宝宝生日")
    @Pattern(regexp = BABY_BIRTHDAY_PATTERN, message = "生日格式错误")
    private String birthday;
    private String age;
    private String seq;
    private String relation;
    private String createTime;

    public String formatDate() {
        DateFormat fmt = new SimpleDateFormat(YYYY_MM_DD);
        try {
            Date parse = fmt.parse(this.birthday);
            return DateFormatUtils.format(parse, YYYY_MM_DD, Locale.CHINA);
        } catch (ParseException e) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
    }

}
