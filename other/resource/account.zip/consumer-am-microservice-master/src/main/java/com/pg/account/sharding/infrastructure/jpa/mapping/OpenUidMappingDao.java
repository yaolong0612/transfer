package com.pg.account.sharding.infrastructure.jpa.mapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author lfx
 * @date 2021/5/31 14:49
 */
public interface OpenUidMappingDao extends JpaRepository<OpenUidMapping, Long> {

    /**
     * 根据openUid查询映射关系
     *
     * @param tenantId tenantId
     * @param openUid  openUid
     * @return OpenUidMapping
     */
    OpenUidMapping findByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(String tenantId, String openUid);

    /**
     * 根据tenantId和openUid进行删除
     *
     * @param tenantId tenantId
     * @param openUid  openUid
     * @return int
     */
    @Modifying
    @Transactional
    int deleteByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(String tenantId, String openUid);

}
