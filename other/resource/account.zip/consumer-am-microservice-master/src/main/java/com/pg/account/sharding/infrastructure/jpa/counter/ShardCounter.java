package com.pg.account.sharding.infrastructure.jpa.counter;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.CounterInfo;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterCounterJson;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Optional;

/**
 * 柜台类
 *
 * @author Jack
 * @date 2021/5/27 13:28
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_COUNTER")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardCounter extends BaseEntity implements Serializable {
    private static final long serialVersionUID = -8465749847472235603L;

    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterCounterJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private CounterInfo counter;

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.identityId = account.getIdentityId();
        this.counter = account.getCounter();
        super.addCreateTime();
    }

    public void buildFromDb(ShardCounter shardCounter) {
        Optional.ofNullable(shardCounter).ifPresent(s -> this.getCounter().buildFromDb(s.getCounter()));
    }


    public void changeFirstPurchaseCounter(IdentityId identityId, CounterInfo counter) {
        this.identityId = identityId;
        this.counter = counter;
    }

}
