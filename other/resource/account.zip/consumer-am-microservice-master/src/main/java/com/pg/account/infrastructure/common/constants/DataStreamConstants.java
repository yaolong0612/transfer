package com.pg.account.infrastructure.common.constants;

/**
 * @author lfx
 * @date 2020/11/23 11:22
 */
public class DataStreamConstants {
    public static final String DMP_INPUT_CHANNEL = "DMPProducerInputChannel";
    public static final String WE_INPUT_CHANNEL = "WEInputChannel";

    private DataStreamConstants() {
    }
}
