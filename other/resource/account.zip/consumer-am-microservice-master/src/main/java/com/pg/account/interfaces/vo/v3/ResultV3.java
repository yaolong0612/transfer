package com.pg.account.interfaces.vo.v3;

import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 数据返回bean
 *
 * @param <T> 对象
 * @author sunliang
 * @date 2016/12/25
 */
@ApiModel(value = "Result_V3", description = "V3接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultV3<T extends Serializable> implements Serializable {

    private static final String DEFAULT_RESULT_CODE = "0";
    private static final long serialVersionUID = 4012425088360683236L;
    @ApiModelProperty(value = "返回状态码，0为正常，其他字符为异常", required = true)
    private Integer code;
    @ApiModelProperty(value = "错误信息", required = true)
    private String msg;
    @ApiModelProperty(value = "返回的信息", required = true)
    private T data;

    public static String getDefaultResultCode() {
        return DEFAULT_RESULT_CODE;
    }

    public ResultV3(T data) {
        this.code = ResultEnum.SUCCESS.getCode();
        this.msg = ResultEnum.SUCCESS.getMessage();
        this.data = data;
    }
}
