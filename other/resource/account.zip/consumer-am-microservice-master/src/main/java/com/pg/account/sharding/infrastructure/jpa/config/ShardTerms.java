package com.pg.account.sharding.infrastructure.jpa.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author JackSun
 * @date 3/6/17
 */
@javax.persistence.Entity
@Table(name = "SHARD_TERMS")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardTerms implements Serializable {

    private static final long serialVersionUID = 8352362311947071223L;
    @Id
    private Long id;
    @Column(name = "TENANT_ID")
    private Long tenantId;
    @Column(name = "OPT_ID")
    private String optId;
    @Column(name = "TERMS_VERSION")
    private String termsVersion;
    @Column(name = "TERMS_VALUE")
    private String termsValue;
    @Column
    private String description;
    @Column(name = "IS_PRIMARY")
    private String isPrimary;
    @Column(name = "CHANNEL_ID")
    private Long channelId;
    @Column(name = "CREATE_BY")
    private String createBy;
    @Column(name = "CREATE_TIME")
    private Timestamp createTime;
    @Column(name = "MODIFY_BY")
    private String modifyBy;
    @Column(name = "MODIFY_TIME")
    private Timestamp modifyTime;
    @Column
    private Byte status;

}
