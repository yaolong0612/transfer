package com.pg.account.sharding.infrastructure.jpa.profile.extraattribute;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterExtraAttributeListJson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

/**
 * 属性信息类
 *
 * @author Jack
 * @date 2021/5/27 19:44
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_EXTRA_ATTRIBUTE")
@Data
@DynamicUpdate
@DynamicInsert
public class ShardExtraAttribute extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 6643369554524034585L;
    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterExtraAttributeListJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private List<ExtraAttributeItem> extraAttributeItemList;

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.identityId = account.getIdentityId();
        if (Optional.ofNullable(this.getExtraAttributeItems()).filter(extraAttributeItems -> !extraAttributeItems.isEmpty()).isPresent()) {
            account.getUserAdditionalInfo().getExtraAttributeList().forEach(extraAttributeItem -> {
                this.extraAttributeItemList.forEach(a -> {

                });
                Iterator<ExtraAttributeItem> iterator = this.extraAttributeItemList.iterator();
                while (iterator.hasNext()) {
                    ExtraAttributeItem attributeItem = iterator.next();
                    if (attributeItem.getAttrId().equals(extraAttributeItem.getAttrId())) {
                        extraAttributeItem.builder(attributeItem);
                        iterator.remove();
                    }
                }
            });
            this.extraAttributeItemList.addAll(account.getUserAdditionalInfo().getExtraAttributeList());
        } else {
            this.extraAttributeItemList = account.getUserAdditionalInfo().getExtraAttributeList();
        }
        super.addCreateTime();
    }

    public void buildFromAccount(Account account) {
        this.identityId = account.getIdentityId();
        if (Optional.ofNullable(this.extraAttributeItemList).filter(extraAttributeItems -> !extraAttributeItems.isEmpty()).isPresent()) {
            account.getUserAdditionalInfo().getExtraAttributeList().forEach(extraAttributeItem -> this.extraAttributeItemList.forEach(item -> {
                if (item.getAttrId().equals(extraAttributeItem.getAttrId())) {
                    extraAttributeItem.builder(item);
                }
            }));
            this.extraAttributeItemList.removeIf(a -> account.getUserAdditionalInfo().getExtraAttributeList().stream().anyMatch(n -> n.getAttrId().equals(a.getAttrId())));
            this.extraAttributeItemList.addAll(account.getUserAdditionalInfo().getExtraAttributeList());
        } else {
            this.extraAttributeItemList = account.getUserAdditionalInfo().getExtraAttributeList();
        }
        super.addUpdatedTime();
    }

    public List<ExtraAttributeItem> getExtraAttributeItems() {
        return Optional.ofNullable(this.extraAttributeItemList).filter(extraAttributeItems -> !extraAttributeItems.isEmpty()).orElse(null);
    }
}
