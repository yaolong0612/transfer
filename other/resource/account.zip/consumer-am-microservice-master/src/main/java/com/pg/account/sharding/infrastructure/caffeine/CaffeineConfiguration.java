package com.pg.account.sharding.infrastructure.caffeine;


import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Caffeine初始化bean
 *
 * @author leiyingbin
 * @date 2022/03/31
 */
@Configuration
@Data
public class CaffeineConfiguration {

    @Value("${caffeine.maximumSize}")
    private Integer maximumSize;

    @Bean
    public Cache<String, Object> caffeineCache() {
        return Caffeine.newBuilder()
                .maximumSize(maximumSize)
                .build();
    }

}
