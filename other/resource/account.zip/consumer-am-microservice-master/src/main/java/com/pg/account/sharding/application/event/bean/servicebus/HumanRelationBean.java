package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 人际关系信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HumanRelationBean implements Serializable {
    private static final long serialVersionUID = -6968484389859355121L;
    @JSONField(ordinal = 1)
    private String relationType;
    @JSONField(ordinal = 2)
    private String relationSeq;
    @JSONField(ordinal = 3)
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @JSONField(ordinal = 4)
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @JSONField(ordinal = 5)
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @JSONField(ordinal = 6)
    @Desensitized(value = DesensitizedEnum.MOBILE_PHONE)
    private String mobile;
    @JSONField(ordinal = 7)
    private String email;
    @JSONField(ordinal = 8)
    private String guardian;
    @JSONField(ordinal = 9)
    private Timestamp createTime;
    @JSONField(ordinal = 10)
    private Timestamp modifyTime;
}
