package com.pg.account.sharding.domain.model.account;


import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.Data;
import org.apache.commons.lang.Validate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * <Description> <br>
 *
 * @author xusheng
 * @date 2021/6/8 <br>
 */
@Data
@Embeddable
public class IdentityId implements Serializable {

    private static final long serialVersionUID = 2918351944400296891L;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "account_id")
    private String accountId;

    public IdentityId(String tenantId, String accountId) {
        this.tenantId = tenantId;
        this.accountId = accountId;
    }

    public IdentityId() {

    }

    public void specialTenantId(String tenantId) {
        Validate.notNull(tenantId, "tenantId is null");
        this.tenantId = tenantId;
    }

    public void specialAccountId(String accountId) {
        this.accountId = accountId;
    }

    public void specialNewAccountId() {
        Validate.notNull(this.tenantId, "tenantId is null");
        this.accountId = RedisConfigUtils.getMemberIdOfRedis(this.tenantId);
        // TODO: 2021/6/16 redis挂掉 accountId不好生成
    }

    public static final class IdentityIdBuilder {
        private String tenantId;
        private String accountId;

        private IdentityIdBuilder() {
        }

        public static IdentityIdBuilder anIdentityId() {
            return new IdentityIdBuilder();
        }

        public IdentityIdBuilder tenantId(String tenantId) {
            this.tenantId = tenantId;
            return this;
        }

        public IdentityIdBuilder accountId(String accountId) {
            this.accountId = accountId;
            return this;
        }

        public IdentityId build() {
            IdentityId identityId = new IdentityId();
            identityId.setTenantId(tenantId);
            identityId.setAccountId(accountId);
            return identityId;
        }
    }
}
