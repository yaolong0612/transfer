package com.pg.account.sharding.infrastructure.jpa.mapping;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author lfx
 * @date 2021/6/9 13:11
 */
@Data
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class UnionIdMapId implements Serializable {
    private static final long serialVersionUID = -8266490711837833142L;
    @Column(name = "tenant_id")
    private String tenantId;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    @Column(name = "union_id")
    private String unionId;
    private String channel;
}
