package com.pg.account.sharding.infrastructure.client.award;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author JackSun
 */
@ApiModel
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AddPointResponse implements Serializable {

    private static final long serialVersionUID = -406041687879323344L;
    @ApiModelProperty(value = "用户属性ID")
    private String attrId;
    @ApiModelProperty(value = "操作积分")
    private String point;
    @ApiModelProperty(value = "总计积分")
    private String totalPoint;

}
