package com.pg.account.infrastructure.component.datastream.servicebus.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageChangeOptEventBean implements Serializable {

    private static final long serialVersionUID = 8829212647878310144L;
    private int marketingProgramId;
    private List<MessageOptBean> opts;

}
