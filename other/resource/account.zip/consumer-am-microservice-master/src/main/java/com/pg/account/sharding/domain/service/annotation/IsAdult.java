package com.pg.account.sharding.domain.service.annotation;


import com.pg.account.sharding.domain.service.AccountBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 判断是否成年
 *
 * @author lfx
 * @date 2021/4/23 16:15
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AccountBaseValidator.AdultValid.class)
public @interface IsAdult {

    String message() default "user is under the age of 18 and is not an adult";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
