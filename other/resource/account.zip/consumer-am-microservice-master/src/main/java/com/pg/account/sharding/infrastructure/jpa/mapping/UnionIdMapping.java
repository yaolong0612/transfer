package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.Data;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * UnionId映射类
 * 用于将UnionId映射成accountId
 *
 * @author LC
 */
@Data
@DynamicUpdate
@DynamicInsert
@Table
@Entity
public class UnionIdMapping extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 6870058385725440365L;
    private Long id;
    @Column(name = "account_id")
    private String accountId;
    @EmbeddedId
    private UnionIdMapId unionIdMapId;


    public void build(String tenantId, String unionId, String unionIdType, String accountId) {
        Validate.notNull(tenantId, "unionIdMapping tenantId is null");
        Validate.notNull(unionId, "unionIdMapping unionId is null");
        Validate.notNull(unionIdType, "unionIdMapping unionIdType is null");
        Validate.notNull(accountId, "unionIdMapping accountId is null");
        this.unionIdMapId = new UnionIdMapId(tenantId, unionId, unionIdType);
        this.accountId = accountId;
        super.addCreateTime();
    }

    public void build(String tenantId, String unionId, String unionIdType) {
        Validate.notNull(tenantId, "unionIdMapping tenantId is null");
        Validate.notNull(unionId, "unionIdMapping unionId is null");
        Validate.notNull(unionIdType, "unionIdMapping unionIdType is null");
        this.unionIdMapId = new UnionIdMapId(tenantId, unionId, unionIdType);
    }
}
