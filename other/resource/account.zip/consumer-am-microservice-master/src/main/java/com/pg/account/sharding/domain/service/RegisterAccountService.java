package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.constants.AccountConstants;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.*;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.INCORRECT_BABY_BIRTHDAY;

/**
 * @author Jack
 * @date 2021/5/31 13:02
 */
@Slf4j
@Service
public class RegisterAccountService {
    public static final int BABY_BIRTHDAY_LENGTH = 10;
    public static final String BABY_ATTR_ID = "113000001";
    private final AccountRepository accountRepository;

    @Autowired
    public RegisterAccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    /**
     * 注册业务处理
     *
     * @param account account
     * @author xusheng
     * @date 2021/6/3 17:18
     */
    public void register(Account account) {
        this.registerAccountValidate(account);
        account.specialNewAccountId();
        account.specialNewOpenUid();
        account.activeStatus();
    }

    /**
     * 更新校验
     *
     * @param account account
     * @author LFX
     */
    public void registerAccountValidate(Account account) {
        Optional.ofNullable(account.getUserAdditionalInfo()).ifPresent(UserAdditionalInfo::sequenceUniqueValid);
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getExtraAttributeList)
                .filter(attrs -> !attrs.isEmpty())
                .ifPresent(this::babyBirthdayValidate);
    }


    /**
     * 宝宝生日校验
     *
     * @param attributesList 属性集合p
     * @date 2021/6/10 22:21
     */
    private void babyBirthdayValidate(List<ExtraAttributeItem> attributesList) {
        attributesList.forEach(attributes -> {
            if (BABY_ATTR_ID.equals(attributes.getAttrId())) {
                List<BabyInfoBean> babyInfoBeanList = parseArray(attributes.getAttrValue(), BabyInfoBean.class);
                babyInfoBeanList.forEach(this::beanValidator);
                babyInfoBeanList.forEach(babyInfoBean -> {
                    if (!Optional.ofNullable(babyInfoBean.getCreateTime()).isPresent()) {
                        babyInfoBean.setCreateTime(DateFormatUtils.format(new Date(), YYYY_MM_DD_HH_MI_SS_SSS, Locale.CHINA));
                    }
                    String babyBirthday = setBabyBirthday(babyInfoBean.getBirthday());
                    if (StringUtils.isNotBlank(babyBirthday)) {
                        babyInfoBean.setBirthday(babyBirthday);
                    }
                });
                babyBirthdayValidator(babyInfoBeanList);
            }
        });
    }

    /**
     * 宝宝生日参数校验
     *
     * @param babyInfoBean 宝宝信息
     */
    private void beanValidator(BabyInfoBean babyInfoBean) {
        ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
        Validator validator = vf.getValidator();
        Set<ConstraintViolation<BabyInfoBean>> validate = validator.validate(babyInfoBean);
        String error;
        for (ConstraintViolation<BabyInfoBean> cv : validate) {
            error = cv.getMessage();
            if (StringUtils.isNotBlank(error)) {
                throw new BusinessException(INCORRECT_BABY_BIRTHDAY.getCode(), INCORRECT_BABY_BIRTHDAY.getV2Code(), error);
            }
        }
    }

    /**
     * 校验两个宝宝生日时间间隔在一年以上
     * 如果两个宝宝生日一样说明是双胞胎不用校验
     *
     * @param babyInfoBeans 宝宝生日信息
     */
    private void babyBirthdayValidator(List<BabyInfoBean> babyInfoBeans) {
        List<String> birthdayList = new ArrayList<>();
        babyInfoBeans.forEach(info -> birthdayList.add(info.getBirthday()));
        if (birthdayList.size() == 2 && !birthdayList.get(0).equals(birthdayList.get(1))) {
            Date birthdayDate1 = DateUtil.formDate(birthdayList.get(0), AccountConstants.YYYY_MM_DD);
            Date birthdayDate2 = DateUtil.formDate(birthdayList.get(1), AccountConstants.YYYY_MM_DD);
            if (Optional.ofNullable(birthdayDate1).isPresent() && Optional.ofNullable(birthdayDate2).isPresent()) {
                LocalDate localDate1 = birthdayDate1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                LocalDate localDate2 = birthdayDate2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                //判断两个日期间隔的年数
                int year = Period.between(localDate1, localDate2).getYears();
                if (Math.abs(year) < 1) {
                    throw new BusinessException(ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getCode(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getV2Code(), ResultEnum.INCORRECT_MULTIPLE_BABIES_BIRTHDAY.getMessage());
                }
            } else {
                throw new BusinessException(INCORRECT_BABY_BIRTHDAY.getCode(), INCORRECT_BABY_BIRTHDAY.getV2Code(), INCORRECT_BABY_BIRTHDAY.getMessage());
            }
        }
    }

    /**
     * 如果宝宝生日格式是yyyy-MM-dd 则改成yyyy-MM-dd HH:mm:ss
     *
     * @param babyBirthday 宝宝生日
     */
    private String setBabyBirthday(String babyBirthday) {
        if (BABY_BIRTHDAY_LENGTH == babyBirthday.length()) {
            SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD);
            try {
                Date date = sdf.parse(babyBirthday);
                return DateFormatUtils.format(date, YYYY_MM_DD_HH_MI_SS, Locale.CHINA);
            } catch (ParseException e) {
                throw new BusinessException(INCORRECT_BABY_BIRTHDAY.getCode(), INCORRECT_BABY_BIRTHDAY.getV2Code(), INCORRECT_BABY_BIRTHDAY.getMessage());
            }
        }
        return null;
    }
}
