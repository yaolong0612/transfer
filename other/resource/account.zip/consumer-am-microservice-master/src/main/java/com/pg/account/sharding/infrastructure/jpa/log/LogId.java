package com.pg.account.sharding.infrastructure.jpa.log;

import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterLocalDateTime;
import lombok.Data;

import javax.persistence.Convert;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @Author wsq
 * @Description
 * @Date 2021/7/29 21:07
 **/
@Data
@Embeddable
public class LogId implements Serializable {

    @Convert(converter = JpaConverterLocalDateTime.class)
    protected LocalDateTime createdTime;
    private Long id;

    public LogId(Long id, LocalDateTime now) {
        this.id = id;
        this.createdTime = now;
    }

    public LogId() {

    }
}
