package com.pg.account.sharding.infrastructure.jpa.log;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * @author yj
 */
public interface DataStreamDao extends JpaRepository<ShardDataStream, Long> {


    List<ShardDataStream> findByEventLabelAndStatusAndRetryCountBeforeOrderByLogIdCreatedTimeAscLogIdIdAsc(String eventLabel, String status, String retryCount, Pageable pageable);


    List<ShardDataStream> findByAccountIdAndTenantIdAndEventLabelAndStatusAndRetryCountBeforeOrderByLogIdCreatedTimeAscLogIdIdAsc(String accountId, String tenantId, String eventLabel, String status, String retryCount);


    List<ShardDataStream> findTop1000ByTenantIdAndEventLabelAndStatusAndRetryCountBeforeOrderByLogIdCreatedTimeAsc(String tenantId, String eventLabel, String status, String retryCount);

    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id not in ('10001','10002','10003','10004') and status='false' and retry_count < '2' and event_label='oldToShardingEventHub' order by created_time", nativeQuery = true)
    List<ShardDataStream> findListByOther(Pageable pageable);


    /**
     * 查询 Pampers 的消费数据
     *
     * @param pageable 分页
     * @return
     */
    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id = '10003' and status='false' and retry_count < '2' and event_label='oldToShardingEventHub' order by created_time, id", nativeQuery = true)
    List<ShardDataStream> getListByPampers(Pageable pageable);


    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id = '10001' and status='false' and retry_count < '2' and event_label='oldToShardingEventHub' order by created_time, id", nativeQuery = true)
    List<ShardDataStream> getListBySkii(Pageable pageable);

    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id = '10002' and status='false' and retry_count < '2' and event_label='oldToShardingEventHub' order by created_time, id", nativeQuery = true)
    List<ShardDataStream> getListByOlay(Pageable pageable);

    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id = '10004' and status='false' and retry_count < '2' and event_label='oldToShardingEventHub' order by created_time, id", nativeQuery = true)
    List<ShardDataStream> getListByLA(Pageable pageable);

    @Query(value = "select * from SHARD_DATA_STREAM where tenant_id not in ('10001','10002','10003','10004') and status='false' and retry_count < 2 and event_label='oldToShardingEventHub' order by created_time, id", nativeQuery = true)
    List<ShardDataStream> getListByOthers(Pageable pageable);


}
