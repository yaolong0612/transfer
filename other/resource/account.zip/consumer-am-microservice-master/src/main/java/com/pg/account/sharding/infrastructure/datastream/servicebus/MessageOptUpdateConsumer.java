package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.component.datastream.servicebus.bean.MessageChangeOptEventBean;
import com.pg.account.infrastructure.component.datastream.servicebus.bean.MessageOptBean;
import com.pg.account.sharding.application.event.SmsUpdateSubscriptionEvent;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.OptionDictionaryDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardOptionDictionary;
import com.pg.account.sharding.infrastructure.jpa.config.ShardTerms;
import com.pg.account.sharding.infrastructure.jpa.config.TermsDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMappingDao;
import com.pg.account.sharding.infrastructure.servicebus.SmsAbstractConsumer;
import com.pg.account.sharding.infrastructure.servicebus.SmsServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.switchconfig.SwitchConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author mrluve
 */
@Slf4j
@Service
public class MessageOptUpdateConsumer extends SmsAbstractConsumer {


    private final MobileMappingDao mobileMappingDao;
    private final SubscriptionRepository subscriptionRepository;
    private final OptionDictionaryDao optionDictionaryDao;
    private final TermsDao termsDao;
    private final SwitchConfiguration switchConfiguration;

    @Autowired
    public MessageOptUpdateConsumer(
            MobileMappingDao mobileMappingDao,
            SubscriptionRepository subscriptionRepository,
            OptionDictionaryDao optionDictionaryDao,
            TermsDao termsDao,
            SwitchConfiguration switchConfiguration) {
        this.mobileMappingDao = mobileMappingDao;
        this.subscriptionRepository = subscriptionRepository;
        this.optionDictionaryDao = optionDictionaryDao;
        this.termsDao = termsDao;
        this.switchConfiguration = switchConfiguration;
    }

    /**
     * 执行更新
     *
     * @param tenantId       租户Id
     * @param messageOptBean we订阅
     */
    private void run(String tenantId, MessageOptBean messageOptBean) {
        saveShardingSubscriptions(tenantId, messageOptBean, true);
    }

    /**
     * 根据租户和短信消息来更新订阅状态
     *
     * @param tenantId       tenantId
     * @param messageOptBean messageOptBean
     * @param flag           flag
     * @author xusheng
     * @date 2021/8/19 9:55
     */
    private void saveShardingSubscriptions(String tenantId, MessageOptBean messageOptBean, boolean flag) {
        MobileMapping mobileMapping = mobileMappingDao.findByMobileMapId_TenantIdAndMobileMapId_Mobile(tenantId, messageOptBean.getMobile());
        if (null != mobileMapping) {
            List<ShardOptionDictionary> shardOptionDictionaries = optionDictionaryDao.findByTenantIdAndEnumType(tenantId, "SMS");
            //判断SMS在订阅词典中是否存在，不存在则抛出异常
            String optId = Optional.ofNullable(shardOptionDictionaries)
                    .filter(shardOptionDictionaries1 -> !shardOptionDictionaries1.isEmpty())
                    .flatMap(shardOptionDictionaries1 -> shardOptionDictionaries1.stream()
                            .findFirst()
                            .map(ShardOptionDictionary::getOptId))
                    .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
            ShardSubscription shardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, mobileMapping.getAccountId());
            Optional.ofNullable(shardSubscription.getSubscriptionList())
                    .filter(subscriptionItems -> !subscriptionItems.isEmpty())
                    .ifPresent(subscriptionItems -> subscriptionItems.forEach(subscriptionItem -> {
                        getTermsVersion(subscriptionItem);
                        if (optId.equals(subscriptionItem.getOptId())) {
                            subscriptionItem.setOptStatus(messageOptBean.getOptStatus());
                            subscriptionItem.changeUpdatedTime();
                        }
                    }));
            subscriptionRepository.save(shardSubscription);
            if (flag) {
                SmsUpdateSubscriptionEvent smsUpdateSubscriptionEvent = new SmsUpdateSubscriptionEvent(this, shardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(smsUpdateSubscriptionEvent);
            }
        }
    }

    /**
     * 判断订阅版本号是否丢失，如果丢失则补全版本号
     *
     * @param subscriptionItem 订阅信息
     * @author xusheng
     * @date 2021/10/11 16:12
     */
    private void getTermsVersion(SubscriptionItem subscriptionItem) {
        Optional.ofNullable(subscriptionItem.getTermsList()).filter(terms -> !terms.isEmpty())
                .ifPresent(terms -> terms.forEach(term -> {
                    // TODO: 2021/10/13 如果termsId为空，则将最新的一条版本附上
                    //termsId能为空，为空则查不出缓存中的订阅关系
                    if (StringUtils.isBlank(term.getTermVersion()) && StringUtils.isNotBlank(term.getTermId())) {
                        Optional<ShardTerms> shardTerms = termsDao.findById(Long.valueOf(term.getTermId()));
                        //获取optId最新的订阅版本
                        shardTerms.ifPresent(shardTerms1 -> term.setTermVersion(shardTerms1.getTermsVersion()));
                    }
                }));
    }


    @Override
    protected void doBusiness(JSON json) {
        JSONObject bodyContent = (JSONObject) json;
        log.info("Message consume start...,and body is:{}", bodyContent);
        MessageChangeOptEventBean messageChangeOptEventBean = bodyContent.toJavaObject(MessageChangeOptEventBean.class);
        String tenantId = LocalCacheConfigUtils.getTenantIdByMarketingProgramId(messageChangeOptEventBean.getMarketingProgramId());
        if (StringUtils.isNotBlank(tenantId)) {
            for (MessageOptBean messageOptBean : messageChangeOptEventBean.getOpts()) {
                this.run(tenantId, messageOptBean);
            }
        } else {
            log.warn("SMS OPT Status update.TenantId is Blank");
        }
    }

    @Override
    protected String getLabel() {
        return SmsServiceBusQueueTopicEnum.S_SMS_SUBSCRIBE_AM.queueOrTopicName();
    }

    @Override
    protected SmsServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return SmsServiceBusQueueTopicEnum.S_SMS_SUBSCRIBE_AM;
    }
}
