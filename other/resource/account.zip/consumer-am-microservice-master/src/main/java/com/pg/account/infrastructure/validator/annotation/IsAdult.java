package com.pg.account.infrastructure.validator.annotation;


import com.pg.account.sharding.domain.service.AccountBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 判断是否成年
 *
 * @author lfx
 * @date 2021/4/23 16:15
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AccountBaseValidator.AdultValid.class)
public @interface IsAdult {

    String message() default "用户年龄未满18岁，不是成人";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
