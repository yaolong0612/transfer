//package com.pg.account.interfaces.facade.v1.assembler;
//
//import com.pg.account.domain.model.account.Account;
//import com.pg.account.domain.model.account.AccountInfo;
//import com.pg.account.domain.model.counter.Counter;
//import com.pg.account.domain.model.profile.Attributes;
//import com.pg.account.domain.model.profile.Devices;
//import com.pg.account.domain.model.profile.Profile;
//import com.pg.account.domain.model.socialaccount.SocialAccount;
//import com.pg.account.domain.model.socialaccount.SocialAccountUnionId;
//import com.pg.account.infrastructure.component.client.address.Address;
//import com.pg.account.interfaces.command.CounterCommand;
//import com.pg.account.interfaces.command.DeviceCommand;
//import com.pg.account.interfaces.command.oralbCommand.*;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.stereotype.Component;
//
//import java.sql.Timestamp;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
///**
// * @author YJ
// * @date 2021/9/1
// */
//@Component
//public class OralbMigrateDtoAssembler {
//    public Account fromDto(MigrateRegisterBindCommand migrateRegisterBindCommand) {
//        AccountInfo accountInfo = this.fromAccountInfoDto(migrateRegisterBindCommand);
//        Profile profile = this.fromProfileDTO(migrateRegisterBindCommand);
//        Counter counter = this.fromCounterDTO(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getCounter());
//        Devices devices = this.fromDeviceDTO(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getDevice());
//        List<Address> addressList = this.fromAddressDTO(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getAddresses());
//        List<Attributes> attributesList = this.fromAttributeDTOList(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getAttrs());
//        List<Subscriptions> subscriptionsList = this.fromSubscriptionList(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getSubscriptions());
//        List<SocialAccount> socialAccountList = this.fromSocialAccountDTO(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getBinds());
//        List<SocialAccountUnionId> socialAccountUnionIdList = this.fromSocialAccountUnionIdDTO(migrateRegisterBindCommand.getTenantId(), migrateRegisterBindCommand.getUnionId(), migrateRegisterBindCommand.getUnionIdBindTime(), migrateRegisterBindCommand.getUnionIdType());
//        return new Account(migrateRegisterBindCommand.getTenantId(),
//                accountInfo.getChannelId(),
//                null,
//                null,
//                accountInfo,
//                counter,
//                devices,
//                profile,
//                addressList,
//                attributesList,
//                subscriptionsList,
//                socialAccountList,
//                socialAccountUnionIdList,
//                null,
//                null,
//                null
//        );
//    }
//
//    /**
//     * SocialAccountUnionIdDTO转换为SocialAccountUnionId
//     *
//     * @param tenantId
//     * @param unionId
//     * @param unionIdBindTime
//     * @param
//     * @return
//     */
//    private List<SocialAccountUnionId> fromSocialAccountUnionIdDTO(long tenantId, String unionId, Timestamp unionIdBindTime, String unionIdType) {
//        List<SocialAccountUnionId> socialAccountUnionIdList = null;
//        if (Optional.ofNullable(unionId).isPresent()) {
//            if (StringUtils.isNotBlank(unionId)) {
//                socialAccountUnionIdList = new ArrayList<>();
//                SocialAccountUnionId socialAccountUnionId = new SocialAccountUnionId();
//                socialAccountUnionId.setTenantId(tenantId);
//                socialAccountUnionId.setUsersId(null);
//                socialAccountUnionId.setUnionId(unionId);
//                socialAccountUnionId.setBindTime(unionIdBindTime);
//                socialAccountUnionId.setUnionIdType(unionIdType);
//                socialAccountUnionIdList.add(socialAccountUnionId);
//            }
//        }
//        return socialAccountUnionIdList;
//    }
//
//    /**
//     * SocialAccountDTO转换成SocialAccount
//     *
//     * @param tenantId
//     * @param bindCommandList
//     * @return
//     */
//    private List<SocialAccount> fromSocialAccountDTO(long tenantId, List<OralbBindCommand> bindCommandList) {
//        List<SocialAccount> socialAccountList = null;
//        if (Optional.ofNullable(bindCommandList).filter(bindCommands -> !bindCommands.isEmpty()).isPresent()) {
//            socialAccountList = new ArrayList<>();
//            for (OralbBindCommand bindCommand : bindCommandList) {
//                if (!StringUtils.isBlank(bindCommand.getBindId())) {
//                    SocialAccount socialAccount = new SocialAccount();
//                    socialAccount.setTenantId(tenantId);
//                    socialAccount.setChannelId(bindCommand.getChannelId());
//                    socialAccount.setUsersId(null);
//                    socialAccount.setBindId(bindCommand.getBindId());
//                    socialAccount.setBindTime(bindCommand.getBindTime());
//                    socialAccount.setAttentionStatus(bindCommand.getAttentionStatus());
//                    socialAccountList.add(socialAccount);
//                }
//            }
//        }
//        if (Optional.ofNullable(socialAccountList).filter(socialAccounts -> !socialAccounts.isEmpty()).isPresent()) {
//            return socialAccountList;
//        }
//        return null;
//    }
//
//    /**
//     * SubscriptiosDTO转换成Subscriptions
//     *
//     * @param tenantId
//     * @param subscriptionCommandList
//     * @return
//     */
//    private List<Subscriptions> fromSubscriptionList(long tenantId, List<OralbSubscriptionCommand> subscriptionCommandList) {
//        List<Subscriptions> subscriptionsList = null;
//        if (Optional.ofNullable(subscriptionCommandList).filter(subscriptionCommands -> !subscriptionCommands.isEmpty()).isPresent()) {
//            subscriptionsList = new ArrayList<>();
//            for (OralbSubscriptionCommand subscriptionCommand : subscriptionCommandList) {
//                if (!StringUtils.isBlank(subscriptionCommand.getOptStatus())) {
//                    Subscriptions subscriptions = new Subscriptions(tenantId, subscriptionCommand.getOptId(), subscriptionCommand.getOptStatus());
//                    subscriptionsList.add(subscriptions);
//                }
//            }
//        }
//        if (Optional.ofNullable(subscriptionsList).filter(subscriptions -> !subscriptions.isEmpty()).isPresent()) {
//            return subscriptionsList;
//        }
//        return null;
//    }
//
//    /**
//     * AttributesDTO转换成Attributes
//     *
//     * @param tenantId
//     * @param attrCommandList
//     * @return
//     */
//    private List<Attributes> fromAttributeDTOList(long tenantId, List<OralbAttrCommand> attrCommandList) {
//        List<Attributes> attributesList = null;
//        if (Optional.ofNullable(attrCommandList).filter(attrCommands -> !attrCommands.isEmpty()).isPresent()) {
//            attributesList = new ArrayList<>();
//            for (OralbAttrCommand attrCommand : attrCommandList) {
//                if (!StringUtils.isBlank(attrCommand.getAttrId())) {
//                    Attributes attributes = new Attributes();
//                    attributes.setUsersId(null);
//                    attributes.setTenantId(tenantId);
//                    attributes.setAttrId(attrCommand.getAttrId());
//                    attributes.setAttrValue(attrCommand.getAttrVal());
//                    attributesList.add(attributes);
//                }
//            }
//        }
//        if (Optional.ofNullable(attributesList).filter(attributes -> !attributes.isEmpty()).isPresent()) {
//            return attributesList;
//        }
//        return null;
//    }
//
//    /**
//     * AddressDTO转换成Address
//     *
//     * @param tenantId
//     * @param addressCommand
//     * @return
//     */
//    private List<Address> fromAddressDTO(long tenantId, OralbAddressCommand addressCommand) {
//        List<Address> addressList = null;
//        boolean flag = false;
//        if (Optional.ofNullable(addressCommand).isPresent()) {
//            addressList = new ArrayList<>();
//            Address address = new Address();
//            address.setTenantId(tenantId);
//            if (StringUtils.isNotBlank(addressCommand.getAddressCode())) {
//                address.setAddressCode(addressCommand.getAddressCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getFullName())) {
//                address.setFullName(addressCommand.getFullName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getCellphone())) {
//                address.setCellphone(addressCommand.getCellphone());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getPhone())) {
//                address.setPhone(addressCommand.getPhone());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getProvince())) {
//                address.setProvince(addressCommand.getProvince());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getCity())) {
//                address.setCity(addressCommand.getCity());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getDistrict())) {
//                address.setDistrict(addressCommand.getDistrict());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getAddress())) {
//                address.setAddress(addressCommand.getAddress());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(addressCommand.getPostcode())) {
//                address.setPostcode(addressCommand.getPostcode());
//                flag = true;
//            }
//            addressList.add(address);
//        }
//        if (flag) {
//            return addressList;
//        }
//        return null;
//    }
//
//    /**
//     * DevicesDTO转换成Device
//     *
//     * @param tenantId
//     * @param deviceCommand
//     * @return
//     */
//    private Devices fromDeviceDTO(long tenantId, DeviceCommand deviceCommand) {
//        Devices devices = null;
//        boolean flag = false;
//        if (Optional.ofNullable(deviceCommand).isPresent()) {
//            devices = new Devices();
//            devices.setTenantId(tenantId);
//            if (StringUtils.isNotBlank(deviceCommand.getOs())) {
//                devices.setOs(deviceCommand.getOs());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getAppv())) {
//                devices.setAppv(deviceCommand.getAppv());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getPackageName())) {
//                devices.setPackageName(deviceCommand.getPackageName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getIdfa())) {
//                devices.setIdfa(deviceCommand.getIdfa());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getImei())) {
//                devices.setImei(deviceCommand.getImei());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getOaid())) {
//                devices.setOaid(deviceCommand.getOaid());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getMac())) {
//                devices.setMac(deviceCommand.getMac());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getOpenudid())) {
//                devices.setOpenudid(deviceCommand.getOpenudid());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getAndroidid())) {
//                devices.setAndroidid(deviceCommand.getAndroidid());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getModel())) {
//                devices.setModel(deviceCommand.getModel());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getBrand())) {
//                devices.setBrand(deviceCommand.getBrand());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(deviceCommand.getAdTracked())) {
//                devices.setAdTracked(deviceCommand.getAdTracked());
//                flag = true;
//            }
//        }
//        if (flag) {
//            return devices;
//        }
//        return null;
//    }
//
//    /**
//     * CounterDTo转换为Counter
//     *
//     * @param tenantId
//     * @param counterCommand
//     * @return
//     */
//    private Counter fromCounterDTO(long tenantId, CounterCommand counterCommand) {
//        Counter counter = null;
//        boolean flag = false;
//        if (Optional.ofNullable(counterCommand).isPresent()) {
//            counter = new Counter();
//            counter.setTenantId(tenantId);
//            if (StringUtils.isNotBlank(counterCommand.getRegCounterCode())) {
//                counter.setRegCounterCode(counterCommand.getRegCounterCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getRegCounterName())) {
//                counter.setRegCounterName(counterCommand.getRegCounterName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getMainCounterCode())) {
//                counter.setMainCounterCode(counterCommand.getMainCounterCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getMainCounterName())) {
//                counter.setMainCounterName(counterCommand.getMainCounterName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getPickupCounterCode())) {
//                counter.setPickupCounterCode(counterCommand.getPickupCounterCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getPickupCounterName())) {
//                counter.setPickupCounterName(counterCommand.getPickupCounterName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getOfflineFirstPurchaseCounterCode())) {
//                counter.setOfflineFirstPurchaseCounterCode(counterCommand.getOfflineFirstPurchaseCounterCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getOfflineFirstPurchaseCounterName())) {
//                counter.setOfflineFirstPurchaseCounterName(counterCommand.getOfflineFirstPurchaseCounterName());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getFirstPurchaseCounterCode())) {
//                counter.setFirstPurchaseCounterCode(counterCommand.getFirstPurchaseCounterCode());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getFirstPurchaseTime())) {
//                counter.setFirstPurchaseTime(counterCommand.getFirstPurchaseTime());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(counterCommand.getCrmPickupCounterCode())) {
//                counter.setCrmPickupCounterCode(counterCommand.getCrmPickupCounterCode());
//                flag = true;
//            }
//        }
//        if (flag) {
//            return counter;
//        }
//        return null;
//    }
//
//    /**
//     * ProfileDTO转换为Profile
//     *
//     * @param migrateRegisterBindCommand ProfileDTO
//     * @return Profile
//     */
//    private Profile fromProfileDTO(MigrateRegisterBindCommand migrateRegisterBindCommand) {
//        Profile profile = null;
//        boolean flag = false;
//        Optional<OralbProfileCommand> optionalProfileCommand = Optional.ofNullable(migrateRegisterBindCommand.getProfile());
//        if (optionalProfileCommand.isPresent()) {
//            profile = new Profile();
//            profile.setTenantId(migrateRegisterBindCommand.getTenantId());
//            if (StringUtils.isNotBlank(optionalProfileCommand.get().getEmail())) {
//                profile.setEmail(optionalProfileCommand.get().getEmail());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(migrateRegisterBindCommand.getUsername())) {
//                profile.setCellphone(migrateRegisterBindCommand.getUsername());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(optionalProfileCommand.get().getNickname())) {
//                profile.setNickname(optionalProfileCommand.get().getNickname());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(optionalProfileCommand.get().getGender())) {
//                profile.setGender(optionalProfileCommand.get().getGender());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(optionalProfileCommand.get().getBirthday())) {
//                profile.setBirthday(optionalProfileCommand.get().getBirthday());
//                flag = true;
//            }
//            if (StringUtils.isNotBlank(optionalProfileCommand.get().getField3())) {
//                profile.setField3(optionalProfileCommand.get().getField3());
//                flag = true;
//            }
//        }
//        if (flag) {
//            return profile;
//        }
//        return null;
//    }
//
//    /**
//     * 将accountDTO转换成accountInfo
//     *
//     * @param migrateRegisterBindCommand accountDTO
//     * @return accountInfo
//     */
//    private AccountInfo fromAccountInfoDto(MigrateRegisterBindCommand migrateRegisterBindCommand) {
//        AccountInfo accountInfo = new AccountInfo();
//        accountInfo.setTenantId(migrateRegisterBindCommand.getTenantId());
//        accountInfo.setChannelId(migrateRegisterBindCommand.getChannelId());
//        accountInfo.setLogonPassword(migrateRegisterBindCommand.getPassword());
//        accountInfo.setSalt(migrateRegisterBindCommand.getSalt());
//        accountInfo.setRegistrationSource(migrateRegisterBindCommand.getSource());
//        if (StringUtils.isNotBlank(migrateRegisterBindCommand.getRegStore())) {
//            accountInfo.setRegStore(migrateRegisterBindCommand.getRegStore());
//        }
//        accountInfo.setRegistrationDate(migrateRegisterBindCommand.getRegDate());
//        if (StringUtils.isNotBlank(migrateRegisterBindCommand.getCustomer())) {
//            accountInfo.setCustomer(migrateRegisterBindCommand.getCustomer());
//        }
//        return accountInfo;
//    }
//}
