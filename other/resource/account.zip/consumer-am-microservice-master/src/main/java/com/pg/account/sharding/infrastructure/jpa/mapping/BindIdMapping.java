package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.Data;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * bindId映射类
 * 用于bindId映射成accountId
 *
 * @author LC
 */
@Table
@Data
@DynamicUpdate
@DynamicInsert
@Entity
public class BindIdMapping extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7326515439519437694L;
    private Long id;
    @Column(name = "account_id")
    private String accountId;
    @EmbeddedId
    private BindIdMapId bindIdMapId;

    public void build(IdentityId identityId, String bindId, String channelId) {
        Validate.notNull(identityId, "identityId is null");
        Validate.notNull(bindId, "bindId is null");
        Validate.notNull(channelId, "channelId is null");
        this.bindIdMapId = new BindIdMapId(identityId.getTenantId(), bindId, channelId);
        this.accountId = identityId.getAccountId();
        super.addCreateTime();
    }
}
