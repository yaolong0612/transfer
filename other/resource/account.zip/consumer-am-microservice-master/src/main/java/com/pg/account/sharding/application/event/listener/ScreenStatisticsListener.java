package com.pg.account.sharding.application.event.listener;

import cn.com.pg.paas.monitor.infrastructure.StreamingUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.application.event.BindingEvent;
import com.pg.account.sharding.application.event.RegisterBindEvent;
import com.pg.account.sharding.application.event.RegisterEvent;
import com.pg.account.sharding.application.event.SignUpEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Customer;
import com.pg.account.sharding.domain.model.account.Registration;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Optional;

/**
 * @author YJ
 * @date 2021/10/18
 */
@Component
@Slf4j
public class ScreenStatisticsListener {
    public static final String REGISTER = "register";
    public static final String BINDING = "binding";
    public static final String SDK = "sdk";
    public static final String KPI_TYPE = "kpiType";
    public static final String MONITOR_TYPE = "monitorType";
    public static final String TENANT_ID = "tenantId";
    public static final String CHANNEL_ID = "channelId";
    public static final String TOTAL_BINDING = "totalBinding";
    public static final String BINDING_COUNT_BY_TENANT_ID = "bindingCountByTenantId";
    public static final String BINDING_COUNT_BY_TENANT_ID_AND_CHANNEL_ID = "bindingCountByTenantIdAndChannelId";
    public static final String TOTAL_ACCOUNT = "totalAccount";
    public static final String BY_TENANT_ACCOUNT = "byTenantAccount";
    public static final String BY_TENANT_AND_CHANNEL_ACCOUNT = "byTenantAndChannelAccount";
    public static final String SEND_TIME = "sendTime";
    public static final String SOURCE = "source";
    public static final String REG_STORE = "regStore";
    private final StreamingUtil streamingUtil;
    private final RedisConfigUtils redisConfigUtils;

    @Autowired
    public ScreenStatisticsListener(StreamingUtil streamingUtil,
                                    RedisConfigUtils redisConfigUtils) {
        this.streamingUtil = streamingUtil;
        this.redisConfigUtils = redisConfigUtils;
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.sendKpiRegisterEvent(event.getAccount());
        }
    }
    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SignUpEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.sendKpiRegisterEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(BindingEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.sendKpiBindEvent(event.getAccount(), event.getShardSocialAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterBindEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.sendKpiRegisterEvent(event.getAccount());
            this.sendKpiBindEvent(event.getAccount(), event.getShardSocialAccount());
        }
    }


    /**
     * 发送绑定时间kpi
     *
     * @param account
     * @param shardSocialAccount
     */
    private void sendKpiBindEvent(Account account, ShardSocialAccount shardSocialAccount) {
        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
            return;
        }
        String kpiType = BINDING;
        String monitorType = SDK;
        SocialAccountItem socialAccountItem = Optional.ofNullable(shardSocialAccount
                .getSocialAccountList())
                .flatMap(social -> social.stream().findFirst())
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
        String channelId = "";
        if (Optional.ofNullable(socialAccountItem).isPresent()) {
            channelId = socialAccountItem.getChannelId();
        }
        //获取所有会员数
        Long totalBinding = redisConfigUtils.totalBinding();
        Long bindingCountByTenantIdAndChannelId = redisConfigUtils.BindingCountByTenantIdAndChannelId(account.getTenantId(), channelId);
        Long bindingCountByTenantId = redisConfigUtils.BindingCountByTenantId(account.getTenantId());

        HashMap<String, Object> object = new HashMap<>(8);
        object.put(KPI_TYPE, kpiType);
        object.put(MONITOR_TYPE, monitorType);
        object.put(TENANT_ID, account.getTenantId());
        object.put(CHANNEL_ID, channelId);
        object.put(TOTAL_BINDING, totalBinding);
        object.put(BINDING_COUNT_BY_TENANT_ID, bindingCountByTenantId);
        object.put(BINDING_COUNT_BY_TENANT_ID_AND_CHANNEL_ID, bindingCountByTenantIdAndChannelId);
        object.put(SEND_TIME, LocalDateTime.now());
        streamingUtil.sendKpiEventhub(object);
    }

    /**
     * 发送注册事件
     *
     * @param account
     */
    private void sendKpiRegisterEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        String tenantId = account.getTenantId();
        String channelId = account.getRegisterChannelId();
        String source = Optional.ofNullable(account.getRegistration()).map(Registration::getSource).orElse(null);
        String regStore = Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getRegStore).orElse(null);
        String kpiType = REGISTER;
        String monitorType = SDK;
        //获取所有会员数
        Long totalAccount = redisConfigUtils.totalAccountNumber();
        //获取分租户会员总数
        Long byTenantAccount = redisConfigUtils.byTenantAccount(account.getTenantId());
        //分租户分渠道会员数写入缓存
        Long byTenantAndChannelAccount = redisConfigUtils.byTenantAndChannelAccount(account.getTenantId(), account.getRegisterChannelId());
        HashMap<String, Object> object = new HashMap<>(10);
        object.put(KPI_TYPE, kpiType);
        object.put(MONITOR_TYPE, monitorType);
        object.put(TENANT_ID, tenantId);
        object.put(CHANNEL_ID, channelId);
        object.put(SOURCE, source);
        object.put(REG_STORE, regStore);
        object.put(TOTAL_ACCOUNT, totalAccount);
        object.put(BY_TENANT_ACCOUNT, byTenantAccount);
        object.put(BY_TENANT_AND_CHANNEL_ACCOUNT, byTenantAndChannelAccount);
        object.put(SEND_TIME, LocalDateTime.now());
        streamingUtil.sendKpiEventhub(object);
    }


}
