package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * 人际关系信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterpersonalRelationshipCommand implements Serializable {
    private static final long serialVersionUID = -8271078268406737578L;
    @ApiModelProperty(value = "relationship 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationship", example = "101或自己")
    @NotBlank(message = "relationship cannot be empty")
    private String relationship;
    @ApiModelProperty(value = "relationshipSequence Sequence limit, the default is 1. Others such as relationshipId: (108: son, 109: daughter, 110: grandson, 111: granddaughter,etc) limit to 2 births, you can fill in 2, up to 5", name = "relationshipSequence", example = "2")
    @NotBlank(message = "relationshipSequence cannot be empty")
    @Pattern(regexp = POSITIVE_PATTERN, message = "relationshipSequence must be a positive integer")
    private String relationshipSequence;
    @ApiModelProperty(value = "fullName", name = "fullName", example = "孙悟空")
    @Pattern(regexp = FULL_NAME_VALID_PATTERN, message = "names are only allowed in Chinese and English or with spaces in between")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "birthday format: yyyy-mm-dd", name = "birthday", example = "1000-01-01")
    @Pattern(regexp = BIRTHDAY_VALID_PATTERN, message = "birthday format error")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @ApiModelProperty(value = "gender, male: M, female: F, unknown: U", name = "gender", example = "M")
    @Pattern(regexp = GENDER_PATTERN, message = "gender format error")
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @ApiModelProperty(value = "cellphone", name = "cellphone", example = "18800000000")
    @NotBlank(message = "cellphone cannot be empty")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "guardian yes: Y, no: N", name = "guardian", example = "Y")
    @Pattern(regexp = Y_N_PATTERN, message = "guardian only can be Y or N")
    private String guardian;
}
