//package com.pg.account.infrastructure.component.datastream.servicebus;
//
//import cn.com.pg.paas.stream.framework.annotation.EventHandler;
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.microsoft.azure.spring.integration.core.AzureHeaders;
//import com.microsoft.azure.spring.integration.core.api.Checkpointer;
//import com.pg.account.application.event.DMPUpdateSubscriptionEvent;
//import com.pg.account.domain.model.account.Account;
//import com.pg.account.domain.model.account.AccountInfo;
//import com.pg.account.domain.model.config.OptionDictionary;
//import com.pg.account.domain.model.profile.Profile;
//import com.pg.account.domain.model.subscription.Subscriptions;
//import com.pg.account.domain.service.SubscriptionService;
//import com.pg.account.infrastructure.common.context.SpringContextUtil;
//import com.pg.account.infrastructure.component.datastream.channel.ServiceBusChannelConfig;
//import com.pg.account.infrastructure.component.datastream.servicebus.bean.MessageChangeOptEventBean;
//import com.pg.account.infrastructure.component.datastream.servicebus.bean.MessageOptBean;
//
//import com.pg.account.infrastructure.repositories.AccountInfoRepository;
//import com.pg.account.infrastructure.repositories.OptionDictionaryRepository;
//import com.pg.account.infrastructure.repositories.ProfileRepository;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.stream.annotation.EnableBinding;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.handler.annotation.Header;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//import static com.pg.account.infrastructure.component.datastream.servicebus.ServiceBusConstants.MESSAGE_OPT_UPDATE_TOPIC_INPUT_CHANNEL;
//import static java.lang.Long.parseLong;
//import static java.nio.charset.StandardCharsets.UTF_8;
//
///**
// * @author Jack Sun
// * @date 2020-5-28 14:32
// */
//@Slf4j
//@Service
//@EnableBinding({ServiceBusChannelConfig.class})
//public class MessageOptUpdateServiceBusConsumerService {
//
//    private final AccountInfoRepository accountInfoRepository;
//    private final ProfileRepository profileRepository;
//    private final SubscriptionService subscriptionService;
//    private final OptionDictionaryRepository optionDictionaryRepository;
//
//    @Autowired
//    public MessageOptUpdateServiceBusConsumerService(ProfileRepository profileRepository, SubscriptionService subscriptionService, OptionDictionaryRepository optionDictionaryRepository, AccountInfoRepository accountInfoRepository) {
//        this.profileRepository = profileRepository;
//        this.subscriptionService = subscriptionService;
//        this.optionDictionaryRepository = optionDictionaryRepository;
//        this.accountInfoRepository = accountInfoRepository;
//    }
//
//    /**
//     * channel:对应声明的通道名称
//     * eventTypeId: 接收来自发送端的eventTypeId，通过配置文件读取
//     *
//     * @param message      消息
//     * @param checkpointer 检查点
//     */
//    @EventHandler(channel = MESSAGE_OPT_UPDATE_TOPIC_INPUT_CHANNEL)
//    public void topicConsumerMessage(Message<Object> message, @Header(AzureHeaders.CHECKPOINTER) Checkpointer checkpointer) {
//        try {
//            // 业务处理
//            JSONObject bodyContent;
//            if (message.getPayload() instanceof byte[]) {
//                bodyContent = JSON.parseObject(new String((byte[]) message.getPayload(), UTF_8));
//            } else {
//                bodyContent = JSON.parseObject(message.getPayload().toString());
//            }
//            log.info("Message Body:" + bodyContent.toJSONString());
//            MessageChangeOptEventBean messageChangeOptEventBean = bodyContent.toJavaObject(MessageChangeOptEventBean.class);
//            String tenantId = ConfigRedisUtils.getTenantIdByMarketingProgramId(messageChangeOptEventBean.getMarketingProgramId());
//            if (StringUtils.isNotBlank(tenantId)) {
//                for (MessageOptBean messageOptBean : messageChangeOptEventBean.getOpts()) {
//                    this.run(tenantId, messageOptBean);
//                    checkpointer.success();
//                }
//            } else {
//                log.warn("SMS OPT Status update.TenantId is Blank");
//            }
//        } catch (Exception e) {
//            log.error("不确认消息，重新入队，交给其他实例处理,处理时出现异常:", e);
//            checkpointer.failure();
//        }
//    }
//
//    /**
//     * 执行更新
//     *
//     * @param tenantId       租户Id
//     * @param messageOptBean we订阅
//     */
//    private void run(String tenantId, MessageOptBean messageOptBean) {
//        Profile profile = this.profileRepository.findProfilesByTenantIdAndCellphone(parseLong(tenantId), messageOptBean.getMobile()).get(0);
//        if (null != profile) {
//            OptionDictionary optionDictionary = optionDictionaryRepository.findOptionDictionariesByTenantIdAndEnumType(parseLong(tenantId), "SMS").get(0);
//            List<Subscriptions> subscriptionsList = subscriptionService.fetchSubscriptionsByOptId(parseLong(tenantId), profile.getUsersId(), optionDictionary.getOptId());
//            for (Subscriptions subscriptions : subscriptionsList) {
//                subscriptions.setOptStatus(messageOptBean.getOptStatus());
//                subscriptions.changeUpdatedTime();
//                subscriptionService.save(subscriptions);
//            }
//            AccountInfo accountInfo = this.accountInfoRepository.findByTenantIdAndUsersId(profile.getTenantId(), profile.getUsersId());
//            Account account = new Account(profile.getTenantId(), accountInfo.getOpenId(), profile.getUsersId(), subscriptionsList);
//            DMPUpdateSubscriptionEvent dmpUpdateSubscriptionEvent = new DMPUpdateSubscriptionEvent(this, account);
//            SpringContextUtil.getApplicationContext().publishEvent(dmpUpdateSubscriptionEvent);
//        }
//    }
//}
