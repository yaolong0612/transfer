package com.pg.account.infrastructure.common.enums;

import com.pg.account.infrastructure.common.exception.BusinessException;
import lombok.Getter;

import java.util.Arrays;

import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.PARAMETER_PARSING_ERROR;

/**
 * 解绑类型
 *
 * @author xusheng
 * @date 2021/7/5 9:50
 */
@Getter
public enum UnBindRouteEnum {
    MEMBER_ID("1", "memberId"),
    BIND_ID_AND_CHANNEL_ID("2", "bindIdAndChannelId"),
    UNION_ID_AND_CHANNEL_ID("3", "unionIdAndChannelId"),
    MEMBER_ID_AND_CHANNEL_ID("4", "memberIdAndChannelId");

    private final String key;
    private final String value;

    UnBindRouteEnum(String key, String value) {
        this.key = key;
        this.value = value;
    }

    public static UnBindRouteEnum getByKeyOrValue(String value) {
        return Arrays.stream(UnBindRouteEnum.values())
                .filter(msg -> msg.getValue().equalsIgnoreCase(value) || msg.getKey().equalsIgnoreCase(value))
                .findAny()
                .orElseThrow(() -> new BusinessException(PARAMETER_PARSING_ERROR.getCode(), PARAMETER_PARSING_ERROR.getV2Code(), PARAMETER_PARSING_ERROR.getMessage()));
    }
}
