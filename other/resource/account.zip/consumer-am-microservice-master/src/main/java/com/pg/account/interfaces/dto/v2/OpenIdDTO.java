package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Jack Sun
 * @date 2020-7-24 17:28
 */
@ApiModel(value = "OpenIdDTO_V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OpenIdDTO implements Serializable {
    private static final long serialVersionUID = -1829258050929158223L;

    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
}
