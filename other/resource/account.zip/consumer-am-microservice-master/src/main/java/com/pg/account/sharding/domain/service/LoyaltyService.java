package com.pg.account.sharding.domain.service;


import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import org.springframework.stereotype.Component;

/**
 * @author Jack
 * @date 2021-04-20 21:47
 */
@Component
public interface LoyaltyService {
    /**
     * 添加积分
     *
     * @param account      account
     * @param registerType registerType
     */
    void enrollAccount(Account account, ShardSocialAccount shardSocialAccount, String registerType);

    /**
     * 添加交互积分
     *
     * @param account   account
     * @param pointType pointType
     */
    void addInteraction(Account account, String pointType);
}
