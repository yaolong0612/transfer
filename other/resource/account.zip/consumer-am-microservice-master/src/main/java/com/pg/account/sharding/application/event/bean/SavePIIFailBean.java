package com.pg.account.sharding.application.event.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author Administrator
 * @date 2022/8/25
 */
@Entity
@Table(name = "SHARD_SavePIIFail_Entity")
@DynamicUpdate
@DynamicInsert
@Data
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class SavePIIFailBean implements Serializable {

    private static final long serialVersionUID = 1758355457220230987L;
    @Id
    private Long id;
    @Column(name = "partition_key")
    private String partitionKey;
    @Column(name = "row_key")
    private String rowKey;
    @Column(name = "mp")
    private String mp;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "account_id")
    private String accountId;
    @Column(name = "retry_status")
    private String retryStatus;
    @Column(name = "retry_type")
    private String type;
    @Column(name = "create_time")
    private LocalDateTime createTime;
    @Column(name = "update_time")
    private LocalDateTime updateTime;
}
