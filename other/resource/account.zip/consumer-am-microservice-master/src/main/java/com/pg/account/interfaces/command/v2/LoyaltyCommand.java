package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * <Description> 积分系统创建用户所需参数
 *
 * @author xusheng
 * @date 2019/11/14 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoyaltyCommand implements Serializable {
    private static final long serialVersionUID = 6135561657335095916L;

    @ApiModelProperty(value = "会员Id", required = true)
    @NotNull(message = "缺少会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;

    @ApiModelProperty(value = "渠道ID", required = true)
    @NotNull(message = "channel is not exist")
    private String channel;

    @ApiModelProperty(value = "绑定Id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;

    @ApiModelProperty(value = "品牌", required = true)
    @NotNull(message = "缺少品牌")
    private String brand;

    @ApiModelProperty(value = "注册来源(ML:大陆，TW:台湾，HK:香港)", required = true)
    @NotNull(message = "缺少注册来源(ML:大陆，TW:台湾，HK:香港)")
    private String region;

    @ApiModelProperty(value = "注册类型(REGISTER:注册，BINDING:绑定)", required = true)
    private String registerType;

    @ApiModelProperty(value = "加积分类型(COMPLETE_PROFILE:修改加积分标识)", required = true)
    private String pointType;

    @ApiModelProperty(value = "宝宝生日年月，格式：yyyyMM")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String babyBirthYearAndMonth;

}
