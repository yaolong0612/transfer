package com.pg.account.sharding.infrastructure.jpa.mapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author lfx
 * @date 2021/5/31 14:48
 */
public interface EmailMappingDao extends JpaRepository<EmailMapping, Long> {

    /**
     * 根据email查询map关系
     *
     * @param tenantId tenantId
     * @param email    email
     * @return EmailMapping
     */
    EmailMapping findByEmailMapId_TenantIdAndEmailMapId_Email(String tenantId, String email);

    /**
     * 根据tenantId和email删除映射关系
     *
     * @param tenantId tenantId
     * @param email    email
     */
    @Modifying
    @Transactional
    void deleteByEmailMapId_TenantIdAndEmailMapId_Email(String tenantId, String email);

}
