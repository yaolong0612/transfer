package com.pg.account.infrastructure.common.exception.enums;

import lombok.Getter;

import java.util.Arrays;

/**
 * @author guye
 * @version 1.0
 * @date 2022/1/24 10:17
 */
@Getter
public enum V3ResultEnum {
    /**
     * 通用状态
     */
    SUCCESS(0, "Success", "成功"),
    ERROR(59999, "System Error", "系统发生意外错误，请稍后再试~"),

    /**
     * 业务异常
     */
    INCORRECT_TENANT_ID(51001, "tenant is not exist", "客官您的tenantId填写有错误~"),
    INCORRECT_CHANNEL_ID(51002, "channel is not exist", "客官您的channelId填写有错误~"),
    INCORRECT_MOBILE(51006, "mobile format is error", "客官您的手机号格式填写有错误~"),
    INCORRECT_EMAIL(51007, "email format is error", "客官您的email格式填写有错误~"),
    MOBILE_EXIST(51302, "mobile is exist", "客官您的手机号已存在~"),
    EMAIL_EXIST(51303, "email is exist", "客官您的email已存在~"),
    REPEAT_OPT_ID(51306, "optId is not exist or repeat optId", "客官您的optId重复或不存在~"),
    ACCOUNT_NOT_EXIST(51308, "account not exist", "客官您的账户不存在~"),
    OPT_ID_NOT_EXIST(51317, "subscription type does not exist", "客官您的订阅类型不存在~"),
    BIND_ID_NOT_EXIST(51320, "bind data does not exist", "客官您的绑定数据不存在~"),
    USER_ATTRIBUTE_DATA_EXIST(51333, "user attribute data exists", "客官您的用户属性不存在~"),
    INCORRECT_MULTIPLE_BABIES_BIRTHDAY(51339, "many babies have birthdays less than a year apart or on different days", "系统开小差了，请稍后再试~"),
    INCORRECT_BABY_BIRTHDAY(51340, "baby's birthday is incorrect", "婴儿的生日填写不正确~"),
    CUSTOMIZED_VALIDATOR_ERROR(51341, "customization error", "客官您的定制有错误~"),
    PARAMETER_PARSING_ERROR(51343, "parameter error", "客官您的参数有错误~"),
    ACCOUNT_DATA_CONFLICT(51344, "account data conflict", "客官您的账号存在冲突，请走解决冲突流程或联系客服~"),
    ACCOUNT_DATA_ERROR(51444, "account data error", "客官您的账号有错误~"),
    ACCOUNT_NOT_CONFLICT(51445, "account no conflict", "客官您的账号不存在冲突~"),
    RETENTION_DELETE_CONSUMER_ERROR(51446, "retention deleteconsumer dobussiness error", "retention消费数据异常~"),
    SEND_PII_ACCOUNT_ERROR(51447, "send pii account error", "发送account快照失败~"),
    SEND_PII_Counter_ERROR(51448, "send pii counter error", "发送counter快照失败~"),
    /**
     * 自定义注解
     */
    QUERY_FIELDS_ERROR(51034, "query fields is error", "客官您的查询字段错误~"),
    QUERY_TYPE_NOT_EXIST(51035, "query type not exist", "客官请填写查询类型~"),
    RELATIONSHIP_SEQUENCE_ERROR(51042, "relationship and sequence must be unique", "客官请填写唯一的关系和顺序~"),
    USER_BIRTHDAY_NOT_ADULT(51336, "user is under the age of 18 and is not an adult", "客官您未满18岁~"),
    INCORRECT_USER_ATTRIBUTE_DATA_TYPE(51337, "user attribute data type is incorrect", "客官您的的属性不正确~"),
    INCORRECT_QUERY_PARAM(51328, "query parameters are incorrect", "客官您的参数不正确~"),
    INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT(51011, "incorrect user attribute information content", "客官您的属性信息不正确~"),

    /**
     * 系统配置问题
     */
    TENANT_CONFIG_NOT_EXIST(52001, "tenant config is not exist", "系统开小差了，请稍后再试~"),
    CHANNEL_CONFIG_NOT_EXIST(52002, "channel config is not exist", "系统开小差了，请稍后再试~"),
    SOURCE_CONFIG_NOT_EXIST(52003, "source config is not exist", "系统开小差了，请稍后再试~"),
    SYSTEM_CONFIG_NOT_EXIST(52004, "system config is not exist", "系统开小差了，请稍后再试~"),
    SYSTEM_CONFIG_ERROR(52005, "system config is error", "系统开小差了，请稍后再试~"),
    /**
     * 外部系统的异常
     */
    ADDRESS_MICRO_SERVICE_ERROR(53001, "address microservice error", "系统繁忙，请稍后再试~"),
    AWARD_MICRO_SERVICE_ERROR(53004, "award microservice error", "系统繁忙，请稍后再试~"),
    LOYALTY_MICRO_SERVICE_ERROR(53005, "loyalty microservice error", "系统繁忙，请稍后再试~"),
    SMS_MICRO_SERVICE_ERROR(53006, "sms microservice error", "系统繁忙，请稍后再试~"),

    /**
     * 底层与组件的异常
     */
    DB_ERROR(54001, "db error", "系统繁忙，请稍后再试~"),
    REDIS_ERROR(54002, "redis service error", "系统繁忙，请稍后再试~"),
    BAI_DU_SNOWFLAKE_ALGORITHM_ERROR(54003, "baiDu snowflake algorithm error", "系统繁忙，请稍后再试~"),
    SERVICE_BUS_ERROR(54004, "service bus error", "系统繁忙，请稍后再试~"),
    EVENT_HUB_ERROR(54005, "event hub error", "系统繁忙，请稍后再试~"),
    MQ_ERROR(54006, "mq error", "系统繁忙，请稍后再试~"),
    TABLE_STORAGE_ERROR(54007, "table Storage error", "系统繁忙，请稍后再试~"),
    READ_TIMEOUT_ERROR(54008, "read time out ", "系统繁忙，请稍后再试~"),
    CAFFEINE_ERROR(54009, "caffeine error", "系统繁忙，请稍后再试~"),

    APP_GUARDIAN_ERROR(55401, "Permission Denied", "拒绝访问");

    private final Integer code;
    private final String message;
    private final String frontMessage;

    V3ResultEnum(Integer code, String message, String frontMessage) {
        this.code = code;
        this.message = message;
        this.frontMessage = frontMessage;
    }

    public static V3ResultEnum getByMsg(String message) {
        return Arrays.stream(V3ResultEnum.values())
                .filter(msg -> message.equals(msg.getMessage()))
                .findAny()
                .orElse(PARAMETER_PARSING_ERROR);
    }
}
