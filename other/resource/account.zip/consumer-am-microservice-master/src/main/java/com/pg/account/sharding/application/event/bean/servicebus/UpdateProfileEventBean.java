package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateProfileEventBean implements Serializable {

    private static final long serialVersionUID = 3046844419810095060L;
    @JSONField(ordinal = 1)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 2)
    private Integer mpId;
    @JSONField(ordinal = 3)
    private Character updateFlag;

    @JSONField(ordinal = 5)
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @JSONField(ordinal = 6)
    private String nickName;
    @JSONField(ordinal = 7)
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @JSONField(ordinal = 8)
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthdate;
    @JSONField(ordinal = 9)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @JSONField(ordinal = 10)
    @Desensitized(value = DesensitizedEnum.MOBILE_PHONE)
    private String mobile;
    @JSONField(ordinal = 11)
    private String mobileSha256;
    @JSONField(ordinal = 12)
    private String province;
    @JSONField(ordinal = 13)
    private String city;
    @JSONField(ordinal = 14)
    private String district;
    @JSONField(ordinal = 15)
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @JSONField(ordinal = 16)
    private String zipCode;
    @JSONField(ordinal = 18)
    private List<JobBean> jobs;
    @JSONField(ordinal = 19)
    private List<EducationBean> educations;
    @JSONField(ordinal = 20)
    private List<HumanRelationBean> humanRelations;
    @JSONField(ordinal = 21)
    private Timestamp updateTime;
    @JSONField(ordinal = 22)
    private Timestamp modifyTime;

    public void updated() {
        this.updateFlag = 'U';
    }

}
