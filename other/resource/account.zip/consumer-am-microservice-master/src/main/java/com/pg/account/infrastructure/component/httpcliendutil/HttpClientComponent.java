package com.pg.account.infrastructure.component.httpcliendutil;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.apache.http.Consts;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author Simon
 * @date 2016/10/19
 */
@Component
@Slf4j
public class HttpClientComponent {

    public static final String GET_TYPE = "GET";
    public static final String POST_TYPE = "POST";
    public static final String PUT_TYPE = "PUT";
    public static final String PATCH_TYPE = "PATCH";
    public static final String DELETE_TYPE = "DELETE";
    public static final String MUST_PUT_REQUEST_BODY = "MUST put Request Body!!!";
    @Resource(name = "closeableHttpClient")
    private CloseableHttpClient httpClient;
    @Autowired
    private RequestConfig requestConfig;

    public HttpClientComponent() {
        //暂时不需要实现
    }

    public HttpResult postJson(String url, String requestBody) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);
        StringEntity entity = new StringEntity(requestBody, ContentType.APPLICATION_JSON);
        httpPost.setEntity(entity);
        return httpExecute(httpPost);
    }

    public HttpResult get(String url) {
        HttpGet httpGet = new HttpGet(url);
        httpGet.setConfig(requestConfig);
        return httpExecute(httpGet);
    }

    public HttpResult delete(String url) {
        HttpDelete httpDelete = new HttpDelete(url);
        httpDelete.setConfig(requestConfig);
        return httpExecute(httpDelete);
    }

    public HttpResult post(String url, String requestBody, Map<String, String> headers) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpPost.setHeader(entry.getKey(), entry.getValue());
            }
        }
        StringEntity entity = new StringEntity(requestBody, ContentType.APPLICATION_JSON);
        httpPost.setEntity(entity);
        return httpExecute(httpPost);
    }

    public HttpResult put(String url, String requestBody, Map<String, String> headers) {
        HttpPut httpPut = new HttpPut(url);
        httpPut.setConfig(requestConfig);
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpPut.setHeader(entry.getKey(), entry.getValue());
            }
        }
        StringEntity entity = new StringEntity(requestBody, ContentType.APPLICATION_JSON);
        httpPut.setEntity(entity);
        return httpExecute(httpPut);
    }

    public HttpResult patch(String url, String requestBody, Map<String, String> headers) {
        HttpPatch httpPatch = new HttpPatch(url);
        httpPatch.setConfig(requestConfig);
        if (headers != null) {
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                httpPatch.setHeader(entry.getKey(), entry.getValue());
            }
        }
        StringEntity entity = new StringEntity(requestBody, ContentType.APPLICATION_JSON);
        httpPatch.setEntity(entity);
        return httpExecute(httpPatch);
    }

    public HttpResult executeHttpRequest(String methodType, String url, String requestBody, Map<String, String> headers) {
        HttpResult result = null;
        if (GET_TYPE.equalsIgnoreCase(methodType)) {
            result = this.get(url);
        } else if (POST_TYPE.equalsIgnoreCase(methodType)) {
            Validate.notNull(requestBody, "POST Type is null");
            result = this.post(url, requestBody, headers);
        } else if (PUT_TYPE.equalsIgnoreCase(methodType)) {
            Validate.notNull(requestBody, "PUT Type is null");
            result = this.put(url, requestBody, headers);
        } else if (PATCH_TYPE.equalsIgnoreCase(methodType)) {
            Validate.notNull(requestBody, "PATCH Type is null");
            result = this.patch(url, requestBody, headers);
        } else if (DELETE_TYPE.equalsIgnoreCase(methodType)) {
            result = this.delete(url);
        }
        return result;
    }

    public HttpResult postText(String url, String requestBody) {
        return postText(url, requestBody, ContentType.TEXT_PLAIN.withCharset(Consts.UTF_8));
    }

    public HttpResult postText(String url, String requestBody, ContentType contentType) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);
        StringEntity entity = new StringEntity(requestBody, contentType);
        httpPost.setEntity(entity);
        return httpExecute(httpPost);
    }

    public HttpResult postForm(String url, Map<String, String> params) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(requestConfig);
        List<BasicNameValuePair> parameters = new ArrayList<>();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            parameters.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }
        UrlEncodedFormEntity entity = new UrlEncodedFormEntity(parameters, Consts.UTF_8);
        httpPost.setEntity(entity);
        return httpExecute(httpPost);
    }

    private HttpResult httpExecute(HttpRequestBase httpRequest) {
        CloseableHttpResponse httpResponse = null;
        HttpResult httpResult = new HttpResult();
        try {
            httpResponse = httpClient.execute(httpRequest);
            httpResult.setStatus(httpResponse.getStatusLine().getStatusCode());
            httpResult.setReason(httpResponse.getStatusLine().getReasonPhrase());
            httpResult.setResponseBody(EntityUtils.toString(httpResponse.getEntity(), StandardCharsets.UTF_8));
        } catch (IOException e) {
            log.info("Request error", e);
            httpResult.setStatus(1050);
            httpResult.setReason(e.getMessage());
        } finally {
            if (httpResponse != null) {
                try {
                    httpResponse.close();
                } catch (IOException e) {
                    log.info("close error, please ignore", e);
                }
            }
        }
        return httpResult;
    }
}
