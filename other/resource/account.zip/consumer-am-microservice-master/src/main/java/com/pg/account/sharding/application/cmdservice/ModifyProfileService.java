package com.pg.account.sharding.application.cmdservice;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.service.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;

/**
 * @author lfx
 * @date 2022/1/5 15:10
 */
@Validated
@Component
public interface ModifyProfileService {

    /**
     * 修改用户信息
     *
     * @param account account
     */
    void modifyProfile(@Valid @IsValidEmail @IsValidMobile @MemberExistValid @IsAdult @IsAttrIdExist Account account);

}
