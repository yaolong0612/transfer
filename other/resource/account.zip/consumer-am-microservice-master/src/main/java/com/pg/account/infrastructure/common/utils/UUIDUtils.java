package com.pg.account.infrastructure.common.utils;

import java.util.UUID;

/**
 * UUID工具类。
 *
 * @author JunJie
 */
public class UUIDUtils {

    private UUIDUtils() {
        //No thing
    }

    /**
     * @return String
     */
    public static String generateUuid() {
        return UUID.randomUUID().toString().replace("-", "").toUpperCase();
    }
}
