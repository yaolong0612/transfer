package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.interfaces.command.SignUpCommand;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Arrays;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COLON;
import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;
import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author mrluve
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = IsValidSignUpAccountSource.IsValidSource.class)
public @interface IsValidSignUpAccountSource {
    String message() default "source config is not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class IsValidSource implements ConstraintValidator<IsValidSignUpAccountSource, @Valid SignUpCommand> {

        @Override
        public boolean isValid(@Valid SignUpCommand signUpCommand, ConstraintValidatorContext constraintValidatorContext) {
            if (!regSourceValid(signUpCommand.getTenant(), signUpCommand.getRegSource())) {
                String result = Optional.ofNullable(LocalCacheConfigUtils.getCooperationOptIn(signUpCommand.getTenant(), signUpCommand.getChannel())).orElse(null);
                if (Optional.ofNullable(result).isPresent()) {
                    return regSourceValid(result.split(COLON)[0], signUpCommand.getRegSource());
                } else {
                    return false;
                }
            } else {
                return true;
            }
        }

        /**
         * 注册来源校验
         *
         * @param tenantId 租户
         * @param source   来源
         */
        private boolean regSourceValid(String tenantId, String source) {
            Optional<String> regSource = Optional.ofNullable(LocalCacheConfigUtils.getRegisterSource(tenantId));
            return regSource.map(value -> Arrays.asList(value.split(COMMA)).contains(source)).orElse(false);
        }
    }

}
