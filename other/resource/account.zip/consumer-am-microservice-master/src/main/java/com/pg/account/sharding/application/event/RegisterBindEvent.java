package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class RegisterBindEvent extends ApplicationEvent {

    private static final long serialVersionUID = 269167968005282272L;
    private Account account;
    private ShardSocialAccount shardSocialAccount;
    private ShardSubscription shardSubscription;

    public RegisterBindEvent(Object source) {
        super(source);
    }

    public RegisterBindEvent(Object source, Account account, ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription) {
        super(source);
        this.account = account;
        this.shardSocialAccount = shardSocialAccount;
        this.shardSubscription = shardSubscription;
    }
}
