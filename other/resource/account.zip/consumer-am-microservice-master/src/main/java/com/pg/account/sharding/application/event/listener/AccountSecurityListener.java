package com.pg.account.sharding.application.event.listener;

import com.pg.account.sharding.application.event.ChangePasswordEvent;
import com.pg.account.sharding.application.event.LogonEvent;
import com.pg.account.sharding.application.event.LogonFailureEvent;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author Jack
 * @date 2021-04-28 21:23
 */
@Slf4j
@Component("shardingAccountSecurityListener")
public class AccountSecurityListener {

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onChangePasswordEvent(ChangePasswordEvent event) {
        Validate.notNull(event.getAccount(), "ChangePasswordEvent account is null");
        Validate.notNull(event.getAccount().getIdentityId().getTenantId(), "ChangePasswordEvent account tenantId is null");
        Validate.notNull(event.getAccount().getIdentityId().getAccountId(), "ChangePasswordEvent account memberId is null");
        RedisConfigUtils.clearLogonFailedCounts(event.getAccount().getIdentityId().getTenantId(), event.getAccount().getIdentityId().getAccountId());
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onLogonEvent(LogonEvent event) {
        Validate.notNull(event.getTenantId(), "LogonEvent account tenantId is null");
        Validate.notNull(event.getMemberId(), "LogonEvent account memberId is null");
        RedisConfigUtils.clearLogonFailedCounts(event.getTenantId(), event.getMemberId());
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onLogonEvent(LogonFailureEvent event) {
        Validate.notNull(event.getAccount(), "LogonFailureEvent account is null");
        Validate.notNull(event.getAccount().getIdentityId().getTenantId(), "LogonFailureEvent account tenantId is null");
        Validate.notNull(event.getAccount().getIdentityId().getAccountId(), "LogonFailureEvent account memberId is null");
        RedisConfigUtils.addLogonFailedCounts(event.getAccount().getIdentityId().getTenantId(), event.getAccount().getIdentityId().getAccountId());
    }
}
