package com.pg.account.sharding.domain.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.enums.SubscriptionsStatusEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.interfaces.dto.QuerySubscriptionDTO;
import com.pg.account.interfaces.dto.v2.SubscriptionDTO;
import com.pg.account.interfaces.dto.v2.SubscriptionQueryDTO;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.Term;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.OptionDictionaryDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import com.pg.account.sharding.infrastructure.jpa.config.ShardOptionDictionary;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;

/**
 * @author wsq
 * @date 2021/6/7 13:52
 **/
@Service
public class SubscriptionsService {


    public static final String TERMS_ID = "termsId";
    public static final String OPT_ID = "optId";
    public static final String CHANNEL_ID = "channelId";
    public static final String TERMS_VERSION = "termsVersion";
    private final SubscriptionRepository subscriptionRepository;
    private final OptionDictionaryDao optionDictionaryDao;
    private final ChannelDao channelDao;

    @Autowired
    public SubscriptionsService(SubscriptionRepository subscriptionRepository, OptionDictionaryDao optionDictionaryDao, ChannelDao channelDao) {
        this.subscriptionRepository = subscriptionRepository;
        this.optionDictionaryDao = optionDictionaryDao;
        this.channelDao = channelDao;
    }

    /**
     * 通过accountId 查询 订阅
     *
     * @param account account
     * @return Account
     */
    public QuerySubscriptionDTO fetchSubscriptionByAccountId(Account account) {
        ShardSubscription shardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
        List<ShardOptionDictionary> optionDictionaryList = optionDictionaryDao.findByTenantId(account.getTenantId());
        List<SubscriptionDTO> subscriptionDTOList = new ArrayList<>();
        if (Optional.ofNullable(shardSubscription).isPresent()) {
            shardSubscription.getSubscriptionList().forEach(sub -> {
                ShardOptionDictionary resultOptionDictionary = optionDictionaryList.stream().filter(optionDictionary ->
                        optionDictionary.getOptId().equals(sub.getOptId()))
                        .findAny().orElse(null);
                if (Optional.ofNullable(resultOptionDictionary).isPresent()) {
                    SubscriptionDTO subscriptionDTO = new SubscriptionDTO(sub.getOptId(), resultOptionDictionary.getOptValue(), sub.getOptStatus());
                    subscriptionDTOList.add(subscriptionDTO);
                } else {
                    SubscriptionDTO subscriptionDTO = new SubscriptionDTO(sub.getOptId(), null, sub.getOptStatus());
                    subscriptionDTOList.add(subscriptionDTO);
                }
            });
        }
        List<SubscriptionDTO> subscriptionDTOList1 = subscriptionDTOList.stream().sorted(Comparator.comparing(SubscriptionDTO::getOptId, Comparator.nullsLast(String::compareTo))).collect(Collectors.toList());
        return new QuerySubscriptionDTO(Long.parseLong(account.getTenantId()), subscriptionDTOList1);
    }


    /**
     * 查询订阅
     *
     * @param account account
     * @return SubscriptionQueryDTO
     * @date 2021/6/10 15:19
     */
    public SubscriptionQueryDTO fetchSubscriptionsByOpenId(Account account) {
        ShardSubscription shardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
        List<ShardOptionDictionary> optionDictionaryList = optionDictionaryDao.findByTenantId(account.getTenantId());
        Set<SubscriptionDTO> subscriptions = new HashSet<>();
        Optional.ofNullable(shardSubscription)
                .map(ShardSubscription::getSubscriptionItemList)
                .filter(list -> !list.isEmpty())
                .ifPresent(subs -> subs.forEach(sub -> {
                    ShardOptionDictionary resultOptionDictionary = optionDictionaryList.stream()
                            .filter(optionDictionary -> optionDictionary.getOptId().equals(sub.getOptId()))
                            .findAny()
                            .orElse(null);
                    SubscriptionDTO subscriptionDTO;
                    if (Optional.ofNullable(resultOptionDictionary).isPresent()) {
                        subscriptionDTO = new SubscriptionDTO(sub.getOptId(), resultOptionDictionary.getOptValue(), sub.getOptStatus());
                    } else {
                        subscriptionDTO = new SubscriptionDTO(sub.getOptId(), null, sub.getOptStatus());
                    }
                    subscriptions.add(subscriptionDTO);
                }));
        return new SubscriptionQueryDTO(account.getOpenUid(), subscriptions);
    }

    /**
     * 组装和校验订阅信息
     * 并添加默认订阅信息和渠道绑定订阅信息
     *
     * @param shardSubscription account聚合根
     */
    public ShardSubscription subscription(ShardSubscription shardSubscription) {
        String tenantId = null;
        if (Optional.ofNullable(shardSubscription).isPresent()) {
            tenantId = shardSubscription.getTenantId();
        }
        //取出SubscriptionItem的值
        List<SubscriptionItem> cmdSubscriptionItemList = Optional.ofNullable(shardSubscription)
                .map(ShardSubscription::getSubscriptionItemList)
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(),
                        ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(),
                        ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
        String channelId = cmdSubscriptionItemList
                .stream()
                .findFirst()
                .flatMap(a -> Optional.ofNullable(a.getChannelId()))
                .orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
        List<SubscriptionItem> subscriptionItemList = toSubscriptionItemList(tenantId, channelId, cmdSubscriptionItemList);

        ShardSubscription dbShareSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, shardSubscription.getAccountId());
        if (Optional.ofNullable(dbShareSubscription).isPresent()) {
            List<SubscriptionItem> dbSubscriptionItems = dbShareSubscription.getSubscriptionList()
                    .stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(SubscriptionItem::getOptId))), ArrayList::new));
            Iterator<SubscriptionItem> iterator = dbSubscriptionItems.iterator();
            while (iterator.hasNext()) {
                SubscriptionItem dbSubscriptionItem = iterator.next();
                subscriptionItemList.forEach(subscriptionItem1 -> {
                    if (dbSubscriptionItem.getOptId().equals(subscriptionItem1.getOptId())) {
                        //删除重复数据
                        iterator.remove();
                    }
                });
            }
            //数据合并
            subscriptionItemList.addAll(dbSubscriptionItems);
            dbShareSubscription.setSubscriptionList(subscriptionItemList);
            dbShareSubscription.addUpdatedTime();
        } else {
            dbShareSubscription = new ShardSubscription();
            dbShareSubscription.build(shardSubscription.getIdentityId(), subscriptionItemList);
        }
        return dbShareSubscription;
    }

    public ShardSubscription subscribe(ShardSubscription shardSubscription) {
        String tenantId = null;
        if (Optional.ofNullable(shardSubscription).isPresent()) {
            tenantId = shardSubscription.tenantId();
        }
        //取出SubscriptionItem的值
        List<SubscriptionItem> cmdSubscriptionItemList = Optional.ofNullable(shardSubscription)
                .map(ShardSubscription::getSubscriptionItemList)
                .orElseThrow(() -> new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(),
                        V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(),
                        V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage()));
        String channelId = cmdSubscriptionItemList
                .stream()
                .findFirst()
                .flatMap(a -> Optional.ofNullable(a.getChannelId()))
                .orElseThrow(() -> new BusinessException(V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getFrontMessage()));
        String allOptionsByDefault = Optional.ofNullable(LocalCacheConfigUtils.getDefaultOptId(tenantId))
                .filter(s -> !s.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //默认订阅标识和当前渠道订阅标识集合
        Set<String> optIdList = Stream.of(allOptionsByDefault.split(COMMA)).collect(Collectors.toSet());
        ShardChannel channel = channelDao.findByTenantIdAndChannelId(tenantId, channelId);
        // 添加当前渠道的订阅关系
        optIdList.add(channel.getIsBindId());
        // 获取入参的订阅关系
        Set<String> cmdOptList = shardSubscription.getSubscriptionItemList().stream().map(SubscriptionItem::getOptId).filter(StringUtils::isNotBlank).collect(Collectors.toSet());
//        默认关系,当前渠道的订阅关系的和 如果不包含入参订阅关系 则报错
        List<String> excessOptList = cmdOptList.stream().filter(a -> !optIdList.contains(a)).collect(Collectors.toList());
        if (!excessOptList.isEmpty()) {
            throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        List<SubscriptionItem> subscriptionItemList = toSubscriptionItemLists(tenantId, channelId, cmdSubscriptionItemList);

        ShardSubscription dbShareSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, shardSubscription.accountId());
        if (Optional.ofNullable(dbShareSubscription).isPresent()) {
            List<SubscriptionItem> dbSubscriptionItems = dbShareSubscription.getSubscriptionList()
                    .stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(SubscriptionItem::getOptId))), ArrayList::new));
            subscriptionItemList.forEach(item -> dbSubscriptionItems.forEach(a -> {
                if (a.getOptId().equals(item.getOptId())) {
                    item.setCreateTime(a.getCreateTime());
                    item.setChannelId(a.getChannelId());
                }
            }));
            List<String> collect = subscriptionItemList.stream().map(SubscriptionItem::getOptId).collect(Collectors.toList());
            //数据合并
            dbSubscriptionItems.removeIf(a -> collect.contains(a.getOptId()));
            subscriptionItemList.addAll(dbSubscriptionItems);
            dbShareSubscription.setSubscriptionList(subscriptionItemList);
            dbShareSubscription.addUpdatedTime();
        } else {
            dbShareSubscription = new ShardSubscription();
            dbShareSubscription.build(shardSubscription.getIdentityId(), subscriptionItemList);
        }
        return dbShareSubscription;
    }

    /**
     * 物理删除订阅状态
     *
     * @param dbShardSubscription dbShardSubscription
     * @author xusheng
     * @date 2021/7/5 13:59
     */
    public void delete(ShardSubscription dbShardSubscription) {
        subscriptionRepository.save(dbShardSubscription);
    }


    /**
     * 保存订阅信息
     *
     * @param shardSubscription shardSubscription
     * @author xusheng
     * @date 2021/7/8 17:24
     */
    public void save(ShardSubscription shardSubscription) {
        this.subscriptionRepository.save(shardSubscription);
    }

    /**
     * 取消订阅
     *
     * @param shardSubscription shardSubscription
     * @author xusheng
     * @date 2021/6/10 22:40
     */
    public ShardSubscription unSubscription(ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription) {
        //根据会员账号查询订阅状态
        List<SubscriptionItem> changSubscription = new ArrayList<>();
        ShardSubscription dbShardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(shardSubscription.getTenantId(), shardSubscription.getAccountId());
        String tenantId = shardSubscription.getTenantId();
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .ifPresent(socialAccountItemList -> socialAccountItemList.forEach(socialAccountItem -> {
                    String bindOptIdByChannel = LocalCacheConfigUtils.getOptIdByChannel(tenantId, socialAccountItem.getChannelId());
                    Optional.ofNullable(dbShardSubscription)
                            .map(ShardSubscription::getSubscriptionList)
                            .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                            .ifPresent(subscriptionItemList -> subscriptionItemList.forEach(subscriptionItem -> {
                                if (subscriptionItem.getOptId().equals(bindOptIdByChannel)) {
                                    subscriptionItem.setOptStatus(SubscriptionsStatusEnum.OUT.getValue());
                                    changSubscription.add(subscriptionItem);
                                }
                            }));
                }));

        shardSubscription.setSubscriptionList(changSubscription);
        return dbShardSubscription;
    }

    /**
     * 1：获取默认的订阅标识和渠道对应的标识组装成需要保存的订阅信息
     * 2：将传入的订阅信息合并到默认的订阅信息
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @author xusheng
     * @date 2021/6/17 13:43
     */
    private List<SubscriptionItem> toSubscriptionItemList(String tenantId, String channelId, List<SubscriptionItem> cmdSubscriptionItemList) {
        //获取当前渠道所有的订阅配置
        //例如：[{"termsId":51,"termsVersion":"7","channelId":3,"optId":"102"},{"termsId":52,"termsVersion":"7","channelId":3,"optId":"103"}]
        String allOptionsByChannel = Optional.ofNullable(LocalCacheConfigUtils.getInitialOption(tenantId, channelId))
                .filter(s -> !s.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(),
                        ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //查询租户对应的订阅字典
        List<ShardOptionDictionary> optionDictionaryList = Optional.ofNullable(optionDictionaryDao.findByTenantId(tenantId))
                .filter(shardOptionDictionaries -> !shardOptionDictionaries.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(),
                        ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //获取当前渠道默认初始化的订阅配置
        //例如：102,103,106,107,110
        String allOptionsByDefault = Optional.ofNullable(LocalCacheConfigUtils.getDefaultOptId(tenantId))
                .filter(s -> !s.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //获取当前渠道对应的订阅标识，可以为null,因为coopreOptIn的渠道没有配置订阅标识
        String bindOptIdByChannel = LocalCacheConfigUtils.getOptIdByChannel(tenantId, channelId);
        //默认订阅标识和当前渠道订阅标识集合
        Set<String> optIdList = Stream.of(allOptionsByDefault.split(COMMA)).collect(Collectors.toSet());
        if (StringUtils.isNotBlank(bindOptIdByChannel)) {
            optIdList.add(bindOptIdByChannel);
        }
        cmdSubscriptionItemList = assembleSubscriptions(cmdSubscriptionItemList, optIdList);
        //将term信息合并到订阅信息
        mergeTermToSubscription(allOptionsByChannel, cmdSubscriptionItemList);
        //将optName信息合并到订阅信息
        mergeOptNameToSubscription(optionDictionaryList, cmdSubscriptionItemList);
        return cmdSubscriptionItemList;
    }

    private List<SubscriptionItem> toSubscriptionItemLists(String tenantId, String channelId, List<SubscriptionItem> cmdSubscriptionItemList) {
        //获取当前渠道所有的订阅配置
        //例如：[{"termsId":51,"termsVersion":"7","channelId":3,"optId":"102"},{"termsId":52,"termsVersion":"7","channelId":3,"optId":"103"}]
        String allOptionsByChannel = Optional.ofNullable(LocalCacheConfigUtils.getInitialOption(tenantId, channelId))
                .filter(s -> !s.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(),
                        ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //查询租户对应的订阅字典
        List<ShardOptionDictionary> optionDictionaryList = Optional.ofNullable(optionDictionaryDao.findByTenantId(tenantId))
                .filter(shardOptionDictionaries -> !shardOptionDictionaries.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(),
                        ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //获取当前渠道默认初始化的订阅配置
        //例如：102,103,106,107,110
        String allOptionsByDefault = Optional.ofNullable(LocalCacheConfigUtils.getDefaultOptId(tenantId))
                .filter(s -> !s.isEmpty())
                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));

        //默认订阅标识和当前渠道订阅标识集合
        Set<String> optIdList = Stream.of(allOptionsByDefault.split(COMMA)).collect(Collectors.toSet());
        cmdSubscriptionItemList = assembleSubscription(cmdSubscriptionItemList, optIdList, tenantId, channelId);
        //将term信息合并到订阅信息
        mergeTermToSubscription(allOptionsByChannel, cmdSubscriptionItemList);
        //将optName信息合并到订阅信息
        mergeOptNameToSubscription(optionDictionaryList, cmdSubscriptionItemList);
        return cmdSubscriptionItemList;
    }

    /**
     * 整合订阅入参和默认订阅信息
     *
     * @param cmdSubscriptionItemList cmdSubscriptionItemList
     * @param newOptList              newOptList
     * @return java.util.List<com.pg.account.domain.model.subscription.Subscriptions>
     * @author xusheng
     * @date 2021/6/29 18:10
     */
    private List<SubscriptionItem> assembleSubscriptions(List<SubscriptionItem> cmdSubscriptionItemList, Set<String> newOptList) {
        //添加入参订阅信息
        if (Optional.ofNullable(cmdSubscriptionItemList)
                .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                .isPresent()) {
            List<String> cmdOptIdList = cmdSubscriptionItemList.stream().map(SubscriptionItem::getOptId).collect(Collectors.toList());
            //默认的订阅标识和入参的订阅标识一样，则将默认中的订阅标识删除
            newOptList.removeIf(cmdOptIdList::contains);
            for (String s : newOptList) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(s, null, SubscriptionsStatusEnum.IN.getValue(), null);
                cmdSubscriptionItemList.add(subscriptionItem);
            }
        } else {
            cmdSubscriptionItemList = new ArrayList<>();
            for (String s : newOptList) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(s, null, SubscriptionsStatusEnum.IN.getValue(), null);
                cmdSubscriptionItemList.add(subscriptionItem);
            }
        }
        cmdSubscriptionItemList.removeIf(subscriptionItem -> StringUtils.isBlank(subscriptionItem.getOptId()));
        return cmdSubscriptionItemList;
    }

    private List<SubscriptionItem> assembleSubscription(List<SubscriptionItem> cmdSubscriptionItemList, Set<String> newOptList, String tenant, String channel) {
        //获取当前渠道对应的订阅标识，可以为null,因为coopreOptIn的渠道没有配置订阅标识
        String bindOptIdByChannel = LocalCacheConfigUtils.getOptIdByChannel(tenant, channel);
        //添加入参订阅信息
        if (Optional.ofNullable(cmdSubscriptionItemList)
                .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                .isPresent()) {
            List<String> cmdOptIdList = cmdSubscriptionItemList.stream().map(SubscriptionItem::getOptId).collect(Collectors.toList());
            //默认的订阅标识和入参的订阅标识一样，则将默认中的订阅标识删除
            newOptList.add(bindOptIdByChannel);
            newOptList.removeIf(cmdOptIdList::contains);
            for (String s : newOptList) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(s, null, channel, SubscriptionsStatusEnum.IN.getValue(), null);
                cmdSubscriptionItemList.add(subscriptionItem);
            }
        } else {
            cmdSubscriptionItemList = new ArrayList<>();
            for (String s : newOptList) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(s, null, SubscriptionsStatusEnum.IN.getValue(), null);
                cmdSubscriptionItemList.add(subscriptionItem);
            }
        }
        cmdSubscriptionItemList.removeIf(subscriptionItem -> StringUtils.isBlank(subscriptionItem.getOptId()));
        return cmdSubscriptionItemList;
    }

    /**
     * 将optName和订阅版本号添加到订阅信息中
     *
     * @param allOptionsByChannel     allOptionsByChannel
     * @param cmdSubscriptionItemList subscriptionItemList
     * @author xusheng
     * @date 2021/6/17 15:30
     */
    private void mergeTermToSubscription(String allOptionsByChannel, List<SubscriptionItem> cmdSubscriptionItemList) {
        JSONArray allOptionsByChannelJsonArray = parseArray(allOptionsByChannel);
        cmdSubscriptionItemList.forEach(subscriptionItem -> {
            List<Term> termList = new ArrayList<>();
            for (Object object : allOptionsByChannelJsonArray) {
                JSONObject jsonObject = (JSONObject) object;
                //获取optId最新的订阅版本
                if (Optional.ofNullable(subscriptionItem.getOptId()).isPresent() && subscriptionItem.getOptId().equals(jsonObject.getString(OPT_ID))) {
                    Term term = new Term(jsonObject.getString(TERMS_ID), jsonObject.getString(TERMS_VERSION));
                    termList.add(term);
                    subscriptionItem.setTermsList(termList);
                }
            }
        });
    }

    /**
     * 将optName合并到订阅信息
     *
     * @param optionDictionaryList    optionDictionaryList
     * @param cmdSubscriptionItemList cmdSubscriptionItemList
     * @author xusheng
     * @date 2021/7/1 17:14
     */
    private void mergeOptNameToSubscription(List<ShardOptionDictionary> optionDictionaryList, List<SubscriptionItem> cmdSubscriptionItemList) {
        cmdSubscriptionItemList.forEach(subscriptionItem -> optionDictionaryList.forEach(shardOptionDictionary -> {
            if (StringUtils.isNotBlank(subscriptionItem.getOptId()) && subscriptionItem.getOptId().equals(shardOptionDictionary.getOptId())) {
                subscriptionItem.setOptName(shardOptionDictionary.getOptValue());
            }
        }));
    }


}
