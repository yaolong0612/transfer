package com.pg.account.sharding.application.cmdservice.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.enums.ConfigStatusEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.sharding.application.cmdservice.ShardAccountV3Service;
import com.pg.account.sharding.application.event.BindingEvent;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.SignUpEvent;
import com.pg.account.sharding.application.event.UpdateProfileEvent;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.domain.service.*;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.*;
import com.pg.account.sharding.infrastructure.jpa.mapping.*;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import com.pg.account.sharding.interfaces.command.AccountConflictCommand;
import com.pg.account.sharding.interfaces.dto.*;
import jodd.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.validation.annotation.Validated;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.enums.AccountProfileEnum.PROFILE;
import static com.pg.account.sharding.domain.service.StringValidator.channelValid;
import static com.pg.account.sharding.domain.service.StringValidator.unionIdIsNecessary;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.*;

/**
 * @author lfx
 * @date 2021/12/31 15:19
 */
@Service
@Validated
public class ShardAccountV3ServiceImpl implements ShardAccountV3Service {


    public static final String COMMA = ",";
    public static final String FOLLOW = "I";
    public static final String UN_FOLLOW = "O";


    private final FetchMappingService fetchMappingService;
    private final FetchAccountService fetchAccountService;
    private final ShardSocialAccountRepository shardSocialAccountRepository;
    private final FetchBindingService fetchBindingService;
    private final RedisConfigUtils redisConfigUtils;
    private final SubscriptionRepository subscriptionRepository;
    private final TermsVersionDao termsVersionDao;
    private final SubscriptionsService subscriptionsService;
    private final AccountRepository accountRepository;
    private final ModifyAccountService modifyAccountService;
    private final BindSocialAccountService bindSocialAccountService;
    private final UnionIdMappingDao unionIdMappingDao;
    private final BindIdMappingDao bindIdMappingDao;
    private final OptionDictionaryDao optionDictionaryDao;
    private final ChannelDao channelDao;

    @Autowired
    public ShardAccountV3ServiceImpl(FetchMappingService fetchMappingService, FetchAccountService fetchAccountService, ShardSocialAccountRepository shardSocialAccountRepository, FetchBindingService fetchBindingService, RedisConfigUtils redisConfigUtils,
                                     SubscriptionRepository subscriptionRepository, TermsVersionDao termsVersionDao,
                                     SubscriptionsService subscriptionsService, AccountRepository accountRepository, ModifyAccountService modifyAccountService, BindSocialAccountService bindSocialAccountService,
                                     UnionIdMappingDao unionIdMappingDao, BindIdMappingDao bindIdMappingDao, OptionDictionaryDao optionDictionaryDao, ChannelDao channelDao) {
        this.fetchMappingService = fetchMappingService;
        this.fetchAccountService = fetchAccountService;
        this.shardSocialAccountRepository = shardSocialAccountRepository;
        this.fetchBindingService = fetchBindingService;
        this.redisConfigUtils = redisConfigUtils;
        this.subscriptionRepository = subscriptionRepository;
        this.termsVersionDao = termsVersionDao;
        this.subscriptionsService = subscriptionsService;
        this.accountRepository = accountRepository;
        this.modifyAccountService = modifyAccountService;
        this.bindSocialAccountService = bindSocialAccountService;
        this.unionIdMappingDao = unionIdMappingDao;
        this.bindIdMappingDao = bindIdMappingDao;
        this.optionDictionaryDao = optionDictionaryDao;
        this.channelDao = channelDao;
    }

    /**
     * 查询账号信息
     *
     * @param tenant  tenant
     * @param channel channel
     * @param type    type
     * @param fields  fields
     * @param query   query
     * @return Account
     */
    @Override
    public Account queryProfile(String tenant, String channel, String type, String fields, String query) {
        channelValid(tenant, channel);
        Account account = getAccount(tenant, type, channel, query);
        List<String> fieldList = new ArrayList<>();
        if (StringUtils.isNotBlank(fields)) {
            //通过逗号把字串传分割并进行排序
            fieldList = Arrays.stream(fields.split(COMMA)).filter(a -> !a.equals(PROFILE.getMsg())).distinct().sorted().collect(Collectors.toList());
        }
        // 缓存后面再加
        try {
            if (Optional.ofNullable(account.accountId()).isPresent() && redisConfigUtils.isMemberInfoCache(account.tenantId(), account.accountId(), fieldList)) {
                return parseObject(String.valueOf(redisConfigUtils.getMemberInfoCache(account.tenantId(), account.accountId(), fieldList)), Account.class);
            }
        } finally {
            account = fetchAccountService.fetchAccountByTenantAndAccountIdAndFields(account, fieldList);
            redisConfigUtils.addProfileCache(account.tenantId(), account.accountId(), JSON.toJSONString(account), fieldList);
        }
        return account;
    }

    /**
     * 查询社交绑定信息
     *
     * @param tenant  tenant
     * @param channel channel
     * @param type    type
     * @param query   query
     * @return QueryBindingDTO
     */
    @Override
    public QueryBindingDTO queryBinding(String tenant, String channel, String type, String query) {
        channelValid(tenant, channel);
        QueryBindingDTO queryBindingDTO = new QueryBindingDTO();
        //通过mobile,bindId,unionId 查询账号
        Account account = getAccount(tenant, type, channel, query);
        Set<BindDTO> bindDTOList = new HashSet<>();
        ShardSocialAccount shardSocialAccount = fetchBindingService.queryBindByTenantAndAccountId(tenant, account.accountId());
        if (Optional.ofNullable(shardSocialAccount.getSocialAccountList()).isPresent()) {
            HashSet<SocialAccountItem> socialAccountItems = new HashSet<>(shardSocialAccount.getSocialAccountList());
            socialAccountItems.forEach(s -> {
                BindDTO bindDTO = new BindDTO();
                bindDTO.setBindId(s.getBindId());
                bindDTO.setChannelId(s.getChannelId());
                bindDTO.setUnionId(s.getUnionId());
                Optional.ofNullable(s.getCustomer()).ifPresent(bindDTO::setCustomer);
                bindDTO.setRegSource(s.getSource());
                bindDTOList.add(bindDTO);
            });
        }
        if (UNION_ID.equals(type)) {
            Optional.ofNullable(channel).ifPresent(c -> bindDTOList.removeIf(list -> !query.equals(list.getUnionId())));
        } else {
            Optional.ofNullable(channel).ifPresent(c -> bindDTOList.removeIf(list -> !list.getChannelId().equals(c)));
        }
        queryBindingDTO.setAccountId(account.accountId());
        // 这里为什么要重新new 一个hashSet
        queryBindingDTO.setBinds(new HashSet<>(bindDTOList));
        return queryBindingDTO;
    }

    /**
     * 查询账号冲突
     *
     * @param tenant                 tenant
     * @param channel                channel
     * @param accountConflictCommand accountConflictCommand
     * @return QueryAccountConflictDTO
     */
    @Override
    public QueryAccountConflictDTO queryAccountConflict(String tenant, String channel, AccountConflictCommand accountConflictCommand) {
        channelValid(tenant, channel);
        // 判断unionId是否要传
        boolean necessary = unionIdIsNecessary(tenant, channel, accountConflictCommand.getMobile(), accountConflictCommand.getBindId(), accountConflictCommand.getUnionId());
        // 如果需要传，但是没有传则报错
        if (!necessary) {
            throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        JSONObject conflictResult = getConflictResult(tenant, channel, accountConflictCommand);
        QueryAccountConflictDTO object = conflictResult.getObject(QUERY_ACCOUNT_CONFLICT_DTO, QueryAccountConflictDTO.class);
        if (Optional.ofNullable(conflictResult.getJSONArray(ACCOUNTS)).isPresent()) {
            // 如果所有的账号都是组装的 则返回false，将accounts 置空，并设为不冲突走新会流程
            boolean flag = conflictResult.getJSONArray(ACCOUNTS).stream().anyMatch(a -> {
                JSONObject json = (JSONObject) a;
                return json.get("flag").equals(true);
            });
            if (!flag) {
                object.setExistConflict(0);
                object.setAccounts(null);
            }
        }
        return object;
    }


    /**
     * 检查是否存在冲突
     *
     * @param tenant                  tenant
     * @param channel                 channel
     * @param accountConflictCommand  accountConflictCommand
     * @param queryAccountConflictDTO queryAccountConflictDTO
     * @param accountDTOList          accountDTOList
     */
    private void checkIsConflict(String tenant, String channel, AccountConflictCommand accountConflictCommand, QueryAccountConflictDTO queryAccountConflictDTO, List<AccountDTO> accountDTOList, JSONObject body) {
        Account account = body.getObject(ACCOUNT, Account.class);
        ShardSocialAccount shardSocialAccount = body.getObject(SOCIAL_ACCOUNT, ShardSocialAccount.class);
        String query = body.getString(QUERY);
        String type = body.getString(TYPE);
        isExistByType(queryAccountConflictDTO, type);
        // 判断传入的类型是否存在
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setQuery(query);
        accountDTO.setType(type);
        accountDTO.setAccountId(body.getString(ACCOUNT_ID));
        //bindId是否有冲突
        Optional.ofNullable(accountConflictCommand.getBindId()).ifPresent(bindId -> accountDTO.setBindIdConflict(bindIdConflict(shardSocialAccount, bindId, channel)));
        //unionId是否有冲突
        Optional.ofNullable(accountConflictCommand.getUnionId()).ifPresent(unionId -> accountDTO.setUnionIdConflict(unionIdConflict(tenant, shardSocialAccount, unionId, channel)));
        //手机号是否有冲突
        Optional.ofNullable(account).ifPresent(a -> Optional.ofNullable(accountConflictCommand.getMobile()).ifPresent(mobile -> accountDTO.setMobileConflict(mobileConflict(a, tenant, mobile))));

        if (accountDTO.getUnionIdConflict() == 1 || accountDTO.getBindIdConflict() == 1 || accountDTO.getMobileConflict() == 1) {
            // mobile bindId unionId 有一个冲突则存在冲突
            queryAccountConflictDTO.setExistConflict(1);
        }
        accountDTOList.add(accountDTO);
    }

    /**
     * 判断mobile bindId unionId 是否存在
     *
     * @param queryAccountConflictDTO queryAccountConflictDTO
     * @param type                    type
     */
    private void isExistByType(QueryAccountConflictDTO queryAccountConflictDTO, String type) {
        switch (type) {
            case MOBILE:
                queryAccountConflictDTO.setExistMobile(1);
                break;
            case BIND_ID:
                queryAccountConflictDTO.setExistBindId(1);
                break;
            case UNION_ID:
                queryAccountConflictDTO.setExistUnionId(1);
                break;
            default:
                break;
        }
    }

    /**
     * 根据某个值进行去重
     *
     * @param keyExtractor key
     * @return Predicate
     */
    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> seen = new ConcurrentHashMap<>(8);
        return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    /**
     * 判断bindId是否冲突
     *
     * @param shardSocialAccount shardSocialAccount
     * @param bindId             bindId
     * @param channel            channel
     */
    private int bindIdConflict(ShardSocialAccount shardSocialAccount, String bindId, String channel) {
        Optional<List<SocialAccountItem>> socialAccountItems = Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getSocialAccountList);
        if (!socialAccountItems.isPresent()) {
            return 0;
        }
        //存在channel相同，且bindId相同或者bindId不存在则返回0 反之返回1
        return socialAccountItems.filter(accountItems -> accountItems.stream().anyMatch(socialAccountItem -> channel.equals(socialAccountItem.getChannelId()) &&
                (socialAccountItem.getBindId() != null && !bindId.equals(socialAccountItem.getBindId())))).map(accountItems -> 1).orElse(0);
    }

    /**
     * 判断unionId 是否冲突
     *
     * @param tenant             tenant
     * @param shardSocialAccount shardSocialAccount
     * @param unionId            unionId
     * @param channel            channel
     */
    public int unionIdConflict(String tenant, ShardSocialAccount shardSocialAccount, String unionId, String channel) {
        String unionType = LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel);
        Optional<List<SocialAccountItem>> socialAccountItems = Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getSocialAccountList);
        if (!socialAccountItems.isPresent() || StringUtil.isBlank(unionType)) {
            return 0;
        }
        //存在channel相同，且unionId相同或者unionId不存在则返回0 反之返回1
        return socialAccountItems
                .filter(
                        accountItems ->
                                accountItems.stream().anyMatch(socialAccountItem -> unionType.equals(socialAccountItem.getUnionType()) &&
                                        (socialAccountItem.getUnionId() != null && !unionId.equals(socialAccountItem.getUnionId())))

                ).map(accountItems -> 1).orElse(0);
    }

    /**
     * 判断手机号是否冲突
     *
     * @param account account
     * @param mobile  mobile
     */
    private int mobileConflict(Account account, String tenant, String mobile) {
        Optional<String> optionMobile = Optional.ofNullable(account).map(Account::getUserBasicInfo).map(UserBasicInfo::getContact)
                .map(Contact::getMobile);
        //手机是否相同。相同返回0，不同返回 如果查询到返回1 查不到返回0
        Integer integer = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(tenant, mobile)).map(s -> 1).orElse(0);
        return optionMobile.filter(s -> s.equals(mobile)).map(s -> 0).orElse(integer);
    }

    /**
     * 根据不同类型查询账号信息
     *
     * @param tenant  tenant
     * @param type    type mobile,bindId,unionId,accountId
     * @param channel channel
     * @param query   query
     * @return JSONObject
     */
    @Override
    public JSONObject queryAccountByType(String tenant, String type, String channel, String query) {
        channelValid(tenant, channel);
        JSONObject object = new JSONObject();
        Account account = getAccount(tenant, type, channel, query);
        Map<String, Integer> map = new HashMap<>(2);
        if (Optional.ofNullable(channel).isPresent()) {
            map = existBind(account, channel);
        }
        AtomicBoolean newVersion = new AtomicBoolean(false);
        Optional.ofNullable(subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(account.tenantId(), account.accountId())).ifPresent(dbShardSubscription -> {
            //最新条款
            ShardTermsVersion termsVersion = Optional.ofNullable(termsVersionDao.findByTenantIdAndStatus(tenant, ConfigStatusEnum.ACTIVE.getCode())).orElseThrow(() -> new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage()));
            List<SubscriptionItem> subscriptionItems = Optional.ofNullable(dbShardSubscription.getSubscriptionList()).orElse(new ArrayList<>());
            for (SubscriptionItem item : subscriptionItems) {
                //账号中存在订阅信息，并且订阅信息中如果有最新条款，则返回true,反之返回false
                if (Optional.ofNullable(item.getTermsList()).isPresent() &&
                        item.getTermsList().stream().anyMatch(term -> termsVersion.getTermsVersionLabel().equals(term.getTermVersion()))) {
                    newVersion.set(true);
                    break;
                }
            }
        });
        object.put(NEW_TERM_VERSION, newVersion.get());
        object.put(ACCOUNT, account);
        object.put(EXIST_BIND_ID, map.get(EXIST_BIND_ID));
        object.put(EXIST_UNION_ID, map.get(EXIST_UNION_ID));
        return object;
    }

    /**
     * 查看是否存在bindId或者unionId
     *
     * @param account account
     * @param channel channel
     * @return map
     */
    public Map<String, Integer> existBind(Account account, String channel) {
        Map<String, Integer> map = new HashMap<>(2);
        ShardSocialAccount shardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.tenantId(), account.accountId());
        Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getSocialAccountList).ifPresent(bindItems -> {
            //存在channel且channel与参数相同，并且存在bindId 则为 1 反之为 0
            map.put(EXIST_BIND_ID, bindItems.stream().anyMatch(c -> Optional.ofNullable(c.getChannel()).isPresent() && channel.equals(c.getChannelId())
                    && Optional.ofNullable(c.getBindId()).isPresent()) ? 1 : 0);
            //存在channel且channel与参数相同，并且存在unionId 则为 1 反之为 0
            map.put(EXIST_UNION_ID, bindItems.stream().anyMatch(c -> Optional.ofNullable(c.getChannel()).isPresent() && channel.equals(c.getChannelId())
                    && Optional.ofNullable(c.getUnionId()).isPresent()) ? 1 : 0);
        });
        return map;
    }

    /**
     * 查询account的基本信息
     *
     * @param tenant  租户
     * @param type    类型
     * @param channel 渠道
     * @param query   查询参数
     * @return account
     */
    private Account getAccount(String tenant, String type, String channel, String query) {
        String accountId = Optional.ofNullable(getAccountId(tenant, type, channel, query)).orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
        return fetchAccountService.fetchActiveAccount(tenant, accountId);
    }

    /**
     * 组合冲突账号
     *
     * @param tenant  tenant
     * @param channel channel
     * @param mobile  mobile
     * @param bindId  bindId
     * @param unionId unionId
     * @return JSONArray
     */
    @Override
    public JSONArray combConflictAccount(String tenant, String channel, String mobile, String bindId, String unionId) {
        Map<String, String> map = new HashMap<>(3);
        Optional.ofNullable(mobile).ifPresent(m -> map.put(MOBILE, m));
        Optional.ofNullable(bindId).ifPresent(b -> map.put(BIND_ID, b));
        Optional.ofNullable(unionId).ifPresent(u -> map.put(UNION_ID, u));
        List<JSONObject> accounts = new ArrayList<>();
        map.forEach((k, v) -> Optional.ofNullable(getConflictAccount(tenant, k, channel, v)).ifPresent(accounts::add));
        boolean existAccount = accounts.stream().anyMatch(a -> Optional.ofNullable(a.getString(ACCOUNT)).isPresent());
        return existAccount ? parseArray(String.valueOf(accounts.stream().distinct().collect(Collectors.toList()))) : null;
    }

    @Override
    public JSONObject getConflictResult(String tenant, String channel, AccountConflictCommand accountConflictCommand) {
        JSONObject jsonObject = new JSONObject();
        QueryAccountConflictDTO queryAccountConflictDTO = new QueryAccountConflictDTO();
        //根据手机号，bindId,unionId 组合查询的账号
        JSONArray maps = combConflictAccount(tenant, channel, accountConflictCommand.getMobile(), accountConflictCommand.getBindId(), accountConflictCommand.getUnionId());
        List<AccountDTO> accountDTOList = new ArrayList<>();
        // 如果查询到账号，就去检查账号是否存在冲突
        Optional.ofNullable(maps).ifPresent(m -> maps.forEach(a -> {
            JSONObject body = (JSONObject) a;
            checkIsConflict(tenant, channel, accountConflictCommand, queryAccountConflictDTO, accountDTOList, body);
        }));
//        去除accountId为空的accountDTO
        accountDTOList.removeIf(accountDTO -> !Optional.ofNullable(accountDTO.getAccountId()).isPresent());
        // 如果accountId超过一个则认为是冲突
        queryAccountConflictDTO.setExistConflict(accountDTOList.stream().filter(distinctByKey(AccountDTO::getAccountId)).count() > 1 ? 1 : queryAccountConflictDTO.getExistConflict());
        queryAccountConflictDTO.setAccounts(new HashSet<>(accountDTOList));
        jsonObject.put(ACCOUNTS, maps);
        jsonObject.put(QUERY_ACCOUNT_CONFLICT_DTO, queryAccountConflictDTO);
        return jsonObject;
    }

    /**
     * 注册
     *
     * @param account            account
     * @param shardSocialAccount shardSocialAccount
     * @param shardSubscription  shardSubscription
     * @return String
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public JSONObject signUp(Account account, ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription) {
        boolean newRegister = false;
        boolean modifyMobile = false;
        //查询是否已经存在账号
        String accountId = existAccountConflict(account.tenantId(), shardSocialAccount.getChannelId(), account.getMobile(),
                shardSocialAccount.getBindId(), shardSocialAccount.getUnionId());
        ShardSubscription dbSubscription;
        if (StringUtil.isBlank(accountId)) {
            //新会员
            account.specialNewAccountId();
            account.specialNewOpenUid();
            account.activeStatus();
            shardSocialAccount.specialIdentityId(account.getIdentityId());
            shardSubscription.specialAccountId(account.accountId());
            dbSubscription = subscriptionsService.subscribe(shardSubscription);
            accountRepository.saveAccountInfoAndMapping(account);
            accountId = account.accountId();
            newRegister = true;
        } else {
            //老会员
            //更改mobileMapping
            account.getIdentityId().setAccountId(accountId);
            modifyMobile = modifyAccountService.isModifyMobile(account);
            modifyAccountService.saveDevice(account);
            shardSocialAccount.setIdentityId(account.getIdentityId());
            shardSocialAccount = bindSocialAccountService.modifyBind(shardSocialAccount);
            shardSubscription.specialAccountId(account.accountId());
            dbSubscription = subscriptionsService.subscribe(shardSubscription);
        }
        //如果存在bindId或者unionId,则更新社交账号
        if (StringUtil.isNotBlank(shardSocialAccount.getBindId()) || StringUtil.isNotBlank(shardSocialAccount.getUnionId())) {
            bindSocialAccountService.saveIfExist(account.tenantId(), accountId, shardSocialAccount);
        }
        //更新bindIdMapping和unionIdMapping
        saveBindIdAndUnionIdMapping(account, shardSocialAccount);
        subscriptionsService.save(dbSubscription);

        boolean finalNewRegister = newRegister;
        boolean isModifyMobile = modifyMobile;
        List<SocialAccountItem> collect = shardSocialAccount.getSocialAccountList().stream().filter(a -> a.getChannelId().equals(account.getRegistration().getChannel().getChannelId())).collect(Collectors.toList());
        ShardSocialAccount dbShardSocialAccount = new ShardSocialAccount();
        dbShardSocialAccount.setIdentityId(shardSocialAccount.getIdentityId());
        dbShardSocialAccount.setCreatedTime(shardSocialAccount.getCreatedTime());
        dbShardSocialAccount.setUpdatedTime(shardSocialAccount.getUpdatedTime());
        dbShardSocialAccount.setSocialAccountList(collect);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                if (finalNewRegister) {
                    SignUpEvent signUpEvent = new SignUpEvent(this, account, dbShardSocialAccount, shardSubscription);
                    SpringContextUtil.getApplicationContext().publishEvent(signUpEvent);
                } else {
                    if (isModifyMobile) {
                        UpdateProfileEvent updateProfileEvent = new UpdateProfileEvent(this, account, null);
                        SpringContextUtil.getApplicationContext().publishEvent(updateProfileEvent);
                    }
                    BindingEvent bindingEvent = new BindingEvent(this, account, shardSubscription, dbShardSocialAccount);
                    SpringContextUtil.getApplicationContext().publishEvent(bindingEvent);
                }
            }
        });
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(ACCOUNT_ID, accountId);
        jsonObject.put(NEW_MEMBER, newRegister);
        return jsonObject;
    }

    @Override
    public QuerySubscriptionDTO querySubscription(String tenant, String channel, String accountId) {
        channelValid(tenant, channel);
        // 查询是否存在有效账号
        Account account = fetchAccountService.fetchActiveAccount(tenant, accountId);
        // 通过tenant和accountId查询订阅关系
        ShardSubscription shardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenant, accountId);
        // 通过tenant查询订阅字典
        List<ShardOptionDictionary> optionDictionaryList = optionDictionaryDao.findByTenantId(tenant);
        Set<SubscriptionDTO> subscriptionDTOList = new HashSet<>();
        Optional.ofNullable(shardSubscription)
                .map(ShardSubscription::getSubscriptionItemList)
                .filter(list -> !list.isEmpty())
                // 如果存在channel,则查询对应channel的订阅关系
                .ifPresent(subs -> subs.stream().filter(l -> {
                    if (Optional.ofNullable(channel).isPresent()) {
                        return channel.equals(l.getChannelId());
                    }
                    return true;
                }).forEach(sub -> {
                    ShardOptionDictionary resultOptionDictionary = optionDictionaryList.stream()
                            .filter(optionDictionary -> optionDictionary.getOptId().equals(sub.getOptId()))
                            .findAny()
                            .orElse(null);
                    SubscriptionDTO subscriptionDTO;
                    if (Optional.ofNullable(resultOptionDictionary).isPresent()) {
                        subscriptionDTO = new SubscriptionDTO(sub.getOptId(), resultOptionDictionary.getOptValue(), sub.getOptStatus());
                    } else {
                        subscriptionDTO = new SubscriptionDTO(sub.getOptId(), null, sub.getOptStatus());
                    }
                    subscriptionDTOList.add(subscriptionDTO);
                }));
        return new QuerySubscriptionDTO(tenant, account.accountId(), subscriptionDTOList);
    }

    /**
     * 更新 bindIdMapping 和 unionIdMapping
     *
     * @param account            account
     * @param shardSocialAccount shardSocialAccount
     */
    private void saveBindIdAndUnionIdMapping(Account account, ShardSocialAccount shardSocialAccount) {
        for (SocialAccountItem item : Optional.ofNullable(shardSocialAccount.getSocialAccountList()).orElse(Collections.emptyList())) {
            Optional.ofNullable(item.getUnionId()).ifPresent(unionId -> {
                String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(account.tenantId(), item.getChannelId());
                if (Optional.ofNullable(unionIdType).isPresent()) {
                    UnionIdMapping dbMapping = unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(account.tenantId(), unionId, unionIdType);
                    if (Optional.ofNullable(dbMapping).isPresent()) {
                        dbMapping.setAccountId(account.accountId());
                    } else {
                        dbMapping = new UnionIdMapping();
                        dbMapping.build(account.tenantId(), unionId, unionIdType, account.accountId());
                    }
                    unionIdMappingDao.save(dbMapping);
                }
            });
            Optional.ofNullable(item.getBindId()).ifPresent(bindId -> {
                BindIdMapping dbMapping = bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(account.tenantId(), item.getChannelId(), bindId);
                if (!Optional.ofNullable(dbMapping).isPresent()) {
                    dbMapping = new BindIdMapping();
                    IdentityId identityId = new IdentityId(account.tenantId(), account.accountId());
                    dbMapping.build(identityId, bindId, item.getChannelId());
                } else {
                    dbMapping.setAccountId(account.accountId());
                }
                bindIdMappingDao.save(dbMapping);
            });
        }
    }

    /**
     * 存在冲突账号
     *
     * @param tenant  tenant
     * @param channel channel
     * @param mobile  mobile
     * @param bindId  bindId
     * @param unionId unionId
     * @return String
     */
    private String existAccountConflict(String tenant, String channel, String mobile, String bindId, String unionId) {
        AccountConflictCommand accountConflictCommand = new AccountConflictCommand(mobile, bindId, unionId);
        QueryAccountConflictDTO queryAccountConflictDTO = queryAccountConflict(tenant, channel, accountConflictCommand);
        if (queryAccountConflictDTO.getExistConflict() == 1) {
            throw new BusinessException(V3ResultEnum.ACCOUNT_DATA_CONFLICT.getCode(), V3ResultEnum.ACCOUNT_DATA_CONFLICT.getMessage(), V3ResultEnum.ACCOUNT_DATA_CONFLICT.getFrontMessage());
        }
        return Optional.ofNullable(queryAccountConflictDTO.getAccounts()).isPresent() && !queryAccountConflictDTO.getAccounts().isEmpty() ? queryAccountConflictDTO.getAccounts().iterator().next().getAccountId() : null;
    }


    /**
     * 查询冲突账号
     *
     * @param tenant  tenant
     * @param type    type
     * @param channel channel
     * @param query   query
     * @return 账户的基本信息和绑定信息
     */
    private JSONObject getConflictAccount(String tenant, String type, String channel, String query) {
        String accountId = getAccountId(tenant, type, channel, query);
        JSONObject value = new JSONObject();
        Optional.ofNullable(accountId).ifPresent(aId -> {
            Account account;
            // 这里为什么要捕捉异常
            try {
                account = fetchAccountService.fetchActiveAccount(tenant, accountId);
                value.put("flag", true);
            } catch (Exception ex) {
                account = Account.AccountBuilder.anAccount().tenantId(tenant).accountId(accountId).build();
                value.put("flag", false);
            }
            ShardSocialAccount socialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId);
            if (Optional.ofNullable(socialAccount).isPresent()) {
                value.put(SOCIAL_ACCOUNT, socialAccount);
            } else {
                IdentityId identityId = new IdentityId();
                identityId.setTenantId(tenant);
                identityId.setAccountId(accountId);
                SocialAccountItem socialAccountItem = new SocialAccountItem();
                Channel c = new Channel();
                c.setChannelId(channel);
                String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel);
                c.setUnionType(unionIdType);
                socialAccountItem.setChannel(c);
                if (type.equals(BIND_ID)) {
                    socialAccountItem.setBindId(query);
                    socialAccount = new ShardSocialAccount(identityId, Collections.singletonList(socialAccountItem));
                    value.put(SOCIAL_ACCOUNT, socialAccount);
                }
                if (type.equals(UNION_ID)) {
                    socialAccountItem.setUnionId(query);
                    socialAccount = new ShardSocialAccount(identityId, Collections.singletonList(socialAccountItem));
                    value.put(SOCIAL_ACCOUNT, socialAccount);
                }
            }
            value.put(ACCOUNT, account);
            value.put(ACCOUNT_ID, accountId);
        });
        value.put(TYPE, type);
        value.put(QUERY, query);
        return Optional.ofNullable(accountId).isPresent() ? value : null;
    }

    /**
     * 通过各种情况查询accountId
     *
     * @param tenant  tenant
     * @param type    type
     * @param channel channel
     * @param query   query
     * @return accountId
     */
    private String getAccountId(String tenant, String type, String channel, String query) {
        String accountId;
        switch (type) {
            case MOBILE:
                // 判断是否是手机号格式
                if (!StringValidUtil.isMobile(query)) {
                    throw new BusinessException(V3ResultEnum.INCORRECT_MOBILE.getCode(), V3ResultEnum.INCORRECT_MOBILE.getMessage(), V3ResultEnum.INCORRECT_MOBILE.getFrontMessage());
                }
                // 根据手机号查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(tenant, query)).map(MobileMapping::getAccountId).orElse(null);
                break;
            case BIND_ID:
                // 判断channel是否存在 不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(V3ResultEnum.INCORRECT_CHANNEL_ID.getCode(), V3ResultEnum.INCORRECT_CHANNEL_ID.getMessage(), V3ResultEnum.INCORRECT_CHANNEL_ID.getFrontMessage()));
//                根据channel和bindId查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenant, query, channel)).map(BindIdMapping::getAccountId).orElse(null);
                break;
            case UNION_ID:
                // 判断channel是否存在，如果不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(V3ResultEnum.INCORRECT_CHANNEL_ID.getCode(), V3ResultEnum.INCORRECT_CHANNEL_ID.getMessage(), V3ResultEnum.INCORRECT_CHANNEL_ID.getFrontMessage()));
                // 根据租户和渠道查询unionType，如果不存在则报错
                String channelUnionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage()));
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenant, query, channelUnionIdType)).map(UnionIdMapping::getAccountId).orElse(null);
                break;
            case ACCOUNT_ID:
                // 如果是通过accountId查询则将query赋值给accountId
                accountId = query;
                break;
            default:
                throw new BusinessException(V3ResultEnum.QUERY_TYPE_NOT_EXIST.getCode(), V3ResultEnum.QUERY_TYPE_NOT_EXIST.getMessage(), V3ResultEnum.QUERY_TYPE_NOT_EXIST.getFrontMessage());
        }
        return accountId;
    }

    /**
     * 关注
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     */
    @Override
    public void follow(String tenant, String channel, String bindId) {
        concern(tenant, channel, bindId, FOLLOW);
    }

    /**
     * 取关
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     */
    @Override
    public void unfollow(String tenant, String channel, String bindId) {
        concern(tenant, channel, bindId, UN_FOLLOW);
    }

    /**
     * 关注或者取关
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     * @param status  关注取关状态
     */
    private void concern(String tenant, String channel, String bindId, String status) {
        channelValid(tenant, channel);
        ShardSubscription shardSubscription = getSubscription(tenant, channel, bindId);
        if (Optional.ofNullable(shardSubscription).isPresent()) {
            //获取渠道对应的订阅标识
            ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(tenant, channel);
            String isBindId = Optional.ofNullable(shardChannel).map(ShardChannel::getIsBindId).orElse(null);
            Optional.ofNullable(shardSubscription.getSubscriptionItemList())
                    .ifPresent(subscriptionItemList -> subscriptionItemList.forEach(subscriptionItem -> {
                        if (subscriptionItem.getOptId().equals(isBindId)) {
                            subscriptionItem.setOptStatus(status);
                        }
                    }));
            //更新订阅状态
            subscriptionRepository.save(shardSubscription);
            ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, tenant, channel);
            SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
        }
    }

    /**
     * 通过bindId和channelId查询会员账号
     *
     * @param tenant  tenant
     * @param channel channel
     * @param bindId  bindId
     * @author xusheng
     * @date 2022/2/16 13:47
     */
    private ShardSubscription getSubscription(String tenant, String channel, String bindId) {
        //根据租户、渠道Id和bindId查询对应的会员账号
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenant, bindId, channel);
        //判断bindMapping是否存在,不存在则抛异常
        String accountId = Optional.ofNullable(bindIdMapping)
                .map(BindIdMapping::getAccountId)
                .orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
        //判断账号是否有效
        Account account = fetchAccountService.fetchActiveAccount(tenant, accountId);
        // 通过tenant和accountId查询订阅关系
        return subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenant, account.accountId());
    }
}
