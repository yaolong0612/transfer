package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 学历信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationBean implements Serializable {
    private static final long serialVersionUID = 8266915499071896407L;
    private String relationType;
    @JSONField(ordinal = 1)
    private String relationSeq;
    @JSONField(ordinal = 2)
    private String province;
    @JSONField(ordinal = 3)
    private String city;
    @JSONField(ordinal = 4)
    private String district;
    @JSONField(ordinal = 5)
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @JSONField(ordinal = 6)
    private String zipCode;
    @JSONField(ordinal = 7)
    private String name;
    @JSONField(ordinal = 8)
    private String category;
    @JSONField(ordinal = 9)
    private String major;
    @JSONField(ordinal = 10)
    private String grade;
    @JSONField(ordinal = 11)
    private String className;
    @JSONField(ordinal = 12)
    private String college;
    @JSONField(ordinal = 13)
    private String degree;
    @JSONField(ordinal = 14)
    private String admissionTime;
    @JSONField(ordinal = 15)
    private String graduationTime;
    @JSONField(ordinal = 16)
    private Timestamp createTime;
    @JSONField(ordinal = 17)
    private Timestamp modifyTime;


}
