package com.pg.account.sharding.application.event;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 * @date 2021-6-9
 */
@Getter
public class LogonEvent extends ApplicationEvent {

    private static final long serialVersionUID = -3561377936566194834L;

    private String tenantId;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    private String code;

    public LogonEvent(Object source) {
        super(source);
    }

    public LogonEvent(Object source, String tenantId, String memberId, String code) {
        super(source);
        this.tenantId = tenantId;
        this.memberId = memberId;
        this.code = code;
    }
}
