package com.pg.account.sharding.infrastructure.jpa.profile.humanrelation;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.HumanRelationItem;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterHumanRelationListJson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 * 人际关系表
 *
 * @author Jack
 * @date 2021/5/27 13:42
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_HUMAN_RELATION")
@Data
@DynamicUpdate
@DynamicInsert
public class ShardHumanRelation extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1021356981573131722L;
    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterHumanRelationListJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private List<HumanRelationItem> humanRelationList;

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.identityId = account.getIdentityId();
        this.humanRelationList = account.getUserAdditionalInfo().getHumanRelationList();
        super.addCreateTime();
    }

    public void buildFromAccount(Account account) {
        this.identityId = account.getIdentityId();
        this.humanRelationList = account.getUserAdditionalInfo().getHumanRelationList();
        super.addUpdatedTime();
    }

    public void buildFromDb(ShardHumanRelation db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.id = Optional.ofNullable(this.id).orElse(db.getId());
            this.identityId = Optional.ofNullable(this.identityId).orElse(db.getIdentityId());
            Optional.ofNullable(this.getHumanRelationList())
                    .ifPresent(humanList -> humanList
                            .forEach(h -> db.humanRelationList
                                    .forEach(h::builder)));
        }
    }
}
