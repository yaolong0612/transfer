package com.pg.account.infrastructure.common.enums;


import lombok.Getter;

/**
 * @author JackSun
 */
@Getter
public enum ConfigStatusEnum {
    /**
     * 账号状态
     * ACTIVE 启动标识“1”
     * INACTIVE 失效标识“2”
     * DELETE 删除标识“3”
     */
    ACTIVE((byte) 1, "启用"),
    INACTIVE((byte) 2, "失效"),
    DELETE((byte) 3, "删除");

    private final Byte code;

    private final String message;

    ConfigStatusEnum(Byte code, String message) {
        this.code = code;
        this.message = message;
    }
}
