package com.pg.account.infrastructure.component.snowflake;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.shardingsphere.spi.keygen.ShardingKeyGenerator;
import org.springframework.stereotype.Component;

import java.util.Properties;

/**
 * @author lfx
 * @date 2021/8/11 19:09
 */
@Component
@Slf4j
public class ShardSnowFlake implements ShardingKeyGenerator {

    @Override
    public Comparable<?> generateKey() {
        UidGenerator uidGenerator = SpringContextUtil.getBean(UidGenerator.class);
        return uidGenerator.getUid();
    }

    @Override
    public String getType() {
        return "MY_SNOWFLAKE";
    }

    @Override
    public Properties getProperties() {
        return null;
    }

    @Override
    public void setProperties(Properties properties) {

    }
}
