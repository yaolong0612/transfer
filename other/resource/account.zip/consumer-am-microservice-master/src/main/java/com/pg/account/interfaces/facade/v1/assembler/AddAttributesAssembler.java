package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.AttributesCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author yj
 */
@Component
public class AddAttributesAssembler {
    /**
     * 将AttributesCommand 转换成Account
     *
     * @param attributesCommand attributesCommand
     * @return Account
     */
    public Account toAccount(AttributesCommand attributesCommand) {
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(attributesCommand.getTenantId().toString())
                .accountId(attributesCommand.getMemberId())
                .extraAttrs(toAttribute(attributesCommand));
        if (Optional.ofNullable(attributesCommand.getChannelId()).isPresent()) {
            accountBuilder.channelId(attributesCommand.getChannelId().toString());
        }
        return accountBuilder.build();
    }

    private List<ExtraAttributeItem> toAttribute(AttributesCommand attributesCommand) {
        List<ExtraAttributeItem> extraAttributeItemList = new ArrayList<>();
        Optional.ofNullable(attributesCommand.getAttrs()).filter(attributes -> !attributes.isEmpty()).ifPresent(attrs -> {
            attrs.forEach(a -> {
                ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
                extraAttributeItem.setAttrId(a.getAttrId());
                extraAttributeItem.setAttrValue(a.getAttrVal());
                extraAttributeItem.setCreateTime(LocalDateTime.now());
                extraAttributeItem.setUpdateTime(LocalDateTime.now());
                extraAttributeItemList.add(extraAttributeItem);
            });
        });
        return extraAttributeItemList;

    }
}
