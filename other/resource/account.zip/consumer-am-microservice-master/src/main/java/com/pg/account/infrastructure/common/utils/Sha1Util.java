package com.pg.account.infrastructure.common.utils;

import lombok.NoArgsConstructor;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 *
 * @author Dustin
 * Date: 17-3-22
 * Time: 下午4:36
 * To change this template use File | Settings | File Templates.
 */
@NoArgsConstructor
public class Sha1Util {

    private static final String ALGORITHM = "SHA1";
    private static final char[] HEX_DIGITS = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /**
     * encode string
     *
     * @param algorithm algorithm
     * @param str       str
     * @return String
     */
    public static String encode(String algorithm, String str) {
        if (str == null) {
            return null;
        }
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));
            return getFormattedText(messageDigest.digest());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Takes the raw bytes from the digest and formats them correct.
     *
     * @param bytes the raw bytes from the digest.
     * @return the formatted bytes.
     */
    private static String getFormattedText(byte[] bytes) {
        int len = bytes.length;
        StringBuilder buf = new StringBuilder(len * 2);
        for (byte aByte : bytes) {
            buf.append(HEX_DIGITS[(aByte >> 4) & 0x0f]);
            buf.append(HEX_DIGITS[aByte & 0x0f]);
        }
        return buf.toString();
    }

    /**
     * @param list list
     * @return String
     */
    public static String sigOfSha1(List<String> list) {
        String result = "";
        StringBuilder sb = new StringBuilder();
        if (list != null && !list.isEmpty()) {
            Collections.sort(list);
            for (String string : list) {
                sb.append(string);
            }
            result = encode(ALGORITHM, sb.toString());
        }
        return result;
    }
}
