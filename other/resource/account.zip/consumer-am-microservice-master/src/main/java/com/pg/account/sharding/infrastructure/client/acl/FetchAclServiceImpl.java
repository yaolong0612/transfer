package com.pg.account.sharding.infrastructure.client.acl;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.ExternalSystemException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.Sha1Util;
import com.pg.account.infrastructure.component.httpcliendutil.HttpClientComponent;
import com.pg.account.infrastructure.component.httpcliendutil.HttpResult;
import com.pg.account.sharding.domain.service.FetchAclService;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.constants.AccountConstants.UNION_ID;
import static com.pg.account.infrastructure.common.constants.AccountConstants.URL;

/**
 * @author Jack
 * @date 2021-04-22 16:06
 */
@Slf4j
@Component
public class FetchAclServiceImpl implements FetchAclService {
    public static final String ERR_CODE = "errcode";
    public static final String ERR_MSG = "errmsg";
    public static final String API_SECRET = "apiSecret";
    public static final String BRAND_ID = "brandId";
    public static final String METHOD_TYPE = "type";
    public static final String TIMESTAMP = "timestamp";
    public static final String SIGNATURE = "signature";
    private static final String TYPE = "get";
    private static final String OPEN_ID = "openid";
    private final HttpClientComponent httpClient;

    @Autowired
    public FetchAclServiceImpl(HttpClientComponent httpClient) {
        this.httpClient = httpClient;
    }

    @Override
    public String fetchUnionId(String tenantId, String channelId, String openId) {
        String unionId = null;
        Validate.notNull(tenantId, "getUnionId tenantId is null");
        Validate.notNull(channelId, "getUnionId channelId is null");
        Validate.notNull(openId, "getUnionId openId is null");
        // 获取请求 uri
        String uri = getAclUserInfoUri(tenantId, channelId, openId);
        try {
            Validate.notNull(uri, "acl uri is null");
            HttpResult httpResult = httpClient.get(uri);
            final int httpStatus = 200;
            log.warn("RequestAclHelper.getUnionId().Call Access Layer Return:[{}]", httpResult);
            if (httpResult.getStatus() != httpStatus || StringUtils.isEmpty(httpResult.getResponseBody())) {
                throw new ExternalSystemException(ResultEnum.ACL_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getMessage());
            }
            JSONObject jsonObject = parseObject(httpResult.getResponseBody());
            this.getErrorResult(jsonObject);
            if (jsonObject.containsKey(UNION_ID)) {
                unionId = jsonObject.getString(UNION_ID);
            }
        } catch (ExternalSystemException e) {
            log.warn("RequestAclHelper.getUnionId().Call Access Layer UserInfo Exception.", e);
            throw new ExternalSystemException(ResultEnum.ACL_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getMessage());
        } catch (Exception e) {
            log.warn("RequestAclHelper.getUnionId().Get Aclparam from Redis Exception. tenantId:{},channelId:{},openId:{}", tenantId, channelId, openId, e);
            throw new ExternalSystemException(ResultEnum.ACL_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getMessage());
        } finally {
            log.info("FetchAclServiceImpl-fetchUnionId.Request TenantId:{},ChannelId:{},OpenId:{}. Response UnionId:{}", tenantId, channelId, DesensitizedUtils.identification(openId), DesensitizedUtils.identification(unionId));
        }
        return Optional.ofNullable(unionId).filter(u -> !u.isEmpty()).orElseThrow(() -> new ExternalSystemException(ResultEnum.ACL_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getMessage()));
    }

    private String getAclUserInfoUri(String tenantId, String channelId, String openId) {
        String result = LocalCacheConfigUtils.getAclParam(tenantId, channelId);
        Validate.notNull(result, "acl config is null");
        JSONObject jsonObject = parseObject(result);
        String apiSecret = null;
        String brandId = null;
        String uri = null;
        //从redis取出的结果集中获取：apiSecret、brandId、uri
        if (jsonObject.containsKey(API_SECRET)) {
            apiSecret = jsonObject.getString(API_SECRET);
            Validate.notNull(apiSecret, "acl config apiSecret is null");
        }
        if (jsonObject.containsKey(BRAND_ID)) {
            brandId = jsonObject.getString(BRAND_ID);
            Validate.notNull(brandId, "acl config brandId is null");
        }
        if (jsonObject.containsKey(URL)) {
            uri = jsonObject.getString(URL);
            Validate.notNull(uri, "acl config uri is null");
        }
        String timestamp = String.valueOf(System.currentTimeMillis());
        // 组装出请求ACL 的userinfo接口的请求url
        List<String> list = new ArrayList<>();
        list.add(openId);
        list.add(apiSecret);
        list.add(TYPE);
        list.add(timestamp);
        Map<String, String> params = new HashMap<>(5);
        params.put(BRAND_ID, brandId);
        params.put(METHOD_TYPE, TYPE);
        params.put(TIMESTAMP, timestamp);
        params.put(OPEN_ID, openId);
        params.put(SIGNATURE, Sha1Util.sigOfSha1(list));
        //拼接参数
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : params.entrySet()) {
            String key = entry.getKey();
            sb.append(key).append('=').append(params.get(key)).append('&');
        }
        String paramStr = sb.substring(0, sb.length() - 1);
        Validate.notNull(uri);
        return uri.concat("?").concat(paramStr);
    }

    /**
     * getErrorResult
     *
     * @param jsonObject jsonObject
     */
    private void getErrorResult(JSONObject jsonObject) {
        if (jsonObject.containsKey(ERR_CODE)) {
            String errorCode = jsonObject.getString(ERR_CODE);
            String errMsg = null;
            if (jsonObject.containsKey(ERR_MSG)) {
                errMsg = jsonObject.getString(ERR_MSG);
            }
            log.warn("RequestAclHelper.getErrorResult()..Call Access Layer UserInfo response error.[errorcode={},errormsg={}]", errorCode, errMsg);
            throw new ExternalSystemException(ResultEnum.ACL_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ACL_MICRO_SERVICE_ERROR.getMessage());
        }
    }
}
