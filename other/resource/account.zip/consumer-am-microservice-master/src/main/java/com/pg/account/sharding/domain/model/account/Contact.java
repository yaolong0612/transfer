package com.pg.account.sharding.domain.model.account;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import java.util.Optional;

/**
 * 联系方式类
 *
 * @author dell
 */
@Data
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class Contact implements ValueObject<Contact> {
    private static final long serialVersionUID = 263017973028313126L;

    private String mobileCountryCode;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;

    @Override
    public boolean sameValueAs(Contact other) {
        return this.equals(other);
    }

    public void specialMobile(String mobile) {
        this.mobile = mobile;
    }

    public void specialEmail(String email) {
        this.email = email;
    }

    public void buildFromDb(Contact db) {
        Optional.ofNullable(db).ifPresent(c -> {
            this.mobileCountryCode = Optional.ofNullable(this.mobileCountryCode).orElse(db.mobileCountryCode);
            this.mobile = Optional.ofNullable(this.mobile).orElse(db.mobile);
            this.email = Optional.ofNullable(this.email).orElse(db.email);
        });
    }

    public static final class ContactBuilder {
        private String mobileCountryCode;
        @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
        private String mobile;
        @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
        private String email;

        private ContactBuilder() {
        }

        public static ContactBuilder aContact() {
            return new ContactBuilder();
        }

        public ContactBuilder mobileCountryCode(String mobileCountryCode) {
            this.mobileCountryCode = mobileCountryCode;
            return this;
        }

        public ContactBuilder mobile(String mobile) {
            this.mobile = mobile;
            return this;
        }

        public ContactBuilder email(String email) {
            this.email = email;
            return this;
        }

        public Contact build() {
            Contact contact = new Contact();
            contact.setMobileCountryCode(mobileCountryCode);
            contact.setMobile(mobile);
            contact.setEmail(email);
            return contact;
        }
    }
}
