package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.QueryAttributesCommand;
import com.pg.account.interfaces.dto.AttrDTO;
import com.pg.account.interfaces.dto.QueryAttributesDTO;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author yj
 */
@Component
public class QueryAttributesAssembler {

    /**
     * 将QueryAttributesCommand成account
     *
     * @param queryAttributesCommand queryAttributesCommand
     * @return Account
     */
    public Account toAccount(QueryAttributesCommand queryAttributesCommand) {
        return Account.AccountBuilder
                .anAccount()
                .tenantId(queryAttributesCommand.getTenantId().toString())
                .accountId(queryAttributesCommand.getMemberId())
                .build();
    }

    /**
     * 将account转换成QueryAttributesDTO
     *
     * @param account account
     * @return QueryAttributesDTO
     */
    public QueryAttributesDTO fromAccount(Account account) {
        List<AttrDTO> attrDTOList = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getExtraAttributeList)
                .filter(extraAttributes -> !extraAttributes.isEmpty())
                .ifPresent(attrs -> attrs.forEach(a -> {
                    AttrDTO attrDTO = new AttrDTO();
                    attrDTO.setAttrId(a.getAttrId());
                    attrDTO.setAttrVal(a.getAttrValue());
                    attrDTOList.add(attrDTO);
                }));
        List<AttrDTO> attrDTOList1 = attrDTOList.stream().sorted(Comparator.comparing(AttrDTO::getAttrId, Comparator.nullsLast(String::compareTo))).collect(Collectors.toList());
        return new QueryAttributesDTO(account.getAccountId(), attrDTOList1);
    }
}
