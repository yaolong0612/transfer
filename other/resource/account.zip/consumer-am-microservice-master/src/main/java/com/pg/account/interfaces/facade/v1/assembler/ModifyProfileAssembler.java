package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.ModifyProfileCommand;
import com.pg.account.interfaces.command.v2.AccountProfileModifyCommand;
import com.pg.account.sharding.domain.model.account.Account;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static com.pg.account.sharding.domain.model.account.CounterInfo.toCounterInfo;
import static com.pg.account.sharding.domain.model.account.EducationItem.toEducation;
import static com.pg.account.sharding.domain.model.account.ExtraAttributeItem.toAttr;
import static com.pg.account.sharding.domain.model.account.ExtraAttributeItem.toExtraAttributeItem;
import static com.pg.account.sharding.domain.model.account.HumanRelationItem.toHuman;
import static com.pg.account.sharding.domain.model.account.JobItem.toJob;
import static com.pg.account.sharding.infrastructure.client.address.Address.toAddress;
import static com.pg.account.sharding.infrastructure.client.address.Address.toAddressV2;

/**
 * @author lfx
 * @date 2021/6/9 15:29
 */
@Component
public class ModifyProfileAssembler {
    private ModifyProfileAssembler() {

    }

    public Account toAccount(ModifyProfileCommand command) {
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(command.getTenantId().toString())
                .accountId(command.getMemberId())
                .channelId(command.getChannelId().toString())
                .counter(toCounterInfo(command.getCounter()))
                .address(toAddress(command.getAddresses()))
                .extraAttrs(toExtraAttributeItem(command.getAttrs()));
        if (Optional.ofNullable(command.getProfile()).isPresent()) {
            accountBuilder.birthday(command.getProfile().getBirthday())
                    .gender(command.getProfile().getGender())
                    .fullName(Optional.ofNullable(command.getAddresses()).filter(a -> !a.isEmpty()).map(addressCommands -> addressCommands.get(0).getFullName()).orElse(null))
                    .mobile(command.getProfile().getCellphone())
                    .email(command.getProfile().getEmail())
                    .nickName(command.getProfile().getNickname());
        }
        return accountBuilder.build();
    }

    /**
     * @param tenant    tenant
     * @param channel   channel
     * @param accountId accountId
     * @param command   command
     * @return Account
     */
    public Account toAccount(Long tenant, Long channel, String accountId, AccountProfileModifyCommand command) {
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(tenant.toString())
                .channelId(channel.toString())
                .accountId(accountId)
                .openUid(command.getOpenId())
                .counter(toCounterInfo(command.getCounter()))
                .address(toAddressV2(command.getAddress()))
                .human(toHuman(command.getInterpersonalRelationships()))
                .education(toEducation(command.getEducations()))
                .job(toJob(command.getJobs()))
                .extraAttrs(toAttr(command.getAttributes()));

        if (Optional.ofNullable(command.getProfile()).isPresent()) {
            accountBuilder.birthday(command.getProfile().getBirthday())
                    .gender(command.getProfile().getGender())
                    .fullName(Optional.ofNullable(command.getAddress()).map(com.pg.account.interfaces.command.v2.AddressCommand::getFullName).orElse(null))
                    .mobile(command.getProfile().getMobile())
                    .email(command.getProfile().getEmail())
                    .nickName(command.getProfile().getNickname());
        }
        return accountBuilder.build();
    }
}
