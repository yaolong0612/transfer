package com.pg.account.infrastructure.common.exception;

import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.interfaces.ResultInterface;
import lombok.Getter;

/**
 * 自定义异常
 *
 * @author Jack Sun
 * @date 2019-11-25 15:47
 */
@Getter
public class ResultException extends RuntimeException {

    private static final long serialVersionUID = 2238193213706164956L;
    private final Integer code;
    private final Integer v2Code;

    private final String frontMessage;

    /**
     * 异常处理
     *
     * @param resultInterface resultInterface
     */
    public ResultException(ResultInterface resultInterface) {
        super(resultInterface.getMessage());
        this.code = resultInterface.getCode();
        this.v2Code = resultInterface.getV2Code();
        this.frontMessage = resultInterface.getFrontMessage();
    }

    /**
     * 异常处理
     *
     * @param resultEnum 异常状态枚举
     */
    public ResultException(ResultEnum resultEnum) {
        super(resultEnum.getMessage());
        this.code = resultEnum.getCode();
        this.v2Code = resultEnum.getV2Code();
        this.frontMessage = null;
    }

    /**
     * 异常处理
     *
     * @param code    状态码
     * @param message 提示信息
     */
    public ResultException(Integer code, Integer v2Code, String message) {
        super(message);
        this.code = code;
        this.v2Code = v2Code;
        this.frontMessage = null;
    }

    /**
     * 异常处理
     *
     * @param code         状态码
     * @param message      提示信息
     * @param frontMessage 前端提示消息
     */
    public ResultException(Integer code, String message, String frontMessage) {
        super(message);
        this.code = code;
        this.frontMessage = frontMessage;
        this.v2Code = null;
    }

}
