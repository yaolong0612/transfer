package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAttrEventBean implements Serializable {

    private static final long serialVersionUID = 3530136653216811500L;
    @JSONField(ordinal = 1)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 2)
    private Integer mpId;
    @JSONField(ordinal = 3)
    private Character updateFlag;
    @JSONField(ordinal = 5)
    private List<AttributeBean> attributes;
    @JSONField(ordinal = 6)
    private List<DependentBean> dependents;
    @JSONField(ordinal = 7)
    private Timestamp modifyTime;

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
