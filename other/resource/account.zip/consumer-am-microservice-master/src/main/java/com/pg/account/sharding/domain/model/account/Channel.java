package com.pg.account.sharding.domain.model.account;

import com.pg.account.sharding.domain.model.shared.ValueObject;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * 渠道信息表
 *
 * @author Jack
 * @date 2021/5/27 13:51
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Channel implements ValueObject<Channel> {
    private static final long serialVersionUID = -6796190012880028977L;
    private String channelId;
    private String channelLabel;
    private String brandCode;
    private String unionType;

    @Override
    public boolean sameValueAs(Channel other) {
        return this.getChannelId().equals(other.getChannelId());
    }

    public void build(ShardChannel shardChannel) {
        this.channelId = shardChannel.getChannelId();
        this.channelLabel = shardChannel.getChannelLabel();
        this.brandCode = shardChannel.getBrandCode();
        this.unionType = shardChannel.getUnionIdType();
    }

    public void buildFromDb(Channel db) {
        Optional.ofNullable(db).ifPresent(c -> {
            this.channelId = Optional.ofNullable(this.channelId).orElse(db.getChannelId());
            this.channelLabel = Optional.ofNullable(this.channelLabel).orElse(db.getChannelLabel());
            this.brandCode = Optional.ofNullable(this.brandCode).orElse(db.getBrandCode());
            this.unionType = Optional.ofNullable(this.unionType).orElse(db.getUnionType());
        });
    }

    public static final class ChannelBuilder {
        private String channelId;
        private String channelLabel;
        private String brandCode;
        private String unionType;

        private ChannelBuilder() {
        }

        public static ChannelBuilder aChannel() {
            return new ChannelBuilder();
        }

        public ChannelBuilder channelId(String channelId) {
            this.channelId = channelId;
            return this;
        }

        public ChannelBuilder channelLabel(String channelLabel) {
            this.channelLabel = channelLabel;
            return this;
        }

        public ChannelBuilder brandCode(String brandCode) {
            this.brandCode = brandCode;
            return this;
        }

        public ChannelBuilder unionType(String unionType) {
            this.unionType = unionType;
            return this;
        }

        public Channel build() {
            Channel channel = new Channel();
            channel.setChannelId(channelId);
            channel.setChannelLabel(channelLabel);
            channel.setBrandCode(brandCode);
            channel.setUnionType(unionType);
            return channel;
        }
    }
}
