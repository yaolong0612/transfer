package com.pg.account.infrastructure.common.advice;

import cn.com.pg.desenitize.infrastructure.desensitized.filter.DesensitizedSerializeFilter;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * @author Jack
 * @description
 * @date 2021/8/22 22:05
 * @modified Jack
 */
@ControllerAdvice
@Slf4j
public class LogResponseAdvice implements ResponseBodyAdvice<Object> {

    @Override
    public boolean supports(MethodParameter returnType, Class converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
        log.info("requestUrl:[{}]-[{}] response body:[{}]",request.getMethod(), request.getURI(), JSON.toJSONString(body, new DesensitizedSerializeFilter()));
        return body;
    }
}

