package com.pg.account.sharding.infrastructure.jpa.mapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author lfx
 * @date 2021/5/31 14:47
 */
public interface BindIdMappingDao extends JpaRepository<BindIdMapping, Long> {

    /**
     * 查询bindMap关系
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param bindId    bindId
     * @return BindIdMapping
     */
    BindIdMapping findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(String tenantId, String channelId, String bindId);

    /**
     * 根据租户、bindId和channelId删除绑定关系
     *
     * @param tenantId  tenantId
     * @param bindId    bindId
     * @param channelId channelId
     */
    @Modifying
    @Transactional
    void deleteByBindIdMapIdTenantIdAndBindIdMapIdBindIdAndBindIdMapIdChannelId(String tenantId, String bindId, String channelId);

    /**
     * 通过accountId查询bindIdMapping
     *
     * @param accountId accountId
     * @return list of bindIdMapping
     */
    List<BindIdMapping> findByAccountId(String accountId);

}
