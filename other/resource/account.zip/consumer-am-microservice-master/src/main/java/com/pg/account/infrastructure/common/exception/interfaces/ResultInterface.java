package com.pg.account.infrastructure.common.exception.interfaces;

/**
 * 结果枚举接口
 *
 * @author Jack Sun
 * @date 2019-11-25 15:21
 */
public interface ResultInterface {
    /**
     * 获取状态码
     *
     * @return 状态码
     */
    Integer getCode();

    /**
     * 获取V2状态码
     *
     * @return 状态码
     */
    Integer getV2Code();


    /**
     * 获取消息内容
     *
     * @return 提示信息
     */
    String getMessage();

    /**
     * 获取前端消息消息内容
     *
     * @return 前端提示信息
     */
    String getFrontMessage();

}
