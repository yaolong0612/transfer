package com.pg.account.sharding.application.event.listener;

import com.pg.account.sharding.application.event.*;
import com.pg.account.sharding.domain.service.AddAwardWrapperService;
import com.pg.account.sharding.domain.service.LoyaltyService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * @author Jack
 * @date 2021-04-28 21:06
 */
@Slf4j
@Component("shardIntegralNotifierListener")
public class IntegralNotifierListener {
    /**
     * loyalty 创建积分账号所需常量
     */
    public static final String REGISTER = "REGISTER";
    public static final String BINDING = "BINDING";
    /**
     * 会员修改加积分
     */
    public static final String COMPLETE_PROFILE = "COMPLETE_PROFILE";

    private final AddAwardWrapperService addAwardWrapperService;
    private final LoyaltyService loyaltyService;

    @Autowired
    public IntegralNotifierListener(AddAwardWrapperService addAwardWrapperService, LoyaltyService loyaltyService) {
        this.addAwardWrapperService = addAwardWrapperService;
        this.loyaltyService = loyaltyService;
    }


    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onRegisterEvent(RegisterEvent event) {
        Validate.notNull(event.getAccount(), "RegisterEvent account is null");
        loyaltyService.enrollAccount(event.getAccount(), null, REGISTER);
    }
    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onRegisterEvent(SignUpEvent event) {
        Validate.notNull(event.getAccount(), "SignUpEvent account is null");
        loyaltyService.enrollAccount(event.getAccount(), null, REGISTER);
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onRegisterBindEvent(RegisterBindEvent event) {
        Validate.notNull(event.getAccount(), "RegisterBindEvent account is null");
        Validate.notNull(event.getAccount(), "RegisterBindEvent account is null");
        loyaltyService.enrollAccount(event.getAccount(), event.getShardSocialAccount(), REGISTER);
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onBindingEvent(BindingEvent event) {
        Validate.notNull(event.getAccount(), "BindingEvent account is null");
        loyaltyService.enrollAccount(event.getAccount(), event.getShardSocialAccount(), BINDING);
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onFirstModifyProfileEvent(FirstModifyProfileEvent event) {
        Validate.notNull(event.getAccount(), "FirstModifyProfileEvent account is null");
        loyaltyService.addInteraction(event.getAccount(), COMPLETE_PROFILE);
    }
    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onFirstModifyProfileEvent(UpdateProfileEvent event) {
        Validate.notNull(event.getAccount(), "FirstModifyProfileEvent account is null");
        loyaltyService.addInteraction(event.getAccount(), COMPLETE_PROFILE);
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onOralbFirstModifyProfileEvent(OralbFirstModifyProfileEvent event) {
        Validate.notNull(event.getAccount(), "OralBFirstModifyProfileEvent account is null");
        Validate.notNull(event.getAttrId(), "OralBFirstModifyProfileEvent attrId is null");
        addAwardWrapperService.addFirstModifyPoints(event.getAccount().getTenantId(), event.getAccount().getRegisterChannelId(), event.getAccount().getAccountId());
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onOralbFirstSaveGoodsEvent(OralbFirstSaveGoodsEvent event) {
        Validate.notNull(event.getAccount(), "OralBFirstSaveEvent account is null");
        Validate.notNull(event.getAttrId(), "OralBFirstSaveEvent attrId is null");
        addAwardWrapperService.addFirstSaveGoodsPoints(event.getAccount().getTenantId(), event.getAccount().getRegisterChannelId(), event.getAccount().getAccountId());
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onBraunFirstSaveGoodsEvent(BraunFirstSaveGoodsEvent event) {
        Validate.notNull(event.getAccount(), "BraunFirstSaveEvent account is null");
        Validate.notNull(event.getAttrId(), "BraunFirstSaveEvent attrId is null");
        addAwardWrapperService.addFirstSaveGoodsPoints(event.getAccount().getTenantId(), event.getAccount().getRegisterChannelId(), event.getAccount().getAccountId());
    }

}
