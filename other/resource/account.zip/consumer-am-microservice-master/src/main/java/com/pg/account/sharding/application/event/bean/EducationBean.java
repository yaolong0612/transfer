package com.pg.account.sharding.application.event.bean;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 学历信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationBean implements Serializable {
    private static final long serialVersionUID = -5641526664772598211L;
    @JSONField(name = "relationship_name")
    private String relationshipName;
    @JSONField(name = "relationship_sequence")
    private String relationshipSequence;
    private String province;
    private String city;
    private String district;
    @JSONField(name = "school_address")
    private String schoolAddress;
    @JSONField(name = "school_name")
    private String schoolName;
    @JSONField(name = "school_category")
    private String schoolCategory;
    private String grade;
    @JSONField(name = "class")
    private String className;
    private String college;
    private String major;
    private String degree;
    @JSONField(name = "create_time")
    private Timestamp createTime;
    @JSONField(name = "modify_time")
    private Timestamp modifyTime;
}
