package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author LFX
 */
@ApiModel(value = "ProfileCommand_V2", description = "V2 interface ProfileCommand")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileCommand implements Serializable {

    private static final long serialVersionUID = 7368276921055524750L;
    @ApiModelProperty(value = "nickname", name = "nickname", example = "孙悟空")
    private String nickname;
    @ApiModelProperty(value = "性别，男：M，女：F，无：U", example = "U")
    @Pattern(regexp = GENDER_PATTERN, message = "gender format error")
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @ApiModelProperty(value = "生日，年满18岁，生日格式：yyyy-mm-dd", example = "1993-10-09")
    @Pattern(regexp = BIRTHDAY_VALID_PATTERN, message = "birthday format error")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @ApiModelProperty(value = "mobile phone number", name = "mobile", example = "15061837133")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "email", name = "email", example = "test@163.com")
    @Pattern(regexp = EMAIL_VALID_PATTERN, message = "email format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "full Name", name = "fullName", example = "孙悟空")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;

}
