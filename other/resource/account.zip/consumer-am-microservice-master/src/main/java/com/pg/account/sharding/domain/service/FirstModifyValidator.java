package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.sharding.application.event.FirstModifyProfileEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author sunliang
 */
@Component("shardFirstModifyValidator")
@Slf4j
public class FirstModifyValidator {

    /**
     * 检查数据是否首次保存
     *
     * @param attributes attributes
     * @return String
     */
    public String validator(ExtraAttributeItem attributes) {
        return attributes.getAttrValue();
    }

    /**
     * 执行添加积分事件
     *
     * @param account account
     * @param attrId  attrId
     */
    @Transactional(rollbackFor = Exception.class)
    public void runEvent(Account account, String attrId) {
        FirstModifyProfileEvent event = new FirstModifyProfileEvent(this, account, attrId);
        SpringContextUtil.getApplicationContext().publishEvent(event);
    }

}
