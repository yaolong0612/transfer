package com.pg.account.infrastructure.component.snowflake;

import com.pg.account.infrastructure.common.constants.SnowFlakeConstants;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Properties;

/**
 * 雪花算法生成UUID方法
 *
 * @author xusheng
 * @date 2019/12/22 19:21
 */
@Slf4j
public final class Snowflake implements Serializable {

    private static final long serialVersionUID = -2282650019490872043L;
    Properties properties = new Properties();
    /**
     * 当前机器码id
     */
    private long workerId;
    /**
     * 当前数据中心id
     */
    private long dataCenterId;
    /**
     * 序列
     */
    private long sequence = 0L;
    /**
     * 上一次时间戳
     */
    private long lastTimestamp = -1L;


    /**
     * 构造
     *
     * @param workerId     当前机器码ID
     * @param dataCenterId 数据中心ID
     */
    public Snowflake(long workerId, long dataCenterId) {
        /**
         * 最大支持机器节点数0~31，一共32个
         */
        if (workerId > SnowFlakeConstants.MAX_MACHINE_NUM || workerId < 0) {
            log.warn("workerId can't be greater than MAX_MACHINE_NUM or less than 0");
            throw new BusinessException(ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getCode(), ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getV2Code(), ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getMessage());
        }
        /**
         * 最大支持数据中心节点数0~31，一共32个
         */
        if (dataCenterId > SnowFlakeConstants.MAX_DATACENTER_NUM || dataCenterId < 0) {
            log.warn("dataCenterId can't be greater than MAX_DATACENTER_NUM or less than 0");
            throw new BusinessException(ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getCode(), ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getV2Code(), ResultEnum.BAI_DU_SNOWFLAKE_ALGORITHM_ERROR.getMessage());
        }
        this.workerId = workerId;
        this.dataCenterId = dataCenterId;
    }

    public Snowflake() {
    }

    /**
     * 获取机器id
     *
     * @return 所属机器的id
     */
    public long getWorkerId() {
        return this.workerId;
    }

    /**
     * 获取数据中心id
     *
     * @return 所属数据中心id
     */
    public long getDataCenterId() {
        return this.dataCenterId;
    }

    /**
     * 下一个ID
     *
     * @return ID
     */
    public synchronized long nextId() {
        //当前时间戳
        long nowStamp = getNowStamp();
        if (nowStamp < lastTimestamp) {
            // 如果服务器时间有问题(时钟后退) 报错。
            throw new IllegalStateException(String.format("Clock moved backwards. Refusing to generate id for %sms", lastTimestamp - nowStamp));
        }
        if (lastTimestamp == nowStamp) {
//            long sequenceMask = 4095L;
            sequence = (sequence + 1) & SnowFlakeConstants.MAX_SEQUENCE;
            if (sequence == 0) {
                nowStamp = getNextMill(lastTimestamp);
            }
        } else {
            sequence = 0L;
        }
        lastTimestamp = nowStamp;
        /**
         * (nowStmp - START_STMP) << TIMESTMP_LEFT  时间戳部分
         *
         * datacenterId << DATACENTER_LEFT  数据中心部分
         *
         * machineId << MACHINE_LEFT   机器标识部分
         *
         * sequence  序列号部分
         */
        return ((nowStamp - SnowFlakeConstants.START_STAMP) << SnowFlakeConstants.TIMESTMP_LEFT)
                | (dataCenterId << SnowFlakeConstants.DATACENTER_LEFT)
                | (workerId << SnowFlakeConstants.MACHINE_LEFT)
                | sequence;
    }


    /**
     * 获取下一个时间戳
     *
     * @param lastTimestamp 上次记录的时间
     * @return 下一个时间
     */
    private long getNextMill(long lastTimestamp) {
        long timestamp = getNowStamp();
        while (timestamp <= lastTimestamp) {
            timestamp = getNowStamp();
        }
        return timestamp;
    }

    /**
     * 生成时间戳
     *
     * @return 时间戳
     */
    private long getNowStamp() {
        return LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
    }

//    @Override
//    public Comparable<?> generateKey() {
//        return this.nextId();
//    }
//
//    @Override
//    public String getType() {
//        return "MY_SNOWFLAKE";
//    }
//
//    @Generated
//    @Override
//    public Properties getProperties() {
//        return this.properties;
//    }
//
//    @Generated
//    @Override
//    public void setProperties(Properties properties) {
//        this.properties = properties;
//    }
}
