package com.pg.account.interfaces.dto.v2;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.SPECIAL_CHARACTER_FILTERING_PATTERN;

/**
 * 学历信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel(value = "EducationDTO_V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationDTO implements Serializable {
    private static final long serialVersionUID = -5641526664772598211L;
    @ApiModelProperty(value = "relationshipId 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationshipId", example = "101")
    private String relationshipId;
    @ApiModelProperty(value = "relationshipName 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationshipName", example = "自己")
    private String relationshipName;
    @ApiModelProperty(value = "relationshipSequence Sequence limit, the default is 1. Others such as relationshipId: (108: son, 109: daughter, 110: grandson, 111: granddaughter,etc) limit to 2 births, you can fill in 2, up to 5", name = "relationshipSequence", example = "2")
    private String relationshipSequence;
    @ApiModelProperty(value = "province", name = "province", example = "江苏省")
    private String province;
    @ApiModelProperty(value = "city", name = "city", example = "无锡市")
    private String city;
    @ApiModelProperty(value = "district", name = "district", example = "滨湖区")
    private String district;
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "schoolAddress cannot contains special characters")
    @ApiModelProperty(value = "schoolAddress", name = "schoolAddress", example = "方庙路118号")
    private String schoolAddress;
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "schoolName cannot contains special characters")
    @ApiModelProperty(value = "schoolName", name = "schoolName", example = "太湖格至小学")
    private String schoolName;
    @ApiModelProperty(value = "schoolCategory", name = "schoolCategory", example = "小学")
    private String schoolCategory;
    @ApiModelProperty(value = "grade", name = "grade", example = "一年级")
    private String grade;
    @ApiModelProperty(value = "className", name = "className", example = "一班")
    private String className;
    @ApiModelProperty(value = "college", name = "college", example = "计算机与软件学院")
    private String college;
    @ApiModelProperty(value = "major", name = "major", example = "计算机软件工程")
    private String major;
    @ApiModelProperty(value = "degree", name = "degree", example = "学士")
    private String degree;
    @ApiModelProperty(value = "admissionTime", name = "admissionTime", example = "2020-09")
    private String admissionTime;
    @ApiModelProperty(value = "graduationTime", name = "graduationTime", example = "2020-06")
    private String graduationTime;
}
