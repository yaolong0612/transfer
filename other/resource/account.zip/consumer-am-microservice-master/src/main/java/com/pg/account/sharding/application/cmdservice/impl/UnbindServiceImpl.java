package com.pg.account.sharding.application.cmdservice.impl;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.enums.SubscriptionsStatusEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.sharding.application.cmdservice.UnbindService;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.UnBindingEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.domain.service.BindSocialAccountService;
import com.pg.account.sharding.domain.service.SubscriptionsService;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.DeleteMappingService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.*;

import static com.pg.account.sharding.domain.service.StringValidator.channelValid;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.*;

/**
 * @author lfx
 * @date 2022/1/10 14:11
 */
@Service
public class UnbindServiceImpl implements UnbindService {

    public static final String UNION_TYPE = "1";
    public static final String CHANNEL_ID = "2";
    public static final String ALL = "3";

    private final ShardSocialAccountRepository shardSocialAccountRepository;
    private final BindSocialAccountService bindSocialAccountService;
    private final SubscriptionRepository subscriptionRepository;
    private final SubscriptionsService subscriptionsService;

    private final DeleteMappingService deleteMappingService;
    private final FetchMappingService fetchMappingService;

    @Autowired
    public UnbindServiceImpl(ShardSocialAccountRepository shardSocialAccountRepository,
                             BindSocialAccountService bindSocialAccountService,
                             SubscriptionRepository subscriptionRepository, SubscriptionsService subscriptionsService,
                             DeleteMappingService deleteMappingService, FetchMappingService fetchMappingService) {
        this.shardSocialAccountRepository = shardSocialAccountRepository;
        this.bindSocialAccountService = bindSocialAccountService;
        this.subscriptionRepository = subscriptionRepository;
        this.subscriptionsService = subscriptionsService;
        this.deleteMappingService = deleteMappingService;
        this.fetchMappingService = fetchMappingService;
    }

    /**
     * 解绑
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String unBind(String tenant, String channel, String type, String unBindRoute, String query) {
        channelValid(tenant, channel);
        String accountId = Optional.ofNullable(this.getAccountId(tenant, type, channel, query)).orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
        ShardSocialAccount dbShardSocialAccount = Optional.ofNullable(shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId)).orElse(new ShardSocialAccount(new IdentityId(tenant, accountId), new ArrayList<>()));
        List<SocialAccountItem> socialAccountItems = Optional.of(dbShardSocialAccount).map(ShardSocialAccount::getSocialAccountList).orElse(new ArrayList<>());
        List<SocialAccountItem> removeItems = new ArrayList<>();
        if (unBindRoute.equals(UNION_TYPE)) {
            String unionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getFrontMessage()));
            //根据unionType解绑
            assembleBindByUnionIdType(tenant, socialAccountItems, unionIdType, removeItems);
        } else if (unBindRoute.equals(CHANNEL_ID)) {
            //channelId解绑
            assembleShardSocialAccountAndMappingByChannel(socialAccountItems, channel, removeItems);
        }
        //删除bindIdMapping 和 unionIdMapping
        removeBind(dbShardSocialAccount, removeItems);
        return accountId;
    }

    @Override
    public JSONObject unBindAll(Account account) {
        JSONObject jsonObject = new JSONObject();
        Optional.ofNullable(shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.tenantId(), account.accountId())).ifPresent(bind -> {
            deleteMappingService.deleteAllBinding(account.accountId(), account.tenantId());
            bind.setSocialAccountList(Collections.emptyList());
            ShardSubscription dbShardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(bind.tenantId(), bind.accountId());
            Optional.ofNullable(dbShardSubscription)
                    .map(ShardSubscription::getSubscriptionList)
                    .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                    .ifPresent(subscriptionItemList -> subscriptionItemList.forEach(subscriptionItem -> subscriptionItem.setOptStatus(SubscriptionsStatusEnum.OUT.getValue())));
            subscriptionsService.delete(dbShardSubscription);
            shardSocialAccountRepository.save(bind);
            jsonObject.put(SOCIAL_ACCOUNT, bind);
            jsonObject.put(SUBSCRIPTION, dbShardSubscription);
        });
        return jsonObject;

    }

    /**
     * 根据route解绑
     *
     * @param tenant    tenant
     * @param channel   channel
     * @param accountId accountId
     * @param route     route route = 1 按照unionType解绑 route = 2 按照channelId解绑 route = 3 全解绑
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void unBind(String tenant, String channel, String accountId, String route) {
        ShardSocialAccount dbShardSocialAccount = Optional.ofNullable(shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId)).orElse(new ShardSocialAccount(new IdentityId(tenant, accountId), new ArrayList<>()));
        List<SocialAccountItem> socialAccountItems = Optional.of(dbShardSocialAccount).map(ShardSocialAccount::getSocialAccountList).orElse(new ArrayList<>());
        List<SocialAccountItem> removeItems = new ArrayList<>();
        switch (route) {
            case UNION_TYPE:
                String unionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
                //根据unionType解绑
                assembleBindByUnionIdType(tenant, socialAccountItems, unionIdType, removeItems);
                break;
            case CHANNEL_ID:
                //channelId解绑
                assembleBindByChannel(socialAccountItems, channel, removeItems);
                break;
            case ALL:
                removeItems = socialAccountItems;
                dbShardSocialAccount.setSocialAccountList(Collections.emptyList());
                break;
            default:
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        //删除bindIdMapping 和 unionIdMapping
        removeBind(dbShardSocialAccount, removeItems);
    }


    /**
     * 根据UnionType 删除socialAccountItem数据
     * 汇总删除的unionId和bindId
     *
     * @param tenant             tenant
     * @param socialAccountItems socialAccountItems
     * @param unionType          unionType
     */
    private void assembleBindByUnionIdType(String tenant, List<SocialAccountItem> socialAccountItems, String unionType, List<SocialAccountItem> removeItemList) {
        Iterator<SocialAccountItem> socialAccountItemIterator = socialAccountItems.iterator();
        while (socialAccountItemIterator.hasNext()) {
            SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
            String eachUnionType = Optional.ofNullable(socialAccountItem.getChannel()).map(Channel::getUnionType)
                    .filter(StringUtils::isNotBlank)
                    .orElse(LocalCacheConfigUtils.getChannelUnionIdType(tenant, socialAccountItem.getChannelId()));
            if (unionType.equals(eachUnionType)) {
                removeItemList.add(socialAccountItem);
                socialAccountItemIterator.remove();
            }
        }
    }

    /**
     * 根据ChannelId 删除socialAccountItem数据
     * 汇总删除的unionId和bindId
     *
     * @param socialAccountItems socialAccountItems
     * @param channelId          channelId
     */
    private void assembleShardSocialAccountAndMappingByChannel(List<SocialAccountItem> socialAccountItems, String channelId, List<SocialAccountItem> removeItemList) {
        Iterator<SocialAccountItem> socialAccountItemIterator = socialAccountItems.iterator();
        while (socialAccountItemIterator.hasNext()) {
            SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
            Channel channel = Optional.ofNullable(socialAccountItem.getChannel()).orElseThrow(() -> new BusinessException(V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(),
                    V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getFrontMessage()));
            if (channelId.equals(channel.getChannelId())) {
                removeItemList.add(socialAccountItem);
                socialAccountItemIterator.remove();
            }
        }
    }

    /**
     * 根据ChannelId 删除socialAccountItem数据
     * 汇总删除的unionId和bindId
     *
     * @param socialAccountItems socialAccountItems
     * @param channelId          channelId
     */
    private void assembleBindByChannel(List<SocialAccountItem> socialAccountItems, String channelId, List<SocialAccountItem> removeItemList) {
        Iterator<SocialAccountItem> socialAccountItemIterator = socialAccountItems.iterator();
        while (socialAccountItemIterator.hasNext()) {
            SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
            Channel channel = Optional.ofNullable(socialAccountItem.getChannel()).orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(),
                    ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
            if (channelId.equals(channel.getChannelId())) {
                removeItemList.add(socialAccountItem);
                socialAccountItemIterator.remove();
            }
        }
    }

    private void removeBind(ShardSocialAccount dbShardSocialAccount, List<SocialAccountItem> removeItem) {
        //删UnionMapping
        ShardSocialAccount shardSocialAccount = deleteMappingService.deleteAllBinding(dbShardSocialAccount.getAccountId(), dbShardSocialAccount.getTenantId(), dbShardSocialAccount, removeItem);
        ShardSubscription dbShardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(dbShardSocialAccount.tenantId(), dbShardSocialAccount.accountId());
        for (SocialAccountItem item : removeItem) {
            //删订阅
            String bindOptIdByChannel = LocalCacheConfigUtils.getOptIdByChannel(dbShardSocialAccount.tenantId(), item.getChannelId());
            Optional.ofNullable(dbShardSubscription)
                    .map(ShardSubscription::getSubscriptionList)
                    .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                    .ifPresent(subscriptionItemList -> subscriptionItemList.forEach(subscriptionItem -> {
                        if (subscriptionItem.getOptId().equals(bindOptIdByChannel)) {
                            subscriptionItem.setOptStatus(SubscriptionsStatusEnum.OUT.getValue());
                        }
                    }));
        }
        Optional.ofNullable(dbShardSubscription).ifPresent(subscriptionsService::delete);
        bindSocialAccountService.delete(dbShardSocialAccount);

        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, shardSocialAccount.tenantId(), shardSocialAccount.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UnBindingEvent unBindingEvent = new UnBindingEvent(this, dbShardSubscription, shardSocialAccount, false, "D");
                SpringContextUtil.getApplicationContext().publishEvent(unBindingEvent);
            }
        });
    }

    /**
     * 通过各种情况查询accountId
     *
     * @param tenant  tenant
     * @param type    type
     * @param channel channel
     * @param query   query
     * @return accountId
     */
    private String getAccountId(String tenant, String type, String channel, String query) {
        String accountId;
        switch (type) {
            case MOBILE:
                // 判断是否是手机号格式
                if (!StringValidUtil.isMobile(query)) {
                    throw new BusinessException(V3ResultEnum.INCORRECT_MOBILE.getCode(), V3ResultEnum.INCORRECT_MOBILE.getMessage(), V3ResultEnum.INCORRECT_MOBILE.getFrontMessage());
                }
                // 根据手机号查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(tenant, query)).map(MobileMapping::getAccountId).orElse(null);
                break;
            case BIND_ID:
                // 判断channel是否存在 不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(V3ResultEnum.INCORRECT_CHANNEL_ID.getCode(), V3ResultEnum.INCORRECT_CHANNEL_ID.getMessage(), V3ResultEnum.INCORRECT_CHANNEL_ID.getFrontMessage()));
//                根据channel和bindId查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenant, query, channel)).map(BindIdMapping::getAccountId).orElse(null);
                break;
            case UNION_ID:
                // 判断channel是否存在，如果不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(V3ResultEnum.INCORRECT_QUERY_PARAM.getCode(), V3ResultEnum.INCORRECT_QUERY_PARAM.getMessage(), V3ResultEnum.INCORRECT_QUERY_PARAM.getFrontMessage()));
                // 根据租户和渠道查询unionType，如果不存在则报错
                String channelUnionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage()));
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenant, query, channelUnionIdType)).map(UnionIdMapping::getAccountId).orElse(null);
                break;
            case ACCOUNT_ID:
                // 如果是通过accountId查询则将query赋值给accountId
                accountId = query;
                break;
            default:
                throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        return accountId;
    }
}