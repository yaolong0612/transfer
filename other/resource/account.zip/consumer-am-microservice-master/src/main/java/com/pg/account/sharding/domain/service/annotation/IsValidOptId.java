package com.pg.account.sharding.domain.service.annotation;


import com.pg.account.sharding.domain.service.SubscriptionBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 判断邮箱是否有效（没有被他人使用）
 *
 * @author lfx
 * @date 2021/4/23 16:17
 */

@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = SubscriptionBaseValidator.OptIdValid.class)
public @interface IsValidOptId {

    String message() default "optId is not exist or repeat optId";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
