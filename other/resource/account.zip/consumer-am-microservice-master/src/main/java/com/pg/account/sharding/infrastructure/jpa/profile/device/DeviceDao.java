package com.pg.account.sharding.infrastructure.jpa.profile.device;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author yj
 */
public interface DeviceDao extends JpaRepository<ShardDevice, Long> {

    /**
     * 根据tenantId和accountId查询device信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return DeviceInfo
     */
    ShardDevice findByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);


    /**
     * 根据租户和会员删除
     *
     * @param tenantId    tenantId
     * @param accountId accountId
     */
    @Modifying
    @Transactional
    void deleteByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);
}
