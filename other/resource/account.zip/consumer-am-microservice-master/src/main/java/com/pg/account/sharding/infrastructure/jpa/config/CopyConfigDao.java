package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 查询租户和渠道是否存在同步配置
 *
 * @author xusheng
 * @date 2021/6/11 11:16
 */
public interface CopyConfigDao extends JpaRepository<ShardCopyConfig, Long> {

    /**
     * 根据租户和渠道判断是否需要同步到LA
     *
     * @param oTenantId  oTenantId
     * @param oChannelId oChannelId
     * @return com.pg.account.sharding.infrastructure.jpa.config.ShardCopyConfig
     * @author xusheng
     * @date 2021/8/12 14:54
     */
    ShardCopyConfig findByOldTenantIdAndOldChannelId(String oTenantId, String oChannelId);
}
