package com.pg.account.infrastructure.common.enums;

/**
 * @author JackSun
 * @date 2017/2/21
 */
public enum SubscriptionsStatusEnum {
    /**
     * 订阅状态
     */
    IN("I"), OUT("O");
    private final String value;

    /**
     * @param value value
     */
    SubscriptionsStatusEnum(String value) {
        this.value = value;
    }

    /**
     * @return String
     */
    public String getValue() {
        return value;
    }
}
