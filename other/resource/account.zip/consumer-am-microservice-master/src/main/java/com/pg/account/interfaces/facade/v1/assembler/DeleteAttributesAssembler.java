package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.DeleteAttributesCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author yj
 */
@Component
public class DeleteAttributesAssembler {

    public Account toAccount(DeleteAttributesCommand deleteAttributesCommand) {
        List<ExtraAttributeItem> extraAttributeItemList = new ArrayList<>();
        if (Optional.ofNullable(deleteAttributesCommand.getAttrId()).filter(d -> !d.isEmpty()).isPresent()) {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(deleteAttributesCommand.getAttrId());
            extraAttributeItemList.add(extraAttributeItem);
        }
        Account.AccountBuilder accountBuilder = Account.AccountBuilder.anAccount()
                .tenantId(deleteAttributesCommand.getTenantId().toString())
                .accountId(deleteAttributesCommand.getMemberId())
                .extraAttrs(extraAttributeItemList);
        if (Optional.ofNullable(deleteAttributesCommand.getChannelId()).isPresent()) {
            accountBuilder.channelId(deleteAttributesCommand.getChannelId().toString());
        }
        return accountBuilder.build();
    }
}
