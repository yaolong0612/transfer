package com.pg.account.interfaces.vo.v3;

import lombok.*;

import java.io.Serializable;

/**
 * @author lfx
 * @date 2022/2/23 16:05
 */
@Data
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class V3Result implements Serializable {
    private static final long serialVersionUID = 5261505353619487203L;
    /**
     * 状态码
     */
    private Integer code;
    /**
     * 提示信息
     */
    private String msg;

}
