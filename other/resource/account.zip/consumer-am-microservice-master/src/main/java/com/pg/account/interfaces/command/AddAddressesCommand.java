package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddAddressesCommand implements Serializable {
    private static final long serialVersionUID = 5981573058699296774L;

    @ApiModelProperty(value = "租户ID", example = "10003", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @NotNull(message = "missing memberId")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @Valid
    @ApiModelProperty(value = "地址集合", required = true)
    private List<AddressCommand> addressBeanList;


}
