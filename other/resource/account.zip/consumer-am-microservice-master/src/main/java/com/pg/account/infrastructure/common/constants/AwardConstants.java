package com.pg.account.infrastructure.common.constants;

/**
 * AwardConstants
 *
 * @author Jack Sun
 * @date 2019-6-24 15:35
 */
public class AwardConstants {

    public static final String URL = "url";
    public static final String METHOD = "method";
    public static final String API_SECRET = "apiSecret";
    public static final String API_KEY = "apiKey";
    public static final String LOYALTY_TYPE = "loyaltyType";
    /**
     * Result
     */
    public static final String RESULT = "result";
    /**
     * error
     */
    public static final String ERROR = "error";
    /**
     * object
     */
    public static final String OBJECT = "object";
    /**
     * totalPoint
     */
    public static final String TOTAL_POINT = "totalPoint";
    /**
     * point
     */
    public static final String POINT = "point";

    private AwardConstants() {
        //私有构造方法
    }
}
