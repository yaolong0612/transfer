package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.interfaces.command.AccountConflictCommand;
import org.apache.commons.lang.StringUtils;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Optional;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author guye
 * @version 1.0
 * @date 2022/1/13 17:16
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = MoreThanOneParam.AccountConflictValidator.class)
public @interface MoreThanOneParam {
    String message() default "mobile,bindId,unionId最少传入两项参数";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class AccountConflictValidator implements ConstraintValidator<MoreThanOneParam, @Valid AccountConflictCommand> {

        @Override
        public boolean isValid(AccountConflictCommand accountConflictCommand, ConstraintValidatorContext constraintValidatorContext) {
            int paramNum = 0;
            if (StringUtils.isNotBlank(accountConflictCommand.getMobile())) {
                paramNum++;
            }
            if (StringUtils.isNotBlank(accountConflictCommand.getBindId())) {
                paramNum++;
            }
            if (StringUtils.isNotBlank(accountConflictCommand.getUnionId())) {
                paramNum++;
            }
            return paramNum > 1;
        }
    }
}
