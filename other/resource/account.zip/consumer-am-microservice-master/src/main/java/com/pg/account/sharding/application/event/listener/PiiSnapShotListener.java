package com.pg.account.sharding.application.event.listener;

import com.microsoft.azure.storage.ResultSegment;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.UUIDUtils;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.application.event.ChangeCounterEvent;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.bean.SavePIIFailBean;
import com.pg.account.sharding.application.event.dao.SavePIIFailBeanDao;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import com.pg.account.sharding.infrastructure.retention.sb.consumer.StreamUtil;
import com.pg.account.sharding.infrastructure.tablestorage.PIICounterDirEntity;
import com.pg.account.sharding.infrastructure.tablestorage.PiiSnapShotTolerantEntity;
import com.pg.account.sharding.infrastructure.tablestorage.PiiTolerantDirEntity;
import com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Optional;

/**
 * @author mrluve
 */
@Component
@Slf4j
public class PiiSnapShotListener {
    public static final String PII_TOLERANT_DIR_ENTITY = "PIITolerantDir";
    public static final String COUNTER_PII_DIR_ENTITY = "PIICounterDir";

    private final TableStorageUtils<PiiSnapShotTolerantEntity> piiTsUtils;
    private final TableStorageUtils<PiiTolerantDirEntity> piiDirUtils;
    private final TableStorageUtils<PIICounterDirEntity> piiCounterUtils;
    private final UidGenerator uidGenerator;
    private final SavePIIFailBeanDao savePIIFailBeanDao;
    private final StreamUtil streamUtil;

    @Autowired
    public PiiSnapShotListener(TableStorageUtils<PiiSnapShotTolerantEntity> piiTsUtils, TableStorageUtils<PiiTolerantDirEntity> piiDirUtils, TableStorageUtils<PIICounterDirEntity> piiCounterUtils,
                               UidGenerator uidGenerator, SavePIIFailBeanDao savePIIFailBeanDao, StreamUtil streamUtil) {
        this.piiTsUtils = piiTsUtils;
        this.piiDirUtils = piiDirUtils;
        this.piiCounterUtils = piiCounterUtils;
        this.uidGenerator = uidGenerator;
        this.savePIIFailBeanDao = savePIIFailBeanDao;
        this.streamUtil = streamUtil;
    }

    /**
     * 删除缓存中account信息
     *
     * @param event event
     */
    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ClearCacheEvent event) {
        if (Optional.ofNullable(event).isPresent() && Optional.ofNullable(event.getTenant()).isPresent() && Optional.ofNullable(event.getAccountId()).isPresent()) {
            RedisConfigUtils.clearProfileCache(event.getTenant(), event.getAccountId());
            int mp = LocalCacheConfigUtils.getMarketingProgramId(event.getTenant());
            writeToTs(event.getTenant(), String.valueOf(mp), event.getAccountId(), String.valueOf(false));
        }
    }

    /**
     * 监听counter改变
     *
     * @param event
     */
    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ChangeCounterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            saveToTs(event);
        }
    }

    /**
     * counter信息保存到TS
     *
     * @param event
     */
    public void saveToTs(ChangeCounterEvent event) {
        if (Optional.ofNullable(event.getAccount()).isPresent()) {
            boolean sendFlag = false;
            int sendCount = 0;
            Calendar now = Calendar.getInstance();
            int month = now.get(Calendar.MONTH) + 1;
            int day = now.get(Calendar.DATE);
            String date = now.get(Calendar.YEAR) + "" + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day);
            String name = "PIICounterSnapShot" + date;
            String tableName = name.replace("_", "");
            int mp = LocalCacheConfigUtils.getMarketingProgramId(event.getAccount().getTenantId());
            PiiSnapShotTolerantEntity piiSnapShotTolerantEntity = new PiiSnapShotTolerantEntity(date, UUIDUtils.generateUuid(), String.valueOf(mp), event.getAccount().getTenantId(), event.getAccount().getAccountId(), "false", DateUtil.formatLocalDateTimeToT(LocalDateTime.now()));
            try {
                piiDirUtils.createTableIfNotExist(COUNTER_PII_DIR_ENTITY);
                ResultSegment<PIICounterDirEntity> dirName = piiCounterUtils.queryByPartitionKey(COUNTER_PII_DIR_ENTITY, PIICounterDirEntity.class, date);
                PIICounterDirEntity result;
                if (dirName.getResults().isEmpty()) {
                    result = new PIICounterDirEntity(date, UUIDUtils.generateUuid(), tableName, DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), "false");
                } else {
                    result = dirName.getResults().get(0);
                    result.setStatus("false");
                }
                while (!sendFlag) {
                    try {
                        piiCounterUtils.saveOrUpdate(COUNTER_PII_DIR_ENTITY, result);
                        piiTsUtils.createTableIfNotExist(tableName);
                        piiTsUtils.save(tableName, piiSnapShotTolerantEntity);
                        sendFlag = true;
                    } catch (Exception e) {
                        sendCount++;
                        log.info("第{}次发送Counter信息到TS失败：tenantId：{},accountId：{}", sendCount, event.getAccount().getTenantId(), event.getAccount().getAccountId(), e);
                        if (sendCount > 3) {
                            throw new Exception(e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                log.info("发送柜台数据失败,存入DB容错表,tenantId:{},accountId:{}", event.getAccount().getTenantId(), event.getAccount().getAccountId(), e);
                String errMsg = "SendPiiCounterError -> doBusiness error";
                streamUtil.sendKpi(V3ResultEnum.SEND_PII_Counter_ERROR.getCode(), errMsg, "SendPiiCounter_doBusiness");
                SavePIIFailBean savePIIFailBean = new SavePIIFailBean(uidGenerator.getUid(), date, UUIDUtils.generateUuid(), String.valueOf(mp), String.valueOf(event.getAccount().getTenantId()), event.getAccount().getAccountId(), "false", "counter", LocalDateTime.now(), LocalDateTime.now());
                try {
                    savePIIFailBeanDao.save(savePIIFailBean);
                } catch (Exception ee) {
                    log.info("插入PII信息容错表失败,{}", savePIIFailBean.toString(), ee);
                }

            }

        }
    }


    /**
     * 写入到ts中
     *
     * @param tenant    tenant
     * @param mp        mp
     * @param accountId accountId
     * @param status    status
     */
    public void writeToTs(String tenant, String mp, String accountId, String status) {
        boolean sendFlag = false;
        int sendCount = 0;
        Calendar now = Calendar.getInstance();
        int month = now.get(Calendar.MONTH) + 1;
        int day = now.get(Calendar.DATE);
        String date = now.get(Calendar.YEAR) + "" + (month < 10 ? "0" + month : month) + (day < 10 ? "0" + day : day);
        String name = "PIISnapShotTolerant" + date;
        String tableName = name.replace("_", "");
        PiiSnapShotTolerantEntity piiSnapShotTolerantEntity = new PiiSnapShotTolerantEntity(date, UUIDUtils.generateUuid(), mp, tenant, accountId, status, DateUtil.formatLocalDateTimeToT(LocalDateTime.now()));
        try {
            piiDirUtils.createTableIfNotExist(PII_TOLERANT_DIR_ENTITY);
            ResultSegment<PiiTolerantDirEntity> dirName = piiDirUtils.queryByPartitionKey(PII_TOLERANT_DIR_ENTITY, PiiTolerantDirEntity.class, date);
            PiiTolerantDirEntity result;
            if (dirName.getResults().isEmpty()) {
                result = new PiiTolerantDirEntity(date, UUIDUtils.generateUuid(), tableName, DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), DateUtil.formatLocalDateTimeToT(LocalDateTime.now()), status);
            } else {
                result = dirName.getResults().get(0);
                result.setStatus(status);
            }
            while (!sendFlag) {
                try {
                    piiDirUtils.saveOrUpdate(PII_TOLERANT_DIR_ENTITY, result);
                    piiTsUtils.createTableIfNotExist(tableName);
                    piiTsUtils.save(tableName, piiSnapShotTolerantEntity);
                    sendFlag = true;
                } catch (Exception e) {
                    sendCount++;
                    log.info("第{}次发送Counter信息到TS失败：tenantId：{},accountId：{}", sendCount, tenant, accountId, e);
                    if (sendCount > 3) {
                        throw new Exception(e.getMessage());
                    }
                }
            }

        } catch (Exception e) {
            log.info("发送Account数据失败,存入DB容错表,tenantId:{},accountId:{}", tenant, accountId, e);
            String errMsg = "SendPiiAccountError -> doBusiness error";
            streamUtil.sendKpi(V3ResultEnum.SEND_PII_ACCOUNT_ERROR.getCode(), errMsg, "SendPiiAccount_doBusiness");
            SavePIIFailBean savePIIFailBean = new SavePIIFailBean(uidGenerator.getUid(), date, UUIDUtils.generateUuid(), String.valueOf(mp), tenant, accountId, "false", "account", LocalDateTime.now(), LocalDateTime.now());
            try {
                savePIIFailBeanDao.save(savePIIFailBean);
            } catch (Exception ee) {
                log.info("插入PII信息容错表失败,{}", savePIIFailBean.toString(), ee);
            }
        }
    }
}
