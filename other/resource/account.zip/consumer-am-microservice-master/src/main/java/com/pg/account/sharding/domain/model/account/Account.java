package com.pg.account.sharding.domain.model.account;

import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.PasswordUtils;
import com.pg.account.infrastructure.common.utils.UUIDUtils;
import com.pg.account.sharding.domain.model.shared.Entity;
import com.pg.account.sharding.infrastructure.client.address.Address;

import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang.Validate;

import javax.persistence.EmbeddedId;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Account聚合根
 * 用于存储账户信息
 *
 * @author Jack
 * @date 2021/5/27 13:02
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Account implements Entity<Account>, Serializable {
    private static final long serialVersionUID = 7351118771094447690L;
    protected AccountStatus accountStatus;
    @EmbeddedId
    private IdentityId identityId;
    private String openUid;
    private Security security;
    private Registration registration;
    private UserBasicInfo userBasicInfo;
    private UserAdditionalInfo userAdditionalInfo;
    private Address address;
    private CounterInfo counter;

    public Account(IdentityId identityId, Security security, Registration registration, UserBasicInfo userBasicInfo, UserAdditionalInfo userAdditionalInfo, Address address, CounterInfo counter) {
        Validate.notNull(identityId, "userId is null");
        this.identityId = identityId;
        this.security = security;
        this.registration = registration;
        this.userBasicInfo = userBasicInfo;
        this.userAdditionalInfo = userAdditionalInfo;
        this.address = address;
        this.counter = counter;
    }

    @Override
    public boolean sameIdentityAs(Account other) {
        return other != null && this.identityId.getAccountId().equals(other.getIdentityId().getAccountId());
    }

    public void build(String openUid, Registration registration, UserAdditionalInfo userAdditionalInfo) {
        this.openUid = openUid;
        this.registration = registration;
        this.userAdditionalInfo = userAdditionalInfo;
    }


    public void specialNewOpenUid() {
        this.openUid = String.valueOf(RedisConfigUtils.nextOpenId());
    }

    public void specialIdentityId(IdentityId identityId) {
        Validate.notNull(identityId, "userId is null");
        this.identityId = identityId;
    }

    /**
     * 激活账户
     */
    public void activeStatus() {
        this.accountStatus = AccountStatus.ACTIVE;
    }

    /**
     * 失效账户
     */
    public void inActiveStatus() {
        this.accountStatus = AccountStatus.INACTIVE;
    }

    /**
     * 删除账户
     */
    public void deleteStatus() {
        this.accountStatus = AccountStatus.DELETED;
    }

    /**
     * 检查状态是否有效
     */
    public void activeStatusCheck() {
        if (this.accountStatus != AccountStatus.ACTIVE) {
            throw new BusinessException(ResultEnum.ACCOUNT_STATUS_IS_INVALID.getCode(), ResultEnum.ACCOUNT_STATUS_IS_INVALID.getV2Code(), ResultEnum.ACCOUNT_STATUS_IS_INVALID.getMessage());
        }
    }


    /**
     * 添加安全信息
     *
     * @param security security
     */
    public void security(Security security) {
        Validate.notNull(security, "security is null");
        this.security = security;
    }

    /**
     * 添加注册信息
     */
    public void registration(Registration registration) {
        Validate.notNull(registration, "registration is null");
        this.registration = registration;
    }

    public void userBasicInfo(UserBasicInfo userBasicInfo) {
        this.userBasicInfo = userBasicInfo;
    }

    /**
     * 校验密码
     *
     * @param security security
     * @return 密码是否正确
     */
    public boolean validatePassword(Security security) {
        return this.security == security;
    }

    /**
     * 获取手机号
     *
     * @return 手机号
     */
    @JSONField(serialize = false)
    public String getMobile() {
        return Optional.ofNullable(this.userBasicInfo).map(UserBasicInfo::getContact).map(Contact::getMobile).orElse(null);
    }

    /**
     * 获取email
     *
     * @return email
     */
    @JSONField(serialize = false)
    public String getEmail() {
        return Optional.ofNullable(this.userBasicInfo).map(UserBasicInfo::getContact).map(Contact::getEmail).orElse(null);
    }

    /**
     * 获取租户id
     *
     * @return tenantId
     */
    @JSONField(serialize = false)
    public String getTenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElseThrow(() -> new BusinessException(ResultEnum.TENANT_CONFIG_NOT_EXIST.getCode(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getMessage()));
    }

    /**
     * 获取用户id
     *
     * @return accountId
     */
    @JSONField(serialize = false)
    public String getAccountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
    }

    @JSONField(serialize = false)
    public String getRegisterChannelId() {
        return Optional.ofNullable(this.registration).map(Registration::getChannel).map(Channel::getChannelId).orElse(null);
    }

    public Security security(String password) {
        Validate.notNull(password, "password is null");
        String salt = UUIDUtils.generateUuid();
        String encryptedCode = PasswordUtils.encrypt(password.concat(salt));
        LocalDateTime expiredTime = LocalDateTime.now();
        return Security.registerFrom(salt, encryptedCode, expiredTime);
    }

    public void checkPassword(String password) {
        Validate.notNull(password, "password is null");
        this.security.checkPassword(password);
    }

    public void specialNewAccountId() {
        Validate.notNull(this.identityId, "identityId is null");
        this.identityId.specialNewAccountId();
    }


    /**
     * 获取用户id
     *
     * @return accountId
     */
    public String accountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
    }

    /**
     * 获取租户id
     *
     * @return tenantId
     */
    public String tenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElseThrow(() -> new BusinessException(V3ResultEnum.TENANT_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.TENANT_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.TENANT_CONFIG_NOT_EXIST.getFrontMessage()));
    }

    public static final class AccountBuilder {
        private final IdentityId.IdentityIdBuilder identityIdBuilder = IdentityId.IdentityIdBuilder.anIdentityId();
        private final Registration.RegistrationBuilder registrationBuilder = Registration.RegistrationBuilder.aRegistration();
        private final UserBasicInfo.UserBasicInfoBuilder userBasicInfoBuilder = UserBasicInfo.UserBasicInfoBuilder.anUserBasicInfo();
        private final UserAdditionalInfo.UserAdditionalInfoBuilder userAdditionalInfoBuilder = UserAdditionalInfo.UserAdditionalInfoBuilder.anUserAdditionalInfo();
        protected AccountStatus accountStatus;
        private IdentityId identityId;
        private String openUid;
        private Security security;
        private Registration registration;
        private UserBasicInfo userBasicInfo;
        private UserAdditionalInfo userAdditionalInfo;
        private Address address;
        private CounterInfo counter;

        private AccountBuilder() {
        }

        public static AccountBuilder anAccount() {
            return new AccountBuilder();
        }

        public static AccountBuilder anAccount(Account account) {
            return new AccountBuilder()
                    .accountStatus(account.getAccountStatus())
                    .identityId(account.getIdentityId())
                    .openUid(account.getOpenUid())
                    .security(account.getSecurity())
                    .registration(account.getRegistration())
                    .userBasicInfo(account.getUserBasicInfo())
                    .userAdditionalInfo(account.getUserAdditionalInfo())
                    .counter(account.getCounter())
                    .address(account.getAddress());
        }

        public AccountBuilder identityId(IdentityId identityId) {
            this.identityId = identityId;
            return this;
        }

        public AccountBuilder tenantId(String tenantId) {
            Validate.notNull(tenantId, "tenantId is null");
            this.identityId = identityIdBuilder.tenantId(tenantId).build();
            return this;
        }

        public AccountBuilder accountId(String accountId) {
            Validate.notNull(accountId, "accountId is null");
            this.identityId = identityIdBuilder.accountId(accountId).build();
            return this;
        }

        public AccountBuilder openUid(String openUid) {
            // TODO 2021-09-29 注释，等openUID补齐再开启
//            Validate.notNull(openUid, "openUid is null");
            this.openUid = openUid;
            return this;
        }

        public AccountBuilder security(Security security) {
            Validate.notNull(security, "security is null");
            this.security = security;
            return this;
        }

        public AccountBuilder password(String password) {
            Validate.notNull(password, "password is null");
            Security.SecurityBuilder securityBuilder = Security.SecurityBuilder.aSecurity()
                    .salt(UUIDUtils.generateUuid())
                    .expiredTime(LocalDateTime.now());
            securityBuilder.encryptedCode(PasswordUtils.encrypt(password.concat(securityBuilder.getSalt())));
            this.security = securityBuilder.build();
            return this;
        }

        public AccountBuilder migratePassword(String encryptedCode, String salt) {
            Validate.notNull(encryptedCode, "password is null");
            Security.SecurityBuilder securityBuilder = Security.SecurityBuilder.aSecurity()
                    .expiredTime(LocalDateTime.now());
            securityBuilder.encryptedCode(encryptedCode);
            securityBuilder.salt(salt);
            this.security = securityBuilder.build();
            return this;
        }

        public AccountBuilder registration(Registration registration) {
            Validate.notNull(registration, "registration is null");
            this.registration = registration;
            return this;
        }

        public AccountBuilder registration(String source, Channel channel, String customer, String regStore, LocalDateTime localDateTime) {
            Validate.notNull(source, "source is null");
            Validate.notNull(channel, "channel is null");
            this.registration = registrationBuilder
                    .source(source)
                    .channel(channel)
                    .customer(customer, regStore)
                    .registerTime(localDateTime)
                    .build();
            return this;
        }

        public AccountBuilder registration(Channel channel) {
            Validate.notNull(channel, "channel is null");
            this.registration = registrationBuilder
                    .channel(channel)
                    .build();
            return this;
        }

        public AccountBuilder userBasicInfo(UserBasicInfo userBasicInfo) {
            this.userBasicInfo = userBasicInfo;
            return this;
        }

        public AccountBuilder mobile(String mobile) {
            this.userBasicInfo = userBasicInfoBuilder.contactMobile(mobile).build();
            return this;
        }

        public AccountBuilder birthday(String birthday) {
            this.userBasicInfo = userBasicInfoBuilder.birthday(birthday).build();
            return this;
        }

        public AccountBuilder gender(String gender) {
            this.userBasicInfo = userBasicInfoBuilder.gender(gender).build();
            return this;
        }

        public AccountBuilder nickName(String nickname) {
            this.userBasicInfo = userBasicInfoBuilder.nickName(nickname).build();
            return this;
        }

        public AccountBuilder fullName(String fullName) {
            this.userBasicInfo = userBasicInfoBuilder.fullName(fullName).build();
            return this;
        }

        public AccountBuilder email(String email) {
            this.userBasicInfo = userBasicInfoBuilder.contactEmail(email).build();
            return this;
        }

        public AccountBuilder contact(Contact contact) {
            if (Optional.ofNullable(contact).isPresent()) {
                this.userBasicInfo = userBasicInfoBuilder.contact(contact).build();
            }
            return this;
        }

        public AccountBuilder education(List<EducationItem> educationItems) {
            this.userAdditionalInfo = userAdditionalInfoBuilder.educationList(educationItems).build();
            return this;
        }

        public AccountBuilder job(List<JobItem> jobItems) {
            this.userAdditionalInfo = userAdditionalInfoBuilder.jobList(jobItems).build();
            return this;
        }

        public AccountBuilder human(List<HumanRelationItem> humanRelationItems) {
            this.userAdditionalInfo = userAdditionalInfoBuilder.humanRelationList(humanRelationItems).build();
            return this;
        }

        public AccountBuilder userAdditionalInfo(UserAdditionalInfo userAdditionalInfo) {
            this.userAdditionalInfo = userAdditionalInfo;
            return this;
        }

        public AccountBuilder device(DeviceInfo device) {
            this.userAdditionalInfo = userAdditionalInfoBuilder.device(device).build();
            return this;
        }

        public AccountBuilder extraAttrs(List<ExtraAttributeItem> extraAttributeItems) {
            this.userAdditionalInfo = userAdditionalInfoBuilder.extraAttributeList(extraAttributeItems).build();
            return this;
        }


        public AccountBuilder address(Address address) {
            this.address = address;
            return this;
        }

        public AccountBuilder counter(CounterInfo counter) {
            this.counter = counter;
            return this;
        }

        public AccountBuilder accountStatus(AccountStatus accountStatus) {
            this.accountStatus = accountStatus;
            return this;
        }

        public AccountBuilder channelId(String channelId) {
            Validate.notNull(channelId, "channelId is null");
            this.registration = registrationBuilder
                    .channelId(channelId)
                    .build();
            return this;
        }

        public Account build() {
            Account account = new Account();
            account.setIdentityId(identityId);
            account.setOpenUid(openUid);
            account.setSecurity(security);
            account.setRegistration(registration);
            account.setUserBasicInfo(userBasicInfo);
            account.setUserAdditionalInfo(userAdditionalInfo);
            account.setAddress(address);
            account.setCounter(counter);
            account.setAccountStatus(accountStatus);
            return account;
        }

    }
}