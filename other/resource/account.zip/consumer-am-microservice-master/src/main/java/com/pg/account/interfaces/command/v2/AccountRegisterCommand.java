package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.CounterCommand;
import com.pg.account.interfaces.command.DeviceCommand;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Set;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * 注册绑定请求参数类
 *
 * @author Jack Sun
 * @date 2019-11-25 17:32
 */
@ApiModel(value = "AccountRegisterCommand_V2", description = "V2 interface AccountRegisterCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisterCommand implements Serializable {

    private static final long serialVersionUID = -5613671508974077586L;
    @ApiModelProperty(value = "Registration type, 1, registration, 2, registration binding", name = "type", example = "1", required = true)
    @Pattern(regexp = REGISTER_TYPE_PATTERN, message = "registration type is error")
    private String type;
    @ApiModelProperty(value = "Username (will override the mobile phone number in the profile)", name = "username", example = "15061837133", required = true)
    @NotBlank(message = "missing username")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String username;
    @ApiModelProperty(value = "password", name = "password", example = "123qwe", required = true)
    @NotBlank(message = "missing password")
    @Length(min = 6, message = "password is less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String password;
    @ApiModelProperty(value = "Registration source, need to apply for configuration", name = "source", example = "WECHAT", required = true)
    @NotBlank(message = "missing registration source")
    private String source;
    @ApiModelProperty(value = "Register Store", name = "regStore", example = "大润发")
    private String regStore;
    @ApiModelProperty(value = "Customer, Apply when docking with AM", name = "customer", example = "PG")
    private String customer;
    @ApiModelProperty(value = "Third party social binding ID", name = "bindId", example = "testBindID1234567890")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "The third party's social platform account unique identifier is used to associate the social binding ID", name = "unionId", example = "testUnionID1234567890")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    @ApiModelProperty(value = "User Information", name = "profile")
    @Valid
    private ProfileCommand profile;
    @ApiModelProperty(value = "Device Information", name = "device")
    private DeviceCommand device;
    @ApiModelProperty(value = "Counter Information", name = "counter")
    private CounterCommand counter;
    @ApiModelProperty(value = "Address Information", name = "address")
    @Valid
    private AddressCommand address;
    @ApiModelProperty(value = "Subscription Information Collection", name = "subscriptions")
    @Valid
    private Set<SubscriptionCommand> subscriptions;
    @ApiModelProperty(value = "User Attribute Information Collection", name = "attributes")
    @Valid
    private Set<AttributeCommand> attributes;
    @ApiModelProperty(value = "User Job Information Collection", name = "jobs")
    @Valid
    private Set<JobCommand> jobs;
    @ApiModelProperty(value = "User education Information Collection", name = "educations")
    @Valid
    private Set<EducationCommand> educations;
    @ApiModelProperty(value = "User interpersonalRelationship Information Collection", name = "interpersonalRelationships")
    @Valid
    private Set<InterpersonalRelationshipCommand> interpersonalRelationships;
    private String registerRoute;

    /**
     * 给Profile的mobile字段指定为username的参数值
     */
    public void specifyMobile() {
        if (null == this.profile) {
            this.profile = new ProfileCommand();
        }
        if (StringUtils.isNotBlank(this.username)) {
            if (isMobile(username) && isMobileLength(username)) {
                this.profile.setMobile(this.username);
            } else {
                throw new BusinessException(ResultEnum.USER_NAME_FORMAT_ERROR.getCode(), ResultEnum.USER_NAME_FORMAT_ERROR.getV2Code(), ResultEnum.USER_NAME_FORMAT_ERROR.getMessage());
            }
        }
    }

    /**
     * 给Profile的email字段指定为username的参数值
     */
    public void specifyEmail() {
        if (null == this.profile) {
            this.profile = new ProfileCommand();
        }
        if (StringUtils.isNotBlank(this.username)) {
            if (isEmail(username)) {
                this.profile.setEmail(this.username);
            } else {
                throw new BusinessException(ResultEnum.USER_NAME_FORMAT_ERROR.getCode(), ResultEnum.USER_NAME_FORMAT_ERROR.getV2Code(), ResultEnum.USER_NAME_FORMAT_ERROR.getMessage());
            }
        }
    }

    /**
     * 给unionId字段指定为username的参数值
     */
    public void specifyUnionId() {
        if (StringUtils.isNotBlank(this.username)) {
            if (this.username.equalsIgnoreCase(this.unionId)) {
                this.setUnionId(this.username);
            } else {
                throw new BusinessException(ResultEnum.USER_NAME_VALUE_ERROR.getCode(), ResultEnum.USER_NAME_VALUE_ERROR.getV2Code(), ResultEnum.USER_NAME_VALUE_ERROR.getMessage());
            }
        }
    }

    /**
     * 冗余一下fullName
     * address中fullName为空则用profile里的fullName
     *
     * @param fullName 姓名
     */
    public void specifyAddressFullName(String fullName) {
        if (null == this.address) {
            this.address = new AddressCommand();
        }
        if (StringUtils.isBlank(this.address.getFullName())) {
            this.address.setFullName(fullName);
        }
    }
}