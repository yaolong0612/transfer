package com.pg.account.interfaces.command;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.I_O_PATTERN;

/**
 * @author JackSun
 * @date 2016/12/27
 */
@ApiModel(value = "SubscriptionCommand_V1", description = "V1 interface SubscriptionCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionCommand implements Serializable {
    private static final long serialVersionUID = -3426039431041199677L;
    @ApiModelProperty(value = "订阅ID", example = "103", required = true)
    @NotBlank(message = "missing subscription type")
    private String optId;
    @ApiModelProperty(value = "订阅状态(I或者O)", example = "I", required = true)
    @NotBlank(message = "subscription status does not exist")
    @Pattern(regexp = I_O_PATTERN, message = "subscription status does not exist")
    private String optStatus;

}
