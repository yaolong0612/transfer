package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegProfileEventBean implements Serializable {

    private static final long serialVersionUID = -5574938717679983018L;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 1)
    private Integer mpId;
    @JSONField(ordinal = 2)
    private Character updateFlag;
    @JSONField(ordinal = 3)
    private String brand;
    @JSONField(ordinal = 4)
    private String channel;
    @JSONField(ordinal = 5)
    private String source;
    @JSONField(ordinal = 6)
    private Timestamp regTime;
    @JSONField(ordinal = 7)
    private String customer;
    @JSONField(ordinal = 8)
    private String store;

    @JSONField(ordinal = 11)
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @JSONField(ordinal = 12)
    private String nickName;
    @JSONField(ordinal = 13)
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @JSONField(ordinal = 14)
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthdate;
    @JSONField(ordinal = 15)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @JSONField(ordinal = 16)
    @Desensitized(value = DesensitizedEnum.MOBILE_PHONE)
    private String mobile;
    @JSONField(ordinal = 17)
    private String mobileSha256;
    @JSONField(ordinal = 18)
    private String province;
    @JSONField(ordinal = 19)
    private String city;
    @JSONField(ordinal = 20)
    private String district;
    @JSONField(ordinal = 21)
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @JSONField(ordinal = 22)
    private String zipCode;
    @JSONField(ordinal = 23)
    private String deviceId;
    @JSONField(ordinal = 24)
    private String deviceType;
    @JSONField(ordinal = 25)
    private List<AttributeBean> attributes;
    @JSONField(ordinal = 26)
    private List<DependentBean> dependents;
    @JSONField(ordinal = 27)
    private List<OptBean> opts;
    @JSONField(ordinal = 28)
    private List<JobBean> jobs;
    @JSONField(ordinal = 29)
    private List<EducationBean> educations;
    @JSONField(ordinal = 30)
    private List<HumanRelationBean> humanRelations;
    @JSONField(ordinal = 31)
    private Timestamp createTime;
    @JSONField(ordinal = 32)
    private Timestamp modifyTime;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

}
