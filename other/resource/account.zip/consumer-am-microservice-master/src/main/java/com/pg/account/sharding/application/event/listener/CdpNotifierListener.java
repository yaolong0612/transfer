package com.pg.account.sharding.application.event.listener;

import com.alibaba.fastjson.JSON;
import com.pg.account.infrastructure.common.enums.ConfigStatusEnum;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.application.event.*;
import com.pg.account.sharding.application.event.bean.servicebus.*;
import com.pg.account.sharding.application.event.cdp.CdpListener;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.config.*;
import com.pg.account.sharding.infrastructure.servicebus.ServiceBusQueueTopicEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM;
import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD;
import static java.lang.String.valueOf;

/**
 * @author lvyanlin
 */
@Component("CdpNotifierListener")
@Slf4j
public class CdpNotifierListener {
    @Value("${event_hub.retryCount}")
    private int retryCount;
    public static final String ATTR_ID = "113000001";
    public static final String PAMPERS = "10003";
    public static final String UPDATED = "U";
    public static final String DELETED = "D";
    public static final String STATUS_I = "I";
    public static final String STATUS_O = "O";

    private final ShardSocialAccountRepository socialAccountRepository;
    private final ChannelDao channelDao;
    private final TermsDao termsDao;
    private final TermsVersionDao termsVersionDao;
    private final AccountInfoDao accountInfoDao;


    private final CdpListener cdpListener;


    public CdpNotifierListener(ShardSocialAccountRepository socialAccountRepository,
                               ChannelDao channelDao,
                               TermsDao termsDao,
                               TermsVersionDao termsVersionDao,
                               AccountInfoDao accountInfoDao,
                               CdpListener cdpListener) {
        this.socialAccountRepository = socialAccountRepository;
        this.channelDao = channelDao;
        this.termsDao = termsDao;
        this.termsVersionDao = termsVersionDao;
        this.accountInfoDao = accountInfoDao;
        this.cdpListener = cdpListener;
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SignUpEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            List<SocialAccountItem> socialAccountItems = Optional.ofNullable(event.getShardSocialAccount()).map(ShardSocialAccount::getSocialAccountList).filter(a -> !a.removeIf(b -> StringUtils.isBlank(b.getBindId()) && StringUtils.isBlank(b.getUnionId()))).orElse(null);
            Optional.ofNullable(event.getShardSocialAccount()).ifPresent(bind -> {
                if (Optional.ofNullable(socialAccountItems).isPresent()) {
                    bind.setSocialAccountList(socialAccountItems);
                    this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
                }
            });
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterBindEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ActiveEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.activeAccountEvent(event.getAccount());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(InActiveEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.inActiveAccountEvent(event.getAccount());
        }
    }


    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(BindingEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            List<SocialAccountItem> socialAccountItems = Optional.ofNullable(event.getShardSocialAccount()).map(ShardSocialAccount::getSocialAccountList).filter(a -> a.stream().anyMatch(b -> StringUtils.isNotBlank(b.getBindId()) || StringUtils.isNotBlank(b.getUnionId()))).orElse(null);
            Optional.ofNullable(event.getShardSocialAccount()).ifPresent(bind -> {
                if (Optional.ofNullable(socialAccountItems).isPresent()) {
                    bind.setSocialAccountList(socialAccountItems);
                    this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
                }
            });
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UnBindingEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.deletedBindSocialAccountEvent(event.getShardSocialAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateProfileEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateProfileEvent(event.getAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
            this.updateCounterEvent(event.getAccount());
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateCounterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateSubscriptionEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SmsUpdateSubscriptionEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateAttributeEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateAttributeToDMPEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(DeleteAttributeEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), DELETED);
        }
    }

    @Async("cdpThreadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ConflictEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateProfileEvent(event.getAccount());
            this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    /**
     * RegProfileEvent 消息发送，发给DMP
     *
     * @param account,shardSubscription account对象
     */
    private void regProfileEvent(Account account, ShardSubscription shardSubscription) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        RegProfileEventBean regProfileEventBean = new RegProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                Optional.ofNullable(account.getAccountId()).ifPresent(regProfileEventBean::setAccountId);
                regProfileEventBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                regProfileEventBean.inserted();
                Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getBrandCode).ifPresent(regProfileEventBean::setBrand);
                Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelLabel).ifPresent(regProfileEventBean::setChannel);
                Optional.ofNullable(account.getRegistration()).map(Registration::getSource).ifPresent(regProfileEventBean::setSource);
                Optional.ofNullable(account.getRegistration()).map(Registration::getRegisterTime).ifPresent(t -> {
                    regProfileEventBean.setRegTime(Timestamp.valueOf(t));
                    regProfileEventBean.setCreateTime(Timestamp.valueOf(t));
                });
                //2019年3月6日添加regStore和customer
                Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getRegStore).ifPresent(regProfileEventBean::setStore);
                Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getName).ifPresent(regProfileEventBean::setCustomer);
                Optional.ofNullable(account.getUserBasicInfo()).ifPresent(basicInfo -> {
                    //NickName 无业务场景使用，不需要传到DMP，在2018年7月13日确定设为null值
                    regProfileEventBean.setNickName(null);
                    regProfileEventBean.setGender(basicInfo.getGender());
                    regProfileEventBean.setBirthdate(formatBirthday(basicInfo));
                    //Email 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
                    regProfileEventBean.setEmail(null);
                    Optional.ofNullable(basicInfo.getContact()).map(Contact::getMobile).ifPresent(mobile -> {
                        regProfileEventBean.setMobile(mobile);
                        //添加SHA256加密和手机前6位
                        regProfileEventBean.setMobileSha256(DigestUtils.sha256Hex(mobile));
                    });
                });
                //初始化device信息
                this.setDeviceInfo(account, regProfileEventBean);
                this.setAddressInfo(account, regProfileEventBean);
                regProfileEventBean.setJobs(this.setJobInfo(account));
                regProfileEventBean.setEducations(this.setEducationInfo(account));
                regProfileEventBean.setHumanRelations(this.setHumanRelation(account));
                Optional.ofNullable(account.getUserAdditionalInfo())
                        .map(UserAdditionalInfo::getExtraAttributeList)
                        .filter(extraAttributeItems -> !extraAttributeItems.isEmpty())
                        .ifPresent(extraAttributeItems -> {
                            regProfileEventBean.setAttributes(attributeBeans(extraAttributeItems));
                            regProfileEventBean.setDependents(this.babyInfo(account.getTenantId(), extraAttributeItems));
                        });
                Optional.ofNullable(shardSubscription)
                        .map(ShardSubscription::getSubscriptionList)
                        .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                        .ifPresent(subscriptionItemList -> regProfileEventBean.setOpts(optBeans(shardSubscription.getTenantId(), subscriptionItemList)));
                result = cdpListener.send(ServiceBusQueueTopicEnum.REG_PROFILE_ACCOUNT, regProfileEventBean, "CdpListener_regProfileEvent_sendServiceBus", count);
            } catch (Exception e) {
                log.error("regProfileEvent error,account is:{}", JSON.toJSONString(account), e);
            }
        }

    }

    /**
     * @param basicInfo basicInfo
     * @return String
     */
    private String formatBirthday(UserBasicInfo basicInfo) {
        return StringUtils.isNotBlank(basicInfo.getBirthday()) ? DateUtil.toString(DateUtil.formDate(basicInfo.getBirthday(), YYYY_MM_DD), YYYY_MM) : null;
    }

    /**
     * 初始化工作信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<JobBean> setJobInfo(Account account) {
        List<JobBean> jobBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getJobList)
                .filter(jobItems -> !jobItems.isEmpty())
                .ifPresent(jobItems -> jobItems.forEach(jobItem -> {
                    String relationshipName = Optional.ofNullable(jobItem.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).orElse(null);
                    JobBean jobBean = new JobBean();
                    jobBean.setRelationType(relationshipName);
                    Optional.ofNullable(jobItem.getRelation()).map(Relation::getSequence).ifPresent(jobBean::setRelationSeq);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getProvince).ifPresent(jobBean::setProvince);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getCity).ifPresent(jobBean::setCity);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(jobBean::setDistrict);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(jobBean::setAddress);
                    Optional.ofNullable(jobItem.getName()).ifPresent(jobBean::setName);
                    Optional.ofNullable(jobItem.getCategory()).ifPresent(jobBean::setCategory);
                    Optional.ofNullable(jobItem.getProfession()).ifPresent(jobBean::setProfession);
                    jobBean.setZipCode(jobItem.getAddress().getPostCode());
                    jobBean.setCreateTime(Optional.ofNullable(jobItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    jobBean.setModifyTime(Optional.ofNullable(jobItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    jobBeans.add(jobBean);
                }));
        return jobBeans;
    }


    /**
     * 初始化监护人信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<HumanRelationBean> setHumanRelation(Account account) {
        List<HumanRelationBean> humanRelationBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getHumanRelationList)
                .filter(humanRelationItems -> !humanRelationItems.isEmpty())
                .ifPresent(humanRelationItems -> humanRelationItems.forEach(humanRelationItem -> {
                    String relationshipName = humanRelationItem.getRelation().getRelationType().getRelationName();
                    String cellphone = humanRelationItem.getPerson().getContact().getMobile();
                    HumanRelationBean humanRelationBean = new HumanRelationBean();
                    humanRelationBean.setRelationType(relationshipName);
                    humanRelationBean.setMobile(cellphone);
                    Optional.ofNullable(humanRelationItem.getRelation()).map(Relation::getSequence).ifPresent(humanRelationBean::setRelationSeq);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getFullName).ifPresent(humanRelationBean::setFullName);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getBirthday).ifPresent(humanRelationBean::setBirthday);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getGender).ifPresent(humanRelationBean::setGender);
                    Optional.ofNullable(humanRelationItem.getGuardian()).ifPresent(humanRelationBean::setGuardian);
                    Optional.ofNullable(humanRelationItem.getCreateTime()).ifPresent(t -> humanRelationBean.setCreateTime(Timestamp.valueOf(t)));
                    Optional.ofNullable(humanRelationItem.getUpdateTime()).ifPresent(t -> humanRelationBean.setModifyTime(Timestamp.valueOf(t)));
                    humanRelationBean.setCreateTime(Optional.ofNullable(humanRelationItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    humanRelationBean.setModifyTime(Optional.ofNullable(humanRelationItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));

                    humanRelationBeans.add(humanRelationBean);
                }));
        return humanRelationBeans;
    }


    /**
     * 初始化教育信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<EducationBean> setEducationInfo(Account account) {
        List<EducationBean> educationBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getEducationList)
                .filter(educationItems -> !educationItems.isEmpty())
                .ifPresent(educationItems -> educationItems.forEach(educationItem -> {
                    // 这里修改是因为现在不通过redis获取
                    String relationshipName = Optional.ofNullable(educationItem.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).orElse(null);
                    EducationBean educationBean = new EducationBean();
                    educationBean.setRelationType(relationshipName);
                    Optional.ofNullable(educationItem.getRelation()).map(Relation::getSequence).ifPresent(educationBean::setRelationSeq);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getProvince).ifPresent(educationBean::setProvince);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(educationBean::setAddress);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getCity).ifPresent(educationBean::setCity);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(educationBean::setDistrict);
                    Optional.ofNullable(educationItem.getName()).ifPresent(educationBean::setName);
                    Optional.ofNullable(educationItem.getCategory()).ifPresent(educationBean::setCategory);
                    Optional.ofNullable(educationItem.getGrade()).ifPresent(educationBean::setGrade);
                    Optional.ofNullable(educationItem.getClassName()).ifPresent(educationBean::setClassName);
                    Optional.ofNullable(educationItem.getCollege()).ifPresent(educationBean::setCollege);
                    Optional.ofNullable(educationItem.getMajor()).ifPresent(educationBean::setMajor);
                    Optional.ofNullable(educationItem.getDegree()).ifPresent(educationBean::setDegree);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getPostCode).ifPresent(educationBean::setZipCode);
                    Optional.ofNullable(educationItem.getAdmissionTime()).ifPresent(educationBean::setAdmissionTime);
                    Optional.ofNullable(educationItem.getGraduationTime()).ifPresent(educationBean::setGraduationTime);
                    educationBean.setCreateTime(Optional.ofNullable(educationItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    educationBean.setModifyTime(Optional.ofNullable(educationItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    educationBeans.add(educationBean);
                }));
        return educationBeans;
    }
    /**
     * 初始化device信息
     *
     * @param account             account对象
     * @param regProfileEventBean regProfileEventBean对象
     */
    private void setDeviceInfo(Account account, RegProfileEventBean regProfileEventBean) {
        //DeviceID 2018年11月26日添加 2019年3月6日重新设计
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getDevice)
                .ifPresent(deviceInfo -> {
                    regProfileEventBean.setDeviceType(deviceInfo.getOs());
                    if (StringUtils.isNotBlank(deviceInfo.getDeviceId())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getDeviceId());
                    } else if (StringUtils.isNotBlank(deviceInfo.getIdfa())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getIdfa());
                    } else if (StringUtils.isNotBlank(deviceInfo.getImei())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getImei());
                    } else if (StringUtils.isNotBlank(deviceInfo.getOaid())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getOaid());
                    }
                });
    }


    /**
     * 初始化device信息
     *
     * @param account               updatedBindSocialAccountEvent对象
     * @param bindSocialAccountBean bindSocialAccountBean对象
     */
    private void setDeviceInfo(Account account, BindSocialAccountBean bindSocialAccountBean) {
        //DeviceID 2018年11月26日添加 2019年3月6日重新设计 2020年5月18日支持绑定收集
        Optional.ofNullable(account)
                .map(Account::getUserAdditionalInfo)
                .map(UserAdditionalInfo::getDevice)
                .ifPresent(deviceInfo -> {
                    bindSocialAccountBean.setDeviceType(deviceInfo.getOs());
                    if (StringUtils.isNotBlank(deviceInfo.getDeviceId())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getDeviceId());
                    } else if (StringUtils.isNotBlank(deviceInfo.getIdfa())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getIdfa());
                    } else if (StringUtils.isNotBlank(deviceInfo.getImei())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getImei());
                    } else if (StringUtils.isNotBlank(deviceInfo.getOaid())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getOaid());
                    }
                });
    }


    /**
     * 初始化地址信息
     *
     * @param account             account对象
     * @param regProfileEventBean regProfileEventBean对象
     */
    private void setAddressInfo(Account account, RegProfileEventBean regProfileEventBean) {
        Optional.ofNullable(account.getAddress()).ifPresent(address -> {
            //fullName 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            regProfileEventBean.setFullName(address.getFullName());
            //address 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            regProfileEventBean.setAddress(address.getAddress());

            regProfileEventBean.setProvince(address.getProvince());
            regProfileEventBean.setCity(address.getCity());
            regProfileEventBean.setDistrict(address.getDistrict());
            regProfileEventBean.setZipCode(address.getPostcode());
        });
    }


    /**
     * 订阅信息组装
     *
     * @param subscriptionItemList 账号聚合参数
     * @return List<OptBean>
     */
    private List<OptBean> optBeans(String tenantId, List<SubscriptionItem> subscriptionItemList) {
        List<OptBean> opts = new ArrayList<>();
        for (SubscriptionItem subscriptionItem : subscriptionItemList) {
            OptBean optBean = new OptBean();
            optBean.setId(subscriptionItem.getOptId());
            optBean.setValue(subscriptionItem.getOptName());
            Optional.ofNullable(subscriptionItem.getTermsList())
                    .filter(termList -> !termList.isEmpty())
                    .ifPresent(terms -> terms.forEach(term -> {
                        optBean.setVersion(term.getTermVersion());
                        //termsId不为空且版本号为空则根据termId去查询terms表中的版本号
                        if (StringUtils.isBlank(subscriptionItem.getTermsList().get(0).getTermVersion())
                                && StringUtils.isNotBlank(subscriptionItem.getTermsList().get(0).getTermId())) {
                            Optional<ShardTerms> shardTermsOptional = termsDao.findById(Long.valueOf(subscriptionItem.getTermsList().get(0).getTermId()));
                            shardTermsOptional.ifPresent(shardTerms -> optBean.setVersion(shardTerms.getTermsVersion()));
                        }
                    }));
            optBean.setStatus(subscriptionItem.getOptStatus());
            Optional.ofNullable(subscriptionItem.getOptTime()).ifPresent(t -> optBean.setOptTime(Timestamp.valueOf(t)));
            Optional.ofNullable(subscriptionItem.getCreateTime()).ifPresent(t -> optBean.setCreateTime(Timestamp.valueOf(t)));
            Optional.ofNullable(subscriptionItem.getUpdateTime()).ifPresent(t -> optBean.setModifyTime(Timestamp.valueOf(t)));
            if (StringUtils.isBlank(optBean.getVersion())) {
                //termsId为空且版本号也为空则将最新的版本号同步给DMP
                ShardTermsVersion shardTermsVersion = termsVersionDao.findByTenantIdAndStatus(tenantId, ConfigStatusEnum.ACTIVE.getCode());
                optBean.setVersion(shardTermsVersion.getTermsVersionLabel());
            }
            String replace = optBean.getVersion().replace("-", "0");
            optBean.setVersion(replace);
            opts.add(optBean);
        }
        return opts;
    }


    /**
     * 宝宝信息
     *
     * @param tenantId            tenantId
     * @param extraAttributeItems extraAttributeItems
     * @return DependentBean对象集合
     */
    private List<DependentBean> babyInfo(String tenantId, List<ExtraAttributeItem> extraAttributeItems) {
        List<DependentBean> dependentBeans = new ArrayList<>();
        Optional<ExtraAttributeItem> attributesOptional = extraAttributeItems.stream().filter(attributes -> ATTR_ID.equals(attributes.getAttrId()) && PAMPERS.equals(tenantId)).findFirst();
        if (attributesOptional.isPresent()) {
            List<BabyInfoBean> babyInfoBeanList = JSON.parseArray(attributesOptional.get().getAttrValue(), BabyInfoBean.class);
            int i = 0;
            for (BabyInfoBean babyInfoBean : babyInfoBeanList) {
                i++;
                DependentBean dependentBean = new DependentBean();
                dependentBean.setSqn(valueOf(i));
                dependentBean.setName(babyInfoBean.getName());
                dependentBean.setGender(babyInfoBean.getGender());
                if (StringUtils.isNotBlank(babyInfoBean.getBirthday())) {
                    String babyBirthday = null;
                    try {
                        babyBirthday = DateUtil.toString(DateUtil.formDate(babyInfoBean.getBirthday(), YYYY_MM_DD), YYYY_MM);
                    } catch (Exception e) {
                        log.warn("InsertedRegProfileEvent babyBirthday DateFormat error{}", babyInfoBean.getBirthday());
                    }
                    dependentBean.setBirthdate(babyBirthday);
                }
                dependentBean.setRelation(babyInfoBean.getRelation());
                dependentBeans.add(dependentBean);
            }
        }
        return dependentBeans;
    }


    /**
     * 属性信息组装
     *
     * @param extraAttributeItems extraAttributeItems
     * @return AttributeBean对象集合
     */
    private List<AttributeBean> attributeBeans(List<ExtraAttributeItem> extraAttributeItems) {
        List<AttributeBean> attributeBeans = new ArrayList<>();
        for (ExtraAttributeItem extraAttributeItem : extraAttributeItems) {
            AttributeBean attributeBean = new AttributeBean();
            attributeBean.setAttrId(extraAttributeItem.getAttrId());
            attributeBean.setAttrValue(extraAttributeItem.getAttrValue());
            attributeBeans.add(attributeBean);
        }
        return attributeBeans;
    }


    /**
     * updateProfileEvent 将完善好的会员信息发送发给DMP
     *
     * @param account account对象
     */
    private void updateProfileEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        UpdateProfileEventBean updateProfileEventBean = new UpdateProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                updateProfileEventBean.setAccountId(account.getAccountId());
                updateProfileEventBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                updateProfileEventBean.updated();
                Optional.ofNullable(account.getUserBasicInfo()).ifPresent(basicInfo -> {
                    //NickName 无业务场景使用，不需要传到DMP，在2018年7月13日确定设为null值
                    updateProfileEventBean.setNickName(basicInfo.getNickName());
                    updateProfileEventBean.setFullName(basicInfo.getFullName());
                    //Email 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
                    updateProfileEventBean.setEmail(basicInfo.getContact().getEmail());
                    updateProfileEventBean.setGender(basicInfo.getGender());
                    updateProfileEventBean.setBirthdate(formatBirthday(basicInfo));
                    String mobile = basicInfo.getContact().getMobile();
                    if (StringUtils.isNotBlank(mobile)) {
                        updateProfileEventBean.setMobile(mobile);
                        //添加SHA256加密和手机前6位,在2020年03月11日添加
                        updateProfileEventBean.setMobileSha256(DigestUtils.sha256Hex(mobile));
                    }
                });
                this.setAddressInfo(account, updateProfileEventBean);
                updateProfileEventBean.setJobs(this.setJobInfo(account));
                updateProfileEventBean.setEducations(this.setEducationInfo(account));
                updateProfileEventBean.setHumanRelations(this.setHumanRelation(account));
                updateProfileEventBean.setUpdateTime(DateUtil.getCurrentTimestamp());
                result = cdpListener.send(ServiceBusQueueTopicEnum.UPDATE_PROFILE_ACCOUNT, updateProfileEventBean, "CdpListener_updateProfileEvent_sendServiceBus", count);
            } catch (Exception e) {
                log.error("updateProfileEvent error:{}", e.getMessage());
            }
        }
    }

    /**
     * 初始化地址信息
     *
     * @param account                account对象
     * @param updateProfileEventBean updateProfileEventBean对象
     */
    private void setAddressInfo(Account account, UpdateProfileEventBean updateProfileEventBean) {
        Optional.ofNullable(account.getAddress()).ifPresent(address -> {
            updateProfileEventBean.setFullName(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getFullName).orElse(address.getFullName()));
            updateProfileEventBean.setAddress(address.getAddress());
            updateProfileEventBean.setProvince(address.getProvince());
            updateProfileEventBean.setCity(address.getCity());
            updateProfileEventBean.setDistrict(address.getDistrict());
            updateProfileEventBean.setZipCode(address.getPostcode());
        });
    }

    /**
     * counterEvent 消息发送，发给DMP
     *
     * @param account account对象
     */
    private void updateCounterEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getCounter())
                .ifPresent(counterInfo -> {
                    boolean result = false;
                    CounterBean counterBean = new CounterBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            counterBean.setAccountId(account.getAccountId());
                            counterBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                            counterBean.updated();
                            this.getCounterInfo(counterInfo, counterBean);
                            result = cdpListener.send(ServiceBusQueueTopicEnum.UPDATE_COUNTER_ACCOUNT, counterBean, "CdpListener_updateCounterEvent_sendServiceBus", count);
                        } catch (Exception e) {
                            log.error("UpdatedCounterEvent error,account is:{}", JSON.toJSONString(account), e);
                        }
                    }
                });

    }


    /**
     * 将柜台信息转成DMP需要的柜台格式
     *
     * @param counterInfo 柜台
     * @param counterBean DMP需要的柜台格式
     * @author xusheng
     * @date 2020/9/28 17:32
     */
    private void getCounterInfo(CounterInfo counterInfo, CounterBean counterBean) {
        Optional.ofNullable(counterInfo).ifPresent(counterInfo1 -> {
            counterBean.setRegCounter(counterInfo1.getRegCounterCode());
            counterBean.setMainCounter(counterInfo1.getMainCounterCode());
            counterBean.setPickupCounter(counterInfo1.getPickupCounterCode());
            counterBean.setCrmPickupCounter(counterInfo1.getCrmPickupCounterCode());
            counterBean.setFirstPurchaseCounter(counterInfo1.getFirstPurchaseCounterCode());
            counterBean.setFirstPurchaseTime(counterInfo1.getFirstPurchaseTime());
            counterBean.setOfflineFirstPurchaseCounter(counterInfo1.getOfflineFirstPurchaseCounterCode());
            counterBean.setOfflineLastPurchaseCounter(counterInfo1.getLastPurchaseCounterCode());
            counterBean.setMemberBelongToCounter(counterInfo1.getBelongToCounterCode());
            Optional.ofNullable(counterInfo1.getCreateTime()).ifPresent(t -> counterBean.setCreateTime(Timestamp.valueOf(t)));
            Optional.ofNullable(counterInfo1.getUpdateTime()).ifPresent(t -> counterBean.setModifyTime(Timestamp.valueOf(t)));
        });
    }


    /**
     * modifyAttrEvent 更新用户属性消息发送，发给DMP
     *
     * @param account account对象
     */
    private void updateAttributeEvent(Account account, String flag) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getExtraAttributeList)
                .filter(extraAttributeItems -> !extraAttributeItems.isEmpty())
                .ifPresent(extraAttributeItems -> {
                    boolean result = false;
                    UpdateAttrEventBean updateAttrEventBean = new UpdateAttrEventBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            updateAttrEventBean.setAccountId(account.getAccountId());
                            updateAttrEventBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                            if (UPDATED.equals(flag)) {
                                updateAttrEventBean.updated();
                            } else {
                                updateAttrEventBean.deleted();
                            }
                            updateAttrEventBean.setAttributes(attributeBeans(extraAttributeItems));
                            updateAttrEventBean.setDependents(this.babyInfo(account.getTenantId(), extraAttributeItems));
                            result = cdpListener.send(ServiceBusQueueTopicEnum.UPDATE_ATTRIBUTE_ACCOUNT, updateAttrEventBean, "CdpListener_updateAttributeEvent_sendServiceBus", count);
                        } catch (Exception e) {
                            log.error("modifyAttrEvent error{}", e.getMessage());
                        }
                    }
                });

    }

    /**
     * ChangeOptEvent 更新用户订阅信息消息发送，发给DMP
     *
     * @param shardSubscription shardSubscription
     */
    private void updateSubscriptionEvent(ShardSubscription shardSubscription) {
        if (!Optional.ofNullable(shardSubscription).isPresent()) {
            return;
        }
        Optional.ofNullable(shardSubscription.getSubscriptionList())
                .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                .ifPresent(subscriptionItemList -> {
                    boolean result = false;
                    ChangeOptEventBean changeOptEventBean = new ChangeOptEventBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            changeOptEventBean.setAccountId(shardSubscription.getAccountId());
                            changeOptEventBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(shardSubscription.getTenantId()));
                            changeOptEventBean.updated();
                            changeOptEventBean.setOpts(optBeans(shardSubscription.getTenantId(), subscriptionItemList));
                            result = cdpListener.send(ServiceBusQueueTopicEnum.UPDATE_SUBSCRIPTION_ACCOUNT, changeOptEventBean, "CdpListener_updateSubscriptionEvent_sendServiceBus", count);
                        } catch (Exception e) {
                            log.error("UpdatedChangeOptEvent error,shardSubscription is:{}", JSON.toJSONString(shardSubscription), e);
                        }
                    }
                });

    }

    /**
     * 获取会员绑定信息
     *
     * @param tenantId 租户
     * @param memberId 会员Id
     * @author xusheng
     * @date 2020/8/21 16:49
     */
    private List<SocialAccountBean> socialAccountBeanList(Long tenantId, String memberId) {
        List<SocialAccountBean> socialAccountBeanList = new ArrayList<>();
        ShardSocialAccount shardSocialAccount = socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenantId.toString(), memberId);
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .filter(socialAccountList -> !socialAccountList.isEmpty())
                .ifPresent(socialAccountList -> socialAccountList.forEach(socialAccount -> {
                    ShardChannel channel = channelDao.findByTenantIdAndChannelId(tenantId.toString(), socialAccount.getChannel().getChannelId());
                    SocialAccountBean socialAccountBean = comboSocialAccountBean(socialAccount, channel, STATUS_I);
                    if (null != socialAccount.getUnionId()) {
                        socialAccountBean.setUnionId(socialAccount.getUnionId());
                    }
                    socialAccountBeanList.add(socialAccountBean);
                }));
        return socialAccountBeanList;
    }

    /**
     * 组合SocialAccountBean
     *
     * @param socialAccountItem socialAccount
     * @param channel           channel
     * @return SocialAccountBean
     */
    private SocialAccountBean comboSocialAccountBean(SocialAccountItem socialAccountItem, ShardChannel channel, String status) {
        SocialAccountBean socialAccountBean = new SocialAccountBean();
        socialAccountBean.setChannelId(channel.getChannelId());
        socialAccountBean.setSource(socialAccountItem.getSource());
        Optional.ofNullable(socialAccountItem.getCustomer())
                .ifPresent(t -> socialAccountBean.setCustomer(String.valueOf(t.getName())));
        socialAccountBean.setChannel(channel.getChannelLabel());
        socialAccountBean.setBrand(channel.getBrandCode());
        socialAccountBean.setPublicAccount(channel.getPublicAccount());
        socialAccountBean.setBindId(socialAccountItem.getBindId());
        socialAccountBean.setBindTime(Timestamp.valueOf(socialAccountItem.getBindTime()));
        socialAccountBean.setCreateTime(Timestamp.valueOf(socialAccountItem.getCreateTime()));
        socialAccountBean.setModifyTime(Timestamp.valueOf(socialAccountItem.getUpdateTime()));
        socialAccountBean.setBindStatus(status);
        return socialAccountBean;
    }


    /**
     * 获取会员绑定信息
     *
     * @param tenantId              tenantId
     * @param socialAccountItemList socialAccountItemList
     * @author xusheng
     * @date 2020/8/21 16:49
     */
    private List<SocialAccountBean> socialAccountBeanList(String tenantId, List<SocialAccountItem> socialAccountItemList, String status) {
        List<SocialAccountBean> socialAccountBeanList = new ArrayList<>();
        socialAccountItemList.forEach(socialAccountItem -> {
            if (Optional.ofNullable(socialAccountItem).isPresent()) {
                ShardChannel channel = channelDao.findByTenantIdAndChannelId(tenantId, socialAccountItem.getChannelId());
                SocialAccountBean socialAccountBean = comboSocialAccountBean(socialAccountItem, channel, status);
                if (StringUtils.isNotBlank(channel.getUnionIdType())) {
                    socialAccountBean.setUnionId(socialAccountItem.getUnionId());
                }
                socialAccountBeanList.add(socialAccountBean);
            }
        });
        return socialAccountBeanList;
    }

    /**
     * bindSocialAccountEvent 用户社交账号绑定信息消息发送，发给DMP
     *
     * @param account account对象
     */
    private void bindSocialAccountEvent(Account account, ShardSocialAccount shardSocialAccount) {
        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
            return;
        }
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .filter(socialAccountItemList -> !socialAccountItemList.isEmpty())
                .ifPresent(socialAccountItemList -> {
                    boolean result = false;
                    BindSocialAccountBean bindSocialAccountBean = new BindSocialAccountBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            Optional.ofNullable(account)
                                    // 判断userBasicInfo是否存在 如果存在使用封装的account中的userBasic，如果不存在查询数据库的accountInfo中的userBasicInfo（绑定的时候没有将userBasicInfo封装到account）
                                    .map(a -> {
                                        UserBasicInfo userBasicInfo = a.getUserBasicInfo();
                                        if (!Optional.ofNullable(userBasicInfo).isPresent()) {
                                            ShardAccountInfo shardAccountInfo = accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
                                            userBasicInfo = shardAccountInfo.getUserBasicInfo();
                                        }
                                        return userBasicInfo;
                                    })
                                    .map(UserBasicInfo::getContact)
                                    .map(Contact::getMobile)
                                    .ifPresent(bindSocialAccountBean::setMobile);
                            //添加设备信息
                            this.setDeviceInfo(account, bindSocialAccountBean);
                            bindSocialAccountBean.setAccountId(shardSocialAccount.getAccountId());
                            bindSocialAccountBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(shardSocialAccount.getTenantId()));
                            bindSocialAccountBean.updated();
                            bindSocialAccountBean.setSocialAccountInfo(socialAccountBeanList(shardSocialAccount.getTenantId(), socialAccountItemList, STATUS_I));
                            result = cdpListener.send(ServiceBusQueueTopicEnum.BIND_SOCIAL_ACCOUNT, bindSocialAccountBean, "CdpListener_bindSocialAccountEvent_sendServiceBus", count);
                        } catch (Exception e) {
                            log.error("InsertedBindSocialAccountEvent error,account is:{}", JSON.toJSONString(account), e);
                        }
                    }
                });
    }


    /**
     * deletedBindSocialAccountEvent 用户社交账号解绑信息消息发送，发给DMP
     *
     * @param shardSocialAccount account对象
     */
    private void deletedBindSocialAccountEvent(ShardSocialAccount shardSocialAccount) {
        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
            return;
        }
        List<SocialAccountItem> socialAccountItemList = shardSocialAccount.getSocialAccountList();
        if (!Optional.ofNullable(socialAccountItemList).isPresent() || socialAccountItemList.isEmpty()) {
            return;
        }
        boolean result = false;
        BindSocialAccountBean bindSocialAccountBean = new BindSocialAccountBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                bindSocialAccountBean.setAccountId(shardSocialAccount.getAccountId());
                bindSocialAccountBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(shardSocialAccount.getTenantId()));
                bindSocialAccountBean.deleted();
                bindSocialAccountBean.setSocialAccountInfo(socialAccountBeanList(shardSocialAccount.getTenantId(), socialAccountItemList, STATUS_O));
                result = cdpListener.send(ServiceBusQueueTopicEnum.UNBIND_ACCOUNT, bindSocialAccountBean, "CdpListener_deleteBindEvent_sendServiceBus", count);
            } catch (Exception e) {
                log.error("DeletedBindSocialAccountEvent error,shardSocialAccount is:{}", JSON.toJSONString(shardSocialAccount), e);
            }
        }

    }


    /**
     * Active account
     *
     * @param account account
     */
    public void activeAccountEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        ActiveAccountBean activeBean = new ActiveAccountBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                activeBean.setAccountId(account.getAccountId());
                activeBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                activeBean.updated();

                result = cdpListener.send(ServiceBusQueueTopicEnum.ACTIVE_ACCOUNT, activeBean, "CdpListener_activeAccountEvent_sendServiceBus", count);

            } catch (Exception e) {
                log.error("DeletedRegProfileEvent error,account is:{}", JSON.toJSONString(account), e);
            }
        }
    }


    /**
     * InActive account
     *
     * @param account account
     */
    public void inActiveAccountEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        InActiveAccountBean inActiveAccountBean = new InActiveAccountBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                inActiveAccountBean.setAccountId(account.getAccountId());
                inActiveAccountBean.setMpId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                inActiveAccountBean.deleted();
                result = cdpListener.send(ServiceBusQueueTopicEnum.CANCEL_ACCOUNT, inActiveAccountBean, "CdpListener_cancelAccount_sendServiceBus", count);
            } catch (Exception e) {
                log.error("DeletedRegProfileEvent error,account is:{}", JSON.toJSONString(account), e);
            }
        }
    }

}
