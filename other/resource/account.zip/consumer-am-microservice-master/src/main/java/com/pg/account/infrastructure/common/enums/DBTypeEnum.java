package com.pg.account.infrastructure.common.enums;


/**
 * @author JackSun
 */

public enum DBTypeEnum {
    /**
     * 数据库类型
     */
    ORACLE, MYSQL, SQLSERVER, SQLSERVER2005, DB2, INFORMIX, SYBASE, OTHER, EMPTY
}
