package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "AddressDTO_V1", description = "V1 AddressDTO接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO implements Serializable {
    private static final long serialVersionUID = -4185506825248945673L;
    @ApiModelProperty(value = "地址UUID识别编码", example = "12345556")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String addressCode;
    @ApiModelProperty(value = "是否是主地址（主：1,备：0），主地址只能存在一个，默认是主地址", example = "1")
    private String isPrimary;
    @ApiModelProperty(value = "地址类型:1、HOME 不填默认是1（HOME）", example = "1")
    private String addressType;
    @ApiModelProperty(value = "姓名", example = "1")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "手机", example = "188888888")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "电话", example = "0510-83195186")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "省", example = "江苏省")
    private String province;
    @ApiModelProperty(value = "市", example = "无锡市")
    private String city;
    @ApiModelProperty(value = "区", example = "滨湖区")
    private String district;
    @ApiModelProperty(value = "地址详情", example = "蠡湖大道1008号")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "邮编", example = "215600")
    private String postcode;
}
