package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.StringValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;

/**
 * @author lfx
 * @date 2021/12/31 13:55
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({FIELD, METHOD, PARAMETER})
@Constraint(validatedBy = StringValidator.TypeValid.class)
public @interface IsValidType {
    String message() default "query type not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
