package com.pg.account.interfaces.command.oralbCommand;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import com.pg.account.interfaces.command.CounterCommand;
import com.pg.account.interfaces.command.DeviceCommand;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author YJ
 * @date 2021/9/1
 */
@ApiModel
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MigrateRegisterBindCommand implements Serializable {
    private static final long serialVersionUID = -124452297796814766L;

    @ApiModelProperty(value = "租户ID，需要申请配置", example = "10003", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    public Long tenantId;
    @ApiModelProperty(value = "渠道ID，需要申请配置", example = "20", required = true)
    public Long channelId;
    @ApiModelProperty(value = "用户名（手机号码）", example = "13062661723", required = true)
    @NotBlank(message = "missing username")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    public String username;
    @ApiModelProperty(value = "密码,已经加密过得密码", example = "123456", required = true)
    @NotBlank(message = "missing password")
    @Length(min = 6, message = "password length less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    public String password;
    @ApiModelProperty(value = "盐值", example = "123456", required = true)
    @NotBlank(message = "missing salt")
    public String salt;
    @ApiModelProperty(value = "注册来源，需要申请配置", example = "OTT", required = true)
    @NotBlank(message = "missing source")
    public String source;
    @ApiModelProperty(value = "注册日期，从原来的数据得到", example = "2021-08-09 11:48:03.234000", required = true)
    public Timestamp regDate;
    @ApiModelProperty(value = "注册店铺", example = "SMART")
    public String regStore;
    @ApiModelProperty(value = "顾客,和AM对接时申请", example = "PG")
    public String customer;
    @ApiModelProperty(value = "用户信息")
    public OralbProfileCommand profile;
    @ApiModelProperty(value = "设备信息")
    private DeviceCommand device;
    @ApiModelProperty(value = "柜台信息")
    private CounterCommand counter;
    @ApiModelProperty(value = "地址信息集合")
    private OralbAddressCommand addresses;
    @ApiModelProperty(value = "订阅信息集合")
    @Valid
    private List<OralbSubscriptionCommand> subscriptions;
    @ApiModelProperty(value = "用户属性信息集合")
    @Valid
    private List<OralbAttrCommand> attrs;
    @ApiModelProperty(value = "第三方的社交绑定ID集合", example = "oxD-dt-Ev379xF3MHK6Pk")
    private List<OralbBindCommand> binds;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY", required = true)
    private String unionIdType;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码绑定时间", example = "2021-08-09 11:48:03.234000")
    private Timestamp unionIdBindTime;
}
