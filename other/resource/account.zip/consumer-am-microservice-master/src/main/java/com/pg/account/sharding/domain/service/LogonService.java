package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.LogonCommand;
import com.pg.account.sharding.application.event.LogonEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.AccountStatus;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author lfx
 * @date 2021/6/18 10:17
 */
@Service
@Slf4j
public class LogonService {

    private final FetchMappingService fetchMappingService;
    private final AccountInfoDao accountInfoDao;

    @Autowired
    public LogonService(FetchMappingService fetchMappingService, AccountInfoDao accountInfoDao) {
        this.fetchMappingService = fetchMappingService;
        this.accountInfoDao = accountInfoDao;
    }

    /**
     * 根据手机号登录
     *
     * @param logonCommand logonCommand
     */
    public Account logonBySms(LogonCommand logonCommand) {
        // 手机不能为空
        if (StringUtils.isBlank(logonCommand.getMobile())) {
            log.warn("lack_of_mobile");
            throw new BusinessException(ResultEnum.INCORRECT_MOBILE.getCode(), ResultEnum.INCORRECT_MOBILE.getV2Code(), ResultEnum.INCORRECT_MOBILE.getMessage());
        }
        // 短信验证码不能为空
        if (StringUtils.isBlank(logonCommand.getSmsCode())) {
            log.warn("lack_of_message_code");
            throw new BusinessException(ResultEnum.INCORRECT_MESSAGE_CODE.getCode(), ResultEnum.INCORRECT_MESSAGE_CODE.getV2Code(), ResultEnum.INCORRECT_MESSAGE_CODE.getMessage());
        }
        // 验证码不能为空
        if (StringUtils.isBlank(logonCommand.getTemplateId())) {
            log.warn("lack_of_message_template_id");
            throw new BusinessException(ResultEnum.INCORRECT_MESSAGE_TEMPLATE_ID.getCode(), ResultEnum.INCORRECT_MESSAGE_TEMPLATE_ID.getV2Code(), ResultEnum.INCORRECT_MESSAGE_TEMPLATE_ID.getMessage());
        }
        // 通过手机号查询profile
        return Optional.ofNullable(fetchMappingService.fetchByTenantIdAndMobile(logonCommand.getTenantId().toString(), logonCommand.getMobile()))
                .orElseThrow(() ->
                        new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
    }

    /**
     * 根据密码登录
     *
     * @param logonCommand logonCommand
     */
    public Account logonByPwd(LogonCommand logonCommand) {
        if (StringUtils.isBlank(logonCommand.getPassword())) {
            log.warn("lack_of_original_pwd");
            throw new BusinessException(ResultEnum.INCORRECT_ORIGINAL_PASSWORD.getCode(), ResultEnum.INCORRECT_ORIGINAL_PASSWORD.getV2Code(), ResultEnum.INCORRECT_ORIGINAL_PASSWORD.getMessage());
        }
        Account account;
        // 通过mobile活email获取profile
        if (StringUtils.isNotBlank(logonCommand.getMobile()) && StringUtils.isBlank(logonCommand.getEmail())) {
            account = fetchMappingService.fetchByTenantIdAndMobile(logonCommand.getTenantId().toString(), logonCommand.getMobile());
        } else if (StringUtils.isNotBlank(logonCommand.getEmail()) && StringUtils.isBlank(logonCommand.getMobile())) {
            account = fetchMappingService.fetchByTenantIdAndEmail(logonCommand.getTenantId().toString(), logonCommand.getEmail());
        } else {
            throw new BusinessException(ResultEnum.INCORRECT_ACCOUNT_IDENTIFICATION_INFORMATION.getCode(), ResultEnum.INCORRECT_ACCOUNT_IDENTIFICATION_INFORMATION.getV2Code(), ResultEnum.INCORRECT_ACCOUNT_IDENTIFICATION_INFORMATION.getMessage());
        }
        String accountId = Optional.ofNullable(account).map(Account::getAccountId).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        //获取登录失败次数配置
        int logonFailedCounts = RedisConfigUtils.getLogonFailedCounts(logonCommand.getTenantId().toString(), accountId);
        //限定错误次数
        int limit = RedisConfigUtils.getLogonFailedLimitCounts(logonCommand.getTenantId().toString());
        if (logonFailedCounts > limit) {
            // event事件
            LogonEvent logonEvent = new LogonEvent(this, String.valueOf(logonCommand.getTenantId()), account.getAccountId(), logonCommand.getSmsCode());
            SpringContextUtil.getApplicationContext().publishEvent(logonEvent);
            log.warn("AccountValidator,logonValidate(),too_many_login_fail");
            throw new BusinessException(ResultEnum.THE_NUMBER_OF_USER_LOGIN_ERRORS_REACHED_THE_LIMIT.getCode(), ResultEnum.THE_NUMBER_OF_USER_LOGIN_ERRORS_REACHED_THE_LIMIT.getV2Code(), ResultEnum.THE_NUMBER_OF_USER_LOGIN_ERRORS_REACHED_THE_LIMIT.getMessage());
        }
        ShardAccountInfo accountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(logonCommand.getTenantId().toString(), accountId, AccountStatus.ACTIVE))
                .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        account.security(accountInfo.getSecurity());
        return account;
    }
}
