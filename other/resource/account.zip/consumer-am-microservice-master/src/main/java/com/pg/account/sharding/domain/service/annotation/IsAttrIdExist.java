package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.AccountBaseValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author lfx
 * @date 2021/4/29 15:37
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AccountBaseValidator.AttrIdValid.class)
public @interface IsAttrIdExist {

    String message() default "attrId system config is error";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
