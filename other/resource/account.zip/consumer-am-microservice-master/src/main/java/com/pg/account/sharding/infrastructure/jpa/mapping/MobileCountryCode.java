package com.pg.account.sharding.infrastructure.jpa.mapping;

import java.io.Serializable;

/**
 * 手机国家编码字典类
 *
 * @author LC
 */
public enum MobileCountryCode implements Serializable {

    /**
     * 地区mcc枚举
     */
    CHINA("CN", "86"),
    TAI_WAN("TW", "886"),
    HONG_KONG("HK", "852"),
    JAPAN("JP", "81");

    private String countryShortcode;

    private String countryCode;

    MobileCountryCode(String countryShortcode, String countryCode) {
        this.countryShortcode = countryShortcode;
        this.countryCode = countryCode;
    }

    public String getCode() {
        return this.countryCode;
    }

}
