package com.pg.account.sharding.domain.service;

/**
 * @author Jack
 * @description
 * @date 2021/6/2 22:07
 * @modified Jack
 */
public interface FetchAclService {

    /**
     * 获取unionId
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param openId    openId
     * @return java.lang.String
     * @author xusheng
     * @date 2021/7/28 13:55
     */
    String fetchUnionId(String tenantId, String channelId, String openId);
}
