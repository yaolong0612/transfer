package com.pg.account.infrastructure.common.enums;

/**
 * 属性字典
 *
 * @author JackSun
 */
public enum AttrDicDataTypeEnum {
    /**
     * 用户属性类型
     */
    OBJECT_JSON("OBJECT_JSON"),
    ARRAY_JSON("ARRAY_JSON"),
    STRING("STRING"),
    TIMESTAMP("TIMESTAMP");

    String dataType;

    AttrDicDataTypeEnum(String dataType) {
        this.dataType = dataType;
    }

    public String getDataType() {
        return dataType;
    }

}
