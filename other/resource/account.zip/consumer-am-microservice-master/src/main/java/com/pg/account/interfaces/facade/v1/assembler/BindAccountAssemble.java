package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.infrastructure.common.enums.UnBindRouteEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.UnBindingCommand;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 组装绑定数据
 *
 * @author xusheng
 * @date 2021/6/8 <br>
 */
@Component("BindAccountAssembleV1")
public class BindAccountAssemble {

    private final ChannelDao channelDao;

    @Autowired
    public BindAccountAssemble(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 封装注册绑定参数
     *
     * @return com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount
     * @author xusheng
     * @date 2021/6/8 18:17
     */
    public ShardSocialAccount toShardSocialAccount(Long tenantId, Long channelId, String memberId, String bindId, String unionId) {
        ShardChannel shardChannel = Optional.ofNullable(channelDao.findByTenantIdAndChannelId(tenantId.toString(), channelId.toString())).orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
        Channel channel = new Channel();
        channel.build(shardChannel);
        ShardSocialAccount.ShardSocialAccountBuilder shardSocialAccountBuilder = ShardSocialAccount
                .ShardSocialAccountBuilder
                .aShardSocialAccount()
                .tenantId(tenantId.toString())
                .accountId(memberId)
                .socialAccountList(toSocialAccountItem(channel, bindId, unionId));
        return shardSocialAccountBuilder.build();
    }

    private List<SocialAccountItem> toSocialAccountItem(Channel channel, String bindId, String unionId) {
        List<SocialAccountItem> socialAccountList = new ArrayList<>();
        SocialAccountItem socialAccountItem = new SocialAccountItem();
        socialAccountItem.build(channel, null, bindId, unionId);
        socialAccountList.add(socialAccountItem);
        return socialAccountList;
    }

    /**
     * 校验解绑路由参数
     *
     * @param command UnBindingCommand
     */
    public void checkUnBindIdRoute(UnBindingCommand command) {
        //如果入参没有传路由则默认给memberIdAndChannelId
        String unBindRoute = Optional.ofNullable(command.getUnBindRoute())
                .orElse(UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey());
        if (UnBindRouteEnum.MEMBER_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey()) && StringUtils.isBlank(command.getMemberId())) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        if (UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey()) && StringUtils.isBlank(command.getMemberId())) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        if (UnBindRouteEnum.BIND_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey()) && StringUtils.isBlank(command.getBindId())) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        if (UnBindRouteEnum.UNION_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey()) && StringUtils.isBlank(command.getUnionId())) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        command.setUnBindRoute(unBindRoute);
    }
}
