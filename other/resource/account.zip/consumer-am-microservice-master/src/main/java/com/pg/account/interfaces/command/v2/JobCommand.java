package com.pg.account.interfaces.command.v2;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * 工作信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobCommand implements Serializable {
    private static final long serialVersionUID = -6263802410952820001L;
    @ApiModelProperty(value = "relationship 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationship", example = "101或自己")
    @NotBlank(message = "relationship cannot be empty")
    private String relationship;
    @ApiModelProperty(value = "relationshipSequence Sequence limit, the default is 1. Others such as relationshipId: (108: son, 109: daughter, 110: grandson, 111: granddaughter,etc) limit to 2 births, you can fill in 2, up to 5", name = "relationshipSequence", example = "2")
    @NotBlank(message = "relationshipSequence cannot be empty")
    @Pattern(regexp = POSITIVE_PATTERN, message = "relationshipSequence must be a positive integer")
    private String relationshipSequence;
    @ApiModelProperty(value = "province", name = "province", example = "江苏省")
    @Pattern(regexp = CHINESE_PATTERN, message = "province must be Chinese")
    private String province;
    @ApiModelProperty(value = "city", name = "city", example = "无锡市")
    @Pattern(regexp = CHINESE_PATTERN, message = "city must be Chinese")
    private String city;
    @ApiModelProperty(value = "district", name = "district", example = "滨湖区")
    @Pattern(regexp = CHINESE_PATTERN, message = "region must be in chinese")
    private String district;
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "unitAddress can not contains special characters")
    @ApiModelProperty(value = "unitAddress", name = "unitAddress", example = "太湖大道2008号科技园3号")
    private String unitAddress;
    @ApiModelProperty(value = "unitName", name = "unitName", example = "XX有限公司")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "unit name can not contains special characters")
    private String unitName;
    @ApiModelProperty(value = "unitCategory", name = "unitCategory", example = "教师")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "unit category can not contains special characters")
    private String unitCategory;
    @ApiModelProperty(value = "profession", name = "profession", example = "工程师")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "profession can not contains special characters")
    private String profession;
}
