package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 * @date 2017/3/24
 * @date 2021-6-9
 */
@Getter
public class BindingEvent extends ApplicationEvent {
    private static final long serialVersionUID = -4890095788340679548L;

    private Account account;
    private ShardSubscription shardSubscription;
    private ShardSocialAccount shardSocialAccount;

    public BindingEvent(Object source) {
        super(source);
    }

    public BindingEvent(Object source, Account account, ShardSubscription shardSubscription, ShardSocialAccount shardSocialAccount) {
        super(source);
        this.account = account;
        this.shardSubscription = shardSubscription;
        this.shardSocialAccount = shardSocialAccount;
    }

}
