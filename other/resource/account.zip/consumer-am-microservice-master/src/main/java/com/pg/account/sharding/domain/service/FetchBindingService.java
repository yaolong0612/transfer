package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author lfx
 * @date 2021/6/7 13:32
 */
@Service
public class FetchBindingService {
    private final ShardSocialAccountRepository socialAccountRepository;

    @Autowired
    public FetchBindingService(ShardSocialAccountRepository socialAccountRepository) {
        this.socialAccountRepository = socialAccountRepository;
    }

    /**
     * 根据租户和账号查询绑定信息
     *
     * @param tenant    租户
     * @param accountId 账号Id
     * @date 2021/8/11 13:23
     */
    public ShardSocialAccount fetchBindByTenantAndAccountId(String tenant, String accountId) {
        return Optional.ofNullable(socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId)).orElseThrow(() -> new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(), ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), ResultEnum.BIND_ID_NOT_EXIST.getMessage()));
    }

    /**
     * 根据租户和账号查询绑定信息
     *
     * @param tenant    租户
     * @param accountId 账号Id
     * @date 2021/8/11 13:23
     */
    public ShardSocialAccount queryBindByTenantAndAccountId(String tenant, String accountId) {
        return Optional.ofNullable(socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId)).orElseThrow(() -> new BusinessException(V3ResultEnum.BIND_ID_NOT_EXIST.getCode(), V3ResultEnum.BIND_ID_NOT_EXIST.getMessage(), V3ResultEnum.BIND_ID_NOT_EXIST.getFrontMessage()));
    }

}
