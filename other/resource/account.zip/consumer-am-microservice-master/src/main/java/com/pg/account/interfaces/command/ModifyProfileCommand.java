package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.NUMBER_PATTERN;

/**
 * @author JackSun
 * @date 2017/2/8
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModifyProfileCommand implements Serializable {
    private static final long serialVersionUID = 5434914635831422120L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12", required = true)
    @NotNull(message = "channel is not exist")
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @NotBlank(message = "missing member ID")
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "柜台信息")
    private CounterCommand counter;
    @Valid
    @ApiModelProperty(value = "用户信息")
    private ProfileCommand profile;
    @Valid
    @ApiModelProperty(value = "订阅信息")
    private List<SubscriptionCommand> subscriptions;
    @Valid
    @ApiModelProperty(value = "地址信息")
    @Size(min = 1, message = "only one address information can be modified")
    private List<AddressCommand> addresses;
    @Valid
    @ApiModelProperty(value = "用户属性信息")
    private List<AttrCommand> attrs;

    /**
     * 首次添加属性加积分
     *
     * @param attrId  attrId
     * @param attrVal attrVal
     */
    public void addFirstModifyCountAttr(String attrId, String attrVal) {
        if (null == this.attrs) {
            this.attrs = new ArrayList<>();
        }
        this.attrs.add(new AttrCommand(attrId, attrVal));
    }

    public String gotFullName() {
        if (null != this.addresses && !this.addresses.isEmpty()) {
            return this.addresses.get(0).getFullName();
        }
        return null;
    }
}
