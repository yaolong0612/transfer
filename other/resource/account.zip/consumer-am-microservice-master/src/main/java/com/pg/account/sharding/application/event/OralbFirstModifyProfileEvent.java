package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class OralbFirstModifyProfileEvent extends ApplicationEvent {
    private static final long serialVersionUID = 7092308699952264417L;
    private Account account;
    private String attrId;

    public OralbFirstModifyProfileEvent(Object source) {
        super(source);
    }

    public OralbFirstModifyProfileEvent(Object source, Account account, String attrId) {
        super(source);
        this.account = account;
        this.attrId = attrId;
    }
}
