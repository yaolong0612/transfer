package com.pg.account.interfaces.facade.v1;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;

import com.pg.account.interfaces.command.MemberCommand;
import com.pg.account.interfaces.command.QueryOptionConfigCommand;
import com.pg.account.interfaces.command.ReplaceBindIdCommand;
import com.pg.account.interfaces.command.UpdateBindIdCommand;
import com.pg.account.interfaces.command.oralbCommand.MigrateRegisterBindCommand;
import com.pg.account.interfaces.dto.QueryOptionConfigDTO;
import com.pg.account.interfaces.dto.RegisterBindAccountDTO;
import com.pg.account.interfaces.dto.TermsDTO;
import com.pg.account.interfaces.facade.v1.assembler.BindAccountAssemble;
import com.pg.account.interfaces.facade.v1.assembler.MigrateShardingRegisterBindAssembler;
import com.pg.account.interfaces.facade.v1.assembler.SubscriptionAssemble;
import com.pg.account.interfaces.vo.Result;
import com.pg.account.sharding.application.AccountAppService;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.common.constants.AccountConstants;
import com.pg.account.sharding.infrastructure.jpa.config.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.NEW_REGISTER;

/**
 * @author JackSun
 * @date 2017/4/15
 */
@RestController
@RequestMapping("/CustomizedServiceRest")
@Api(tags = {"V1接口 定制接口请不要接入，需要接入请联系AM负责人"})
@Slf4j
public class ShardCustomizedServiceRest {
    private final AccountAppService accountAppService;
    private final BindAccountAssemble bindAccountAssemble;
    private final SubscriptionAssemble subscriptionAssemble;
    private final OptionDictionaryDao optionDictionaryDao;
    private final ChannelDao channelDao;
    private final TermsVersionDao termsVersionDao;
    private final MigrateShardingRegisterBindAssembler migrateShardingRegisterBindAssembler;

    @Autowired
    public ShardCustomizedServiceRest(AccountAppService accountAppService,
                                      BindAccountAssemble bindAccountAssemble,
                                      SubscriptionAssemble subscriptionAssemble,
                                      OptionDictionaryDao optionDictionaryDao,
                                      ChannelDao channelDao,
                                      TermsVersionDao termsVersionDao,
                                      MigrateShardingRegisterBindAssembler migrateShardingRegisterBindAssembler) {
        this.accountAppService = accountAppService;
        this.bindAccountAssemble = bindAccountAssemble;
        this.subscriptionAssemble = subscriptionAssemble;
        this.optionDictionaryDao = optionDictionaryDao;
        this.channelDao = channelDao;
        this.termsVersionDao = termsVersionDao;
        this.migrateShardingRegisterBindAssembler = migrateShardingRegisterBindAssembler;
    }

    /**
     * 更新替换 BIND_ID
     *
     * @param updateBindIdCommand 入参
     * @return 返回参
     */
    @PostMapping("/updateBindId")
    @ApiOperation(value = "更新绑定ID")
    public Result<String> updateBindId(@RequestBody @Valid UpdateBindIdCommand updateBindIdCommand) {
        ShardSocialAccount oldShardSocialAccount = bindAccountAssemble.toShardSocialAccount(updateBindIdCommand.getTenantId(),
                updateBindIdCommand.getChannelId(), updateBindIdCommand.getMemberId(), updateBindIdCommand.getOldBindId(), null);
        ShardSocialAccount newShardSocialAccount = bindAccountAssemble.toShardSocialAccount(updateBindIdCommand.getTenantId(),
                updateBindIdCommand.getChannelId(), updateBindIdCommand.getMemberId(), updateBindIdCommand.getNewBindId(), null);
        ShardSubscription oldShardSubscription = subscriptionAssemble.toShardSubscription(updateBindIdCommand.getTenantId(),
                updateBindIdCommand.getChannelId(), updateBindIdCommand.getMemberId(), null);
        ShardSubscription newShardSubscription = subscriptionAssemble.toShardSubscription(updateBindIdCommand.getTenantId(),
                updateBindIdCommand.getChannelId(), updateBindIdCommand.getMemberId(), null);
        accountAppService.updateBindId(updateBindIdCommand, oldShardSocialAccount, newShardSocialAccount, oldShardSubscription, newShardSubscription);
        return new Result<>(null, null);
    }

    /**
     * 替换BIND_ID，解绑冲突的绑定数据
     *
     * @param replaceBindIdCommand 入参
     * @return 返回参
     */
    @PostMapping("/replaceBindId")
    @ApiOperation(value = "替换绑定ID")
    public Result<String> replaceBindId(@RequestBody @Valid ReplaceBindIdCommand replaceBindIdCommand) {
        Account account = Account.AccountBuilder.anAccount()
                .tenantId(replaceBindIdCommand.getTenantId().toString())
                .accountId(replaceBindIdCommand.getMemberId())
                .build();
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(replaceBindIdCommand.getTenantId(),
                replaceBindIdCommand.getChannelId(), replaceBindIdCommand.getMemberId(), replaceBindIdCommand.getBindId(), replaceBindIdCommand.getUnionId());
        ShardSubscription shardSubscription = subscriptionAssemble.toShardSubscription(replaceBindIdCommand.getTenantId(),
                replaceBindIdCommand.getChannelId(), replaceBindIdCommand.getMemberId(), null);
        accountAppService.replaceBindId(account, shardSocialAccount, shardSubscription);
        return new Result<>(null, null);

    }

    /**
     * 激活账号
     *
     * @param memberCommand 入参
     * @return 返回参
     */
    @PostMapping("/activeMember")
    @ApiOperation(value = "激活账号")
    public Result<String> activeMember(@RequestBody @Valid MemberCommand memberCommand) {
        Account account = Account.AccountBuilder.anAccount()
                .tenantId(memberCommand.getTenantId().toString())
                .accountId(memberCommand.getMemberId())
                .build();
        accountAppService.activeMember(account);
        return new Result<>(null, null);

    }

    /**
     * 账号失效
     *
     * @param memberCommand 入参
     * @return 返回参
     */
    @PostMapping("/inactiveMember")
    @ApiOperation(value = "注销账号")
    public Result<String> inactiveMember(@RequestBody @Valid MemberCommand memberCommand) {
        Account account = Account.AccountBuilder.anAccount()
                .tenantId(memberCommand.getTenantId().toString())
                .accountId(memberCommand.getMemberId())
                .build();
        accountAppService.inactiveAccount(account);
        return new Result<>(null, null);
    }

    /**
     * 查询订阅配置
     *
     * @param queryOptionConfigCommand 入参
     * @return 返回参
     */
    @PostMapping("/queryOptionConfig")
    @ApiOperation(value = "查询订阅条款")
    public Result<QueryOptionConfigDTO> queryOptionConfig(@RequestBody @Valid QueryOptionConfigCommand queryOptionConfigCommand) {
        String tenantId = CacheLocalConfigUtils.getTenantIdByMarketingProgramId(queryOptionConfigCommand.getMarketingProgramId());
        QueryOptionConfigDTO queryOptionConfigDTO = new QueryOptionConfigDTO();
        if (StringUtils.isBlank(queryOptionConfigCommand.getPublicAccount())) {
            List<ShardOptionDictionary> optionDictionaryList = optionDictionaryDao.findByTenantIdAndEnumType(tenantId, queryOptionConfigCommand.getType());
            String optId = Optional.ofNullable(optionDictionaryList).filter(opt -> !opt.isEmpty()).flatMap(opts -> opts.stream().findFirst().map(ShardOptionDictionary::getOptId)).orElseThrow(() -> new BusinessException(ResultEnum.OPT_ID_NOT_EXIST.getCode(), ResultEnum.OPT_ID_NOT_EXIST.getV2Code(), ResultEnum.OPT_ID_NOT_EXIST.getMessage()));
            queryOptionConfigDTO.setOptId(optId);
        } else {
            ShardChannel shardChannel = channelDao.findByTenantIdAndPublicAccount(tenantId, queryOptionConfigCommand.getPublicAccount());
            shardChannel = Optional.ofNullable(shardChannel).orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
            queryOptionConfigDTO.setOptId(shardChannel.getIsBindId());
        }
        List<ShardTermsVersion> termsVersionList = termsVersionDao.findByTenantId(tenantId);
        List<TermsDTO> terms = new ArrayList<>();
        if (Optional.ofNullable(termsVersionList).filter(t -> !t.isEmpty()).isPresent()) {
            termsVersionList.forEach(t -> terms.add(new TermsDTO(t.getTermsVersionLabel(), t.getTermsContent())));
            queryOptionConfigDTO.setTerms(terms);
        }
        return new Result<>(null, queryOptionConfigDTO);
    }

    /**
     * Oralb租户迁移接口
     *
     * @param migrateRegisterBindCommand 入参
     * @return 返回参
     */
    @PostMapping("/migrateRegisterBind")
    @ApiOperation(value = "OralB数据迁移接口")
    public Result<RegisterBindAccountDTO> migrateRegisterBind(@RequestBody @Valid MigrateRegisterBindCommand migrateRegisterBindCommand) {
        Account account = migrateShardingRegisterBindAssembler.toAccount(migrateRegisterBindCommand);
        ShardSocialAccount shardSocialAccount = migrateShardingRegisterBindAssembler.toShardSocialAccount(migrateRegisterBindCommand.getTenantId(), null, migrateRegisterBindCommand.getBinds(), migrateRegisterBindCommand.getUnionId(), migrateRegisterBindCommand.getSource());
        ShardSubscription shardSubscription = migrateShardingRegisterBindAssembler.toShardSubscription(migrateRegisterBindCommand.getTenantId(), account, null, migrateRegisterBindCommand.getSubscriptions());
        JSONObject jsonObject = accountAppService.migrateRegisterBind(account, shardSocialAccount, shardSubscription);
        RegisterBindAccountDTO registerBindAccountDTO = new RegisterBindAccountDTO(jsonObject.getString(AccountConstants.MEMBER_ID), jsonObject.getBoolean(NEW_REGISTER));
        return new Result<>(null, registerBindAccountDTO);
    }

}
