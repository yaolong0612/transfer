package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.EMAIL_VALID_PATTERN;
import static com.pg.account.infrastructure.common.utils.StringValidUtil.MOBILE_PATTERN;

/**
 * @author JackSun
 * @date 2017/2/7
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogonCommand implements Serializable {

    private static final long serialVersionUID = 8931412443180617020L;

    @ApiModelProperty(value = "租户ID", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "登陆类型", required = true)
    @NotBlank(message = "missing login type")
    @Pattern(regexp = "(^PASSWORD$)|(^SMS$)", message = "login type error")
    private String logonType;
    @ApiModelProperty(value = "手机")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "邮箱")
    @Pattern(regexp = EMAIL_VALID_PATTERN, message = "email format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "密码")
    @Length(min = 6, message = "password length less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String password;
    @ApiModelProperty(value = "短信验证码")
    private String smsCode;
    @ApiModelProperty(value = "短信验证码模板ID")
    private String templateId;


}
