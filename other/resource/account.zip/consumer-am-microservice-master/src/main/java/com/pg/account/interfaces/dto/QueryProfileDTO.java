package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.common.utils.DateUtil;
import com.pg.account.interfaces.dto.v2.SubscriptionDTO;
import com.pg.account.sharding.domain.model.account.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD_HH_MI_SS;

/**
 * 会员信息
 *
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "QueryProfileDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryProfileDTO implements Serializable {
    private static final long serialVersionUID = 7148297187855318605L;

    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "手机号", example = "18862661876")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "邮箱", example = "1011@qq.com")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "昵称", example = "齐天大圣")
    private String nickname;
    @ApiModelProperty(value = "性别，男：M，女：F，无：U", example = "U")
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @ApiModelProperty(value = "生日，年满18岁，生日格式：yyyy-mm-dd", example = "1999-10-09")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @ApiModelProperty(value = "注册来源", example = "OTT")
    private String source;
    @ApiModelProperty(value = "注册时间", example = "2019-10-23 12:12:12")
    private String registrationDate;
    @ApiModelProperty(value = "订阅信息集合")
    private List<SubscriptionDTO> subscriptions;
    @ApiModelProperty(value = "地址信息集合")
    private List<AddressDTO> addresses;
    @ApiModelProperty(value = "用户属性信息集合")
    private List<AttrDTO> attrs;
    @ApiModelProperty(value = "绑定信息集合")
    private List<BindDTO> binds;
    @ApiModelProperty(value = "积分信息")
    private List<PointDTO> points;
    @ApiModelProperty(value = "柜台信息")
    private CounterDTO counter;
    @ApiModelProperty(value = "bindId查询时检查绑定状态", example = "true")
    private boolean isBind;
    @ApiModelProperty(hidden = true, example = "true")
    private boolean isModifyPhone;

    public QueryProfileDTO(String memberId, String cellphone, String email, String nickname, String gender, String birthday, String source, Timestamp registrationDate, List<AddressDTO> addresses, List<SubscriptionDTO> subscriptions, List<AttrDTO> attrs, CounterDTO counterDTO, List<BindDTO> binds) {
        SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD_HH_MI_SS);
        this.memberId = memberId;
        this.cellphone = cellphone;
        this.email = email;
        this.nickname = nickname;
        this.gender = gender;
        this.birthday = birthday;
        this.source = source;
        if (registrationDate != null) {
            this.registrationDate = sdf.format(registrationDate);
        }
        this.subscriptions = subscriptions;
        this.addresses = addresses;
        this.attrs = attrs;
        this.binds = binds;
        this.counter = counterDTO;
    }


    public QueryProfileDTO(String memberId, List<PointDTO> points) {
        this.memberId = memberId;
        if (null != points && !points.isEmpty()) {
            this.points = points;
        }
    }


    public static CounterDTO toCounterDTO(CounterInfo counter) {
        CounterDTO counterDTO = null;
        if (Optional.ofNullable(counter).isPresent()) {
            counterDTO = new CounterDTO(counter.getRegCounterCode(), counter.getRegCounterName(), counter.getMainCounterCode(),
                    counter.getMainCounterName(), counter.getPickupCounterCode(), counter.getPickupCounterName(),
                    counter.getOfflineFirstPurchaseCounterCode(), counter.getOfflineFirstPurchaseCounterName(),
                    counter.getFirstPurchaseCounterCode(), counter.getFirstPurchaseTime(), counter.getCrmPickupCounterCode());
        }
        return counterDTO;
    }

    public void build(Account account) {
        Optional.ofNullable(account).ifPresent(a -> {
            this.memberId = a.getIdentityId().getAccountId();
            this.cellphone = Optional.ofNullable(a.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).orElse(null);
            this.email = Optional.ofNullable(a.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getEmail).orElse(null);
            this.nickname = Optional.ofNullable(a.getUserBasicInfo()).map(UserBasicInfo::getNickName).orElse(null);
            this.gender = Optional.ofNullable(a.getUserBasicInfo()).map(UserBasicInfo::getGender).orElse(null);
            this.birthday = Optional.ofNullable(a.getUserBasicInfo()).map(UserBasicInfo::getBirthday).orElse(null);
            this.source = Optional.ofNullable(a.getRegistration()).map(Registration::getSource).orElse(null);
            this.registrationDate = Optional.ofNullable(a.getRegistration()).map(registration -> DateUtil.formatLocalDateTime(registration.getRegisterTime())).orElse(null);
            this.attrs = toAttributeDTO(a);
            this.counter = toCounterDTO(a.getCounter());
        });
    }

    public List<AttrDTO> toAttributeDTO(Account account) {
        List<AttrDTO> attributeDTOList = null;
        List<ExtraAttributeItem> attributes = account.getUserAdditionalInfo().getExtraAttributeList();
        if (Optional.ofNullable(attrs).filter(a -> !a.isEmpty()).isPresent()) {
            attributeDTOList = new ArrayList<>();
            for (ExtraAttributeItem attr : attributes) {
                AttrDTO attributeDTO = new AttrDTO(attr.getAttrId(), attr.getAttrValue());
                attributeDTOList.add(attributeDTO);
            }
        }
        return attributeDTOList;
    }

    public boolean getIsBind() {
        return isBind;
    }

    public void setIsBind(boolean isBind) {
        this.isBind = isBind;
    }

    public boolean getIsModifyPhone() {
        return isModifyPhone;
    }

    public void setIsModifyPhone(boolean modifyPhone) {
        isModifyPhone = modifyPhone;
    }
}
