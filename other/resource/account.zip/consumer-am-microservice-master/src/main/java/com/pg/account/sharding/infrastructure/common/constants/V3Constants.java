package com.pg.account.sharding.infrastructure.common.constants;

/**
 * @author lfx
 * @date 2022/2/23 18:34
 */
public class V3Constants {
    public static final String BIND_ID = "bindId";
    public static final String UNION_ID = "unionId";
    public static final String ACCOUNT_ID = "accountId";
    public static final String MOBILE = "mobile";
    public static final String ACCOUNT = "account";
    public static final String SOCIAL_ACCOUNT = "socialAccount";
    public static final String SUBSCRIPTION = "subscription";


    public static final String EXIST_BIND_ID = "existBindId";
    public static final String EXIST_UNION_ID = "existUnionId";
    public static final String NEW_TERM_VERSION = "newTermVersion";

    public static final String QUERY = "query";
    public static final String TYPE = "type";

    public static final String BY_UNION_TYPE = "1";
    public static final String BY_CHANNEL = "2";
    public static final String ACCOUNTS = "accounts";
    public static final String QUERY_ACCOUNT_CONFLICT_DTO = "queryAccountConflictDTO";
    public static final String NEW_MEMBER = "newMember";

    public static final String TENANT = "tenant";

    private V3Constants() {
    }
}
