package com.pg.account.sharding.domain.model.subscription;

import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.shared.Entity;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterSubscriptionListJson;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 订阅类
 *
 * @author Jack
 * @date 2021/5/27 14:49
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_SUBSCRIPTION")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardSubscription extends BaseEntity implements Entity<ShardSubscription>, Serializable {
    private static final long serialVersionUID = 3850736272787850676L;
    @Column(name = "id")
    protected Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterSubscriptionListJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private List<SubscriptionItem> subscriptionList;

    public ShardSubscription(IdentityId identityId, List<SubscriptionItem> subscriptionList) {
        this.identityId = identityId;
        this.subscriptionList = subscriptionList;
    }

    @Override
    public boolean sameIdentityAs(ShardSubscription other) {
        return other != null && this.identityId.getAccountId().equals(other.getIdentityId().getAccountId());
    }

    public void build(IdentityId identityId, List<SubscriptionItem> subscriptionList) {
        this.identityId = identityId;
        this.subscriptionList = subscriptionList;
        super.addCreateTime();
    }

    /**
     * 获取租户Id
     */
    @JSONField(serialize = false)
    public String getTenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElseThrow(() -> new BusinessException(ResultEnum.TENANT_CONFIG_NOT_EXIST.getCode(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.TENANT_CONFIG_NOT_EXIST.getMessage()));
    }

    /**
     * 获取账号
     */
    @JSONField(serialize = false)
    public String getAccountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
    }

    /**
     * 获取租户Id
     */
    @JSONField(serialize = false)
    public String tenantId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getTenantId).orElse(null);
    }

    /**
     * 获取账号
     */
    @JSONField(serialize = false)
    public String accountId() {
        return Optional.ofNullable(this.identityId).map(IdentityId::getAccountId).orElse(null);
    }

    public List<SubscriptionItem> getSubscriptionItemList() {
        return Optional.ofNullable(this.subscriptionList).filter(subscriptionItemList -> !subscriptionItemList.isEmpty()).orElse(null);
    }

    /**
     * 将accountId赋值到订阅信息中
     */
    public void specialAccountId(String accountId) {
        Validate.notNull(accountId, "accountId is null");
        Validate.notNull(this.identityId, "identityId is null");
        this.identityId.specialAccountId(accountId);
    }

    /**
     * 将identityId赋值到订阅信息中
     */
    public void specialIdentityId(IdentityId identityId) {
        Validate.notNull(identityId, "identityId is null");
        Validate.notNull(identityId.getTenantId(), "identityId tenantId is null");
        Validate.notNull(identityId.getAccountId(), "identityId accountId is null");
        this.identityId = identityId;
    }

    public static final class ShardSubscriptionBuilder {
        private final IdentityId.IdentityIdBuilder identityIdBuilder = IdentityId.IdentityIdBuilder.anIdentityId();
        private final SubscriptionItem subscriptionItem = new SubscriptionItem();
        protected Long id;
        protected LocalDateTime createdTime;
        protected LocalDateTime updatedTime;
        private IdentityId identityId;
        private List<SubscriptionItem> subscriptionList;

        private ShardSubscriptionBuilder() {
        }

        public static ShardSubscriptionBuilder aShardSubscription() {
            return new ShardSubscriptionBuilder();
        }

        public ShardSubscriptionBuilder id(Long id) {
            this.id = id;
            return this;
        }

        public ShardSubscriptionBuilder identityId(IdentityId identityId) {
            this.identityId = identityId;
            return this;
        }

        public ShardSubscriptionBuilder tenantId(String tenantId) {
            Validate.notNull(tenantId, "tenantId is null");
            this.identityId = identityIdBuilder.tenantId(tenantId).build();
            return this;
        }

        public ShardSubscriptionBuilder accountId(String accountId) {
            this.identityId = identityIdBuilder.accountId(accountId).build();
            return this;
        }

        public ShardSubscriptionBuilder subscriptionList(List<SubscriptionItem> subscriptionList) {
            this.subscriptionList = subscriptionList;
            return this;
        }

        public ShardSubscriptionBuilder createdTime(LocalDateTime createdTime) {
            this.createdTime = createdTime;
            return this;
        }

        public ShardSubscriptionBuilder updatedTime(LocalDateTime updatedTime) {
            this.updatedTime = updatedTime;
            return this;
        }

        public ShardSubscriptionBuilder channelId(String channelId) {
            subscriptionItem.setChannelId(channelId);
            ArrayList<SubscriptionItem> subscriptionItems = new ArrayList<>();
            subscriptionItems.add(subscriptionItem);
            this.subscriptionList = subscriptionItems;
            return this;
        }

        public ShardSubscription build() {
            ShardSubscription shardSubscription = new ShardSubscription();
            shardSubscription.setId(id);
            shardSubscription.setIdentityId(identityId);
            shardSubscription.setSubscriptionList(subscriptionList);
            shardSubscription.setCreatedTime(createdTime);
            shardSubscription.setUpdatedTime(updatedTime);
            return shardSubscription;
        }
    }
}
