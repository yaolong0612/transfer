package com.pg.account.interfaces.facade.v2.assembler;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;

import com.pg.account.interfaces.command.DeviceCommand;
import com.pg.account.interfaces.command.v2.AccountRegisterCommand;
import com.pg.account.interfaces.command.v2.AddressCommand;
import com.pg.account.interfaces.command.v2.ProfileCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.Contact;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.enums.RegisterTypeEnum.getByKeyOrValue;
import static com.pg.account.sharding.domain.model.account.CounterInfo.toCounterInfo;
import static com.pg.account.sharding.domain.model.account.DeviceInfo.toDeviceInfo;
import static com.pg.account.sharding.domain.model.account.EducationItem.toEducation;
import static com.pg.account.sharding.domain.model.account.ExtraAttributeItem.toAttr;
import static com.pg.account.sharding.domain.model.account.HumanRelationItem.toHuman;
import static com.pg.account.sharding.domain.model.account.JobItem.toJob;
import static com.pg.account.sharding.infrastructure.client.address.Address.toAddressV2;
import static jodd.util.StringPool.COMMA;

/**
 * 注册参数组装
 *
 * @author xusheng
 * @date 2021/6/4 <br>
 */
@Component("RegisterAccountAssemblerV2")
public class RegisterAccountAssembler {

    private final ChannelDao channelDao;

    @Autowired
    public RegisterAccountAssembler(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 检查是否符合配置规定
     *
     * @param result 缓存结果
     */
    private static String registerCheck(String result, String registerType) {
        String typeValue;
        String limitValue;
        try {
            JSONObject jsonObject = parseObject(result);
            typeValue = jsonObject.get(TYPE).toString();
            switch (typeValue) {
                case CELLPHONE:
                    typeValue = MOBILE_TYPE;
                    break;
                case UNION_ID:
                    typeValue = UNION_ID_TYPE;
                    break;
                default:
                    break;
            }
            limitValue = jsonObject.get(LIMIT).toString();
            String gerValue = getByKeyOrValue(registerType).getValue();
            if (Arrays.stream(limitValue.split(COMMA)).noneMatch(value -> value.equals(gerValue))) {
                throw new BusinessException(ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getCode(), ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getV2Code(), ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getMessage());
            }
        } catch (JSONException | NullPointerException e) {
            throw new BusinessException(ResultEnum.SYSTEM_CONFIG_ERROR.getCode(), ResultEnum.SYSTEM_CONFIG_ERROR.getV2Code(), ResultEnum.SYSTEM_CONFIG_ERROR.getMessage());
        }
        return typeValue;
    }

    /**
     * 将入参转成account
     *
     * @param accountRegisterCommand accountRegisterCommand
     * @return com.pg.account.sharding.domain.model.account.Account
     * @author xusheng
     * @date 2021/6/4 12:19
     */
    public Account toAccount(Long tenantId, Long channelId, AccountRegisterCommand accountRegisterCommand) {
        ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(tenantId.toString(), channelId.toString());
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        Contact contact = new Contact();
        checkRegisterRoute(contact, tenantId, accountRegisterCommand);
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId.toString())
                .password(accountRegisterCommand.getPassword())
                .registration(accountRegisterCommand.getSource(), channel, accountRegisterCommand.getCustomer(), accountRegisterCommand.getRegStore(), LocalDateTime.now())
                .contact(contact)
                .counter(toCounterInfo(accountRegisterCommand.getCounter()))
                .job(toJob(accountRegisterCommand.getJobs()))
                .education(toEducation(accountRegisterCommand.getEducations()))
                .human(toHuman(accountRegisterCommand.getInterpersonalRelationships()))
                .address(toAddressV2(accountRegisterCommand.getAddress()))
                .device(toDeviceInfo(accountRegisterCommand.getDevice()))
                .extraAttrs(toAttr(accountRegisterCommand.getAttributes()));
        if (Optional.ofNullable(accountRegisterCommand.getProfile()).isPresent()) {
            accountBuilder.birthday(accountRegisterCommand.getProfile().getBirthday())
                    .gender(accountRegisterCommand.getProfile().getGender())
                    .fullName(Optional.ofNullable(accountRegisterCommand.getAddress()).map(AddressCommand::getFullName).orElse(null))
                    .nickName(accountRegisterCommand.getProfile().getNickname());
        }

        return accountBuilder.build();

    }

    /**
     * 检查或获取路由
     *
     * @param contact                contact
     * @param accountRegisterCommand accountRegisterCommand
     */
    public void checkRegisterRoute(Contact contact, Long tenantId, AccountRegisterCommand accountRegisterCommand) {
        switch (Optional.ofNullable(accountRegisterCommand.getRegisterRoute())
                .orElse(registerCheck(Optional
                                .ofNullable(CacheLocalConfigUtils.getUniqueRegistrationType(tenantId))
                                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_ERROR.getCode(), ResultEnum.SYSTEM_CONFIG_ERROR.getV2Code(), ResultEnum.SYSTEM_CONFIG_ERROR.getMessage()))
                        , accountRegisterCommand.getType()))) {
            case MOBILE_TYPE:
                if (!StringValidUtil.isMobile(accountRegisterCommand.getUsername())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getCode(), "username不是手机格式");
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getMobile).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getProfile().getMobile())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getEmail).isPresent()) {
                    contact.specialEmail(accountRegisterCommand.getProfile().getEmail());
                }
                contact.specialMobile(accountRegisterCommand.getUsername());
                break;
            case EMAIL_TYPE:
                if (!StringValidUtil.isEmail(accountRegisterCommand.getUsername())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getCode(), "username不是手机格式");
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getEmail).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getProfile().getEmail())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getMobile).isPresent()) {
                    contact.specialMobile(accountRegisterCommand.getProfile().getMobile());
                }
                contact.specialEmail(accountRegisterCommand.getUsername());
                break;
            case UNION_ID_TYPE:
                if (Optional.ofNullable(accountRegisterCommand.getUnionId()).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getUnionId())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (StringUtils.isBlank(accountRegisterCommand.getUnionId())) {
                    accountRegisterCommand.setUnionId(accountRegisterCommand.getUsername());
                }
                break;
            case BIND_ID_TYPE:
                if (Optional.ofNullable(accountRegisterCommand.getBindId()).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getBindId())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (StringUtils.isBlank(accountRegisterCommand.getBindId())) {
                    accountRegisterCommand.setBindId(accountRegisterCommand.getUsername());
                }
                break;
            default:
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                // 将默认值替换成自定义的输出内容
        }
    }

    public Account toAccount(Long tenantId, String memberId, DeviceCommand device) {
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId.toString())
                .accountId(memberId)
                .device(toDeviceInfo(device));
        return accountBuilder.build();
    }
}
