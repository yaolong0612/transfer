package com.pg.account.sharding.domain.model.account;

import com.pg.account.interfaces.command.v2.InterpersonalRelationshipCommand;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * 人际信息类
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HumanRelationItem implements ValueObject<HumanRelationItem> {
    private static final long serialVersionUID = 8787393042564615545L;

    private Person person;
    private Relation relation;
    private String guardian;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public static List<HumanRelationItem> toHuman(Set<InterpersonalRelationshipCommand> interpersonalRelationships) {
        ArrayList<HumanRelationItem> humanRelationList = new ArrayList<>();
        Optional.ofNullable(interpersonalRelationships).ifPresent(inter -> inter.forEach(i -> {
            HumanRelationItem humanRelationItem = new HumanRelationItem();
            Person person = new Person();
            Contact contact1 = new Contact();
            contact1.setMobile(i.getCellphone());
            person.setContact(contact1);
            person.setFullName(i.getFullName());
            person.setBirthday(i.getBirthday());
            person.setGender(i.getGender());
            humanRelationItem.setPerson(person);
            Relation relation = new Relation();
            relation.setRelationType(RelationType.getRelation(i.getRelationship()));
            relation.setSequence(i.getRelationshipSequence());
            humanRelationItem.setRelation(relation);
            humanRelationItem.setGuardian(i.getGuardian());
            humanRelationList.add(humanRelationItem);
        }));
        return humanRelationList;
    }

    @Override
    public boolean sameValueAs(HumanRelationItem other) {
        return this.equals(other);
    }

    public void builder(HumanRelationItem db) {
        Optional.ofNullable(db).ifPresent(edu -> {
            Optional.ofNullable(this.person).ifPresent(a -> a.builder(db.person));
            Optional.ofNullable(this.relation).ifPresent(r -> r.builder(db.relation));
            this.guardian = Optional.ofNullable(this.guardian).orElse(db.guardian);
            this.createTime = Optional.ofNullable(db.createTime).orElse(this.createTime);
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(db.updateTime);
        });
    }
}
