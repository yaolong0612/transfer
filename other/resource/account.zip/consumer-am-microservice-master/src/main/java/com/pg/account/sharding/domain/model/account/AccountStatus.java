package com.pg.account.sharding.domain.model.account;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;

import java.util.Arrays;

/**
 * 账户状态枚举类
 *
 * @author Jack
 * @date 2021/5/27 13:18
 */
public enum AccountStatus {
    /**
     * 激活状态
     */
    ACTIVE("1"),
    /**
     * 不激活，销户状态
     */
    INACTIVE("2"),
    /**
     * 删除状态
     */
    DELETED("3");

    String value;

    AccountStatus(String value) {
        this.value = value;
    }

    public static AccountStatus getAccountStatus(String value) {
        return Arrays.stream(AccountStatus.values())
                .filter(msg -> value.equals(msg.getValue()))
                .findAny()
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
    }

    public String getValue() {
        return value;
    }
}
