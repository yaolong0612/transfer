package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * 修改属性发送给DMP 创建目的是为了和原来的时间区别开 不会被同步双鞋监听到
 */
@Getter
public class UpdateAttributeToDMPEvent extends ApplicationEvent {

    private static final long serialVersionUID = 6811532305357378936L;

    private Account account;

    public UpdateAttributeToDMPEvent(Object source) {
        super(source);
    }

    public UpdateAttributeToDMPEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }
}
