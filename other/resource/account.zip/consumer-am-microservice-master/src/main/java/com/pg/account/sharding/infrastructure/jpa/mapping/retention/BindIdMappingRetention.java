package com.pg.account.sharding.infrastructure.jpa.mapping.retention;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterLocalDateTime;
import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author lfx
 * @date 2022/2/24 13:32
 */
@Data
@Table(name = "BIND_ID_MAPPING_RETENTION")
@DynamicUpdate
@DynamicInsert
@Entity
public class BindIdMappingRetention implements Serializable {

    private static final long serialVersionUID = 7799583688453941722L;
    @Id
    private Long id;
    @Column(name = "account_id")
    private String accountId;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "bind_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @Column(name = "channel_id")
    private String channelId;
    @Convert(converter = JpaConverterLocalDateTime.class)
    protected LocalDateTime createdTime;
    @Convert(converter = JpaConverterLocalDateTime.class)
    protected LocalDateTime updatedTime;
}
