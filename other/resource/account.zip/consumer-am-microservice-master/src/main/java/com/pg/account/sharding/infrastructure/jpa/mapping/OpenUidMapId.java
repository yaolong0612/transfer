package com.pg.account.sharding.infrastructure.jpa.mapping;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author lfx
 * @date 2021/6/10 11:11
 */
@Data
@Embeddable
@AllArgsConstructor
@NoArgsConstructor
public class OpenUidMapId implements Serializable {
    private static final long serialVersionUID = -7948269013601732705L;
    @Column(name = "tenant_id")
    private String tenantId;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openUid;
}
