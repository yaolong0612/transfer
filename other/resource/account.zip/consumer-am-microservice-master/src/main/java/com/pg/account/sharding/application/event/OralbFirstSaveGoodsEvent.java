package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class OralbFirstSaveGoodsEvent extends ApplicationEvent {
    private static final long serialVersionUID = -1063394136818773237L;
    private Account account;
    private String attrId;

    public OralbFirstSaveGoodsEvent(Object source) {
        super(source);
    }

    public OralbFirstSaveGoodsEvent(Object source, Account account, String attrId) {
        super(source);
        this.account = account;
        this.attrId = attrId;
    }
}
