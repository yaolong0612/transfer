package com.pg.account.sharding.infrastructure.jpa.profile.education;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.EducationItem;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterEducationListJson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 * 教育类
 *
 * @author Jack
 * @date 2021/5/27 13:41
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_EDUCATION")
@DynamicUpdate
@DynamicInsert
@Data
public class ShardEducation extends BaseEntity implements Serializable {
    private static final long serialVersionUID = -6485653862311604981L;

    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    @Convert(converter = JpaConverterEducationListJson.class)
    @Column(columnDefinition = "NVARCHAR(MAX)")
    private List<EducationItem> educationList;

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.identityId = account.getIdentityId();
        this.educationList = account.getUserAdditionalInfo().getEducationList();
        super.addCreateTime();
    }

    public void buildFromAccount(Account account) {
        this.identityId = account.getIdentityId();
        this.educationList = account.getUserAdditionalInfo().getEducationList();
        super.addUpdatedTime();
    }

    public void buildFromDb(ShardEducation db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.id = Optional.ofNullable(this.id).orElse(db.getId());
            this.identityId = Optional.ofNullable(this.identityId).orElse(db.getIdentityId());
            Optional.ofNullable(this.getEducationList())
                    .ifPresent(eduList -> eduList
                            .forEach(e -> db.educationList
                                    .forEach(e::builder)));
        }
    }
}
