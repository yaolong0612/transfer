package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 * @date 2021/6/9 21:21
 **/
@Getter
public class UpdateCounterEvent extends ApplicationEvent {
    private static final long serialVersionUID = -262409890631938385L;

    private Account account;

    public UpdateCounterEvent(Object source) {
        super(source);
    }

    public UpdateCounterEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }

}
