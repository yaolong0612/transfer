package com.pg.account.interfaces.vo.v3;

/**
 * @author lfx
 * @date 2022/2/23 12:49
 */
public class V3ResultUtil {

    private V3ResultUtil() {
    }

    /**
     * 请求失败，返回状态码和提示信息
     *
     * @param code 状态码
     * @return 返回参数
     */
    public static V3Result error(Integer code, String frontMsg) {
        return new V3Result(code, frontMsg);
    }
}
