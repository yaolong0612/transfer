package com.pg.account.infrastructure.common.interceptor;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;
import org.apache.commons.lang3.StringUtils;

/**
 * @author Simon
 */
public class RequestIdConverter extends ClassicConverter {
    private static final ThreadLocal<String> REQUEST_ID_POOL = new ThreadLocal<>();

    public static String getRequestId() {
        String requestId = REQUEST_ID_POOL.get();
        if (StringUtils.isEmpty(requestId)) {
            return "NoN";
        }
        return requestId;
    }

    public static void setRequestId(String requestId) {
        REQUEST_ID_POOL.set(requestId);
    }

    public static void remove() {
        REQUEST_ID_POOL.remove();
    }

    @Override
    public String convert(ILoggingEvent event) {
        return getRequestId();
    }
}
