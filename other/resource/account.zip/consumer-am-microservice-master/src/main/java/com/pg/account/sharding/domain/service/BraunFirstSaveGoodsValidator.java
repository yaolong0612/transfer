package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.stereotype.Component;

/**
 * @author JackSun
 */
@Component
@Slf4j
public class BraunFirstSaveGoodsValidator {

    private final AddAwardWrapperService addAwardWrapperService;

    public BraunFirstSaveGoodsValidator(AddAwardWrapperService addAwardWrapperService) {
        this.addAwardWrapperService = addAwardWrapperService;
    }

    /**
     * 检查数据是否首次保存
     *
     * @param attributes attributes
     * @return String
     */
    public String validator(ExtraAttributeItem attributes) {
        return attributes.getAttrValue();
    }

    /**
     * 执行添加积分事件
     *
     * @param account account
     */
    public void runEvent(Account account, String attrId) {
        Validate.notNull(account, "BraunFirstSaveGoodsValidator account is null");
        addAwardWrapperService.addFirstSaveGoodsPoints(account.getTenantId(), account.getRegisterChannelId(), account.getAccountId());
    }
}
