package com.pg.account.interfaces.facade.v2.assembler;

import com.pg.account.interfaces.command.v2.AccountSubscriptionsModifyCommand;
import com.pg.account.interfaces.command.v2.SubscriptionCommand;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * @author wsq
 * @date 2021/6/8 17:30
 **/
@Component
public class ModifySubscriptionsAssembler {

    public ShardSubscription toShardSubscription(AccountSubscriptionsModifyCommand command, String tenantId, String channelId, String accountId) {
        ShardSubscription shardSubscription = new ShardSubscription();
        List<SubscriptionItem> subscriptionItems = toSubscriptionItem(command.getSubscriptions());
        shardSubscription.setIdentityId(new IdentityId(tenantId, accountId));
        shardSubscription.setSubscriptionList(subscriptionItems);
        shardSubscription.getSubscriptionList().forEach(subscriptionItem -> {
            subscriptionItem.setChannelId(channelId);
        });
        return shardSubscription;
    }

    private List<SubscriptionItem> toSubscriptionItem(Set<SubscriptionCommand> subscriptionCommands) {
        List<SubscriptionItem> subscriptionItemList = new ArrayList<>();
        Optional.ofNullable(subscriptionCommands)
                .filter(subscriptionCommands1 -> !subscriptionCommands1.isEmpty())
                .ifPresent(subscriptionCommands1 -> subscriptionCommands1.forEach(subscriptionCommand -> {
                    SubscriptionItem subscriptionItem = new SubscriptionItem();
                    subscriptionItem.setOptId(subscriptionCommand.getOptId());
                    subscriptionItem.setOptStatus(subscriptionCommand.getOptStatus());
                    subscriptionItem.setTermsList(new ArrayList<>());
                    subscriptionItemList.add(subscriptionItem);
                }));
        return subscriptionItemList;
    }
}
