package com.pg.account.sharding.infrastructure.jpa.mapping.retention;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author lfx
 * @date 2021/5/31 14:48
 */
public interface OpenUidMappingRetentionDao extends JpaRepository<OpenUidMappingRetention, Long> {

    /**
     * 删除mapping 根据tenantId和accountId
     *
     * @param accountId accountId
     * @param tenantId  tenantId
     */
    void deleteByAccountIdAndTenantId(String accountId, String tenantId);

}
