package com.pg.account.sharding.application.cmdservice;

import com.pg.account.sharding.domain.service.annotation.IsValidTenant;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

/**
 * @author lfx
 * @date 2022/2/10 9:36
 */
@Validated
@Component
public interface CancelService {

    /**
     * 退会
     *
     * @param tenant    tenant
     * @param type type
     * @param query query
     * @return string 返回accountId
     */
    String cancelAccount(@IsValidTenant String tenant, String type, String query);
}
