package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author JackSun
 */
@Component
@Slf4j
@Service("shardOralbFirstModifyValidator")
public class OralbFirstModifyValidator {

    private final AddAwardWrapperService addAwardWrapperService;

    @Autowired
    public OralbFirstModifyValidator(AddAwardWrapperService addAwardWrapperService) {
        this.addAwardWrapperService = addAwardWrapperService;
    }

    /**
     * 检查数据是否首次保存
     *
     * @param attributes attributes
     * @return String
     */
    public String validator(ExtraAttributeItem attributes) {
        return attributes.getAttrValue();
    }

    /**
     * 执行添加积分事件
     *
     * @param account account
     * @param attrId  attrId
     */
    public void runEvent(Account account, String attrId) {
        Validate.notNull(account, "OralbFirstModifyValidator account is null");
        addAwardWrapperService.addFirstModifyPoints(account.getTenantId(), account.getRegisterChannelId(), account.getAccountId());
    }

}
