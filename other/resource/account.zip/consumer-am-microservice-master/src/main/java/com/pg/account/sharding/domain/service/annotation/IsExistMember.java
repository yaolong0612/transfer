package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.domain.service.SubscriptionValidator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author wsq
 * @date 2021/6/16 9:37
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = SubscriptionValidator.MemberIsExist.class)
public @interface IsExistMember {

    String message() default "account not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
