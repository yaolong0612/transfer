package com.pg.account.sharding.application.cmdservice;

import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.service.annotation.IsValidOptId;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

/**
 * @author lfx
 * @date 2022/2/11 14:33
 */
@Validated
@Component
public interface ModifySubscriptionService {

    /**
     * 修改订阅
     *
     * @param subscription subscription
     */
    void modifySubscription(@IsValidOptId ShardSubscription subscription);
}
