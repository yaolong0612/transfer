package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 * @date 2021-6-9-21:19:38
 */
@Getter
public class ActiveEvent extends ApplicationEvent {
    private static final long serialVersionUID = 1812143508219848714L;
    private Account account;

    public ActiveEvent(Object source) {
        super(source);
    }

    public ActiveEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }

}
