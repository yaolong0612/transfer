package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.Data;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * openUid映射类
 * 用于将openUid映射成accountId
 *
 * @author LC
 */
@Data
@DynamicUpdate
@DynamicInsert
@Table
@Entity
public class OpenUidMapping extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 3410207103399428979L;

    private Long id;

    @EmbeddedId
    private OpenUidMapId openUidMapId;

    @Column(name = "account_id")
    private String accountId;


    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.accountId = account.getAccountId();
        this.openUidMapId = new OpenUidMapId(account.getTenantId(), account.getOpenUid());
        super.addCreateTime();
    }

    public void builder(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.accountId = account.accountId();
        this.openUidMapId = new OpenUidMapId(account.tenantId(), account.getOpenUid());
        super.addCreateTime();
    }
}
