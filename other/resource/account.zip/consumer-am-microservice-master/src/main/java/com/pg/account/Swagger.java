package com.pg.account;

import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.PathProvider;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import javax.servlet.ServletContext;

/**
 * @author JackSun
 */
@Configuration
@EnableOpenApi
public class Swagger {
    private final ServletContext servletContext;

    @Autowired
    public Swagger(ServletContext servletContext) {
        this.servletContext = servletContext;
    }

    @Bean
    public Docket createRestApi() {
        return createOnlineRestApi();
    }

    /**
     * 离线文档
     *
     * @return Docket
     */
    private Docket createOfflineRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .host("api-consumer-qa.cn-pgcloud.com").pathProvider(new PathProvider() {
                    @Override
                    public String getOperationPath(String operationPath) {
                        return "/cms-account-micro-service";
                    }

                    @Override
                    public String getResourceListingPath(String groupName, String apiDeclaration) {
                        return null;
                    }
                })
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                .paths(PathSelectors.any())
                .build().forCodeGeneration(true);
    }

    /**
     * 线上文档
     *
     * @return Docket
     */
    private Docket createOnlineRestApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                .paths(PathSelectors.any())
                .build().forCodeGeneration(true);
    }

    /**
     * API 文档信息
     *
     * @return ApiInfo
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Account Management Micro Service")
                .description("## Account management service is the repository to maintain consumer profiles.\n\r" +
                        "\n" +
                        "### Note: tenant, channel, source, and attr Id are parameters that need to be applied to the AM. The API needs to be configured before the AM can be properly tuned.\n\r" +
                        "\n" +
                        "### AM docking document reference information address：https://confluence-wiki.pg.com.cn/display/CC/1.+AM+new+channel+request\n\r" +
                        "\n" +
                        "### Jira ticket submission address：https://jira.pg.com.cn/servicedesk/customer/portal/9/create/209\n\r" +
                        "\n" +
                        "\n" +
                        "# **码表**\n" +
                        "\n" +
                        "## AM的错误码为5位数,以AM Code和Error Code拼接而成\n" +
                        "### 示例：51001\n" +
                        "       5代表AM\n" +
                        "       1001代表错误编号\n" +
                        "\n" +
                        "\n" +
                        "## **业务错误**\n" +
                        "| v1 Error Code | v2 Error Code | Error Message |\n" +
                        "| :----: | :----: | :----: |\n" +
                        "| 51000 | 51000 | format error |\n" +
                        "| 51001 | 51001 | tenantId is incorrect |\n" +
                        "| 51002 | 51002 | channelId is incorrect |\n" +
                        "| 51006 | 51012 | mobile is error |\n" +
                        "| 51007 | 51013 | email is error |\n" +
                        "| 51012 | 51011 | memberId is error |\n" +
                        "| 51013 | 51010 | openUid is error |\n" +
                        "| 51018 | 51007 | password is error |\n" +
                        "| 51024 | 51045 | message template id is error |\n" +
                        "| 51025 | 51046 | message code is error |\n" +
                        "| 51031 | 51047 | original password is error |\n" +
                        "| 51032 | 51048 | change password is error |\n" +
                        "| 51301 | 51006 | username is error |\n" +
                        "| 51302 | 51014 | mobile is exist |\n" +
                        "| 51303 | 51015 | email is exist |\n" +
                        "| 51304 | 51005 | user is exist |\n" +
                        "| 51306 | 51044 | repeat opt_id |\n" +
                        "| 51308 | 51032 | account not exist |\n" +
                        "| 51309 | 51004 | more than one users, please contact customer service |\n" +
                        "| 51311 | 51028 | account status missing |\n" +
                        "| 51312 | 51029 | account has expired |\n" +
                        "| 51313 | 51030 | account has been deleted |\n" +
                        "| 51314 | 51049 | user login errors has reached the limit |\n" +
                        "| 51317 | 51041 | subscription type does not exist |\n" +
                        "| 51319 | 51018 | bind data type conflicts |\n" +
                        "| 51320 | 51031 | bind data does not exist |\n" +
                        "| 51321 | 51027 | unionId's bound data does not exist |\n" +
                        "| 51322 | 51018 | bind data conflict |\n" +
                        "| 51331 | 51017 | unionId data conflict |\n" +
                        "| 51332 | 51050 | unionId data type conflict |\n" +
                        "| 51333 | 51051 | user attribute data exists |\n" +
                        "| 51338 | 51009 | unionId is null |\n" +
                        "| 51339 | 51024 | many babies have birthdays less than a year apart or on different days |\n" +
                        "| 51340 | 51025 | baby's birthday is incorrect |\n" +
                        "| 51341 | 51341 | customization error |\n" +
                        "| 51343 | 51036 | parameter error |\n" +
                        "| 51344 | 51043 | account data conflict |\n" +
                        "| 51019 | 51019 | query type is is null |\n" +
                        "| 51020 | 51020 | query validation is error |\n" +
                        "| 51033 | 51033 | register type is not exist |\n" +
                        "| 51034 | 51034 | query fields is error |\n" +
                        "| 51035 | 51035 | query type not exist |\n" +
                        "| 51037 | 51037 | relation id not exist |\n" +
                        "| 51038 | 51038 | user name format error |\n" +
                        "| 51039 | 51039 | user name must equals to the specified value |\n" +
                        "| 51040 | 51040 | register type choose error |\n" +
                        "| 51042 | 51042 | relationship and sequence must be unique |\n" +
                        "| 51336 | 51021 | the user is under the age of 18 and is not an adult |\n" +
                        "| 51337 | 51023 | user attribute data type is incorrect |\n" +
                        "| 51325 | 51325 | incorrect password change type |\n" +
                        "| 51326 | 51326 | duplicate address type |\n" +
                        "| 51328 | 51328 | query parameters are incorrect |\n" +
                        "| 51022 | 51022 | account identification information is incorrect |\n" +
                        "| 51011 | 51052 | incorrect user attribute information content |\n" +
                        "\n" +
                        "## **系统配置错误**\n" +
                        "| v1 Error Code | v2 Error Code | Error Message |\n" +
                        "| :----: | :----: | :----: |\n" +
                        "| 52001 | 52001 | tenant config is not exist |\n" +
                        "| 52002 | 52002 | channel config is not exist |\n" +
                        "| 52003 | 52003 | source config is not exist |\n" +
                        "| 52004 | 52004 | system config is not exist |\n" +
                        "| 52005 | 52005 | system config is error |\n" +
                        "\n" +
                        "## **外部系统错误**\n" +
                        "| v1 Error Code | v2 Error Code | Error Message |\n" +
                        "| :----: | :----: | :----: |\n" +
                        "| 53001 | 53001 | address microservice error |\n" +
                        "| 53002 | 53002 | ACL/MINI_ACL microservice error |\n" +
                        "| 53003 | 53003 | ACL/MINI_ACL unionId not exist |\n" +
                        "| 53004 | 53004 | award microservice error |\n" +
                        "| 53005 | 53005 | loyalty microservice error |\n" +
                        "| 53006 | 53006 | sms microservice error |\n" +
                        "\n" +
                        "## **系统错误**\n" +
                        "| v1 Error Code | v2 Error Code | Error Message |\n" +
                        "| :----: | :----: | :----: |\n" +
                        "| 54001 | 54001 | db error |\n" +
                        "| 54002 | 54002 | redis service error |\n" +
                        "| 54003 | 54003 | baiDu snowflake algorithm error |\n" +
                        "| 54004 | 54004 | service bus error |\n" +
                        "| 54005 | 54005 | event hub error |\n" +
                        "| 54006 | 54006 | mq error |\n" +
                        "| 54007 | 54007 | table Storage error |\n" +
                        "| 59999 | 59999 | System Error |\n"
                )
                .contact(new Contact("ZhuYaoLong", null, "zhu.y.42@pg.com"))
                .termsOfServiceUrl("http://www.pg.com/zh_CN/terms_conditions/index.shtml")
                .license("Reserved by P&G")
                .version("6.0")
                .build();
    }
}
