package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * 用户属性添加和修改同步DMP事件
 *
 * @author yj
 * @date 2021-6-9
 */
@Getter
public class DeleteAttributeEvent extends ApplicationEvent {
    private static final long serialVersionUID = -5098131018811665561L;
    private Account account;

    public DeleteAttributeEvent(Object source) {
        super(source);
    }

    public DeleteAttributeEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }
}
