package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 设备信息类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "DeviceDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceDTO implements Serializable {

    private static final long serialVersionUID = -6065958332178031462L;
    @ApiModelProperty(value = "Device system, column: ios and android", name = "os", example = "android", required = true)
    private String os;
    @ApiModelProperty(value = "Current application version number", name = "appv", example = "10")
    private String appv;
    @ApiModelProperty(value = "Application package name, ios is the bundle ID", name = "packageName", example = "cn.com.pg.android")
    private String packageName;
    @ApiModelProperty(value = "IOS system idfa original value, android is advertisiong ID", name = "idfa", example = "C1CEA826-A684-43EF-93FF-A219D00C0E59")
    private String idfa;
    @ApiModelProperty(value = "android device imei", name = "imei", example = "4cd07a422573af446079621a784c67ec")
    private String imei;
    @ApiModelProperty(value = "android device oaid", name = "oaid", example = "4cd07a422573af446079621a784c67ec")
    private String oaid;
    @ApiModelProperty(value = "Standard api to get mac address", name = "mac", example = "C0:9F:05:B6:A4:A2")
    private String mac;
    @ApiModelProperty(value = "Openudid of the original collection, when unable to obtain, pass an empty string", name = "openudid", example = "XXXX21f1f19edff198e2a2356bf4XXXX ")
    private String openudid;
    @ApiModelProperty(value = "Android system android ID, when unable to get, pass empty string", name = "androidid", example = "9774d56d682e549c")
    private String androidid;
    @ApiModelProperty(value = "Current phone model", name = "model", example = "P30 PROD")
    private String model;
    @ApiModelProperty(value = "Current mobile phone brand name", name = "brand", example = "华为")
    private String brand;
    @ApiModelProperty(value = "Whether ad tracking is restricted, 0 means that ad tracking is not restricted, 1 otherwise", name = "adTracked", example = "0")
    private String adTracked;

}
