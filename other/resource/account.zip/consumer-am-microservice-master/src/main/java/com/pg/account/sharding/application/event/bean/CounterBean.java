package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Jack Sun
 * @date 2019-6-19 9:15
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterBean implements Serializable {
    private static final long serialVersionUID = -5000915536926936582L;
    @JSONField(name = "member_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @JSONField(name = "marketing_program_id")
    private int marketingProgramId;
    @JSONField(name = "update_flag")
    private char updateFlag;
    @JSONField(name = "create_datetime")
    private Timestamp createDatetime;
    @JSONField(name = "modify_datetime")
    private Timestamp modifyDatetime;
    @JSONField(name = "reg_counter")
    private String regCounter;
    @JSONField(name = "main_counter")
    private String mainCounter;
    @JSONField(name = "pickup_counter")
    private String pickupCounter;
    @JSONField(name = "offline_first_purchase_counter")
    private String offlineFirstPurchaseCounter;
    @JSONField(name = "first_purchase_counter")
    private String firstPurchaseCounter;
    @JSONField(name = "first_purchase_time")
    private String firstPurchaseTime;
    @JSONField(name = "crm_pickup_counter")
    private String crmPickupCounter;
    @JSONField(name = "offline_last_purchase_counter")
    private String offlineLastPurchaseCounter;
    @JSONField(name = "member_belong_to_counter")
    private String memberBelongToCounter;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
