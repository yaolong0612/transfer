package com.pg.account.infrastructure.validator.annotation;


import com.pg.account.infrastructure.validator.TenantNotNullValid;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 用于校验租户是否存在
 *
 * @author lfx
 * @date 2021/4/22 9:26
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = TenantNotNullValid.class)
public @interface TenantExistValid {

    String message() default "tenant is not exist";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
