package com.pg.account.infrastructure.common.utils;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.BeansException;

import java.beans.PropertyDescriptor;
import java.util.HashSet;
import java.util.Set;

/**
 * 表单bean工具类
 *
 * @author Jack Sun
 * @date 2019-2-18 10:25
 */
public class EntityBeanUtil {
    /**
     * 忽略的Bean属性
     */
    private static final String[] DEFAULT_FIELDS = new String[]{
            "createTime",
            "createBy"
    };

    private EntityBeanUtil() {
    }

    /**
     * 获取为null的属性参数
     *
     * @param source source
     * @return array of String
     */
    public static String[] getNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        PropertyDescriptor[] pds = src.getPropertyDescriptors();

        Set<String> emptyNames = new HashSet<>();
        for (PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());
            if (srcValue == null) {
                emptyNames.add(pd.getName());
            }
        }
        String[] result = new String[emptyNames.size()];
        return emptyNames.toArray(result);
    }


    /**
     * 封装spring的BeanUtils工具对象，忽略为null的bean属性
     *
     * @param source 源对象
     * @param target 目标对象
     */
    public static void copyPropertiesIsNotNull(Object source, Object target) throws BeansException {
        BeanUtils.copyProperties(source, target, getNullPropertyNames(source));
    }

    /**
     * 封装spring的BeanUtils工具对象，忽略部分Bean属性
     *
     * @param source 源对象
     * @param target 目标对象
     */
    public static void copyProperties(Object source, Object target) throws BeansException {
        BeanUtils.copyProperties(source, target, DEFAULT_FIELDS);
    }

    /**
     * 封装spring的BeanUtils工具对象，忽略指定Bean属性
     *
     * @param source 源对象
     * @param target 目标对象
     */
    public static void copyProperties(Object source, Object target, String... fields) throws BeansException {
        BeanUtils.copyProperties(source, target, fields);
    }
}
