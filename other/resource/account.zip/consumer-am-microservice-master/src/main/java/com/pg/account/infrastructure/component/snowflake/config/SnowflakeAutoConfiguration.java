package com.pg.account.infrastructure.component.snowflake.config;

import com.pg.account.infrastructure.common.constants.SnowFlakeConstants;
import com.pg.account.infrastructure.component.snowflake.SnowFlakeLog;
import com.pg.account.infrastructure.component.snowflake.Snowflake;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.infrastructure.component.uid.utils.BaseNetUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import java.util.concurrent.ThreadLocalRandom;

/**
 * 雪花算法初始化配置
 *
 * @author xusheng
 * @date 2019/12/22 19:02
 */
@Slf4j
@Configuration
@Lazy
public class SnowflakeAutoConfiguration {

    private final UidGenerator uidGenerator;

    @Autowired
    public SnowflakeAutoConfiguration(UidGenerator uidGenerator) {
        this.uidGenerator = uidGenerator;
    }

    @Bean
    public Snowflake snowflake() {
        Snowflake snowflake = initSnowflake();
        log.info("【当前workerId为：{}，dataCenterId为：{}】", snowflake.getWorkerId(), snowflake.getDataCenterId());
        return snowflake;
    }

    /**
     * 初始化雪花
     *
     * @return 返回雪花实例
     */
    private Snowflake initSnowflake() {
        // 判断生成的数据中心Id和工作Id是否存在
        boolean flag = false;
        // 取一个随机机器码id
        long workerId = ThreadLocalRandom.current().nextLong(0, SnowFlakeConstants.MAX_MACHINE_NUM);
        // 取一个随机数据中心id
        long dataCenterId = ThreadLocalRandom.current().nextLong(0, SnowFlakeConstants.MAX_DATACENTER_NUM);
        String hostName = BaseNetUtils.getLocalAddress();
        SnowFlakeLog existSnowflake = new SnowFlakeLog();
        existSnowflake.setWorkId(1L);
        existSnowflake.setDataCenterId(1L);
//        SnowFlakeLog existSnowflake = snowFlakeLogRepository.findSnowFlakeLogByHostNameAndWorkIdAndDataCenterId(hostName, workerId, dataCenterId);
//        if (null == existSnowflake) {
//            SnowFlakeLog snowFlakeLog = new SnowFlakeLog(uidGenerator, hostName, workerId, dataCenterId);
//            snowFlakeLogRepository.save(snowFlakeLog);
//        } else {
//            flag = true;
//        }
        Snowflake availableSnowflake;
//         当前随机机器码id与数据中心id被占用
        if (flag) {
            // 获取可用雪花
            availableSnowflake = new Snowflake(existSnowflake.getWorkId(), existSnowflake.getDataCenterId());
        } else {
            // 初始化可用雪花
            availableSnowflake = new Snowflake(workerId, dataCenterId);
        }
        return availableSnowflake;
    }
}
