package com.pg.account.infrastructure.common.config;

import cn.com.pg.paas.monitor.infrastructure.monitor.ApiMetricFilter;
import com.pg.account.infrastructure.common.filter.AccessLogFilter;
import com.pg.account.infrastructure.common.filter.StreamXssFilter;
import com.pg.account.infrastructure.common.filter.XssFilter;
import com.pg.account.infrastructure.common.interceptor.SystemInterceptor;
import com.pg.account.sharding.infrastructure.interceptor.AppGuardianInterceptor;
import com.pg.account.sharding.infrastructure.switchconfig.SwitchConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.DispatcherType;

/**
 * 拦截器配置
 *
 * @author Jack Sun
 * @date 2019-12-4
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private final ApiMetricFilter apiMetricFilter;

    private final SystemInterceptor systemInterceptor;
    private final AppGuardianInterceptor appGuardianInter;

    private final SwitchConfiguration switchConfiguration;

    @Autowired
    public WebMvcConfig(SystemInterceptor systemInterceptor, ApiMetricFilter apiMetricFilter, SwitchConfiguration switchConfiguration, AppGuardianInterceptor appGuardianInter) {
        this.systemInterceptor = systemInterceptor;
        this.appGuardianInter = appGuardianInter;
        this.apiMetricFilter = apiMetricFilter;
        this.switchConfiguration = switchConfiguration;
    }

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.setUseSuffixPatternMatch(false).setUseTrailingSlashMatch(false);
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(appGuardianInter).addPathPatterns("/protected/**");
        registry.addInterceptor(systemInterceptor).addPathPatterns("/**");
    }

    @Bean
    public FilterRegistrationBean<ApiMetricFilter> registerApiFilter() {
        FilterRegistrationBean<ApiMetricFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(apiMetricFilter);
        registration.setDispatcherTypes(DispatcherType.FORWARD, DispatcherType.REQUEST);
        registration.addUrlPatterns("/*");
        registration.setName("apiMetricFilter");
        registration.setOrder(Ordered.LOWEST_PRECEDENCE);
        return registration;
    }


    @Bean
    public FilterRegistrationBean<AccessLogFilter> accessLogFilterRegistration() {
        FilterRegistrationBean<AccessLogFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new AccessLogFilter());
        registration.addUrlPatterns("/*");
        registration.setName("accessLogFilter");
        registration.setDispatcherTypes(DispatcherType.FORWARD, DispatcherType.REQUEST);
        registration.setOrder(5);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<XssFilter> xssFilterRegistration() {
        FilterRegistrationBean<XssFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new XssFilter());
        registration.addUrlPatterns("/*");
        registration.setName("xssFilter");
        registration.setDispatcherTypes(DispatcherType.FORWARD, DispatcherType.REQUEST);
        registration.setOrder(2);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<StreamXssFilter> streamXssFilterRegistration() {
        FilterRegistrationBean<StreamXssFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new StreamXssFilter());
        registration.addUrlPatterns("/*");
        registration.setName("streamXssFilter");
        registration.setDispatcherTypes(DispatcherType.FORWARD, DispatcherType.REQUEST);
        registration.setOrder(3);
        return registration;
    }
}
