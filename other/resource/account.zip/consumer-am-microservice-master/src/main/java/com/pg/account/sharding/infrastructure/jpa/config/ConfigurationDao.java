package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Jack
 * @date 2021/5/31 13:37
 */
public interface ConfigurationDao extends JpaRepository<ShardConfiguration, Long> {
    /**
     * 查询配置
     *
     * @param tenantId tenantId
     * @param key      key
     * @return Configuration
     */
    ShardConfiguration findByTenantIdAndConfigKey(String tenantId, String key);

    /**
     * 查询配置
     *
     * @param key key
     * @return Configuration
     */
    ShardConfiguration findByConfigKey(String key);
}
