//package com.pg.account.sharding.application.event.listener;
//
//import cn.com.pg.paas.stream.framework.StreamTemplate;
//import com.alibaba.fastjson.JSONObject;
//import com.pg.account.application.event.*;
//import com.pg.account.domain.model.account.Account;
//import com.pg.account.domain.model.counter.Counter;
//import com.pg.account.domain.model.log.DataStream;
//import com.pg.account.domain.model.profile.*;
//import com.pg.account.domain.model.socialaccount.SocialAccount;
//import com.pg.account.domain.model.socialaccount.SocialAccountUnionId;
//import com.pg.account.infrastructure.common.enums.AttrIdEnum;
//import com.pg.account.infrastructure.component.uid.UidGenerator;
//import com.pg.account.infrastructure.repositories.DataStreamRepository;
//import com.pg.account.sharding.domain.model.account.*;
//import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
//import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
//import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
//import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
//import com.pg.account.sharding.infrastructure.client.address.Address;
//import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
//import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.event.EventListener;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.stereotype.Component;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static com.alibaba.fastjson.JSON.toJSONString;
//import static com.pg.account.infrastructure.common.constants.AccountConstants.PRODUCER_EVENT_HUB;
//import static java.lang.String.valueOf;
//
///**
// * @Author wsq
// * @Description
// * @Date 2021/6/17 22:04
// **/
//@Component()
//@Slf4j
//public class OldDataSyncListener {
//
//    public static final String AM_REGISTER_IN_SHARDING_EVENT_HUB = "AM_REGISTER_IN_SHARDING_EVENT_HUB";
//    public static final String FLAG = "flag";
//    public static final String ACCOUNT = "account";
//    public static final String SHARD_SUBSCRIPTION = "shardSubscription";
//    public static final String EVENT_TYPE = "eventType";
//    public static final String CREATE_TIME = "createTime";
//    public static final String REGISTER_EVENT = "registerEvent";
//    public static final String REGISTER_BIND_EVENT = "registerBindEvent";
//    public static final String SHARD_SOCIAL_ACCOUNT = "shardSocialAccount";
//    private final StreamTemplate streamTemplate;
//    private final ChannelDao channelDao;
//    private final DataStreamRepository dataStreamRepository;
//    private final UidGenerator uidGenerator;
//    @Value("${event_hub.doubleWriteEventTypeId}")
//    private String doubleWriteEventTypeId;
//    @Value("${event_hub.retryCount}")
//    private int retryCount;
//    private boolean result;
//
//
//    @Autowired
//    public OldDataSyncListener(StreamTemplate streamTemplate, ChannelDao channelDao, DataStreamRepository dataStreamRepository,
//                               UidGenerator uidGenerator) {
//        this.streamTemplate = streamTemplate;
//        this.channelDao = channelDao;
//        this.dataStreamRepository = dataStreamRepository;
//        this.uidGenerator = uidGenerator;
//    }
//
//    public static CounterInfo toCounterInfo(Counter counter) {
//        if (Optional.ofNullable(counter).isPresent()) {
//            return new CounterInfo(counter.getRegCounterCode(),
//                    counter.getRegCounterName(),
//                    counter.getMainCounterCode(),
//                    counter.getMainCounterName(),
//                    counter.getPickupCounterCode(),
//                    counter.getPickupCounterName(),
//                    counter.getOfflineFirstPurchaseCounterCode(),
//                    counter.getOfflineFirstPurchaseCounterName(),
//                    counter.getFirstPurchaseCounterCode(),
//                    counter.getFirstPurchaseTime(),
//                    counter.getCrmPickupCounterCode(),
//                    null,
//                    null,
//                    null,
//                    null,
//                    counter.getCreateTime() == null ? null : counter.getCreateTime().toLocalDateTime(), counter.getModifyTime() == null ? null : counter.getModifyTime().toLocalDateTime());
//        }
//        return null;
//    }
//
//    public static DeviceInfo toDeviceInfo(Devices devices) {
//        if (Optional.ofNullable(devices).isPresent()) {
//            return new DeviceInfo(devices.getOs(), devices.getAppv(),
//                    devices.getPackageName(), devices.getIdfa(),
//                    devices.getImei(), devices.getOaid(), devices.getMac(),
//                    devices.getOpenudid(), devices.getAndroidid(),
//                    devices.getModel(), devices.getBrand(), devices.getAdTracked(),null);
//        }
//        return null;
//    }
//
//    public static Address toAddress(List<com.pg.account.infrastructure.component.client.address.Address> addresses) {
//        if (Optional.ofNullable(addresses).filter(addressCommands -> !addressCommands.isEmpty()).isPresent()) {
//            com.pg.account.infrastructure.component.client.address.Address addressCommand = addresses.get(0);
//            return new Address(addressCommand.getAddressCode(), addressCommand.getIsPrimary(), addressCommand.getAddressType(),
//                    addressCommand.getFullName(), addressCommand.getCellphone(), addressCommand.getPhone(), addressCommand.getProvince(),
//                    addressCommand.getCity(), addressCommand.getDistrict(), addressCommand.getAddress(), addressCommand.getPostcode());
//        }
//        return null;
//    }
//
//    public static List<ExtraAttributeItem> toExtraAttributeItem(List<Attributes> attrCommandList) {
//        List<ExtraAttributeItem> extraAttributes = null;
//        if (Optional.ofNullable(attrCommandList).filter(attrCommands -> !attrCommands.isEmpty()).isPresent()) {
//            extraAttributes = new ArrayList<>();
//            for (Attributes attrCommand : attrCommandList) {
//                if (AttrIdEnum.isInclude(attrCommand.getAttrId())) {
//                    continue;
//                }
//                ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem(attrCommand.getAttrId(), null,
//                        attrCommand.getAttrValue(), LocalDateTime.now(), LocalDateTime.now());
//                extraAttributes.add(extraAttributeItem);
//            }
//        }
//        return extraAttributes;
//    }
//
//    public static List<JobItem> toJobItem(List<Job> jobList) {
//        List<JobItem> jobItems = null;
//        if (Optional.ofNullable(jobList).filter(jobList1 -> !jobList1.isEmpty()).isPresent()) {
//            jobItems = new ArrayList<>();
//            for (Job job : jobList) {
//                AddressInfo addressInfo = new AddressInfo(job.getProvince(), job.getCity(), job.getDistrict(), job.getUnitAddress(), null);
//                Relation relation = new Relation();
//                relation.setSequence(job.getRelationshipSequence());
//                relation.setRelationType(RelationType.getRelation(job.getRelationship()));
//                JobItem jobItem = new JobItem(relation, job.getUnitName(), job.getUnitCategory(), addressInfo, job.getProfession(), job.getCreateTime().toLocalDateTime(), job.getModifyTime().toLocalDateTime());
//                jobItems.add(jobItem);
//            }
//        }
//        return jobItems;
//    }
//
//    public static List<EducationItem> toEducationItem(List<Education> educationList) {
//        List<EducationItem> educationItems = null;
//        if (Optional.ofNullable(educationList).filter(educationList1 -> !educationList1.isEmpty()).isPresent()) {
//            educationItems = new ArrayList<>();
//            for (Education education : educationList) {
//                Relation relation = new Relation();
//                relation.setSequence(education.getRelationshipSequence());
//                relation.setRelationType(RelationType.getRelation(education.getRelationship()));
//                AddressInfo addressInfo = new AddressInfo(education.getProvince(), education.getCity(), education.getDistrict(), education.getSchoolAddress(), null);
//                EducationItem educationItem = new EducationItem(relation, education.getSchoolName(), education.getSchoolCategory(), addressInfo, education.getCollege(), education.getMajor(),
//                        education.getGrade(), education.getClassName(), education.getDegree(), education.getAdmissionTime(),
//                        education.getGraduationTime(), education.getCreateTime().toLocalDateTime(), education.getModifyTime().toLocalDateTime());
//                educationItems.add(educationItem);
//            }
//        }
//        return educationItems;
//    }
//
//    public static List<HumanRelationItem> toHumanRelationItem(List<InterpersonalRelationShip> interpersonalRelationShipList) {
//        List<HumanRelationItem> humanRelationItems = null;
//        if (Optional.ofNullable(interpersonalRelationShipList).filter(interpersonalRelationShipList1 -> !interpersonalRelationShipList1.isEmpty()).isPresent()) {
//            humanRelationItems = new ArrayList<>();
//            for (InterpersonalRelationShip ship : interpersonalRelationShipList) {
//                Relation relation = new Relation();
//                Person person = new Person();
//                person.setGender(ship.getGender());
//                person.setFullName(ship.getFullName());
//                person.setBirthday(ship.getBirthday());
//                Contact contact = new Contact();
//                contact.setMobile(ship.getCellphone());
//                person.setContact(contact);
//                relation.setRelationType(RelationType.getRelation(ship.getRelationship()));
//                relation.setSequence(ship.getRelationshipSequence());
//                HumanRelationItem humanRelationItem = new HumanRelationItem(person, relation, ship.getGuardian(), ship.getCreateTime().toLocalDateTime(), ship.getModifyTime().toLocalDateTime());
//                humanRelationItems.add(humanRelationItem);
//            }
//        }
//        return humanRelationItems;
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.regEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    /**
//     * 注册绑定监听
//     *
//     * @param event event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterBindEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.regBindEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(ChangePasswordEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.changePwdEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    /**
//     * @Description 修改属性监听
//     * @Date 2021/6/22 21:30
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateAttributeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateAttrEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(DeleteAttributeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.deleteAttrEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(BindingEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.bingingEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateProfileEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateProfileEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateSubscriptionEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateSubscriptionEvent(event.getAccount(), event.getFlag());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UnBindingEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.unBindingEvent(event.getAccount(), event.getUnBindType());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(InActiveEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.inActiveEvent(event.getAccount());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(ActiveEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.activeEvent(event.getAccount());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(SubscribeEvent event) {
//        if (Optional.ofNullable(event.getAccount()).isPresent()) {
//            this.subscribeEvent(event.getAccount());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UnSubscribeEvent event) {
//        if (Optional.ofNullable(event.getAccount()).isPresent()) {
//            this.unSubscribeEvent(event.getAccount());
//        }
//    }
//
//    private void unSubscribeEvent(Account account) {
//        if (!Optional.ofNullable(account).map(Account::getMemberId).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSocialAccount shardSocialAccount = toShardSocialAccount(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSocialAccountList(), account.getSocialAccountUnionIdList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, "old");
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SOCIAL_ACCOUNT, shardSocialAccount);
//                jsonObject.put(EVENT_TYPE, "unSubscribeEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("subscribe error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//
//    }
//
//    private void subscribeEvent(Account account) {
//        if (!Optional.ofNullable(account).map(Account::getMemberId).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSocialAccount shardSocialAccount = toShardSocialAccount(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSocialAccountList(), account.getSocialAccountUnionIdList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, "old");
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SOCIAL_ACCOUNT, shardSocialAccount);
//                jsonObject.put(EVENT_TYPE, "subscribeEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("subscribe error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void activeEvent(Account account) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, "old");
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(EVENT_TYPE, "activeEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("active error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//
//    }
//
//    private void inActiveEvent(Account account) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, "old");
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(EVENT_TYPE, "inActiveEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("unbinding error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void unBindingEvent(Account account, String unBindType) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                ShardSocialAccount shardSocialAccount = toShardSocialAccount(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSocialAccountList(), account.getSocialAccountUnionIdList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, "old");
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put("unBindType", unBindType);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(SHARD_SOCIAL_ACCOUNT, shardSocialAccount);
//                jsonObject.put(EVENT_TYPE, "unBindingEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("unbinding error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void updateSubscriptionEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(EVENT_TYPE, "updateSubscriptionEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("updateSubscription error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void updateProfileEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(EVENT_TYPE, "updateProfileEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("updateProfile error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void bingingEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                ShardSocialAccount shardSocialAccount = toShardSocialAccount(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSocialAccountList(), account.getSocialAccountUnionIdList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(SHARD_SOCIAL_ACCOUNT, shardSocialAccount);
//                jsonObject.put(EVENT_TYPE, "bindingEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("binding error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void deleteAttrEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(EVENT_TYPE, "deleteAttributeEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("deleteAttribute error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void updateAttrEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(EVENT_TYPE, "updateAttributeEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("updateAttribute error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void changePwdEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(EVENT_TYPE, "changePasswordEvent");
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("changePassword error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void regBindEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                ShardSocialAccount shardSocialAccount = toShardSocialAccount(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSocialAccountList(), account.getSocialAccountUnionIdList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(SHARD_SOCIAL_ACCOUNT, shardSocialAccount);
//                jsonObject.put(EVENT_TYPE, REGISTER_BIND_EVENT);
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("registerBind error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private void regEvent(Account account, String flag) {
//        result = false;
//        String eventTypeId = doubleWriteEventTypeId;
//        int count = 0;
//        String strJson = null;
//        String errorMessage = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.sharding.domain.model.account.Account account1 = toShardAccount(account);
//                ShardSubscription shardSubscription = toShardSubscription(account.getTenantId(), account.getChannelId(), account.getMemberId(), account.getSubscriptionsList());
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put(FLAG, flag);
//                jsonObject.put(ACCOUNT, account1);
//                jsonObject.put(SHARD_SUBSCRIPTION, shardSubscription);
//                jsonObject.put(EVENT_TYPE, REGISTER_EVENT);
//                jsonObject.put(CREATE_TIME, LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("Register error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, strJson, errorMessage, valueOf(result), valueOf(count));
//    }
//
//    private com.pg.account.sharding.domain.model.account.Account toShardAccount(Account account) {
//        com.pg.account.sharding.domain.model.account.Account.AccountBuilder accountBuilder = com.pg.account.sharding.domain.model.account.Account.AccountBuilder
//                .anAccount()
//                .tenantId(account.getTenantId().toString())
//                .accountId(account.getMemberId())
//                .counter(toCounterInfo(account.getCounter()))
//                .address(toAddress(account.getAddressList()))
//                .device(toDeviceInfo(account.getDevices()))
//                .job(toJobItem(account.getJobList()))
//                .education(toEducationItem(account.getEducationList()))
//                .human(toHumanRelationItem(account.getInterpersonalRelationShips()))
//                .extraAttrs(toExtraAttributeItem(account.getAttributesList()));
//
//        Channel channel = new Channel();
//        if (Optional.ofNullable(account.getChannelId()).isPresent()) {
//            ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(account.getTenantId().toString(), account.getChannelId().toString());
//            Optional.ofNullable(shardChannel).ifPresent(channel::build);
//            accountBuilder.channelId(account.getChannelId().toString());
//        }
//        Security security = new Security();
//        if (Optional.ofNullable(account.getAccountInfo()).isPresent()) {
//            security.setSalt(account.getAccountInfo().getSalt());
//            security.setType(SecurityType.PASSWORD);
//            security.setEncryptedCode(account.getAccountInfo().getLogonPassword());
//            accountBuilder.accountStatus(AccountStatus.getAccountStatus(account.getAccountInfo().getStatus()))
//                    .registration(account.getAccountInfo().getRegistrationSource(), channel, account.getAccountInfo().getCustomer(), account.getAccountInfo().getRegStore(), account.getAccountInfo().getRegistrationDate().toLocalDateTime())
//                    .security(security);
//        }
//        if (Optional.ofNullable(account.getOpenId()).isPresent()) {
//            accountBuilder.openUid(account.getOpenId());
//        }
//
//        Contact contact = new Contact();
//        Optional.ofNullable(account.getProfile()).ifPresent(p -> {
//            contact.setEmail(Optional.ofNullable(p.getEmail()).orElse(null));
//            contact.setMobile(Optional.ofNullable(p.getCellphone()).orElse(null));
//            accountBuilder.birthday(p.getBirthday())
//                    .fullName(Optional.ofNullable(account.getAddressList()).filter(a -> !a.isEmpty()).map(addressCommands -> addressCommands.get(0).getFullName()).orElse(null))
//                    .contact(contact)
//                    .nickName(p.getNickname());
//        });
//
//        return accountBuilder.build();
//    }
//
//    public ShardSubscription toShardSubscription(Long tenantId, Long channelId, String memberId, List<Subscriptions> subscriptionList) {
//        ShardSubscription.ShardSubscriptionBuilder shardSubscriptionBuilder = ShardSubscription.ShardSubscriptionBuilder
//                .aShardSubscription()
//                .tenantId(tenantId.toString())
//                .accountId(memberId);
//        List<SubscriptionItem> subscriptionItems = new ArrayList<>();
//        if (Optional.ofNullable(subscriptionList)
//                .filter(subscriptionCommands -> !subscriptionCommands.isEmpty())
//                .isPresent()) {
//            toSubscriptionItem(channelId, subscriptionList, subscriptionItems);
//        } else {
//            SubscriptionItem subscriptionItem = new SubscriptionItem();
//            subscriptionItem.setChannelId(channelId.toString());
//            subscriptionItems.add(subscriptionItem);
//        }
//        return shardSubscriptionBuilder.subscriptionList(subscriptionItems).build();
//    }
//
//
//    /**
//     * 组装subcriptionItemList
//     *
//     * @param channelId               channelId
//     * @param subscriptionCommandList subscriptionCommandList
//     * @param subscriptionList        subscriptionList
//     */
//    private void toSubscriptionItem(Long channelId, List<Subscriptions> subscriptionCommandList, List<SubscriptionItem> subscriptionList) {
//        subscriptionCommandList.forEach(subscriptionCommand -> {
//            SubscriptionItem subscriptionItem = new SubscriptionItem();
//            subscriptionItem.build(subscriptionCommand.getOptId(), null, subscriptionCommand.getOptStatus(), null);
//            subscriptionItem.setChannelId(channelId.toString());
//            subscriptionList.add(subscriptionItem);
//        });
//    }
//
//    public ShardSocialAccount toShardSocialAccount(Long tenantId, Long channelId, String memberId, List<SocialAccount> socialAccountList,
//                                                   List<SocialAccountUnionId> socialAccountUnionIdList) {
//        ShardSocialAccount.ShardSocialAccountBuilder shardSocialAccountBuilder = ShardSocialAccount
//                .ShardSocialAccountBuilder
//                .aShardSocialAccount()
//                .tenantId(tenantId.toString())
//                .accountId(memberId);
//        shardSocialAccountBuilder.socialAccountList(toSocialAccountItem(socialAccountList, socialAccountUnionIdList, channelId, tenantId));
//
//
//        return shardSocialAccountBuilder.build();
//    }
//
//
//    private List<SocialAccountItem> toSocialAccountItem(List<SocialAccount> socialAccountList,
//                                                        List<SocialAccountUnionId> socialAccountUnionIdList, Long channelId, Long tenantId) {
//        String unionId = null;
//        boolean flag = false;
//        if (Optional.ofNullable(socialAccountUnionIdList).filter(socialAccountUnionIds -> !socialAccountUnionIds.isEmpty()).isPresent()) {
//            unionId = socialAccountUnionIdList.get(0).getUnionId();
//            flag = true;
//        }
//        List<SocialAccountItem> socialAccountItemList = new ArrayList<>();
//        if (Optional.ofNullable(socialAccountList).filter(s -> !s.isEmpty()).isPresent()) {
//            String finalUnionId = unionId;
//            socialAccountList.forEach(socialAccount -> {
//                if (null == socialAccount.getChannelId()) {
//                    socialAccount.setChannelId(channelId);
//                }
//                if (null == socialAccount.getTenantId()) {
//                    socialAccount.setTenantId(tenantId);
//                }
//                ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(socialAccount.getTenantId().toString(), socialAccount.getChannelId().toString());
//                Channel channel = new Channel();
//                Optional.ofNullable(shardChannel).ifPresent(channel::build);
//                SocialAccountItem socialAccountItem = new SocialAccountItem();
//                socialAccountItem.build(channel, null, socialAccount.getBindId(), finalUnionId);
//                socialAccountItemList.add(socialAccountItem);
//            });
//        } else if (flag) {
//            ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(tenantId.toString(), channelId.toString());
//            Channel channel = new Channel();
//            Optional.ofNullable(shardChannel).ifPresent(channel::build);
//            SocialAccountItem socialAccountItem = new SocialAccountItem();
//            socialAccountItem.build(channel, null, null, unionId);
//            socialAccountItemList.add(socialAccountItem);
//        }
//        return socialAccountItemList;
//    }
//
//    private void writeLog(Account account, String eventTypeId, String eventMessage, String errorMessage, String status, String retryCount) {
//        DataStream dataStream = new DataStream(account.getTenantId(), account.getMemberId(), PRODUCER_EVENT_HUB, eventTypeId, AM_REGISTER_IN_SHARDING_EVENT_HUB, null, null, eventMessage, errorMessage, status, retryCount);
//        dataStream.setId(uidGenerator.getUid());
//        dataStreamRepository.save(dataStream);
//    }
//
//}
