package com.pg.account.infrastructure.common.utils;

import org.apache.commons.codec.digest.DigestUtils;

import java.nio.charset.StandardCharsets;

/**
 * 密码工具类。
 *
 * @author JackSun
 */
public class PasswordUtils {
    public PasswordUtils() {
        //空构造函数
    }

    /**
     * MD5加密方法
     *
     * @param rawPass rawPass
     * @return String
     */
    public static String encrypt(String rawPass) {
        String eccryptedPass;
        byte[] bArray = DigestUtils.md5(rawPass.getBytes(StandardCharsets.UTF_16LE));
        StringBuilder sb = new StringBuilder(bArray.length);
        String result;
        for (byte b : bArray) {
            result = Integer.toHexString(0xFF & b);
            if (result.length() == 1) {
                result = "0".concat(result);
            }

            sb.append(result.toUpperCase());
        }
        eccryptedPass = sb.toString();

        return eccryptedPass;
    }

    /**
     * 原来存在BUG的MD5加密方法
     *
     * @param rawPass rawPass
     * @return String
     */
    public static String encryptOld(String rawPass) {
        String eccryptedPass;
        byte[] bArray = DigestUtils.md5(rawPass.getBytes(StandardCharsets.UTF_16LE));
        StringBuilder sb = new StringBuilder(bArray.length);
        String result;
        for (byte b : bArray) {
            result = Integer.toHexString(0xFF & b);
            sb.append(result.toUpperCase());
        }
        eccryptedPass = sb.toString();

        return eccryptedPass;
    }
}
