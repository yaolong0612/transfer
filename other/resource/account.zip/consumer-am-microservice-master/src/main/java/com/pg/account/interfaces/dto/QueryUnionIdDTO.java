package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Jack Sun
 * @date 2019-4-30 15:18
 */
@ApiModel(value = "QueryUnionIdDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryUnionIdDTO implements Serializable {
    private static final long serialVersionUID = -3313622425513209425L;
    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
}
