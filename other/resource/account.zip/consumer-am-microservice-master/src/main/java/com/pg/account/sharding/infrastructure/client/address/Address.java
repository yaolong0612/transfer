package com.pg.account.sharding.infrastructure.client.address;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.interfaces.command.AddressCommand;
import com.pg.account.interfaces.dto.AddressDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Address implements Serializable {

    public static final String IS_PRIMARY = "1";
    public static final String HOME_ADDRESS = "1";
    private static final long serialVersionUID = -3833128482564205197L;
    @ApiModelProperty(value = "地址UUID识别编码", example = "12345556")
    private String addressCode;
    @ApiModelProperty(value = "是否是主地址（主：1,备：0），主地址只能存在一个，默认是主地址", example = "1", required = true)
    @Pattern(regexp = IS_PRIMARY_PATTERN, message = "未匹配到有效地址类型")
    private String isPrimary;
    @ApiModelProperty(value = "地址类型:1、HOME 不填默认是1（HOME）", example = "1", required = true)
    @Pattern(regexp = ADDRESS_TYPE_PATTERN, message = "未匹配到有效地址种类")
    private String addressType;
    @ApiModelProperty(value = "姓名", example = "孙悟空")
    @Pattern(regexp = FULL_NAME_VALID_PATTERN, message = "姓名只允许输入中文和英文,中间允许输入空格隔开")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "手机", example = "188888888")
    @Pattern(regexp = MOBILE_PATTERN, message = "手机号格式错误")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "电话", example = "0510-83195186")
    @Pattern(regexp = HOME_PHONE_PATTERN, message = "家庭电话格式错误")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "省", example = "江苏省")
    @Pattern(regexp = CH_EN_PATTERN, message = "省只允许输入中英文")
    private String province;
    @ApiModelProperty(value = "市", example = "无锡市")
    @Pattern(regexp = CH_EN_PATTERN, message = "市只允许输入中英文")
    private String city;
    @ApiModelProperty(value = "区", example = "滨湖区")
    @Pattern(regexp = CH_EN_PATTERN, message = "区只允许输入中英文")
    private String district;
    @ApiModelProperty(value = "地址详情", example = "蠡湖大道1008号")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "地址只允许输入中英文，数字，空格，小括号，中划线，下划线和#号")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "邮编", example = "215600")
    @Pattern(regexp = POSTAL_CODE_PATTERN, message = "邮编格式错误")
    private String postcode;

    public static Address toAddressV2(com.pg.account.interfaces.command.v2.AddressCommand address) {
        if (Optional.ofNullable(address).isPresent()) {
            return new Address(address.getAddressCode(), IS_PRIMARY, HOME_ADDRESS,
                    address.getFullName(), address.getMobile(), address.getPhone(), address.getProvince(),
                    address.getCity(), address.getDistrict(), address.getAddress(), address.getPostcode());
        }
        return null;
    }

    /**
     * 封装设备信息
     *
     * @param addresses addresses
     * @return void
     * @author xusheng
     * @date 2021/6/7 11:26
     */
    public static Address toAddress(List<AddressCommand> addresses) {
        if (Optional.ofNullable(addresses).filter(addressCommands -> !addressCommands.isEmpty()).isPresent()) {
            AddressCommand addressCommand = addresses.get(0);
            return new Address(addressCommand.getAddressCode(), addressCommand.getIsPrimary(), addressCommand.getAddressType(),
                    addressCommand.getFullName(), addressCommand.getCellphone(), addressCommand.getPhone(), addressCommand.getProvince(),
                    addressCommand.getCity(), addressCommand.getDistrict(), addressCommand.getAddress(), addressCommand.getPostcode());
        }
        return null;
    }

    public AddressDTO build() {
        AddressDTO addressDTO = new AddressDTO();
        addressDTO.setAddressCode(this.getAddressCode());
        addressDTO.setIsPrimary(this.getIsPrimary());
        addressDTO.setAddressType(this.getAddressType());
        addressDTO.setFullName(this.getFullName());
        addressDTO.setCellphone(this.getCellphone());
        addressDTO.setPhone(this.getPhone());
        addressDTO.setProvince(this.getProvince());
        addressDTO.setCity(this.getCity());
        addressDTO.setDistrict(this.getDistrict());
        addressDTO.setAddress(this.getAddress());
        addressDTO.setPostcode(this.getPostcode());
        return addressDTO;
    }
}
