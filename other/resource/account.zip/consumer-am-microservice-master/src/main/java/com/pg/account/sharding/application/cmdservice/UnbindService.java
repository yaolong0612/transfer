package com.pg.account.sharding.application.cmdservice;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.sharding.domain.model.account.Account;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

/**
 * @author lfx
 * @date 2022/1/8 16:21
 */
@Validated
@Component
public interface UnbindService {
    /**
     * 解绑
     *
     * @param tenant      tenant
     * @param channel     channel
     * @param type        type
     * @param unBindRoute unBindRoute
     * @param query       query
     * @return String   解绑的accountId
     */
    String unBind(String tenant, String channel, String type, String unBindRoute, String query);

    /**
     * 解绑所有
     *
     * @param account account
     * @return JSObject
     */
    JSONObject unBindAll(Account account);

    /**
     * 根据路由进行解绑
     *
     * @param tenant    tenant
     * @param channel   channel
     * @param accountId accountId
     * @param route     route
     */
    void unBind(String tenant, String channel, String accountId, String route);
}
