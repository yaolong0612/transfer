package com.pg.account.interfaces.command;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/4/5
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscribeCommand implements Serializable {
    private static final long serialVersionUID = -1597574291188676677L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12", required = true)
    @NotNull(message = "channel is not exist")
    private Long channelId;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk", required = true)
    @NotBlank(message = "missing BindId")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;

}
