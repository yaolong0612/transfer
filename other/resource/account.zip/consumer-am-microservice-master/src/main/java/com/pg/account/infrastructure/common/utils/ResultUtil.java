package com.pg.account.infrastructure.common.utils;


import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.vo.Result;

/**
 * 响应数据工具类
 *
 * @author Jack Sun
 * @date 2019-11-25 16:08
 */
public class ResultUtil {

    private ResultUtil() {
    }

    /**
     * 请求失败，返回状态码和提示信息
     *
     * @param code 状态码
     * @param msg  提示信息
     * @return 返回参数
     */
    public static Result error(Integer code, String msg) {
        Result result = new Result();
        result.setCode(code);
        result.setMsg(msg);
        return result;
    }

    /**
     * 请求失败，返回默认错误状态码和捕捉的错误信息
     *
     * @param msg 提示信息
     * @return 返回参数
     */
    public static Result error(String msg) {
        Integer code = ResultEnum.ERROR.getCode();
        return error(code, msg);
    }

    /**
     * 请求失败，返回默认错误状态码和错误信息
     *
     * @return 返回参数
     */
    public static Result error() {
        return error(ResultEnum.ERROR.getCode(), ResultEnum.ERROR.getMessage());
    }
}
