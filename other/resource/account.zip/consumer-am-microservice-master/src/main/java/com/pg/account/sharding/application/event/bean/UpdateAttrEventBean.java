package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAttrEventBean implements Serializable {

    private static final long serialVersionUID = 4787156916279285162L;
    @JSONField(name = "member_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @JSONField(name = "marketing_program_id")
    private int marketingProgramId;
    @JSONField(name = "update_flag")
    private char updateFlag;
    @JSONField(name = "modify_datetime")
    private Timestamp modifyDatetime;
    private List<AttributeBean> attributes;
    private List<DependentBean> dependents;

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
