package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 */
@ApiModel(value = "PointDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PointDTO implements Serializable {
    private static final long serialVersionUID = -1512511889657005964L;

    @ApiModelProperty(value = "用户属性ID")
    private String attrId;
    @ApiModelProperty(value = "操作积分")
    private String point;
    @ApiModelProperty(value = "总计积分")
    private String totalPoint;

}
