package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Optional;

/**
 * email
 * 映射类
 * 用于将email映射成accountId
 *
 * @author LC
 */
@Table
@Data
@DynamicUpdate
@DynamicInsert
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class EmailMapping extends BaseEntity implements Serializable {
    private static final long serialVersionUID = -2230026352446824522L;
    private Long id;
    @Column(name = "account_id")
    private String accountId;
    @EmbeddedId
    private EmailMapId emailMapId;

    public String getEmail() {
        return Optional.ofNullable(emailMapId).map(EmailMapId::getEmail).orElse(null);
    }

    public EmailMapping(Long id) {
        this.id = id;
    }

    public void build(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.emailMapId = new EmailMapId(account.getTenantId(), account.getEmail());
        this.accountId = account.getAccountId();
        super.addCreateTime();
    }

    public void builder(Account account) {
        Validate.notNull(account, "account is null");
        Validate.notNull(account.getIdentityId(), "userId is null");
        this.emailMapId = new EmailMapId(account.tenantId(), account.getEmail());
        this.accountId = account.accountId();
        super.addCreateTime();
    }
}
