package com.pg.account.sharding.domain.model.account;

import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.Data;

import javax.persistence.Embeddable;
import java.util.Optional;

/**
 * 地址信息类
 *
 * @author dell
 */
@Data
@Embeddable
public class AddressInfo implements ValueObject<AddressInfo> {
    private static final long serialVersionUID = -6252300838903020041L;
    private String province;
    private String city;
    private String district;
    private String addressInfo;
    private String postCode;

    public AddressInfo() {

    }

    public AddressInfo(String province, String city, String district, String addressInfo, String postCode) {
        this.province = province;
        this.city = city;
        this.district = district;
        this.addressInfo = addressInfo;
        this.postCode = postCode;
    }

    @Override
    public boolean sameValueAs(AddressInfo other) {
        return this.equals(other);
    }

    public void builder(AddressInfo db) {
        Optional.ofNullable(db).ifPresent(a -> {
            this.province = Optional.ofNullable(this.province).orElse(db.getProvince());
            this.city = Optional.ofNullable(this.city).orElse(db.getCity());
            this.district = Optional.ofNullable(this.district).orElse(db.getDistrict());
            this.addressInfo = Optional.ofNullable(this.addressInfo).orElse(db.getAddressInfo());
            this.postCode = Optional.ofNullable(this.postCode).orElse(db.getPostCode());
        });
    }
}
