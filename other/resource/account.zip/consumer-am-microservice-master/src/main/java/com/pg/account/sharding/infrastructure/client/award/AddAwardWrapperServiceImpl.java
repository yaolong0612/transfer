package com.pg.account.sharding.infrastructure.client.award;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.ExternalSystemException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.JsonUtil;
import com.pg.account.infrastructure.component.client.loyalty.AddLoyaltyInteractionRequest;
import com.pg.account.infrastructure.component.client.loyalty.LoyaltyServiceClient;
import com.pg.account.sharding.application.event.listener.IntegralNotifierListener;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.account.Registration;
import com.pg.account.sharding.domain.service.AddAwardWrapperService;
import com.pg.account.sharding.domain.service.LoyaltyService;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.log.ServiceCallDao;
import com.pg.account.sharding.infrastructure.jpa.log.ShardServiceCall;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;

/**
 * @author Jack
 * @date 2021-04-23 16:28
 */
@Slf4j
@Component
public class AddAwardWrapperServiceImpl implements AddAwardWrapperService {

    public static final String URL = "url";
    public static final String METHOD = "method";
    public static final String API_SECRET = "apiSecret";
    public static final String API_KEY = "apiKey";
    public static final String LOYALTY_TYPE = "loyaltyType";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    /**
     * Result
     */
    public static final String RESULT = "result";
    /**
     * error
     */
    public static final String ERROR = "error";
    /**
     * object
     */
    public static final String OBJECT = "object";
    /**
     * totalPoint
     */
    public static final String TOTAL_POINT = "totalPoint";
    /**
     * point
     */
    public static final String POINT = "point";
    public static final String COMPLETE_CHANNEL = "COMPLETE_CHANNEL";

    private final AwardServiceClient awardServiceClient;
    private final ServiceCallDao serviceCallDao;
    private final LoyaltyService loyaltyService;
    private LoyaltyServiceClient loyaltyServiceClient;

    @Autowired
    public AddAwardWrapperServiceImpl(AwardServiceClient awardServiceClient, ServiceCallDao serviceCallDao, LoyaltyService loyaltyService,
                                      LoyaltyServiceClient loyaltyServiceClient) {
        this.awardServiceClient = awardServiceClient;
        this.serviceCallDao = serviceCallDao;
        this.loyaltyService = loyaltyService;
        this.loyaltyServiceClient = loyaltyServiceClient;
    }

    /**
     * 首次添加商品加积分
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     */
    @Override
    public void addFirstSaveGoodsPoints(String tenantId, String channelId, String accountId) {

        Validate.notNull(tenantId, "首次保存购买商品加积分时，租户信息为空");
        Validate.notNull(channelId, "首次保存购买商品加积分时，渠道信息为空");
        Validate.notNull(accountId, "首次保存购买商品加积分时，账号信息为空");
        //查询品牌
        String brand = CacheLocalConfigUtils.getTenant(Long.parseLong(tenantId));
        //查询渠道
        String channel = CacheLocalConfigUtils.getChannel(tenantId, channelId);
        AddLoyaltyInteractionRequest addInteractionRequest = new AddLoyaltyInteractionRequest(accountId, null, brand, channel,
                REGION, COMPLETE_CHANNEL, null, null, null, false, null);
        ResponseEntity<JSONObject> responseEntity;
        try {
            responseEntity = loyaltyServiceClient.addInteraction(addInteractionRequest);
        } catch (Exception e) {
            log.error("AwardWrapperServiceImpl-addFirstSaveGoodsPoints. Request tenantId:{},channelId:{},memberId:{}. Exception:", tenantId, channelId, DesensitizedUtils.identification(accountId), e);
            throw new ExternalSystemException(ResultEnum.LOYALTY_MICRO_SERVICE_ERROR.getCode(), ResultEnum.LOYALTY_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.LOYALTY_MICRO_SERVICE_ERROR.getMessage());
        }
    }

    /**
     * 首次修改加积分
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     */
    @Override
    public void addFirstModifyPoints(String tenantId, String channelId, String accountId) {
        Validate.notNull(tenantId, "addFirstModifyPoints tenantId is null");
        Validate.notNull(channelId, "addFirstModifyPoints channelId is null");
        Validate.notNull(accountId, "addFirstModifyPoints accountId is null");
        Account account = new Account();
        account.setIdentityId(new IdentityId(tenantId, accountId));
        Channel channel = new Channel();
        channel.setChannelId(channelId);
        Registration registration = new Registration();
        registration.setChannel(channel);
        account.setRegistration(registration);
        loyaltyService.enrollAccount(account, null, IntegralNotifierListener.REGISTER);

    }

    /**
     * 加积分
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     * @param attrValue attrValue
     * @param param     param
     * @return AddPointResponse
     */
    private AddPointResponse addIntegral(String tenantId, String channelId, String accountId, String attrId, String attrValue, String param) {
        Validate.notNull(param, "加积分的请求配置为空");
        String url = null;
        String apiSecret = null;
        JSONObject jsonObject = JSON.parseObject(param);
        JSONObject awardJson = new JSONObject();
        if (jsonObject.containsKey(URL)) {
            url = jsonObject.getString(URL);
            Validate.notNull(url, "config url is null");
        }
        if (jsonObject.containsKey(API_SECRET)) {
            apiSecret = jsonObject.getString(API_SECRET);
            Validate.notNull(apiSecret, "config apiSecret is null");
        }
        if (jsonObject.containsKey(API_KEY)) {
            Validate.notNull(jsonObject.getString(API_KEY), "config apiKey is null");
            awardJson.put(API_KEY, jsonObject.getString(API_KEY));
        }
        if (jsonObject.containsKey(LOYALTY_TYPE)) {
            Validate.notNull(jsonObject.getString(LOYALTY_TYPE), "config loyalty type is null");
            awardJson.put(LOYALTY_TYPE, jsonObject.getString(LOYALTY_TYPE));
        }
        String timeStamp = String.valueOf(System.currentTimeMillis() / 1000);
        awardJson.put("timestamp", timeStamp);
        JSONObject requestJson = new JSONObject();
        requestJson.put("userId", accountId);
        Optional.ofNullable(attrValue).ifPresent(value -> requestJson.put("attrValue", value));
        awardJson.put("parameters", requestJson);
        String paramStr = JsonUtil.jsonObjectToString(awardJson);
        Validate.notNull(apiSecret, "award api secret is null");
        paramStr = paramStr.concat(apiSecret);
        String encryptStr = DigestUtils.md5Hex(paramStr);
        awardJson.put("sig", encryptStr);
        AddPointResponse addPointResponse;
        String resultCode = FALSE;
        ResponseEntity<JSONObject> responseEntity;
        try {
            responseEntity = this.awardServiceClient.addAward(url, awardJson.toJSONString());
        } catch (Exception e) {
            log.warn("AddAwardWrapperServiceImpl-addIntegral.Request tenantId:{},channelId:{},accountId:{},attrId:{},attrValue:{},param:{}. Exception:", tenantId, channelId, DesensitizedUtils.identification(accountId), attrId, attrValue, param, e);
            throw new ExternalSystemException(ResultEnum.AWARD_MICRO_SERVICE_ERROR.getCode(), ResultEnum.AWARD_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.AWARD_MICRO_SERVICE_ERROR.getMessage());
        }
        Validate.notNull(responseEntity.getBody(), "award response body is null");
        JSONObject responseJson = responseEntity.getBody();
        exceptionHandler(responseEntity.getStatusCode(), responseJson);
        if (responseJson.containsKey(RESULT)) {
            resultCode = responseJson.getString(RESULT);
        }
        //当错误信息等于30和35时，设置resultCode为成功状态。
        //30	重复点击
        //35	达到最大活动次数
        String errorCode = null;
        if (responseJson.containsKey(ERROR)) {
            errorCode = responseJson.getString(ERROR);
            if (REPEAT_INTEGRAL.equals(errorCode) || MAX_INTEGRAL.equals(errorCode)) {
                resultCode = TRUE;
            }
        }
        String totalPoint = null;
        String point = null;
        if (responseJson.containsKey(OBJECT)) {
            Validate.notNull(responseJson.get(OBJECT), "积分信息未返回");
            if (responseJson.getJSONObject(OBJECT).containsKey(TOTAL_POINT)) {
                totalPoint = responseJson.getJSONObject(OBJECT).getString(TOTAL_POINT);
            }
            if (responseJson.getJSONObject(OBJECT).containsKey(POINT)) {
                point = responseJson.getJSONObject(OBJECT).getString(POINT);
            }
        }
        addPointResponse = new AddPointResponse(attrId, point, totalPoint);
        ShardServiceCall serviceCall = new ShardServiceCall();
        serviceCall.setIdentityId(new IdentityId(accountId, tenantId));
        serviceCall.setUrl(param);
        serviceCall.setContent(awardJson.toJSONString());
        serviceCall.setType(ADD_INTEGRAL);
        serviceCall.setStatus(resultCode);
        serviceCall.setRetryCount(null);
        serviceCall.setResultCode(errorCode);
        serviceCall.setResultMessage(responseJson.toJSONString());
//        serviceCall.setId(uidGenerator.getUid());
        serviceCall.setCreatedTime(LocalDateTime.now());
        serviceCall.setUpdatedTime(LocalDateTime.now());

        serviceCallDao.save(serviceCall);
        return addPointResponse;
    }


    /**
     * 异常处理
     *
     * @param httpStatus httpStatus
     * @param jsonObject jsonObject
     */
    private void exceptionHandler(HttpStatus httpStatus, JSONObject jsonObject) {
        Integer code = Integer.parseInt(jsonObject.getString(RESULT));
        String message = jsonObject.getString(ERROR);
        if (httpStatus.is5xxServerError()) {
            throw new ExternalSystemException(code, code, message);
        } else if (httpStatus.is4xxClientError()) {
            throw new BusinessException(code, code, message);
        }
    }
}
