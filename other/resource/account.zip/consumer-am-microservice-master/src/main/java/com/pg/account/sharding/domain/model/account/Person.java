package com.pg.account.sharding.domain.model.account;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * 个人基本信息类
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Person implements ValueObject<Person> {
    private static final long serialVersionUID = -8372642070542324013L;
    private Contact contact;
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    private String nickName;
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;

    @Override
    public boolean sameValueAs(Person other) {
        return this.equals(other);
    }

    public void builder(Person db) {
        Optional.ofNullable(db).ifPresent(p -> {
            Optional.ofNullable(this.contact).ifPresent(c -> c.buildFromDb(db.getContact()));
            this.fullName = Optional.ofNullable(this.fullName).orElse(db.fullName);
            this.fullName = Optional.ofNullable(this.fullName).orElse(db.fullName);
            this.nickName = Optional.ofNullable(this.nickName).orElse(db.nickName);
            this.birthday = Optional.ofNullable(this.birthday).orElse(db.birthday);
            this.gender = Optional.ofNullable(this.gender).orElse(db.gender);
        });
    }
}
