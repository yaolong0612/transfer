package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "AccountRegisterDTO_V1", description = "V1 AccountRegisterDTO接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisterDTO implements Serializable {
    private static final long serialVersionUID = -1903724912362238954L;

    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "是否是新注册的会员", example = "true")
    private boolean isNewRegister;

    public AccountRegisterDTO(String memberId) {
        this.memberId = memberId;
    }

    public boolean getIsNewRegister() {
        return isNewRegister;
    }

    public void setIsNewRegister(boolean isNewRegister) {
        this.isNewRegister = isNewRegister;
    }

}
