package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * 注册渠道
 *
 * @author xusheng
 * @date 2021/6/11 11:16
 */
public interface TermsDao extends JpaRepository<ShardTerms, Long> {

}
