package com.pg.account.sharding.infrastructure.datastream.servicebus.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author YJ
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SkiiAttributesBean implements Serializable {

    private static final long serialVersionUID = -4191440200091658896L;
    private Long id;
    private String usersId;
    private Long tenantId;
    private String registrationCounterCode;
    private String registrationCounterName;
    private String pickupCounterCode;
    private String pickupCounterName;
    private String firstPurchaseCounterCode;
    private String firstPurchaseCounterName;
    private Timestamp createTime;
    private Timestamp modifyTime;

}
