package com.pg.account.infrastructure.common.enums;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import lombok.Getter;

import java.util.Arrays;

/**
 * 查询类型枚举
 *
 * @author Jack Sun
 * @date 2019-11-27 16:29
 */
@Getter
public enum QueryBindTypeEnum {

    /**
     * 查询类型枚举
     */
    BIND_ID(1, "bindId"),
    CHANNEL_AND_OPEN_ID(2, "channelAndOpenId"),
    OPEN_ID(3, "openId"),
    MEMBER_ID(4, "memberId"),
    CHANNEL_AND_MEMBER_ID(5, "channelAndMemberId");

    private final Integer key;
    private final String value;

    /**
     * 构造器
     *
     * @param key   num
     * @param value name
     */
    QueryBindTypeEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public static QueryBindTypeEnum getByKeyOrValue(String value) {
        return Arrays.stream(QueryBindTypeEnum.values())
                .filter(msg -> msg.getValue().equalsIgnoreCase(value) || String.valueOf(msg.getKey()).equals(value))
                .findAny()
                .orElseThrow(() -> new BusinessException(ResultEnum.QUERY_TYPE_NOT_EXIST.getCode(), ResultEnum.QUERY_TYPE_NOT_EXIST.getV2Code(), ResultEnum.QUERY_TYPE_NOT_EXIST.getMessage()));
    }
}
