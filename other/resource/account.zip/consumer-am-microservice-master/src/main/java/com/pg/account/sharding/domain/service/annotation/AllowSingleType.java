package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMappingDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMappingDao;

import com.pg.account.sharding.interfaces.command.UnBindCommand;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Optional;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author lfx
 * @date 2022/1/8 14:31
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AllowSingleType.UnbindValidator.class)
public @interface AllowSingleType {
    String message() default "参数只能是一个";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class UnbindValidator implements ConstraintValidator<AllowSingleType, @Valid UnBindCommand> {

        @Autowired
        protected BindIdMappingDao bindIdMappingDao;
        @Autowired
        protected UnionIdMappingDao unionIdMappingDao;

        @Override
        public boolean isValid(UnBindCommand unBindCommand, ConstraintValidatorContext constraintValidatorContext) {
            int i = 0;
            if (Optional.ofNullable(unBindCommand.getAccountId()).isPresent()) {
                i++;
            }
            if (Optional.ofNullable(unBindCommand.getBindId()).isPresent() && Optional.ofNullable(unBindCommand.getChannel()).isPresent()) {
                if (i >= 1) {
                    return false;
                }
                Optional<BindIdMapping> bindIdMapping = Optional.ofNullable(bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(unBindCommand.getTenant(), unBindCommand.getChannel(), unBindCommand.getBindId()));
                unBindCommand.setAccountId(bindIdMapping.map(BindIdMapping::getAccountId).orElse(null));
                i++;
            }
            if (Optional.ofNullable(unBindCommand.getUnionId()).isPresent() && Optional.ofNullable(unBindCommand.getChannel()).isPresent()) {
                if (i >= 1) {
                    return false;
                }
                String channelUnionIdType = LocalCacheConfigUtils.getChannelUnionIdType(unBindCommand.getTenant(), unBindCommand.getChannel());
                Optional<UnionIdMapping> unionIdMapping = Optional.ofNullable(unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(unBindCommand.getTenant(), unBindCommand.getUnionId(), channelUnionIdType));
                unBindCommand.setAccountId(unionIdMapping.map(UnionIdMapping::getAccountId).orElse(null));
                i++;
            }
            return i == 1;
        }
    }
}
