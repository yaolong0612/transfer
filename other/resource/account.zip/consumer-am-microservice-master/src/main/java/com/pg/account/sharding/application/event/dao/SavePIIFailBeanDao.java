package com.pg.account.sharding.application.event.dao;

import com.pg.account.sharding.application.event.bean.SavePIIFailBean;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Administrator
 */
public interface SavePIIFailBeanDao extends JpaRepository<SavePIIFailBean, Long> {


}
