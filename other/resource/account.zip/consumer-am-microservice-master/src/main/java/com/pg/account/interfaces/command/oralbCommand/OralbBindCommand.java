package com.pg.account.interfaces.command.oralbCommand;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author YJ
 * @date 2021/9/1
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OralbBindCommand implements Serializable {
    private static final long serialVersionUID = 1005932086536932914L;

    @ApiModelProperty(value = "第三方的社交绑定渠道", example = "22")
    private Long channelId;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交绑定时间", example = "2021-08-09 11:48:03.234000")
    private Timestamp bindTime;
    @ApiModelProperty(value = "第三方的社交绑定状态", example = "I/O")
    private String attentionStatus;
}
