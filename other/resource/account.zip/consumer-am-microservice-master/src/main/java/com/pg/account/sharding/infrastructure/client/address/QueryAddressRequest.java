package com.pg.account.sharding.infrastructure.client.address;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author Jack
 * @date 2021-04-20 16:15
 */
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class QueryAddressRequest implements Serializable {

    private static final long serialVersionUID = -3662040691422592252L;
    @ApiModelProperty(value = "租户编号", name = "tenantId", example = "99999")
    @NotNull(message = "缺少租户ID")
    private Long tenantId;
    @ApiModelProperty(value = "会员编号", name = "memberId", example = "12345")
    @NotBlank(message = "缺少会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "地址码", name = "addressCode", example = "321321-sfhj-21321")
    private String addressCode;
    @ApiModelProperty(value = "地址类型", name = "addressType", example = "1")
    private String addressType;
}
