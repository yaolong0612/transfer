package com.pg.account.sharding.infrastructure.jpa.mapping.retention;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author lfx
 * @date 2021/5/31 14:48
 */
public interface UnionIdMappingRetentionDao extends JpaRepository<UnionIdMappingRetention, Long> {

    /**
     * 删除mapping 根据tenantId和accountId
     *
     * @param accountId accountId
     * @param tenantId  tenantId
     */
    void deleteByAccountIdAndTenantId(String accountId, String tenantId);

    /**
     * 删除mapping 根据tenantId和accountId和channel
     *
     * @param accountId accountId
     * @param tenantId  tenantId
     * @param channel   channel
     */
    void deleteByAccountIdAndTenantIdAndChannel(String accountId, String tenantId, String channel);

    /**
     * @param accountId accountId
     * @param tenantId tenantId
     * @return
     */
    List<UnionIdMappingRetention> findByAccountIdAndTenantId(String accountId, String tenantId);

}
