package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class UpdateProfileEvent extends ApplicationEvent {
    private static final long serialVersionUID = -3339598854913649842L;
    private Account account;
    private ShardSubscription shardSubscription;

    public UpdateProfileEvent(Object source) {
        super(source);
    }

    public UpdateProfileEvent(Object source, Account account, ShardSubscription shardSubscription) {
        super(source);
        this.account = account;
        this.shardSubscription = shardSubscription;
    }

}
