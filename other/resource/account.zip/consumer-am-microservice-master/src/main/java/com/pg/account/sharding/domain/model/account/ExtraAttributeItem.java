package com.pg.account.sharding.domain.model.account;

import com.alibaba.fastjson.JSON;
import com.pg.account.interfaces.command.AttrCommand;
import com.pg.account.interfaces.command.v2.AttributeCommand;
import com.pg.account.interfaces.dto.AttrDTO;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * 属性类
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExtraAttributeItem implements ValueObject<ExtraAttributeItem> {
    private static final long serialVersionUID = -6115077368067195258L;
    private static final String ATTR_ID = "113000001";

    private String attrId;
    private String attrName;
    private String attrValue;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public ExtraAttributeItem(String attrId, String attrValue) {
        this.attrId = attrId;
        this.attrValue = attrValue;
    }

    /**
     * 封装属性信息
     *
     * @param attrCommandList attrCommandList
     * @return java.util.List<com.pg.account.sharding.domain.model.account.ExtraAttributeItem>
     * @author xusheng
     * @date 2021/6/7 13:16
     */
    public static List<ExtraAttributeItem> toExtraAttributeItem(List<AttrCommand> attrCommandList) {
        List<ExtraAttributeItem> extraAttributes = null;
        if (Optional.ofNullable(attrCommandList).filter(attrCommands -> !attrCommands.isEmpty()).isPresent()) {
            extraAttributes = new ArrayList<>();
            for (AttrCommand attrCommand : attrCommandList) {
                ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem(attrCommand.getAttrId(), null,
                        attrCommand.getAttrVal(), LocalDateTime.now(), LocalDateTime.now());
                extraAttributes.add(extraAttributeItem);
            }
        }
        return extraAttributes;
    }

    /**
     * 封装属性信息
     *
     * @param attributes attributes
     * @return ExtraAttributeItems
     */
    public static List<ExtraAttributeItem> toAttr(Set<AttributeCommand> attributes) {
        ArrayList<ExtraAttributeItem> extraAttributeList = new ArrayList<>();
        Optional.ofNullable(attributes).ifPresent(attr -> attr.forEach(a -> {
            ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem();
            extraAttributeItem.setAttrId(a.getAttrId());
            extraAttributeItem.setAttrValue(a.getAttrVal());
            extraAttributeList.add(extraAttributeItem);
        }));
        return extraAttributeList;
    }

    @Override
    public boolean sameValueAs(ExtraAttributeItem other) {
        return this.equals(other);
    }

    public AttrDTO build() {
        AttrDTO attrDTO = new AttrDTO();
        attrDTO.setAttrId(this.attrId);
        attrDTO.setAttrVal(this.attrValue);
        if (ATTR_ID.equals(this.attrId) && StringUtils.isNotBlank(this.attrValue)) {
            List<BabyInfoBean> babyInfoBeanList = JSON.parseArray(this.attrValue, BabyInfoBean.class);
            babyInfoBeanList.forEach(b -> b.setBirthday(b.formatDate()));
        }
        return attrDTO;
    }

    public void builder(ExtraAttributeItem db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.attrId = Optional.ofNullable(this.attrId).filter(tmp -> !tmp.isEmpty()).orElse(db.getAttrId());
            this.attrName = Optional.ofNullable(this.attrName).filter(tmp -> !tmp.isEmpty()).orElse(db.getAttrName());
            this.attrValue = Optional.ofNullable(this.attrValue).filter(tmp -> !tmp.isEmpty()).orElse(db.getAttrValue());
            this.createTime = db.getCreateTime();
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(db.getUpdateTime());
        }
    }
}
