package com.pg.account.sharding.application;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.enums.AccountLogonTypeEnum;
import com.pg.account.infrastructure.common.enums.UnBindRouteEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.interfaces.command.LogonCommand;
import com.pg.account.interfaces.command.ModifyPasswordCommand;
import com.pg.account.interfaces.command.UpdateBindIdCommand;
import com.pg.account.interfaces.dto.*;
import com.pg.account.interfaces.dto.v2.SubscriptionQueryDTO;
import com.pg.account.sharding.application.cmdservice.UnbindService;
import com.pg.account.sharding.application.event.*;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.AccountStatus;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.domain.service.*;
import com.pg.account.sharding.domain.service.annotation.*;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.client.address.Address;
import com.pg.account.sharding.infrastructure.common.constants.AccountConstants;
import com.pg.account.sharding.infrastructure.common.constants.V3Constants;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.counter.CounterDao;
import com.pg.account.sharding.infrastructure.jpa.counter.ShardCounter;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.DeleteMappingService;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.enums.AccountProfileEnum.*;
import static com.pg.account.infrastructure.common.enums.QueryBindTypeEnum.*;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.PARAMETER_PARSING_ERROR;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.MOBILE;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.UNION_ID;


/**
 * shardingAppService
 *
 * @author xusheng
 * @date 2021/6/2 15:06
 */
@Slf4j
@Service
@Validated
public class AccountAppService {
    public static final String COMMA = ",";
    public static final String DELETE_FLAG = "D";
    public static final String ACCOUNT = "account";
    public static final String IS_BIND = "isBind";
    public static final String ACCOUNT_ID = "accountId";
    private final BindSocialAccountService bindSocialAccountService;
    private final FetchAccountService fetchAccountService;
    private final RegisterAccountService registerAccountService;
    private final SubscribeService subscribeService;
    private final AccountRepository accountRepository;
    private final FetchAddressService fetchAddressService;
    private final FetchMappingService fetchMappingService;
    private final SubscriptionRepository subscriptionRepository;
    private final ShardSocialAccountRepository socialAccountRepository;
    private final CounterDao counterDao;
    private final FetchAttributeService fetchAttributeService;
    private final StoreAttributesService storeAttributesService;
    private final AccountInfoDao accountInfoDao;
    private final DeleteAttributesService deleteAttributesService;
    private final SubscriptionsService subscriptionsService;
    private final RedisConfigUtils redisConfigUtils;
    private final FetchBindingService fetchBindingService;
    private final ModifyAccountService modifyAccountService;
    private final CancelService cancelService;
    private final ModifyPasswordService modifyPasswordService;
    private final CreateAddressService createAddressService;
    private final SendMessageService sendMessageService;
    private final AccountValidator accountValidator;
    private final LogonService logonService;
    private final DeleteMappingService deleteMappingService;
    private final UnbindService unbindService;

    @Autowired
    public AccountAppService(BindSocialAccountService bindSocialAccountService,
                             RegisterAccountService registerAccountService,
                             SubscribeService subscribeService,
                             AccountRepository accountRepository,
                             SubscriptionRepository subscriptionRepository,
                             ShardSocialAccountRepository socialAccountRepository,
                             FetchMappingService fetchMappingService,
                             FetchAccountService fetchAccountService,
                             CounterDao counterDao,
                             FetchAttributeService fetchAttributeService,
                             StoreAttributesService storeAttributesService,
                             AccountInfoDao accountInfoDao,
                             DeleteAttributesService deleteAttributesService,
                             FetchBindingService fetchBindingService,
                             RedisConfigUtils redisConfigUtils,
                             SubscriptionsService subscriptionsService,
                             FetchAddressService fetchAddressService,
                             CancelService cancelService,
                             ModifyAccountService modifyAccountService,
                             CreateAddressService createAddressService,
                             ModifyPasswordService modifyPasswordService,
                             SendMessageService sendMessageService,
                             AccountValidator accountValidator,
                             LogonService logonService,
                             DeleteMappingService deleteMappingService,
                             UnbindService unbindService
    ) {
        this.bindSocialAccountService = bindSocialAccountService;
        this.fetchAccountService = fetchAccountService;
        this.registerAccountService = registerAccountService;
        this.subscribeService = subscribeService;
        this.accountRepository = accountRepository;
        this.fetchMappingService = fetchMappingService;
        this.subscriptionRepository = subscriptionRepository;
        this.socialAccountRepository = socialAccountRepository;
        this.counterDao = counterDao;
        this.fetchAttributeService = fetchAttributeService;
        this.storeAttributesService = storeAttributesService;
        this.accountInfoDao = accountInfoDao;
        this.deleteAttributesService = deleteAttributesService;
        this.fetchBindingService = fetchBindingService;
        this.redisConfigUtils = redisConfigUtils;
        this.subscriptionsService = subscriptionsService;
        this.fetchAddressService = fetchAddressService;
        this.modifyAccountService = modifyAccountService;
        this.cancelService = cancelService;
        this.modifyPasswordService = modifyPasswordService;
        this.createAddressService = createAddressService;
        this.sendMessageService = sendMessageService;
        this.accountValidator = accountValidator;
        this.logonService = logonService;
        this.deleteMappingService = deleteMappingService;
        this.unbindService = unbindService;
    }


    /**
     * 根据租户 渠道和bindId查询会员账号
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param unionId   unionId
     * @param bindId    bindId
     * @return com.alibaba.fastjson.JSONObject
     * @author xusheng
     * @date 2021/8/5 20:45
     */
    public JSONObject fetchAccountByUnionIdAndBindId(String tenantId, String channelId, String unionId, String bindId) {
        return this.fetchAccountService.fetchAccountByTenantIdAndBind(tenantId, channelId, unionId, bindId);
    }

    /**
     * 根据租户 渠道和bindId查询会员信息
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param unionId   unionId
     * @param bindId    bindId
     * @param fields    fields
     * @return com.alibaba.fastjson.JSONObject
     * @author xusheng
     * @date 2021/8/5 20:58
     */
    public JSONObject fetchProfileByUnionIdAndBindId(String tenantId, String channelId, String unionId, String bindId, String fields) {
        JSONObject jsonObject = this.fetchAccountService.fetchAccountByTenantIdAndBindAndUnionId(tenantId, channelId, unionId, bindId);
        Account account = new Account();
        IdentityId identityId = new IdentityId();
        identityId.specialAccountId(jsonObject.getString(ACCOUNT_ID));
        identityId.specialTenantId(tenantId);
        account.specialIdentityId(identityId);
        JSONObject profileJson = getProfile(account, fields);
        profileJson.put(IS_BIND, jsonObject.getBoolean(IS_BIND));
        return profileJson;
    }

    /**
     * 根据租户 邮箱查询会员信息
     *
     * @param tenantId tenantId
     * @param email    email
     * @param fields   fields
     * @return com.alibaba.fastjson.JSONObject
     * @author xusheng
     * @date 2021/8/5 20:58
     */
    public JSONObject fetchProfileByTenantIdAndEmail(String tenantId, String email, String fields) {
        Account account = this.fetchMappingService.fetchByTenantIdAndEmail(tenantId, email);
        return getProfile(account, fields);
    }

    /**
     * 根据租户 手机号查询会员信息
     *
     * @param tenantId tenantId
     * @param mobile   mobile
     * @param fields   fields
     * @return com.alibaba.fastjson.JSONObject
     * @author xusheng
     * @date 2021/8/5 20:58
     */
    public JSONObject fetchProfileByTenantIdAndMobile(String tenantId, String mobile, String fields) {
        Account account = this.fetchMappingService.fetchByTenantIdAndMobile(tenantId, mobile);
        return getProfile(account, fields);
    }

    /**
     * 根据租户 手机号查询会员信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param fields    fields
     * @return com.alibaba.fastjson.JSONObject
     * @author xusheng
     * @date 2021/8/5 20:58
     */
    public JSONObject fetchProfileByTenantIdAndAccountId(String tenantId, String accountId, String fields) {
        Account account = this.fetchAccountService.fetchAccountByTenantIdAndAccountId(tenantId, accountId);
        account.activeStatusCheck();
        return getProfile(account, fields);
    }

    /**
     * 注册账号
     *
     * @param account 账号聚合根
     * @author xusheng
     * @date 2021/6/2 23:36
     */
    @Transactional(rollbackFor = Exception.class)
    public void register(@Valid @ChannelExistValid @IsAdult @IsValidEmail @IsValidMobile @IsValidSource @IsAttrIdExist Account account, @IsValidOptId ShardSubscription shardSubscription) {
        registerAccountService.register(account);
        shardSubscription.specialAccountId(account.getAccountId());
        ShardSubscription dbSubscription = subscriptionsService.subscription(shardSubscription);
        subscriptionsService.save(dbSubscription);
        accountRepository.save(account);
        Optional.ofNullable(account.getAddress()).ifPresent(address -> createAddressService.store(account.getTenantId(), account.getAccountId(), address));
        this.modifyAccountService.runCustomEvent(account);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                if (Optional.ofNullable(account.getCounter()).isPresent()) {
                    ChangeCounterEvent changeCounterEvent = new ChangeCounterEvent(this, account);
                    SpringContextUtil.getApplicationContext().publishEvent(changeCounterEvent);
                }
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                RegisterEvent registerEvent = new RegisterEvent(this, account, shardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(registerEvent);
            }
        });
    }

    /**
     * 通过AccountId 和 tenantId 查找用户属性
     *
     * @param account 入参
     * @author yj
     */
    public void fetchExtraAttributeByTenantIdAndAccountId(@Valid @MemberExistValid Account account) {
        fetchAttributeService.fetchAttributesAssembleValidator(account);
    }

    /**
     * 保存用户属性
     *
     * @param account account
     */
    @Transactional(rollbackFor = Exception.class)
    public void storeAttributes(@Valid @MemberExistValid @IsAttrIdExist Account account) {
        if (Optional.ofNullable(account.getUserAdditionalInfo()).isPresent()) {
            //缓存中存在tenantId且accountId存在
            storeAttributesService.storeShardExtraAttributeAssembleValidator(account);
            storeAttributesService.storeShardExtraAttribute(account);
        } else {
            throw new BusinessException(PARAMETER_PARSING_ERROR.getCode(),
                    PARAMETER_PARSING_ERROR.getV2Code(),
                    PARAMETER_PARSING_ERROR.getMessage());
        }
        this.modifyAccountService.runCustomEvent(account);
        RedisConfigUtils.clearProfileCache(account.getTenantId(), account.getAccountId());
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UpdateAttributeEvent updateAttributeEvent = new UpdateAttributeEvent(this, account);
                SpringContextUtil.getApplicationContext().publishEvent(updateAttributeEvent);
            }
        });
    }

    /**
     * 删除属性
     *
     * @param account account
     */
    @Transactional(rollbackFor = Exception.class)
    public void deleteAttributes(@ChannelExistValid @IsAttrIdExist Account account) {
        if (Optional.ofNullable(account.getUserAdditionalInfo().getExtraAttributeList()).isPresent()) {
            deleteAttributesService.deleteAttributes(account);
            RedisConfigUtils.clearProfileCache(account.getTenantId(), account.getAccountId());
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
                @Override
                public void afterCommit() {
                    ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                    SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                    DeleteAttributeEvent deleteAttributeEvent = new DeleteAttributeEvent(this, account);
                    SpringContextUtil.getApplicationContext().publishEvent(deleteAttributeEvent);
                }
            });
        }
    }

    /**
     * 查询个人信息
     *
     * @param account account
     * @param fields  域
     * @return JSONObject
     */
    public JSONObject getProfile(@Valid @MemberExistValid Account account, String fields) {
        List<String> fieldsList = new ArrayList<>();
        if (StringUtils.isNotBlank(fields)) {
            //通过逗号把字串传分割并进行排序
            fieldsList = Arrays.stream(fields.split(COMMA)).filter(a -> !a.equals(PROFILE.getMsg())).distinct().sorted().collect(Collectors.toList());
        }
        // accountId存在并且有緩存 直接返回
        if (Optional.ofNullable(account.getAccountId()).isPresent() && redisConfigUtils.isMemberInfoCache(account.getTenantId(), account.getAccountId(), fieldsList)) {
            JSONObject result = parseObject(String.valueOf(redisConfigUtils.getMemberInfoCache(account.getTenantId(), account.getAccountId(), fieldsList)));
            if (Optional.ofNullable(result).isPresent() && !result.containsKey("redisCache")) {
                return result;
            }
        }
        // 先查詢basicInfo的信息和additionalInfo信息
        account = fetchAccountService.fetchAccountByTenantAndAccountId(account.getTenantId(), account.getAccountId(), fieldsList);
        if (fieldsList.stream().anyMatch(COUNTER.getMsg()::equals)) {
            ShardCounter counter = counterDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
            account.setCounter(Optional.ofNullable(counter).map(ShardCounter::getCounter).orElse(null));
        }
        if (fieldsList.stream().anyMatch(ADDRESS.getMsg()::equals)) {
            Address address = fetchAddressService.fetchByTenantIdAndAccountId(account.getTenantId(), account.getAccountId());
            account.setAddress(address);
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(ACCOUNT, account);
        if (fieldsList.stream().anyMatch(SOCIAL_ACCOUNT.getMsg()::equals)) {
            Optional<ShardSocialAccount> socialAccount = Optional.ofNullable(socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.getTenantId(), account.getAccountId()));
            jsonObject.put(SOCIAL_ACCOUNT.getMsg(), socialAccount.orElse(null));
        }
        if (fieldsList.stream().anyMatch(SUBSCRIPTION.getMsg()::equals)) {
            Optional<ShardSubscription> subscription = Optional.ofNullable(subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId()));
            jsonObject.put(SUBSCRIPTION.getMsg(), subscription.orElse(null));
        }
        redisConfigUtils.addProfileCache(account.getTenantId(), account.getAccountId(), JSON.toJSONString(jsonObject), fieldsList);
        return jsonObject;
    }

    @Transactional(rollbackFor = Exception.class)
    public void bind(@Valid @MemberExistValid Account account, ShardSocialAccount shardSocialAccount, @IsValidOptId ShardSubscription shardSubscription) {
        ShardSocialAccount resultShardSocialAccount = bindSocialAccountService.bind(shardSocialAccount);
        ShardSubscription dbSubscription = subscriptionsService.subscription(shardSubscription);
        modifyAccountService.storeAccountInfo(account);
        modifyAccountService.storeDevice(account);
        subscriptionsService.save(dbSubscription);
        bindSocialAccountService.save(resultShardSocialAccount);
        RedisConfigUtils.clearProfileCache(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId());
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                BindingEvent bindingEvent = new BindingEvent(this, account, shardSubscription, shardSocialAccount);
                SpringContextUtil.getApplicationContext().publishEvent(bindingEvent);
            }
        });
    }

    /**
     * 解绑
     *
     * @param shardSocialAccount shardSocialAccount
     * @param shardSubscription  shardSubscription
     * @param unBindRoute        unBindType
     * @author xusheng
     * @date 2021/6/10 22:46
     */
    @Transactional(rollbackFor = Exception.class)
    public void unBind(@Valid ShardSocialAccount shardSocialAccount, @IsValidOptId ShardSubscription shardSubscription, String unBindRoute) {
        String accountId = null;
        switch (UnBindRouteEnum.getByKeyOrValue(unBindRoute)) {
            case MEMBER_ID:
                unbindService.unBind(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), shardSocialAccount.getAccountId(), "3");
                break;
            case BIND_ID_AND_CHANNEL_ID:
//                bindId+channelId
                accountId = Optional.ofNullable(getAccountId(shardSocialAccount.getTenantId(), "bindId", shardSocialAccount.getChannelId(), shardSocialAccount.getBindId())).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
//                根据channelId解绑
                unbindService.unBind(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), accountId, "2");
                break;
            case UNION_ID_AND_CHANNEL_ID:
//                unionId + channelId
                accountId = Optional.ofNullable(getAccountId(shardSocialAccount.getTenantId(), "unionId", shardSocialAccount.getChannelId(), shardSocialAccount.getUnionId())).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
                unbindService.unBind(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), accountId, "1");
                //                根据unionType解绑
                break;
            case MEMBER_ID_AND_CHANNEL_ID:
                accountId = shardSocialAccount.getAccountId();
//                memberId+channelId
//                根据channelId解绑
                unbindService.unBind(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), accountId, "2");
                break;
            default:
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
//        //判断channel是否存在
//        Channel channel = Optional.ofNullable(shardSocialAccount.getChannel()).orElseThrow(() -> new BusinessException(PARAMETER_PARSING_ERROR.getCode(), PARAMETER_PARSING_ERROR.getV2Code(), PARAMETER_PARSING_ERROR.getMessage()));
//        //根据类型封装需要删除的bindid,shardSocialAccount是需要同步的数据
//        List<UnionIdMapping> unionIdMappingList = new ArrayList<>();
//        ShardSocialAccount dbShardSocialAccount = bindSocialAccountService.getShardSocialAccountByUnBindType(shardSocialAccount, unBindRoute, channel, unionIdMappingList);
//        //判断dbShardSocialAccount是否为空，为空则不存在绑定关系，不需要发送DMP消息
//        if (Optional.ofNullable(dbShardSocialAccount).isPresent()) {
//            if (!Optional.ofNullable(dbShardSocialAccount.getSocialAccountList()).isPresent() || dbShardSocialAccount.getSocialAccountList().isEmpty()) {
//                deleteMappingService.deleteAllBinding(shardSocialAccount.getAccountId(), shardSocialAccount.getTenantId());
//            }
//            shardSocialAccount.specialIdentityId(dbShardSocialAccount.getIdentityId());
//            //修改订阅状态
//            shardSubscription.specialIdentityId(dbShardSocialAccount.getIdentityId());
//            ShardSubscription dbShardSubscription = subscriptionsService.unSubscription(shardSocialAccount, shardSubscription);
//            List<BindIdMapping> bindIdMapping = bindSocialAccountService.isDelBindIdMapping(shardSocialAccount);
//            //删除解绑的绑定关系
//            bindSocialAccountService.delete(dbShardSocialAccount);
//            //删除解绑的订阅关系
//            subscriptionsService.delete(dbShardSubscription);
//            //封装需要删除的socialAccount和bindIdmapping
//            boolean isRemoveUnionId = bindSocialAccountService.delMapping(bindIdMapping, unionIdMappingList);
//            if (Optional.ofNullable(dbShardSocialAccount.getAccountId()).isPresent()) {
//                RedisConfigUtils.clearProfileCache(dbShardSocialAccount.getTenantId(), dbShardSocialAccount.getAccountId());
//            }
//            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
//                @Override
//                public void afterCommit() {
//                    UnBindingEvent unBindingEvent = new UnBindingEvent(this, shardSubscription, shardSocialAccount, isRemoveUnionId, DELETE_FLAG);
//                    SpringContextUtil.getApplicationContext().publishEvent(unBindingEvent);
//                }
//            });
//        } else {
//            deleteMappingService.deleteAllBinding(shardSocialAccount.getAccountId(), shardSocialAccount.getTenantId());
//        }
    }

    private String getAccountId(String tenant, String type, String channel, String query) {
        String accountId;
        switch (type) {
            case MOBILE:
                // 判断是否是手机号格式
                if (!StringValidUtil.isMobile(query)) {
                    throw new BusinessException(ResultEnum.INCORRECT_MOBILE.getCode(), ResultEnum.INCORRECT_MOBILE.getV2Code(), ResultEnum.INCORRECT_MOBILE.getMessage());
                }
                // 根据手机号查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(tenant, query)).map(MobileMapping::getAccountId).orElse(null);
                break;
            case V3Constants.BIND_ID:
                // 判断channel是否存在 不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(ResultEnum.INCORRECT_CHANNEL_ID.getCode(), ResultEnum.INCORRECT_CHANNEL_ID.getV2Code(), ResultEnum.INCORRECT_CHANNEL_ID.getMessage()));
//                根据channel和bindId查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenant, query, channel)).map(BindIdMapping::getAccountId).orElse(null);
                break;
            case UNION_ID:
                // 判断channel是否存在，如果不存在则报错
                channel = Optional.ofNullable(channel).orElseThrow(() -> new BusinessException(ResultEnum.INCORRECT_QUERY_PARAM.getCode(), ResultEnum.INCORRECT_QUERY_PARAM.getV2Code(), ResultEnum.INCORRECT_QUERY_PARAM.getMessage()));
                // 根据租户和渠道查询unionType，如果不存在则报错
                String channelUnionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
                accountId = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenant, query, channelUnionIdType)).map(UnionIdMapping::getAccountId).orElse(null);
                break;
            case ACCOUNT_ID:
                // 如果是通过accountId查询则将query赋值给accountId
                accountId = query;
                break;
            default:
                throw new BusinessException(PARAMETER_PARSING_ERROR.getCode(), PARAMETER_PARSING_ERROR.getV2Code(), PARAMETER_PARSING_ERROR.getMessage());
        }
        return accountId;
    }

    /**
     * 根据 type 解绑
     *
     * @param shardSocialAccount shardSocialAccount
     * @param type               type
     * @author xusheng
     * @date 2021/6/11 16:41
     */
    @Transactional(rollbackFor = Exception.class)
    public void unBindAll(ShardSocialAccount shardSocialAccount, String type) {
        List<ShardSocialAccount> shardSocialAccountList = bindSocialAccountService.unBindAll(shardSocialAccount, type);
        Optional.ofNullable(shardSocialAccountList)
                .filter(shardSocialAccounts -> !shardSocialAccounts.isEmpty())
                .ifPresent(shardSocialAccounts -> shardSocialAccounts.forEach(shardSocialAccount1 -> {
                    SubscriptionItem subscriptionItem = new SubscriptionItem();
                    subscriptionItem.setChannelId(shardSocialAccount1.getChannelId());
                    ShardSubscription shardSubscription = new ShardSubscription(shardSocialAccount1.getIdentityId(), Collections.singletonList(subscriptionItem));
                    this.unBind(shardSocialAccount1, shardSubscription, UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey());
                }));
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject registerBind(@Valid @IsAttrIdExist @IsAdult @IsValidSource @ChannelExistValid Account account, ShardSocialAccount shardSocialAccount, @IsValidOptId ShardSubscription shardSubscription) {
        boolean newRegister = false;
        //多账号校验
        String memberId = accountValidator.multipleAccountValidator(account, shardSocialAccount);
        Optional.of(account).map(Account::getIdentityId).ifPresent(identityId -> identityId.specialAccountId(memberId));
        ShardSocialAccount dbSocialAccount;
        ShardSubscription dbSubscription;
        if (StringUtils.isBlank(memberId)) {
            registerAccountService.register(account);
            shardSocialAccount.specialIdentityId(account.getIdentityId());
            dbSocialAccount = bindSocialAccountService.bind(shardSocialAccount);
            shardSubscription.specialAccountId(account.getAccountId());
            dbSubscription = subscriptionsService.subscription(shardSubscription);
            Optional.of(account).map(Account::getAddress).ifPresent(address -> createAddressService.store(account.getTenantId(), account.getAccountId(), address));
            accountRepository.save(account);
            newRegister = true;
        } else {
            modifyAccountService.storeAccountInfo(account);
            modifyAccountService.storeDevice(account);
            shardSocialAccount.specialIdentityId(account.getIdentityId());
            dbSocialAccount = bindSocialAccountService.bind(shardSocialAccount);
            shardSubscription.specialAccountId(account.getAccountId());
            dbSubscription = subscriptionsService.subscription(shardSubscription);
        }
        bindSocialAccountService.save(dbSocialAccount);
        subscriptionsService.save(dbSubscription);
        this.modifyAccountService.runCustomEvent(account);
        RedisConfigUtils.clearProfileCache(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId());
        boolean finalNewMemberStatus = newRegister;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                if (finalNewMemberStatus) {
                    if (Optional.ofNullable(account.getCounter()).isPresent()) {
                        ChangeCounterEvent changeCounterEvent = new ChangeCounterEvent(this, account);
                        SpringContextUtil.getApplicationContext().publishEvent(changeCounterEvent);
                    }
                    RegisterBindEvent registerBindEvent = new RegisterBindEvent(this, account, shardSocialAccount, shardSubscription);
                    SpringContextUtil.getApplicationContext().publishEvent(registerBindEvent);
                } else {
                    BindingEvent bindingEvent = new BindingEvent(this, account, shardSubscription, shardSocialAccount);
                    SpringContextUtil.getApplicationContext().publishEvent(bindingEvent);
                }
            }
        });
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(AccountConstants.MEMBER_ID, account.getAccountId());
        jsonObject.put(AccountConstants.OPEN_ID, account.getOpenUid());
        jsonObject.put(AccountConstants.NEW_REGISTER, newRegister);
        return jsonObject;
    }

    /**
     * 迁移注册接口
     *
     * @param account
     * @param shardSocialAccount
     * @param shardSubscription
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public JSONObject migrateRegisterBind(@Valid Account account, ShardSocialAccount shardSocialAccount, @IsValidOptId ShardSubscription shardSubscription) {
        boolean newRegister = false;
        //多账号校验
        String memberId = accountValidator.multipleAccountValidator(account, shardSocialAccount);
        Optional.of(account).map(Account::getIdentityId).ifPresent(identityId -> identityId.specialAccountId(memberId));
        ShardSocialAccount dbSocialAccount;
        ShardSubscription dbSubscription;
        if (StringUtils.isBlank(memberId)) {
            registerAccountService.register(account);
            shardSocialAccount.specialIdentityId(account.getIdentityId());
            dbSocialAccount = bindSocialAccountService.migrateBind(shardSocialAccount);
            shardSubscription.specialAccountId(account.getAccountId());
            dbSubscription = subscriptionsService.subscription(shardSubscription);
            Optional.of(account).map(Account::getAddress).ifPresent(address -> createAddressService.store(account.getTenantId(), account.getAccountId(), address));
            accountRepository.save(account);
            newRegister = true;
        } else {
            modifyAccountService.storeAccountInfo(account);
            modifyAccountService.storeDevice(account);
            shardSocialAccount.specialIdentityId(account.getIdentityId());
            dbSocialAccount = bindSocialAccountService.migrateBind(shardSocialAccount);
            shardSubscription.specialAccountId(account.getAccountId());
            dbSubscription = subscriptionsService.subscription(shardSubscription);
        }
        bindSocialAccountService.save(dbSocialAccount);
        subscriptionsService.save(dbSubscription);
        boolean finalNewMemberStatus = newRegister;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                if (finalNewMemberStatus) {
                    RegisterBindEvent registerBindEvent = new RegisterBindEvent(this, account, shardSocialAccount, shardSubscription);
                    SpringContextUtil.getApplicationContext().publishEvent(registerBindEvent);
                } else {
                    BindingEvent bindingEvent = new BindingEvent(this, account, shardSubscription, shardSocialAccount);
                    SpringContextUtil.getApplicationContext().publishEvent(bindingEvent);
                }
            }
        });
        JSONObject jsonObject = new JSONObject();
        jsonObject.put(AccountConstants.MEMBER_ID, account.getAccountId());
        jsonObject.put(AccountConstants.OPEN_ID, account.getOpenUid());
        jsonObject.put(AccountConstants.NEW_REGISTER, newRegister);
        return jsonObject;
    }

    public JSONObject queryBinding(Long tenant, Long channel, String type, String query) {
        Account account = new Account();
        List<BindDTO> bindDTOList = new ArrayList<>();
        if (BIND_ID.getKey().toString().equals(type)) {
            account = fetchMappingService.fetchByTenantIdAndChannelIdAndBindId(tenant.toString(), channel.toString(), query);
        }
        if (CHANNEL_AND_OPEN_ID.getKey().toString().equals(type) || OPEN_ID.getKey().toString().equals(type)) {
            account = Optional.ofNullable(fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), query)).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        }
        if (MEMBER_ID.getKey().toString().equals(type) || CHANNEL_AND_MEMBER_ID.getKey().toString().equals(type)) {
            ShardAccountInfo accountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(tenant.toString(), query, AccountStatus.ACTIVE))
                    .orElseThrow(() ->
                            new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                                    ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                                    ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
            IdentityId identityId = IdentityId.IdentityIdBuilder.anIdentityId()
                    .accountId(accountInfo.getIdentityId().getAccountId())
                    .build();
            account.setIdentityId(identityId);
        }
        ShardSocialAccount shardSocialAccount = fetchBindingService.fetchBindByTenantAndAccountId(tenant.toString(), account.getAccountId());

        if (!Optional.ofNullable(shardSocialAccount.getSocialAccountList()).isPresent()) {
            throw new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(), ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), ResultEnum.BIND_ID_NOT_EXIST.getMessage());
        }

        if (BIND_ID.getKey().toString().equals(type)) {
            shardSocialAccount.getSocialAccountList().removeIf(s -> !s.getBindId().equals(query));
        }
        if (CHANNEL_AND_MEMBER_ID.getKey().toString().equals(type) || CHANNEL_AND_OPEN_ID.getKey().toString().equals(type)) {
            shardSocialAccount.getSocialAccountList().removeIf(s -> !s.getChannel().getChannelId().equals(channel.toString()));
        }
        //当socialAccountList被remove后，size发生变化，需要再次判断是否有值
        if (!Optional.ofNullable(shardSocialAccount.getSocialAccountList()).isPresent()) {
            throw new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(), ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), ResultEnum.BIND_ID_NOT_EXIST.getMessage());
        }
        shardSocialAccount.getSocialAccountList().forEach(s -> bindDTOList.add(s.build()));
        List<BindDTO> bindDTOS = bindDTOList.stream().sorted(Comparator.comparing(BindDTO::getChannelId, Comparator.nullsLast(Long::compareTo))).collect(Collectors.toList());
        JSONObject jsonObject = new JSONObject();
        String accountId = account.getAccountId();
        jsonObject.put(ACCOUNT_ID, accountId);
        jsonObject.put("openId", Optional.ofNullable(account.getOpenUid()).orElseGet(() -> accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenant.toString(), accountId).getOpenUid()));
        jsonObject.put("bindDTOList", JSON.toJSONString(bindDTOS));
        return jsonObject;
    }

    @Transactional(rollbackFor = Exception.class)
    public void storeShardSubscription(@Valid @IsExistMember @IsValidOptId ShardSubscription shardSubscription) {
        //保存
        subscriptionsService.subscription(shardSubscription);
        RedisConfigUtils.clearProfileCache(shardSubscription.getTenantId(), shardSubscription.getAccountId());
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, shardSubscription.getTenantId(), shardSubscription.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UpdateSubscriptionEvent updateSubscriptionEvent = new UpdateSubscriptionEvent(this, shardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(updateSubscriptionEvent);
            }
        });
    }

    public SubscriptionQueryDTO querySubscriptionsByOpenId(@Valid @MemberExistValid Account account) {
        return subscriptionsService.fetchSubscriptionsByOpenId(account);
    }

    public QuerySubscriptionDTO querySubscriptions(@Valid @MemberExistValid Account account) {
        return subscriptionsService.fetchSubscriptionByAccountId(account);
    }

    @Transactional(rollbackFor = Exception.class)
    public QueryProfileDTO modifyAccount(@Valid @IsValidEmail @IsValidMobile @MemberExistValid @IsAdult @IsAttrIdExist @ChannelExistValid Account account, @IsValidOptId ShardSubscription shardSubscription) {
        // 组合account的中的profile聚合
        Account basicAccount = modifyAccountService.comboAccountValidate(account);
        accountRepository.save(basicAccount);
        if (Optional.ofNullable(shardSubscription).map(ShardSubscription::getSubscriptionItemList).filter(s -> !s.isEmpty()).isPresent()) {
            ShardSubscription dbSubscription = subscriptionsService.subscription(shardSubscription);
            subscriptionRepository.save(dbSubscription);
        }
        Optional.ofNullable(account.getAddress()).ifPresent(a -> createAddressService.store(account.getTenantId(), account.getAccountId(), account.getAddress()));
        basicAccount.setAddress(account.getAddress());
        RedisConfigUtils.clearProfileCache(account.getTenantId(), account.getAccountId());
        List<PointDTO> pointDTOList = this.modifyAccountService.runCustomEvent(account);
        QueryProfileDTO profileDTO = new QueryProfileDTO(account.getAccountId(), pointDTOList);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.getTenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                if (Optional.ofNullable(account.getCounter()).isPresent()) {
                    ChangeCounterEvent changeCounterEvent = new ChangeCounterEvent(this, account);
                    SpringContextUtil.getApplicationContext().publishEvent(changeCounterEvent);
                }
                UpdateProfileEvent updateProfileEvent = new UpdateProfileEvent(this, basicAccount, shardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(updateProfileEvent);
            }
        });
        return profileDTO;
    }

    @Transactional(rollbackFor = Exception.class)
    public void inactiveAccount(Account account) {
        //判斷是否是openUid，如果是通過openUid查詢account的AccountId
        if (Optional.ofNullable(account.getOpenUid()).isPresent()) {
            account = fetchMappingService.fetchByTenantIdAndOpenUid(account.getTenantId(), account.getOpenUid());
        }
        // 通過查詢的accountId查詢Account信息
        account = accountRepository.fetchAccountByTenantIdAndAccountId(account.getTenantId(), account.getAccountId());
        //將account账号注销（包含手机邮箱置空，账号改为失效状态）
        cancelService.cancellation(account);
        // 清除緩存
        RedisConfigUtils.clearProfileCache(account.getTenantId(), account.getAccountId());
        Account finalAccount = account;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, finalAccount.tenantId(), finalAccount.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                InActiveEvent inActiveEvent = new InActiveEvent(this, finalAccount);
                SpringContextUtil.getApplicationContext().publishEvent(inActiveEvent);
            }
        });
    }

    /**
     * 登录
     *
     * @param logonCommand logonCommand
     * @return LogonDTO
     */
    public LogonDTO logon(LogonCommand logonCommand) {
        Account account;
        switch (AccountLogonTypeEnum.getByType(logonCommand.getLogonType())) {
            case PASSWORD:
                account = logonService.logonByPwd(logonCommand);
                account.checkPassword(logonCommand.getPassword());
                break;
            case SMS:
                account = logonService.logonBySms(logonCommand);
                boolean success = sendMessageService.logonSmsVerifyCode(account.getTenantId(), logonCommand.getMobile(), logonCommand.getTemplateId(), logonCommand.getSmsCode());
                if (!success) {
                    throw new BusinessException(ResultEnum.INCORRECT_MESSAGE_CODE.getCode(), ResultEnum.INCORRECT_MESSAGE_CODE.getV2Code(), ResultEnum.INCORRECT_MESSAGE_CODE.getMessage());
                }
                break;
            default:
                throw new BusinessException(ResultEnum.INCORRECT_QUERY_PARAM.getCode(), ResultEnum.INCORRECT_QUERY_PARAM.getV2Code(), ResultEnum.INCORRECT_QUERY_PARAM.getMessage());
        }
        return new LogonDTO(account.getAccountId());
    }

    /**
     * 修改密码
     *
     * @param modifyPasswordCommand modifyPasswordCommand
     * @author xusheng
     * @date 2021/6/15 9:51
     */
    @Transactional(rollbackFor = Exception.class)
    public void modifyPassword(ModifyPasswordCommand modifyPasswordCommand) {
        Account account = modifyPasswordService.modifyPassword(modifyPasswordCommand);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                ChangePasswordEvent changePasswordEvent = new ChangePasswordEvent(this, account);
                SpringContextUtil.getApplicationContext().publishEvent(changePasswordEvent);
            }
        });
    }

    /**
     * 激活账号
     *
     * @param account account
     */
    @Transactional(rollbackFor = Exception.class)
    public void activeMember(Account account) {
        ShardAccountInfo accountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId()))
                .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                        ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                        ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        accountInfo.addUpdatedTime();
        account = accountInfo.builder();
        account.activeStatus();
        if (StringUtils.isBlank(account.getOpenUid())) {
            account.specialNewOpenUid();
        }
        accountRepository.saveAccountInfo(account);
        Account finalAccount = account;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, finalAccount.tenantId(), finalAccount.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                ActiveEvent activeEvent = new ActiveEvent(this, finalAccount);
                SpringContextUtil.getApplicationContext().publishEvent(activeEvent);
            }
        });
    }

    /**
     * 关注
     *
     * @param shardSocialAccount shardSocialAccount
     */
    @Transactional(rollbackFor = Exception.class)
    public void subscribe(ShardSocialAccount shardSocialAccount) {
        ShardSubscription shardSubscription = null;
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(shardSocialAccount.getTenantId(), shardSocialAccount.getBindId(), shardSocialAccount.getChannelId());
        if (Optional.ofNullable(bindIdMapping).isPresent()) {
            Optional.of(shardSocialAccount)
                    .map(ShardSocialAccount::getIdentityId)
                    .ifPresent(identityId1 -> identityId1.specialAccountId(bindIdMapping.getAccountId()));
            shardSubscription = subscribeService.saveOrUpdateSubscriptionToIn(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), shardSocialAccount.getAccountId());
        }
        ShardSubscription finalShardSubscription = shardSubscription;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, shardSocialAccount.getTenantId(), shardSocialAccount.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                SubscribeEvent subscribeEvent = new SubscribeEvent(this, shardSocialAccount);
                SpringContextUtil.getApplicationContext().publishEvent(subscribeEvent);
                SmsUpdateSubscriptionEvent smsUpdateSubscriptionEvent = new SmsUpdateSubscriptionEvent(this, finalShardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(smsUpdateSubscriptionEvent);
            }
        });
    }

    /**
     * 取关
     *
     * @param shardSocialAccount shardSocialAccount
     */
    @Transactional(rollbackFor = Exception.class)
    public void unSubscribe(ShardSocialAccount shardSocialAccount) {
        ShardSubscription shardSubscription = null;
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(shardSocialAccount.getTenantId(), shardSocialAccount.getBindId(), shardSocialAccount.getChannelId());
        if (Optional.ofNullable(bindIdMapping).isPresent()) {
            Optional.of(shardSocialAccount)
                    .map(ShardSocialAccount::getIdentityId)
                    .ifPresent(identityId1 -> identityId1.specialAccountId(bindIdMapping.getAccountId()));
            shardSubscription = subscribeService.saveOrUpdateSubscriptionToOut(shardSocialAccount.getTenantId(), shardSocialAccount.getChannelId(), shardSocialAccount.getAccountId());
        }
        ShardSubscription finalShardSubscription = shardSubscription;
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, shardSocialAccount.getTenantId(), shardSocialAccount.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                UnSubscribeEvent unSubscribeEvent = new UnSubscribeEvent(this, shardSocialAccount);
                SpringContextUtil.getApplicationContext().publishEvent(unSubscribeEvent);
                SmsUpdateSubscriptionEvent smsUpdateSubscriptionEvent = new SmsUpdateSubscriptionEvent(this, finalShardSubscription);
                SpringContextUtil.getApplicationContext().publishEvent(smsUpdateSubscriptionEvent);
            }
        });
    }

    /**
     * 更新替换 BIND_ID
     *
     * @param oldShardSocialAccount oldShardSocialAccount
     * @param newShardSocialAccount newShardSocialAccount
     * @param oldShardSubscription  oldShardSubscription
     * @param newShardSubscription  newShardSubscription
     * @author xusheng
     * @date 2021/6/16 9:39
     */
    @Transactional(rollbackFor = Exception.class)
    public void updateBindId(UpdateBindIdCommand updateBindIdCommand, ShardSocialAccount oldShardSocialAccount,
                             ShardSocialAccount newShardSocialAccount, ShardSubscription oldShardSubscription, ShardSubscription newShardSubscription) {
        bindSocialAccountService.updateBindIdValidator(updateBindIdCommand);
        this.unBind(oldShardSocialAccount, oldShardSubscription, UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey());
        Account account = new Account();
        IdentityId identityId = new IdentityId();
        identityId.setTenantId(String.valueOf(updateBindIdCommand.getTenantId()));
        identityId.setAccountId(updateBindIdCommand.getMemberId());
        account.setIdentityId(identityId);
        this.bind(account, newShardSocialAccount, newShardSubscription);
    }

    /**
     * 替换BIND_ID，解绑冲突的绑定数据
     *
     * @param shardSocialAccount shardSocialAccount
     * @author xusheng
     * @date 2021/6/16 11:09
     */
    @Transactional(rollbackFor = Exception.class)
    public void replaceBindId(Account account, ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription) {
        List<ShardSocialAccount> shardSocialAccountList = bindSocialAccountService.replaceBindId(shardSocialAccount);
        Optional.ofNullable(shardSocialAccountList)
                .filter(shardSocialAccounts -> !shardSocialAccounts.isEmpty())
                .ifPresent(shardSocialAccounts -> shardSocialAccounts.forEach(shardSocialAccount1 -> {
                    SubscriptionItem subscriptionItem = new SubscriptionItem();
                    subscriptionItem.setChannelId(shardSocialAccount1.getChannelId());
                    this.unBind(shardSocialAccount1, new ShardSubscription(shardSocialAccount1.getIdentityId(), Collections.singletonList(subscriptionItem)), UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey());
                }));
        SubscriptionItem subscriptionItem = new SubscriptionItem();
        subscriptionItem.setChannelId(shardSocialAccount.getChannelId());
        this.bind(account, shardSocialAccount, shardSubscription);
    }
}
