package com.pg.account.infrastructure.common.enums;


/**
 * @author JackSun
 */

public enum AddressTypeEnum {
    /**
     * 地址类型
     */
    HOME("1"),
    COMPANY("3"),
    DELIVERY("5");

    String value;

    AddressTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
