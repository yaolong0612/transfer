package com.pg.account.sharding.infrastructure.jpa.config;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author JackSun
 * @date 3/6/17
 */
@javax.persistence.Entity
@Table(name = "SHARD_COPY_CONFIG")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardCopyConfig extends BaseEntity implements Serializable {


    private static final long serialVersionUID = 7491591701678352776L;
    @Id
    private Long id;
    @Column(name = "o_tenant_id")
    private String oldTenantId;
    @Column(name = "o_channel_id")
    private String oldChannelId;
    @Column(name = "n_tenant_id")
    private String newTenantId;
    @Column(name = "n_channel_id")
    private String newChannelId;
    @Column(name = "create_by")
    private String createBy;
    @Column(name = "modify_by")
    private String modifyBy;
    private Byte status;

}
