package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.EMAIL_VALID_PATTERN;

/**
 * @author JackSun
 * @date 2017/3/12
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckEmailCommand implements Serializable {
    private static final long serialVersionUID = -8295318947809264762L;

    @ApiModelProperty(value = "租户ID", example = "10002", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "邮箱", example = "101134@qq.com", required = true)
    @NotNull(message = "missing email")
    @Pattern(regexp = EMAIL_VALID_PATTERN, message = "email format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
}
