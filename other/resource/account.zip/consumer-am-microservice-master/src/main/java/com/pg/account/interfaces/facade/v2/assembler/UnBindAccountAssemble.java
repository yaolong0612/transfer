package com.pg.account.interfaces.facade.v2.assembler;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.Registration;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * 组装解绑数据
 *
 * @author xusheng
 * @createDate 2021/6/8 <br>
 */
@Component("UnBindAccountAssemble")
public class UnBindAccountAssemble {

    private final ChannelDao channelDao;

    @Autowired
    public UnBindAccountAssemble(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 封装注册绑定参数
     *
     * @param account   account
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param bindId    bindId
     * @return com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount
     * @author xusheng
     * @date 2021/6/8 18:17
     */
    public Account toAccount(Account account, Long tenantId, Long channelId, String bindId, String openId) {
        ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(tenantId.toString(), channelId.toString());
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        Registration registration = new Registration();
        registration.specialChannel(channel);
        account.build(openId, registration, null);
        return account;
    }

}
