package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.interfaces.dto.PointDTO;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.counter.CounterDao;
import com.pg.account.sharding.infrastructure.jpa.counter.ShardCounter;
import com.pg.account.sharding.infrastructure.jpa.mapping.EmailMappingDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMappingDao;
import com.pg.account.sharding.infrastructure.jpa.profile.device.DeviceDao;
import com.pg.account.sharding.infrastructure.jpa.profile.device.ShardDevice;
import com.pg.account.sharding.infrastructure.jpa.profile.education.EducationDao;
import com.pg.account.sharding.infrastructure.jpa.profile.education.ShardEducation;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import com.pg.account.sharding.infrastructure.jpa.profile.humanrelation.HumanRelationDao;
import com.pg.account.sharding.infrastructure.jpa.profile.humanrelation.ShardHumanRelation;
import com.pg.account.sharding.infrastructure.jpa.profile.job.JobDao;
import com.pg.account.sharding.infrastructure.jpa.profile.job.ShardJob;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.*;
import static com.pg.account.sharding.domain.model.account.UserAdditionalInfo.sequenceUniqueValid;
import static com.pg.account.sharding.domain.model.account.UserAdditionalInfo.sequenceUniqueValidate;

/**
 * 更新会员信息
 *
 * @author Jack
 * @date 2021/5/31 13:02
 */
@Service
@Slf4j
public class ModifyAccountService {

    public static final String VALIDATOR = "validator";
    public static final String RUN_EVENT = "runEvent";
    private static final String PATH = "com.pg.account.sharding.domain.service.";
    private final DeviceDao deviceDao;
    private final EducationDao educationDao;
    private final JobDao jobDao;
    private final HumanRelationDao humanRelationDao;
    private final ExtraAttributeDao extraAttributeDao;
    private final MobileMappingDao mobileMappingDao;
    private final EmailMappingDao emailMappingDao;
    private final CounterDao counterDao;
    private final AccountInfoDao accountInfoDao;
    private final AccountRepository accountRepository;

    @Autowired
    public ModifyAccountService(DeviceDao deviceDao, EducationDao educationDao,
                                JobDao jobDao,
                                HumanRelationDao humanRelationDao,
                                ExtraAttributeDao extraAttributeDao,
                                MobileMappingDao mobileMappingDao,
                                EmailMappingDao emailMappingDao,
                                CounterDao counterDao,
                                AccountInfoDao accountInfoDao,
                                AccountRepository accountRepository
    ) {
        this.deviceDao = deviceDao;
        this.educationDao = educationDao;
        this.jobDao = jobDao;
        this.humanRelationDao = humanRelationDao;
        this.extraAttributeDao = extraAttributeDao;
        this.mobileMappingDao = mobileMappingDao;
        this.emailMappingDao = emailMappingDao;
        this.accountInfoDao = accountInfoDao;
        this.counterDao = counterDao;
        this.accountRepository = accountRepository;
    }

    /**
     * 更新会员信息
     *
     * @param account account
     * @author xusheng
     * @date 2021/6/9 9:39
     */
    public void storeDevice(Account account) {
        if (Optional.ofNullable(account).isPresent()) {
            //判断是否传入device信息
            Optional.ofNullable(account.getUserAdditionalInfo())
                    .map(UserAdditionalInfo::getDevice)
                    .ifPresent(deviceInfo -> {
                        ShardDevice shardDevice = deviceDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
                        if (Optional.ofNullable(shardDevice).isPresent()) {
                            deviceInfo.builder(shardDevice.getDevice());
                            shardDevice.setDevice(deviceInfo);
                            shardDevice.addUpdatedTime();
                        } else {
                            shardDevice = new ShardDevice();
                            shardDevice.build(account);
                        }
                        deviceDao.save(shardDevice);
                    });
        }
    }

    /**
     * 激活账号
     *
     * @param account account
     * @author xusheng
     * @date 2021/7/22 15:00
     */
    public void storeAccountInfo(Account account) {
        ShardAccountInfo shardAccountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId()))
                .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        boolean flag = false;
        if (StringUtils.isBlank(shardAccountInfo.getOpenUid())) {
            account.specialNewOpenUid();
            flag = true;
        }
        if (!shardAccountInfo.checkAccountStatusIsActive()) {
            shardAccountInfo.active();
            flag = true;
        }

        if (flag) {
            accountInfoDao.save(shardAccountInfo);
        } else {
            account.setOpenUid(shardAccountInfo.getOpenUid());
        }
    }

    public boolean isModifyMobile(Account account) {
        ShardAccountInfo shardAccountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.tenantId(), account.accountId()))
                .orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
        boolean flag = false;
        boolean modifyMobile = false;
        if (StringUtils.isBlank(shardAccountInfo.getOpenUid())) {
            account.specialNewOpenUid();
            shardAccountInfo.setOpenUid(account.getOpenUid());
            flag = true;
        }
        if (!shardAccountInfo.checkAccountStatusIsActive()) {
            shardAccountInfo.active();
            flag = true;
        }
        if (Optional.ofNullable(account.getMobile()).isPresent() && !account.getMobile().equals(shardAccountInfo.getMobile())) {
            Optional.ofNullable(shardAccountInfo.getMobile()).ifPresent(mobile -> mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(account.tenantId(), mobile));
            shardAccountInfo.modifyMobile(account.getMobile());
            MobileMapping mobileMapping = new MobileMapping();
            mobileMapping.builder(account);
            mobileMappingDao.save(mobileMapping);
            modifyMobile = true;
            flag = true;
        }

        if (flag) {
            accountInfoDao.save(shardAccountInfo);
        } else {
            // 这个不太明白有啥用
            account.setOpenUid(shardAccountInfo.getOpenUid());
        }
        return modifyMobile;
    }

    /**
     * 组合account并校验
     *
     * @param account account
     * @return account
     */
    public Account comboAccountValidate(Account account) {
        //进行序列校验
        sequenceUniqueValid(account.getUserAdditionalInfo());
        // 進行屬性和首次加積分校驗
        this.modifyAccountValidate(account);
        this.attrIdValidate(account);
        //组装好聚合根
        String tenantId = account.getTenantId();
        String accountId = account.getAccountId();
        ShardAccountInfo dbShardAccountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId))
                .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        ShardAccountInfo cmdShardAccountInfo = new ShardAccountInfo();
        cmdShardAccountInfo.build(account);
        cmdShardAccountInfo.buildFromDb(dbShardAccountInfo);
        Optional<Contact> dbContact = Optional.ofNullable(dbShardAccountInfo.getUserBasicInfo())
                .map(UserBasicInfo::getContact);
        // 更新手机号 只要数据库有值 先删除mobileMapping，入参有值插入
        dbContact.map(Contact::getMobile).ifPresent(dbMob -> mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(tenantId, dbMob));

        dbContact.map(Contact::getEmail).ifPresent(dbEmail -> emailMappingDao.deleteByEmailMapId_TenantIdAndEmailMapId_Email(tenantId, dbEmail));
        //组装accountInfo信息
        account.registration(cmdShardAccountInfo.getRegistration());
        account.setSecurity(cmdShardAccountInfo.getSecurity());
        account.userBasicInfo(cmdShardAccountInfo.getUserBasicInfo());
        account.setOpenUid(cmdShardAccountInfo.getOpenUid());
        account.setAccountStatus(Optional.of(dbShardAccountInfo.getAccountStatus()).orElse(AccountStatus.ACTIVE));
        // 组装attributes
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).ifPresent(attr -> getFinalAttribute(tenantId, accountId, attr));
        // 组装educations
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getEducationList).ifPresent(edu -> getFinalEducation(tenantId, accountId, edu));
        // 组装jobs
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getJobList).ifPresent(job -> getFinalJob(tenantId, accountId, job));
        // 组装humanRelations
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getHumanRelationList).ifPresent(relation -> getFinalHumanRelation(tenantId, accountId, relation));
        getFinalCounter(account);

        return account;
    }


    private void getFinalCounter(Account account) {
        Optional.ofNullable(account.getCounter()).ifPresent(c -> {
            ShardCounter dbCounter = counterDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
            c.buildFromDb(Optional.ofNullable(dbCounter).map(ShardCounter::getCounter).orElse(null));
        });
    }

    private void getFinalAttribute(String tenantId, String accountId, List<ExtraAttributeItem> attrs) {
        ShardExtraAttribute dbExtraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        Optional.ofNullable(dbExtraAttribute).ifPresent(dbAttrs -> dbAttrs.getExtraAttributeItemList()
                .forEach(dbAttr -> attrs
                        .forEach(a -> a.builder(dbAttr))));
    }

    private void getFinalHumanRelation(String tenantId, String accountId, List<HumanRelationItem> humanRelationItems) {
        ShardHumanRelation dbRelation = humanRelationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        Optional.ofNullable(dbRelation).ifPresent(dbRelations -> dbRelations.getHumanRelationList().forEach(dbHuman -> humanRelationItems.forEach(h -> h.builder(dbHuman))));
    }

    private void getFinalJob(String tenantId, String accountId, List<JobItem> jobItems) {
        ShardJob dbJob = jobDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        Optional.ofNullable(dbJob).ifPresent(dbJobs -> dbJobs.getJobList().forEach(job -> jobItems.forEach(j -> j.builder(job))));
    }

    private void getFinalEducation(String tenantId, String accountId, List<EducationItem> educationItems) {
        ShardEducation dbShardEducation = educationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        Optional.ofNullable(dbShardEducation).ifPresent(dbShardEducations -> dbShardEducations.getEducationList().forEach(dbEducation -> educationItems.forEach(e -> e.builder(dbEducation))));
    }

    /**
     * 更新校验
     *
     * @param account account
     * @author LFX
     */
    public void modifyAccountValidate(Account account) {
        isFirstModifyIntegralAddition(account);
    }


    /**
     * 是否首次加积分
     *
     * @param account account
     */
    public void isFirstModifyIntegralAddition(Account account) {
        String result = LocalCacheConfigUtils.getHasFirstModifyAward(account.getTenantId());
        if (StringUtils.isNotBlank(result)) {
            String[] x = result.split(COMMA);
            Stream.of(x).forEach(s -> {
                String[] a = s.split(COLON);
                if (a[0].equals(account.getRegistration().getChannel().getChannelId())) {
                    ShardExtraAttribute shardExtraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
                    if (Optional.ofNullable(shardExtraAttribute).isPresent()) {
                        Optional.ofNullable(shardExtraAttribute.getExtraAttributeItems())
                                .ifPresent(extraAttributeItems -> {
                                    if (extraAttributeItems.stream().noneMatch(extraAttributeItem -> extraAttributeItem.getAttrId().equals(a[1]))) {
                                        this.addFirstModifyCountAttr(account, a[1], "addAward");
                                    }
                                });
                    } else {
                        this.addFirstModifyCountAttr(account, a[1], "addAward");
                    }

                }
            });
        }
    }

    /**
     * 首次添加属性加积分
     *
     * @param attrId  attrId
     * @param attrVal attrVal
     */
    public void addFirstModifyCountAttr(Account account, String attrId, String attrVal) {
        ExtraAttributeItem e = new ExtraAttributeItem();
        e.setAttrId(attrId);
        e.setAttrValue(attrVal);
        UserAdditionalInfo userAdditionalInfo = Optional.ofNullable(account.getUserAdditionalInfo()).orElse(new UserAdditionalInfo());
        List<ExtraAttributeItem> attributeItems = Optional.ofNullable(userAdditionalInfo.getExtraAttributeList()).orElse(new ArrayList<>());
        attributeItems.add(e);
        userAdditionalInfo.setExtraAttributeList(attributeItems);
        account.setUserAdditionalInfo(userAdditionalInfo);
    }

    /**
     * 用户属性信息校验
     *
     * @param account account
     */
    public void attrIdValidate(Account account) {
        if (!Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).filter(attributes -> !attributes.isEmpty()).isPresent()) {
            return;
        }
        List<String> attrIdList = account.getUserAdditionalInfo().getExtraAttributeList().stream().map(ExtraAttributeItem::getAttrId).distinct().collect(Collectors.toList());
        if (account.getUserAdditionalInfo().getExtraAttributeList().size() != attrIdList.size()) {
            throw new BusinessException(PARAMETER_PARSING_ERROR.getCode(), PARAMETER_PARSING_ERROR.getV2Code(), PARAMETER_PARSING_ERROR.getMessage());
        }
        account.getUserAdditionalInfo().getExtraAttributeList().forEach(attributes -> {
            boolean isTrue = false;
            // 获取租户下的所有属性id配置
            String result = Optional.ofNullable(LocalCacheConfigUtils.getAttrId(account.getTenantId())).orElseThrow(() -> new BusinessException(SYSTEM_CONFIG_NOT_EXIST.getCode(), SYSTEM_CONFIG_NOT_EXIST.getV2Code(), SYSTEM_CONFIG_NOT_EXIST.getMessage()));
            String[] x = result.split(COMMA);
            String dataType = null;
            for (String s : x) {
                String[] a = s.split(COLON);
                if (a[0].equals(attributes.getAttrId())) {
                    isTrue = true;
                    String[] b = a[1].split(EQUAL);
                    if (a.length == 2) {
                        dataType = b[0];
                    }
                    // 判断属性的格式是否正确
                    if (!StringValidUtil.validateDataType(dataType, attributes.getAttrValue())) {
                        log.warn("AccountValidator,attrIdValidate(),attr_datatype_invalid,[Redis_datatype,param]:{},{}", dataType, attributes.getAttrValue());
                        throw new BusinessException(INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getCode(), INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getV2Code(), INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getMessage());
                    }
                    if (b.length == 2) {
                        validator(attributes, b[1]);
                    }
                    break;
                }
            }
            if (!isTrue) {
                log.warn("AccountValidator,attrIdValidate(),not_match_true_attr_id,[attr_id]:{}", attributes.getAttrId());
                throw new BusinessException(SYSTEM_CONFIG_NOT_EXIST.getCode(), SYSTEM_CONFIG_NOT_EXIST.getV2Code(), SYSTEM_CONFIG_NOT_EXIST.getMessage());
            }
        });
    }

    /**
     * V3用户属性信息校验
     *
     * @param account account
     */
    public void attrIdValid(Account account) {
        if (!Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).filter(attributes -> !attributes.isEmpty()).isPresent()) {
            return;
        }
        List<String> attrIdList = account.getUserAdditionalInfo().getExtraAttributeList().stream().map(ExtraAttributeItem::getAttrId).distinct().collect(Collectors.toList());
        if (account.getUserAdditionalInfo().getExtraAttributeList().size() != attrIdList.size()) {
            throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        account.getUserAdditionalInfo().getExtraAttributeList().forEach(attributes -> {
            boolean isTrue = false;
            // 获取租户下的所有属性id配置
            String result = Optional.ofNullable(LocalCacheConfigUtils.getAttrId(account.tenantId())).orElseThrow(() -> new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage()));
            String[] x = result.split(COMMA);
            String dataType = null;
            for (String s : x) {
                String[] a = s.split(COLON);
                if (a[0].equals(attributes.getAttrId())) {
                    isTrue = true;
                    String[] b = a[1].split(EQUAL);
                    if (a.length == 2) {
                        dataType = b[0];
                    }
                    // 判断属性的格式是否正确
                    if (!StringValidUtil.validateDataType(dataType, attributes.getAttrValue())) {
                        log.warn("AccountValidator,attrIdValidate(),attr_datatype_invalid,[Redis_datatype,param]:{},{}", dataType, attributes.getAttrValue());
                        throw new BusinessException(V3ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getCode(), V3ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getMessage(), V3ResultEnum.INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT.getFrontMessage());
                    }
                    if (b.length == 2) {
                        v3Validator(attributes, b[1]);
                    }
                    break;
                }
            }
            if (!isTrue) {
                log.warn("AccountValidator,attrIdValidate(),not_match_true_attr_id,[attr_id]:{}", attributes.getAttrId());
                throw new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage());
            }
        });
    }

    /**
     * 校验属性
     *
     * @param attributes 属性参数
     * @param classPath  类路径
     * @date 2022/2/28 14:49
     */
    private void v3Validator(ExtraAttributeItem attributes, String classPath) {
        String validatorPath;
        validatorPath = PATH + classPath.substring(classPath.lastIndexOf('.') + 1);
        Class<?> cls;
        try {
            cls = Class.forName(validatorPath);
            Object json = SpringContextUtil.getApplicationContext().getBean(cls).getClass().getDeclaredMethod(VALIDATOR, ExtraAttributeItem.class).invoke(SpringContextUtil.getApplicationContext().getBean(cls), attributes);
            attributes.setAttrValue(String.valueOf(json));
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException e) {
            log.error("Exception", e);
            throw new BusinessException(V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getCode(), V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getMessage(), V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getFrontMessage());
        } catch (InvocationTargetException e) {
            log.error("InvocationTargetException:", e);
            Throwable cause = e.getCause();
            if (cause instanceof BusinessException) {
                throw new BusinessException(((BusinessException) cause).getCode(), cause.getMessage(), ((BusinessException) cause).getFrontMessage());
            } else {
                throw new BusinessException(V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getCode(), V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getMessage(), V3ResultEnum.CUSTOMIZED_VALIDATOR_ERROR.getFrontMessage());
            }
        }
    }

    /**
     * 校验属性
     *
     * @param attributes 属性参数
     * @param classPath  类路径
     * @author xusheng
     * @date 2021/5/8 11:14
     */
    private void validator(ExtraAttributeItem attributes, String classPath) {
        String validatorPath;
        validatorPath = PATH + classPath.substring(classPath.lastIndexOf('.') + 1);
        Class<?> cls;
        try {
            cls = Class.forName(validatorPath);
            Object json = SpringContextUtil.getApplicationContext().getBean(cls).getClass().getDeclaredMethod(VALIDATOR, ExtraAttributeItem.class).invoke(SpringContextUtil.getApplicationContext().getBean(cls), attributes);
            attributes.setAttrValue(String.valueOf(json));
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException e) {
            log.error("Exception", e);
            throw new BusinessException(CUSTOMIZED_VALIDATOR_ERROR.getCode(), CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), CUSTOMIZED_VALIDATOR_ERROR.getMessage());
        } catch (InvocationTargetException e) {
            log.error("InvocationTargetException:", e);
            Throwable cause = e.getCause();
            if (cause instanceof BusinessException) {
                throw new BusinessException(((BusinessException) cause).getCode(), ((BusinessException) cause).getV2Code(), cause.getMessage());
            } else {
                throw new BusinessException(CUSTOMIZED_VALIDATOR_ERROR.getCode(), CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), CUSTOMIZED_VALIDATOR_ERROR.getMessage());
            }
        }
    }

    /**
     * 用户属性信息校验
     *
     * @param account account
     * @return List<PointDTO>
     */
    public List<PointDTO> runCustomEvent(Account account) {
        List<ExtraAttributeItem> extraAttributeItemList = Optional.ofNullable(account)
                .map(Account::getUserAdditionalInfo)
                .map(UserAdditionalInfo::getExtraAttributeList)
                .orElse(null);
        if (!Optional.ofNullable(extraAttributeItemList).isPresent()) {
            return Collections.emptyList();
        }
        List<PointDTO> pointDTOList = new ArrayList<>();
        for (ExtraAttributeItem extraAttributeItem : extraAttributeItemList) {
            String result = LocalCacheConfigUtils.getAttrId(account.getTenantId());
            if (StringUtils.isBlank(result)) {
                throw new BusinessException(SYSTEM_CONFIG_NOT_EXIST.getCode(), SYSTEM_CONFIG_NOT_EXIST.getV2Code(), SYSTEM_CONFIG_NOT_EXIST.getMessage());
            }
            String[] x = result.split(COMMA);
            for (String s : x) {
                String[] a = s.split(COLON);
                if (a[0].equals(extraAttributeItem.getAttrId())) {
                    String[] b = a[1].split(EQUAL);
                    if (b.length == 2) {
                        runEvent(account, pointDTOList, extraAttributeItem, b);
                    }
                    break;
                }
            }
        }
        return pointDTOList;
    }

    /**
     * 执行定制化事件
     *
     * @param account            入参
     * @param pointDTOList       积分信息
     * @param extraAttributeItem 属性信息
     * @param classPath          类路径
     * @author xusheng
     * @date 2021/5/8 11:21
     */
    private void runEvent(Account account, List<PointDTO> pointDTOList, ExtraAttributeItem extraAttributeItem, String[] classPath) {
        String validatorPath;
        validatorPath = PATH + classPath[1].substring(classPath[1].lastIndexOf('.') + 1);
        Class<?> cls;
        try {
            cls = Class.forName(validatorPath);
            Object object = SpringContextUtil.getApplicationContext().getBean(cls).getClass().getDeclaredMethod(RUN_EVENT, Account.class, String.class).invoke(SpringContextUtil.getApplicationContext().getBean(cls), account, extraAttributeItem.getAttrId());
            if (null != object) {
                pointDTOList.add((PointDTO) object);
            }
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException e) {
            log.error("ClassNotFoundException", e);
            throw new BusinessException(CUSTOMIZED_VALIDATOR_ERROR.getCode(), CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), CUSTOMIZED_VALIDATOR_ERROR.getMessage());
        } catch (InvocationTargetException e) {
            log.error("InvocationTargetException:", e);
            Throwable cause = e.getCause();
            if (cause instanceof BusinessException) {
                throw new BusinessException(((BusinessException) cause).getCode(), ((BusinessException) cause).getV2Code(), cause.getMessage());
            } else {
                throw new BusinessException(CUSTOMIZED_VALIDATOR_ERROR.getCode(), CUSTOMIZED_VALIDATOR_ERROR.getV2Code(), CUSTOMIZED_VALIDATOR_ERROR.getMessage());
            }
        }
    }

    public void modifyMobileMapping(Account account) {
        Account dbAccount = accountRepository.fetchAccountByTenantIdAndAccountId(account.getTenantId(), account.getAccountId());
        if (Optional.ofNullable(account.getMobile()).isPresent() && !account.getMobile().equals(dbAccount.getMobile())) {
            //需要修改mobileMapping
            Optional.ofNullable(dbAccount.getMobile()).ifPresent(mobile -> {
                mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(account.getTenantId(), mobile);
            });
            MobileMapping mobileMapping = new MobileMapping();
            mobileMapping.build(account);
            mobileMappingDao.save(mobileMapping);
        }
    }

    /**
     * 组合account并校验
     *
     * @param account account
     * @return account
     */
    public Account accountValidate(Account account) {
        //进行序列校验
        sequenceUniqueValidate(account.getUserAdditionalInfo());
        // 進行屬性和首次加積分校驗
//        this.modifyAccountValidate(account);
        this.attrIdValid(account);
        //组装好聚合根
        String tenantId = account.tenantId();
        String accountId = account.accountId();
        ShardAccountInfo dbShardAccountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId))
                .orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
        ShardAccountInfo cmdShardAccountInfo = new ShardAccountInfo();
        cmdShardAccountInfo.build(account);
        cmdShardAccountInfo.buildFromDb(dbShardAccountInfo);
        Optional<Contact> dbContact = Optional.ofNullable(dbShardAccountInfo.getUserBasicInfo())
                .map(UserBasicInfo::getContact);
        // 更新手机号 只要数据库有值 先删除mobileMapping，入参有值插入
        dbContact.map(Contact::getMobile).ifPresent(dbMob -> mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(tenantId, dbMob));

        dbContact.map(Contact::getEmail).ifPresent(dbEmail -> emailMappingDao.deleteByEmailMapId_TenantIdAndEmailMapId_Email(tenantId, dbEmail));
        //组装accountInfo信息
        account.registration(cmdShardAccountInfo.getRegistration());
        account.setSecurity(cmdShardAccountInfo.getSecurity());
        account.userBasicInfo(cmdShardAccountInfo.getUserBasicInfo());
        account.setOpenUid(cmdShardAccountInfo.getOpenUid());
        account.setAccountStatus(Optional.ofNullable(dbShardAccountInfo.getAccountStatus()).orElse(AccountStatus.ACTIVE));
        // 组装attributes
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).ifPresent(attr -> getFinalAttribute(tenantId, accountId, attr));
        // 组装educations
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getEducationList).ifPresent(edu -> getFinalEducation(tenantId, accountId, edu));
        // 组装jobs
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getJobList).ifPresent(job -> getFinalJob(tenantId, accountId, job));
        // 组装humanRelations
        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getHumanRelationList).ifPresent(relation -> getFinalHumanRelation(tenantId, accountId, relation));
        getFinalCounter(account);

        return account;
    }

    /**
     * 更新会员信息
     *
     * @param account account
     * @author xusheng
     * @date 2021/6/9 9:39
     */
    public void saveDevice(Account account) {
        if (Optional.ofNullable(account).isPresent()) {
            //判断是否传入device信息
            Optional.ofNullable(account.getUserAdditionalInfo())
                    .map(UserAdditionalInfo::getDevice)
                    .ifPresent(deviceInfo -> {
                        ShardDevice shardDevice = deviceDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.tenantId(), account.accountId());
                        if (Optional.ofNullable(shardDevice).isPresent()) {
                            deviceInfo.builder(shardDevice.getDevice());
                            shardDevice.setDevice(deviceInfo);
                            shardDevice.addUpdatedTime();
                        } else {
                            shardDevice = new ShardDevice();
                            shardDevice.build(account);
                        }
                        deviceDao.save(shardDevice);
                    });
        }
    }
}
