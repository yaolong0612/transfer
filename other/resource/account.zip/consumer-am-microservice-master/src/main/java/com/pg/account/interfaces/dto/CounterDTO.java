package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 柜台类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "CounterDTO_V1")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterDTO implements Serializable {

    private static final long serialVersionUID = -2542557208990765038L;
    @ApiModelProperty(value = "Registration counter number", name = "regCounterCode", example = "A-FJ-XM-0592-CT007")
    private String regCounterCode;
    @ApiModelProperty(value = "Registration counter name", name = "regCounterName", example = "小李百货")
    private String regCounterName;
    @ApiModelProperty(value = "Center counter number", name = "mainCounterCode", example = "A-FJ-XM-0592-CT007")
    private String mainCounterCode;
    @ApiModelProperty(value = "Center counter name", name = "mainCounterName", example = "小李百货")
    private String mainCounterName;
    @ApiModelProperty(value = "Exchange counter number", name = "pickupCounterCode", example = "A-FJ-XM-0592-CT007")
    private String pickupCounterCode;
    @ApiModelProperty(value = "Exchange counter name", name = "pickupCounterName", example = "小李百货")
    private String pickupCounterName;
    @ApiModelProperty(value = "Offline first purchase counter number", name = "offlineFirstPurchaseCounterCode", example = "A-FJ-XM-0592-CT007")
    private String offlineFirstPurchaseCounterCode;
    @ApiModelProperty(value = "Name of offline first purchase counter", name = "offlineFirstPurchaseCounterName", example = "小李百货")
    private String offlineFirstPurchaseCounterName;
    @ApiModelProperty(value = "First purchase counter number", name = "firstPurchaseCounterCode", example = "A-FJ-XM-0592-CT007")
    private String firstPurchaseCounterCode;
    @ApiModelProperty(value = "First purchase time", name = "firstPurchaseTime", example = "2019-11-11 11:11:11")
    private String firstPurchaseTime;
    @ApiModelProperty(value = "CRM exchange counter number", name = "crmPickupCounterCode", example = "A-FJ-XM-0592-CT007")
    private String crmPickupCounterCode;
}
