package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccountRegisterBindCommand implements Serializable {
    private static final long serialVersionUID = -5078557977842197894L;
    @ApiModelProperty(value = "租户ID，需要申请配置", example = "10003", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    public Long tenantId;
    @ApiModelProperty(value = "渠道ID，需要申请配置", example = "20", required = true)
    @NotNull(message = "channel is not exist")
    public Long channelId;
    @ApiModelProperty(value = "用户名（手机号码）", example = "13062661723", required = true)
    @NotBlank(message = "missing username")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String username;
    @ApiModelProperty(value = "密码", example = "123456", required = true)
    @NotBlank(message = "missing password")
    @Length(min = 6, message = "password length less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String password;
    @ApiModelProperty(value = "注册来源，需要申请配置", example = "OTT", required = true)
    @NotBlank(message = "missing source")
    private String source;
    @ApiModelProperty(value = "注册店铺", example = "SMART")
    private String regStore;
    @ApiModelProperty(value = "顾客,和AM对接时申请", example = "PG")
    private String customer;
    @ApiModelProperty(value = "用户信息")
    @Valid
    private ProfileCommand profile;
    @ApiModelProperty(value = "设备信息")
    private DeviceCommand device;
    @ApiModelProperty(value = "柜台信息")
    private CounterCommand counter;
    @ApiModelProperty(value = "地址信息集合")
    @Valid
    @Size(max = 1, message = "地址信息只能添加一条")
    private List<AddressCommand> addresses;
    @ApiModelProperty(value = "订阅信息集合")
    @Valid
    private List<SubscriptionCommand> subscriptions;
    @ApiModelProperty(value = "用户属性信息集合")
    @Valid
    private List<AttrCommand> attrs;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "W0yJ_wVRj7AAz6-AzY")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    /**
     * 判断是否加积分，为空加积分，为Y加积分，为N不加积分
     */
    @ApiModelProperty(value = "是否需要加积分", example = "Y")
    private String isAward;
    @ApiModelProperty(value = "注册的路由规则,手机号Mobile=M,邮箱Email=E,第三方账号BindID=B,第三方账号UnionID=U", example = "M")
    private String registerRoute;

    public String gotFullName() {
        if (null != this.addresses && !this.addresses.isEmpty()) {
            return this.addresses.get(0).getFullName();
        }
        return null;
    }

    public String gotBirthday() {
        if (null != this.profile) {
            return this.profile.getBirthday();
        }
        return null;
    }

    /**
     * 判断地址是否传入手机号，如果没传入手机号则将username赋值给手机号
     */
    public void specifyAddressCellphone() {
        Optional.ofNullable(this.addresses).filter(addr -> !addr.isEmpty()).ifPresent(a -> a.get(0).setCellphone(this.username));
    }
}
