package com.pg.account.sharding.application.cmdservice.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.interfaces.command.SubscriptionCommand;
import com.pg.account.sharding.application.cmdservice.ShardAccountV3Service;
import com.pg.account.sharding.application.cmdservice.SolveConflictService;
import com.pg.account.sharding.application.cmdservice.UnbindService;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import com.pg.account.sharding.interfaces.command.AccountConflictCommand;
import com.pg.account.sharding.interfaces.command.SignUpCommand;
import com.pg.account.sharding.interfaces.dto.KeepRuleEnum;
import com.pg.account.sharding.interfaces.dto.QueryAccountConflictDTO;
import com.pg.account.sharding.interfaces.dto.assembler.AccountAssembler;
import com.pg.account.sharding.interfaces.dto.assembler.SocialAccountAssembler;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.pg.account.sharding.domain.service.StringValidator.channelValid;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.*;
import static com.pg.account.sharding.interfaces.dto.KeepRuleEnum.BIND_ID;
import static com.pg.account.sharding.interfaces.dto.KeepRuleEnum.MOBILE;
import static com.pg.account.sharding.interfaces.dto.KeepRuleEnum.UNION_ID;

/**
 * @author lfx
 * @date 2022/1/13 17:37
 */
@Service
public class SolveConflictServiceImpl implements SolveConflictService {

    public static final String COMMA = ",";
    public static final String KEEP_RULE = "keepRule";
    public static final int HAS_NO_ACCOUNT = 2;
    private final UnbindService unbindService;
    private final ShardAccountV3Service shardAccountV3Service;
    private final AccountAssembler accountAssembler;
    private final SocialAccountAssembler socialAccountAssembler;

    String keepRule = MOBILE.getMsg();


    @Autowired
    public SolveConflictServiceImpl(UnbindService unbindService, ShardAccountV3Service shardAccountV3Service, AccountAssembler accountAssembler, SocialAccountAssembler socialAccountAssembler) {
        this.unbindService = unbindService;
        this.shardAccountV3Service = shardAccountV3Service;
        this.accountAssembler = accountAssembler;
        this.socialAccountAssembler = socialAccountAssembler;
    }

    /**
     * 解决冲突
     *
     * @param signUpCommand signUpCommand
     * @return JSONObject
     */
    @Override
    @Retryable(value = OptimisticLockingFailureException.class, maxAttempts = 3, backoff = @Backoff(delay = 100L, multiplier = 1.5))
    public JSONObject solveConflict(SignUpCommand signUpCommand) {
        channelValid(signUpCommand.getTenant(), signUpCommand.getChannel());
        String unionType = checkIsUnionType(signUpCommand.getTenant(), signUpCommand.getChannel(), signUpCommand.getUnionId());
        // 通过入参查询账号
        JSONObject result = shardAccountV3Service.getConflictResult(signUpCommand.getTenant(), signUpCommand.getChannel(), new AccountConflictCommand(signUpCommand.getMobile(), signUpCommand.getBindId(), signUpCommand.getUnionId()));
        JSONArray objects = result.getJSONArray(ACCOUNTS);
        QueryAccountConflictDTO queryAccountConflictDTO = result.getObject(QUERY_ACCOUNT_CONFLICT_DTO, QueryAccountConflictDTO.class);
        checkIsSameAccount(objects);
        JSONObject jsonObject = null;
        boolean conflictLock = RedisConfigUtils.getIfPresent(String.valueOf(signUpCommand.hashCode()));
        if (queryAccountConflictDTO.getExistConflict() == 1) {
            conflictLock = RedisConfigUtils.setIfAbsent(String.valueOf(signUpCommand.hashCode()), signUpCommand.toString(), 60);
        }
        // 1. 存在锁，且存在冲突 走解决冲突整个流程 2. 存在所 不存在冲突走入会流程 3. 不存在锁，存在冲突走解决冲突流程 4. 不存在冲突 也不存在锁 直接报 不存在冲突，
        if (conflictLock && queryAccountConflictDTO.getExistConflict() == 1) {
            jsonObject = solve(signUpCommand, unionType, objects, queryAccountConflictDTO);
        } else if (conflictLock && queryAccountConflictDTO.getExistConflict() == 0) {
            jsonObject = signup(signUpCommand);
        } else if (!conflictLock && queryAccountConflictDTO.getExistConflict() == 1) {
            jsonObject = solve(signUpCommand, unionType, objects, queryAccountConflictDTO);
        } else if (!conflictLock && queryAccountConflictDTO.getExistConflict() == 0) {
            throw new BusinessException(V3ResultEnum.ACCOUNT_NOT_CONFLICT.getCode(), V3ResultEnum.ACCOUNT_NOT_CONFLICT.getMessage(), V3ResultEnum.ACCOUNT_NOT_CONFLICT.getFrontMessage());
        }
        return jsonObject;
    }

    /**
     * 解决冲突+入会
     *
     * @param signUpCommand           signUpCommand
     * @param unionType               unionType
     * @param objects                 objects
     * @param queryAccountConflictDTO queryAccountConflictDTO
     * @return
     */
    private JSONObject solve(SignUpCommand signUpCommand, String unionType, JSONArray objects, QueryAccountConflictDTO queryAccountConflictDTO) {
        // 筛选出通过手机号查询到的信息JSON
        JSONObject mobileJson = objects.stream().filter(switchWithType(MOBILE)).map(JSONObject.class::cast).findFirst().orElse(null);
        // 筛选出通过unionId查询到的信息JSON
        JSONObject unionIdJson = objects.stream().filter(switchWithType(UNION_ID)).map(JSONObject.class::cast).findFirst().orElse(null);
        // 筛选出通过bindId查询到的信息JSON
        JSONObject bindIdJson = objects.stream().filter(switchWithType(BIND_ID)).map(JSONObject.class::cast).findFirst().orElse(null);
        if (queryAccountConflictDTO.getExistMobile() == 1) {
            solveConflictByMobile(signUpCommand, unionType, mobileJson, unionIdJson, bindIdJson);
            // 将入参的bindId和unionId进行组合绑定到当前账号
        } else if (queryAccountConflictDTO.getExistUnionId() == 1) {
            solveConflictByUnionId(signUpCommand, unionType, unionIdJson, bindIdJson);
            // 将入参的bindId绑定到该账号下
        } else if (queryAccountConflictDTO.getExistBindId() == 1) {
            solveConflictByBindId(signUpCommand, unionType, bindIdJson);
        }
        return signup(signUpCommand);
    }

    /**
     * 入会
     *
     * @param signUpCommand signUpCommand
     * @return
     */
    private JSONObject signup(SignUpCommand signUpCommand) {
        Account account = accountAssembler.formSignUpCommand(signUpCommand);
        ShardSocialAccount shardSocialAccount = socialAccountAssembler.toShardSocialAccount(signUpCommand.getTenant(), signUpCommand.getChannel(), null,
                signUpCommand.getBindId(), signUpCommand.getUnionId(), signUpCommand.getCustomer(), signUpCommand.getRegSource(), signUpCommand.getRegStore());
        JSONObject jsonObject = shardAccountV3Service.signUp(account, shardSocialAccount, toShardSubscription(signUpCommand.getTenant(), signUpCommand.getChannel(), null, null));
        jsonObject.remove(NEW_MEMBER);
        jsonObject.put(KEEP_RULE, keepRule);
        RedisConfigUtils.clearProfileCache(signUpCommand.getTenant(), jsonObject.getString(ACCOUNT_ID));
        return jsonObject;
    }

    /**
     * 检查是否是统一账号
     *
     * @param jsonArray jsonArray
     */
    private void checkIsSameAccount(JSONArray jsonArray) {
        // 如果jsonArray 不存在（不太可能看看要不要删除）或者 jsonArray的每个item的size都为2的时候（代表所有参数都没有查到账号）
        if (!Optional.ofNullable(jsonArray).isPresent() || jsonArray.stream().map(JSONObject.class::cast).allMatch(s -> s.size() == HAS_NO_ACCOUNT)) {
            throw new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage());
        }
    }

    /**
     * 按照bindid规则处理
     *
     * @param signUpCommand signUpCommand
     * @param unionType     unionType
     * @param bindIdJson    bindIdJson
     */
    private void solveConflictByBindId(SignUpCommand signUpCommand, String unionType, JSONObject bindIdJson) {
        keepRule = BIND_ID.getMsg();
        // 如果入参unionId 和 账号下unionId 的不一致 替换当前unionType的所有unionId
        Optional.ofNullable(bindIdJson).ifPresent(b -> {
            Optional.ofNullable(bindIdJson.getObject(ACCOUNT, Account.class)).map(Account::getMobile).ifPresent(signUpCommand::setMobile);
            ShardSocialAccount bind = Optional.ofNullable(b.getObject(SOCIAL_ACCOUNT, ShardSocialAccount.class)).filter(a -> Optional.ofNullable(a.getSocialAccountList()).isPresent() && !a.getSocialAccountList().isEmpty()).orElse(null);
            if (Optional.ofNullable(bind).isPresent() && Optional.ofNullable(signUpCommand.getUnionId()).isPresent() && !signUpCommand.getUnionId().equals(bind.getSocialAccountList().stream().filter(a -> a.getUnionType().equals(unionType)).map(SocialAccountItem::getUnionId).findFirst().orElse(null))) {
                unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), bind.accountId(), BY_UNION_TYPE);
            }
        });
    }

    /**
     * 根据unionId规则解决冲突
     *
     * @param signUpCommand signUpCommand
     * @param unionType     unionType
     * @param unionIdJson   unionIdJson
     * @param bindIdJson    bindIdJson
     */
    private void solveConflictByUnionId(SignUpCommand signUpCommand, String unionType, JSONObject unionIdJson, JSONObject bindIdJson) {
        keepRule = UNION_ID.getMsg();
        // 如果入参的bindId 和该账号的bindId不一致则 解绑 该账号当前渠道的bindId 和入参账号的bindId
        Optional.ofNullable(unionIdJson).ifPresent(u -> {
            Optional.ofNullable(unionIdJson.getObject(ACCOUNT, Account.class)).map(Account::getMobile).ifPresent(signUpCommand::setMobile);
            ShardSocialAccount unionBind = Optional.ofNullable(u.getObject(SOCIAL_ACCOUNT, ShardSocialAccount.class)).filter(a -> Optional.ofNullable(a.getSocialAccountList()).isPresent() && !a.getSocialAccountList().isEmpty()).orElse(null);
            if (Optional.ofNullable(unionBind).isPresent() && Optional.ofNullable(signUpCommand.getBindId()).isPresent() && !signUpCommand.getBindId().equals(unionBind.getSocialAccountList().stream().filter(a -> a.getChannelId().equals(signUpCommand.getChannel())).map(a -> Optional.ofNullable(a.getBindId()).orElse("")).findFirst().orElse(null))) {
                unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), unionBind.accountId(), BY_CHANNEL);
            }
            Optional.ofNullable(bindIdJson).ifPresent(b -> {
                if (Optional.ofNullable(bindIdJson.getString(ACCOUNT_ID)).isPresent() && !unionIdJson.getString(ACCOUNT_ID).equals(bindIdJson.getString(ACCOUNT_ID))) {
                    unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), b.getString(ACCOUNT_ID), Optional.ofNullable(unionType).isPresent() ? BY_UNION_TYPE : BY_CHANNEL);
                }
            });
        });
    }

    /**
     * 按照手机号规则进行处理冲突
     *
     * @param signUpCommand signUpCommand
     * @param unionType     unionType
     * @param mobileJson    mobileJson
     * @param unionIdJson   unionIdJson
     * @param bindIdJson    bindIdJson
     */
    private void solveConflictByMobile(SignUpCommand signUpCommand, String unionType, JSONObject mobileJson, JSONObject unionIdJson, JSONObject bindIdJson) {
        keepRule = MOBILE.getMsg();
        Optional.ofNullable(mobileJson).ifPresent(json -> unbindSelf(signUpCommand, unionType, mobileJson));
        Optional.ofNullable(unionIdJson).ifPresent(u -> Optional.ofNullable(mobileJson).ifPresent(m -> {
            if (Optional.ofNullable(unionIdJson.getString(ACCOUNT_ID)).isPresent() && !m.getString(ACCOUNT_ID).equals(unionIdJson.getString(ACCOUNT_ID))) {
                unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), u.getString(ACCOUNT_ID), Optional.ofNullable(unionType).isPresent() ? BY_UNION_TYPE : BY_CHANNEL);
            }
        }));
        Optional.ofNullable(bindIdJson).ifPresent(b -> Optional.ofNullable(mobileJson).ifPresent(m -> {
            if (Optional.ofNullable(bindIdJson.getString(ACCOUNT_ID)).isPresent() && !m.getString(ACCOUNT_ID).equals(bindIdJson.getString(ACCOUNT_ID))) {
                unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), b.getString(ACCOUNT_ID), Optional.ofNullable(unionType).isPresent() ? BY_UNION_TYPE : BY_CHANNEL);
            }
        }));
//                将其他的号有如果unionType 根据unionTye解绑 没有则根据channelId解绑
    }

    /**
     * 判断账号是否存在冲突
     *
     * @param signUpCommand signUpCommand
     * @param unionType     unionType
     * @param mobileJson    mobileJson
     */
    private void unbindSelf(SignUpCommand signUpCommand, String unionType, JSONObject mobileJson) {
        ShardSocialAccount mobileBind = Optional.ofNullable(mobileJson.getObject(SOCIAL_ACCOUNT, ShardSocialAccount.class)).filter(a -> Optional.ofNullable(a.getSocialAccountList()).isPresent() && !a.getSocialAccountList().isEmpty()).orElse(null);
        if (Optional.ofNullable(mobileBind).isPresent()) {
            // 如果入参unionId 和 mobileBind中的不一致 ，进行根据unionType解绑
            String optionBindId = mobileBind.getSocialAccountList().stream().filter(a -> signUpCommand.getChannel().equals(a.getChannelId())).map(a -> Optional.ofNullable(a.getBindId()).orElse("")).findFirst().orElse(null);
            if (Optional.ofNullable(unionType).isPresent()) {
                String optionUnionId = mobileBind.getSocialAccountList().stream().filter(a -> unionType.equals(a.getUnionType())).map(a -> Optional.ofNullable(a.getUnionId()).orElse("")).findFirst().orElse(null);
                if (Optional.ofNullable(optionUnionId).isPresent() && !optionUnionId.equals(signUpCommand.getUnionId())) {
                    unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), mobileBind.accountId(), BY_UNION_TYPE);
                } else if (StringUtils.isNotBlank(optionBindId) && Optional.ofNullable(signUpCommand.getBindId()).isPresent() && !optionBindId.equals(signUpCommand.getBindId())) {
                    unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), mobileBind.accountId(), BY_CHANNEL);
                }
            } else {
                // 如果入参bindId 和 mobileBind中的不一致 ，进行根据channelId解绑
                if (StringUtils.isNotBlank(optionBindId) && Optional.ofNullable(signUpCommand.getBindId()).isPresent() && !optionBindId.equals(signUpCommand.getBindId())) {
                    unbindService.unBind(signUpCommand.getTenant(), signUpCommand.getChannel(), mobileBind.accountId(), BY_CHANNEL);
                }
            }
        }
    }

    /**
     * 检查是否是unionType类型的channel
     *
     * @param tenant  tenant
     * @param channel channel
     * @return 是否属于需要传unionTYpe的channel 如果该channel没有unionType传了unionId则报错
     */
    private String checkIsUnionType(String tenant, String channel, String unionId) {
        // 查询unionType是否存在
        String unionType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel)).orElse(null);
        // 如果unionType不存在, unionId存在 则报错，否则返回具体的unionType
        if (!Optional.ofNullable(unionType).isPresent() && Optional.ofNullable(unionId).isPresent()) {
            throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        } else {
            return unionType;
        }
    }


    /**
     * 将SubscriptionCommand转入订阅聚合根
     *
     * @param tenantId                tenantId
     * @param channelId               channelId
     * @param subscriptionCommandList subscriptionCommandList
     */
    public ShardSubscription toShardSubscription(String tenantId, String channelId, String accountId, List<SubscriptionCommand> subscriptionCommandList) {
        String result = LocalCacheConfigUtils.getChannelId(tenantId);
        String[] x = result.split(COMMA);
        boolean flag = Arrays.asList(x).contains(channelId);
        if (!flag) {
            throw new BusinessException(V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getFrontMessage());
        }
        ShardSubscription.ShardSubscriptionBuilder shardSubscriptionBuilder = ShardSubscription.ShardSubscriptionBuilder
                .aShardSubscription()
                .tenantId(tenantId)
                .accountId(accountId);
        List<SubscriptionItem> subscriptionItems = new ArrayList<>();
        if (Optional.ofNullable(subscriptionCommandList)
                .filter(subscriptionCommands -> !subscriptionCommands.isEmpty())
                .isPresent()) {
            subscriptionCommandList.forEach(subscriptionCommand -> {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(subscriptionCommand.getOptId(), null, subscriptionCommand.getOptStatus(), null);
                subscriptionItem.setChannelId(channelId);
                subscriptionItems.add(subscriptionItem);
            });
        } else {
            SubscriptionItem subscriptionItem = new SubscriptionItem();
            subscriptionItem.setChannelId(channelId);
            subscriptionItems.add(subscriptionItem);
        }
        return shardSubscriptionBuilder.subscriptionList(subscriptionItems).build();
    }

    /**
     * 通过类型 筛选
     *
     * @param ruleEnum ruleEnum
     * @return Predicate<Object>
     */
    private <T> Predicate<T> switchWithType(KeepRuleEnum ruleEnum) {
        return i -> {
            JSONObject jsonObject = (JSONObject) i;
            return ruleEnum.getMsg().equals(jsonObject.getString(TYPE));
        };
    }
}
