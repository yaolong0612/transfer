package com.pg.account.sharding.domain.service;


import org.springframework.stereotype.Service;

/**
 * @author Jack
 * @description
 * @date 2021/6/2 22:59
 * @modified Jack
 */
@Service
public interface AddAwardWrapperService {

    /**
     * 首次添加商品加积分
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     * @param attrId    attrId
     * @param attrValue attrValue
     */
    void addFirstSaveGoodsPoints(String tenantId, String channelId, String accountId);

    /**
     * 首次修改加积分
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     */
    void addFirstModifyPoints(String tenantId, String channelId, String memberId);
}