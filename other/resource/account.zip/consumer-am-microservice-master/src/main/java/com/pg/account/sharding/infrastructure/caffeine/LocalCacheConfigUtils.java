package com.pg.account.sharding.infrastructure.caffeine;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.benmanes.caffeine.cache.Cache;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;


/**
 * @author leiyingbin
 */
@Component
@Slf4j
public class LocalCacheConfigUtils {

    private static Cache<String, Object> caffeineCache;

    @Autowired
    public LocalCacheConfigUtils(Cache<String, Object> caffeineCache) {
        LocalCacheConfigUtils.caffeineCache = caffeineCache;
    }

    /**
     * 获取tenantId
     *
     * @param tenantId 租戶Id
     * @return 配置
     */
    public static String getTenant(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getTenantId";

        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getTenant(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取MarketingProgramId
     *
     * @param tenantId 租戶Id
     * @return 配置
     */
    public static Integer getMarketingProgramId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getMarketingProgramId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return Integer.parseInt(String.valueOf(object));
        }
        int value = RedisConfigUtils.getMarketingProgramId(tenantId);
        if (value != 0) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取TenantId
     *
     * @param marketingProgramId 营销计划Id
     * @return 配置
     */
    public static String getTenantIdByMarketingProgramId(int marketingProgramId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + marketingProgramId + KEY_DELIMITER + "getTenantIdByMarketingProgramId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getTenantIdByMarketingProgramId(marketingProgramId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道Id
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getChannelId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getChannelId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannelId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getChannel(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getChannel";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannel(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道订阅ID
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getChannelOptId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getChannelOptId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannelOptId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 根据Channel获取OptId
     *
     * @param tenantId  租户
     * @param channelId 渠道
     * @return optId
     */
    public static String getOptIdByChannel(String tenantId, String channelId) {
        String optId = null;
        String optIds = getChannelOptId(tenantId);
        if (StringUtils.isNotBlank(optIds)) {
            String[] br = optIds.split(COMMA);
            for (String s : br) {
                String[] optIdArray = s.split(COLON);
                if (optIdArray[0].equals(String.valueOf(channelId))) {
                    optId = optIdArray[1];
                }
            }
        }
        return optId;
    }

    /**
     * 获取绑定渠道配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getHasBindId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getHasBindId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getHasBindId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }


    /**
     * 获取unionId绑定渠道配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getHasUnionId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getHasUnionId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getHasUnionId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取首次修改送奖励的配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getHasFirstModifyAward(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getHasFirstModifyAward";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getHasFirstModifyAward(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取unionId type配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getChannelUnionIdType(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getChannelUnionIDType";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannelUnionIdType(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道迁移状态配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getChannelMigrationStatus(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getChannelMigrationStatus";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannelMigrationStatus(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道订阅条款配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getInitialOptions(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getTermsId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getInitialOptions(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取条款ID
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return Long
     */
    public static Long getTermsId(String tenantId, String channelId, String optId) {
        String options = getInitialOptions(tenantId, channelId);
        JSONArray jsonArray = parseArray(options);
        for (Object o : jsonArray) {
            JSONObject jsonObject = (JSONObject) o;
            if (jsonObject.containsKey(CHANNEL_ID)
                    && channelId.equals(jsonObject.getString(CHANNEL_ID))
                    && jsonObject.containsKey(RedisConfigUtils.TERMS_ID)
                    && jsonObject.containsKey(RedisConfigUtils.OPT_ID)
                    && optId.equals(jsonObject.getString(RedisConfigUtils.OPT_ID))) {
                return jsonObject.getLong(RedisConfigUtils.TERMS_ID);
            }
        }
        return null;
    }

    /**
     * 获取当前渠道的初始化订阅信息
     *
     * @param tenantId  租户ID
     * @param channelId 渠道ID
     * @return String
     */
    public static String getInitialOption(String tenantId, String channelId) {
        String options = getInitialOptions(tenantId, channelId);
        if (StringUtils.isBlank(options)) {
            throw new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage());
        }
        JSONArray jsonArray = parseArray(options);
        JSONArray array = new JSONArray();
        for (Object o : jsonArray) {
            JSONObject jsonObject = (JSONObject) o;
            if (jsonObject.containsKey(CHANNEL_ID) && channelId.equals(jsonObject.getString(CHANNEL_ID))) {
                array.add(jsonObject);
            }
        }
        return array.toJSONString();
    }

    /**
     * 获取注册来源配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getRegisterSource(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getRegisterSource";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getRegisterSource(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取用户属性Id配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getAttrId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getAttId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAttrId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取人际关系配置
     * key的设计：5_10011_EDUCATION_RELATIONSHIP_ID_RULE
     *
     * @param tenantId 租户
     * @return java.lang.String
     * @author xusheng
     * @date 2020/9/15 13:55
     */
    public static String getRelationShipId(String tenantId, String tableName) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + tableName + KEY_DELIMITER + "RELATIONSHIP_ID_RULE";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getRelationShipId(tenantId, tableName);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取relationShipId对应描述
     * key的设计：5_10011_101_getRelationshipName
     *
     * @param tenantId 租户
     * @return java.lang.String
     * @author xusheng
     * @date 2020/9/16 13:55
     */
    public static String getRelationShipName(String tenantId, String relationShipId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + relationShipId + KEY_DELIMITER + "getRelationshipName";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getRelationShipName(tenantId, relationShipId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取唯一注册类型配置
     *
     * @param tenantId 租户
     * @return String
     */
    public static String getUniqueRegistrationType(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getUniqueRegistration";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getUniqueRegistrationType(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取渠道初始化订阅Id配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getDefaultOptId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getDefaultOptId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getDefaultOptId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取Cooperation OPT In的配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getCooperationOptIn(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getCopyIn";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getCooperationOptIn(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取注册新会短信模板配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getSmsTemplateRegisterCode(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getSMS_message";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getSmsTemplateRegisterCode(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取短信校验配置
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getSmsVerificationUrl(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getSMS_verification";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getSmsVerificationUrl(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }


    /**
     * 获取所有订阅Id
     *
     * @param tenantId 租户Id
     * @return 配置
     */
    public static String getOptId(String tenantId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + "getOptId";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getOptId(tenantId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取访问ACL的配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getAclParam(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getAclParam";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAclParam(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取注册奖励配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getAwardRegister(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getAward_register";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAwardRegister(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取绑定奖励配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getAwardBinding(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getAward_binding";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAwardBinding(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取首次修改奖励配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getAwardFirstModify(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getAward_firstModify";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAwardFirstModify(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取首次保存货物信息奖励配置
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @return 配置
     */
    public static String getAwardFirstSaveGoods(String tenantId, String channelId) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + channelId + KEY_DELIMITER + "getAward_firstSaveGoods";
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getAwardFirstSaveGoods(tenantId, channelId);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取tenantId下有unionIdType配置的channelId
     *
     * @param tenantId    租户
     * @param unionIdType unionID类型
     * @return java.lang.String
     * @author xusheng
     * @date 2020/10/23 15:20
     */
    public static String getChannelIds(String tenantId, String unionIdType) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tenantId + KEY_DELIMITER + unionIdType;
        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getChannelIds(tenantId, unionIdType);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

    /**
     * 获取tableStorage
     *
     * @param tableName 表名
     * @return 配置
     */
    public static String getTableStorage(String tableName) {
        String key = BASE_AM_CODE + KEY_DELIMITER + tableName + KEY_DELIMITER + "getTableStorage";

        Object object = caffeineCache.getIfPresent(key);
        if (!Objects.isNull(object)) {
            return object.toString();
        }
        String value = RedisConfigUtils.getTableStorage(tableName);
        if (!StringUtils.isEmpty(value)) {
            caffeineCache.put(key, value);
        }
        return value;
    }

}