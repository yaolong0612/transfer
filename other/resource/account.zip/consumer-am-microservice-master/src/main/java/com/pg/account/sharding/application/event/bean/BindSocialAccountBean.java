package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BindSocialAccountBean implements Serializable {
    private static final long serialVersionUID = 6183855390561103428L;
    @JSONField(name = "member_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @JSONField(name = "marketing_program_id")
    private int marketingProgramId;
    @JSONField(name = "modify_datetime")
    private Timestamp modifyDatetime;
    @JSONField(name = "update_flag")
    private char updateFlag;
    @JSONField(name = "mobile_no")
    private String mobileNo;
    @JSONField(name = "device_id")
    private String deviceId;
    @JSONField(name = "device_id_type")
    private String deviceIdType;
    @JSONField(name = "social_account_info")
    private List<SocialAccountBean> socialAccountInfo;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
