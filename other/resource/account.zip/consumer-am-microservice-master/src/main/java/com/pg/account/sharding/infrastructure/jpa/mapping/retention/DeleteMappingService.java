package com.pg.account.sharding.infrastructure.jpa.mapping.retention;

import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMappingDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMappingDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author lfx
 * @date 2022/2/24 14:56
 */
@Service
public class DeleteMappingService {

    private final BindIdMappingRetentionDao bindIdMappingRetentionDao;
    private final BindIdMappingDao bindIdMappingDao;
    private final EmailMappingRetentionDao emailMappingRetentionDao;
    private final MobileMappingRetentionDao mobileMappingRetentionDao;
    private final OpenUidMappingRetentionDao openUidMappingRetentionDao;
    private final UnionIdMappingRetentionDao unionIdMappingRetentionDao;
    private final UnionIdMappingDao unionIdMappingDao;
    private final ChannelDao channelDao;

    @Autowired
    public DeleteMappingService(BindIdMappingRetentionDao bindIdMappingRetentionDao,
                                EmailMappingRetentionDao emailMappingRetentionDao,
                                MobileMappingRetentionDao mobileMappingRetentionDao,
                                OpenUidMappingRetentionDao openUidMappingRetentionDao,
                                UnionIdMappingRetentionDao unionIdMappingRetentionDao,
                                ChannelDao channelDao,
                                BindIdMappingDao bindIdMappingDao,
                                UnionIdMappingDao unionIdMappingDao
    ) {
        this.bindIdMappingRetentionDao = bindIdMappingRetentionDao;
        this.emailMappingRetentionDao = emailMappingRetentionDao;
        this.mobileMappingRetentionDao = mobileMappingRetentionDao;
        this.openUidMappingRetentionDao = openUidMappingRetentionDao;
        this.unionIdMappingRetentionDao = unionIdMappingRetentionDao;
        this.channelDao = channelDao;
        this.bindIdMappingDao = bindIdMappingDao;
        this.unionIdMappingDao = unionIdMappingDao;
    }

    @Transactional(rollbackFor = Exception.class)
    public void retention(String accountId, String tenantId) {
        bindIdMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
        emailMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
        mobileMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
        openUidMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
        unionIdMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteAllBinding(String accountId, String tenantId) {
        bindIdMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
        unionIdMappingRetentionDao.deleteByAccountIdAndTenantId(accountId, tenantId);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteBindIdMapping(String accountId, String tenantId, String channel) {
        bindIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannelId(accountId, tenantId, channel);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteAllBinding(String accountId, String tenantId, String unionType) {
        List<ShardChannel> channels = channelDao.findByTenantIdAndUnionIdType(tenantId, unionType);
        channels.forEach(c -> bindIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannelId(accountId, tenantId, c.getChannelId()));
        Optional.ofNullable(unionType).ifPresent(u -> unionIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannel(accountId, tenantId, u));
    }

    @Transactional(rollbackFor = Exception.class)
    public ShardSocialAccount deleteAllBinding(String accountId, String tenantId, ShardSocialAccount shardSocialAccount, List<SocialAccountItem> removeItem) {
        ArrayList<SocialAccountItem> socialAccountList = new ArrayList<>();
        // 通过accountId查询所有bindIdMapping
        List<BindIdMappingRetention> bindMappingList = bindIdMappingRetentionDao.findBindIdMappingRetentionByAccountIdAndTenantId(accountId, tenantId);
        // 通过accountId查询所有unionIdMapping
        List<UnionIdMappingRetention> unionIdMappingList = unionIdMappingRetentionDao.findByAccountIdAndTenantId(accountId, tenantId);
        if (!Optional.ofNullable(shardSocialAccount.getSocialAccountList()).filter(list -> !list.isEmpty()).isPresent()) {
            bindMappingList.forEach(b -> {
                bindIdMappingDao.deleteByBindIdMapIdTenantIdAndBindIdMapIdBindIdAndBindIdMapIdChannelId(b.getTenantId(), b.getBindId(), b.getChannelId());
                comboShardAccount(tenantId, socialAccountList, unionIdMappingList, b);
            });
            unionIdMappingList.forEach(u -> unionIdMappingDao.deleteByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(u.getTenantId(), u.getUnionId(), u.getChannel()));
        } else {
            // 将所有bindIdMapping的channelId列出来组合成一个集合
            List<String> channelIds = bindMappingList.stream().map(BindIdMappingRetention::getChannelId).collect(Collectors.toList());
            // 将所有unionType列出来组合成一个集合
            List<String> dbUnionTypes = unionIdMappingList.stream().map(UnionIdMappingRetention::getChannel).collect(Collectors.toList());
            // 列出不需要解绑的channelId
            List<String> existChannelId = shardSocialAccount.getSocialAccountList().stream().map(SocialAccountItem::getChannelId).collect(Collectors.toList());
            // 需要解绑的bindId
            List<String> toRemoveBind = channelIds.stream().filter(n -> !existChannelId.contains(n)).collect(Collectors.toList());
            // 列出不需要解绑的unionType
            List<String> unionTypes = shardSocialAccount.getSocialAccountList().stream().map(SocialAccountItem::getChannelId).map(channel -> LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channel)).collect(Collectors.toList());
            // 列出需要解绑的unionType
            List<String> toRemoveUnion = dbUnionTypes.stream().filter(n -> !unionTypes.contains(n)).collect(Collectors.toList());
            List<BindIdMappingRetention> removedBindIdMapping = bindMappingList.stream().filter(a -> toRemoveBind.contains(a.getChannelId())).collect(Collectors.toList());
            List<UnionIdMappingRetention> removedUnionIdMapping = unionIdMappingList.stream().filter(a -> toRemoveUnion.contains(a.getChannel())).collect(Collectors.toList());
            removedBindIdMapping.forEach(b -> comboShardAccount(tenantId, socialAccountList, removedUnionIdMapping, b));
            // 删除需要解绑的bindIdMapping
            toRemoveBind.forEach(i -> bindIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannelId(accountId, tenantId, i));
            // 删除unionIdMapping
            toRemoveUnion.forEach(u -> unionIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannel(accountId, tenantId, u));
        }
        socialAccountList.removeIf(a -> removeItem.stream().map((Function<SocialAccountItem, Object>) SocialAccountItem::getChannelId).collect(Collectors.toList()).contains(a.getChannelId()));
        removeItem.addAll(socialAccountList);
        return ShardSocialAccount.ShardSocialAccountBuilder.aShardSocialAccount()
                .tenantId(tenantId)
                .accountId(accountId)
                .socialAccountList(removeItem)
                .createdTime(LocalDateTime.now())
                .updatedTime(LocalDateTime.now())
                .build();
    }

    private void comboShardAccount(String tenantId, ArrayList<SocialAccountItem> socialAccountList, List<UnionIdMappingRetention> unionIdMappingList, BindIdMappingRetention b) {
        String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenantId, b.getChannelId());
        SocialAccountItem socialAccountItem = new SocialAccountItem();
        ShardChannel shardchannel = channelDao.findByTenantIdAndChannelId(tenantId, b.getChannelId());
        Channel channel = new Channel();
        channel.build(shardchannel);
        socialAccountItem.setChannel(channel);
        socialAccountItem.setBindId(b.getBindId());
        socialAccountItem.setUnionId(unionIdMappingList.stream().filter(a -> a.getChannel().equals(unionIdType)).findFirst().map(UnionIdMappingRetention::getUnionId).orElse(""));
        socialAccountItem.setBindTime(LocalDateTime.now());
        socialAccountItem.setCreateTime(LocalDateTime.now());
        socialAccountItem.setUpdateTime(LocalDateTime.now());
        socialAccountList.add(socialAccountItem);
    }


}
