package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.AddSubscriptionsCommand;
import com.pg.account.interfaces.command.SubscriptionCommand;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author wsq
 * @date 2021/6/7 19:40
 **/
@Component
public class AddSubscriptionsAssembler {

    public ShardSubscription toShardSubscription(AddSubscriptionsCommand command) {
        ShardSubscription shardSubscription = new ShardSubscription();
        List<SubscriptionItem> subscriptionItems = toSubscriptionItem(command.getSubscriptions());
        shardSubscription.setIdentityId(new IdentityId(command.getTenantId().toString(), command.getMemberId()));
        shardSubscription.setSubscriptionList(subscriptionItems);
        shardSubscription.getSubscriptionList().forEach(subscriptionItem -> subscriptionItem.setChannelId(command.getChannelId().toString()));
        return shardSubscription;
    }

    private List<SubscriptionItem> toSubscriptionItem(List<SubscriptionCommand> subscriptionCommands) {
        List<SubscriptionItem> subscriptionItemList = new ArrayList<>();
        Optional.ofNullable(subscriptionCommands)
                .filter(subscriptionCommands1 -> !subscriptionCommands1.isEmpty())
                .ifPresent(subscriptionCommands1 -> subscriptionCommands1.forEach(subscriptionCommand -> {
                    SubscriptionItem subscriptionItem = new SubscriptionItem();
                    subscriptionItem.setOptId(subscriptionCommand.getOptId());
                    subscriptionItem.setOptStatus(subscriptionCommand.getOptStatus());
                    subscriptionItemList.add(subscriptionItem);
                }));
        return subscriptionItemList;
    }

}
