package com.pg.account.interfaces.command;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.CELLPHONE_OR_EMAIL_PATTERN;
import static com.pg.account.infrastructure.common.utils.StringValidUtil.M_R_PATTERN;

/**
 * @author JackSun
 * @date 2017/2/9
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModifyPasswordCommand implements Serializable {
    private static final long serialVersionUID = -1448476376781121031L;

    @ApiModelProperty(value = "租户ID", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "会员卡号,手机号，邮箱三者选填一个")
    @NotBlank(message = "missing user name")
    @Pattern(regexp = CELLPHONE_OR_EMAIL_PATTERN, message = "username invalid")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String username;
    @ApiModelProperty(value = "密码的修改类型，M：修改密码；R：重置密码", required = true)
    @NotBlank(message = "missing password change type")
    @Pattern(regexp = M_R_PATTERN, message = "password type error")
    private String type;
    @ApiModelProperty(value = "旧密码，当修改类型为重置密码时与newPassword的值相同。")
    @NotBlank(message = "original password length is less than 6 characters")
    @Length(min = 6, message = "original password length is less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String oldPassword;
    @ApiModelProperty(value = "新密码")
    @NotBlank(message = "change password length less than 6 characters")
    @Length(min = 6, message = "change password length less than 6 characters")
    @Desensitized(value = DesensitizedEnum.PASSWORD)
    private String newPassword;


}
