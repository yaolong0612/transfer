package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "AddressCommand_V1", description = "V1 interface AddressCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressCommand implements Serializable {
    private static final long serialVersionUID = -4185506825248945673L;
    @ApiModelProperty(value = "地址UUID识别编码", example = "12345556")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String addressCode;
    @ApiModelProperty(value = "是否是主地址（主：1,备：0），主地址只能存在一个，默认是主地址", example = "1", required = true)
    @Pattern(regexp = IS_PRIMARY_PATTERN, message = "no match to valid address type")
    private String isPrimary;
    @ApiModelProperty(value = "地址类型:1、HOME 不填默认是1（HOME）", example = "1", required = true)
    @Pattern(regexp = ADDRESS_TYPE_PATTERN, message = "no match to valid address type")
    private String addressType;
    @ApiModelProperty(value = "姓名", example = "孙悟空")
    @Pattern(regexp = FULL_NAME_VALID_PATTERN, message = "name is only allowed to enter Chinese and English, with space between the input allowed")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "手机", example = "188888888")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "电话", example = "0510-83195186")
    @Pattern(regexp = HOME_PHONE_PATTERN, message = "home phone format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "省", example = "江苏省")
    @Pattern(regexp = CH_EN_PATTERN, message = "province only Chinese and English are allowed")
    private String province;
    @ApiModelProperty(value = "市", example = "无锡市")
    @Pattern(regexp = CH_EN_PATTERN, message = "city only Chinese and English are allowed")
    private String city;
    @ApiModelProperty(value = "区", example = "滨湖区")
    @Pattern(regexp = CH_EN_PATTERN, message = "district only Chinese and English are allowed")
    private String district;
    @ApiModelProperty(value = "地址详情", example = "蠡湖大道1008号")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "address only Chinese and English, Numbers, Spaces, Braces, Underlines, Underlines and # signs are allowed")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "邮编", example = "215600")
    @Pattern(regexp = POSTAL_CODE_PATTERN, message = "postcode format error")
    private String postcode;
}
