package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SocialAccountBean implements Serializable {

    private static final long serialVersionUID = -1011110427008908752L;
    @JSONField(name = "bind_channel")
    private String bindChannel;
    @JSONField(name = "bind_brand")
    private String bindBrand;
    @JSONField(name = "public_account")
    private String publicAccount;
    @JSONField(name = "social_account_id")
    private String socialAccountId;
    @JSONField(name = "bind_status")
    private String bindStatus;
    @JSONField(name = "bind_datetime")
    private Timestamp bindDatetime;
    @JSONField(name = "bind_create_datetime")
    private Timestamp bindCreateDatetime;
    @JSONField(name = "bind_modify_datetime")
    private Timestamp bindModifyDatetime;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    @JSONField(name = "union_id")
    private String unionId;

}
