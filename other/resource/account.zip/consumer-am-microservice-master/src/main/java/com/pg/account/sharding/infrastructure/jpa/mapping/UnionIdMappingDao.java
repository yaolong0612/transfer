package com.pg.account.sharding.infrastructure.jpa.mapping;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author lfx
 * @date 2021/5/31 14:50
 */
public interface UnionIdMappingDao extends JpaRepository<UnionIdMapping, Long> {


    /**
     * 根据unionId和channel查询映射关系
     *
     * @param tenantId tenantId
     * @param unionId  unionId
     * @param channel  channel
     * @return com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping
     * @author xusheng
     * @date 2021/6/8 14:56
     */
    UnionIdMapping findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(String tenantId, String unionId, String channel);

    /**
     * 根据租户、unionId和渠道类型 删除unionId mapping
     *
     * @param tenantId tenantId
     * @param unionId  unionId
     * @param channel  channel
     * @author xusheng
     * @date 2021/7/5 13:45
     */
    @Modifying
    @Transactional
    void deleteByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(String tenantId, String unionId, String channel);


    /**
     * 通过accountId查询unionIdMapping
     *
     * @param accountId accountId
     * @return list of unionIdMapping
     */
    List<UnionIdMapping> findByAccountId(String accountId);

}
