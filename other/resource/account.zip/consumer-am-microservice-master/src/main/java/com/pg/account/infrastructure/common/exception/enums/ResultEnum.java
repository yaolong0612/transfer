package com.pg.account.infrastructure.common.exception.enums;

import lombok.Getter;

/**
 * @author Jack
 * @date 2021-04-23 13:11
 */
@Getter
public enum ResultEnum {
    /**
     * 通用状态
     */
    SUCCESS(0, 0, "Success"),
    ERROR(59999, 59999, "System Error"),

    /**
     * 业务异常
     */
    FORMAT_ERROR(51000, 51000, "format error"),
    INCORRECT_TENANT_ID(51001, 51001, "tenantId is incorrect"),
    INCORRECT_CHANNEL_ID(51002, 51002, "channelId is incorrect"),
    INCORRECT_MOBILE(51006, 51012, "mobile is error"),
    INCORRECT_EMAIL(51007, 51013, "email is error"),
    INCORRECT_MEMBER_ID(51012, 51011, "memberId is error"),
    INCORRECT_OPEN_UID(51013, 51010, "openUid is error"),
    INCORRECT_PASSWORD(51018, 51007, "password is error"),
    INCORRECT_MESSAGE_TEMPLATE_ID(51024, 51045, "message template id is error"),
    INCORRECT_MESSAGE_CODE(51025, 51046, "message code is error"),
    INCORRECT_ORIGINAL_PASSWORD(51031, 51047, "original password is error"),
    INCORRECT_CHANGE_PASSWORD(51032, 51048, "change password is error"),
    INCORRECT_USERNAME(51301, 51006, "username is error"),
    MOBILE_EXIST(51302, 51014, "mobile is exist"),
    EMAIL_EXIST(51303, 51015, "email is exist"),
    USER_EXIST(51304, 51005, "user is exist"),
    REPEAT_OPT_ID(51306, 51044, "repeat opt_id"),
    ACCOUNT_NOT_EXIST(51308, 51032, "account not exist"),
    MULTIPLE_USERS_EXIST(51309, 51004, "more than one users, please contact customer service"),
    ACCOUNT_STATUS_IS_NOT_EXIST(51311, 51028, "account status missing"),
    ACCOUNT_STATUS_IS_INVALID(51312, 51029, "account has expired"),
    ACCOUNT_STATUS_IS_DELETED(51313, 51030, "account has been deleted"),
    THE_NUMBER_OF_USER_LOGIN_ERRORS_REACHED_THE_LIMIT(51314, 51049, "user login errors has reached the limit"),
    OPT_ID_NOT_EXIST(51317, 51041, "subscription type does not exist"),
    BIND_DATA_TYPE_CONFLICT(51319, 51018, "bind data type conflicts"),
    BIND_ID_NOT_EXIST(51320, 51031, "bind data does not exist"),
    UNION_ID_NOT_EXIST(51321, 51027, "unionId's bound data does not exist"),
    BIND_DATA_CONFLICT(51322, 51018, "bind data conflict"),
    UNION_ID_DATA_CONFLICT(51331, 51017, "unionId data conflict"),
    UNION_ID_DATA_TYPE_CONFLICT(51332, 51050, "unionId data type conflict"),
    USER_ATTRIBUTE_DATA_EXIST(51333, 51051, "user attribute data exists"),
    UNION_ID_IS_NULL(51338, 51009, "unionId is null"),
    INCORRECT_MULTIPLE_BABIES_BIRTHDAY(51339, 51024, "many babies have birthdays less than a year apart or on different days"),
    INCORRECT_BABY_BIRTHDAY(51340, 51025, "baby's birthday is incorrect"),
    CUSTOMIZED_VALIDATOR_ERROR(51341, 51341, "customization error"),
    PARAMETER_PARSING_ERROR(51343, 51036, "parameter error"),
    ACCOUNT_DATA_CONFLICT(51344, 51043, "account data conflict"),
    ACCOUNT_DATA_ERROR(51444, 51444, "account data error"),

    /**
     * 自定义注解
     */
    QUERY_TYPE_IS_NULL(51019, 51019, "query type is is null"),
    QUERY_VALIDATION_ERROR(51020, 51020, "query validation is error"),
    REGISTER_TYPE_NOT_EXIST(51033, 51033, "register type is not exist"),
    QUERY_FIELDS_ERROR(51034, 51034, "query fields is error"),
    QUERY_TYPE_NOT_EXIST(51035, 51035, "query type not exist"),
    RELATION_ID_NOT_EXIST(51037, 51037, "relation id not exist"),
    USER_NAME_FORMAT_ERROR(51038, 51038, "user name format error"),
    USER_NAME_VALUE_ERROR(51039, 51039, "user name must equals to the specified value"),
    REGISTER_TYPE_CHOOSE_ERROR(51040, 51040, "register type choose error"),
    RELATIONSHIP_SEQUENCE_ERROR(51042, 51042, "relationship and sequence must be unique"),
    USER_BIRTHDAY_NOT_ADULT(51336, 51021, "user is under the age of 18 and is not an adult"),
    INCORRECT_USER_ATTRIBUTE_DATA_TYPE(51337, 51023, "user attribute data type is incorrect"),
    INCORRECT_PASSWORD_MODIFICATION_TYPE(51325, 51325, "incorrect password change type"),
    REPEAT_ADDRESS_TYPE(51326, 51326, "duplicate address type"),
    INCORRECT_QUERY_PARAM(51328, 51328, "query parameters are incorrect"),
    INCORRECT_ACCOUNT_IDENTIFICATION_INFORMATION(51022, 51022, "account identification information is incorrect"),
    INCORRECT_USER_ATTRIBUTE_INFORMATION_CONTENT(51011, 51052, "incorrect user attribute information content"),

    /**
     * 系统配置问题
     */
    TENANT_CONFIG_NOT_EXIST(52001, 52001, "tenant config is not exist"),
    CHANNEL_CONFIG_NOT_EXIST(52002, 52002, "channel config is not exist"),
    SOURCE_CONFIG_NOT_EXIST(52003, 52003, "source config is not exist"),
    SYSTEM_CONFIG_NOT_EXIST(52004, 52004, "system config is not exist"),
    SYSTEM_CONFIG_ERROR(52005, 52005, "system config is error"),
    /**
     * 外部系统的异常
     */
    ADDRESS_MICRO_SERVICE_ERROR(53001, 53001, "address microservice error"),
    ACL_MICRO_SERVICE_ERROR(53002, 53002, "ACL/MINI_ACL microservice error"),
    ACL_MICRO_UNION_ID_NOT_EXIST(53003, 53003, "ACL/MINI_ACL unionId not exist"),
    AWARD_MICRO_SERVICE_ERROR(53004, 53004, "award microservice error"),
    LOYALTY_MICRO_SERVICE_ERROR(53005, 53005, "loyalty microservice error"),
    SMS_MICRO_SERVICE_ERROR(53006, 53006, "sms microservice error"),

    /**
     * 底层与组件的异常
     */
    DB_ERROR(54001, 54001, "db error"),
    REDIS_ERROR(54002, 54002, "redis service error"),
    BAI_DU_SNOWFLAKE_ALGORITHM_ERROR(54003, 54003, "baiDu snowflake algorithm error"),
    SERVICE_BUS_ERROR(54004, 54004, "service bus error"),
    EVENT_HUB_ERROR(54005, 54005, "event hub error"),
    MQ_ERROR(54006, 54006, "mq error"),
    TABLE_STORAGE_ERROR(54007, 54007, "table Storage error"),
    READ_TIMEOUT_ERROR(54008, 54008, "read time out"),
    CAFFEINE_ERROR(54009, 54009, "caffeine error"),
    ;

    private final Integer code;
    private final Integer v2Code;
    private final String message;

    ResultEnum(Integer code, Integer v2Code, String message) {
        this.code = code;
        this.v2Code = v2Code;
        this.message = message;
    }
}
