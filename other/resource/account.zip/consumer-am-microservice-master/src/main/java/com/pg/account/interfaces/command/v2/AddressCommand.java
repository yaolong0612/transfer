package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * @author LFX
 */
@ApiModel(value = "AddressCommand_V2", description = "V2 interface AddressCommand")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressCommand implements Serializable {

    private static final long serialVersionUID = -4815064373291904084L;
    @ApiModelProperty(value = "Address UUID identification code", name = "addressCode", example = "123")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String addressCode;
    @ApiModelProperty(value = "full Name", name = "fullName", example = "孙悟空")
    @Pattern(regexp = FULL_NAME_VALID_PATTERN, message = "only Chinese and English names are allowed, and spaces are allowed in the middle")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "Mobile phone", name = "cellphone", example = "15061837133")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    @ApiModelProperty(value = "phone", name = "phone", example = "15061837133")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "province", name = "province", example = "江苏")
    @Pattern(regexp = CH_EN_PATTERN, message = "only chinese and english are allowed")
    private String province;
    @ApiModelProperty(value = "city", name = "city", example = "南京")
    @Pattern(regexp = CH_EN_PATTERN, message = "only chinese and english are allowed")
    private String city;
    @ApiModelProperty(value = "district", name = "district", example = "江宁区")
    @Pattern(regexp = CH_EN_PATTERN, message = "only chinese and english are allowed")
    private String district;
    @ApiModelProperty(value = "Address details", name = "address", example = "秣陵街道胜太路77号胜泰新寓9999#1801")
    @Pattern(regexp = SPECIAL_CHARACTER_FILTERING_PATTERN, message = "地址只允许输入中英文，数字，空格，小括号，中划线，下划线和#号")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "Postcode", name = "postcode", example = "230001")
    @Pattern(regexp = POSTAL_CODE_PATTERN, message = "postcode format error")
    private String postcode;
}
