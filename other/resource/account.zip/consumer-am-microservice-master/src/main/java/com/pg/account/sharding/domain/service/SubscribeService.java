package com.pg.account.sharding.domain.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.enums.AttentionStatusEnum;
import com.pg.account.infrastructure.common.enums.SubscriptionsStatusEnum;
import com.pg.account.infrastructure.common.exception.DbException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.Term;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.OptionDictionaryDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardOptionDictionary;
import com.pg.account.sharding.infrastructure.jpa.config.ShardTerms;
import com.pg.account.sharding.infrastructure.jpa.config.TermsDao;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COLON;
import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;

/**
 * @author Jack
 * @date 2021/5/31 11:42
 */
@Service
@Slf4j
public class SubscribeService {

    public static final String TERMS_VERSION = "termsVersion";
    public static final String TERMS_ID = "termsId";
    public static final String CHANNEL_ID = "channelId";
    public static final String OPT_ID = "optId";
    private final SubscriptionRepository subscriptionRepository;
    private final TermsDao termsDao;
    private final OptionDictionaryDao optionDictionaryDao;

    @Autowired
    public SubscribeService(SubscriptionRepository subscriptionRepository, TermsDao termsDao, OptionDictionaryDao optionDictionaryDao) {
        this.subscriptionRepository = subscriptionRepository;
        this.termsDao = termsDao;
        this.optionDictionaryDao = optionDictionaryDao;
    }

    /**
     * 保存或更新社交账号的订阅信息为IN
     *
     * @param tenantId  租户Id
     * @param channelId 渠道Id
     * @param accountId 会员Id
     */
    public ShardSubscription saveOrUpdateSubscriptionToIn(String tenantId, String channelId, String accountId) {
        // 获取该用户该渠道下的所有订阅信息
        ShardSubscription shardSubscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        //根据TermsId补全订阅数据中丢失的版本号
        getTermsVersion(shardSubscription);
        String options = LocalCacheConfigUtils.getInitialOption(tenantId, channelId);
        // 获取默认的订阅id
        String result = LocalCacheConfigUtils.getDefaultOptId(tenantId);
        String optId = getOptId(tenantId, channelId);
        List<String> optList = Arrays.stream(result.split(COMMA)).collect(Collectors.toList());
        if (StringUtils.isNotBlank(optId)) {
            optList.add(optId);
        }
        List<String> originOptList = shardSubscription.getSubscriptionList().stream().map(SubscriptionItem::getOptId).collect(Collectors.toList());
        //获取渠道对应的OPT_ID
        List<ShardOptionDictionary> optionDictionaryList = optionDictionaryDao.findByTenantId(tenantId);
        optList.forEach(opt -> {
            if (!originOptList.contains(opt)) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.setOptId(opt);
                subscriptionItem.setOptStatus(AttentionStatusEnum.SUBSCRIBE.getValue());
                JSONArray jsonArray = JSON.parseArray(options);
                addTermsInfo(optId, optionDictionaryList, subscriptionItem, jsonArray);
                subscriptionItem.setOptTime(LocalDateTime.now());
                subscriptionItem.setCreateTime(LocalDateTime.now());
                subscriptionItem.setUpdateTime(LocalDateTime.now());
                shardSubscription.getSubscriptionList().add(subscriptionItem);
            }
        });
        shardSubscription.getSubscriptionList().forEach(item -> item.setOptStatus(AttentionStatusEnum.SUBSCRIBE.getValue()));
        subscriptionRepository.save(shardSubscription);
        return shardSubscription;
    }

    /**
     * 添加terms信息
     *
     * @param optId                订阅Id
     * @param optionDictionaryList 订阅标识字典
     * @param subscriptionItem     subscriptionItem 订阅信息
     * @param jsonArray            jsonArray 订阅配置信息
     * @author xusheng
     * @date 2021/11/3 14:23
     */
    private void addTermsInfo(String optId, List<ShardOptionDictionary> optionDictionaryList, SubscriptionItem subscriptionItem, JSONArray jsonArray) {
        String optValue = null;
        List<Term> terms = new ArrayList<>();
        for (Object j : jsonArray) {
            JSONObject jsonObject = (JSONObject) j;
            if (jsonObject.getString(OPT_ID).equals(optId)) {
                terms.add(new Term(jsonObject.getString(TERMS_ID), jsonObject.getString(TERMS_VERSION)));
            }
        }
        for (ShardOptionDictionary dict : optionDictionaryList) {
            if (dict.getOptId().equals(optId)) {
                optValue = dict.getOptValue();
            }
        }
        subscriptionItem.setTermsList(terms);
        subscriptionItem.setOptName(optValue);
    }

    /**
     * 根据订阅关系补全里面丢失的版本号
     *
     * @param shardSubscription shardSubscription
     * @author xusheng
     * @date 2021/10/12 17:18
     */
    private void getTermsVersion(ShardSubscription shardSubscription) {
        Optional.ofNullable(shardSubscription)
                .map(ShardSubscription::getSubscriptionItemList)
                .ifPresent(subscriptionItemList -> subscriptionItemList.forEach(subscriptionItem -> Optional.ofNullable(subscriptionItem.getTermsList())
                        .filter(terms -> !terms.isEmpty())
                        .ifPresent(terms -> terms.forEach(term -> {
                            if (StringUtils.isBlank(term.getTermVersion())) {
                                Optional<ShardTerms> optionalShardTerms = termsDao.findById(Long.valueOf(term.getTermId()));
                                optionalShardTerms.ifPresent(shardTerms -> term.setTermVersion(shardTerms.getTermsVersion()));
                            }
                        }))));
    }

    private String getOptId(String tenantId, String channelId) {
        //获取渠道对应的OPT_ID
        String optId = null;
        String result = LocalCacheConfigUtils.getChannelOptId(tenantId);
        String[] x = result.split(COMMA);
        for (String s : x) {
            String[] j = s.split(COLON);
            if (j[0].equals(String.valueOf(channelId))) {
                optId = j[1];
                break;
            }
        }
        return optId;
    }

    /**
     * 将订阅状态改为O
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param channelId channelId
     */
    public ShardSubscription saveOrUpdateSubscriptionToOut(String tenantId, String channelId, String accountId) {
        // 获取该用户该渠道下的所有订阅信息
        ShardSubscription subscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        getTermsVersion(subscription);
        String optId = getOptId(tenantId, channelId);
        try {
            subscription.getSubscriptionList().forEach(sub -> {
                if (sub.getOptId().equals(optId)) {
                    sub.setOptStatus(SubscriptionsStatusEnum.OUT.getValue());
                    sub.changeUpdatedTime();
                }
            });
            subscription.addUpdatedTime();
            subscriptionRepository.save(subscription);
        } catch (DbException e) {
            throw new DbException(ResultEnum.DB_ERROR.getCode(), ResultEnum.DB_ERROR.getV2Code(), ResultEnum.DB_ERROR.getMessage());
        }
        return subscription;
    }

    /**
     * 更新dbShardSubscription
     *
     * @param dbShardSubscription
     */
    public void delete(ShardSubscription dbShardSubscription) {
        subscriptionRepository.save(dbShardSubscription);
    }
}
