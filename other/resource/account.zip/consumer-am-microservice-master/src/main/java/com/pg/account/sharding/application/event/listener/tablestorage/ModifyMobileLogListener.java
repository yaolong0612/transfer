package com.pg.account.sharding.application.event.listener.tablestorage;

import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.application.event.SignUpEvent;
import com.pg.account.sharding.application.event.UpdateProfileEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Contact;
import com.pg.account.sharding.domain.model.account.UserBasicInfo;
import com.pg.account.sharding.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.infrastructure.tablestorage.ModifyMobileEntity;
import com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils;
import com.pg.account.sharding.infrastructure.tablestorage.TenantIdMappingTenantNameProperties;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

/**
 * @author yj
 * @date 2022/3/17
 */
@Data
@Component
@Slf4j
@RefreshScope
@ConfigurationProperties(prefix = "tenantmapping")
public class ModifyMobileLogListener {

    public static final String SIGN_UP_EVENT = "signUpEvent";
    public static final String TRUE = "true";
    public static final String UPDATE_PROFILE_EVENT = "updateProfileEvent";
    public static final String MODIFY_MOBILE_LOG = "ModifyMobileLog";
    private final UidGenerator uidGenerator;
    private List<TenantIdMappingTenantNameProperties> tenantIdToTenantName;
    private final TableStorageUtils<ModifyMobileEntity> tableStorageWriter;

    public ModifyMobileLogListener(UidGenerator uidGenerator, TableStorageUtils<ModifyMobileEntity> tableStorageWriter) {
        this.uidGenerator = uidGenerator;
        this.tableStorageWriter = tableStorageWriter;
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SignUpEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            signUpEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateProfileEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            updateProfileEvent(event.getAccount());
        }
    }

    /**
     * 注册event
     *
     * @param account account
     */
    private void signUpEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).ifPresent(mobile -> {
            //封装modifyMobileEntity
            ModifyMobileEntity modifyMobileEntity = encapsulationEntity(account, mobile, SIGN_UP_EVENT, TRUE);
            //写入tb
            try {
                writeToTb(modifyMobileEntity);
            } catch (Exception e) {
                log.error("写入失败", e);
            }

        });
    }

    /**
     * 更新event
     *
     * @param account account
     */
    private void updateProfileEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).ifPresent(mobile -> {
            //封装modifyMobileEntity
            ModifyMobileEntity modifyMobileEntity = encapsulationEntity(account, mobile, UPDATE_PROFILE_EVENT, TRUE);
            //写入tb
            try {
                writeToTb(modifyMobileEntity);
            } catch (Exception e) {
                log.error("写入失败", e);
            }
        });
    }


    /**
     * 写入tb
     *
     * @param modifyMobileEntity modifyMobileEntity
     */
    private void writeToTb(ModifyMobileEntity modifyMobileEntity) throws Exception {
        //根据租户确定表明
        String tableName = matchTableName(modifyMobileEntity);
        tableStorageWriter.createTableIfNotExist(tableName);
        if (StringUtils.isNotBlank(tableName)) {
            tableStorageWriter.save(tableName, modifyMobileEntity);
        } else {
            log.warn("tableName为空:{}" + modifyMobileEntity.getPartitionKey());
        }
    }

    /**
     * 封装修改手机号实体
     *
     * @param account       account
     * @param mobile        mobile
     * @param eventType     eventType
     * @param accountStatus accountStatus
     * @return ModifyMobileEntity
     */
    private ModifyMobileEntity encapsulationEntity(Account account, String mobile, String eventType, String accountStatus) {
        ModifyMobileEntity.ModifyMobileEntityBuilder modifyMobileEntityBuilder = ModifyMobileEntity.ModifyMobileEntityBuilder.aModifyMobileEntity()
                .accountId(account.accountId())
                .modifyMobile(mobile)
                .eventType(eventType)
                .accountStatus(accountStatus)
                .updateTime(DateUtil.formatLocalDateTimeToT(LocalDateTime.now()));
        ModifyMobileEntity modifyMobileEntity = modifyMobileEntityBuilder.build();
        modifyMobileEntity.setPartitionKey(account.tenantId());
        modifyMobileEntity.setRowKey(String.valueOf(uidGenerator.getUid()));
        return modifyMobileEntity;
    }

    /**
     * 匹配租户对应的表名
     *
     * @param modifyMobileEntity modifyMobileEntity
     * @return 表名
     */
    private String matchTableName(ModifyMobileEntity modifyMobileEntity) {
        String tableName = null;
        String tenantName = null;
        Calendar now = Calendar.getInstance();
        String year = String.valueOf(now.get(Calendar.YEAR));
        for (TenantIdMappingTenantNameProperties tenantIdMappingTenantNameProperties : tenantIdToTenantName) {
            if (modifyMobileEntity.getPartitionKey().equals(tenantIdMappingTenantNameProperties.getTenantId())) {
                tenantName = tenantIdMappingTenantNameProperties.getTenantName();
                break;
            }
        }
        if (Optional.ofNullable(tenantName).isPresent()) {
            tableName = MODIFY_MOBILE_LOG + tenantName + year;
        }
        return tableName;
    }

}
