package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.domain.service.annotation.IsValidField;
import com.pg.account.sharding.domain.service.annotation.IsValidRoute;
import com.pg.account.sharding.domain.service.annotation.IsValidTenant;
import com.pg.account.sharding.domain.service.annotation.IsValidType;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.common.enums.QueryFieldEnum;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Valid;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;
import static java.util.Arrays.asList;

/**
 * @author lfx
 * @date 2021/12/31 13:21
 */
public class StringValidator<T extends Annotation> implements ConstraintValidator<T, @Valid String> {

    protected Predicate<String> predicate = c -> true;

    @Autowired
    protected ChannelDao channelDao;

    @Override
    public boolean isValid(String query, ConstraintValidatorContext constraintValidatorContext) {
        return predicate.test(query);
    }

    public static class TenantValid extends StringValidator<IsValidTenant> {
        @Override
        public void initialize(IsValidTenant constraintAnnotation) {
            predicate = tenant -> StringUtils.isNotBlank(LocalCacheConfigUtils.getTenant(tenant));
        }
    }

    public static class TypeValid extends StringValidator<IsValidType> {
        @Override
        public void initialize(IsValidType constraintAnnotation) {
            List<String> types = asList("mobile", "accountId", "bindId", "unionId");
            predicate = types::contains;
        }
    }

    public static class FieldValid extends StringValidator<IsValidField> {
        @Override
        public void initialize(IsValidField constraintAnnotation) {
            predicate = a -> !Optional.ofNullable(a).isPresent() || Arrays.stream(QueryFieldEnum.values()).map(QueryFieldEnum::getMsg).anyMatch(msg -> msg.equals(a));
        }
    }

    public static class RouteValid extends StringValidator<IsValidRoute> {
        @Override
        public void initialize(IsValidRoute constraintAnnotation) {
            List<String> routes = asList("1", "2");
            predicate = routes::contains;
        }
    }

    /**
     * 渠道校验 如果渠道不存在则返回false
     */
    public static void channelValid(String tenant, String channel) {
        if (Optional.ofNullable(channel).isPresent()) {
            String result = Optional.ofNullable(LocalCacheConfigUtils.getChannelId(tenant)).orElse("");
            String[] x = result.split(COMMA);
            if (Arrays.stream(x).noneMatch(i -> i.equals(channel))) {
                throw new BusinessException(V3ResultEnum.INCORRECT_CHANNEL_ID.getCode(), V3ResultEnum.INCORRECT_CHANNEL_ID.getMessage(), V3ResultEnum.INCORRECT_CHANNEL_ID.getFrontMessage());
            }
        }
    }


    /**
     * 判断是否需要unionId
     *
     * @param tenant  tenant
     * @param channel channel
     * @param mobile  mobile
     * @param bindId  bindId
     * @param unionId unionId
     * @return 是否存在unionId
     */
    public static boolean unionIdIsNecessary(String tenant, String channel, String mobile, String bindId, String unionId) {
        // 查询是否存在unionType
        String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenant, channel);
        if (StringUtils.isBlank(unionIdType)) {
            // 如果不存在unionType 返回true
            return true;
        } else {
            if (StringUtils.isNotBlank(mobile) && StringUtils.isBlank(unionId) && StringUtils.isBlank(bindId)) {
                //存在unionType 如果存在手机号 并且unionId和bindId都不存在返回true
                return true;
            } else {
                //存在unionType 存在unionId 返回true 不存在返回false
                return StringUtils.isNotBlank(unionId);
            }
        }
    }
}
