package com.pg.account.infrastructure.component.snowflake;

import com.pg.account.infrastructure.component.uid.UidGenerator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * @author JackSun
 * @date 2017/1/12
 */
@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "SNOWFLAKE_LOG")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SnowFlakeLog implements Serializable {

    private static final long serialVersionUID = 120626224606898691L;

    @Id
    private Long id;
    @Column(name = "HOST_NAME")
    private String hostName;
    @Column(name = "PORT")
    private int port;
    @Column(name = "WORK_ID")
    private Long workId;
    @Column(name = "DATA_CENTER_ID")
    private Long dataCenterId;
    @Column(name = "CREATE_TIME")
    private Timestamp createTime;
    @Column(name = "MODIFY_TIME")
    private Timestamp modifyTime;

    public SnowFlakeLog(UidGenerator uidGenerator, String hostName, Long workerId, Long dataCenterId) {
        Timestamp timestamp = new Timestamp(LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli());
        this.id = uidGenerator.getUid();
        this.hostName = hostName;
        this.port = 0;
        this.workId = workerId;
        this.dataCenterId = dataCenterId;
        this.createTime = timestamp;
        this.modifyTime = timestamp;
    }
}
