package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.CounterCommand;
import com.pg.account.interfaces.command.DeviceCommand;
import com.pg.account.interfaces.command.oralbCommand.*;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.infrastructure.client.address.Address;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 迁移注册绑定封装
 */
@Component
public class MigrateShardingRegisterBindAssembler {


    private final ChannelDao channelDao;

    @Autowired
    public MigrateShardingRegisterBindAssembler(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 将入参转换为account
     *
     * @param migrateRegisterBindCommand migrateRegisterBindCommand
     * @return Account
     */
    public Account toAccount(MigrateRegisterBindCommand migrateRegisterBindCommand) {
        String channelId = migrateRegisterBindCommand.getChannelId().toString();
        ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(migrateRegisterBindCommand.getTenantId().toString(), channelId);
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        Contact contact = new Contact();
        if (StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getCellphone())) {
            contact.specialMobile(migrateRegisterBindCommand.getProfile().getCellphone());
        }
        if (StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getEmail())) {
            contact.specialEmail(migrateRegisterBindCommand.getProfile().getEmail());
        }
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(migrateRegisterBindCommand.getTenantId().toString())
                .migratePassword(migrateRegisterBindCommand.getPassword(), migrateRegisterBindCommand.getSalt())
                .registration(migrateRegisterBindCommand.getSource(), channel, StringUtils.isNotBlank(migrateRegisterBindCommand.getCustomer()) ? migrateRegisterBindCommand.getCustomer() : null, StringUtils.isNotBlank(migrateRegisterBindCommand.getRegStore()) ? migrateRegisterBindCommand.getRegStore() : null, migrateRegisterBindCommand.getRegDate().toLocalDateTime())
                .counter(toCounterInfo(migrateRegisterBindCommand.getCounter()))
                .address(toAddress(migrateRegisterBindCommand.getAddresses()))
                .device(this.toDeviceInfo(migrateRegisterBindCommand.getDevice()))
                .extraAttrs(toExtraAttributeItem(migrateRegisterBindCommand.getAttrs()));
        if (Optional.ofNullable(migrateRegisterBindCommand.getProfile()).isPresent()) {
            accountBuilder.birthday(StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getBirthday()) ? migrateRegisterBindCommand.getProfile().getBirthday() : null)
                    .gender(StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getGender()) ? migrateRegisterBindCommand.getProfile().getGender() : null)
                    .fullName(StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getField3()) ? migrateRegisterBindCommand.getProfile().getField3() : null)
                    .contact(contact)
                    .nickName(StringUtils.isNotBlank(migrateRegisterBindCommand.getProfile().getNickname()) ? migrateRegisterBindCommand.getProfile().getNickname() : null);
        }
        return accountBuilder.build();
    }

    /**
     * 封装成DeviceInfo
     *
     * @param deviceCommand
     * @return
     */
    private DeviceInfo toDeviceInfo(DeviceCommand deviceCommand) {
        DeviceInfo deviceInfo = null;
        boolean flag = false;
        if (Optional.ofNullable(deviceCommand).isPresent()) {
            deviceInfo = new DeviceInfo();
            if (StringUtils.isNotBlank(deviceCommand.getOs())) {
                deviceInfo.setOs(deviceCommand.getOs());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getAppv())) {
                deviceInfo.setAppv(deviceCommand.getAppv());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getPackageName())) {
                deviceInfo.setPackageName(deviceCommand.getPackageName());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getIdfa())) {
                deviceInfo.setIdfa(deviceCommand.getIdfa());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getImei())) {
                deviceInfo.setImei(deviceCommand.getImei());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getOaid())) {
                deviceInfo.setOaid(deviceCommand.getOaid());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getMac())) {
                deviceInfo.setMac(deviceCommand.getMac());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getOpenudid())) {
                deviceInfo.setOpenudid(deviceCommand.getOpenudid());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getAndroidid())) {
                deviceInfo.setAndroidid(deviceCommand.getAndroidid());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getModel())) {
                deviceInfo.setModel(deviceCommand.getModel());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getBrand())) {
                deviceInfo.setBrand(deviceCommand.getBrand());
                flag = true;
            }
            if (StringUtils.isNotBlank(deviceCommand.getAdTracked())) {
                deviceInfo.setAdTracked(deviceCommand.getAdTracked());
                flag = true;
            }
        }
        if (flag) {
            return deviceInfo;
        }
        return null;
    }

    /**
     * 封装成 ShardSocialAccount
     *
     * @param tenantId
     * @param memberId
     * @param bindingCommandList
     * @param unionId
     * @return
     */
    public ShardSocialAccount toShardSocialAccount(Long tenantId, String memberId, List<OralbBindCommand> bindingCommandList, String unionId, String source) {
        List<SocialAccountItem> socialAccountItemList = new ArrayList<>();
        for (OralbBindCommand oralbBindCommand : bindingCommandList) {
            if (StringUtils.isNotBlank(oralbBindCommand.getBindId())) {
                ShardChannel shardChannel = Optional.ofNullable(channelDao.findByTenantIdAndChannelId(tenantId.toString(), oralbBindCommand.getChannelId().toString())).orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
                Channel channel = new Channel();
                channel.build(shardChannel);
                SocialAccountItem socialAccountItem = new SocialAccountItem();
                socialAccountItem.setChannel(channel);
                socialAccountItem.setSource(source);
                socialAccountItem.setBindId(oralbBindCommand.getBindId());
                socialAccountItem.setUnionId(StringUtils.isNotBlank(unionId) ? unionId : null);
                socialAccountItem.setBindTime(oralbBindCommand.getBindTime().toLocalDateTime());
                socialAccountItem.setCreateTime(LocalDateTime.now());
                socialAccountItem.setUpdateTime(LocalDateTime.now());
                socialAccountItemList.add(socialAccountItem);
            }
        }
        ShardSocialAccount.ShardSocialAccountBuilder shardSocialAccountBuilder = ShardSocialAccount
                .ShardSocialAccountBuilder
                .aShardSocialAccount()
                .tenantId(tenantId.toString())
                .accountId(memberId)
                .socialAccountList(socialAccountItemList);
        return shardSocialAccountBuilder.build();
    }

    public ShardSubscription toShardSubscription(Long tenantId, Account account, String memberId, List<OralbSubscriptionCommand> subscriptionCommandList) {
        ShardSubscription.ShardSubscriptionBuilder shardSubscriptionBuilder = ShardSubscription.ShardSubscriptionBuilder
                .aShardSubscription()
                .tenantId(tenantId.toString())
                .accountId(memberId);
        List<SubscriptionItem> subscriptionItems = new ArrayList<>();
        if (Optional.ofNullable(subscriptionCommandList)
                .filter(subscriptionCommands -> !subscriptionCommands.isEmpty())
                .isPresent()) {
            toSubscriptionItem(account.getRegisterChannelId(), subscriptionCommandList, subscriptionItems);
        } else {
            SubscriptionItem subscriptionItem = new SubscriptionItem();
            subscriptionItem.setChannelId(account.getRegisterChannelId());
            subscriptionItems.add(subscriptionItem);
        }
        return shardSubscriptionBuilder.subscriptionList(subscriptionItems).build();
    }


    /**
     * 封装 ExtraAttributeItem
     *
     * @param attrCommandList attrCommandList
     * @return ExtraAttributeItem4
     */
    private List<ExtraAttributeItem> toExtraAttributeItem(List<OralbAttrCommand> attrCommandList) {
        List<ExtraAttributeItem> extraAttributes = null;
        if (Optional.ofNullable(attrCommandList).filter(attrCommands -> !attrCommands.isEmpty()).isPresent()) {
            extraAttributes = new ArrayList<>();
            for (OralbAttrCommand attrCommand : attrCommandList) {
                if (StringUtils.isNotBlank(attrCommand.getAttrId())) {
                    ExtraAttributeItem extraAttributeItem = new ExtraAttributeItem(attrCommand.getAttrId(), null, attrCommand.getAttrVal(), LocalDateTime.now(), LocalDateTime.now());
                    extraAttributes.add(extraAttributeItem);
                }
            }
        }
        return extraAttributes;
    }

    /**
     * 封装Addrees
     *
     * @param addressCommand OralbAddressCommand
     * @return Address
     */
    private Address toAddress(OralbAddressCommand addressCommand) {
        Address address = null;
        boolean flag = false;
        if (Optional.ofNullable(addressCommand).isPresent()) {
            address = new Address();
            if (StringUtils.isNotBlank(addressCommand.getAddressCode())) {
                address.setAddressCode(addressCommand.getAddressCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getFullName())) {
                address.setFullName(addressCommand.getFullName());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getCellphone())) {
                address.setCellphone(addressCommand.getCellphone());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getPhone())) {
                address.setPhone(addressCommand.getPhone());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getProvince())) {
                address.setProvince(addressCommand.getProvince());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getCity())) {
                address.setCity(addressCommand.getCity());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getDistrict())) {
                address.setDistrict(addressCommand.getDistrict());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getAddress())) {
                address.setAddress(addressCommand.getAddress());
                flag = true;
            }
            if (StringUtils.isNotBlank(addressCommand.getPostcode())) {
                address.setPostcode(addressCommand.getPostcode());
                flag = true;
            }
        }
        if (flag) {
            return address;
        }
        return null;
    }

    /**
     * 封装CounterInfo
     *
     * @param counterCommand
     * @return CounterInfo
     */
    private CounterInfo toCounterInfo(CounterCommand counterCommand) {
        CounterInfo counterInfo = null;
        boolean flag = false;
        if (Optional.ofNullable(counterCommand).isPresent()) {
            counterInfo = new CounterInfo();
            if (StringUtils.isNotBlank(counterCommand.getRegCounterCode())) {
                counterInfo.setRegCounterCode(counterCommand.getRegCounterCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getRegCounterName())) {
                counterInfo.setRegCounterName(counterCommand.getRegCounterName());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getMainCounterCode())) {
                counterInfo.setMainCounterCode(counterCommand.getMainCounterCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getMainCounterName())) {
                counterInfo.setMainCounterName(counterCommand.getMainCounterName());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getPickupCounterCode())) {
                counterInfo.setPickupCounterCode(counterCommand.getPickupCounterCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getPickupCounterName())) {
                counterInfo.setPickupCounterName(counterCommand.getPickupCounterName());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getOfflineFirstPurchaseCounterCode())) {
                counterInfo.setOfflineFirstPurchaseCounterCode(counterCommand.getOfflineFirstPurchaseCounterCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getOfflineFirstPurchaseCounterName())) {
                counterInfo.setOfflineFirstPurchaseCounterName(counterCommand.getOfflineFirstPurchaseCounterName());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getFirstPurchaseCounterCode())) {
                counterInfo.setFirstPurchaseCounterCode(counterCommand.getFirstPurchaseCounterCode());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getFirstPurchaseTime())) {
                counterInfo.setFirstPurchaseTime(counterCommand.getFirstPurchaseTime());
                flag = true;
            }
            if (StringUtils.isNotBlank(counterCommand.getCrmPickupCounterCode())) {
                counterInfo.setCrmPickupCounterCode(counterCommand.getCrmPickupCounterCode());
                flag = true;
            }
        }
        if (flag) {
            return counterInfo;
        }
        return null;
    }


    private void toSubscriptionItem(String channelId, List<OralbSubscriptionCommand> subscriptionCommandList, List<SubscriptionItem> subscriptionList) {
        subscriptionCommandList.forEach(oralbSubscriptionCommand -> {
            if (StringUtils.isNotBlank(oralbSubscriptionCommand.getOptId())) {
                SubscriptionItem subscriptionItem = new SubscriptionItem();
                subscriptionItem.build(oralbSubscriptionCommand.getOptId(), null, oralbSubscriptionCommand.getOptStatus(), null);
                subscriptionItem.setChannelId(channelId);
                subscriptionList.add(subscriptionItem);
            }
        });
    }

}
