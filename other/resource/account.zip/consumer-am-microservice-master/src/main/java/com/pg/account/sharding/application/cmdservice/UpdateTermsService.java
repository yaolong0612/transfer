package com.pg.account.sharding.application.cmdservice;

import com.pg.account.sharding.interfaces.command.TermsCommand;
import org.springframework.stereotype.Component;

/**
 * @author lfx
 * @date 2022/2/21 10:54
 */
@Component
public interface UpdateTermsService {

    /**
     * 跟新条款
     *
     * @param command command
     */
    void updateTerms(TermsCommand command);
}
