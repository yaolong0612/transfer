package com.pg.account.infrastructure.common.interceptor;

import cn.com.pg.paas.monitor.domain.entity.ApiLogExtend;
import cn.com.pg.paas.monitor.domain.services.ICustomApiMetric;
import cn.hutool.extra.servlet.ServletUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;

/**
 * @author Jack
 * @description
 * @date 2021/8/22 23:45
 * @modified Jack
 */
@Component
@Getter
@Setter
public class ApiMetric implements ICustomApiMetric {

    public static final String QUERY_STRING = "queryString";
    public static final String REQUEST_BODY = "requestBody";
    public static final String REQUEST_ID = "requestId";
    public static final String HTTP_STATUS = "httpStatus";
    public static final String REQUEST_URI = "requestUri";
    public static final String METHOD = "method";
    public static final String CONTENT_TYPE = "contentType";
    public static final String REMOTE_ADDR = "remoteAddr";
    public static final String REQUEST_QUERY_STRING = "requestQueryString";
    public static final String RESPONSE_DATA = "responseData";
    public static final String TENANT_ID = "tenantId";
    public static final String START_TIME = "startTime";
    public static final String END_TIME = "endTime";
    public static final String START_STR = "{";
    public static final String VERSION_V2 = "v2";
    public static final String LIVENESS = "/liveness";
    public static final String READINESS = "/readiness";
    public static final String PROMETHEUS = "/prometheus";
    public static final String V_3 = "v3/accounts/";
    public static final String CLIENT_IP = "clientIp";
    private Map<String, Object> dimension;

    @Override
    public ApiLogExtend getCustomMetric(String returnArgs, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        return getApiLogExtend(returnArgs, httpServletRequest);
    }

    private ApiLogExtend getApiLogExtend(String returnArgs, HttpServletRequest httpServletRequest) {
        ApiLogExtend apiLogExtend = new ApiLogExtend();
        String requestUri = httpServletRequest.getAttribute(REQUEST_URI).toString();
        String uri = requestUri;
        if (requestUri.contains(V_3)) {
            if (GET.equals(httpServletRequest.getMethod()) || DELETE.equals(httpServletRequest.getMethod())) {
                int fromIndex = requestUri.lastIndexOf("accounts/") + 8;
                int toIndex = requestUri.lastIndexOf("/");
                if (fromIndex == toIndex) {
                    toIndex = requestUri.length();
                }
                String substring = requestUri.substring(fromIndex + 1, toIndex);
                uri = requestUri.replaceAll(substring, "*");
            }
        }
        HashMap<String, Object> requestIdMap = new HashMap<>(10);
        if (null != dimension) {
            requestIdMap = (HashMap<String, Object>) dimension;
            this.setDimension(null);
        }
        requestIdMap.put(CLIENT_IP, ServletUtil.getClientIP(httpServletRequest, null));
        requestIdMap.put(REQUEST_ID, httpServletRequest.getAttribute(REQUEST_ID));
        requestIdMap.put(START_TIME, httpServletRequest.getAttribute(START_TIME));
        requestIdMap.put(REQUEST_URI, uri);
        long endTime = System.currentTimeMillis();
        requestIdMap.put(END_TIME, endTime);
        apiLogExtend.setDimension(requestIdMap);
        if (!returnArgs.startsWith(START_STR)) {
            return apiLogExtend;
        }
        JSONObject returnJson = JSON.parseObject(returnArgs);
        final String resultKey = RESULT_CODE;
        final String resultCode = CODE;
        if (returnJson.containsKey(resultKey)) {
            String result = returnJson.getString(resultKey);
            //获取result字段，判断请求是否成功
            if (StringUtils.isNotBlank(result)) {
                apiLogExtend.setError_code(Integer.parseInt(result));
            }
        } else if (returnJson.containsKey(resultCode)) {
            Integer result = returnJson.getInteger(resultCode);
            //获取result字段，判断请求是否成功
            if (null != result) {
                apiLogExtend.setError_code(result);
            }
        }
        return apiLogExtend;
    }
}
