package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.infrastructure.client.address.Address;

/**
 * @author Jack
 * @description
 * @date 2021/6/2 23:24
 * @modified Jack
 */
public interface CreateAddressService {

    /**
     * 存储地址
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param address   address
     */
    void store(String tenantId, String accountId, Address address);

    /**
     * v3存储地址
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param address   address
     */
    void save(String tenantId, String accountId, Address address);
}
