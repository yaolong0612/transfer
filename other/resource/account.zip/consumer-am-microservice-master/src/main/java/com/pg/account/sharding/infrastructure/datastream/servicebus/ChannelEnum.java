package com.pg.account.sharding.infrastructure.datastream.servicebus;

/**
 * 用于判断AM传入的channel是否是loyalty需要的channel，不是则给默认的channel
 *
 * @author xusheng
 * @date 2019/11/20 15:37
 */
public enum ChannelEnum {
    /**
     * 注册渠道类型
     */
    WECHAT("WECHAT"),
    WECHAT_MINI_PROGRAM("WECHAT_MINI_PROGRAM"),
    JD("JD"),
    TMALL("TMALL"),
    WEBSITE("WEBSITE"),
    COUNTER("COUNTER"),
    LINE("LINE"),
    ADMIN("ADMIN"),
    SMS("SMS"),
    EXTERNAL_APP_WEBSITE("EXTERNAL_APP_WEBSITE"),
    VIP("VIP"),
    WEIBO("WEIBO"),
    QQ("QQ"),
    ALIPAY("ALIPAY"),
    GCR("GCR"),
    INSTORE("INSTORE");

    private final String value;

    ChannelEnum(String value) {
        this.value = value;
    }

    /**
     * 根据传入channel判断是否在枚举类中，没有则给默认的channel
     *
     * @param channel channel
     * @return java.lang.String
     * @author xusheng
     * @date 2019/11/20 15:40
     */
    public static String fromValue(String channel) {
        for (ChannelEnum channelEnum : ChannelEnum.values()) {
            if (channelEnum.value.equals(channel)) {
                return channelEnum.value;
            }
        }
        //这是默认的值
        return ChannelEnum.EXTERNAL_APP_WEBSITE.value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

}
