package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 注册绑定响应类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "AccountRegisterDTO_V2", description = "V2 AccountRegisterDTO接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountRegisterDTO implements Serializable {
    private static final long serialVersionUID = 399045192962987937L;
    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
}
