package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 */
@Getter
public class BraunFirstSaveGoodsEvent extends ApplicationEvent {
    private static final long serialVersionUID = -8186934142539120998L;

    private Account account;
    private String attrId;

    public BraunFirstSaveGoodsEvent(Object source) {
        super(source);
    }

    public BraunFirstSaveGoodsEvent(Object source, Account account, String attrId) {
        super(source);
        this.account = account;
        this.attrId = attrId;
    }
}
