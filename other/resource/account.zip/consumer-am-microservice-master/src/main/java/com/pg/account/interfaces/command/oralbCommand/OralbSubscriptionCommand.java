package com.pg.account.interfaces.command.oralbCommand;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author YJ
 * @date 2021/9/4
 */
@ApiModel(value = "Oralb_SubscriptionCommand", description = "Oralb migrate interface SubscriptionCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OralbSubscriptionCommand implements Serializable {
    private static final long serialVersionUID = 2462326661623153214L;
    @ApiModelProperty(value = "订阅ID", example = "103", required = true)
    private String optId;
    @ApiModelProperty(value = "订阅状态(I或者O)", example = "I", required = true)
    private String optStatus;
}
