package com.pg.account.interfaces.facade.v1.assembler;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;

import com.pg.account.interfaces.command.AccountRegisterCommand;
import com.pg.account.interfaces.command.ProfileCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.Contact;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.enums.RegisterTypeEnum.getByKeyOrValue;
import static com.pg.account.sharding.domain.model.account.CounterInfo.toCounterInfo;
import static com.pg.account.sharding.domain.model.account.DeviceInfo.toDeviceInfo;
import static com.pg.account.sharding.domain.model.account.ExtraAttributeItem.toExtraAttributeItem;
import static com.pg.account.sharding.infrastructure.client.address.Address.toAddress;
import static jodd.util.StringPool.COMMA;

/**
 * 注册参数组装
 *
 * @author xusheng
 * @date 2021/6/4 <br>
 */
@Component("RegisterAccountAssemblerV1")
public class RegisterAccountAssembler {

    private final ChannelDao channelDao;

    @Autowired
    public RegisterAccountAssembler(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 检查是否符合配置规定
     *
     * @param result 缓存结果
     */
    private static String registerCheck(String result, Integer registerType) {
        String typeValue;
        String limitValue;
        try {
            JSONObject jsonObject = parseObject(result);
            typeValue = jsonObject.get(TYPE).toString();
            switch (typeValue) {
                case CELLPHONE:
                    typeValue = MOBILE_TYPE;
                    break;
                case UNION_ID:
                    typeValue = UNION_ID_TYPE;
                    break;
                default:
                    break;
            }
            limitValue = jsonObject.get(LIMIT).toString();
            String gerValue = getByKeyOrValue(registerType.toString()).getValue();
            if (Arrays.stream(limitValue.split(COMMA)).noneMatch(value -> value.equals(gerValue))) {
                throw new BusinessException(ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getCode(), ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getV2Code(), ResultEnum.REGISTER_TYPE_CHOOSE_ERROR.getMessage());
            }
        } catch (JSONException | NullPointerException e) {
            throw new BusinessException(ResultEnum.SYSTEM_CONFIG_ERROR.getCode(), ResultEnum.SYSTEM_CONFIG_ERROR.getV2Code(), ResultEnum.SYSTEM_CONFIG_ERROR.getMessage());
        }
        return typeValue;
    }

    /**
     * 将入参转成account
     *
     * @param accountRegisterCommand accountRegisterCommand
     * @return com.pg.account.sharding.domain.model.account.Account
     * @author xusheng
     * @date 2021/6/4 12:19
     */
    public Account toAccount(AccountRegisterCommand accountRegisterCommand) {
        ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(accountRegisterCommand.getTenantId().toString(), accountRegisterCommand.getChannelId().toString());
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        Contact contact = new Contact();
        checkRegisterRoute(contact, accountRegisterCommand);
        Account.AccountBuilder accountBuilder = Account.AccountBuilder
                .anAccount()
                .tenantId(accountRegisterCommand.getTenantId().toString())
                .password(accountRegisterCommand.getPassword())
                .registration(accountRegisterCommand.getSource(), channel, accountRegisterCommand.getCustomer(), accountRegisterCommand.getRegStore(), LocalDateTime.now())
                .contact(contact)
                .counter(toCounterInfo(accountRegisterCommand.getCounter()))
                .address(toAddress(accountRegisterCommand.getAddresses()))
                .device(toDeviceInfo(accountRegisterCommand.getDevice()))
                .extraAttrs(toExtraAttributeItem(accountRegisterCommand.getAttrs()));
        if (Optional.ofNullable(accountRegisterCommand.getProfile()).isPresent()) {
            accountBuilder.birthday(accountRegisterCommand.getProfile().getBirthday())
                    .gender(accountRegisterCommand.getProfile().getGender())
                    .fullName(Optional.ofNullable(accountRegisterCommand.getAddresses()).filter(a -> !a.isEmpty()).map(addressCommands -> addressCommands.get(0).getFullName()).orElse(null))
                    .nickName(accountRegisterCommand.getProfile().getNickname());
        }
        return accountBuilder.build();
    }

    /**
     * 检查或获取路由
     *
     * @param contact                contact
     * @param accountRegisterCommand accountRegisterCommand
     */
    public void checkRegisterRoute(Contact contact, AccountRegisterCommand accountRegisterCommand) {
        switch (Optional.ofNullable(accountRegisterCommand.getRegisterRoute())
                .orElse(registerCheck(Optional
                                .ofNullable(CacheLocalConfigUtils.getUniqueRegistrationType(accountRegisterCommand.getTenantId()))
                                .orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_ERROR.getCode(), ResultEnum.SYSTEM_CONFIG_ERROR.getV2Code(), ResultEnum.SYSTEM_CONFIG_ERROR.getMessage()))
                        , 1))) {
            case MOBILE_TYPE:
                if (!StringValidUtil.isMobile(accountRegisterCommand.getUsername())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getCode(), "username不是手机格式");
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getCellphone).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getProfile().getCellphone())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getEmail).isPresent()) {
                    contact.specialEmail(accountRegisterCommand.getProfile().getEmail());
                }
                contact.specialMobile(accountRegisterCommand.getUsername());
                //将userName赋值到地址的手机号
                accountRegisterCommand.specifyAddressCellphone();
                break;
            case EMAIL_TYPE:
                if (!StringValidUtil.isEmail(accountRegisterCommand.getUsername())) {
                    throw new BusinessException(ResultEnum.INCORRECT_EMAIL.getCode(), ResultEnum.INCORRECT_EMAIL.getCode(), ResultEnum.INCORRECT_EMAIL.getMessage());
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getEmail).isPresent() && !accountRegisterCommand.getUsername().equals(accountRegisterCommand.getProfile().getEmail())) {
                    throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                }
                if (Optional.ofNullable(accountRegisterCommand.getProfile()).map(ProfileCommand::getCellphone).isPresent()) {
                    contact.specialMobile(accountRegisterCommand.getProfile().getCellphone());
                }
                contact.specialEmail(accountRegisterCommand.getUsername());
                break;
            default:
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
                // 将默认值替换成自定义的输出内容
        }
    }
}
