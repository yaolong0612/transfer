/*
 * Copyright (c) 2017 Baidu, Inc. All Rights Reserve.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.pg.account.infrastructure.component.uid.worker.dao;

import com.pg.account.infrastructure.component.uid.worker.entity.WorkerNodeEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * DAO for M_WORKER_NODE
 *
 * @author yutianbao
 */
@Repository
public class WorkerNodeDAO {

    @Autowired
    private WorkerNodeRepository workerNodeRepository;

    /**
     * Get {@link WorkerNodeEntity} by node host
     *
     * @param hostName host
     * @param port     port
     * @return WorkerNodeEntity
     */
    public WorkerNodeEntity getWorkerNodeByHostPort(@Param("host") String hostName, @Param("port") String port) {
        WorkerNodeEntity workerNodeEntity = workerNodeRepository.findAllByHostNameAndPort(hostName, port);
        return Optional.ofNullable(workerNodeEntity).orElse(null);
    }

    /**
     * Add {@link WorkerNodeEntity}
     *
     * @param workerNodeEntity workerNodeEntity
     */
    public void addWorkerNode(WorkerNodeEntity workerNodeEntity) {
        workerNodeRepository.save(workerNodeEntity);
    }

}
