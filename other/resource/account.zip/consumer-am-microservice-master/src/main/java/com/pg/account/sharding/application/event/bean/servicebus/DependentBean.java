package com.pg.account.sharding.application.event.bean.servicebus;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DependentBean implements Serializable {

    private static final long serialVersionUID = -7760873769079487752L;
    private String sqn;
    @JSONField(ordinal = 1)
    private String name;
    @JSONField(ordinal = 2)
    private String gender;
    @JSONField(ordinal = 3)
    private String birthdate;
    @JSONField(ordinal = 4)
    private String relation;

}
