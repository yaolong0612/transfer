package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * 注册渠道
 *
 * @author xusheng
 * @date 2021/6/11 11:16
 */
public interface TermsVersionDao extends JpaRepository<ShardTermsVersion, Long> {


    /**
     * 根据租户和渠道查询渠道信息
     *
     * @param tenantId tenantId
     * @return com.pg.account.sharding.infrastructure.jpa.config.ShardChannel
     * @author xusheng
     * @date 2021/6/11 11:18
     */
    List<ShardTermsVersion> findByTenantId(String tenantId);

    /**
     * 根据租户和状态查询订阅版本信息
     *
     * @param tenantId tenantId
     * @param status   状态
     * @return com.pg.account.sharding.infrastructure.jpa.config.ShardChannel
     * @author xusheng
     * @date 2021/6/11 11:18
     */
    ShardTermsVersion findByTenantIdAndStatus(String tenantId, byte status);

}
