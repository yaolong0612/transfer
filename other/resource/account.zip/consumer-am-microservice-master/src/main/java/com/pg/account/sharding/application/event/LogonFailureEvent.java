package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 * @date 2021-6-9
 */
@Getter
public class LogonFailureEvent extends ApplicationEvent {

    private static final long serialVersionUID = -7814936395585212304L;
    private Account account;

    public LogonFailureEvent(Object source) {
        super(source);
    }

    public LogonFailureEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }
}
