package com.pg.account.infrastructure.component.datastream.servicebus.bean;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * @author sunliang
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OptBean implements Serializable {

    private static final long serialVersionUID = -4191440200091658896L;
    @JSONField(name = "opt_id")
    private String optId;
    @JSONField(name = "opt_value")
    private String optValue;
    @JSONField(name = "opt_status")
    private String optStatus;
    @JSONField(name = "opt_version")
    private String optVersion;
    @JSONField(name = "prefered_contact")
    private String preferedContact;
    @JSONField(name = "opt_dateTime")
    private Timestamp optDateTime;
    @JSONField(name = "opt_create_datetime")
    private Timestamp optCreateDatetime;
    @JSONField(name = "opt_modify_datetime")
    private Timestamp optModifyDatetime;

}
