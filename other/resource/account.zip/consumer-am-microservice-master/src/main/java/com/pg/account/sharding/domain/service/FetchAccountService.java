package com.pg.account.sharding.domain.service;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.enums.AccountProfileEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.client.address.Address;
import com.pg.account.sharding.infrastructure.common.enums.QueryFieldEnum;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.counter.CounterDao;
import com.pg.account.sharding.infrastructure.jpa.counter.ShardCounter;
import com.pg.account.sharding.infrastructure.jpa.mapping.BindIdMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping;
import com.pg.account.sharding.infrastructure.jpa.profile.device.DeviceDao;
import com.pg.account.sharding.infrastructure.jpa.profile.device.ShardDevice;
import com.pg.account.sharding.infrastructure.jpa.profile.education.EducationDao;
import com.pg.account.sharding.infrastructure.jpa.profile.education.ShardEducation;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import com.pg.account.sharding.infrastructure.jpa.profile.humanrelation.HumanRelationDao;
import com.pg.account.sharding.infrastructure.jpa.profile.humanrelation.ShardHumanRelation;
import com.pg.account.sharding.infrastructure.jpa.profile.job.JobDao;
import com.pg.account.sharding.infrastructure.jpa.profile.job.ShardJob;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.ACCOUNT_NOT_EXIST;

/**
 * @author Jack
 * @date 2021/5/31 11:37
 */
@Service
@Slf4j
public class FetchAccountService {

    private final AccountRepository accountRepository;
    private final FetchMappingService fetchMappingService;
    private final FetchAclService fetchAclService;
    private final AccountInfoDao accountInfoDao;
    private final JobDao jobDao;
    private final EducationDao educationDao;
    private final HumanRelationDao humanRelationDao;
    private final ExtraAttributeDao extraAttributeDao;
    private final BindSocialAccountService bindSocialAccountService;
    private final CounterDao counterDao;
    private final FetchAddressService fetchAddressService;
    private final DeviceDao deviceDao;

    @Autowired
    public FetchAccountService(AccountRepository accountRepository,
                               FetchMappingService fetchMappingService,
                               FetchAclService fetchAclService,
                               AccountInfoDao accountInfoDao,
                               JobDao jobDao,
                               EducationDao educationDao,
                               HumanRelationDao humanRelationDao,
                               ExtraAttributeDao extraAttributeDao,
                               BindSocialAccountService bindSocialAccountService,
                               CounterDao counterDao,
                               FetchAddressService fetchAddressService,
                               DeviceDao deviceDao
    ) {
        this.fetchMappingService = fetchMappingService;
        this.accountRepository = accountRepository;
        this.fetchAclService = fetchAclService;
        this.accountInfoDao = accountInfoDao;
        this.jobDao = jobDao;
        this.educationDao = educationDao;
        this.humanRelationDao = humanRelationDao;
        this.extraAttributeDao = extraAttributeDao;
        this.bindSocialAccountService = bindSocialAccountService;
        this.counterDao = counterDao;
        this.fetchAddressService = fetchAddressService;
        this.deviceDao = deviceDao;
    }

    /**
     * 根据租户和会员号查询账号
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Account
     */
    public Account fetchAccountByTenantIdAndAccountId(String tenantId, String accountId) {
        return accountRepository.fetchAccountByTenantIdAndAccountId(tenantId, accountId);
    }

    /**
     * 根据租户和会员号查询有效的账号
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Account
     */
    public Account fetchActiveAccount(String tenantId, String accountId) {
        return accountRepository.fetchActiveAccountByTenantIdAndAccountId(tenantId, accountId);
    }

    public Account fetchAccountByTenantAndAccountId(String tenant, String accountId) {
        ShardAccountInfo accountInfo = accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenant, accountId);
        return Optional.ofNullable(accountInfo).map(ShardAccountInfo::builder).orElse(null);
    }

    /**
     * 根据租户、渠道、bindId和unionId查询账号信息（是queryAccount中bindIdAndUnionId查询类型）
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param unionId   unionId
     * @param bindId    bindId
     * @author xusheng
     * @date 2021/8/11 13:25
     */
    public JSONObject fetchAccountByTenantIdAndBind(String tenantId, String channelId, String unionId, String bindId) {
        String accountId = null;
        if (bindSocialAccountService.validateUnionIdConfigExisting(tenantId, channelId)) {
            if (StringUtils.isBlank(unionId)) {
                unionId = fetchAclService.fetchUnionId(tenantId, channelId, bindId);
            }
            String channelUnionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channelId);
            if (StringUtils.isNotBlank(unionId) && StringUtils.isNotBlank(channelUnionIdType)) {
                UnionIdMapping unionIdMapping = fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenantId, unionId, channelUnionIdType);
                if (Optional.ofNullable(unionIdMapping).isPresent()) {
                    accountId = unionIdMapping.getAccountId();
                }
            }
        }
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenantId, bindId, channelId);
        if (StringUtils.isBlank(accountId)) {
            if (!Optional.ofNullable(bindIdMapping).isPresent()) {
                throw new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(), ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), ResultEnum.BIND_ID_NOT_EXIST.getMessage());
            }
            accountId = bindIdMapping.getAccountId();
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("accountId", Optional.ofNullable(accountId).orElseThrow(() -> new BusinessException(ACCOUNT_NOT_EXIST.getCode(), ACCOUNT_NOT_EXIST.getV2Code(), ACCOUNT_NOT_EXIST.getMessage())));
        jsonObject.put("isBind", Optional.ofNullable(bindIdMapping).isPresent());
        return jsonObject;
    }

    /**
     * 根据租户、渠道和bindId或者unionId查询会员账号
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param unionId   unionId
     * @param bindId    bindId
     * @author xusheng
     * @date 2021/8/11 13:49
     */
    public JSONObject fetchAccountByTenantIdAndBindAndUnionId(String tenantId, String channelId, String unionId, String bindId) {
        String accountId = null;
        if (bindSocialAccountService.validateUnionIdConfigExisting(tenantId, channelId)) {
            try {
                if (StringUtils.isBlank(unionId)) {
                    unionId = fetchAclService.fetchUnionId(tenantId, channelId, bindId);
                }
            } catch (Exception e) {
                log.error("ACL error");
            }

            if (StringUtils.isNotBlank(unionId)) {
                String channelUnionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channelId)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
                UnionIdMapping unionIdMapping = fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenantId, unionId, channelUnionIdType);
                if (Optional.ofNullable(unionIdMapping).isPresent()) {
                    accountId = unionIdMapping.getAccountId();
                }
            }
        }
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenantId, bindId, channelId);
        if (StringUtils.isBlank(accountId)) {
            if (!Optional.ofNullable(bindIdMapping).isPresent()) {
                throw new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(), ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), ResultEnum.BIND_ID_NOT_EXIST.getMessage());
            }
            accountId = bindIdMapping.getAccountId();
        }
        accountId = Optional.ofNullable(accountId).orElseThrow(() -> new BusinessException(ACCOUNT_NOT_EXIST.getCode(), ACCOUNT_NOT_EXIST.getV2Code(), ACCOUNT_NOT_EXIST.getMessage()));
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("accountId", accountId);
        jsonObject.put("isBind", Optional.ofNullable(bindIdMapping).isPresent());
        return jsonObject;
    }

    public Account fetchAccountByTenantAndAccountId(String tenantId, String accountId, List<String> fields) {
        ShardAccountInfo accountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId))
                .orElseThrow(() ->
                        new BusinessException(
                                ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        ShardJob job = null;
        ShardEducation education = null;
        ShardHumanRelation humanRelation = null;
        ShardExtraAttribute extraAttribute = null;
        if (fields.stream().anyMatch(AccountProfileEnum.JOB.getMsg()::equals)) {
            job = jobDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(AccountProfileEnum.EDUCATION.getMsg()::equals)) {
            education = educationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(AccountProfileEnum.INTERPERSONAL_RELATIONSHIP.getMsg()::equals)) {
            humanRelation = humanRelationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(AccountProfileEnum.ATTRIBUTE.getMsg()::equals)) {
            extraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        UserAdditionalInfo userAdditionalInfo = new UserAdditionalInfo(
                Optional.ofNullable(education).map(ShardEducation::getEducationList).orElse(null),
                Optional.ofNullable(humanRelation).map(ShardHumanRelation::getHumanRelationList).orElse(null),
                Optional.ofNullable(job).map(ShardJob::getJobList).orElse(null),
                Optional.ofNullable(extraAttribute).map(ShardExtraAttribute::getExtraAttributeItemList).orElse(null), null);
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(accountId)
                .openUid(accountInfo.getOpenUid())
                .registration(accountInfo.getRegistration())
                .userBasicInfo(accountInfo.getUserBasicInfo())
                .userAdditionalInfo(userAdditionalInfo)
                .build();
    }

    /**
     * 通过fields查询相关个人信息
     *
     * @param account account
     * @param fields  fields
     * @return account
     */
    public Account fetchAccountByTenantAndAccountIdAndFields(Account account, List<String> fields) {
        String tenantId = account.getTenantId();
        String accountId = account.getAccountId();
        ShardJob job = null;
        ShardEducation education = null;
        ShardHumanRelation humanRelation = null;
        ShardExtraAttribute extraAttribute = null;
        ShardCounter counter = null;
        Address address = null;
        ShardDevice device = null;
//        效率不高 需要改进
        if (fields.stream().anyMatch(QueryFieldEnum.JOB.getMsg()::equals)) {
            job = jobDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.EDUCATION.getMsg()::equals)) {
            education = educationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.HUMAN_RELATIONSHIP.getMsg()::equals)) {
            humanRelation = humanRelationDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.ATTRIBUTE.getMsg()::equals)) {
            extraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.COUNTER.getMsg()::equals)) {
            counter = counterDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.DEVICE.getMsg()::equals)) {
            device = deviceDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        }
        if (fields.stream().anyMatch(QueryFieldEnum.ADDRESS.getMsg()::equals)) {
            address = fetchAddressService.fetchByAccountIdAndTenant(accountId, tenantId);
        }
        UserAdditionalInfo userAdditionalInfo = new UserAdditionalInfo(
                Optional.ofNullable(education).map(ShardEducation::getEducationList).orElse(null),
                Optional.ofNullable(humanRelation).map(ShardHumanRelation::getHumanRelationList).orElse(null),
                Optional.ofNullable(job).map(ShardJob::getJobList).orElse(null),
                Optional.ofNullable(extraAttribute).map(ShardExtraAttribute::getExtraAttributeItemList).orElse(null),
                Optional.ofNullable(device).map(ShardDevice::getDevice).orElse(null)
        );

        return Account.AccountBuilder
                .anAccount(account)
                .userAdditionalInfo(userAdditionalInfo)
                .counter(Optional.ofNullable(counter).map(ShardCounter::getCounter).orElse(null))
                .address(address)
                .build();
    }
}
