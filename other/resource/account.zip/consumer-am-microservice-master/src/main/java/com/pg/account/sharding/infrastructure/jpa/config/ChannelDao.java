package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * 注册渠道
 *
 * @author xusheng
 * @date 2021/6/11 11:16
 */
public interface ChannelDao extends JpaRepository<ShardChannel, Long> {


    /**
     * 根据租户和渠道查询渠道信息
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @return com.pg.account.sharding.infrastructure.jpa.config.ShardChannel
     * @author xusheng
     * @date 2021/6/11 11:18
     */
    ShardChannel findByTenantIdAndChannelId(String tenantId, String channelId);

    /**
     * 根据租户和公共账号查询渠道信息
     *
     * @param tenantId      tenantId
     * @param publicAccount publicAccount
     * @return com.pg.account.sharding.infrastructure.jpa.config.ShardChannel
     * @author xusheng
     * @date 2021/6/16 16:00
     */
    ShardChannel findByTenantIdAndPublicAccount(String tenantId, String publicAccount);

    /**
     * 通过tenant和unionType查询channel
     *
     * @param tenantId  tenantId
     * @param unionType unionType
     * @return list of shardChannel
     */
    List<ShardChannel> findByTenantIdAndUnionIdType(String tenantId, String unionType);

}
