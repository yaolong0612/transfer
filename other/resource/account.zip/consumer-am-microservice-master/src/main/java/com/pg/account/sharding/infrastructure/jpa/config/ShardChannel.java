package com.pg.account.sharding.infrastructure.jpa.config;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author wsq
 * @date
 */
@javax.persistence.Entity
@Table(name = "SHARD_CHANNEL")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardChannel extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 842298969687696924L;
    @Id
    private Long id;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "channel_id")
    private String channelId;
    @Column(name = "channel_label")
    private String channelLabel;
    @Column(name = "is_bind_id")
    private String isBindId;
    @Column(name = "brand_code")
    private String brandCode;
    @Column(name = "union_id_type")
    private String unionIdType;
    @Column(name = "description")
    private String description;
    @Column(name = "first_modify_award")
    private String firstModifyAward;
    @Column(name = "public_account")
    private String publicAccount;
    @Column(name = "migration_status")
    private String migrationStatus;
    @Column(name = "create_by")
    private String createBy;
    @Column(name = "modify_by")
    private String modifyBy;
    private Byte status;


}
