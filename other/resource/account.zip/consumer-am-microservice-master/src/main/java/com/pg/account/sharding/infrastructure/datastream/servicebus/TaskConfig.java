package com.pg.account.sharding.infrastructure.datastream.servicebus;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author LC
 */
@Configuration
public class TaskConfig {

    /**
     * core-pool-size: 250
     * keep-alive-seconds: 60
     * max-pool-size: 300
     * queue-capacity: 500
     *
     * @return Executor
     */
    @Bean("taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
        //线程池维护线程所允许的空闲时间
        pool.setKeepAliveSeconds(60);
        //核心线程池数
        pool.setCorePoolSize(60);
        // 最大线程
        pool.setMaxPoolSize(60);
        //队列容量
        pool.setQueueCapacity(40480);
        pool.setWaitForTasksToCompleteOnShutdown(true);
        //配置线程池中的线程的名称前缀
        pool.setThreadNamePrefix("am-sync-");

//        1. CallerRunsPolicy ：这个策略重试添加当前的任务，他会自动重复调用 execute() 方法，直到成功。
//        2. AbortPolicy ：对拒绝任务抛弃处理，并且抛出异常。
//        3. DiscardPolicy ：对拒绝任务直接无声抛弃，没有异常信息。
//        4. DiscardOldestPolicy ：对拒绝任务不抛弃，而是抛弃队列里面等待最久的一个线程，然后把拒绝任务加到队列。
        pool.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        pool.initialize();
        return pool;
    }

    /**
     * 该线程池用于删除数据
     *
     * @return Executor
     */
    @Bean("retentionExecutor")
    public Executor retentionExecutor() {
        ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
        //线程池维护线程所允许的空闲时间
        pool.setKeepAliveSeconds(60);
        //核心线程池数
        pool.setCorePoolSize(60);
        // 最大线程
        pool.setMaxPoolSize(60);
        //队列容量
        pool.setQueueCapacity(40480);
        pool.setWaitForTasksToCompleteOnShutdown(true);
        //配置线程池中的线程的名称前缀
        pool.setThreadNamePrefix("am-retention-");

//        1. CallerRunsPolicy ：这个策略重试添加当前的任务，他会自动重复调用 execute() 方法，直到成功。
//        2. AbortPolicy ：对拒绝任务抛弃处理，并且抛出异常。
//        3. DiscardPolicy ：对拒绝任务直接无声抛弃，没有异常信息。
//        4. DiscardOldestPolicy ：对拒绝任务不抛弃，而是抛弃队列里面等待最久的一个线程，然后把拒绝任务加到队列。
        pool.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        pool.initialize();
        return pool;
    }
}
