package com.pg.account.infrastructure.common.enums;


import java.util.Arrays;

/**
 * @author JackSun
 */

public enum AccountLogonTypeEnum {
    /**
     * 登录类型
     */
    SMS,
    PASSWORD;

    public static AccountLogonTypeEnum getByType(String type) {
        return Arrays.stream(AccountLogonTypeEnum.values())
                .filter(a -> a.name().equals(type))
                .findAny()
                .orElse(PASSWORD);
    }
}
