package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.service.annotation.IsValidOptId;

import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Valid;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.SYSTEM_CONFIG_NOT_EXIST;

/**
 * 注解校验实现类
 *
 * @author lfx
 * @date 2021/4/22 9:54
 */
@Slf4j
public class SubscriptionBaseValidator<T extends Annotation> implements ConstraintValidator<T, @Valid ShardSubscription> {


    protected Predicate<ShardSubscription> predicate = c -> true;

    @Override
    public boolean isValid(ShardSubscription shardSubscription, ConstraintValidatorContext constraintValidatorContext) {
        return predicate.test(shardSubscription);
    }

    public static class OptIdValid extends SubscriptionBaseValidator<IsValidOptId> {
        @Override
        public void initialize(IsValidOptId constraintAnnotation) {
            predicate = shardSubscription -> {
                boolean flag = true;
                // 先判断optId是否重复，不重复就判断是否存在
                if (Optional.ofNullable(shardSubscription).map(ShardSubscription::getSubscriptionList).isPresent()) {
                    List<String> optIdList = shardSubscription.getSubscriptionItemList().stream().map(SubscriptionItem::getOptId).distinct().collect(Collectors.toList());
                    //有重复的optId，则将状态改为false且不在判断optId是否存在
                    if (optIdList.size() != shardSubscription.getSubscriptionItemList().size()) {
                        flag = false;
                    } else {
                        String result = Optional.ofNullable(LocalCacheConfigUtils.getOptId(shardSubscription.getTenantId())).orElseThrow(() -> new BusinessException(SYSTEM_CONFIG_NOT_EXIST.getCode(), SYSTEM_CONFIG_NOT_EXIST.getV2Code(), SYSTEM_CONFIG_NOT_EXIST.getMessage()));
                        String[] x = result.split(COMMA);
                        for (SubscriptionItem subscriptionItem : shardSubscription.getSubscriptionItemList()) {
                            //这个非空判断是在会员注册或者注册绑定场景中可能存在不传订阅信息，但是订阅信息中会添加渠道
                            if (StringUtils.isNotBlank(subscriptionItem.getOptId())) {
                                //判断optId是否存在缓存配置中
                                flag = Arrays.stream(x).anyMatch(s -> s.equals(subscriptionItem.getOptId()));
                                //如果flag返回值为false,说明optId不存在缓存配置中，则跳出循环
                                if (!flag) {
                                    break;
                                }
                            }
                        }
                    }
                }
                return flag;
            };
        }
    }
}