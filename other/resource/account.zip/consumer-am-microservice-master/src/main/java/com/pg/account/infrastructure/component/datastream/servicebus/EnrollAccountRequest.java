package com.pg.account.infrastructure.component.datastream.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * <Description> 积分系统创建用户所需参数
 *
 * @author xusheng
 * @date 2019/11/14 <br>
 */
@ApiModel
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EnrollAccountRequest implements Serializable {
    private static final long serialVersionUID = 6135561657335095916L;

    @ApiModelProperty(value = "会员Id", example = "1234", required = true)
    @NotNull(message = "缺少会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;

    @ApiModelProperty(value = "渠道ID", example = "WECHAT", required = true)
    @NotNull(message = "channel is not exist")
    private String channel;

    @ApiModelProperty(value = "绑定Id", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;

    @ApiModelProperty(value = "品牌", example = "PAMPERS", required = true)
    @NotNull(message = "缺少品牌")
    private String brand;

    @ApiModelProperty(value = "注册来源(ML:大陆，TW:台湾，HK:香港)", example = "ML", required = true)
    @NotNull(message = "缺少注册来源(ML:大陆，TW:台湾，HK:香港)")
    private String region;

    @ApiModelProperty(value = "注册类型(REGISTER:注册，BINDING:绑定)", example = "BINDING", required = true)
    private String registerType;

    @ApiModelProperty(value = "宝宝生日年月，格式：yyyyMM", example = "199310")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String babyBirthYearAndMonth;

}
