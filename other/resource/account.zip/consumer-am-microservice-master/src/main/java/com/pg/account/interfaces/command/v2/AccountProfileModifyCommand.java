package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.interfaces.command.CounterCommand;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.Set;

/**
 * @author Jack Sun
 * @date 2020-7-24 17:19
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountProfileModifyCommand implements Serializable {

    private static final long serialVersionUID = 1341393883442417516L;
    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
    @ApiModelProperty(value = "User Profile Information", name = "profile")
    @Valid
    private ProfileCommand profile;
    @ApiModelProperty(value = "Address Information", name = "address")
    @Valid
    private AddressCommand address;
    @ApiModelProperty(value = "User Attribute Information Collection", name = "attributes")
    @Valid
    private Set<AttributeCommand> attributes;
    @ApiModelProperty(value = "Counter Information", name = "counter")
    private CounterCommand counter;
    @ApiModelProperty(value = "User Job Information Collection", name = "jobs")
    @Valid
    private Set<JobCommand> jobs;
    @ApiModelProperty(value = "User education Information Collection", name = "educations")
    @Valid
    private Set<EducationCommand> educations;
    @ApiModelProperty(value = "User interpersonalRelationship Information Collection", name = "interpersonalRelationships")
    @Valid
    private Set<InterpersonalRelationshipCommand> interpersonalRelationships;

    public void specifyAddressFullName(String fullName) {
        if (null == this.address) {
            this.address = new AddressCommand();
        }
        if (StringUtils.isBlank(this.address.getFullName())) {
            this.address.setFullName(fullName);
        }
    }
}
