package com.pg.account.sharding.application.event.listener;

import cn.com.pg.paas.stream.framework.StreamTemplate;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.pg.account.infrastructure.common.enums.ConfigStatusEnum;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.application.event.*;
import com.pg.account.sharding.application.event.bean.*;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.infrastructure.datastream.servicebus.bean.OptBean;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.config.*;
import com.pg.account.sharding.infrastructure.tablestorage.EventHubEntity;
import com.pg.account.sharding.infrastructure.tablestorage.EventHubFaultTolerantEntity;
import com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import static com.alibaba.fastjson.JSON.toJSONString;
import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static java.lang.String.valueOf;

/**
 * @author Jack
 * @date 2021-05-06 13:38
 */
@Component("shardingDataManagementPlatformNotifierListener")
@Slf4j
public class DataManagementPlatformNotifierListener {

    public static final String ATTR_ID = "113000001";
    public static final String PAMPERS = "10003";
    public static final String UPDATED = "U";
    public static final String DELETED = "D";
    public static final String AM_REG_PROFILE_EVENT_TYPE = "amRegProfileEventType";
    public static final String AM_COUNTER_EVENT_TYPE = "amCounterEventType";
    public static final String AM_CHANGE_OPT_EVENT_TYPE = "amChangeOptEventType";
    public static final String AM_BIND_SOCIAL_ACCOUNT_EVENT_TYPE = "amBindSocialAccountEventType";
    public static final String AM_DEL_BIND_SOCIAL_ACCOUNT_EVENT_TYPE = "amDelBindSocialAccountEventType";
    public static final String AM_MODIFY_ATTRIBUTES_EVENT_TYPE = "amModifyAttributesEventType";
    public static final String AM_MODIFY_PROFILE_EVENT_TYPE = "amModifyProfileEventType";
    public static final String STATUS_I = "I";
    public static final String STATUS_O = "O";
    public static final String TRUE1 = "true";
    public static final String FALSE1 = "false";
    public static final String EVENT_HUB_FAULT_TOLERANT = "EventHubFaultTolerant";

    private final StreamTemplate streamTemplate;
    private final ShardSocialAccountRepository socialAccountRepository;
    private final ChannelDao channelDao;
    private final TermsDao termsDao;
    private final TermsVersionDao termsVersionDao;
    private final UidGenerator uidGenerator;
    private final AccountInfoDao accountInfoDao;
    private final TableStorageUtils<EventHubEntity> eventHubUtil;
    private final TableStorageUtils<EventHubFaultTolerantEntity> faultTolarentUtil;


    @Value("${event_hub.amUpdateAttrEventTypeId}")
    private String amUpdateAttrEventTypeId;
    @Value("${event_hub.amRegProfileEventTypeId}")
    private String amRegProfileEventTypeId;
    @Value("${event_hub.retryCount}")
    private int retryCount;
    @Value("${event_hub.amDelBindSocialAccountEventTypeId}")
    private String amDelBindSocialAccountEventTypeId;
    @Value("${event_hub.amCounterEventTypeId}")
    private String amCounterEventTypeId;
    @Value("${event_hub.amChangeOptEventTypeId}")
    private String amChangeOptEventTypeId;
    @Value("${event_hub.amUpdateProfileEventTypeId}")
    private String amUpdateProfileEventTypeId;
    @Value("${event_hub.amBindSocialAccountEventTypeId}")
    private String amBindSocialAccountEventTypeId;

    public DataManagementPlatformNotifierListener(StreamTemplate streamTemplate,
                                                  ShardSocialAccountRepository socialAccountRepository,
                                                  ChannelDao channelDao,
                                                  TermsDao termsDao,
                                                  TermsVersionDao termsVersionDao,
                                                  UidGenerator uidGenerator,
                                                  AccountInfoDao accountInfoDao,
                                                  TableStorageUtils<EventHubEntity> eventHubUtil,
                                                  TableStorageUtils<EventHubFaultTolerantEntity> faultTolarentUtil
    ) {
        this.streamTemplate = streamTemplate;
        this.socialAccountRepository = socialAccountRepository;
        this.channelDao = channelDao;
        this.termsDao = termsDao;
        this.termsVersionDao = termsVersionDao;
        this.uidGenerator = uidGenerator;
        this.accountInfoDao = accountInfoDao;
        this.eventHubUtil = eventHubUtil;
        this.faultTolarentUtil = faultTolarentUtil;
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SignUpEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            List<SocialAccountItem> socialAccountItems = Optional.ofNullable(event.getShardSocialAccount()).map(ShardSocialAccount::getSocialAccountList).filter(a -> !a.removeIf(b -> StringUtils.isBlank(b.getBindId()) && StringUtils.isBlank(b.getUnionId()))).orElse(null);
            Optional.ofNullable(event.getShardSocialAccount()).ifPresent(bind -> {
                if (Optional.ofNullable(socialAccountItems).isPresent()) {
                    bind.setSocialAccountList(socialAccountItems);
                    this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
                }
            });
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(RegisterBindEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.regProfileEvent(event.getAccount(), event.getShardSubscription());
            this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ActiveEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.activeAccountEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(InActiveEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.inActiveAccountEvent(event.getAccount());
        }
    }


    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(BindingEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            List<SocialAccountItem> socialAccountItems = Optional.ofNullable(event.getShardSocialAccount()).map(ShardSocialAccount::getSocialAccountList).filter(a -> a.stream().anyMatch(b -> StringUtils.isNotBlank(b.getBindId()) || StringUtils.isNotBlank(b.getUnionId()))).orElse(null);
            Optional.ofNullable(event.getShardSocialAccount()).ifPresent(bind -> {
                if (Optional.ofNullable(socialAccountItems).isPresent()) {
                    bind.setSocialAccountList(socialAccountItems);
                    this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
                }
            });
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UnBindingEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.deletedBindSocialAccountEvent(event.getShardSocialAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateProfileEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateProfileEvent(event.getAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
            this.updateCounterEvent(event.getAccount());
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateCounterEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateCounterEvent(event.getAccount());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateSubscriptionEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(SmsUpdateSubscriptionEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateAttributeEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(UpdateAttributeToDMPEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), UPDATED);
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(DeleteAttributeEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateAttributeEvent(event.getAccount(), DELETED);
        }
    }

    @Async("threadPoolTaskExecutor")
    @EventListener
    public void onApplicationEvent(ConflictEvent event) {
        if (Optional.ofNullable(event).isPresent()) {
            this.updateProfileEvent(event.getAccount());
            this.bindSocialAccountEvent(event.getAccount(), event.getShardSocialAccount());
            this.updateSubscriptionEvent(event.getShardSubscription());
        }
    }

    /**
     * RegProfileEvent 消息发送，发给DMP
     *
     * @param account account对象
     */
    private void regProfileEvent(Account account, ShardSubscription shardSubscription) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        String errorMessage = null;
        String regProfile = null;
        String eventTypeId = amRegProfileEventTypeId;
        RegProfileEventBean regProfileEventBean = new RegProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                Optional.ofNullable(account.getAccountId()).ifPresent(regProfileEventBean::setMemberId);
                regProfileEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                regProfileEventBean.inserted();
                Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getBrandCode).ifPresent(regProfileEventBean::setRegistrationBrand);
                Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelLabel).ifPresent(regProfileEventBean::setRegistrationChannel);
                Optional.ofNullable(account.getRegistration()).map(Registration::getSource).ifPresent(regProfileEventBean::setRegistrationSource);
                Optional.ofNullable(account.getRegistration()).map(Registration::getRegisterTime).ifPresent(t -> {
                    regProfileEventBean.setRegistrationDatetime(Timestamp.valueOf(t));
                    // TODO: 2022/2/9 是否需要
                    regProfileEventBean.setCreateDatetime(Timestamp.valueOf(t));
                });
                //2019年3月6日添加regStore和customer
                Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getRegStore).ifPresent(regProfileEventBean::setRegStore);
                Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getName).ifPresent(regProfileEventBean::setCustomer);
                Optional.ofNullable(account.getUserBasicInfo()).ifPresent(basicInfo -> {
                    //NickName 无业务场景使用，不需要传到DMP，在2018年7月13日确定设为null值
                    regProfileEventBean.setNickName(null);
                    regProfileEventBean.setGender(basicInfo.getGender());
                    regProfileEventBean.setBirthdate(formatBirthday(basicInfo));
                    //Email 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
                    regProfileEventBean.setEmail(null);
                    Optional.ofNullable(basicInfo.getContact()).map(Contact::getMobile).ifPresent(mobile -> {
                        regProfileEventBean.setMobilePhone(DigestUtils.md5Hex(mobile));
                        //添加SHA256加密和手机前6位
                        regProfileEventBean.setMobileSha256(DigestUtils.sha256Hex(mobile));
                        regProfileEventBean.setMobileHead(mobile.substring(0, 7));
                    });
                });
                //初始化device信息
                this.setDeviceInfo(account, regProfileEventBean);
                this.setAddressInfo(account, regProfileEventBean);
                regProfileEventBean.setJobs(this.setJobInfo(account));
                regProfileEventBean.setEducations(this.setEducationInfo(account));
                regProfileEventBean.setInterpersonalRelationshipBeans(this.setInterPersonalRelationShipInfo(account));
                Optional.ofNullable(account.getUserAdditionalInfo())
                        .map(UserAdditionalInfo::getExtraAttributeList)
                        .filter(extraAttributeItems -> !extraAttributeItems.isEmpty())
                        .ifPresent(extraAttributeItems -> {
                            regProfileEventBean.setAttributes(attributeBeans(extraAttributeItems));
                            regProfileEventBean.setDependents(this.babyInfo(account.getTenantId(), extraAttributeItems));
                        });
                Optional.ofNullable(shardSubscription)
                        .map(ShardSubscription::getSubscriptionList)
                        .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                        .ifPresent(subscriptionItemList -> regProfileEventBean.setOpts(optBeans(shardSubscription.getTenantId(), subscriptionItemList)));
                regProfile = toJSONString(regProfileEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                result = streamTemplate.send(eventTypeId, regProfile);
            } catch (Exception e) {
                log.warn("regProfileEvent error", e);
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_REG_PROFILE_EVENT_TYPE, regProfile, valueOf(result), errorMessage, valueOf(count));

    }

    /**
     * @param basicInfo basicInfo
     * @return String
     */
    private String formatBirthday(UserBasicInfo basicInfo) {
        return StringUtils.isNotBlank(basicInfo.getBirthday()) ? DateUtil.toString(DateUtil.formDate(basicInfo.getBirthday(), YYYY_MM_DD), YYYY_MM) : null;
    }

    /**
     * 初始化工作信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<JobBean> setJobInfo(Account account) {
        List<JobBean> jobBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getJobList)
                .filter(jobItems -> !jobItems.isEmpty())
                .ifPresent(jobItems -> jobItems.forEach(jobItem -> {
                    String relationshipName = Optional.ofNullable(jobItem.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).orElse(null);
                    JobBean jobBean = new JobBean();
                    jobBean.setRelationshipName(relationshipName);
                    Optional.ofNullable(jobItem.getRelation()).map(Relation::getSequence).ifPresent(jobBean::setRelationshipSequence);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getProvince).ifPresent(jobBean::setProvince);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getCity).ifPresent(jobBean::setCity);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(jobBean::setDistrict);
                    Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(jobBean::setUnitAddress);
                    Optional.ofNullable(jobItem.getName()).ifPresent(jobBean::setUnitName);
                    Optional.ofNullable(jobItem.getCategory()).ifPresent(jobBean::setUnitCategory);
                    Optional.ofNullable(jobItem.getProfession()).ifPresent(jobBean::setProfession);
                    jobBean.setCreateTime(Optional.ofNullable(jobItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    jobBean.setModifyTime(Optional.ofNullable(jobItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    jobBeans.add(jobBean);
                }));
        return jobBeans;
    }


    /**
     * 初始化监护人信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<InterpersonalRelationshipBean> setInterPersonalRelationShipInfo(Account account) {
        List<InterpersonalRelationshipBean> interpersonalRelationshipBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getHumanRelationList)
                .filter(humanRelationItems -> !humanRelationItems.isEmpty())
                .ifPresent(humanRelationItems -> humanRelationItems.forEach(humanRelationItem -> {
                    String relationshipName = humanRelationItem.getRelation().getRelationType().getRelationName();
                    String cellphone = humanRelationItem.getPerson().getContact().getMobile();
                    if (StringUtils.isNotBlank(cellphone)) {
                        cellphone = DigestUtils.md5Hex(cellphone);
                    }
                    InterpersonalRelationshipBean interpersonalRelationshipBean = new InterpersonalRelationshipBean();
                    interpersonalRelationshipBean.setRelationshipName(relationshipName);
                    interpersonalRelationshipBean.setCellphone(cellphone);
                    Optional.ofNullable(humanRelationItem.getRelation()).map(Relation::getSequence).ifPresent(interpersonalRelationshipBean::setRelationshipSequence);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getFullName).ifPresent(interpersonalRelationshipBean::setFullName);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getBirthday).ifPresent(interpersonalRelationshipBean::setBirthday);
                    Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getGender).ifPresent(interpersonalRelationshipBean::setGender);
                    Optional.ofNullable(humanRelationItem.getGuardian()).ifPresent(interpersonalRelationshipBean::setGuardian);
                    Optional.ofNullable(humanRelationItem.getCreateTime()).ifPresent(t -> interpersonalRelationshipBean.setCreateTime(Timestamp.valueOf(t)));
                    Optional.ofNullable(humanRelationItem.getUpdateTime()).ifPresent(t -> interpersonalRelationshipBean.setModifyTime(Timestamp.valueOf(t)));
                    interpersonalRelationshipBean.setCreateTime(Optional.ofNullable(humanRelationItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    interpersonalRelationshipBean.setModifyTime(Optional.ofNullable(humanRelationItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    interpersonalRelationshipBeans.add(interpersonalRelationshipBean);
                }));
        return interpersonalRelationshipBeans;
    }


    /**
     * 初始化教育信息
     *
     * @param account 数据聚合根
     * @author yj
     * @date 2021/6/15 14:24
     */
    private List<EducationBean> setEducationInfo(Account account) {
        List<EducationBean> educationBeans = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getEducationList)
                .filter(educationItems -> !educationItems.isEmpty())
                .ifPresent(educationItems -> educationItems.forEach(educationItem -> {
                    // 这里修改是因为现在不通过redis获取
                    String relationshipName = Optional.ofNullable(educationItem.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).orElse(null);
                    EducationBean educationBean = new EducationBean();
                    educationBean.setRelationshipName(relationshipName);
                    Optional.ofNullable(educationItem.getRelation()).map(Relation::getSequence).ifPresent(educationBean::setRelationshipSequence);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getProvince).ifPresent(educationBean::setProvince);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(educationBean::setSchoolAddress);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getCity).ifPresent(educationBean::setCity);
                    Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(educationBean::setDistrict);
                    Optional.ofNullable(educationItem.getName()).ifPresent(educationBean::setSchoolName);
                    Optional.ofNullable(educationItem.getCategory()).ifPresent(educationBean::setSchoolCategory);
                    Optional.ofNullable(educationItem.getGrade()).ifPresent(educationBean::setGrade);
                    Optional.ofNullable(educationItem.getClassName()).ifPresent(educationBean::setClassName);
                    Optional.ofNullable(educationItem.getCollege()).ifPresent(educationBean::setCollege);
                    Optional.ofNullable(educationItem.getMajor()).ifPresent(educationBean::setMajor);
                    Optional.ofNullable(educationItem.getDegree()).ifPresent(educationBean::setDegree);
                    educationBean.setCreateTime(Optional.ofNullable(educationItem.getCreateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    educationBean.setModifyTime(Optional.ofNullable(educationItem.getUpdateTime()).map(Timestamp::valueOf).orElse(Timestamp.valueOf(LocalDateTime.now())));
                    educationBeans.add(educationBean);
                }));
        return educationBeans;
    }

    /**
     * 初始化device信息
     *
     * @param account             account对象
     * @param regProfileEventBean regProfileEventBean对象
     */
    private void setDeviceInfo(Account account, RegProfileEventBean regProfileEventBean) {
        //DeviceID 2018年11月26日添加 2019年3月6日重新设计
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getDevice)
                .ifPresent(deviceInfo -> {
                    regProfileEventBean.setDeviceIdType(deviceInfo.getOs());
                    // TODO: 2022/2/9 是否需要改为直接赋值deviceId
                    if (StringUtils.isNotBlank(deviceInfo.getDeviceId())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getDeviceId());
                    } else if (StringUtils.isNotBlank(deviceInfo.getIdfa())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getIdfa());
                    } else if (StringUtils.isNotBlank(deviceInfo.getImei())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getImei());
                    } else if (StringUtils.isNotBlank(deviceInfo.getOaid())) {
                        regProfileEventBean.setDeviceId(deviceInfo.getOaid());
                    }
                });
    }


    /**
     * 初始化device信息
     *
     * @param account               updatedBindSocialAccountEvent对象
     * @param bindSocialAccountBean bindSocialAccountBean对象
     */
    private void setDeviceInfo(Account account, BindSocialAccountBean bindSocialAccountBean) {
        //DeviceID 2018年11月26日添加 2019年3月6日重新设计 2020年5月18日支持绑定收集
        Optional.ofNullable(account)
                .map(Account::getUserAdditionalInfo)
                .map(UserAdditionalInfo::getDevice)
                .ifPresent(deviceInfo -> {
                    bindSocialAccountBean.setDeviceIdType(deviceInfo.getOs());
                    if (StringUtils.isNotBlank(deviceInfo.getDeviceId())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getDeviceId());
                    } else if (StringUtils.isNotBlank(deviceInfo.getIdfa())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getIdfa());
                    } else if (StringUtils.isNotBlank(deviceInfo.getImei())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getImei());
                    } else if (StringUtils.isNotBlank(deviceInfo.getOaid())) {
                        bindSocialAccountBean.setDeviceId(deviceInfo.getOaid());
                    }
                });
    }


    /**
     * 初始化地址信息
     *
     * @param account             account对象
     * @param regProfileEventBean regProfileEventBean对象
     */
    private void setAddressInfo(Account account, RegProfileEventBean regProfileEventBean) {
        Optional.ofNullable(account.getAddress()).ifPresent(address -> {
            //fullName 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            regProfileEventBean.setFullName(null);
            //address 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            regProfileEventBean.setAddress(null);
//            if (Optional.ofNullable(address.getAddressCode()).isPresent()) {
//                regProfileEventBean.setAddressId(Long.parseLong(address.getAddressCode()));
//            }
            regProfileEventBean.setProvince(address.getProvince());
            regProfileEventBean.setCity(address.getCity());
            regProfileEventBean.setDistrict(address.getDistrict());
            regProfileEventBean.setZipcode(address.getPostcode());
        });
    }


    /**
     * 订阅信息组装
     *
     * @param subscriptionItemList 账号聚合参数
     * @return List<OptBean>
     */
    private List<OptBean> optBeans(String tenantId, List<SubscriptionItem> subscriptionItemList) {
        List<OptBean> opts = new ArrayList<>();
        for (SubscriptionItem subscriptionItem : subscriptionItemList) {
            OptBean optBean = new OptBean();
            optBean.setOptId(subscriptionItem.getOptId());
            optBean.setOptValue(subscriptionItem.getOptName());
            Optional.ofNullable(subscriptionItem.getTermsList())
                    .filter(termList -> !termList.isEmpty())
                    .ifPresent(terms -> terms.forEach(term -> {
                        optBean.setOptVersion(term.getTermVersion());
                        //termsId不为空且版本号为空则根据termId去查询terms表中的版本号
                        if (StringUtils.isBlank(subscriptionItem.getTermsList().get(0).getTermVersion())
                                && StringUtils.isNotBlank(subscriptionItem.getTermsList().get(0).getTermId())) {
                            Optional<ShardTerms> shardTermsOptional = termsDao.findById(Long.valueOf(subscriptionItem.getTermsList().get(0).getTermId()));
                            shardTermsOptional.ifPresent(shardTerms -> optBean.setOptVersion(shardTerms.getTermsVersion()));
                        }
                    }));
            optBean.setOptStatus(subscriptionItem.getOptStatus());
            Optional.ofNullable(subscriptionItem.getOptTime()).ifPresent(t -> optBean.setOptDateTime(Timestamp.valueOf(t)));
            Optional.ofNullable(subscriptionItem.getCreateTime()).ifPresent(t -> optBean.setOptCreateDatetime(Timestamp.valueOf(t)));
            Optional.ofNullable(subscriptionItem.getUpdateTime()).ifPresent(t -> optBean.setOptModifyDatetime(Timestamp.valueOf(t)));
            if (StringUtils.isBlank(optBean.getOptVersion())) {
                //termsId为空且版本号也为空则将最新的版本号同步给DMP
                ShardTermsVersion shardTermsVersion = termsVersionDao.findByTenantIdAndStatus(tenantId, ConfigStatusEnum.ACTIVE.getCode());
                optBean.setOptVersion(shardTermsVersion.getTermsVersionLabel());
            }
            String replace = optBean.getOptVersion().replace("-", "0");
            optBean.setOptVersion(replace);
            opts.add(optBean);
        }
        return opts;
    }


    /**
     * 宝宝信息
     *
     * @param tenantId            tenantId
     * @param extraAttributeItems extraAttributeItems
     * @return DependentBean对象集合
     */
    private List<DependentBean> babyInfo(String tenantId, List<ExtraAttributeItem> extraAttributeItems) {
        List<DependentBean> dependentBeans = new ArrayList<>();
        Optional<ExtraAttributeItem> attributesOptional = extraAttributeItems.stream().filter(attributes -> ATTR_ID.equals(attributes.getAttrId()) && PAMPERS.equals(tenantId)).findFirst();
        if (attributesOptional.isPresent()) {
            List<BabyInfoBean> babyInfoBeanList = JSON.parseArray(attributesOptional.get().getAttrValue(), BabyInfoBean.class);
            int i = 0;
            for (BabyInfoBean babyInfoBean : babyInfoBeanList) {
                i++;
                DependentBean dependentBean = new DependentBean();
                dependentBean.setDependentSqn(valueOf(i));
                dependentBean.setDependentName(babyInfoBean.getName());
                dependentBean.setDependentGender(babyInfoBean.getGender());
                if (StringUtils.isNotBlank(babyInfoBean.getBirthday())) {
                    String babyBirthday = null;
                    try {
                        babyBirthday = DateUtil.toString(DateUtil.formDate(babyInfoBean.getBirthday(), YYYY_MM_DD), YYYY_MM);
                    } catch (Exception e) {
                        log.warn("InsertedRegProfileEvent babyBirthday DateFormat error{}", babyInfoBean.getBirthday());
                    }
                    dependentBean.setDependentBirthdate(babyBirthday);
                }
                dependentBean.setDependentRelationship(babyInfoBean.getRelation());
                dependentBeans.add(dependentBean);
            }
        }
        return dependentBeans;
    }


    /**
     * 属性信息组装
     *
     * @param extraAttributeItems extraAttributeItems
     * @return AttributeBean对象集合
     */
    private List<AttributeBean> attributeBeans(List<ExtraAttributeItem> extraAttributeItems) {
        List<AttributeBean> attributeBeans = new ArrayList<>();
        Long seq = 1L;
        for (ExtraAttributeItem extraAttributeItem : extraAttributeItems) {
            AttributeBean attributeBean = new AttributeBean();
            attributeBean.setAttributeId(extraAttributeItem.getAttrId());
            attributeBean.setAttributeSqn(seq);
            seq++;
            attributeBean.setAttributeValue(extraAttributeItem.getAttrValue());
            attributeBeans.add(attributeBean);
        }
        return attributeBeans;
    }


    /**
     * updateProfileEvent 将完善好的会员信息发送发给DMP
     *
     * @param account account对象
     */
    private void updateProfileEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        String errorMessage = null;
        String regProfile = null;
        String eventTypeId = amUpdateProfileEventTypeId;
        UpdateProfileEventBean updateProfileEventBean = new UpdateProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                updateProfileEventBean.setMemberId(account.getAccountId());
                updateProfileEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                updateProfileEventBean.updated();
                Optional.ofNullable(account.getUserBasicInfo()).ifPresent(basicInfo -> {
                    //NickName 无业务场景使用，不需要传到DMP，在2018年7月13日确定设为null值
                    updateProfileEventBean.setNickName(null);
                    //Email 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
                    updateProfileEventBean.setEmail(null);
                    updateProfileEventBean.setGender(basicInfo.getGender());
                    updateProfileEventBean.setBirthdate(formatBirthday(basicInfo));
                    String mobile = basicInfo.getContact().getMobile();
                    if (StringUtils.isNotBlank(mobile)) {
                        updateProfileEventBean.setMobilePhone(DigestUtils.md5Hex(mobile));
                        //添加SHA256加密和手机前6位,在2020年03月11日添加
                        updateProfileEventBean.setMobileSha256(DigestUtils.sha256Hex(mobile));
                        updateProfileEventBean.setMobileHead(mobile.substring(0, 7));
                    }
                });
                this.setAddressInfo(account, updateProfileEventBean);
                updateProfileEventBean.setJobs(this.setJobInfo(account));
                updateProfileEventBean.setEducations(this.setEducationInfo(account));
                updateProfileEventBean.setInterpersonalRelationshipBeans(this.setInterPersonalRelationShipInfo(account));
                updateProfileEventBean.setUpdateTime(DateUtil.getCurrentTimestamp());
                regProfile = toJSONString(updateProfileEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                result = streamTemplate.send(eventTypeId, regProfile);
            } catch (Exception e) {
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_MODIFY_PROFILE_EVENT_TYPE, regProfile, valueOf(result), errorMessage, valueOf(count));
    }

    /**
     * 初始化地址信息
     *
     * @param account                account对象
     * @param updateProfileEventBean updateProfileEventBean对象
     */
    private void setAddressInfo(Account account, UpdateProfileEventBean updateProfileEventBean) {
        Optional.ofNullable(account.getAddress()).ifPresent(address -> {
            //fullName 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            updateProfileEventBean.setFullName(null);
            //address 属于PII主数据，不需要传到DMP，在2018年7月11日确定设为null值
            updateProfileEventBean.setAddress(null);
            updateProfileEventBean.setProvince(address.getProvince());
            updateProfileEventBean.setCity(address.getCity());
            updateProfileEventBean.setDistrict(address.getDistrict());
            updateProfileEventBean.setZipcode(address.getPostcode());
        });
    }

    /**
     * counterEvent 消息发送，发给DMP
     *
     * @param account account对象
     */
    private void updateCounterEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getCounter())
                .ifPresent(counterInfo -> {
                    boolean result = false;
                    String errorMessage = null;
                    String counterStr = null;
                    String eventTypeId = amCounterEventTypeId;
                    CounterBean counterBean = new CounterBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            counterBean.setMemberId(account.getAccountId());
                            counterBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                            counterBean.updated();
                            this.getCounterInfo(counterInfo, counterBean);
                            counterStr = toJSONString(counterBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                            result = streamTemplate.send(eventTypeId, counterStr);
                        } catch (Exception e) {
                            log.warn("UpdatedCounterEvent error", e);
                            errorMessage = e.getMessage();
                        }
                    }
                    if (!result) {
                        --count;
                    }
                    writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_COUNTER_EVENT_TYPE, counterStr, valueOf(result), errorMessage, valueOf(count));
                });

    }


    /**
     * 将柜台信息转成DMP需要的柜台格式
     *
     * @param counterInfo 柜台
     * @param counterBean DMP需要的柜台格式
     * @author xusheng
     * @date 2020/9/28 17:32
     */
    private void getCounterInfo(CounterInfo counterInfo, CounterBean counterBean) {
        Optional.ofNullable(counterInfo).ifPresent(counterInfo1 -> {
            counterBean.setRegCounter(counterInfo1.getRegCounterCode());
            counterBean.setMainCounter(counterInfo1.getMainCounterCode());
            counterBean.setPickupCounter(counterInfo1.getPickupCounterCode());
            counterBean.setCrmPickupCounter(counterInfo1.getCrmPickupCounterCode());
            counterBean.setFirstPurchaseCounter(counterInfo1.getFirstPurchaseCounterCode());
            counterBean.setFirstPurchaseTime(counterInfo1.getFirstPurchaseTime());
            counterBean.setOfflineFirstPurchaseCounter(counterInfo1.getOfflineFirstPurchaseCounterCode());
            counterBean.setOfflineLastPurchaseCounter(counterInfo1.getLastPurchaseCounterCode());
            counterBean.setMemberBelongToCounter(counterInfo1.getBelongToCounterCode());
            Optional.ofNullable(counterInfo1.getCreateTime()).ifPresent(t -> counterBean.setCreateDatetime(Timestamp.valueOf(t)));
            Optional.ofNullable(counterInfo1.getUpdateTime()).ifPresent(t -> counterBean.setModifyDatetime(Timestamp.valueOf(t)));
        });
    }


    /**
     * modifyAttrEvent 更新用户属性消息发送，发给DMP
     *
     * @param account account对象
     */
    private void updateAttributeEvent(Account account, String flag) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getExtraAttributeList)
                .filter(extraAttributeItems -> !extraAttributeItems.isEmpty())
                .ifPresent(extraAttributeItems -> {
                    boolean result = false;
                    String errorMessage = null;
                    String updateAttr = null;
                    String eventTypeId = amUpdateAttrEventTypeId;
                    UpdateAttrEventBean updateAttrEventBean = new UpdateAttrEventBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            updateAttrEventBean.setMemberId(account.getAccountId());
                            updateAttrEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                            if (UPDATED.equals(flag)) {
                                updateAttrEventBean.updated();
                            } else {
                                updateAttrEventBean.deleted();
                            }
                            updateAttrEventBean.setAttributes(attributeBeans(extraAttributeItems));
                            updateAttrEventBean.setDependents(this.babyInfo(account.getTenantId(), extraAttributeItems));
                            updateAttr = toJSONString(updateAttrEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                            result = streamTemplate.send(eventTypeId, updateAttr);
                        } catch (Exception e) {
                            log.warn("modifyAttrEvent error{}", e.getMessage());
                            errorMessage = e.getMessage();
                        }
                    }
                    if (!result) {
                        --count;
                    }
                    writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_MODIFY_ATTRIBUTES_EVENT_TYPE, updateAttr, valueOf(result), errorMessage, valueOf(count));
                });

    }

    /**
     * ChangeOptEvent 更新用户订阅信息消息发送，发给DMP
     *
     * @param shardSubscription shardSubscription
     */
    private void updateSubscriptionEvent(ShardSubscription shardSubscription) {
        if (!Optional.ofNullable(shardSubscription).isPresent()) {
            return;
        }
        Optional.ofNullable(shardSubscription.getSubscriptionList())
                .filter(subscriptionItemList -> !subscriptionItemList.isEmpty())
                .ifPresent(subscriptionItemList -> {
                    boolean result = false;
                    String errorMessage = null;
                    String changeOptStr = null;
                    String eventTypeId = amChangeOptEventTypeId;
                    ChangeOptEventBean changeOptEventBean = new ChangeOptEventBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            changeOptEventBean.setMemberId(shardSubscription.getAccountId());
                            changeOptEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(shardSubscription.getTenantId()));
                            changeOptEventBean.updated();
                            changeOptEventBean.setOpts(optBeans(shardSubscription.getTenantId(), subscriptionItemList));
                            changeOptStr = toJSONString(changeOptEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                            result = streamTemplate.send(eventTypeId, changeOptStr);
                        } catch (Exception e) {
                            log.warn("UpdatedChangeOptEvent error", e);
                            errorMessage = e.getMessage();
                        }
                    }
                    if (!result) {
                        --count;
                    }
                    writeLog(shardSubscription.getTenantId(), shardSubscription.getAccountId(), eventTypeId, AM_CHANGE_OPT_EVENT_TYPE, changeOptStr, valueOf(result), errorMessage, valueOf(count));
                });

    }

    /**
     * 获取会员绑定信息
     *
     * @param tenantId 租户
     * @param memberId 会员Id
     * @author xusheng
     * @date 2020/8/21 16:49
     */
    private List<SocialAccountBean> socialAccountBeanList(Long tenantId, String memberId) {
        List<SocialAccountBean> socialAccountBeanList = new ArrayList<>();
        ShardSocialAccount shardSocialAccount = socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenantId.toString(), memberId);
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .filter(socialAccountList -> !socialAccountList.isEmpty())
                .ifPresent(socialAccountList -> socialAccountList.forEach(socialAccount -> {
                    ShardChannel channel = channelDao.findByTenantIdAndChannelId(tenantId.toString(), socialAccount.getChannel().getChannelId());
                    SocialAccountBean socialAccountBean = comboSocialAccountBean(socialAccount, channel, STATUS_I);
                    if (null != socialAccount.getUnionId()) {
                        socialAccountBean.setUnionId(socialAccount.getUnionId());
                    }
                    socialAccountBeanList.add(socialAccountBean);
                }));
        return socialAccountBeanList;
    }

    /**
     * 组合SocialAccountBean
     *
     * @param socialAccountItem socialAccount
     * @param channel           channel
     * @return SocialAccountBean
     */
    private SocialAccountBean comboSocialAccountBean(SocialAccountItem socialAccountItem, ShardChannel channel, String status) {
        SocialAccountBean socialAccountBean = new SocialAccountBean();
        socialAccountBean.setBindChannel(channel.getChannelLabel());
        socialAccountBean.setBindBrand(channel.getBrandCode());
        socialAccountBean.setPublicAccount(channel.getPublicAccount());
        socialAccountBean.setSocialAccountId(socialAccountItem.getBindId());
        socialAccountBean.setBindDatetime(Timestamp.valueOf(socialAccountItem.getBindTime()));
        socialAccountBean.setBindCreateDatetime(Timestamp.valueOf(socialAccountItem.getCreateTime()));
        socialAccountBean.setBindModifyDatetime(Timestamp.valueOf(socialAccountItem.getUpdateTime()));
        socialAccountBean.setBindStatus(status);
        return socialAccountBean;
    }


    /**
     * 获取会员绑定信息
     *
     * @param tenantId              tenantId
     * @param socialAccountItemList socialAccountItemList
     * @author xusheng
     * @date 2020/8/21 16:49
     */
    private List<SocialAccountBean> socialAccountBeanList(String tenantId, List<SocialAccountItem> socialAccountItemList, String status) {
        List<SocialAccountBean> socialAccountBeanList = new ArrayList<>();
        socialAccountItemList.forEach(socialAccountItem -> {
            if (Optional.ofNullable(socialAccountItem).isPresent()) {
                ShardChannel channel = channelDao.findByTenantIdAndChannelId(tenantId, socialAccountItem.getChannelId());
                SocialAccountBean socialAccountBean = comboSocialAccountBean(socialAccountItem, channel, status);
                if (StringUtils.isNotBlank(channel.getUnionIdType())) {
                    socialAccountBean.setUnionId(socialAccountItem.getUnionId());
                }
                socialAccountBeanList.add(socialAccountBean);
            }
        });
        return socialAccountBeanList;
    }

    /**
     * bindSocialAccountEvent 用户社交账号绑定信息消息发送，发给DMP
     *
     * @param account account对象
     */
    private void bindSocialAccountEvent(Account account, ShardSocialAccount shardSocialAccount) {
        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
            return;
        }
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .filter(socialAccountItemList -> !socialAccountItemList.isEmpty())
                .ifPresent(socialAccountItemList -> {
                    boolean result = false;
                    String errorMessage = null;
                    String socialAccountStr = null;
                    String eventTypeId = amBindSocialAccountEventTypeId;
                    BindSocialAccountBean bindSocialAccountBean = new BindSocialAccountBean();
                    int count = 0;
                    while (!result) {
                        ++count;
                        if (count > retryCount) {
                            break;
                        }
                        try {
                            Optional.ofNullable(account)
                                    // 判断userBasicInfo是否存在 如果存在使用封装的account中的userBasic，如果不存在查询数据库的accountInfo中的userBasicInfo（绑定的时候没有将userBasicInfo封装到account）
                                    .map(a -> {
                                        UserBasicInfo userBasicInfo = a.getUserBasicInfo();
                                        if (!Optional.ofNullable(userBasicInfo).isPresent()) {
                                            ShardAccountInfo shardAccountInfo = accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
                                            userBasicInfo = shardAccountInfo.getUserBasicInfo();
                                        }
                                        return userBasicInfo;
                                    })
                                    .map(UserBasicInfo::getContact)
                                    .map(Contact::getMobile)
                                    .ifPresent(s -> bindSocialAccountBean.setMobileNo(DigestUtils.md5Hex(s)));
                            //添加设备信息
                            this.setDeviceInfo(account, bindSocialAccountBean);
                            bindSocialAccountBean.setMemberId(shardSocialAccount.getAccountId());
                            bindSocialAccountBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(shardSocialAccount.getTenantId()));
                            bindSocialAccountBean.updated();
                            bindSocialAccountBean.setSocialAccountInfo(socialAccountBeanList(shardSocialAccount.getTenantId(), socialAccountItemList, STATUS_I));
                            socialAccountStr = toJSONString(bindSocialAccountBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                            result = streamTemplate.send(eventTypeId, socialAccountStr);
                        } catch (Exception e) {
                            log.warn("InsertedBindSocialAccountEvent error", e);
                            errorMessage = e.getMessage();
                        }
                    }
                    if (!result) {
                        --count;
                    }
                    writeLog(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId(), eventTypeId, AM_BIND_SOCIAL_ACCOUNT_EVENT_TYPE, socialAccountStr, valueOf(result), errorMessage, valueOf(count));

                });
    }


    /**
     * deletedBindSocialAccountEvent 用户社交账号解绑信息消息发送，发给DMP
     *
     * @param shardSocialAccount account对象
     */
    private void deletedBindSocialAccountEvent(ShardSocialAccount shardSocialAccount) {
        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
            return;
        }
        List<SocialAccountItem> socialAccountItemList = shardSocialAccount.getSocialAccountList();
        if (!Optional.ofNullable(socialAccountItemList).isPresent() || socialAccountItemList.isEmpty()) {
            return;
        }
        boolean result = false;
        String errorMessage = null;
        String bindSocialAccount = null;
        String eventTypeId = amDelBindSocialAccountEventTypeId;
        BindSocialAccountBean bindSocialAccountBean = new BindSocialAccountBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                bindSocialAccountBean.setMemberId(shardSocialAccount.getAccountId());
                bindSocialAccountBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(shardSocialAccount.getTenantId()));
                bindSocialAccountBean.deleted();
                bindSocialAccountBean.setSocialAccountInfo(socialAccountBeanList(shardSocialAccount.getTenantId(), socialAccountItemList, STATUS_O));
                bindSocialAccount = toJSONString(bindSocialAccountBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                result = streamTemplate.send(eventTypeId, bindSocialAccount);
            } catch (Exception e) {
                log.warn("DeletedBindSocialAccountEvent error", e);
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        if (Optional.ofNullable(bindSocialAccountBean.getMemberId()).isPresent()) {
            writeLog(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId(), eventTypeId, AM_DEL_BIND_SOCIAL_ACCOUNT_EVENT_TYPE, bindSocialAccount, valueOf(result), errorMessage, valueOf(count));
        }

    }


    /**
     * Active account
     *
     * @param account account
     */
    public void activeAccountEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        String errorMessage = null;
        String regProfile = null;
        String eventTypeId = amRegProfileEventTypeId;
        RegProfileEventBean regProfileEventBean = new RegProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                regProfileEventBean.setMemberId(account.getAccountId());
                regProfileEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                regProfileEventBean.updated();
                regProfile = toJSONString(regProfileEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                result = streamTemplate.send(eventTypeId, regProfile);
            } catch (Exception e) {
                log.warn("DeletedRegProfileEvent error", e);
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_REG_PROFILE_EVENT_TYPE, regProfile, valueOf(result), errorMessage, valueOf(count));
    }


    /**
     * InActive account
     *
     * @param account account
     */
    public void inActiveAccountEvent(Account account) {
        if (!Optional.ofNullable(account).isPresent()) {
            return;
        }
        boolean result = false;
        String errorMessage = null;
        String regProfile = null;
        String eventTypeId = amRegProfileEventTypeId;
        RegProfileEventBean regProfileEventBean = new RegProfileEventBean();
        int count = 0;
        while (!result) {
            ++count;
            if (count > retryCount) {
                break;
            }
            try {
                regProfileEventBean.setMemberId(account.getAccountId());
                regProfileEventBean.setMarketingProgramId(LocalCacheConfigUtils.getMarketingProgramId(account.getTenantId()));
                regProfileEventBean.deleted();
                regProfile = toJSONString(regProfileEventBean, SerializerFeature.WriteNullStringAsEmpty, SerializerFeature.WriteNullListAsEmpty);
                result = streamTemplate.send(eventTypeId, regProfile);
            } catch (Exception e) {
                log.warn("DeletedRegProfileEvent error", e);
                errorMessage = e.getMessage();
            }
        }
        if (!result) {
            --count;
        }
        writeLog(account.getTenantId(), account.getAccountId(), eventTypeId, AM_REG_PROFILE_EVENT_TYPE, regProfile, valueOf(result), errorMessage, valueOf(count));
    }

    /**
     * 存储到Ts
     *
     * @param tenantId     tenantId
     * @param accountId    accountId
     * @param eventTypeId  eventTypeId
     * @param eventType    eventType
     * @param eventMessage eventMessage
     * @param status       status
     * @param errorMessage errorMessage
     * @param retryCount   retryCount
     */
    private void writeLog(String tenantId, String accountId, String eventTypeId, String eventType, String eventMessage, String status, String errorMessage, String retryCount) {
        Calendar now = Calendar.getInstance();
        EventHubEntity eventHubEntity = new EventHubEntity(String.valueOf(System.currentTimeMillis()), String.valueOf(uidGenerator.getUid()), tenantId, accountId, eventTypeId, eventMessage, errorMessage, status, retryCount, FALSE1, String.valueOf(LocalDateTime.now()));
        try {
            int month = now.get(Calendar.MONTH) + 1;
            String str = PRODUCER_EVENT_HUB + eventType + now.get(Calendar.YEAR) + (month < 10 ? "0" + month : month);
            String tableName = str.replace("_", "");
            eventHubUtil.createTableIfNotExist(tableName);
            eventHubUtil.save(tableName, eventHubEntity);
            String faultTolerantTable = EVENT_HUB_FAULT_TOLERANT;
            EventHubFaultTolerantEntity eventHubFaultTolerantEntity = faultTolarentUtil.get(faultTolerantTable, EventHubFaultTolerantEntity.class, PRODUCER_EVENT_HUB, tableName);
            if (!Optional.ofNullable(eventHubFaultTolerantEntity).isPresent()) {
                eventHubFaultTolerantEntity = new EventHubFaultTolerantEntity(PRODUCER_EVENT_HUB, tableName, TRUE1, TRUE1, String.valueOf(LocalDateTime.now()));
                faultTolarentUtil.save(faultTolerantTable, eventHubFaultTolerantEntity);
            } else {
                if (FALSE1.equals(status)) {
                    if (TRUE1.equals(eventHubFaultTolerantEntity.getTableStatus())) {
                        eventHubFaultTolerantEntity.setTableStatus(FALSE1);
                    }
                    if (TRUE1.equals(eventHubFaultTolerantEntity.getTableRetryStatus())) {
                        eventHubFaultTolerantEntity.setTableRetryStatus(FALSE1);
                    }
                    faultTolarentUtil.save(faultTolerantTable, eventHubFaultTolerantEntity);
                }
            }
        } catch (Exception e) {
            log.error("TB存储失败:", e);
        }
    }
}
