package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.interfaces.command.SignUpCommand;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author lfx
 * @date 2022-2-8
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = AtLeastOneParam.SignUpCommandValidator.class)
public @interface AtLeastOneParam {
    String message() default "mobile,bindId,unionId最少传入两项参数";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class SignUpCommandValidator implements ConstraintValidator<AtLeastOneParam, @Valid SignUpCommand> {

        @Override
        public boolean isValid(SignUpCommand signUpCommand, ConstraintValidatorContext constraintValidatorContext) {
            int paramNum = 0;
            if (signUpCommand.getMobile() != null) {
                paramNum++;
            }
            if (signUpCommand.getBindId() != null) {
                paramNum++;
            }
            if (signUpCommand.getUnionId() != null) {
                paramNum++;
            }
            return paramNum > 1;
        }
    }
}
