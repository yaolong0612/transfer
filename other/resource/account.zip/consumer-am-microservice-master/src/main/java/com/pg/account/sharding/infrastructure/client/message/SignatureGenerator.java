package com.pg.account.sharding.infrastructure.client.message;

import org.springframework.util.DigestUtils;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * SMS签名
 *
 * @author JackSun
 */
public class SignatureGenerator {

    private SignatureGenerator() {
    }

    /**
     * 生成签名
     *
     * @param apiKey    apiKey
     * @param apiSecret apiSecret
     * @param timeStamp timeStamp
     * @return String
     */
    public static String generateSignature(String apiKey, String apiSecret, String timeStamp) {
        String encryptStr = "apiKey=" + apiKey + "&apiSecret=" + apiSecret + "&timestamp=" + timeStamp;
        return DigestUtils.md5DigestAsHex(encryptStr.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * 生成签名
     *
     * @param dataMap   dataMap
     * @param apiSecret apiSecret
     * @return String
     */
    public static String generateApiSecret(Map<String, Object> dataMap, String apiSecret) {
        List<Map.Entry<String, Object>> infoIds = new ArrayList<>(dataMap.entrySet());
        infoIds.sort(Map.Entry.comparingByKey());
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Object> infoId : infoIds) {
            if ("signature".equals(infoId.getKey())) {
                continue;
            }
            if ("paramEntityList".equals(infoId.getKey()) && null != infoId.getValue()) {
                List<Map<String, Object>> list = (List) infoId.getValue();
                if (!list.isEmpty()) {
                    StringBuilder psb = new StringBuilder();
                    int j = 0;
                    for (Map<String, Object> map : list) {
                        psb.append('{');
                        int i = 0;
                        for (Map.Entry<String, Object> entity : map.entrySet()) {
                            psb.append(entity.getKey()).append('=').append(entity.getValue());
                            i++;
                            if (i == 1) {
                                psb.append('&');
                            }
                        }
                        psb.append('}');
                        j++;
                        if (j < list.size()) {
                            psb.append(',');
                        }
                    }
                    String encryptPsb = psb.toString();
                    sb.append('&').append(infoId.getKey()).append('=').append('[').append(encryptPsb).append(']');
                } else {
                    // key=value
                    String id = infoId.toString();
                    sb.append('&').append(id);
                }

            } else {
                // key=value
                String id = infoId.toString();
                sb.append('&').append(id);
            }
        }
        sb.append(apiSecret);
        String encryptStr = sb.substring(1);
        String resultStr = encryptStr.replace(" ", "");
        return DigestUtils.md5DigestAsHex(resultStr.getBytes(StandardCharsets.UTF_8));
    }
}
