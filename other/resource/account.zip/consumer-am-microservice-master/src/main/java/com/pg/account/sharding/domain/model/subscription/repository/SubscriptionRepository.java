package com.pg.account.sharding.domain.model.subscription.repository;

import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author yj
 */
public interface SubscriptionRepository extends JpaRepository<ShardSubscription, Long> {

    /**
     * 通过usersId查询SubscriptionInfo
     *
     * @param tenantId tenantId
     * @param accountId  accountId
     * @return SubscriptionInfo
     */
    ShardSubscription findByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);

    /**
     * 根据租户和会员删除
     *
     * @param tenantId   tenantId
     * @param accountId accountId
     */
    @Modifying
    @Transactional
    void deleteByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);
}
