package com.pg.account.sharding.domain.model.account.repository;

import com.pg.account.sharding.domain.model.account.Account;

/**
 * @author Jack
 * @date 2021/5/31 13:39
 */
public interface AccountRepository {

    /**
     * 根据accountId查询accountInfo
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Account
     */
    Account fetchAccountByTenantIdAndAccountId(String tenantId, String accountId);

    /**
     * 保存账号
     *
     * @param account account
     * @author xusheng
     * @date 2021/6/4 14:56
     */
    void save(Account account);


    /**
     * 保存accountInfo
     *
     * @param account account
     */
    void saveAccountInfo(Account account);

    /**
     * 保存accountInfo 判断mapping
     * @param account account
     */
    void saveAccountInfoAndMapping(Account account);


    /**
     * 根据accountId查询accountInfo
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Account
     */
    Account fetchActiveAccountByTenantIdAndAccountId(String tenantId, String accountId);
    /**
     * 根据accountId查询accountInfo
     *
     * @param tenant  tenant
     * @param accountId accountId
     * @return Account
     */
    Account fetchAccountByTenantAndAccountId(String tenant, String accountId);
}
