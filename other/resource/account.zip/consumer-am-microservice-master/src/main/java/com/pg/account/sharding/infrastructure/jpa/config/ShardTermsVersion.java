package com.pg.account.sharding.infrastructure.jpa.config;

import com.pg.account.sharding.infrastructure.jpa.shared.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author JackSun
 * @date 3/6/17
 */
@javax.persistence.Entity
@Table(name = "SHARD_TERMS_VERSION")
@Data
@DynamicUpdate
@DynamicInsert
@NoArgsConstructor
@AllArgsConstructor
public class ShardTermsVersion extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -5651951988733521643L;

    @Id
    private Long id;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "channel_id")
    private String channelId;
    @Column(name = "terms_title")
    private String termsTitle;
    @Column(name = "terms_content")
    private String termsContent;
    @Column(name = "terms_version")
    private String termsVersionLabel;
    @Column(name = "terms_of_use")
    private String termsOfUse;
    @Column(name = "terms_privacy_policy")
    private String termsPrivacyPolicy;
    @Column(name = "create_by")
    private String createBy;
    @Column(name = "modify_by")
    private String modifyBy;
    private Byte status;
    @Column(name = "effective_time")
    private Timestamp effectiveTime;

}
