package com.pg.account.sharding.infrastructure.client.address;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * AddressFeignClient
 *
 * @author Jack Sun
 * @date 2019-6-20 13:31
 */
@FeignClient(name = "cms-address-micro-service")
public interface AddressServiceClient {


    /**
     * 调用Address Micro新增地址信息
     *
     * @param queryAddressRequest 查询地址的标识
     * @return result返回参
     */
    @PostMapping(value = "/AddressServiceRest/queryAddress", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> queryAddress(@RequestBody QueryAddressRequest queryAddressRequest);

    /**
     * 存储会员主地址
     * 没有新增，有就更新
     *
     * @param storeAddressRequest 地址信息
     * @return result返回参
     */
    @PostMapping(value = "/AddressServiceRest/modifyAddress", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> store(@RequestBody StoreAddressRequest storeAddressRequest);
}
