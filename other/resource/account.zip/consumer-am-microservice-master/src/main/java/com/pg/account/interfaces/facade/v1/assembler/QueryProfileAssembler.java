package com.pg.account.interfaces.facade.v1.assembler;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Sets;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.interfaces.command.QueryProfileCommand;
import com.pg.account.interfaces.dto.AttrDTO;
import com.pg.account.interfaces.dto.BindDTO;
import com.pg.account.interfaces.dto.CounterDTO;
import com.pg.account.interfaces.dto.QueryProfileDTO;
import com.pg.account.interfaces.dto.v2.*;
import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * @author lfx
 * @date 2021/6/7 16:39
 */
@Component
public class QueryProfileAssembler {

    public static final String ACCOUNT = "account";
    public static final String SOCIAL_ACCOUNT = "socialAccount";
    public static final String SUBSCRIPTION = "subscription";
    public static final String IS_BIND = "isBind";
    private final FetchMappingService fetchMappingService;

    @Autowired
    public QueryProfileAssembler(FetchMappingService fetchMappingService) {
        this.fetchMappingService = fetchMappingService;
    }

    public static QueryProfileDTO fromAccountDTO(JSONObject jsonObject) {
        Account account = jsonObject.getObject(ACCOUNT, Account.class);
        ShardSocialAccount socialAccount = jsonObject.getObject(SOCIAL_ACCOUNT, ShardSocialAccount.class);
        ShardSubscription subscription = jsonObject.getObject(SUBSCRIPTION, ShardSubscription.class);
        QueryProfileDTO queryProfileDTO = new QueryProfileDTO();
        queryProfileDTO.setIsModifyPhone(false);
        queryProfileDTO.setMemberId(account.getAccountId());

        queryProfileDTO.setCellphone(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).orElse(null));
        queryProfileDTO.setEmail(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getEmail).orElse(null));
        queryProfileDTO.setNickname(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getNickName).orElse(null));
        queryProfileDTO.setGender(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getGender).orElse(null));
        queryProfileDTO.setBirthday(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getBirthday).orElse(null));
        queryProfileDTO.setSource(Optional.ofNullable(account.getRegistration()).map(Registration::getSource).orElse(null));
        queryProfileDTO.setRegistrationDate(String.valueOf(Optional.ofNullable(account.getRegistration()).map(Registration::getRegisterTime).map(date -> DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(date)).orElse(null)));
        List<SubscriptionDTO> subscriptionDTOList = new ArrayList<>();
        Optional.ofNullable(subscription)
                .ifPresent(subs -> subs.getSubscriptionList()
                        .forEach(sub -> {
                            SubscriptionDTO subscriptionDTO = sub.build();
                            subscriptionDTOList.add(subscriptionDTO);
                        }));
        queryProfileDTO.setSubscriptions(subscriptionDTOList.stream().sorted(Comparator.comparing(SubscriptionDTO::getOptId, Comparator.nullsLast(String::compareTo))).collect(Collectors.toList()));
        List<com.pg.account.interfaces.dto.AddressDTO> addressDTOList = new ArrayList<>();
        Optional.ofNullable(account.getAddress()).ifPresent(address -> addressDTOList.add(address.build()));
        queryProfileDTO.setAddresses(addressDTOList);
        ArrayList<AttrDTO> attrs = new ArrayList<>();
        Optional.ofNullable(account.getUserAdditionalInfo())
                .map(UserAdditionalInfo::getExtraAttributeList)
                .filter(e -> !e.isEmpty())
                .ifPresent(attr -> attr.forEach(a -> {
                    AttrDTO attrDTO = a.build();
                    attrs.add(attrDTO);
                }));
        queryProfileDTO.setAttrs(attrs.stream().sorted(Comparator.comparing(AttrDTO::getAttrId, Comparator.nullsLast(String::compareTo))).collect(Collectors.toList()));
        ArrayList<BindDTO> binds = new ArrayList<>();
        Optional.ofNullable(socialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .filter(s -> !s.isEmpty())
                .ifPresent(social -> socialAccount.getSocialAccountList()
                        .forEach(s -> binds.add(s.build())));
        List<BindDTO> bindDTOList = binds.stream().sorted(Comparator.comparing(BindDTO::getChannelId, Comparator.nullsLast(Long::compareTo))).collect(Collectors.toList());
        queryProfileDTO.setBinds(bindDTOList);
        queryProfileDTO.setCounter(Optional.ofNullable(account.getCounter()).map(CounterInfo::builder).orElse(new CounterDTO()));
        boolean isBind = false;
        if (jsonObject.containsKey(IS_BIND)) {
            isBind = jsonObject.getBoolean(IS_BIND);
        }
        queryProfileDTO.setIsBind(isBind);
        return queryProfileDTO;
    }

    public static AccountDTO fromAccountDtoV2(JSONObject jsonObject) {
        Account account = jsonObject.getObject(ACCOUNT, Account.class);
        AccountDTO accountDTO = new AccountDTO();
        accountDTO.setOpenId(account.getOpenUid());
        accountDTO.setSource(Optional.ofNullable(account.getRegistration()).map(Registration::getSource).orElse(null));
        accountDTO.setRegistrationDate(String.valueOf(Optional.ofNullable(account.getRegistration()).map(Registration::getRegisterTime).orElse(null)));
        accountDTO.setRegStore(Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getRegStore).orElse(null));
        accountDTO.setCustomer(Optional.ofNullable(account.getRegistration()).map(Registration::getCustomer).map(Customer::getName).orElse(null));
        ProfileDTO profile = getProfileDTO(account);
        accountDTO.setProfile(profile);
        AddressDTO address = getAddressDTO(account);
        accountDTO.setAddress(address);
        accountDTO.setCounter(getCounter(account));
        if (Optional.ofNullable(account.getUserAdditionalInfo()).isPresent()) {
            HashSet<AttrDTO> attributes = getAttrDTOS(account);
            accountDTO.setAttributes(attributes);
            HashSet<JobDTO> jobs = getJobDtoList(account);
            accountDTO.setJobs(jobs);
            HashSet<EducationDTO> educations = getEducationDtoList(account);
            accountDTO.setEducations(educations);
            HashSet<InterpersonalRelationshipDTO> interpersonalRelationships = getInterpersonalRelationshipDtoList(account);
            accountDTO.setInterpersonalRelationships(interpersonalRelationships);
        }
        return accountDTO;

    }

    /**
     * 添加isBind是否为true判断
     *
     * @param bindDTOList         bindDTOList
     * @param queryProfileCommand queryProfileCommand
     * @return boolean
     * @author xusheng
     * @date 2021/8/4 16:00
     */
    private static boolean toIsBind(List<BindDTO> bindDTOList, QueryProfileCommand queryProfileCommand) {
        AtomicBoolean flag = new AtomicBoolean(false);
        if (StringUtils.isNotBlank(queryProfileCommand.getBindId())) {
            Optional.ofNullable(bindDTOList)
                    .filter(bindDTOs -> !bindDTOs.isEmpty())
                    .ifPresent(bindDTOs -> bindDTOs.forEach(bindDTO -> {
                        if (queryProfileCommand.getBindId().equals(bindDTO.getBindId())) {
                            flag.set(true);
                        }
                    }));
        }
        return flag.get();
    }

    private static HashSet<InterpersonalRelationshipDTO> getInterpersonalRelationshipDtoList(Account account) {
        HashSet<InterpersonalRelationshipDTO> interpersonalRelationships = Sets.newHashSet();
        Optional.ofNullable(account.getUserAdditionalInfo().getHumanRelationList()).ifPresent(human -> human.forEach(h -> {
            InterpersonalRelationshipDTO interpersonalRelationshipDTO = new InterpersonalRelationshipDTO();
            Optional.of(h.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationCode).ifPresent(code -> interpersonalRelationshipDTO.setRelationshipId(code.toString()));
            Optional.of(h.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).ifPresent(interpersonalRelationshipDTO::setRelationshipName);
            Optional.of(h.getRelation()).map(Relation::getSequence).ifPresent(interpersonalRelationshipDTO::setRelationshipSequence);
            Optional.ofNullable(h.getPerson()).ifPresent(p -> {
                interpersonalRelationshipDTO.setFullName(p.getFullName());
                interpersonalRelationshipDTO.setBirthday(p.getBirthday());
                interpersonalRelationshipDTO.setGender(p.getGender());
                interpersonalRelationshipDTO.setCellphone(Optional.ofNullable(p.getContact()).map(Contact::getMobile).orElse(null));
            });
            interpersonalRelationshipDTO.setGuardian(h.getGuardian());
            interpersonalRelationships.add(interpersonalRelationshipDTO);
        }));
        return interpersonalRelationships;
    }

    private static HashSet<EducationDTO> getEducationDtoList(Account account) {
        HashSet<EducationDTO> educations = Sets.newHashSet();
        Optional.ofNullable(account.getUserAdditionalInfo().getEducationList()).ifPresent(educationItems -> educationItems.forEach(e -> {
            EducationDTO educationDTO = new EducationDTO();
            Optional.of(e.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationCode).ifPresent(code -> educationDTO.setRelationshipId(code.toString()));
            Optional.of(e.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).ifPresent(educationDTO::setRelationshipName);
            Optional.of(e.getRelation()).map(Relation::getSequence).ifPresent(educationDTO::setRelationshipSequence);
            Optional.ofNullable(e.getAddress()).ifPresent(a -> {
                educationDTO.setProvince(a.getProvince());
                educationDTO.setCity(a.getCity());
                educationDTO.setDistrict(a.getDistrict());
                educationDTO.setSchoolAddress(a.getAddressInfo());
            });
            educationDTO.setSchoolName(e.getName());
            educationDTO.setSchoolCategory(e.getCategory());
            educationDTO.setGrade(e.getGrade());
            educationDTO.setClassName(e.getClassName());
            educationDTO.setDegree(e.getDegree());
            educationDTO.setAdmissionTime(e.getAdmissionTime());
            educationDTO.setGraduationTime(e.getGraduationTime());
            educations.add(educationDTO);
        }));
        return educations;
    }

    private static HashSet<JobDTO> getJobDtoList(Account account) {
        HashSet<JobDTO> jobs = Sets.newHashSet();
        Optional.ofNullable(account.getUserAdditionalInfo().getJobList()).ifPresent(job -> job.forEach(
                j -> {
                    JobDTO jobDTO = new JobDTO();
                    Optional.of(j.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationCode).ifPresent(code -> jobDTO.setRelationshipId(code.toString()));
                    Optional.of(j.getRelation()).map(Relation::getRelationType).map(RelationType::getRelationName).ifPresent(jobDTO::setRelationshipName);
                    Optional.of(j.getRelation()).map(Relation::getSequence).ifPresent(jobDTO::setRelationshipSequence);
                    Optional.ofNullable(j.getAddress()).ifPresent(a -> {
                        jobDTO.setProvince(a.getProvince());
                        jobDTO.setCity(a.getCity());
                        jobDTO.setDistrict(a.getDistrict());
                        jobDTO.setUnitAddress(a.getAddressInfo());
                    });
                    jobDTO.setUnitName(j.getName());
                    jobDTO.setUnitCategory(j.getCategory());
                    jobDTO.setProfession(j.getProfession());
                    jobs.add(jobDTO);
                }
        ));
        return jobs;
    }

    private static HashSet<AttrDTO> getAttrDTOS(Account account) {
        HashSet<AttrDTO> attributes = Sets.newHashSet();
        Optional.ofNullable(account.getUserAdditionalInfo().getExtraAttributeList()).ifPresent(extra -> extra.forEach(e -> {
            AttrDTO attrDTO = new AttrDTO();
            attrDTO.setAttrId(e.getAttrId());
            attrDTO.setAttrVal(e.getAttrValue());
            attributes.add(attrDTO);
        }));
        return attributes;
    }

    private static CounterDTO getCounter(Account account) {
        if (Optional.ofNullable(account.getCounter()).isPresent()) {
            CounterDTO counter = new CounterDTO();
            counter.setRegCounterCode(account.getCounter().getRegCounterCode());
            counter.setRegCounterName(account.getCounter().getRegCounterName());
            counter.setMainCounterCode(account.getCounter().getMainCounterCode());
            counter.setMainCounterName(account.getCounter().getMainCounterName());
            counter.setPickupCounterCode(account.getCounter().getPickupCounterCode());
            counter.setPickupCounterName(account.getCounter().getPickupCounterName());
            counter.setOfflineFirstPurchaseCounterCode(account.getCounter().getFirstPurchaseCounterCode());
            counter.setOfflineFirstPurchaseCounterName(account.getCounter().getOfflineFirstPurchaseCounterName());
            counter.setFirstPurchaseCounterCode(account.getCounter().getFirstPurchaseCounterCode());
            counter.setFirstPurchaseTime(account.getCounter().getFirstPurchaseTime());
            counter.setCrmPickupCounterCode(account.getCounter().getCrmPickupCounterCode());
            return counter;
        }
        return null;
    }

    private static ProfileDTO getProfileDTO(Account account) {
        ProfileDTO profile = new ProfileDTO();
        profile.setGender(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getGender).orElse(null));
        profile.setBirthday(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getBirthday).orElse(null));
        profile.setMobile(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).orElse(null));
        profile.setEmail(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getEmail).orElse(null));
        profile.setFullName(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getFullName).orElse(null));
        profile.setNickname(Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getNickName).orElse(null));
        return profile;
    }

    public static AddressDTO getAddressDTO(Account account) {
        if (Optional.of(account).map(Account::getAddress).isPresent()) {
            AddressDTO address = new AddressDTO();
            address.setAddressCode(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getAddressCode).orElse(null));
            address.setFullName(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getFullName).orElse(null));
            address.setMobile(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getCellphone).orElse(null));
            address.setPhone(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getPhone).orElse(null));
            address.setProvince(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getProvince).orElse(null));
            address.setCity(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getCity).orElse(null));
            address.setDistrict(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getDistrict).orElse(null));
            address.setAddress(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getAddress).orElse(null));
            address.setPostcode(Optional.ofNullable(account.getAddress()).map(com.pg.account.sharding.infrastructure.client.address.Address::getPostcode).orElse(null));
            return address;
        }
        return null;
    }

    public Account toAccount(QueryProfileCommand queryProfileCommand) {
        int querySize = 0;
        Account account = null;
        if (Optional.ofNullable(queryProfileCommand.getBindId()).isPresent() && Optional.ofNullable(queryProfileCommand.getChannelId()).isPresent()) {
            querySize++;
            account = fetchMappingService.fetchByTenantIdAndChannelIdAndBindId(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getChannelId().toString(), queryProfileCommand.getBindId());
        }
        if (Optional.ofNullable(queryProfileCommand.getMobile()).isPresent()) {
            querySize++;
            account = fetchMappingService.fetchByTenantIdAndMobile(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getMobile());
        }
        if (Optional.ofNullable(queryProfileCommand.getEmail()).isPresent()) {
            querySize++;
            account = fetchMappingService.fetchByTenantIdAndEmail(queryProfileCommand.getTenantId().toString(), queryProfileCommand.getEmail());
        }
        if (Optional.ofNullable(queryProfileCommand.getMemberId()).isPresent()) {
            querySize++;
            account = Account.AccountBuilder
                    .anAccount()
                    .tenantId(queryProfileCommand.getTenantId().toString())
                    .accountId(queryProfileCommand.getMemberId())
                    .build();
        }
        if (querySize != 1) {
            throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        return account;
    }
}
