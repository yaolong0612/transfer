package com.pg.account.infrastructure.component.datastream.servicebus.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageOptBean implements Serializable {
    private static final long serialVersionUID = -8880408641362151308L;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;
    private String optStatus;
}
