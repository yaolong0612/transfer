package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/1/13
 */
@ApiModel(value = "RegisterBindAccountDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterBindAccountDTO implements Serializable {
    private static final long serialVersionUID = 212752117854875922L;

    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "是否是新注册的会员", example = "true")
    private boolean isNewRegister;

    public boolean getIsNewRegister() {
        return isNewRegister;
    }

    public void setIsNewRegister(boolean newRegister) {
        this.isNewRegister = newRegister;
    }

}
