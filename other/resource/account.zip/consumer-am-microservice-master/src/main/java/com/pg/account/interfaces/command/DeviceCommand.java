package com.pg.account.interfaces.command;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2018/12/10
 */
@ApiModel(value = "DeviceCommand_V1", description = "V1 interface DeviceCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceCommand implements Serializable {

    private static final long serialVersionUID = 860600709569603784L;
    @ApiModelProperty(value = "设备系统,列：ios和android", example = "android")
    private String os;
    @ApiModelProperty(value = "当前应用版本号", example = "10")
    private String appv;
    @ApiModelProperty(value = "应用包名,ios为bundleID", example = "cn.com.pg.android")
    private String packageName;
    @ApiModelProperty(value = "ios系统idfa原始值，android为advertisiong ID", example = "C1CEA826-A684-43EF-93FF-A219D00C0E59")
    private String idfa;
    @ApiModelProperty(value = "android设备imei", example = "4cd07a422573af446079621a784c67ec")
    private String imei;
    @ApiModelProperty(value = "android设备oaid", example = "4cd07a422573af446079621a784c67ec")
    private String oaid;
    @ApiModelProperty(value = "标准api获取mac地址", example = "C0:9F:05:B6:A4:A2")
    private String mac;
    @ApiModelProperty(value = "原始采集的openudid，无法获取时，传空字符串", example = "XXXX21f1f19edff198e2a2356bf4XXXX")
    private String openudid;
    @ApiModelProperty(value = "android系统androidID ，无法获取时，传空字符串", example = "9774d56d682e549c")
    private String androidid;
    @ApiModelProperty(value = "当前手机型号", example = "P30 PROD")
    private String model;
    @ApiModelProperty(value = "当前手机品牌名称", example = "华为")
    private String brand;
    @ApiModelProperty(value = "是否限制广告跟踪，0表示未限制广告跟踪，1反之", example = "0")
    private String adTracked;

}
