package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 开放账号
 *
 * @author Jack Sun
 * @date 2019-11-26 20:15
 */
@ApiModel(value = "AccountQueryDTO_V2")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountQueryDTO implements Serializable {

    private static final long serialVersionUID = -1909585144049507662L;
    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
    @ApiModelProperty(value = "bind Id query whether this bind Id is bound", name = "binded", example = "false", required = true)
    private Boolean binded;
}
