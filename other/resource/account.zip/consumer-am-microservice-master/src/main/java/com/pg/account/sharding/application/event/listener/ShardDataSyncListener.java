//package com.pg.account.sharding.application.event.listener;
//
//import cn.com.pg.paas.stream.framework.StreamTemplate;
//import com.alibaba.fastjson.JSONObject;
//import com.pg.account.domain.model.account.AccountInfo;
//import com.pg.account.domain.model.counter.Counter;
//import com.pg.account.domain.model.profile.*;
//import com.pg.account.domain.model.socialaccount.SocialAccount;
//import com.pg.account.domain.model.socialaccount.SocialAccountUnionId;
//import com.pg.account.infrastructure.component.client.address.Address;
//import com.pg.account.infrastructure.component.uid.UidGenerator;
//import com.pg.account.sharding.application.event.*;
//import com.pg.account.sharding.domain.model.account.*;
//import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
//import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
//import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
//import com.pg.account.sharding.infrastructure.jpa.log.DataStreamDao;
//import com.pg.account.sharding.infrastructure.jpa.log.LogId;
//import com.pg.account.sharding.infrastructure.jpa.log.ShardDataStream;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.event.EventListener;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.stereotype.Component;
//
//import java.sql.Timestamp;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import static com.alibaba.fastjson.JSON.toJSONString;
//import static java.lang.String.valueOf;
//
///**
// * @author yj
// * @date 2021年6月17日22:29:55
// */
//@Component
//@Slf4j
//public class ShardDataSyncListener {
//
//    public static final String PRODUCER_EVENT_HUB = "ShardToOldProducerEventHub";
//    private final DataStreamDao dataStreamDao;
//    private final StreamTemplate streamTemplate;
//    private final UidGenerator uidGenerator;
//    private boolean result;
//    @Value("${event_hub.doubleWriteEventTypeId}")
//    private String amRegProfileEventTypeId;
//    @Value("${event_hub.retryCount}")
//    private int retryCount;
//
//    @Autowired
//    public ShardDataSyncListener(DataStreamDao dataStreamDao, StreamTemplate streamTemplate, UidGenerator uidGenerator) {
//        this.dataStreamDao = dataStreamDao;
//        this.streamTemplate = streamTemplate;
//        this.uidGenerator = uidGenerator;
//    }
//
//    /**
//     * 注册账户监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.registerAccount(event.getAccount(), event.getShardSubscription());
//        }
//    }
//
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(SignUpEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.registerAccount(event.getAccount(), event.getShardSubscription());
//        }
//    }
//
//    /**
//     * 注册绑定监听
//     *
//     * @param event event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(RegisterBindEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.registerBindAccount(event.getAccount(), event.getShardSubscription(), event.getShardSocialAccount());
//        }
//    }
//
//    /**
//     * 修改密码监听
//     *
//     * @param event event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(ChangePasswordEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.modifyPassword(event.getAccount());
//        }
//    }
//
//    /**
//     * 更新用户属性
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateAttributeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateAttribute(event.getAccount());
//        }
//    }
//
//    /**
//     * 删除用户属性
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(DeleteAttributeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.deleteAttribute(event.getAccount());
//        }
//    }
//
//    /**
//     * 添加订阅监听
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateSubscriptionEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateSubscriptionEvent(event.getShardSubscription());
//        }
//    }
//
//    /**
//     * 绑定监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(BindingEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.binding(event.getAccount(), event.getShardSubscription(), event.getShardSocialAccount());
//        }
//    }
//
//    /**
//     * 更新个人信息监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UpdateProfileEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.updateProfileEvent(event.getAccount(), event.getShardSubscription());
//        }
//    }
//
//    /**
//     * 关注监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(SubscribeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.subscribe(event.getShardSocialAccount());
//        }
//    }
//
//    /**
//     * 解绑监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UnBindingEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.unBinding(event.getShardSocialAccount(), event.getShardSubscription(), event.isRemoveUnionId());
//        }
//    }
//
//    /**
//     * 取关监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(UnSubscribeEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.unSubscribe(event.getShardSocialAccount());
//        }
//    }
//
//    /**
//     * 激活账号监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(ActiveEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.activeEvent(event.getAccount());
//        }
//    }
//
//    /**
//     * 注销账号监听
//     *
//     * @param event
//     */
//    @Async("threadPoolTaskExecutor")
//    @EventListener
//    public void onApplicationEvent(InActiveEvent event) {
//        if (Optional.ofNullable(event).isPresent()) {
//            this.inActiveEvent(event.getAccount());
//        }
//    }
//
//    /**
//     * 注销账号监听实现
//     *
//     * @param account
//     */
//    private void inActiveEvent(Account account) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, null, null);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "inActiveEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("inActiveEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "inActiveEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    private void activeEvent(Account account) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, null, null);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "activeEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("activeEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "activeEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    private void unSubscribe(ShardSocialAccount shardSocialAccount) {
//        if (!Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getAccountId).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(null, null, shardSocialAccount);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "unSubscribeEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("unSubscribeEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(shardSocialAccount, "unSubscribeEvent", eventTypeId, strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 关注监听实现
//     *
//     * @param shardSocialAccount
//     */
//    private void subscribe(ShardSocialAccount shardSocialAccount) {
//        if (!Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getAccountId).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(null, null, shardSocialAccount);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "subscribeEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("subscribeEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(shardSocialAccount, "subscribeEvent", eventTypeId, strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    private void unBinding(ShardSocialAccount shardSocialAccount, ShardSubscription shardSubscription, Boolean isRemoveUnionId) {
//        if (!Optional.ofNullable(shardSocialAccount).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(null, shardSubscription, shardSocialAccount);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("isRemoveAccountUnion", isRemoveUnionId);
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "unBindingEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("unBindingEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(shardSubscription, "unBindingEvent", eventTypeId, strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 更新个人信息监听实现
//     *
//     * @param account
//     * @param shardSubscription
//     */
//    private void updateProfileEvent(Account account, ShardSubscription shardSubscription) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, shardSubscription, null);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "updateProfileEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("updateProfileEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "updateProfileEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 绑定监听实现
//     *
//     * @param account
//     * @param shardSubscription
//     * @param shardSocialAccount
//     */
//    private void binding(Account account, ShardSubscription shardSubscription, ShardSocialAccount shardSocialAccount) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, shardSubscription, shardSocialAccount);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "bindingEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("bindingEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "bindingEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//
//    /**
//     * 修改密码监听实现代码
//     *
//     * @param account account
//     */
//    private void modifyPassword(Account account) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, null, null);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("eventType", "changePasswordEvent");
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("changePasswordEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "changePasswordEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 删除用户属性监听实现
//     *
//     * @param account
//     */
//    private void deleteAttribute(Account account) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        if (Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).isPresent()) {
//            result = false;
//            String eventTypeId = amRegProfileEventTypeId;
//            int count = 0;
//            String errorMessage = null;
//            String strJson = null;
//            while (!result) {
//                ++count;
//                if (count > retryCount) {
//                    break;
//                }
//                try {
//                    com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, null, null);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("flag", "new");
//                    jsonObject.put("account", oldAccount);
//                    jsonObject.put("eventType", "deleteAttributeEvent");
//                    jsonObject.put("uid", uidGenerator.getUid());
//                    jsonObject.put("createTime", LocalDateTime.now());
//                    strJson = toJSONString(jsonObject);
//                    result = streamTemplate.send(eventTypeId, strJson);
//                } catch (Exception e) {
//                    log.warn("deleteAttributeEvent error", e);
//                    errorMessage = e.getMessage();
//                }
//            }
//            if (!result) {
//                --count;
//            }
//            writeLog(account, eventTypeId, "deleteAttributeEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//        }
//    }
//
//    /**
//     * 注册账户监听方法
//     *
//     * @param account           account
//     * @param shardSubscription shardSubscription
//     */
//    private void registerAccount(Account account, ShardSubscription shardSubscription) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, shardSubscription, null);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("eventType", "registerEvent");
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("registerAccountEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "registerEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * 更新用户属性实现
//     *
//     * @param account
//     */
//    private void updateAttribute(Account account) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        if (Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getExtraAttributeList).isPresent()) {
//            result = false;
//            String eventTypeId = amRegProfileEventTypeId;
//            int count = 0;
//            String errorMessage = null;
//            String strJson = null;
//            while (!result) {
//                ++count;
//                if (count > retryCount) {
//                    break;
//                }
//                try {
//                    com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, null, null);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("flag", "new");
//                    jsonObject.put("account", oldAccount);
//                    jsonObject.put("eventType", "updateAttributeEvent");
//                    jsonObject.put("uid", uidGenerator.getUid());
//                    jsonObject.put("createTime", LocalDateTime.now());
//                    strJson = toJSONString(jsonObject);
//                    result = streamTemplate.send(eventTypeId, strJson);
//                } catch (Exception e) {
//                    log.warn("updateAttributeEvent error", e);
//                    errorMessage = e.getMessage();
//                }
//            }
//            if (!result) {
//                --count;
//            }
//            writeLog(account, eventTypeId, "updateAttributeEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//        }
//    }
//
//    /**
//     * 注册绑定监听实现
//     *
//     * @param account            account
//     * @param shardSubscription  shardSubscription
//     * @param shardSocialAccount shardSocialAccount
//     */
//    private void registerBindAccount(Account account, ShardSubscription shardSubscription, ShardSocialAccount shardSocialAccount) {
//        if (!Optional.ofNullable(account).isPresent()) {
//            return;
//        }
//        result = false;
//        String eventTypeId = amRegProfileEventTypeId;
//        int count = 0;
//        String errorMessage = null;
//        String strJson = null;
//        while (!result) {
//            ++count;
//            if (count > retryCount) {
//                break;
//            }
//            try {
//                com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(account, shardSubscription, shardSocialAccount);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("flag", "new");
//                jsonObject.put("account", oldAccount);
//                jsonObject.put("eventType", "registerBindEvent");
//                jsonObject.put("uid", uidGenerator.getUid());
//                jsonObject.put("createTime", LocalDateTime.now());
//                strJson = toJSONString(jsonObject);
//                result = streamTemplate.send(eventTypeId, strJson);
//            } catch (Exception e) {
//                log.warn("registerBindEvent error", e);
//                errorMessage = e.getMessage();
//            }
//        }
//        if (!result) {
//            --count;
//        }
//        writeLog(account, eventTypeId, "registerBindEvent", strJson, valueOf(result), errorMessage, valueOf(count));
//    }
//
//    /**
//     * @param shardSubscription
//     */
//    private void updateSubscriptionEvent(ShardSubscription shardSubscription) {
//        if (!Optional.ofNullable(shardSubscription).isPresent()) {
//            return;
//        }
//        if (Optional.ofNullable(shardSubscription).map(ShardSubscription::getSubscriptionList).isPresent()) {
//            result = false;
//            String eventTypeId = amRegProfileEventTypeId;
//            int count = 0;
//            String errorMessage = null;
//            String strJson = null;
//            while (!result) {
//                ++count;
//                if (count > retryCount) {
//                    break;
//                }
//                try {
//                    com.pg.account.domain.model.account.Account oldAccount = this.toOldAccount(null, shardSubscription, null);
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("flag", "new");
//                    jsonObject.put("account", oldAccount);
//                    jsonObject.put("uid", uidGenerator.getUid());
//                    jsonObject.put("eventType", "updateSubscriptionEvent");
//                    jsonObject.put("createTime", LocalDateTime.now());
//                    strJson = toJSONString(jsonObject);
//                    result = streamTemplate.send(eventTypeId, strJson);
//                } catch (Exception e) {
//                    log.warn("updateSubscriptionEvent error", e);
//                    errorMessage = e.getMessage();
//                }
//            }
//            if (!result) {
//                --count;
//            }
//            writeLog(shardSubscription, PRODUCER_EVENT_HUB, eventTypeId, strJson, valueOf(result), errorMessage, valueOf(count));
//        }
//    }
//
//    private com.pg.account.domain.model.account.Account toOldAccount(Account account, ShardSubscription shardSubscription, ShardSocialAccount shardSocialAccount) {
//        com.pg.account.domain.model.account.Account oldAccount = new com.pg.account.domain.model.account.Account();
//        if (Optional.ofNullable(account).isPresent()) {
//            oldAccount.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelId)
//                    .ifPresent(s -> oldAccount.setChannelId(Long.parseLong(s)));
//            Optional.ofNullable(account.getOpenUid()).ifPresent(oldAccount::setOpenId);
//            Optional.ofNullable(account.getIdentityId()).map(IdentityId::getAccountId).ifPresent(oldAccount::setMemberId);
//            oldAccount.setAccountInfo(toOldAccountInfo(account));
//            oldAccount.setCounter(toOldCounter(account));
//            oldAccount.setDevices(toOldDevice(account));
//            oldAccount.setProfile(toOldProfile(account));
//            Address address = toOldAddress(account);
//            List<Address> addressList = new ArrayList<>();
//            addressList.add(address);
//            oldAccount.setAddressList(addressList);
//            oldAccount.setAttributesList(toOldAttribute(account));
//            oldAccount.setJobList(toOldJob(account));
//            oldAccount.setEducationList(toOldEducation(account));
//            oldAccount.setInterpersonalRelationShips(toOldInterPersonalRelationShip(account));
//        } else if (Optional.ofNullable(shardSubscription).isPresent()) {
//            oldAccount.setTenantId(Long.parseLong(shardSubscription.getTenantId()));
//            Optional.ofNullable(shardSubscription.getIdentityId()).map(IdentityId::getAccountId).ifPresent(oldAccount::setMemberId);
//            Optional.ofNullable(shardSubscription.getSubscriptionList()).filter(subscriptionItems -> !subscriptionItems.isEmpty()).flatMap(subscriptionItems -> Optional.ofNullable(subscriptionItems.get(0))).ifPresent(subscriptionItem -> {
//                String channelId = subscriptionItem.getChannelId();
//                if (Optional.ofNullable(channelId).isPresent()) {
//                    oldAccount.setChannelId(Long.parseLong(channelId));
//                }
//            });
//        } else if (Optional.ofNullable(shardSocialAccount).isPresent()) {
//            oldAccount.setTenantId(Long.parseLong(shardSocialAccount.getTenantId()));
//            Optional.ofNullable(shardSocialAccount.getIdentityId()).map(IdentityId::getAccountId).ifPresent(oldAccount::setMemberId);
//            Optional.ofNullable(shardSocialAccount.getChannel()).map(Channel::getChannelId).ifPresent(c -> oldAccount.setChannelId(Long.parseLong(c)));
//        }
//        oldAccount.setSubscriptionsList(toOldSubscribute(shardSubscription));
//        oldAccount.setSocialAccountList(toOldSocialAccount(shardSocialAccount));
//        oldAccount.setSocialAccountUnionIdList(toOldSocialAccountUnionIdList(shardSocialAccount));
//        return oldAccount;
//    }
//
//    private AccountInfo toOldAccountInfo(Account account) {
//        AccountInfo accountInfo = new AccountInfo();
//        accountInfo.setTenantId(Long.parseLong(account.getTenantId()));
//        Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(accountInfo::setUsersId);
//        Optional.ofNullable(account.getAccountStatus()).map(AccountStatus::getValue).ifPresent(accountInfo::setStatus);
//        Optional.ofNullable(account.getSecurity())
//                .map(Security::getEncryptedCode)
//                .ifPresent(accountInfo::setLogonPassword);
//        Optional.ofNullable(account.getSecurity())
//                .map(Security::getSalt)
//                .ifPresent(accountInfo::setSalt);
//        Optional.ofNullable(account.getRegistration())
//                .map(Registration::getRegisterTime)
//                .ifPresent(localDateTime -> accountInfo.setRegistrationDate(Timestamp.valueOf(localDateTime)));
//        Optional.ofNullable(account.getRegistration())
//                .map(Registration::getCustomer)
//                .map(Customer::getRegStore)
//                .ifPresent(accountInfo::setRegStore);
//        Optional.ofNullable(account.getRegistration())
//                .map(Registration::getSource)
//                .ifPresent(accountInfo::setRegistrationSource);
//        Optional.ofNullable(account.getRegistration())
//                .map(Registration::getCustomer)
//                .map(Customer::getName)
//                .ifPresent(accountInfo::setCustomer);
//        Optional.ofNullable(account.getRegisterChannelId()).ifPresent(s -> accountInfo.setChannelId(Long.parseLong(account.getRegisterChannelId())));
//        Optional.ofNullable(account.getOpenUid()).ifPresent(accountInfo::setOpenId);
//        accountInfo.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//        accountInfo.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//        return accountInfo;
//    }
//
//    private Counter toOldCounter(Account account) {
//        Counter counter = null;
//        if (Optional.ofNullable(account.getCounter()).isPresent()) {
//            counter = new Counter();
//            counter.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(counter::setUsersId);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getRegCounterCode)
//                    .ifPresent(counter::setRegCounterCode);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getRegCounterName)
//                    .ifPresent(counter::setRegCounterName);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getMainCounterCode)
//                    .ifPresent(counter::setMainCounterCode);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getMainCounterName)
//                    .ifPresent(counter::setMainCounterName);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getPickupCounterCode)
//                    .ifPresent(counter::setPickupCounterCode);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getPickupCounterName)
//                    .ifPresent(counter::setPickupCounterName);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getOfflineFirstPurchaseCounterCode)
//                    .ifPresent(counter::setOfflineFirstPurchaseCounterCode);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getOfflineFirstPurchaseCounterName)
//                    .ifPresent(counter::setOfflineFirstPurchaseCounterName);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getFirstPurchaseCounterCode)
//                    .ifPresent(counter::setFirstPurchaseCounterCode);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getFirstPurchaseTime)
//                    .ifPresent(counter::setFirstPurchaseTime);
//            Optional.ofNullable(account.getCounter())
//                    .map(CounterInfo::getCrmPickupCounterCode)
//                    .ifPresent(counter::setCrmPickupCounterCode);
//            counter.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//            counter.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//        }
//        return counter;
//    }
//
//    private Devices toOldDevice(Account account) {
//        Devices devices = null;
//        if (Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getDevice).isPresent()) {
//            devices = new Devices();
//            devices.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(devices::setUsersId);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getOs)
//                    .ifPresent(devices::setOs);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getAppv)
//                    .ifPresent(devices::setAppv);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getPackageName)
//                    .ifPresent(devices::setPackageName);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getIdfa)
//                    .ifPresent(devices::setIdfa);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getImei)
//                    .ifPresent(devices::setImei);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getOaid)
//                    .ifPresent(devices::setOaid);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getMac)
//                    .ifPresent(devices::setMac);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getOpenudid)
//                    .ifPresent(devices::setOpenudid);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getAndroidid)
//                    .ifPresent(devices::setAndroidid);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getModel)
//                    .ifPresent(devices::setModel);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getBrand)
//                    .ifPresent(devices::setBrand);
//            Optional.ofNullable(account.getUserAdditionalInfo())
//                    .map(UserAdditionalInfo::getDevice)
//                    .map(DeviceInfo::getAdTracked)
//                    .ifPresent(devices::setAdTracked);
//            devices.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//            devices.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//        }
//        return devices;
//    }
//
//    private Profile toOldProfile(Account account) {
//        Profile profile = new Profile();
//        profile.setTenantId(Long.parseLong(account.getTenantId()));
//        Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(profile::setUsersId);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getContact)
//                .map(Contact::getEmail)
//                .ifPresent(profile::setEmail);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getContact)
//                .map(Contact::getMobile)
//                .ifPresent(profile::setCellphone);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getNickName)
//                .ifPresent(profile::setNickname);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getGender)
//                .ifPresent(profile::setGender);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getBirthday)
//                .ifPresent(profile::setBirthday);
//        Optional.ofNullable(account.getUserBasicInfo())
//                .map(UserBasicInfo::getNickName)
//                .ifPresent(profile::setNickname);
//        profile.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//        profile.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//        return profile;
//    }
//
//    private Address toOldAddress(Account account) {
//        Address address = null;
//        if (null != account.getAddress()) {
//            address = new Address();
//            address.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(address::setMemberId);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getAddressCode)
//                    .ifPresent(address::setAddressCode);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getIsPrimary)
//                    .ifPresent(address::setIsPrimary);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getAddressType)
//                    .ifPresent(address::setAddressType);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getFullName)
//                    .ifPresent(address::setFullName);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getCellphone)
//                    .ifPresent(address::setCellphone);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getPhone)
//                    .ifPresent(address::setPhone);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getProvince)
//                    .ifPresent(address::setProvince);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getCity)
//                    .ifPresent(address::setCity);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getDistrict)
//                    .ifPresent(address::setDistrict);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getAddress)
//                    .ifPresent(address::setAddress);
//            Optional.ofNullable(account.getAddress())
//                    .map(com.pg.account.sharding.infrastructure.client.address.Address::getPostcode)
//                    .ifPresent(address::setPostcode);
//        }
//        return address;
//    }
//
//    private List<Attributes> toOldAttribute(Account account) {
//        List<Attributes> attributesList = new ArrayList<>();
//        Optional.ofNullable(account.getUserAdditionalInfo())
//                .map(UserAdditionalInfo::getExtraAttributeList)
//                .ifPresent(extraAttributeItemList -> extraAttributeItemList.forEach(extraAttributeItem -> {
//                    Attributes attributes = new Attributes();
//                    attributes.setTenantId(Long.parseLong(account.getTenantId()));
//                    Optional.ofNullable(account.getIdentityId().getAccountId()).ifPresent(attributes::setUsersId);
//                    Optional.ofNullable(extraAttributeItem.getAttrId()).ifPresent(attributes::setAttrId);
//                    Optional.ofNullable(extraAttributeItem.getAttrValue()).ifPresent(attributes::setAttrValue);
//                    attributes.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//                    attributes.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//                    attributesList.add(attributes);
//                }));
//        return attributesList;
//    }
//
//    private List<Subscriptions> toOldSubscribute(ShardSubscription shardSubscription) {
//        List<Subscriptions> subscriptionsList = new ArrayList<>();
//        if (Optional.ofNullable(shardSubscription).isPresent()) {
//            Optional.ofNullable(shardSubscription.getSubscriptionList())
//                    .ifPresent(subscriptionItems -> subscriptionItems.forEach(subscriptionItem -> {
//                        Subscriptions subscriptions = new Subscriptions();
//                        subscriptions.setTenantId(Long.parseLong(shardSubscription.getTenantId()));
//                        Optional.ofNullable(shardSubscription.getIdentityId()).map(IdentityId::getAccountId).ifPresent(subscriptions::setUsersId);
//                        Optional.ofNullable(subscriptionItem.getTermsList()).filter(terms -> !terms.isEmpty()).flatMap(terms -> Optional.ofNullable(terms.get(0))).ifPresent(term -> {
//                            String termId = term.getTermId();
//                            if (Optional.ofNullable(termId).isPresent()) {
//                                subscriptions.setTermsId(Long.parseLong(termId));
//                            }
//                        });
//                        Optional.ofNullable(subscriptionItem.getOptStatus()).ifPresent(subscriptions::setOptStatus);
//                        Optional.ofNullable(subscriptionItem.getOptTime()).ifPresent(localDateTime -> subscriptions.setOptionTime(Timestamp.valueOf(localDateTime)));
//                        Optional.ofNullable(subscriptionItem.getOptId()).ifPresent(subscriptions::setOptId);
//                        subscriptions.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//                        subscriptions.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//                        subscriptionsList.add(subscriptions);
//                    }));
//        }
//        return subscriptionsList;
//    }
//
//    private List<SocialAccount> toOldSocialAccount(ShardSocialAccount shardSocialAccount) {
//        List<SocialAccount> socialAccountList = new ArrayList<>();
//        if (Optional.ofNullable(shardSocialAccount).isPresent()) {
//            Optional.ofNullable(shardSocialAccount.getSocialAccountList())
//                    .ifPresent(socialAccountItems -> socialAccountItems.forEach(socialAccountItem -> {
//                        if (Optional.ofNullable(socialAccountItem.getBindId()).isPresent()) {
//                            SocialAccount socialAccount = new SocialAccount();
//                            socialAccount.setTenantId(Long.parseLong(shardSocialAccount.getTenantId()));
//                            Optional.ofNullable(shardSocialAccount.getIdentityId()).map(IdentityId::getAccountId).ifPresent(socialAccount::setUsersId);
//                            Optional.ofNullable(socialAccountItem.getBindId()).ifPresent(socialAccount::setBindId);
//                            Optional.ofNullable(socialAccountItem.getChannel()).map(Channel::getChannelId).ifPresent(c -> socialAccount.setChannelId(Long.parseLong(c)));
//                            Optional.ofNullable(socialAccountItem.getBindTime()).ifPresent(t -> socialAccount.setBindTime(Timestamp.valueOf(t)));
//                            socialAccount.setAttentionStatus(null);
//                            Optional.ofNullable(socialAccountItem.getCreateTime()).ifPresent(t -> socialAccount.setCreateTime(Timestamp.valueOf(t)));
//                            Optional.ofNullable(socialAccountItem.getUpdateTime()).ifPresent(t -> socialAccount.setModifyTime(Timestamp.valueOf(t)));
//                            socialAccount.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//                            socialAccount.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//                            socialAccountList.add(socialAccount);
//                        }
//                    }));
//        }
//        return socialAccountList;
//    }
//
//    private List<SocialAccountUnionId> toOldSocialAccountUnionIdList(ShardSocialAccount shardSocialAccount) {
//        List<SocialAccountUnionId> socialAccountUnionIdList = new ArrayList<>();
//        if (Optional.ofNullable(shardSocialAccount).isPresent()) {
//            if (Optional.ofNullable(shardSocialAccount.getSocialAccountList()).isPresent()) {
//                SocialAccountItem socialAccountItem = shardSocialAccount.getSocialAccountList().get(0);
//                if (Optional.ofNullable(socialAccountItem.getUnionId()).isPresent()) {
//                    SocialAccountUnionId socialAccountUnionId = new SocialAccountUnionId();
//                    socialAccountUnionId.setTenantId(Long.parseLong(shardSocialAccount.getTenantId()));
//                    Optional.ofNullable(shardSocialAccount.getIdentityId()).map(IdentityId::getAccountId).ifPresent(socialAccountUnionId::setUsersId);
//                    Optional.ofNullable(socialAccountItem.getUnionId()).ifPresent(socialAccountUnionId::setUnionId);
//                    Optional.ofNullable(socialAccountItem.getChannel()).map(Channel::getUnionType).ifPresent(socialAccountUnionId::setUnionIdType);
//                    Optional.ofNullable(socialAccountItem.getBindTime()).ifPresent(t -> socialAccountUnionId.setBindTime(Timestamp.valueOf(t)));
//                    Optional.ofNullable(socialAccountItem.getCreateTime()).ifPresent(t -> socialAccountUnionId.setCreateTime(Timestamp.valueOf(t)));
//                    Optional.ofNullable(socialAccountItem.getUpdateTime()).ifPresent(t -> socialAccountUnionId.setModifyTime(Timestamp.valueOf(t)));
//                    socialAccountUnionId.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//                    socialAccountUnionId.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//                    socialAccountUnionIdList.add(socialAccountUnionId);
//                }
//            }
//        }
//        return socialAccountUnionIdList;
//    }
//
//    private List<Job> toOldJob(Account account) {
//        List<Job> jobList = new ArrayList<>();
//        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getJobList)
//                .filter(jobLists -> !jobLists.isEmpty()).ifPresent(jobItems -> jobItems.forEach(jobItem -> {
//            Job job = new Job();
//            job.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId()).map(IdentityId::getAccountId).ifPresent(job::setUsersId);
//            Optional.ofNullable(jobItem.getRelation()).map(Relation::getRelationType).ifPresent(relationType -> {
//                job.setRelationship(relationType.getRelationName());
//            });
//            Optional.ofNullable(jobItem.getRelation()).map(Relation::getSequence).ifPresent(job::setRelationshipSequence);
//            Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getProvince).ifPresent(job::setProvince);
//            Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getCity).ifPresent(job::setCity);
//            Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(job::setDistrict);
//            Optional.ofNullable(jobItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(job::setUnitAddress);
//            Optional.ofNullable(jobItem.getName()).ifPresent(job::setUnitName);
//            Optional.ofNullable(jobItem.getCategory()).ifPresent(job::setUnitCategory);
//            Optional.ofNullable(jobItem.getProfession()).ifPresent(job::setProfession);
//            Optional.ofNullable(jobItem.getCreateTime()).ifPresent(t -> job.setCreateTime(Timestamp.valueOf(t)));
//            Optional.ofNullable(jobItem.getUpdateTime()).ifPresent(t -> job.setModifyTime(Timestamp.valueOf(t)));
//            job.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//            job.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//            jobList.add(job);
//        }));
//        return jobList;
//    }
//
//    private List<Education> toOldEducation(Account account) {
//        List<Education> educationList = new ArrayList<>();
//        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getEducationList)
//                .filter(educationLists -> !educationLists.isEmpty()).ifPresent(educationItems -> educationItems.forEach(educationItem -> {
//            Education education = new Education();
//            education.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId()).map(IdentityId::getAccountId).ifPresent(education::setUsersId);
//            Optional.ofNullable(educationItem.getRelation()).map(Relation::getRelationType).ifPresent(r -> education.setRelationship(r.getRelationName()));
//            Optional.ofNullable(educationItem.getRelation()).map(Relation::getSequence).ifPresent(education::setRelationshipSequence);
//            Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getProvince).ifPresent(education::setProvince);
//            Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getCity).ifPresent(education::setCity);
//            Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getDistrict).ifPresent(education::setDistrict);
//            Optional.ofNullable(educationItem.getAddress()).map(AddressInfo::getAddressInfo).ifPresent(education::setSchoolAddress);
//            Optional.ofNullable(educationItem.getName()).ifPresent(education::setSchoolName);
//            Optional.ofNullable(educationItem.getCategory()).ifPresent(education::setSchoolCategory);
//            Optional.ofNullable(educationItem.getGrade()).ifPresent(education::setGrade);
//            Optional.ofNullable(educationItem.getClassName()).ifPresent(education::setClassName);
//            Optional.ofNullable(educationItem.getCollege()).ifPresent(education::setCollege);
//            Optional.ofNullable(educationItem.getMajor()).ifPresent(education::setMajor);
//            Optional.ofNullable(educationItem.getDegree()).ifPresent(education::setDegree);
//            Optional.ofNullable(educationItem.getAdmissionTime()).ifPresent(education::setAdmissionTime);
//            Optional.ofNullable(educationItem.getGraduationTime()).ifPresent(education::setGraduationTime);
//            Optional.ofNullable(educationItem.getCreateTime()).ifPresent(t -> education.setCreateTime(Timestamp.valueOf(t)));
//            Optional.ofNullable(educationItem.getUpdateTime()).ifPresent(t -> education.setModifyTime(Timestamp.valueOf(t)));
//            education.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//            education.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//            educationList.add(education);
//        }));
//        return educationList;
//    }
//
//    private List<InterpersonalRelationShip> toOldInterPersonalRelationShip(Account account) {
//        List<InterpersonalRelationShip> interpersonalRelationShipList = new ArrayList<>();
//        Optional.ofNullable(account.getUserAdditionalInfo()).map(UserAdditionalInfo::getHumanRelationList)
//                .filter(humanRelationItemList -> !humanRelationItemList.isEmpty()).ifPresent(humanRelationItemList -> humanRelationItemList.forEach(humanRelationItem -> {
//            InterpersonalRelationShip interpersonalRelationShip = new InterpersonalRelationShip();
//            interpersonalRelationShip.setTenantId(Long.parseLong(account.getTenantId()));
//            Optional.ofNullable(account.getIdentityId()).map(IdentityId::getAccountId).ifPresent(interpersonalRelationShip::setUsersId);
//            Optional.ofNullable(humanRelationItem.getRelation()).map(Relation::getRelationType).ifPresent(relationType -> interpersonalRelationShip.setRelationship(relationType.getRelationName()));
//            Optional.ofNullable(humanRelationItem.getRelation()).map(Relation::getSequence).ifPresent(interpersonalRelationShip::setRelationshipSequence);
//            Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getFullName).ifPresent(interpersonalRelationShip::setFullName);
//            Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getBirthday).ifPresent(interpersonalRelationShip::setBirthday);
//            Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getGender).ifPresent(interpersonalRelationShip::setGender);
//            Optional.ofNullable(humanRelationItem.getPerson()).map(Person::getContact).map(Contact::getMobile).ifPresent(interpersonalRelationShip::setCellphone);
//            Optional.ofNullable(humanRelationItem.getGuardian()).ifPresent(interpersonalRelationShip::setGuardian);
//            Optional.ofNullable(humanRelationItem.getCreateTime()).ifPresent(t -> interpersonalRelationShip.setCreateTime(Timestamp.valueOf(t)));
//            Optional.ofNullable(humanRelationItem.getCreateTime()).ifPresent(t -> interpersonalRelationShip.setCreateTime(Timestamp.valueOf(t)));
//            interpersonalRelationShip.setModifyTime(Timestamp.valueOf(LocalDateTime.now()));
//            interpersonalRelationShip.setCreateTime(Timestamp.valueOf(LocalDateTime.now()));
//            interpersonalRelationShipList.add(interpersonalRelationShip);
//        }));
//        return interpersonalRelationShipList;
//    }
//
//    private void writeLog(Account account, String eventTypeId, String eventType, String eventMessage, String status, String errorMessage, String retryCount) {
//        LogId logId = new LogId(uidGenerator.getUid(), LocalDateTime.now());
//        ShardDataStream dataStream = new ShardDataStream(logId, account.getTenantId(), account.getAccountId(), PRODUCER_EVENT_HUB, eventTypeId, eventType, null, null, eventMessage, errorMessage, status, retryCount);
//        dataStreamDao.save(dataStream);
//    }
//
//    private void writeLog(ShardSubscription shardSubscription, String eventType, String eventTypeId, String eventMessage, String status, String errorMessage, String retryCount) {
//        LogId logId = new LogId(uidGenerator.getUid(), LocalDateTime.now());
//        ShardDataStream dataStream = new ShardDataStream(logId, shardSubscription.getTenantId(), shardSubscription.getAccountId(), PRODUCER_EVENT_HUB, eventTypeId, eventType, null, null, eventMessage, errorMessage, status, retryCount);
//        dataStreamDao.save(dataStream);
//    }
//
//    private void writeLog(ShardSocialAccount shardSocialAccount, String eventType, String eventTypeId, String eventMessage, String status, String errorMessage, String retryCount) {
//        LogId logId = new LogId(uidGenerator.getUid(), LocalDateTime.now());
//        ShardDataStream dataStream = new ShardDataStream(logId, shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId(), PRODUCER_EVENT_HUB, eventTypeId, eventType, null, null, eventMessage, errorMessage, status, retryCount);
//        dataStreamDao.save(dataStream);
//    }
//}
