package com.pg.account.interfaces.command.oralbCommand;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author YJ
 * @date 2021/9/2
 */
@ApiModel(value = "Oralb_ProfileCommand", description = "Oralb migrate interface ProfileCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OralbProfileCommand implements Serializable {

    private static final long serialVersionUID = -4022245346784845892L;
    @ApiModelProperty(value = "昵称", example = "孙悟空")
    private String nickname;
    @ApiModelProperty(value = "性别，男：M，女：F，无：U", example = "U")
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @ApiModelProperty(value = "生日，年满18岁，生日格式：yyyy-mm-dd", example = "1993-10-09")
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @ApiModelProperty(value = "手机号", example = "13019191919")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "邮箱", example = "1010@qq.com")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @ApiModelProperty(value = "fullName", example = "张三")
    private String field3;
}
