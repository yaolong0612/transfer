package com.pg.account.infrastructure.validator;

import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * @author LC
 * <p>
 * 判断tenantId是否存在
 */
public class TenantNotNullValid implements ConstraintValidator<TenantExistValid, Long> {

    @Override
    public boolean isValid(Long tenantId, ConstraintValidatorContext constraintValidatorContext) {
        try {
            return StringUtils.isNotBlank(CacheLocalConfigUtils.getTenant(tenantId));
        } catch (Exception e) {
            try {
                return StringUtils.isNotBlank(LocalCacheConfigUtils.getTenant(tenantId.toString()));
            } catch (Exception e2) {
                return false;
            }
        }
    }
}