package com.pg.account.sharding.infrastructure.jpa.config;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author wsq
 * @date 2021/6/10 15:12
 **/
public interface OptionDictionaryDao extends JpaRepository<ShardOptionDictionary, Long> {


    /**
     * 查询ShardOptionDictionary对象
     *
     * @param tenantId tenantId
     * @return list of ShardOptionDictionary
     * @date 2021/6/10 15:15
     */
    List<ShardOptionDictionary> findByTenantId(String tenantId);

    /**
     * 根据租户和枚举类型查询订阅信息
     *
     * @param tenantId tenantId
     * @param enumType enumType
     * @return java.util.List<com.pg.account.sharding.infrastructure.jpa.config.ShardOptionDictionary>
     * @author xusheng
     * @date 2021/6/16 15:54
     */
    List<ShardOptionDictionary> findByTenantIdAndEnumType(String tenantId, String enumType);

}
