package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.application.event.ChangeCounterEvent;
import com.pg.account.sharding.application.event.UpdateCounterEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.CounterInfo;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.counter.CounterDao;
import com.pg.account.sharding.infrastructure.jpa.counter.ShardCounter;
import com.pg.account.sharding.infrastructure.servicebus.LoyaltyAbstractConsumer;
import com.pg.account.sharding.infrastructure.servicebus.LoyaltyServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.switchconfig.SwitchConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.MEMBER_ID;
import static com.pg.account.sharding.infrastructure.servicebus.LoyaltyServiceBusQueueTopicEnum.Q_FIRST_COUNTER_OLAY;

/**
 * @author mrluve
 */
@Slf4j
@Service
public class LoyaltyFirstPurchaseConsumer extends LoyaltyAbstractConsumer {

    public static final String MARKETING_PROGRAM_ID = "marketingProgramId";
    public static final String FIRST_PURCHASE_STORE_CODE = "firstPurchaseStoreCode";
    public static final String FIRST_PURCHASE_TIME = "firstPurchaseTime";
    private final CounterDao counterDao;
    private final UidGenerator uidGenerator;
    private final SwitchConfiguration switchConfiguration;

    @Autowired
    public LoyaltyFirstPurchaseConsumer(CounterDao counterDao, UidGenerator uidGenerator, SwitchConfiguration switchConfiguration) {
        this.counterDao = counterDao;
        this.uidGenerator = uidGenerator;
        this.switchConfiguration = switchConfiguration;
    }

    /**
     * 接收message消息，进行首单柜信息更新，生成CRM领取柜
     *
     * @param jsonObject jsonObject
     */
    private void saveFirstPurchaseCounter(JSONObject jsonObject) {
        String memberId = jsonObject.containsKey(MEMBER_ID) ? jsonObject.getString(MEMBER_ID) : null;
        String marketingProgramId = jsonObject.containsKey(MARKETING_PROGRAM_ID) ? jsonObject.getString(MARKETING_PROGRAM_ID) : null;
        String tenantId = LocalCacheConfigUtils.getTenantIdByMarketingProgramId(Integer.parseInt(Objects.requireNonNull(marketingProgramId)));
                saveShardingCounter(tenantId, memberId, jsonObject, true);

    }

    private void saveShardingCounter(String tenantId, String memberId, JSONObject jsonObject, boolean flag) {
        ShardCounter shardCounter = counterDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, memberId);
        IdentityId identityId = new IdentityId(tenantId, memberId);
        CounterInfo counterInfo = new CounterInfo();
        counterInfo.setFirstPurchaseCounterCode(jsonObject.getString(FIRST_PURCHASE_STORE_CODE));
        counterInfo.setFirstPurchaseTime(jsonObject.getString(FIRST_PURCHASE_TIME));
        if (Optional.ofNullable(shardCounter).isPresent()) {
            counterInfo.buildFromDb(shardCounter.getCounter());
            shardCounter.changeFirstPurchaseCounter(identityId, counterInfo);
            shardCounter.addUpdatedTime();
        } else {
            shardCounter = new ShardCounter();
            shardCounter.changeFirstPurchaseCounter(identityId, counterInfo);
            shardCounter.addCreateTime();
        }
        counterDao.save(shardCounter);
        if (flag) {
            Account account = new Account();
            account.setIdentityId(shardCounter.getIdentityId());
            account.setCounter(shardCounter.getCounter());
            //发送counter快照
            ChangeCounterEvent changeCounterEvent = new ChangeCounterEvent(this, account);
            SpringContextUtil.getApplicationContext().publishEvent(changeCounterEvent);
            UpdateCounterEvent updatedCounterEvent = new UpdateCounterEvent(this, account);
            SpringContextUtil.getApplicationContext().publishEvent(updatedCounterEvent);
        }
    }


    @Override
    protected void doBusiness(JSON json) {
        JSONObject bodyContent = (JSONObject) json;
        log.info("LoyaltyFirstPurchase consume start...,and body is:{}", bodyContent);
        JSONObject jsonObject = bodyContent.getJSONObject("jsonObject");
        Optional.ofNullable(jsonObject).ifPresent(this::saveFirstPurchaseCounter);
    }

    @Override
    protected String getLabel() {
        return Q_FIRST_COUNTER_OLAY.queueOrTopicName();
    }

    @Override
    protected LoyaltyServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return Q_FIRST_COUNTER_OLAY;
    }
}
