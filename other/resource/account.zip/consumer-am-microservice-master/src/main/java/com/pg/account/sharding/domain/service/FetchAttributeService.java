package com.pg.account.sharding.domain.service;

import com.alibaba.fastjson.JSON;
import com.pg.account.infrastructure.common.utils.DateUtil;
import com.pg.account.sharding.application.customized.bean.BabyInfoBean;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.YYYY_MM_DD;

/**
 * @author yj
 */
@Service
public class FetchAttributeService {

    private static final String ATTR_ID = "113000001";
    private final ExtraAttributeDao extraAttributeDao;

    @Autowired
    public FetchAttributeService(ExtraAttributeDao extraAttributeDao) {
        this.extraAttributeDao = extraAttributeDao;
    }


    /**
     * 校验生日格式
     *
     * @param account account
     * @return Account
     */
    public Account fetchAttributesAssembleValidator(Account account) {
        UserAdditionalInfo userAdditionalInfo = new UserAdditionalInfo();
        List<ExtraAttributeItem> extraAttributeList = new ArrayList<>();
        //查询会员存在的用户属性信息
        ShardExtraAttribute shardExtraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
        if (Optional.ofNullable(shardExtraAttribute).isPresent()) {
            Optional.ofNullable(shardExtraAttribute.getExtraAttributeItemList())
                    .filter(extraAttributes -> !extraAttributes.isEmpty())
                    .ifPresent(extraAttributes -> extraAttributes.forEach(extraAttribute -> {
                        ExtraAttributeItem extraAttributeItem = null;
                        if (ATTR_ID.equals(extraAttribute.getAttrId()) && StringUtils.isNotBlank(extraAttribute.getAttrValue())) {
                            List<BabyInfoBean> babyInfoBeanList = JSON.parseArray(extraAttribute.getAttrValue(), BabyInfoBean.class);
                            for (BabyInfoBean babyInfoBean : babyInfoBeanList) {
                                String birthday = babyInfoBean.getBirthday();
                                String babyBirthday = DateFormatUtils.format(DateUtil.fromMysqlDate(birthday), YYYY_MM_DD, Locale.CHINA);
                                babyInfoBean.setBirthday(babyBirthday);
                                extraAttributeItem = new ExtraAttributeItem(extraAttribute.getAttrId(), JSON.toJSONString(babyInfoBeanList));
                            }
                        } else {
                            extraAttributeItem = new ExtraAttributeItem(extraAttribute.getAttrId(), extraAttribute.getAttrValue());
                        }
                        extraAttributeList.add(extraAttributeItem);
                    }));
            userAdditionalInfo.setExtraAttributeList(extraAttributeList);
            account.setUserAdditionalInfo(userAdditionalInfo);
        }
        return account;
    }
}
