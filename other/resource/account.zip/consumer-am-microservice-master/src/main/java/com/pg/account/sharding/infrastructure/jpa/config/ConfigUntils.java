package com.pg.account.sharding.infrastructure.jpa.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*


 * @return:
 * @Author: zhubin
 * @Date: 2022/11/14 16:48
 */
@Component
@Slf4j
public class ConfigUntils {

    private static ChannelDao channelDao;
    @Autowired
    public ConfigUntils(ChannelDao channelDao){
        this.channelDao = channelDao;
    }

    /**
     * 获取public_account
     * @param tenantId
     * @param channelId
     * @return
     */
    public static String getPublicAccount(String tenantId,String channelId){
        ShardChannel byTenantIdAndChannelId = channelDao.findByTenantIdAndChannelId(tenantId, channelId);
        return byTenantIdAndChannelId.getPublicAccount();
    }


}
