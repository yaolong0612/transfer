package com.pg.account.sharding.application.cmdservice.impl;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.sharding.application.cmdservice.CancelService;
import com.pg.account.sharding.application.cmdservice.UnbindService;
import com.pg.account.sharding.application.event.ClearCacheEvent;
import com.pg.account.sharding.application.event.InActiveEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.UserBasicInfo;
import com.pg.account.sharding.domain.model.account.repository.AccountRepository;
import com.pg.account.sharding.infrastructure.jpa.mapping.*;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.DeleteMappingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.Optional;

import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.ACCOUNT_ID;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.MOBILE;

/**
 * @author lfx
 * @date 2022/2/10 9:38
 */
@Service
public class CancelServiceImpl implements CancelService {

    public static final String ALL = "3";
    private final AccountRepository accountRepository;
    private final MobileMappingDao mobileMappingDao;
    private final EmailMappingDao emailMappingDao;
    private final OpenUidMappingDao openUidMappingDao;
    private final UnbindService unbindService;
    private final FetchMappingService fetchMappingService;

    @Autowired
    public CancelServiceImpl(AccountRepository accountRepository, MobileMappingDao mobileMappingDao, EmailMappingDao emailMappingDao, OpenUidMappingDao openUidMappingDao, UnbindService unbindService, FetchMappingService fetchMappingService, DeleteMappingService deleteMappingService) {
        this.accountRepository = accountRepository;
        this.mobileMappingDao = mobileMappingDao;
        this.emailMappingDao = emailMappingDao;
        this.openUidMappingDao = openUidMappingDao;
        this.unbindService = unbindService;
        this.fetchMappingService = fetchMappingService;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String cancelAccount(String tenant, String type, String query) {
        String accountId = this.getAccountId(tenant, type, query);
        Account account = accountRepository.fetchAccountByTenantAndAccountId(tenant, accountId);
        // 将所有的绑定关系解绑
        unbindService.unBind(tenant, null, accountId, ALL);
        // 将所有PII信息置空，删除所有mapping关系
        UserBasicInfo.UserBasicInfoBuilder userBasicInfoBuilder = UserBasicInfo.UserBasicInfoBuilder.anUserBasicInfo();
        Optional.ofNullable(account.getUserBasicInfo()).ifPresent(u -> {
            userBasicInfoBuilder.fullName(u.getFullName());
            userBasicInfoBuilder.nickName(u.getNickName());
            userBasicInfoBuilder.birthday(u.getBirthday());
            userBasicInfoBuilder.gender(u.getGender());
        });
        mobileMappingDao.deleteByMobileMapId_TenantIdAndMobileMapId_Mobile(account.tenantId(), account.getMobile());
        emailMappingDao.deleteByEmailMapId_TenantIdAndEmailMapId_Email(account.tenantId(), account.getEmail());
        openUidMappingDao.deleteByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(account.tenantId(), account.getOpenUid());
        account.setUserBasicInfo(userBasicInfoBuilder.build());
        // 将账号状态改为失效
        account.inActiveStatus();
        // 同步给DMP
        //更新accountInfo
        accountRepository.saveAccountInfo(account);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                ClearCacheEvent clearCacheEvent = new ClearCacheEvent(this, account.tenantId(), account.accountId());
                SpringContextUtil.getApplicationContext().publishEvent(clearCacheEvent);
                InActiveEvent inActiveEvent = new InActiveEvent(this, account);
                SpringContextUtil.getApplicationContext().publishEvent(inActiveEvent);
            }
        });
        return accountId;
    }

    /**
     * 通过各种情况查询accountId
     *
     * @param tenant tenant
     * @param type   type
     * @param query  query
     * @return accountId
     */
    private String getAccountId(String tenant, String type, String query) {
        String accountId;
        switch (type) {
            case MOBILE:
                if (!StringValidUtil.isMobile(query)) {
                    throw new BusinessException(V3ResultEnum.INCORRECT_MOBILE.getCode(), V3ResultEnum.INCORRECT_MOBILE.getMessage(), V3ResultEnum.INCORRECT_MOBILE.getFrontMessage());
                }
                // 根据手机号查询accountId
                accountId = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(tenant, query)).map(MobileMapping::getAccountId).orElseThrow(() -> new BusinessException(V3ResultEnum.ACCOUNT_NOT_EXIST.getCode(), V3ResultEnum.ACCOUNT_NOT_EXIST.getMessage(), V3ResultEnum.ACCOUNT_NOT_EXIST.getFrontMessage()));
                break;
            case ACCOUNT_ID:
                // 如果是通过accountId查询则将query赋值给accountId
                accountId = query;
                break;
            default:
                throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        return accountId;
    }
}
