package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.enums.UnBindRouteEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.interfaces.command.UpdateBindIdCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.service.annotation.UnionIdIsNecessary;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.client.acl.FetchAclServiceImpl;
import com.pg.account.sharding.infrastructure.jpa.mapping.*;
import jodd.util.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.*;
import static java.util.stream.Collectors.toList;

/**
 * @author Jack
 * @date 2021/5/31 13:03
 */
@Validated
@Service
public class BindSocialAccountService {

    public static final String ALL = "all";
    private final ShardSocialAccountRepository shardSocialAccountRepository;
    private final FetchAclServiceImpl fetchAclServiceImpl;
    private final FetchMappingService fetchMappingService;
    private final UnionIdMappingDao unionIdMappingDao;
    private final BindIdMappingDao bindIdMappingDao;

    @Autowired
    public BindSocialAccountService(ShardSocialAccountRepository shardSocialAccountRepository,
                                    FetchAclServiceImpl fetchAclServiceImpl, FetchMappingService fetchMappingService,
                                    UnionIdMappingDao unionIdMappingDao, BindIdMappingDao bindIdMappingDao) {
        this.shardSocialAccountRepository = shardSocialAccountRepository;
        this.fetchAclServiceImpl = fetchAclServiceImpl;
        this.fetchMappingService = fetchMappingService;
        this.unionIdMappingDao = unionIdMappingDao;
        this.bindIdMappingDao = bindIdMappingDao;
    }

    public ShardSocialAccount bind(@Valid @UnionIdIsNecessary ShardSocialAccount shardSocialAccount) {
        //取出tenantId并校验是否为空
        String tenantId = shardSocialAccount.getTenantId();
        //取出SocialAccountItem的值
        SocialAccountItem socialAccountItem = Optional.ofNullable(shardSocialAccount
                .getSocialAccountList())
                .flatMap(social -> social.stream().findFirst())
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
        String channelId = Optional.ofNullable(socialAccountItem.getChannelId())
                .orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
        String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channelId);
        ShardSocialAccount shardSocialAccount1 = null;
        //如果bindId为空，unionId不为空则注册类型为unionId
        if (!Optional.ofNullable(socialAccountItem.getBindId()).isPresent()) {
            //前端传入unionId
            if (Optional.ofNullable(socialAccountItem.getUnionId()).isPresent()) {
                unionIdValidate(tenantId, socialAccountItem.getUnionId(), shardSocialAccount.getAccountId(), unionIdType);
                shardSocialAccount1 = addShardSocialAccount(shardSocialAccount.getIdentityId(), socialAccountItem);
            }
            return shardSocialAccount1;
        }
        if (StringUtils.isNotBlank(unionIdType)) {
            if (this.validateUnionIdConfigExisting(tenantId, channelId) && StringUtils.isBlank(socialAccountItem.getUnionId())) {
                //需要通过调用ACL服务获取unionId
                String unionId = this.fetchAclServiceImpl.fetchUnionId(tenantId, channelId, socialAccountItem.getBindId());
                socialAccountItem.setUnionId(unionId);
            }
            //前端传入unionId
            unionIdValidate(tenantId, socialAccountItem.getUnionId(), shardSocialAccount.getAccountId(), unionIdType);
        } else {
            socialAccountItem.setUnionId(null);
        }
        this.bindIdValidate(tenantId, channelId, socialAccountItem.getBindId(), shardSocialAccount.getAccountId());
        return addShardSocialAccount(shardSocialAccount.getIdentityId(), socialAccountItem);
    }

    public ShardSocialAccount modifyBind(ShardSocialAccount shardSocialAccount) {
        SocialAccountItem socialAccountItem = Optional.ofNullable(shardSocialAccount
                .getSocialAccountList())
                .flatMap(social -> social.stream().findFirst())
                .orElseThrow(() -> new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage()));
        String channelId = Optional.ofNullable(socialAccountItem.getChannelId())
                .orElseThrow(() -> new BusinessException(V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getFrontMessage()));
        if (StringUtil.isNotBlank(channelId)) {
            shardSocialAccount = addShardSocialAccountItem(shardSocialAccount.getIdentityId(), socialAccountItem);
        }
        return shardSocialAccount;
    }

    public ShardSocialAccount migrateBind(ShardSocialAccount shardSocialAccount) {
        //取出tenantId并校验是否为空
        String tenantId = shardSocialAccount.getTenantId();
        //取出SocialAccountItem的值
        SocialAccountItem socialAccountItem = Optional.ofNullable(shardSocialAccount
                .getSocialAccountList())
                .flatMap(social -> social.stream().findFirst())
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
        String channelId = Optional.ofNullable(socialAccountItem.getChannelId())
                .orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
        String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channelId);
        if (this.validateUnionIdConfigExisting(tenantId, channelId)) {
            if (StringUtils.isBlank(unionIdType)) {
                throw new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage());
            }
            if (StringUtils.isBlank(socialAccountItem.getUnionId())) {
                //需要通过调用ACL服务获取unionId
                String unionId = this.fetchAclServiceImpl.fetchUnionId(tenantId, channelId, socialAccountItem.getBindId());
                socialAccountItem.setUnionId(unionId);
            }
            //前端传入unionId
            unionIdValidate(tenantId, socialAccountItem.getUnionId(), shardSocialAccount.getAccountId(), unionIdType);
        } else {
            socialAccountItem.setUnionId(null);
        }
        this.bindIdValidate(tenantId, channelId, socialAccountItem.getBindId(), shardSocialAccount.getAccountId());
        return addShardSocialAccount(shardSocialAccount.getIdentityId(), socialAccountItem);
    }

    /**
     * 删除绑定关系
     *
     * @param shardSocialAccount shardSocialAccount
     * @author xusheng
     * @date 2021/7/5 13:57
     */
    public void delete(ShardSocialAccount shardSocialAccount) {
        shardSocialAccount.addUpdatedTime();
        shardSocialAccountRepository.save(shardSocialAccount);
    }

    /**
     * 添加或者更新绑定信息
     *
     * @param identityId        userId
     * @param socialAccountItem socialAccountItem
     * @author xusheng
     * @date 2021/6/8 20:27
     */
    private ShardSocialAccount addShardSocialAccount(IdentityId identityId, SocialAccountItem socialAccountItem) {
        ShardSocialAccount dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(identityId.getTenantId(), identityId.getAccountId());
        //会员存在绑定关系
        if (Optional.ofNullable(dbShardSocialAccount).isPresent()) {
            List<SocialAccountItem> socialAccountItemList = Optional.ofNullable(dbShardSocialAccount.getSocialAccountList()).orElseGet(ArrayList::new);
            if (Optional.of(socialAccountItemList)
                    .filter(socialAccountItems -> !socialAccountItems.isEmpty()).isPresent()) {
                socialAccountItemList.removeIf(socialAccountItem1 -> socialAccountItem.getChannel().sameValueAs(socialAccountItem1.getChannel()));
            }
            socialAccountItemList.add(socialAccountItem);
            dbShardSocialAccount.setSocialAccountList(socialAccountItemList);
            dbShardSocialAccount.addUpdatedTime();
        } else {
            dbShardSocialAccount = new ShardSocialAccount();
            dbShardSocialAccount.build(identityId, Collections.singletonList(socialAccountItem));
        }
        return dbShardSocialAccount;
    }

    private ShardSocialAccount addShardSocialAccountItem(IdentityId identityId, SocialAccountItem socialAccountItem) {
        ShardSocialAccount dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(identityId.getTenantId(), identityId.getAccountId());
        //会员存在绑定关系
        if (Optional.ofNullable(dbShardSocialAccount).isPresent() && Optional.ofNullable(dbShardSocialAccount.getSocialAccountList()).filter(list -> !list.isEmpty()).isPresent()) {
            List<SocialAccountItem> socialAccountItemList = dbShardSocialAccount.getSocialAccountList();
            List<SocialAccountItem> list = new ArrayList<>();
            if (socialAccountItemList.stream().noneMatch(item -> item.getChannelId().equals(socialAccountItem.getChannelId()))) {
                list.add(socialAccountItem);
            } else {
                Optional<SocialAccountItem> socialAccount = socialAccountItemList.stream().filter(item -> item.getChannelId().equals(socialAccountItem.getChannelId())).findFirst();
                if (socialAccount.isPresent() && !Optional.ofNullable(socialAccount.get().getBindId()).isPresent() && Optional.ofNullable(socialAccountItem.getBindId()).isPresent()) {
                    socialAccountItemList.removeIf(c -> c.getChannelId().equals(socialAccountItem.getChannelId()));
                    list.add(socialAccountItem);
                }

            }

            socialAccountItemList.addAll(new HashSet<>(list));
            socialAccountItemList.removeIf(item -> StringUtils.isBlank(item.getBindId()) && StringUtils.isBlank(item.getUnionId()));
            dbShardSocialAccount.setSocialAccountList(socialAccountItemList.stream().distinct().collect(Collectors.toList()));
            dbShardSocialAccount.addUpdatedTime();
        } else {
            dbShardSocialAccount = new ShardSocialAccount();
            dbShardSocialAccount.build(identityId, Collections.singletonList(socialAccountItem));
        }
        return dbShardSocialAccount;
    }

    /**
     * 验证绑定的数据是否需要unionId绑定
     *
     * @param tenantId  租戶Id
     * @param channelId 渠道Id
     * @return true or false
     */
    public boolean validateUnionIdConfigExisting(String tenantId, String channelId) {
        Optional<String> result = Optional.ofNullable(LocalCacheConfigUtils.getHasUnionId(tenantId));
        return result.map(value -> Arrays.asList(value.split(COMMA)).contains(channelId)).orElse(false);
    }

    /**
     * 校验unionId是否被使用
     *
     * @param tenantId tenantId
     * @param unionId  unionId
     * @param memberId memberId
     * @author xusheng
     * @date 2021/4/28 10:46
     */
    public void unionIdValidate(String tenantId, String unionId, String memberId, String unionIdType) {
        UnionIdMapping unionIdMapping = fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(tenantId, unionId, unionIdType);
        ShardSocialAccount shardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenantId, memberId);
        if (Optional.ofNullable(unionIdMapping).isPresent()) {
            if (!unionIdMapping.getAccountId().equals(memberId)) {
                throw new BusinessException(UNION_ID_DATA_CONFLICT.getCode(), UNION_ID_DATA_CONFLICT.getV2Code(), UNION_ID_DATA_CONFLICT.getMessage());
            }
        } else if (Optional.ofNullable(shardSocialAccount).map(ShardSocialAccount::getSocialAccountList).isPresent()) {
            shardSocialAccount.getSocialAccountList().forEach(socialAccountItem -> Optional.ofNullable(socialAccountItem.getUnionId()).ifPresent(s -> {
                if (StringUtils.isNotBlank(socialAccountItem.getUnionType()) && unionIdType.equals(socialAccountItem.getUnionType()) && !unionId.equals(s)) {
                    throw new BusinessException(UNION_ID_DATA_TYPE_CONFLICT.getCode(), UNION_ID_DATA_TYPE_CONFLICT.getV2Code(), UNION_ID_DATA_TYPE_CONFLICT.getMessage());
                }
            }));
        }
        //会员已经存在mapping关系则不保存
        if (!Optional.ofNullable(unionIdMapping).isPresent()) {
            UnionIdMapping unionIdMapping2 = new UnionIdMapping();
            unionIdMapping2.build(tenantId, unionId, unionIdType, memberId);
            unionIdMappingDao.save(unionIdMapping2);
        }
    }

    /**
     * 校验bindId是否被使用
     * 如果account.getSocialAccountList()为空则说明是people X场景入会
     *
     * @author xusheng
     * @date 2021/4/28 10:46
     */
    public void bindIdValidate(String tenantId, String channelId, String bindId, String memberId) {
        if (StringUtils.isBlank(bindId)) {
            return;
        }
        //查询bindId对应绑定信息
        BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(tenantId, bindId, channelId);
        ShardSocialAccount shardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenantId, memberId);
        //根据bindId,channelId查询bindAccount,若存在，判断查询出的绑定的userId是否与请求的userId一致，若一致，则返回绑定成功
        // 若不一致，则抛出异常：绑定数据已经被另一个账号绑定
        Optional.ofNullable(bindIdMapping).ifPresent(bindIdMapping2 -> {
            if (!memberId.equals(bindIdMapping2.getAccountId())) {
                throw new BusinessException(BIND_DATA_CONFLICT.getCode(), BIND_DATA_CONFLICT.getV2Code(), BIND_DATA_CONFLICT.getMessage());
            }
        });
        //若用户已经绑定该channelId的bindId，若已绑定的bindId与传入的不一致，则报错：账号已绑定相同类型的平台账号
        Optional.ofNullable(shardSocialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .filter(socialAccountItemList -> !socialAccountItemList.isEmpty())
                .ifPresent(socialAccountItemList -> socialAccountItemList.forEach(socialAccountItem -> {
                    if (socialAccountItem.getChannel().getChannelId().equals(channelId) && !bindId.equals(socialAccountItem.getBindId())) {
                        throw new BusinessException(BIND_DATA_TYPE_CONFLICT.getCode(), BIND_DATA_TYPE_CONFLICT.getV2Code(), BIND_DATA_TYPE_CONFLICT.getMessage());
                    }
                }));
        //bindId和channelId在bindIdMapping表中不存在，需要添加
        if (!Optional.ofNullable(bindIdMapping).isPresent()) {
            bindIdMapping = new BindIdMapping();
            IdentityId identityId = new IdentityId(tenantId, memberId);
            bindIdMapping.build(identityId, bindId, channelId);
            bindIdMappingDao.save(bindIdMapping);
        }

    }

    /**
     * 获取需要解绑参数
     *
     * @param shardSocialAccount shardSocialAccount 需要同步DMP和双写事件的数据
     * @param unBindRoute        unBindRoute
     * @param channel            channel
     * @param unionIdMapping     unionIdMapping
     * @author xusheng
     * @date 2021/6/21 9:45
     */
    public ShardSocialAccount getShardSocialAccountByUnBindType(ShardSocialAccount shardSocialAccount, String unBindRoute, Channel channel, UnionIdMapping unionIdMapping) {
        //根据会员账号解绑，解除当前会员下所有的绑定关系
        List<SocialAccountItem> socialAccountItemList = new ArrayList<>();
        ShardSocialAccount dbShardSocialAccount = null;
        if (UnBindRouteEnum.MEMBER_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey())) {
            //根据tenantId和accountId查询会员所有绑定信息
            dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId());
            //根据会员账号封装解绑数据
            assembleShardSocialAccountByMemberId(shardSocialAccount, unionIdMapping, socialAccountItemList, dbShardSocialAccount);
        }
        //根据bindId解绑，解除当前bindId和channelId对应的绑定关系
        if (UnBindRouteEnum.BIND_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey())) {
            Account account = fetchMappingService.fetchByTenantIdAndChannelIdAndBindId(shardSocialAccount.getTenantId(), channel.getChannelId(), shardSocialAccount.getBindId());
            //根据tenantId和accountId获取所有的bindId
            dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.getTenantId(), account.getAccountId());
            //根据bindId封装解绑数据
            assembleShardSocialAccountByBindId(shardSocialAccount, channel, unionIdMapping, socialAccountItemList, dbShardSocialAccount);
        }
        //根据unionId解绑，解除当前unionId和unionIdType下所有的绑定关系
        if (UnBindRouteEnum.UNION_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey())) {
            Account account = fetchMappingService.fetchByTenantIdAndUnionId(shardSocialAccount.getTenantId(), shardSocialAccount.getUnionId(), channel.getUnionType());
            //根据tenantId和accountId获取所有的bindId
            dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.getTenantId(), account.getAccountId());
            //根据unionId封装解绑数据
            assembleShardSocialAccountByUnionId(shardSocialAccount, channel, unionIdMapping, socialAccountItemList, dbShardSocialAccount);
        }
        //根据会员账号和渠道解绑，解除当前会员账号和
        if (UnBindRouteEnum.MEMBER_ID_AND_CHANNEL_ID.getKey().equals(UnBindRouteEnum.getByKeyOrValue(unBindRoute).getKey())) {
            //根据tenantId和accountId获取所有的bindId
            dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId());
            //根据会员账号和渠道标识
            assembleShardSocialAccountByMemberIdAndChannelId(shardSocialAccount, channel, unionIdMapping, socialAccountItemList, dbShardSocialAccount);
        }
        return dbShardSocialAccount;
    }

    /**
     * 根据会员账号封装解绑数据
     *
     * @param shardSocialAccount    shardSocialAccount
     * @param unionIdMapping        unionIdMapping
     * @param socialAccountItemList socialAccountItemList
     * @param dbShardSocialAccount  dbShardSocialAccount
     * @author xusheng
     * @date 2021/7/5 21:49
     */
    private void assembleShardSocialAccountByMemberId(ShardSocialAccount shardSocialAccount, UnionIdMapping unionIdMapping, List<SocialAccountItem> socialAccountItemList, ShardSocialAccount dbShardSocialAccount) {
        Optional.ofNullable(dbShardSocialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .filter(dbSocialAccountItems -> !dbSocialAccountItems.isEmpty())
                .ifPresent(dbSocialAccountItems -> {
                    Iterator<SocialAccountItem> socialAccountItemIterator = dbSocialAccountItems.iterator();
                    while (socialAccountItemIterator.hasNext()) {
                        SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
                        socialAccountItemList.add(socialAccountItem);
                        //判断是否需要删除unionId mapping
                        isDeleteUnionIdMapping(shardSocialAccount.getTenantId(), socialAccountItem.getUnionType(), dbSocialAccountItems, unionIdMapping);
                        socialAccountItemIterator.remove();
                    }
                    shardSocialAccount.setSocialAccountList(socialAccountItemList);
                });
    }

    /**
     * 根据bindId封装解绑数据
     *
     * @param shardSocialAccount    shardSocialAccount
     * @param channel               channel
     * @param unionIdMapping        unionIdMapping
     * @param socialAccountItemList socialAccountItemList
     * @param dbShardSocialAccount  dbShardSocialAccount
     * @author xusheng
     * @date 2021/7/5 22:04
     */
    private void assembleShardSocialAccountByBindId(ShardSocialAccount shardSocialAccount, Channel channel, UnionIdMapping unionIdMapping, List<SocialAccountItem> socialAccountItemList, ShardSocialAccount dbShardSocialAccount) {
        Optional.ofNullable(dbShardSocialAccount.getSocialAccountList())
                .filter(dbSocialAccountItems -> !dbSocialAccountItems.isEmpty())
                .ifPresent(dbSocialAccountItems -> {
                    Iterator<SocialAccountItem> socialAccountItemIterator = dbSocialAccountItems.iterator();
                    while (socialAccountItemIterator.hasNext()) {
                        SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
                        //判断是否需要删除unionId mapping
                        if (socialAccountItem.getBindId().equals(shardSocialAccount.getBindId()) && socialAccountItem.getChannelId().equals(channel.getChannelId())) {
                            isDeleteUnionIdMapping(shardSocialAccount.getTenantId(), socialAccountItem.getUnionType(), dbSocialAccountItems, unionIdMapping);
                            socialAccountItemList.add(socialAccountItem);
                            socialAccountItemIterator.remove();
                        }
                    }
                    shardSocialAccount.setSocialAccountList(socialAccountItemList);
                });
    }

    /**
     * 根据unionId封装解绑数据
     *
     * @param shardSocialAccount    shardSocialAccount
     * @param channel               channel
     * @param unionIdMapping        unionIdMapping
     * @param socialAccountItemList socialAccountItemList
     * @param dbShardSocialAccount  dbShardSocialAccount
     * @author xusheng
     * @date 2021/7/5 22:07
     */
    private void assembleShardSocialAccountByUnionId(ShardSocialAccount shardSocialAccount, Channel channel, UnionIdMapping unionIdMapping, List<SocialAccountItem> socialAccountItemList, ShardSocialAccount dbShardSocialAccount) {
        Optional.ofNullable(dbShardSocialAccount).map(ShardSocialAccount::getSocialAccountList)
                .filter(dbSocialAccountItems -> !dbSocialAccountItems.isEmpty())
                .ifPresent(dbSocialAccountItems -> {
                    Iterator<SocialAccountItem> socialAccountItemIterator = dbSocialAccountItems.iterator();
                    while (socialAccountItemIterator.hasNext()) {
                        SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
                        if (channel.getUnionType().equals(socialAccountItem.getUnionType())) {
                            //判断是否需要删除unionId mapping
                            isDeleteUnionIdMapping(shardSocialAccount.getTenantId(), socialAccountItem.getUnionType(), dbSocialAccountItems, unionIdMapping);
                            socialAccountItemList.add(socialAccountItem);
                            socialAccountItemIterator.remove();
                        }
                    }
                    shardSocialAccount.setSocialAccountList(socialAccountItemList);
                });
    }

    /**
     * 根据会员账号和渠道标识封装解绑数据
     *
     * @param shardSocialAccount    shardSocialAccount
     * @param channel               channel
     * @param unionIdMapping        unionIdMapping
     * @param socialAccountItemList socialAccountItemList
     * @param dbShardSocialAccount  dbShardSocialAccount
     * @author xusheng
     * @date 2021/7/5 22:17
     */
    private void assembleShardSocialAccountByMemberIdAndChannelId(ShardSocialAccount shardSocialAccount, Channel channel, UnionIdMapping unionIdMapping, List<SocialAccountItem> socialAccountItemList, ShardSocialAccount dbShardSocialAccount) {
        Optional.ofNullable(dbShardSocialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .ifPresent(dbSocialAccountItems -> {
                    Iterator<SocialAccountItem> socialAccountItemIterator = dbSocialAccountItems.iterator();
                    while (socialAccountItemIterator.hasNext()) {
                        SocialAccountItem socialAccountItem = socialAccountItemIterator.next();
                        if (socialAccountItem.getChannelId().equals(channel.getChannelId())) {
                            //判断是否需要删除unionId mapping
                            isDeleteUnionIdMapping(shardSocialAccount.getTenantId(), socialAccountItem.getUnionType(), dbSocialAccountItems, unionIdMapping);
                            socialAccountItemList.add(socialAccountItem);
                            socialAccountItemIterator.remove();
                        }
                    }
                    shardSocialAccount.setSocialAccountList(socialAccountItemList);
                });
    }

    /**
     * 判断是否需要删除unionId mapping
     *
     * @param tenantId             tenantId
     * @param unionIdType          unionIdType
     * @param dbSocialAccountItems dbSocialAccountItems
     * @param unionIdMapping       unionIdMapping
     * @author xusheng
     * @date 2021/7/5 13:31
     */
    private void isDeleteUnionIdMapping(String tenantId, String unionIdType, List<SocialAccountItem> dbSocialAccountItems, UnionIdMapping unionIdMapping) {
        if (StringUtils.isNotBlank(unionIdType)) {
            //example:20,58,125,166,170,180
            // TODO: 2021/12/8
            String result = Optional.ofNullable(LocalCacheConfigUtils.getChannelIds(tenantId, unionIdType)).orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
            //查询同一个租户下相同unionType的channelId List
            List<Long> allChannelIds = Arrays.stream(result.split(COMMA)).map(Long::parseLong).collect(Collectors.toList());
            //根据会员号和渠道集合查询绑定信息集合
            List<SocialAccountItem> socialAccountItems = dbSocialAccountItems.stream()
                    .filter(socialAccountItem -> allChannelIds.contains(Long.valueOf(socialAccountItem.getChannel().getChannelId()))).collect(toList());
            //如果最终集合大小是1并且传入的渠道在集合中，则需要解除unionId绑定关系
            if (socialAccountItems.size() == 1) {
                SocialAccountItem socialAccountItem = socialAccountItems.get(0);
                //解除unionId mapping
                if (Optional.ofNullable(socialAccountItem.getUnionId()).isPresent()) {
                    unionIdMapping.build(tenantId, socialAccountItem.getUnionId(), unionIdType);
                }
            }
        }

    }

    /**
     * 根据 type 类型解绑
     *
     * @param shardSocialAccount shardSocialAccount
     * @param type               type
     * @author xusheng
     * @date 2021/6/11 17:20
     */
    public List<ShardSocialAccount> unBindAll(ShardSocialAccount shardSocialAccount, String type) {
        List<ShardSocialAccount> shardSocialAccountList = new ArrayList<>();
        ShardSocialAccount dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(shardSocialAccount.getTenantId(), shardSocialAccount.getAccountId());
        if (ALL.equals(type)) {
            Optional.ofNullable(dbShardSocialAccount)
                    .map(ShardSocialAccount::getSocialAccountList)
                    .ifPresent(dbSocialAccountItemList -> dbSocialAccountItemList.
                            forEach(socialAccountItem ->
                                    shardSocialAccountList.add(new ShardSocialAccount(dbShardSocialAccount.getIdentityId(), Collections.singletonList(socialAccountItem)))));
        } else {
            Optional.ofNullable(dbShardSocialAccount)
                    .map(ShardSocialAccount::getSocialAccountList)
                    .ifPresent(dbSocialAccountItemList -> {
                        for (SocialAccountItem dbSocialAccountItem : dbSocialAccountItemList) {
                            if (type.equals(dbSocialAccountItem.getChannel().getUnionType())) {
                                shardSocialAccountList.add(new ShardSocialAccount(dbShardSocialAccount.getIdentityId(), Collections.singletonList(dbSocialAccountItem)));
                            }
                        }
                    });
        }
        return shardSocialAccountList;
    }

    /**
     * 更新和替换Bind_id
     *
     * @param updateBindIdCommand updateBindIdCommand
     * @author xusheng
     * @date 2021/6/16 9:52
     */
    public void updateBindIdValidator(UpdateBindIdCommand updateBindIdCommand) {
        if (Optional.ofNullable(updateBindIdCommand.getChannelId()).isPresent()) {
            BindIdMapping oldBindIdMapping = bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(updateBindIdCommand.getTenantId().toString(), updateBindIdCommand.getChannelId().toString(), updateBindIdCommand.getOldBindId());
            BindIdMapping newBindIdMapping = bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(updateBindIdCommand.getTenantId().toString(), updateBindIdCommand.getChannelId().toString(), updateBindIdCommand.getNewBindId());
            if (Optional.ofNullable(newBindIdMapping).isPresent()) {
                throw new BusinessException(ResultEnum.BIND_DATA_CONFLICT.getCode(), ResultEnum.BIND_DATA_CONFLICT.getV2Code(), ResultEnum.BIND_DATA_CONFLICT.getMessage());
            }
            Optional.ofNullable(oldBindIdMapping)
                    .filter(oldBindIdMapping1 -> oldBindIdMapping1.getAccountId().equals(updateBindIdCommand.getMemberId()))
                    .orElseThrow(() -> new BusinessException(ResultEnum.BIND_DATA_CONFLICT.getCode(), ResultEnum.BIND_DATA_CONFLICT.getV2Code(), ResultEnum.BIND_DATA_CONFLICT.getMessage()));
//        } else {
//            List<SocialAccount> oldBindAccounts = socialAccountService.fetchSocialAccountByBindId(updateBindIdCommand.getTenantId(), updateBindIdCommand.getOldBindId());
//            List<SocialAccount> newBindAccounts = socialAccountService.fetchSocialAccountByBindId(updateBindIdCommand.getTenantId(), updateBindIdCommand.getNewBindId());
//            oldBindAccounts = Optional.ofNullable(oldBindAccounts)
//                    .filter(socialAccounts -> !socialAccounts.isEmpty())
//                    .orElseThrow(() ->
//                            new com.pg.account.infrastructure.common.exception.BusinessException(com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_ID_NOT_EXIST.getCode(), com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_ID_NOT_EXIST.getV2Code(), com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_ID_NOT_EXIST.getMessage()));
//            if (Optional.ofNullable(newBindAccounts).filter(socialAccounts -> !socialAccounts.isEmpty()).isPresent()) {
//                throw new com.pg.account.infrastructure.common.exception.BusinessException(com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_DATA_CONFLICT.getCode(), com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_DATA_CONFLICT.getV2Code(), com.pg.account.infrastructure.common.exception.enums.ResultEnum.BIND_DATA_CONFLICT.getMessage());
//            }
//            oldBindAccounts.forEach(b -> saveUpdateRecord(updateBindIdCommand, b, socialAccountList));
//            account.setSocialAccountList(socialAccountList);
        }
    }

    /**
     * 替换bindId
     *
     * @param shardSocialAccount shardSocialAccount
     * @author xusheng
     * @date 2021/6/16 11:11
     */
    public List<ShardSocialAccount> replaceBindId(ShardSocialAccount shardSocialAccount) {
        String tenantId = shardSocialAccount.getTenantId();
        String accountId = shardSocialAccount.getAccountId();
        //取出SocialAccountItem的值
        List<SocialAccountItem> cmdSocialAccountItems = Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(),
                        ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(),
                        ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
        SocialAccountItem cmdSocialAccountItem = cmdSocialAccountItems.stream().findFirst().orElse(new SocialAccountItem());
        String channelId = Optional.of(cmdSocialAccountItem.getChannelId())
                .orElseThrow(() -> new BusinessException(ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getCode(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.CHANNEL_CONFIG_NOT_EXIST.getMessage()));
        String unionIdType = Optional.ofNullable(LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channelId)).orElseThrow(() -> new BusinessException(ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getV2Code(), ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage()));
        //根据memberId和channelId 查询是否存在相同类型绑定关系，如果存在全解
        List<ShardSocialAccount> shardSocialAccountList = new ArrayList<>();
        ShardSocialAccount dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenantId, accountId);
        Optional.ofNullable(dbShardSocialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .ifPresent(socialAccountItems -> socialAccountItems.forEach(dbSocialAccountItem -> {
                    if (unionIdType.equals(dbSocialAccountItem.getChannel().getUnionType())) {
                        unBindIdAssemble(tenantId, shardSocialAccountList, shardSocialAccount.getAccountId(), dbSocialAccountItem);
                    }
                }));
        BindIdMapping bindIdMapping = bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(tenantId, channelId, cmdSocialAccountItem.getBindId());
        Optional.ofNullable(bindIdMapping).ifPresent(bindIdMapping1 -> {
            ShardSocialAccount shardSocialAccount1 = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(bindIdMapping1.getBindIdMapId().getTenantId(), bindIdMapping1.getAccountId());
            Optional.ofNullable(shardSocialAccount1).map(ShardSocialAccount::getSocialAccountList).ifPresent(socialAccountItems -> socialAccountItems.forEach(socialAccountItem -> {
                if (unionIdType.equals(socialAccountItem.getChannel().getUnionType())) {
                    unBindIdAssemble(tenantId, shardSocialAccountList, bindIdMapping.getAccountId(), socialAccountItem);
                }
            }));
        });
        UnionIdMapping unionIdMapping = unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(tenantId, cmdSocialAccountItem.getUnionId(), unionIdType);
        Optional.ofNullable(unionIdMapping).ifPresent(unionIdMapping1 -> {
            ShardSocialAccount shardSocialAccount1 = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(unionIdMapping1.getUnionIdMapId().getTenantId(), unionIdMapping1.getAccountId());
            Optional.ofNullable(shardSocialAccount1).map(ShardSocialAccount::getSocialAccountList).ifPresent(socialAccountItems -> socialAccountItems.forEach(socialAccountItem -> {
                if (unionIdType.equals(socialAccountItem.getChannel().getUnionType())) {
                    unBindIdAssemble(tenantId, shardSocialAccountList, unionIdMapping.getAccountId(), socialAccountItem);
                }
            }));
        });
        return shardSocialAccountList;
    }

    private void unBindIdAssemble(String tenantId, List<ShardSocialAccount> shardSocialAccountList, String accountId, SocialAccountItem socialAccountItem) {
        IdentityId identityId = new IdentityId(tenantId, accountId);
        List<SocialAccountItem> socialAccountItemList1 = new ArrayList<>();
        socialAccountItemList1.add(socialAccountItem);
        shardSocialAccountList.add(new ShardSocialAccount(identityId, socialAccountItemList1));
    }

    /**
     * 删除socialaccount表信息和Mapping表信息
     *
     * @param bindIdMappingList bindIdMappingList
     * @param unionIdMapping    unionIdMapping
     */
    public boolean delMapping(List<BindIdMapping> bindIdMappingList, UnionIdMapping unionIdMapping) {
        boolean flag = false;
        Optional.ofNullable(bindIdMappingList).filter(bindIdMappingList1 -> !bindIdMappingList.isEmpty())
                .ifPresent(bindIdMappingList1 -> bindIdMappingList1.forEach(bindIdMapping -> bindIdMappingDao.deleteByBindIdMapIdTenantIdAndBindIdMapIdBindIdAndBindIdMapIdChannelId(bindIdMapping.getBindIdMapId().getTenantId(), bindIdMapping.getBindIdMapId().getBindId(), bindIdMapping.getBindIdMapId().getChannelId())));
        if (Optional.ofNullable(unionIdMapping).map(UnionIdMapping::getUnionIdMapId).isPresent() && StringUtils.isNotBlank(unionIdMapping.getUnionIdMapId().getUnionId())) {
            flag = true;
            unionIdMappingDao.deleteByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(unionIdMapping.getUnionIdMapId().getTenantId(), unionIdMapping.getUnionIdMapId().getUnionId(), unionIdMapping.getUnionIdMapId().getChannel());
        }

        return flag;
    }

    /**
     * 组装需要删除解绑的mapping关系
     *
     * @param shardSocialAccount 需要解绑的数据
     * @author xusheng
     * @date 2021/7/5 11:32
     */
    public List<BindIdMapping> isDelBindIdMapping(ShardSocialAccount shardSocialAccount) {
        List<BindIdMapping> bindIdMappingList = new ArrayList<>();
        Optional.ofNullable(shardSocialAccount)
                .map(ShardSocialAccount::getSocialAccountList)
                .filter(socialAccountItemList -> !socialAccountItemList.isEmpty())
                .ifPresent(socialAccountItemList -> socialAccountItemList.forEach(socialAccountItem -> {
                    //添加非空判断，用于注册绑定类型为unionId的不传bindId的场景
                    if (StringUtils.isNotBlank(socialAccountItem.getBindId())) {
                        BindIdMapping bindIdMapping = new BindIdMapping();
                        bindIdMapping.build(shardSocialAccount.getIdentityId(), socialAccountItem.getBindId(), socialAccountItem.getChannel().getChannelId());
                        bindIdMappingList.add(bindIdMapping);
                    }
                }));
        return bindIdMappingList;
    }

    /**
     * 保存绑定关系
     *
     * @param resultShardSocialAccount resultShardSocialAccount
     * @return void
     * @author xusheng
     * @date 2021/7/8 17:38
     */
    public void save(ShardSocialAccount resultShardSocialAccount) {
        shardSocialAccountRepository.save(resultShardSocialAccount);
    }

    public void saveIfExist(String tenant, String accountId, ShardSocialAccount resultShardSocialAccount) {
        ShardSocialAccount dbShardSocialAccount = shardSocialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(tenant, accountId);
        if (Optional.ofNullable(dbShardSocialAccount).isPresent()) {
            dbShardSocialAccount.setSocialAccountList(resultShardSocialAccount.getSocialAccountList());
            shardSocialAccountRepository.save(dbShardSocialAccount);
        } else {
            shardSocialAccountRepository.save(resultShardSocialAccount);
        }
    }

    /**
     * 删除socialAccount表信息和Mapping表信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     */
    public void delAllMapping(String tenantId, String accountId) {
        List<BindIdMapping> bindIdMappingList = bindIdMappingDao.findByAccountId(accountId);
        bindIdMappingList.forEach(bindIdMapping -> {
            if (tenantId.equals(bindIdMapping.getBindIdMapId().getTenantId())) {
                bindIdMappingDao.deleteByBindIdMapIdTenantIdAndBindIdMapIdBindIdAndBindIdMapIdChannelId(bindIdMapping.getBindIdMapId().getTenantId(), bindIdMapping.getBindIdMapId().getBindId(), bindIdMapping.getBindIdMapId().getChannelId());
            }
        });
        List<UnionIdMapping> unionIdMappingList = unionIdMappingDao.findByAccountId(accountId);
        unionIdMappingList.forEach(unionIdMapping -> {
            if (tenantId.equals(unionIdMapping.getUnionIdMapId().getTenantId())) {
                unionIdMappingDao.deleteByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(unionIdMapping.getUnionIdMapId().getTenantId(), unionIdMapping.getUnionIdMapId().getUnionId(), unionIdMapping.getUnionIdMapId().getChannel());
            }
        });
    }
}
