package com.pg.account.sharding.infrastructure.datastream.servicebus;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.component.uid.UidGenerator;
import com.pg.account.sharding.application.event.UpdateCounterEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.CounterInfo;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.infrastructure.jpa.counter.CounterDao;
import com.pg.account.sharding.infrastructure.jpa.counter.ShardCounter;
import com.pg.account.sharding.infrastructure.servicebus.AbstractConsumer;
import com.pg.account.sharding.infrastructure.servicebus.ServiceBusQueueTopicEnum;
import com.pg.account.sharding.infrastructure.switchconfig.SwitchConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;


/**
 * @author mrluve
 * @date 2022/6/29 13:15
 **/
@Slf4j
@Service
public class OlayC2UpdateCounterConsumer extends AbstractConsumer {


    public static final String USERS_ID = "usersId";
    public static final String TENANT_ID = "tenantId";
    public static final String FIRST_PURCHASE_COUNTER_CODE = "firstPurchaseCounterCode";
    public static final String FIRST_PURCHASE_COUNTER_NAME = "firstPurchaseCounterName";
    public static final String PICKUP_COUNTER_CODE = "pickupCounterCode";
    public static final String PICKUP_COUNTER_NAME = "pickupCounterName";
    public static final String REGISTRATION_COUNTER_CODE = "registrationCounterCode";
    public static final String REGISTRATION_COUNTER_NAME = "registrationCounterName";
    public static final String CREATE_TIME = "createTime";
    public static final String MODIFY_TIME = "modifyTime";
    public static final String LAST_PURCHASE_COUNTER_CODE = "lastPurchaseCounterCode";
    public static final String LAST_PURCHASE_COUNTER_NAME = "lastPurchaseCounterName";
    public static final String BELONG_TO_COUNTER_CODE = "belongToCounterCode";
    public static final String BELONG_TO_COUNTER_NAME = "belongToCounterName";
    private final CounterDao counterDao;
    private final UidGenerator uidGenerator;
    private final SwitchConfiguration switchConfiguration;

    @Value("${send.isSend}")
    private boolean isSend;

    @Autowired
    public OlayC2UpdateCounterConsumer(CounterDao counterDao,
                                       UidGenerator uidGenerator, SwitchConfiguration switchConfiguration) {
        this.counterDao = counterDao;
        this.uidGenerator = uidGenerator;
        this.switchConfiguration = switchConfiguration;
    }

    private void saveOlayJoinCounter(JSONObject jsonObject) {
        String accountId = jsonObject.containsKey(USERS_ID) ? jsonObject.getString(USERS_ID) : null;
        String tenantId = jsonObject.containsKey(TENANT_ID) ? jsonObject.getString(TENANT_ID) : null;
        saveShardingCounter(tenantId, accountId, jsonObject, true);

    }

    private void saveShardingCounter(String tenantId, String accountId, JSONObject jsonObject, boolean flag) {
        IdentityId identityId = new IdentityId(tenantId, accountId);
        CounterInfo counterInfo = new CounterInfo(jsonObject.getString(REGISTRATION_COUNTER_CODE), jsonObject.getString(REGISTRATION_COUNTER_NAME), null, null, jsonObject.getString(PICKUP_COUNTER_CODE), jsonObject.getString(PICKUP_COUNTER_NAME), jsonObject.getString(FIRST_PURCHASE_COUNTER_CODE), jsonObject.getString(FIRST_PURCHASE_COUNTER_NAME),
                null, null, null, jsonObject.getString(LAST_PURCHASE_COUNTER_CODE), jsonObject.getString(LAST_PURCHASE_COUNTER_NAME), jsonObject.getString(BELONG_TO_COUNTER_CODE), jsonObject.getString(BELONG_TO_COUNTER_NAME), LocalDateTime.now(), LocalDateTime.now());
        ShardCounter shardCounter = new ShardCounter();
        shardCounter.setIdentityId(identityId);
        shardCounter.setCounter(counterInfo);
        ShardCounter dbShardCounter = counterDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenantId, accountId);
        if (Optional.ofNullable(dbShardCounter).isPresent()) {
            shardCounter.setId(dbShardCounter.getId());
            shardCounter.buildFromDb(dbShardCounter);
            shardCounter.addUpdatedTime();
            shardCounter.setCreatedTime(dbShardCounter.getCreatedTime());
        } else {
            shardCounter.addCreateTime();
        }
        counterDao.save(shardCounter);
        if (flag && isSend) {
            Account account = new Account();
            account.setIdentityId(shardCounter.getIdentityId());
            account.setCounter(shardCounter.getCounter());
            UpdateCounterEvent updatedCounterEvent = new UpdateCounterEvent(this, account);
            SpringContextUtil.getApplicationContext().publishEvent(updatedCounterEvent);
        }
    }


    @Override
    protected void doBusiness(JSON json) {
        JSONArray bodyContent = (JSONArray) json;
        log.info("OlayC2 consume start...,and body is:{}", bodyContent);
        bodyContent.forEach(a -> {
            JSONObject body = (JSONObject) a;
            JSONObject jsonObject = body.getJSONObject("OlayData");
            Optional.ofNullable(jsonObject).ifPresent(this::saveOlayJoinCounter);
        });
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.OLAY_COUNTER.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.OLAY_COUNTER;
    }
}
