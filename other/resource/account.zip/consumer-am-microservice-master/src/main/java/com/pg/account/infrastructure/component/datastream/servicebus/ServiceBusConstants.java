package com.pg.account.infrastructure.component.datastream.servicebus;

/**
 * @author lfx
 * @date 2020/11/23 11:18
 */
public class ServiceBusConstants {

//    public static final String LOYALTY_FIRST_PURCHASE_QUEUE_INPUT_CHANNEL = "qFirstCounterOlayInputChannel";
//
//    public static final String MESSAGE_OPT_UPDATE_TOPIC_INPUT_CHANNEL = "tSmsSubscribeAmSSmsSubscribeAmInputChannel";
//
//    public static final String OLAY_C2_BATCH_UPDATE_COUNTER = "olaycounterInputChannel";
//
//    public static final String SKII_C2_BATCH_UPDATE_COUNTER = "skiicounterInputChannel";
//
//    public static final String COOPERATION_OPT_IN = "cooperationoptinInputChannel";

    public static final String AM_SHARDING_SYNC = "shardingsyncInputChannel";


    private ServiceBusConstants() {
        //私有构造方法
    }
}
