package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.sharding.infrastructure.datastream.servicebus.bean.OptBean;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegProfileEventBean implements Serializable {

    private static final long serialVersionUID = -8329059238789165568L;
    @JSONField(name = "member_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @JSONField(name = "marketing_program_id")
    private int marketingProgramId;
    @JSONField(name = "update_flag")
    private char updateFlag;
    @JSONField(name = "registration_brand")
    private String registrationBrand;
    @JSONField(name = "registration_channel")
    private String registrationChannel;
    @JSONField(name = "registration_source")
    private String registrationSource;
    @JSONField(name = "registration_datetime")
    private Timestamp registrationDatetime;
    private String customer;
    private String regStore;
    @JSONField(name = "create_datetime")
    private Timestamp createDatetime;
    @JSONField(name = "modify_datetime")
    private Timestamp modifyDatetime;
    @JSONField(name = "full_name")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @JSONField(name = "nick_name")
    private String nickName;
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthdate;
    private String income;
    private String occupation;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String email;
    @JSONField(name = "mobile_phone")
    private String mobilePhone;
    @JSONField(name = "mobile_sha256")
    private String mobileSha256;
    @JSONField(name = "mobile_head")
    private String mobileHead;
    @JSONField(name = "address_id")
    private Long addressId;
    private String province;
    private String city;
    private String district;
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    private String zipcode;
    @JSONField(name = "device_id")
    private String deviceId;
    @JSONField(name = "device_id_type")
    private String deviceIdType;
    private List<AttributeBean> attributes;
    private List<DependentBean> dependents;
    @JSONField(name = "subscription_version")
    private String subscriptionVersion;
    private List<OptBean> opts;
    private List<JobBean> jobs;
    private List<EducationBean> educations;
    @JSONField(name = "interpersonal_relationships")
    private List<InterpersonalRelationshipBean> interpersonalRelationshipBeans;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

}
