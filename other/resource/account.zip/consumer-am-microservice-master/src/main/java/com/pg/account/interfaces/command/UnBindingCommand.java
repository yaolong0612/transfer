package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.NUMBER_PATTERN;

/**
 * @author JackSun
 * @date 2017/4/13
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UnBindingCommand implements Serializable {
    private static final long serialVersionUID = 6738239296417860420L;

    @ApiModelProperty(value = "租户ID", example = "10004", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "渠道ID", example = "12", required = true)
    @NotNull(message = "channel is not exist")
    private Long channelId;
    @ApiModelProperty(value = "会员ID", example = "1234", required = true)
    @Pattern(regexp = NUMBER_PATTERN, message = "memberId format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "第三方的社交绑定ID", example = "oxD-dt-Ev379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "第三方的社交平台账号唯一识别码用于关联社交绑定ID", example = "ouuEv379xF3MHK6Pk")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    @ApiModelProperty(value = "根据解绑路由规则进行解绑，" +
            "路由规则为：1：memberId，解除memberId下所有的绑定关系" +
            "2：bindId+channelId，解绑bindId+channelId的绑定关系" +
            "3：unionId+channelId，解除unionId+channelId对应的绑定类型的所有绑定关系" +
            "4：memberId+channelId，解绑memberId和channelId的绑定关系", example = "1")
    private String unBindRoute;
}
