package com.pg.account.infrastructure.component.httpcliendutil;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.*;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

/**
 * @author Simon
 * @date 2016/10/19
 */
@Configuration
@Slf4j
public class HttpClientConfig {
    @Bean(name = "poolingHttpClientConnectionManager")
    public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
        PoolingHttpClientConnectionManager connectionManager =
                new PoolingHttpClientConnectionManager(1, TimeUnit.MINUTES);
        connectionManager.setMaxTotal(5000);
        connectionManager.setDefaultMaxPerRoute(200);
        return connectionManager;
    }

    @Bean(name = "keepAliveHttpClientBuilder")
    public HttpClientBuilder keepAliveHttpClientBuilder(@Qualifier("poolingHttpClientConnectionManager")
                                                                PoolingHttpClientConnectionManager connectionManager) {
        HttpClientBuilder httpClientBuilder = HttpClients.custom();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy());
        httpClientBuilder.setRetryHandler(new DefaultHttpRequestRetryHandler(1, true));
        return httpClientBuilder;
    }

    @Bean(name = "closeableHttpClient")
    public CloseableHttpClient closeableHttpClient(@Qualifier("keepAliveHttpClientBuilder") HttpClientBuilder httpClientBuilder) {
        return httpClientBuilder.build();
    }

    @Bean
    public RequestConfig requestConfig() {
        RequestConfig.Builder builder = RequestConfig.custom();
        builder.setConnectTimeout(6000);
        builder.setConnectionRequestTimeout(10000);
        builder.setSocketTimeout(6000);
        return builder.build();
    }

    @Bean(destroyMethod = "shutdown")
    public IdleConnectionEvictor idlePoolingHttpClientConnectionManagerEvictor(@Qualifier("poolingHttpClientConnectionManager")
                                                                                       PoolingHttpClientConnectionManager connectionManager) {
        IdleConnectionEvictor connectionEvictor =
                new IdleConnectionEvictor(connectionManager, 20L, TimeUnit.SECONDS, 1L, TimeUnit.MINUTES);
        connectionEvictor.start();
        return connectionEvictor;
    }

}
