package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.domain.service.annotation.*;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.common.utils.StringValidUtil;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.EmailMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.OpenUidMappingDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Valid;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

import static com.pg.account.infrastructure.common.constants.AccountConstants.COLON;
import static com.pg.account.infrastructure.common.constants.AccountConstants.COMMA;

/**
 * 注解校验实现类
 *
 * @author lfx
 * @date 2021/4/22 9:54
 */
@Slf4j
public class AccountBaseValidator<T extends Annotation> implements ConstraintValidator<T, @Valid Account> {


    protected Predicate<Account> predicate = c -> true;
    @Autowired
    protected FetchMappingService fetchMappingService;
    @Autowired
    protected AccountInfoDao accountInfoDao;
    @Autowired
    protected OpenUidMappingDao openUidMappingDao;
    @Autowired
    private ExtraAttributeDao extraAttributeDao;

    @Override
    public boolean isValid(Account account, ConstraintValidatorContext constraintValidatorContext) {
        return predicate.test(account);
    }

    /**
     * 渠道校验 如果渠道不存在则返回false
     */
    public static class ChannelValid extends AccountBaseValidator<ChannelExistValid> {
        @Override
        public void initialize(ChannelExistValid constraintAnnotation) {
            predicate = account -> {
                Optional<String> result = Optional.ofNullable(LocalCacheConfigUtils.getChannelId(account.getTenantId()));
                if (result.isPresent()) {
                    String[] x = result.get().split(COMMA);
                    Optional<String> channelId = Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelId);
                    boolean isPresent = channelId.isPresent();
                    return isPresent && Stream.of(x).anyMatch(s -> s.equals(channelId.get()));
                }
                return false;
            };
        }
    }

    /**
     * attrIdId校验 如果attrId不存在则返回false
     */
    public static class AttrIdValid extends AccountBaseValidator<IsAttrIdExist> {
        @Override
        public void initialize(IsAttrIdExist constraintAnnotation) {
            predicate = account -> {
                boolean flag = true;
                //先判断入参是否传入属性信息
                Optional<List<ExtraAttributeItem>> optionalExtraAttributeItemList = Optional.ofNullable(account.getUserAdditionalInfo())
                        .map(UserAdditionalInfo::getExtraAttributeList)
                        .filter(extraAttributeItemList -> !extraAttributeItemList.isEmpty());
                if (optionalExtraAttributeItemList.isPresent()) {
                    String result = LocalCacheConfigUtils.getAttrId(account.getTenantId());
                    //在判断租户是否有配置属性信息
                    if (StringUtils.isNotBlank(result)) {
                        String[] x = result.split(COMMA);
                        for (ExtraAttributeItem extraAttributeItem : optionalExtraAttributeItemList.get()) {
                            if (Arrays.stream(x).noneMatch(s -> s.split(COLON)[0].equals(extraAttributeItem.getAttrId()))) {
                                flag = false;
                                break;
                            }
                        }
                    } else {
                        //入参传入属性信息，但是该租户不存在属性配置
                        flag = false;
                    }
                }
                return flag;
            };
        }
    }

    /**
     * 手机号校验
     */
    public static class MobileValid extends AccountBaseValidator<IsValidMobile> {
        @Override
        public void initialize(IsValidMobile constraintAnnotation) {
            predicate = account -> {
                if (Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getMobile).isPresent()) {
                    MobileMapping mobileMapping = fetchMappingService.fetchMobileByTenantIdAndMobile(account.getTenantId(), account.getMobile());
                    String accountId = Optional.of(account).map(Account::getIdentityId).map(IdentityId::getAccountId).orElse(null);
                    return !Optional.ofNullable(mobileMapping).isPresent() || mobileMapping.getAccountId().equals(accountId);
                }
                return true;
            };
        }
    }

    /**
     * 判断邮箱是否合规（已被他人使用）
     */
    public static class EmailValid extends AccountBaseValidator<IsValidEmail> {
        @Override
        public void initialize(IsValidEmail constraintAnnotation) {
            predicate = account -> {
                if (Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getContact).map(Contact::getEmail).isPresent()) {
                    EmailMapping emailMapping = fetchMappingService.fetchEmailByTenantIdAndEmail(account.getTenantId(), account.getEmail());
                    String accountId = Optional.of(account).map(Account::getIdentityId).map(IdentityId::getAccountId).orElse(null);
                    return !Optional.ofNullable(emailMapping).isPresent() || emailMapping.getAccountId().equals(accountId);
                }
                return true;
            };
        }
    }

    /**
     * 判断是否是成年人
     * <p>
     * true -> 成人   false -> 未成年
     */
    public static class AdultValid extends AccountBaseValidator<IsAdult> {
        @Override
        public void initialize(IsAdult constraintAnnotation) {
            predicate = account -> {
                if (Optional.ofNullable(account.getUserBasicInfo()).map(UserBasicInfo::getBirthday).isPresent()) {
                    return StringValidUtil.isAdult(account.getUserBasicInfo().getBirthday());
                }
                return true;
            };
        }
    }


    /**
     * 判断source是否有效
     */
    public static class SourceValid extends AccountBaseValidator<IsValidSource> {
        @Override
        public void initialize(IsValidSource constraintAnnotation) {
            predicate = account -> {
                // 先判断CooperationOptIn的注册来源,如果不存在就用自身租户的来源
                if (!regSourceValid(account.getTenantId(), Optional.ofNullable(account.getRegistration()).map(Registration::getSource).orElse(null))) {
                    String result = Optional.ofNullable(LocalCacheConfigUtils.getCooperationOptIn(account.getTenantId(), account.getRegisterChannelId())).orElse(null);
                    if (Optional.ofNullable(result).isPresent()) {
                        return regSourceValid(result.split(COLON)[0], Optional.ofNullable(account.getRegistration()).map(Registration::getChannel).map(Channel::getChannelId).orElse(null));
                    } else {
                        return false;
                    }
                } else {
                    return true;
                }
            };
        }

        /**
         * 注册来源校验
         *
         * @param tenantId 租户
         * @param source   来源
         */
        private boolean regSourceValid(String tenantId, String source) {
            Optional<String> regSource = Optional.ofNullable(LocalCacheConfigUtils.getRegisterSource(tenantId));
            return regSource.map(value -> Arrays.asList(value.split(COMMA)).contains(source.toUpperCase())).orElse(false);
        }
    }

    /**
     * 判断是否存在会员
     */
    public static class MemberIsExist extends AccountBaseValidator<MemberExistValid> {
        @Override
        public void initialize(MemberExistValid constraintAnnotation) {
            predicate = account -> {
                if (Optional.ofNullable(account).map(Account::getIdentityId).map(IdentityId::getAccountId).isPresent()) {
                    return Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(account.getTenantId(), account.getAccountId(), AccountStatus.ACTIVE)).isPresent();
                }
                if (Optional.ofNullable(account).map(Account::getOpenUid).isPresent()) {
                    return Optional.ofNullable(openUidMappingDao.findByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(account.getTenantId(), account.getOpenUid())).isPresent();
                }
                return true;
            };
        }
    }
}