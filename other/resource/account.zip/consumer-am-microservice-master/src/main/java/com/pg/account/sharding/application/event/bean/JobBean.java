package com.pg.account.sharding.application.event.bean;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 工作信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobBean implements Serializable {
    private static final long serialVersionUID = -6263802410952820001L;
    @JSONField(name = "relationship_name")
    private String relationshipName;
    @JSONField(name = "relationship_sequence")
    private String relationshipSequence;
    private String province;
    private String city;
    private String district;
    @JSONField(name = "unit_address")
    private String unitAddress;
    @JSONField(name = "unit_name")
    private String unitName;
    @JSONField(name = "unit_category")
    private String unitCategory;
    private String profession;
    @JSONField(name = "create_time")
    private Timestamp createTime;
    @JSONField(name = "modify_time")
    private Timestamp modifyTime;
}
