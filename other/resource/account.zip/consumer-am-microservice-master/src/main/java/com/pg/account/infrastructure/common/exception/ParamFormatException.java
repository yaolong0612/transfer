package com.pg.account.infrastructure.common.exception;

/**
 * @author JackSun
 */
public class ParamFormatException extends ResultException {

    private static final long serialVersionUID = 6578254161893720880L;


    /**
     * 参数格式化异常
     *
     * @param code    code
     * @param v2Code  v2Code
     * @param message message
     */
    public ParamFormatException(Integer code, Integer v2Code, String message) {
        super(code, v2Code, message);
    }
}
