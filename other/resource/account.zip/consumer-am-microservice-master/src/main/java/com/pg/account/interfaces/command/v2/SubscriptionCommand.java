package com.pg.account.interfaces.command.v2;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.I_O_PATTERN;

/**
 * 订阅信息类
 *
 * @author Jack Sun
 * @date 2019-11-25 21:55
 */
@ApiModel(value = "SubscriptionCommand_V2", description = "V2 interface SubscriptionCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionCommand implements Serializable {

    private static final long serialVersionUID = 7519054324544385627L;
    @ApiModelProperty(value = "Subscription id", name = "optId", example = "103", required = true)
    @NotNull(message = "missing subscription id")
    private String optId;
    @ApiModelProperty(value = "Subscription status I or O (I, subscription, O, unsubscribe)", name = "optStatus", example = "I", required = true)
    @NotNull(message = "missing subscription status")
    @Pattern(regexp = I_O_PATTERN, message = "subscription status does not exist")
    private String optStatus;

}
