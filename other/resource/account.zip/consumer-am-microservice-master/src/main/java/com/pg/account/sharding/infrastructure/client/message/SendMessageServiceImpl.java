package com.pg.account.sharding.infrastructure.client.message;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.ExternalSystemException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.service.SendMessageService;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.pg.account.infrastructure.common.constants.AccountConstants.MEMBER_ID;

/**
 * @author Jack
 * @date 2021-04-21 21:07
 */
@Slf4j
@Component
public class SendMessageServiceImpl implements SendMessageService {

    /**
     * Result true
     */
    public static final String RESULT_TRUE = "0";
    public static final String RESULT_CODE = "resultCode";
    public static final String ERROR_MSG = "errorMsg";
    public static final String URL = "url";
    public static final String API_SECRET = "apiSecret";
    public static final String API_KEY = "apiKey";
    public static final String TEMPLATE_CODE = "template_Register_Code";
    public static final String FULL_NAME = "fullname";
    public static final String MEMBER = "会员";
    private final MessageServiceClient messageServiceClient;

    @Autowired
    public SendMessageServiceImpl(MessageServiceClient messageServiceClient) {
        this.messageServiceClient = messageServiceClient;
    }

    /**
     * 发送入会短信
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     * @param mobile    mobile
     * @param fullName  fullName
     */
    @Override
    public void sendMembershipSms(String tenantId, String channelId, String accountId, String mobile, String fullName) {
        Validate.notNull(tenantId, "sendMembershipSms tenantId is null");
        Validate.notNull(channelId, "sendMembershipSms channelId is null");
        Validate.notNull(accountId, "sendMembershipSms address is null");
        Validate.notNull(mobile, "sendMembershipSms is null");
        String smsTemplateRegisterCode = LocalCacheConfigUtils.getSmsTemplateRegisterCode(tenantId, channelId);
        if (StringUtils.isNotBlank(smsTemplateRegisterCode)) {
            String brand = LocalCacheConfigUtils.getTenant(tenantId);
            Validate.notNull(brand);
            String apiKey = getSmsApiKey(smsTemplateRegisterCode);
            Validate.notNull(apiKey);
            String apiSecret = getSmsApiSecret(smsTemplateRegisterCode);
            Validate.notNull(apiSecret);
            String templateCode = getTemplateCode(smsTemplateRegisterCode);
            Validate.notNull(templateCode);
            List<ParamEntity> paramEntityList = new ArrayList<>();
            paramEntityList.add(new ParamEntity(MEMBER_ID, accountId));
            paramEntityList.add(new ParamEntity(FULL_NAME, StringUtils.isNotBlank(fullName) ? fullName : MEMBER));
            SendMessageRequest request = new SendMessageRequest();
            request.setParamEntityList(paramEntityList);
            request.setApiKey(apiKey);
            request.setBrand(brand);
            request.setMobile(mobile);
            request.setTemplateCode(templateCode);
            request.setTimeStamp(String.valueOf(System.currentTimeMillis() / 1000));
            Map<String, Object> sendMessageRequestMap = JSON.parseObject(JSON.toJSONString(request));
            request.setSignature(SignatureGenerator.generateApiSecret(sendMessageRequestMap, apiSecret));
            ResponseEntity<JSONObject> responseEntity;
            try {
                responseEntity = this.messageServiceClient.sendMessage(request);
                log.info("MessageService sendMembershipSms request:{},responseEntity:{}", request, responseEntity);
            } catch (Exception e) {
                log.warn("SendMessageServiceImpl-sendMembershipSms.Request tenantId:{}, channelId:{}, accountId:{}, mobile:{},fullName:{}. Exception:", tenantId, channelId, DesensitizedUtils.identification(accountId), DesensitizedUtils.identification(mobile), fullName, e);
                throw new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage());
            }
            Validate.notNull(responseEntity.getBody());
            Optional.of(responseEntity).ifPresent(res -> exceptionHandler(responseEntity.getStatusCode(), res.getBody()));
        } else {
            log.info("tenant sendMembershipSms not config");
        }
    }

    /**
     * 登录短信校验
     *
     * @param tenantId     tenantId
     * @param mobile       mobile
     * @param templateCode templateCode
     * @param code         code
     * @return 短信发送状态，成功true，失败false
     */
    @Override
    public boolean logonSmsVerifyCode(String tenantId, String mobile, String templateCode, String code) {
        if (StringUtils.isNotBlank(tenantId) && StringUtils.isNotBlank(mobile) && StringUtils.isNotBlank(templateCode) && StringUtils.isNotBlank(code)) {
            String brand = LocalCacheConfigUtils.getTenant(tenantId);
            Validate.notNull(brand);
            String smsResult = LocalCacheConfigUtils.getSmsVerificationUrl(tenantId);
            Validate.notNull(smsResult);
            String apiKey = getSmsApiKey(smsResult);
            Validate.notNull(apiKey);
            String apiSecret = getSmsApiSecret(smsResult);
            Validate.notNull(apiSecret);
            VerifyCodeRequest request = new VerifyCodeRequest();
            request.setApiKey(apiKey);
            request.setBrand(brand);
            request.setMobile(mobile);
            request.setCode(code);
            request.setTemplateCode(templateCode);
            request.setTimeStamp(String.valueOf(System.currentTimeMillis() / 1000));
            Map<String, Object> sendMessageRequestMap = JSON.parseObject(JSON.toJSONString(request));
            request.setSignature(SignatureGenerator.generateApiSecret(sendMessageRequestMap, apiSecret));
            ResponseEntity<JSONObject> responseEntity;
            try {
                responseEntity = this.messageServiceClient.verifyCode(request);
                log.info("MessageService sendMembershipSms request:{},responseEntity:{}", request, responseEntity);
            } catch (Exception e) {
                log.warn("SendMessageServiceImpl-sendMembershipSms.Request tenantId:{}, mobile:{},templateCode:{},code:{}. Exception:", tenantId, DesensitizedUtils.identification(mobile), templateCode, code, e);
                throw new ExternalSystemException(ResultEnum.SMS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.SMS_MICRO_SERVICE_ERROR.getMessage());
            }
            Validate.notNull(responseEntity.getBody());
            JSONObject jsonObject = responseEntity.getBody();
            Optional.of(responseEntity).ifPresent(res -> exceptionHandler(responseEntity.getStatusCode(), res.getBody()));
            if (Optional.ofNullable(jsonObject).isPresent() && jsonObject.containsKey(RESULT_CODE)) {
                return RESULT_TRUE.equals(jsonObject.get(RESULT_CODE));
            }
        }
        return false;
    }


    /**
     * 异常处理
     *
     * @param httpStatus httpStatus
     * @param jsonObject jsonObject
     */
    private void exceptionHandler(HttpStatus httpStatus, JSONObject jsonObject) {
        Integer code = Integer.parseInt(jsonObject.getString(RESULT_CODE));
        String message = jsonObject.getString(ERROR_MSG);
        if (httpStatus.is5xxServerError()) {
            throw new ExternalSystemException(code, code, message);
        } else if (httpStatus.is4xxClientError()) {
            throw new BusinessException(code, code, message);
        }
    }

    /**
     * 获取SMS templateCode
     *
     * @param json result
     * @return templateCode
     */
    private String getTemplateCode(String json) {
        String templateCode = null;
        if (StringUtils.isNotBlank(json)) {
            JSONObject jsonObject = JSON.parseObject(json);
            if (jsonObject.containsKey(TEMPLATE_CODE)) {
                templateCode = jsonObject.getString(TEMPLATE_CODE);
            }
        }
        return templateCode;
    }


    /**
     * 获取SMS ApiKey
     *
     * @param json json
     * @return ApiKey
     */
    private String getSmsApiKey(String json) {
        String apiKey = null;
        if (StringUtils.isNotBlank(json)) {
            JSONObject jsonObject = JSON.parseObject(json);
            if (jsonObject.containsKey(API_KEY)) {
                apiKey = jsonObject.getString(API_KEY);
            }
        }
        return apiKey;
    }

    /**
     * 获取SMS ApiSecret
     *
     * @param json json
     * @return ApiSecret
     */
    private String getSmsApiSecret(String json) {
        String apiSecret = null;
        if (StringUtils.isNotBlank(json)) {
            JSONObject jsonObject = JSON.parseObject(json);
            if (jsonObject.containsKey(API_SECRET)) {
                apiSecret = jsonObject.getString(API_SECRET);
            }
        }
        return apiSecret;
    }
}
