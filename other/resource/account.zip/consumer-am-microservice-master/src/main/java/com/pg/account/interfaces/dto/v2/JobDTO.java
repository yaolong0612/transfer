package com.pg.account.interfaces.dto.v2;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.UserAdditionalInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Optional;

/**
 * 工作信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel(value = "JobDTO_V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobDTO implements Serializable {
    private static final long serialVersionUID = -6263802410952820001L;
    @ApiModelProperty(value = "relationshipId 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationshipId", example = "101")
    private String relationshipId;
    @ApiModelProperty(value = "relationshipName 101: 自己,102: 爷爷, 103: 奶奶, 104: 外公, 105: 外婆, " +
            "106: 爸爸, 107: 妈妈, 108: 儿子, 109: 女儿, 110: 孙子, 111: 孙女, 112: 外孙, 113: 外孙女, 114: 哥哥, 114: 姐姐", name = "relationshipName", example = "自己")
    private String relationshipName;
    @ApiModelProperty(value = "relationshipSequence Sequence limit, the default is 1. Others such as relationshipId: (108: son, 109: daughter, 110: grandson, 111: granddaughter,etc) limit to 2 births, you can fill in 2, up to 5", name = "relationshipSequence", example = "2")
    private String relationshipSequence;
    @ApiModelProperty(value = "province", name = "province", example = "江苏省")
    private String province;
    @ApiModelProperty(value = "city", name = "city", example = "无锡市")
    private String city;
    @ApiModelProperty(value = "district", name = "district", example = "滨湖区")
    private String district;
    @ApiModelProperty(value = "unitAddress", name = "unitAddress", example = "太湖大道2008号科技园3号")
    private String unitAddress;
    @ApiModelProperty(value = "unitName", name = "unitName", example = "XX有限公司")
    private String unitName;
    @ApiModelProperty(value = "unitCategory", name = "unitCategory", example = "教师")
    private String unitCategory;
    @ApiModelProperty(value = "profession", name = "profession", example = "工程师")
    private String profession;


    public void builder(Account account) {
        Optional.ofNullable(account).map(Account::getUserAdditionalInfo).map(UserAdditionalInfo::getJobList).ifPresent(h -> {
            h.forEach(item -> {
//                空指针异常判断
                this.relationshipId = item.getRelation().getRelationType().getRelationCode().toString();
                this.relationshipName = item.getRelation().getRelationType().getRelationName();
                this.relationshipSequence = item.getRelation().getSequence();
                this.province = item.getAddress().getProvince();
                this.city = item.getAddress().getCity();
                this.district = item.getAddress().getDistrict();
                this.unitAddress = item.getAddress().getAddressInfo();
                this.unitName = item.getName();
                this.unitCategory = item.getCategory();
                this.profession = item.getProfession();
            });

        });
    }
}
