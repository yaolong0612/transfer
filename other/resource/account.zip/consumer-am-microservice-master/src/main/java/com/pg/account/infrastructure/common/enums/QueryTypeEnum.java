package com.pg.account.infrastructure.common.enums;

import com.pg.account.infrastructure.common.exception.BusinessException;
import lombok.Getter;

import java.util.Arrays;

import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.QUERY_TYPE_NOT_EXIST;

/**
 * 查询类型枚举
 *
 * @author Jack Sun
 * @date 2019-11-27 16:29
 */
@Getter
public enum QueryTypeEnum {

    /**
     * 查询类型枚举
     */
    BIND_ID(1, "bindId"),
    UNION_ID(2, "unionId"),
    OPEN_ID(3, "openId"),
    MOBILE(4, "mobile"),
    BIND_ID_AND_UNION_ID(5, "bindIdAndUnionId"),
    EMAIL(6, "email"),
    MEMBER_ID(7, "memberId");

    private final Integer key;
    private final String value;

    /**
     * 构造器
     *
     * @param key   num
     * @param value name
     */
    QueryTypeEnum(Integer key, String value) {
        this.key = key;
        this.value = value;
    }

    public static QueryTypeEnum getByKeyOrValue(String value) {
        return Arrays.stream(QueryTypeEnum.values())
                .filter(msg -> msg.getValue().equalsIgnoreCase(value) || String.valueOf(msg.getKey()).equalsIgnoreCase(value))
                .findAny()
                .orElseThrow(() -> new BusinessException(QUERY_TYPE_NOT_EXIST.getCode(), QUERY_TYPE_NOT_EXIST.getV2Code(), QUERY_TYPE_NOT_EXIST.getMessage()));
    }
}
