package com.pg.account.sharding.application.cmdservice;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.sharding.interfaces.command.SignUpCommand;
import org.springframework.stereotype.Component;

/**
 * @author lfx
 * @date 2022/1/13 17:14
 */
@Component
public interface SolveConflictService {

    /**
     * 解决冲突
     *
     * @param signUpCommand signUpCommand
     * @return JSONObject
     */
    JSONObject solveConflict(SignUpCommand signUpCommand);

}
