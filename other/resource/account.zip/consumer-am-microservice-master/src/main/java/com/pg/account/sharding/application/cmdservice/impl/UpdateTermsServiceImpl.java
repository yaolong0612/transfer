package com.pg.account.sharding.application.cmdservice.impl;

import com.pg.account.infrastructure.common.context.SpringContextUtil;
import com.pg.account.infrastructure.common.enums.ConfigStatusEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.application.cmdservice.UpdateTermsService;
import com.pg.account.sharding.application.event.UpdateSubscriptionEvent;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import com.pg.account.sharding.domain.model.subscription.repository.SubscriptionRepository;
import com.pg.account.sharding.domain.service.FetchAccountService;
import com.pg.account.sharding.infrastructure.jpa.config.ShardTermsVersion;
import com.pg.account.sharding.infrastructure.jpa.config.TermsVersionDao;

import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import com.pg.account.sharding.interfaces.command.TermsCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationAdapter;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.pg.account.sharding.domain.service.StringValidator.channelValid;

/**
 * @author lfx
 * @date 2022/2/21 10:56
 */
@Service
public class UpdateTermsServiceImpl implements UpdateTermsService {

    private final SubscriptionRepository subscriptionRepository;
    private final TermsVersionDao termsVersionDao;
    private final FetchAccountService fetchAccountService;

    @Autowired
    public UpdateTermsServiceImpl(SubscriptionRepository subscriptionRepository, TermsVersionDao termsVersionDao, FetchAccountService fetchAccountService) {
        this.subscriptionRepository = subscriptionRepository;
        this.termsVersionDao = termsVersionDao;
        this.fetchAccountService = fetchAccountService;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateTerms(TermsCommand command) {
        channelValid(command.getTenant(), command.getChannel());
        Account account = fetchAccountService.fetchActiveAccount(command.getTenant(), command.getAccountId());
        ShardTermsVersion termsVersion = Optional.ofNullable(termsVersionDao.findByTenantIdAndStatus(account.getTenantId(), ConfigStatusEnum.ACTIVE.getCode())).orElseThrow(() -> new BusinessException(V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getCode(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getMessage(), V3ResultEnum.SYSTEM_CONFIG_NOT_EXIST.getFrontMessage()));
        ShardSubscription subscription = subscriptionRepository.findByIdentityId_TenantIdAndIdentityId_AccountId(command.getTenant(), command.getAccountId());
        List<SubscriptionItem> list = new ArrayList<>();
        Optional.ofNullable(subscription).ifPresent(s -> s.getSubscriptionList().forEach(item -> {
            Optional.ofNullable(item.getTermsList()).ifPresent(termList -> termList.forEach(term -> term.setTermVersion(termsVersion.getTermsVersionLabel())));
            list.add(item);
            s.setSubscriptionList(list);
            s.addUpdatedTime();
            subscriptionRepository.save(subscription);
        }));
        RedisConfigUtils.clearProfileCache(command.getTenant(), command.getAccountId());
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter() {
            @Override
            public void afterCommit() {
                UpdateSubscriptionEvent updateSubscriptionEvent = new UpdateSubscriptionEvent(this, subscription);
                SpringContextUtil.getApplicationContext().publishEvent(updateSubscriptionEvent);
            }
        });
    }
}
