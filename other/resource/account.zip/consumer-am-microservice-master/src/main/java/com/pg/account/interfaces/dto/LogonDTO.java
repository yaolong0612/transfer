package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/2/13
 */
@ApiModel(value = "LogonDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LogonDTO implements Serializable {
    private static final long serialVersionUID = -153427863669666912L;
    @ApiModelProperty(value = "会员ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
}
