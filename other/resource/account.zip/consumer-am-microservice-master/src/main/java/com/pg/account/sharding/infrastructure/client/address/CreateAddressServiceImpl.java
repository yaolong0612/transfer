package com.pg.account.sharding.infrastructure.client.address;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.ExternalSystemException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.domain.service.CreateAddressService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.Integer.parseInt;

/**
 * @author Jack
 * @date 2021-04-20 14:22
 */
@Slf4j
@Component
public class CreateAddressServiceImpl implements CreateAddressService {

    /**
     * 主地址
     */
    public static final String IS_PRIMARY = "1";
    /**
     * 家庭地址
     */
    public static final String ADDRESS_TYPE = "1";
    public static final String RESULT_CODE = "resultCode";
    public static final String ERROR_MSG = "errorMsg";
    public static final String OBJECT = "object";
    private final AddressServiceClient addressServiceClient;

    @Autowired
    public CreateAddressServiceImpl(AddressServiceClient addressServiceClient) {
        this.addressServiceClient = addressServiceClient;
    }

    /**
     * 存储地址
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param address   address
     */
    @Override
    public void store(String tenantId, String accountId, Address address) {
        Validate.notNull(tenantId, "store address tenantId is null");
        Validate.notNull(accountId, "store address accountId is null");
        Validate.notNull(address, "store address address is null");
        StoreAddressRequest storeAddressRequest = buildRequest(tenantId, accountId, address);
        if (Optional.ofNullable(storeAddressRequest).isPresent()) {
            ResponseEntity<JSONObject> responseEntity;
            JSONObject jsonObject;
            try {
                responseEntity = this.addressServiceClient.store(storeAddressRequest);
            } catch (Exception e) {
                log.warn("CreateAddressServiceImpl-store.Request tenantId:{},accountId:{}. Exception:", tenantId, DesensitizedUtils.identification(accountId), e);
                throw new ExternalSystemException(ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getMessage());
            }
            Validate.notNull(responseEntity.getBody(), "存储地址返回空值");
            jsonObject = responseEntity.getBody();
            Optional.ofNullable(jsonObject).ifPresent(o -> exceptionHandler(responseEntity.getStatusCode(), o));
        }
    }

    /**
     * 存储地址
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param address   address
     */
    @Override
    public void save(String tenantId, String accountId, Address address) {
        Validate.notNull(tenantId, "store address tenantId is null");
        Validate.notNull(accountId, "store address accountId is null");
        Validate.notNull(address, "store address address is null");
        StoreAddressRequest storeAddressRequest = buildRequest(tenantId, accountId, address);
        if (Optional.ofNullable(storeAddressRequest).isPresent()) {
            ResponseEntity<JSONObject> responseEntity;
            JSONObject jsonObject;
            try {
                responseEntity = this.addressServiceClient.store(storeAddressRequest);
            } catch (Exception e) {
                log.warn("CreateAddressServiceImpl-store.Request tenantId:{},accountId:{}. Exception:", tenantId, DesensitizedUtils.identification(accountId), e);
                throw new BusinessException(V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getCode(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getMessage(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getFrontMessage());
            }
            Validate.notNull(responseEntity.getBody(), "存储地址返回空值");
            jsonObject = responseEntity.getBody();
            Optional.ofNullable(jsonObject).ifPresent(o -> {
                if (Optional.ofNullable(o.getString(ERROR_MSG)).isPresent()) {
                    throw new BusinessException(V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getCode(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getMessage(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getFrontMessage());
                }
            });
        }
    }


    /**
     * 异常处理
     *
     * @param httpStatus httpStatus
     * @param jsonObject jsonObject
     */
    private void exceptionHandler(HttpStatus httpStatus, JSONObject jsonObject) {
        Integer code = parseInt(jsonObject.getString(RESULT_CODE));
        String message = jsonObject.getString(ERROR_MSG);
        if (httpStatus.is5xxServerError()) {
            throw new ExternalSystemException(code, code, message);
        } else if (httpStatus.is4xxClientError()) {
            throw new BusinessException(code, code, message);
        }
    }


    /**
     * 地址请求构建
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @param address   address
     * @return StoreAddressesRequest
     */
    private StoreAddressRequest buildRequest(String tenantId, String accountId, Address address) {
        StoreAddressRequest storeAddressRequest = null;
        if (Optional.ofNullable(address).isPresent()) {
            List<Address> addressList = new ArrayList<>();
            Address addressBean = new Address(address.getAddressCode(), IS_PRIMARY, ADDRESS_TYPE, address.getFullName(),
                    address.getCellphone(), address.getPhone(), address.getProvince(), address.getCity(),
                    address.getDistrict(), address.getAddress(), address.getPostcode());
            addressList.add(addressBean);
            storeAddressRequest = new StoreAddressRequest(Long.parseLong(tenantId), accountId, addressList);
        }
        return storeAddressRequest;
    }
}
