package com.pg.account.sharding.domain.service;


import com.pg.account.sharding.domain.model.account.Account;

/**
 * @author Jack
 * @date 2021-04-21 20:20
 */
public interface MessageService {

    /**
     * 发送入会短信
     *
     * @param account account
     */
    void sendMembershipSms(Account account);

    /**
     * 登录短信校验
     *
     * @param account      account
     * @param templateCode templateCode
     * @param code         code
     * @return 短信发送状态，成功true，失败false
     */
    boolean logonSmsVerifyCode(Account account, String templateCode, String code);
}
