package com.pg.account.infrastructure.common.constants;

/**
 * FeignConstants
 *
 * @author Jack Sun
 * @date 2019-6-20 17:23
 */
public class FeignConstants {

    /**
     * Result true
     */
    public static final String RESULT_TRUE = "0";
    /**
     * Result Code
     */
    public static final String RESULT_CODE = "resultCode";
    /**
     * Result Message
     */
    public static final String RESULT_MESSAGE = "errorMsg";
    /**
     * Result Object
     */
    public static final String RESULT_OBJECT = "object";

    private FeignConstants() {
        //私有构造方法
    }

}
