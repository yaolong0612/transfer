package com.pg.account.infrastructure.common.enums;


/**
 * @author JackSun
 */

public enum AttentionStatusEnum {
    /**
     * 关注状态
     */
    SUBSCRIBE("I"),
    UNSUBSCRIBE("O");

    String value;

    AttentionStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
