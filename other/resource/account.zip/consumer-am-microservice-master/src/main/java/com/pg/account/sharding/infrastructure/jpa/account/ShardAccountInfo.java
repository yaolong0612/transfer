package com.pg.account.sharding.infrastructure.jpa.account;

import com.pg.account.sharding.domain.model.account.*;
import com.pg.account.sharding.infrastructure.jpa.shared.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Optional;

/**
 * @author Jack
 * @date 2021/5/31 11:04
 */
@EqualsAndHashCode(callSuper = true)
@javax.persistence.Entity
@Table(name = "SHARD_ACCOUNT_INFO")
@Data
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@DynamicInsert
public class ShardAccountInfo extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 7554987343703112793L;
    @Convert(converter = JpaConverterAccountStatusEnum.class)
    protected AccountStatus accountStatus;
    private Long id;
    @EmbeddedId
    private IdentityId identityId;
    private String openUid;
    @Convert(converter = JpaConverterSecurityJson.class)
    @Column(columnDefinition = "NVARCHAR(1000)")
    private Security security;
    @Convert(converter = JpaConverterRegistrationJson.class)
    @Column(columnDefinition = "NVARCHAR(500)")
    private Registration registration;
    @Convert(converter = JpaConverterUserBasicInfoJson.class)
    @Column(columnDefinition = "NVARCHAR(1000)")
    private UserBasicInfo userBasicInfo;

    /**
     * 检查会员状态是否有效
     */
    public boolean checkAccountStatusIsActive() {
        return AccountStatus.ACTIVE.getValue().equals(this.accountStatus.getValue());
    }

    public void active() {
        this.accountStatus = AccountStatus.ACTIVE;
    }

    /**
     * 获取手机号
     *
     * @return 手机号
     */
    public String getMobile() {
        return Optional.ofNullable(this.userBasicInfo).map(UserBasicInfo::getContact).map(Contact::getMobile).orElse(null);
    }

    public void modifyMobile(String mobile){
        if(!Optional.ofNullable(this.userBasicInfo).isPresent()){
            this.userBasicInfo = new UserBasicInfo();
        }
        if(!Optional.ofNullable(this.userBasicInfo.getContact()).isPresent()){
            this.userBasicInfo.setContact(new Contact());
        }
        this.userBasicInfo.getContact().setMobile(mobile);
    }

    public void build(Account account) {
        this.identityId = account.getIdentityId();
        this.openUid = account.getOpenUid();
        this.security = account.getSecurity();
        this.registration = account.getRegistration();
        this.userBasicInfo = account.getUserBasicInfo();
        this.accountStatus = account.getAccountStatus();
        if (Optional.ofNullable(this.createdTime).isPresent()) {
            super.addUpdatedTime();
        } else {
            super.addCreateTime();
        }
    }

    public Account builder() {
        return Account.AccountBuilder
                .anAccount()
                .identityId(this.identityId)
                .accountStatus(this.accountStatus)
                .openUid(this.openUid)
                .registration(this.registration)
                .security(this.security)
                .userBasicInfo(this.userBasicInfo)
                .build();
    }

    public void buildFromDb(ShardAccountInfo db) {
        Optional.ofNullable(db).ifPresent(info -> {
            this.identityId = Optional.ofNullable(this.identityId).orElse(db.identityId);
            this.openUid = Optional.ofNullable(this.openUid).orElse(db.openUid);
            this.security = db.security;
            this.registration = db.getRegistration();
            if (Optional.ofNullable(this.userBasicInfo).isPresent()) {
                this.userBasicInfo.buildFromDb(db.getUserBasicInfo());
            } else {
                this.userBasicInfo = db.userBasicInfo;
            }
        });
    }
}
