package com.pg.account.interfaces.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 数据返回bean
 *
 * @param <T> 对象
 * @author sunliang
 * @date 2016/12/25
 */
@ApiModel(value = "Result_V1", description = "V1接口返回响应数据")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T extends java.io.Serializable> implements Serializable {
    private static final long serialVersionUID = 2095790749178219483L;
    private static final String DEFAULT_RESULT_CODE = "0";
    @ApiModelProperty(value = "返回状态码，0为正常，其他字符为异常", required = true)
    private String resultCode;
    @ApiModelProperty(value = "错误信息", required = true)
    private String errorMsg;
    @ApiModelProperty(value = "返回的信息", required = true)
    private T object;

    /**
     * 返回成功
     *
     * @param resultCode 返回码
     * @param object     对象
     */
    public Result(String resultCode, T object) {
        if (resultCode == null) {
            this.resultCode = DEFAULT_RESULT_CODE;
        } else {
            this.resultCode = resultCode;
        }
        this.object = object;
    }


    /**
     * 返回失败
     *
     * @param resultCode 返回码
     * @param errorMsg   错误信息
     */
    public Result(String resultCode, String errorMsg) {
        if (resultCode == null) {
            this.resultCode = DEFAULT_RESULT_CODE;
        } else {
            this.resultCode = resultCode;
        }
        this.errorMsg = errorMsg;
    }

    public static String getDefaultResultCode() {
        return DEFAULT_RESULT_CODE;
    }

}
