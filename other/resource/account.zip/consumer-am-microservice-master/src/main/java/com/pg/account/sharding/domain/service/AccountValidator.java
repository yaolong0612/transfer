package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.infrastructure.jpa.mapping.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

/**
 * 账号校验
 *
 * @author xusheng
 * @date 2021/6/17 <br>
 */
@Component("ShardAccountValidator")
public class AccountValidator {

    private final FetchMappingService fetchMappingService;
    private final FetchAccountService fetchAccountService;

    @Autowired
    public AccountValidator(FetchMappingService fetchMappingService, FetchAccountService fetchAccountService) {
        this.fetchMappingService = fetchMappingService;
        this.fetchAccountService = fetchAccountService;
    }

    /**
     * 多账号校验
     *
     * @param account            account
     * @param shardSocialAccount shardSocialAccount
     * @return java.lang.String
     * @author xusheng
     * @date 2021/6/17 16:46
     */
    public String multipleAccountValidator(@Valid Account account, ShardSocialAccount shardSocialAccount) {
        Set<String> members = new HashSet<>();
        //根据手机号查询，返回memberId存入set集合中
        Optional.ofNullable(account.getMobile())
                .ifPresent(m -> {
                    MobileMapping mobileMapping = fetchMappingService.fetchMobileByTenantIdAndMobile(account.getTenantId(), m);
                    Optional.ofNullable(mobileMapping).ifPresent(mobileMapping1 -> members.add(mobileMapping1.getAccountId()));
                });
        Optional.ofNullable(account.getEmail())
                .ifPresent(e -> {
                    EmailMapping emailMapping = fetchMappingService.fetchEmailByTenantIdAndEmail(account.getTenantId(), e);
                    Optional.ofNullable(emailMapping).ifPresent(emailMapping1 -> members.add(emailMapping1.getAccountId()));
                });
        Optional.ofNullable(shardSocialAccount.getSocialAccountList())
                .ifPresent(socialAccountItemList ->
                        socialAccountItemList.forEach(socialAccountItem -> {
                            if (StringUtils.isNotBlank(socialAccountItem.getBindId())) {
                                BindIdMapping bindIdMapping = fetchMappingService.fetchByTenantIdAndBindIdAndChannelId(account.getTenantId(), socialAccountItem.getBindId(), socialAccountItem.getChannel().getChannelId());
                                Optional.ofNullable(bindIdMapping).ifPresent(bindIdMapping1 -> members.add(bindIdMapping1.getAccountId()));
                            }
                            // 如果unionId和unionType都存在则查询unionIdMapping
                            if (StringUtils.isNotBlank(socialAccountItem.getUnionId()) && StringUtils.isNotBlank(socialAccountItem.getUnionType())) {
                                UnionIdMapping unionIdMapping = fetchMappingService.fetchByTenantIdAndUnionIdAndChannel(account.getTenantId(), socialAccountItem.getUnionId(), socialAccountItem.getChannel().getUnionType());
                                Optional.ofNullable(unionIdMapping).ifPresent(unionIdMapping1 -> members.add(unionIdMapping1.getAccountId()));
                            }
                        }));
        //如果set集合大于1，说明存在多个注册参数存在多个account的关联关系
        if (members.size() > 1) {
            throw new BusinessException(ResultEnum.MULTIPLE_USERS_EXIST.getCode(), ResultEnum.MULTIPLE_USERS_EXIST.getV2Code(), ResultEnum.MULTIPLE_USERS_EXIST.getMessage());
        }
        String memberId = members.stream().findFirst().orElse(null);
//        校验获取到的会员与传入的信息是否相同
        if (StringUtils.isNotBlank(memberId)) {
            userBasicInfoValidator(account, memberId);
        }
        return memberId;
    }

    /**
     * 反向校验查出的会员账号信息与入参信息是否一致
     *
     * @param account  account
     * @param memberId memberId
     * @author xusheng
     * @date 2021/6/21 9:56
     */
    private void userBasicInfoValidator(Account account, String memberId) {
        Account dbAccount = fetchAccountService.fetchAccountByTenantIdAndAccountId(account.getTenantId(), memberId);
        Optional.ofNullable(dbAccount).ifPresent(dbAccount1 -> {
            Optional.ofNullable(account.getMobile())
                    .ifPresent(m -> {
                        if (Optional.ofNullable(dbAccount1.getMobile()).isPresent() && !m.equals(dbAccount1.getMobile())) {
                            throw new BusinessException(ResultEnum.ACCOUNT_DATA_CONFLICT.getCode(), ResultEnum.ACCOUNT_DATA_CONFLICT.getV2Code(), ResultEnum.ACCOUNT_DATA_CONFLICT.getMessage());
                        }
                    });
            Optional.ofNullable(account.getEmail())
                    .ifPresent(e -> {
                        if (Optional.ofNullable(dbAccount1.getEmail()).isPresent() && !e.equals(dbAccount1.getEmail())) {
                            throw new BusinessException(ResultEnum.ACCOUNT_DATA_CONFLICT.getCode(), ResultEnum.ACCOUNT_DATA_CONFLICT.getV2Code(), ResultEnum.ACCOUNT_DATA_CONFLICT.getMessage());
                        }
                    });
        });
    }
}
