package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class UnSubscribeEvent extends ApplicationEvent {
    private static final long serialVersionUID = 9052306884969779285L;

    private ShardSocialAccount shardSocialAccount;

    public UnSubscribeEvent(Object source) {
        super(source);
    }

    public UnSubscribeEvent(Object source, ShardSocialAccount shardSocialAccount) {
        super(source);
        this.shardSocialAccount = shardSocialAccount;
    }
}
