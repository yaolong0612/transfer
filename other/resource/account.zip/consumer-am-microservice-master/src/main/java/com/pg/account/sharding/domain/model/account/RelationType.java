package com.pg.account.sharding.domain.model.account;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

/**
 * 关系映射枚举
 *
 * @author Jack
 * @date 2021/5/28 10:26
 */
@Getter
public enum RelationType {
    /**
     * 人际关系映射
     */
    SELF(101, "自己", 1),
    GRAND_PA(102, "爷爷", 1),
    GRAND_MA(103, "奶奶", 1),
    GRAND_FATHER(104, "外公", 1),
    GRAND_MOTHER(105, "外婆", 1),
    FATHER(106, "爸爸", 1),
    MOTHER(107, "妈妈", 1),
    SON(108, "儿子", 5),
    DAUGHTER(109, "女儿", 5),
    GRAND_SON(110, "孙子", 5),
    GRAND_DAUGHTER(111, "孙女", 5),
    GRAND_SON_2(112, "外孙", 5),
    GRAND_DAUGHTER_2(113, "外孙女", 5),
    ELDER_BROTHER(114, "哥哥", 5),
    ELDER_SISTER(115, "姐姐", 5),
    YOUNGER_BROTHER(116, "弟弟", 5),
    YOUNGER_SISTER(117, "妹妹", 5),
    ;

    private final Integer relationCode;
    private final String relationName;
    private final Integer limit;

    RelationType(Integer relationCode, String relationName, Integer limit) {
        this.relationCode = relationCode;
        this.relationName = relationName;
        this.limit = limit;
    }

    public static RelationType getRelation(String value) {
        return Arrays.stream(RelationType.values())
                .filter(msg -> value.equals(msg.getRelationCode().toString()) || value.equals(msg.getRelationName()))
                .findAny()
                .orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
    }

    public static RelationType getRelation(String relationId, String relationName) {
        RelationType relationType;
        if (StringUtils.isNotBlank(relationId) && StringUtils.isNotBlank(relationName)) {
            relationType = Arrays.stream(RelationType.values())
                    .filter(msg -> relationId.equals(msg.getRelationCode().toString()) && relationName.equals(msg.getRelationName()))
                    .findAny()
                    .orElseThrow(() -> new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage()));
        } else if (StringUtils.isNotBlank(relationId)) {
            relationType = Arrays.stream(RelationType.values())
                    .filter(msg -> relationId.equals(msg.getRelationCode().toString()) )
                    .findAny()
                    .orElseThrow(() -> new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage()));
        } else if (StringUtils.isNotBlank(relationName)) {
            relationType = Arrays.stream(RelationType.values())
                    .filter(msg -> relationName.equals(msg.getRelationName()))
                    .findAny()
                    .orElseThrow(() -> new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage()));
        } else {
            throw new BusinessException(V3ResultEnum.PARAMETER_PARSING_ERROR.getCode(), V3ResultEnum.PARAMETER_PARSING_ERROR.getMessage(), V3ResultEnum.PARAMETER_PARSING_ERROR.getFrontMessage());
        }
        return relationType;
    }


}
