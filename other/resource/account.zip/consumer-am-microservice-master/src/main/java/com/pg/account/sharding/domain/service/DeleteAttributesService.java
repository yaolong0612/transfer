package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.ExtraAttributeItem;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ExtraAttributeDao;
import com.pg.account.sharding.infrastructure.jpa.profile.extraattribute.ShardExtraAttribute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.Optional;

/**
 * @author yj
 */
@Service
public class DeleteAttributesService {

    private final ExtraAttributeDao extraAttributeDao;

    @Autowired
    public DeleteAttributesService(ExtraAttributeDao extraAttributeDao) {
        this.extraAttributeDao = extraAttributeDao;
    }

    /**
     * 删除Attributes
     *
     * @param account account
     */
    public void deleteAttributes(Account account) {
        ShardExtraAttribute dbShardExtraAttribute = extraAttributeDao.findByIdentityId_TenantIdAndIdentityId_AccountId(account.getTenantId(), account.getAccountId());
        if (Optional.ofNullable(dbShardExtraAttribute).isPresent()) {
            Iterator<ExtraAttributeItem> iterator = dbShardExtraAttribute.getExtraAttributeItemList().iterator();
            while (iterator.hasNext()) {
                ExtraAttributeItem dbExtraAttributeItem = iterator.next();
                account.getUserAdditionalInfo().getExtraAttributeList().forEach(extraAttributeItem -> {
                    if (dbExtraAttributeItem.getAttrId().equals(extraAttributeItem.getAttrId())) {
                        iterator.remove();
                    }
                });
            }
            dbShardExtraAttribute.addUpdatedTime();
            extraAttributeDao.save(dbShardExtraAttribute);
        }
        // 待测试
//        Optional.ofNullable(dbShardExtraAttribute)
//                .map(ShardExtraAttribute::getExtraAttributeItemList)
//                .filter(attributes -> !attributes.isEmpty())
//                .ifPresent(dbAttrs -> dbAttrs
//                        .forEach(dbAttr -> account.getUserAdditionalInfo()
//                                .getExtraAttributeList()
//                                .forEach(cmdAttr -> {
//                                    dbAttrs.removeIf(db -> db.getAttrId().equals(cmdAttr.getAttrId()));
//                                    dbShardExtraAttribute.addUpdatedTime();
//                                    extraAttributeDao.save(dbShardExtraAttribute);
//                                })));
    }
}
