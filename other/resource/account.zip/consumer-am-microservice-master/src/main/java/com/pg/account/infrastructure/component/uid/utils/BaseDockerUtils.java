/*
 * Copyright (c) 2017 Baidu, Inc. All Rights Reserve.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.pg.account.infrastructure.component.uid.utils;

import com.pg.account.infrastructure.common.exception.ResultException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * BaseDockerUtils
 *
 * @author yutianbao
 */
@Slf4j
public abstract class BaseDockerUtils {
    /**
     * Environment param keys
     */
    private static final String ENV_KEY_HOST = "JPAAS_HOST";
    private static final String ENV_KEY_PORT = "JPAAS_HTTP_PORT";
    private static final String ENV_KEY_PORT_ORIGINAL = "JPAAS_HOST_PORT_8080";
    /**
     * Docker host & port
     */
    private static String dockerHost = "";
    private static String dockerPort = "";
    /**
     * Whether is docker
     */
    private static boolean isDocker;

    static {
        retrieveFromEnv();
    }

    private BaseDockerUtils() {
        //私有构造方法
    }

    /**
     * Retrieve docker host
     *
     * @return empty string if not a docker
     */
    public static String getDockerHost() {
        return dockerHost;
    }

    /**
     * Retrieve docker port
     *
     * @return empty string if not a docker
     */
    public static String getDockerPort() {
        return dockerPort;
    }

    /**
     * Whether a docker
     *
     * @return boolean
     */
    public static boolean isDocker() {
        return isDocker;
    }

    /**
     * Retrieve host & port from environment
     */
    private static void retrieveFromEnv() {
        // retrieve host & port from environment
        dockerHost = System.getenv(ENV_KEY_HOST);
        dockerPort = System.getenv(ENV_KEY_PORT);

        // not found from 'JPAAS_HTTP_PORT', then try to find from 'JPAAS_HOST_PORT_8080'
        if (StringUtils.isBlank(dockerPort)) {
            dockerPort = System.getenv(ENV_KEY_PORT_ORIGINAL);
        }

        boolean hasEnvHost = StringUtils.isNotBlank(dockerHost);
        boolean hasEnvPort = StringUtils.isNotBlank(dockerPort);

        // docker can find both host & port from environment
        if (hasEnvHost && hasEnvPort) {
            isDocker = true;

            // found nothing means not a docker, maybe an actual machine
        } else if (!hasEnvHost && !hasEnvPort) {
            isDocker = false;

        } else {
            log.info("Missing host or port from env for Docker. host:{}, port:{}", dockerHost, dockerPort);
            throw new ResultException(ResultEnum.ERROR.getCode(), ResultEnum.ERROR.getV2Code(), "Missing host or port from env for Docker. host:" + dockerHost + ", port:" + dockerPort);
        }
    }

}
