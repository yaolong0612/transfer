package com.pg.account.sharding.domain.model.subscription;

import com.pg.account.interfaces.dto.v2.SubscriptionDTO;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * 订阅值对象
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SubscriptionItem implements ValueObject<SubscriptionItem> {
    private static final long serialVersionUID = 605449336102190269L;
    private String optId;
    private String optName;
    private String optStatus;
    private String channelId;
    private List<Term> termsList;

    private LocalDateTime optTime;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    @Override
    public boolean sameValueAs(SubscriptionItem other) {
        return this.equals(other);
    }

    public SubscriptionDTO build() {
        SubscriptionDTO subscriptionDTO = new SubscriptionDTO();
        subscriptionDTO.setOptId(this.optId);
        subscriptionDTO.setOptName(this.optName);
        subscriptionDTO.setOptStatus(this.optStatus);
        return subscriptionDTO;
    }

    /**
     * 合并入参和数据库的sub
     *
     * @param db sub from db
     */
    public void builder(SubscriptionItem db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.optStatus = Optional.ofNullable(this.optStatus).orElse(db.getOptStatus());
            this.optTime = Optional.ofNullable(this.optTime).orElse(db.getOptTime());
            this.optName = Optional.ofNullable(this.optName).orElse(db.getOptName());
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(db.getUpdateTime());
            this.optId = Optional.ofNullable(this.optId).orElse(db.getOptId());
            this.termsList = Optional.ofNullable(this.termsList).orElse(db.getTermsList());
        }
    }

    /**
     * 添加创建时间
     *
     * @date 2021/6/8 13:27
     */
    public void addCreateTime() {
        this.optTime = LocalDateTime.now();
        this.createTime = LocalDateTime.now();
        this.updateTime = LocalDateTime.now();
    }

    /**
     * 更新修改时间
     *
     * @date 2021/6/8 13:28
     */
    public void changeUpdatedTime() {
        this.updateTime = LocalDateTime.now();
    }

    public void build(String optId, String optName, String optStatus, List<Term> termsList) {
        this.optId = optId;
        this.optName = optName;
        this.optStatus = optStatus;
        this.termsList = termsList;
        this.addCreateTime();
    }

    public void build(String optId, String optName, String channelId, String optStatus, List<Term> termsList) {
        this.optId = optId;
        this.optName = optName;
        this.channelId = channelId;
        this.optStatus = optStatus;
        this.termsList = termsList;
        this.addCreateTime();
    }
}
