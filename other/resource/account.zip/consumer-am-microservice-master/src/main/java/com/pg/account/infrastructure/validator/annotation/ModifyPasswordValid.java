package com.pg.account.infrastructure.validator.annotation;


import com.pg.account.infrastructure.validator.ModifyPasswordParamValid;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * 用于校验修改密码参数
 *
 * @author xusheng
 * @date 2021/5/06 9:26
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = ModifyPasswordParamValid.class)
public @interface ModifyPasswordValid {

    String message() default "";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
