package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BindSocialAccountBean implements Serializable {
    private static final long serialVersionUID = 4591659667679050421L;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String accountId;
    @JSONField(ordinal = 1)
    private Integer mpId;
    @JSONField(ordinal = 3)
    private Character updateFlag;
    @JSONField(ordinal = 4)
    private String mobile;
    @JSONField(ordinal = 5)
    private String deviceId;
    @JSONField(ordinal = 6)
    private String deviceType;
    @JSONField(ordinal = 7)
    private List<SocialAccountBean> socialAccountInfo;
    @JSONField(ordinal = 8)
    private Timestamp modifyTime;

    public void inserted() {
        this.updateFlag = 'I';
    }

    public void updated() {
        this.updateFlag = 'U';
    }

    public void deleted() {
        this.updateFlag = 'D';
    }

}
