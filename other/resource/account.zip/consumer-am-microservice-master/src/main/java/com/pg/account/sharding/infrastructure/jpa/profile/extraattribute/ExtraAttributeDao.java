package com.pg.account.sharding.infrastructure.jpa.profile.extraattribute;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author yj
 */
public interface ExtraAttributeDao extends JpaRepository<ShardExtraAttribute, Long> {

    /**
     * 根据tenantId和accountId查询属性信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return ExtraAttributeInfo
     */
    ShardExtraAttribute findByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);

    /**
     * 根据租户和会员删除
     *
     * @param tenantId   tenantId
     * @param accountId accountId
     */
    @Modifying
    @Transactional
    void deleteByIdentityId_TenantIdAndIdentityId_AccountId(String tenantId, String accountId);
}
