package com.pg.account.sharding.application.event.bean.servicebus;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author JackSun
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SocialAccountBean implements Serializable {

    private static final long serialVersionUID = 5046738198760941315L;
    @JSONField(ordinal = 1)
    private String channelId;
    @JSONField(ordinal = 2)
    private String channel;
    @JSONField(ordinal = 3)
    private String brand;
    @JSONField(ordinal = 4)
    private String source;
    @JSONField(ordinal = 5)
    private String customer;
    @JSONField(ordinal = 6)
    private String publicAccount;
    @JSONField(ordinal = 7)
    private String bindId;
    @JSONField(ordinal = 8)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    @JSONField(ordinal = 9)
    private String bindStatus;
    @JSONField(ordinal = 10)
    private Timestamp bindTime;
    @JSONField(ordinal = 11)
    private Timestamp createTime;
    @JSONField(ordinal = 12)
    private Timestamp modifyTime;


}
