package com.pg.account.interfaces.command.oralbCommand;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author YJ
 * @date 2021/9/4
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OralbAttrCommand implements Serializable {
    private static final long serialVersionUID = -447131744076331781L;
    @ApiModelProperty(value = "属性主键ID")
    private Long id;
    @ApiModelProperty(value = "用户属性编号", required = true)
    private String attrId;
    @ApiModelProperty(value = "用户属性内容", required = true)
    private String attrVal;

    public OralbAttrCommand(String attrId, String attrVal) {
        this.attrId = attrId;
        this.attrVal = attrVal;
    }
}
