package com.pg.account.sharding.infrastructure.interceptor;

import cn.com.pg.guardian.client.UserVerifier;
import cn.com.pg.guardian.client.shared.GuardianAuthenticationException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.filter.ContentCachingRequestWrapper;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

import static cn.com.pg.guardian.client.shared.ResultCodeMapper.TOKEN_VERIFY_ERROR;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.ACCOUNT_ID;
import static com.pg.account.sharding.infrastructure.common.constants.V3Constants.TENANT;

/**
 * @author joker
 */
@Component
public class AppGuardianInterceptor implements HandlerInterceptor {


    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws IOException {
        //转换成代理类
        ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(httpServletRequest);
        //如果没有zuul的头文件信息,则不需要验证
        String fromZuulHeader = wrappedRequest.getHeader("x-forwarded-host");
        if (!Optional.ofNullable(fromZuulHeader).isPresent() || !StringUtils.contains(fromZuulHeader, "zuul")) {
            return true;
        }
        //得到请求的资源
        String requestUri = wrappedRequest.getRequestURI();
        String guardianToken = wrappedRequest.getHeader("Proxy-Authorization");
        if (!Optional.ofNullable(guardianToken).isPresent()) {
            throw new GuardianAuthenticationException(TOKEN_VERIFY_ERROR);
        }
        String tenantId;
        String accountId;
        String requestBody = IOUtils.toString(wrappedRequest.getBody(), httpServletRequest.getCharacterEncoding());
        JSONObject jsonObj = JSON.parseObject(requestBody);
        if (Optional.ofNullable(httpServletRequest.getParameter(TENANT)).isPresent()) {
            tenantId = httpServletRequest.getParameter(TENANT);
            // 获取最后一个/
            int i = requestUri.lastIndexOf("/");
            int i1 = requestUri.lastIndexOf("/", requestUri.lastIndexOf("/") - 1);
            accountId = requestUri.substring(i1 + 1, i);
        } else {
            tenantId = jsonObj.getString(TENANT);
            accountId = jsonObj.getString(ACCOUNT_ID);
        }
        int marketingProgramId = LocalCacheConfigUtils.getMarketingProgramId(tenantId);
        try {
            UserVerifier userVerifier = new UserVerifier.Builder()
                    .withGuardianToken(guardianToken)
                    .withMemberId(accountId)
                    .withMarketingProgramId(String.valueOf(marketingProgramId))
                    .build();
            userVerifier.verify();
        } catch (GuardianAuthenticationException e) {
            throw new GuardianAuthenticationException(e.getResultCodeMapper());
        } catch (Exception e) {
            throw new GuardianAuthenticationException(TOKEN_VERIFY_ERROR);
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) {
        // Do nothing
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        // Do nothing
    }

}
