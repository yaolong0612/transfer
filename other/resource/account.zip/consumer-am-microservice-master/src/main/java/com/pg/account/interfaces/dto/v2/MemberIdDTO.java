package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Jack Sun
 * @date 2020-7-24 17:28
 */
@ApiModel(value = "MemberIdDTO_V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberIdDTO implements Serializable {
    private static final long serialVersionUID = 14328038352864451L;

    @ApiModelProperty(value = "AM memberId", name = "memberId", example = "1244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
}
