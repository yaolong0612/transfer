package com.pg.account.interfaces.command;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @author JackSun
 * @date 2017/2/9
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttrCommand implements Serializable {
    private static final long serialVersionUID = -2434901540931937690L;
    @ApiModelProperty(value = "属性主键ID")
    private Long id;
    @ApiModelProperty(value = "用户属性编号", required = true)
    @NotEmpty(message = "missing attrId")
    private String attrId;
    @ApiModelProperty(value = "用户属性内容", required = true)
    @NotEmpty(message = "missing attrVal")
    private String attrVal;

    public AttrCommand(String attrId, String attrVal) {
        this.attrId = attrId;
        this.attrVal = attrVal;
    }
}
