package com.pg.account.sharding.infrastructure.jpa.mapping;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.BindIdMappingRetention;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.BindIdMappingRetentionDao;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.UnionIdMappingRetention;
import com.pg.account.sharding.infrastructure.jpa.mapping.retention.UnionIdMappingRetentionDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * <Description> <br>
 *
 * @author xusheng
 */
@Service
public class FetchMappingService {

    private final BindIdMappingDao bindIdMappingDao;
    private final EmailMappingDao emailMappingDao;
    private final MobileMappingDao mobileMappingDao;
    private final OpenUidMappingDao openUidMappingDao;
    private final UnionIdMappingDao unionIdMappingDao;
    private final BindIdMappingRetentionDao bindIdMappingRetentionDao;
    private final UnionIdMappingRetentionDao unionIdMappingRetentionDao;

    @Autowired
    public FetchMappingService(BindIdMappingDao bindIdMappingDao,
                               EmailMappingDao emailMappingDao,
                               MobileMappingDao mobileMappingDao,
                               OpenUidMappingDao openUidMappingDao,
                               UnionIdMappingDao unionIdMappingDao,
                               BindIdMappingRetentionDao bindIdMappingRetentionDao,
                               UnionIdMappingRetentionDao unionIdMappingRetentionDao

    ) {
        this.bindIdMappingDao = bindIdMappingDao;
        this.emailMappingDao = emailMappingDao;
        this.mobileMappingDao = mobileMappingDao;
        this.openUidMappingDao = openUidMappingDao;
        this.unionIdMappingDao = unionIdMappingDao;
        this.bindIdMappingRetentionDao = bindIdMappingRetentionDao;
        this.unionIdMappingRetentionDao = unionIdMappingRetentionDao;
    }

    /**
     * 根据
     *
     * @param tenantId 租户
     * @param bindId   第三方账号Id
     * @return com.pg.account.sharding.domain.model.account.Account
     * @author xusheng
     * @date 2021/6/1 9:54
     */
    public Account fetchByTenantIdAndChannelIdAndBindId(String tenantId, String channelId, String bindId) {
        BindIdMapping bindIdMapping = Optional.ofNullable(bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(tenantId, channelId, bindId))
                .orElseThrow(() -> new BusinessException(ResultEnum.BIND_ID_NOT_EXIST.getCode(),
                        ResultEnum.BIND_ID_NOT_EXIST.getV2Code(),
                        ResultEnum.BIND_ID_NOT_EXIST.getMessage()));
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(bindIdMapping.getAccountId())
                .build();
    }

    public Account fetchByTenantIdAndUnionId(String tenantId, String unionId, String unionType) {
        UnionIdMapping unionIdMapping = Optional.ofNullable(unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(tenantId, unionId, unionType))
                .orElseThrow(() ->
                        new BusinessException(ResultEnum.UNION_ID_NOT_EXIST.getCode(),
                                ResultEnum.UNION_ID_NOT_EXIST.getV2Code(),
                                ResultEnum.UNION_ID_NOT_EXIST.getMessage()));
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(unionIdMapping.getAccountId())
                .build();
    }

    public Account fetchByTenantIdAndMobile(String tenantId, String mobile) {
        MobileMapping mobileMapping = Optional.ofNullable(
                mobileMappingDao.findByMobileMapId_TenantIdAndMobileMapId_Mobile(tenantId, mobile))
                .orElseThrow(() ->
                        new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(mobileMapping.getAccountId())
                .mobile(mobile)
                .build();
    }

    /**
     * 查询手机号
     *
     * @param tenantId tenantId
     * @param mobile   mobile
     * @return com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping
     * @author xusheng
     * @date 2021/6/4 16:38
     */
    public MobileMapping fetchMobileByTenantIdAndMobile(String tenantId, String mobile) {
        return mobileMappingDao.findByMobileMapId_TenantIdAndMobileMapId_Mobile(tenantId, mobile);
    }

    /**
     * 查询邮箱
     *
     * @param tenantId tenantId
     * @param email    email
     * @return com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping
     * @author xusheng
     * @date 2021/6/4 16:38
     */
    public EmailMapping fetchEmailByTenantIdAndEmail(String tenantId, String email) {
        return emailMappingDao.findByEmailMapId_TenantIdAndEmailMapId_Email(tenantId, email);
    }

    public Account fetchByTenantIdAndEmail(String tenantId, String email) {
        EmailMapping emailMapping = Optional.ofNullable(emailMappingDao.findByEmailMapId_TenantIdAndEmailMapId_Email(tenantId, email))
                .orElseThrow(() ->
                        new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(emailMapping.getAccountId())
                .email(email)
                .build();
    }

    public Account fetchByTenantIdAndOpenUid(String tenantId, String openUid) {
        OpenUidMapping openUidMapping = Optional.ofNullable(openUidMappingDao.findByOpenUidMapId_TenantIdAndOpenUidMapId_OpenUid(tenantId, openUid))
                .orElseThrow(() ->
                        new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                                ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        return Account.AccountBuilder
                .anAccount()
                .tenantId(tenantId)
                .accountId(openUidMapping.getAccountId())
                .openUid(openUid)
                .build();
    }

    /**
     * 根据unionId和channel查询映射关系
     *
     * @param tenantId    tenantId
     * @param unionId     unionId
     * @param unionIdType unionIdType
     * @return com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping
     * @author xusheng
     * @date 2021/6/8 14:56
     */
    public UnionIdMapping fetchByTenantIdAndUnionIdAndChannel(String tenantId, String unionId, String unionIdType) {
        return unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(tenantId, unionId, unionIdType);
    }

    /**
     * 根据accountId和channel查询映射关系
     *
     * @param tenantId    tenantId
     * @param memberId    unionId
     * @param unionIdType channel
     * @return com.pg.account.sharding.infrastructure.jpa.mapping.UnionIdMapping
     * @author xusheng
     * @date 2021/6/8 14:56
     */
    public UnionIdMapping fetchByTenantIdAndAccountIdAndUnionIdType(String tenantId, String memberId, String unionIdType) {
        return unionIdMappingDao.findByUnionIdMapIdTenantIdAndUnionIdMapIdUnionIdAndUnionIdMapIdChannel(tenantId, memberId, unionIdType);
    }

    /**
     * 根据bindId和channelId 查询bindMap关系
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param bindId    bindId
     * @return BindIdMapping
     */
    public BindIdMapping fetchByTenantIdAndBindIdAndChannelId(String tenantId, String bindId, String channelId) {
        return bindIdMappingDao.findByBindIdMapIdTenantIdAndBindIdMapIdChannelIdAndBindIdMapIdBindId(tenantId, channelId, bindId);
    }


    public List<BindIdMappingRetention> findBindIdMappingByAccountIdAndTenant(String accountId, String tenant) {
        return bindIdMappingRetentionDao.findBindIdMappingRetentionByAccountIdAndTenantId(accountId, tenant);
    }

    public List<UnionIdMappingRetention> findUnionIdMappingByAccountIdAndTenant(String accountId, String tenant) {
        return unionIdMappingRetentionDao.findByAccountIdAndTenantId(accountId, tenant);
    }


    public void findAllMappings(String accountId, String tenantId, ShardSocialAccount shardSocialAccount) {
        List<String> bindMappings = bindIdMappingRetentionDao.findBindIdMappingRetentionByAccountIdAndTenantId(accountId, tenantId).stream().map(BindIdMappingRetention::getChannelId).collect(Collectors.toList());
        List<String> dbUnionTypes = unionIdMappingRetentionDao.findByAccountIdAndTenantId(accountId, tenantId).stream().map(UnionIdMappingRetention::getChannel).collect(Collectors.toList());
        if (!Optional.ofNullable(shardSocialAccount.getSocialAccountList()).filter(list -> !list.isEmpty()).isPresent()) {
//            deleteAllBinding(accountId, tenantId);
        } else {
            List<String> collect = shardSocialAccount.getSocialAccountList().stream().map(SocialAccountItem::getChannelId).collect(Collectors.toList());
            List<String> toRemoveBind = bindMappings.stream().filter(n -> !collect.contains(n)).collect(Collectors.toList());
            toRemoveBind.forEach(i -> bindIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannelId(accountId, tenantId, i));
            List<String> unionTypes = shardSocialAccount.getSocialAccountList().stream().map(SocialAccountItem::getChannelId).map(channel -> LocalCacheConfigUtils.getChannelUnionIdType(tenantId, channel)).collect(Collectors.toList());
            List<String> toRemoveUnion = dbUnionTypes.stream().filter(n -> !unionTypes.contains(n)).collect(Collectors.toList());
            toRemoveUnion.forEach(u -> unionIdMappingRetentionDao.deleteByAccountIdAndTenantIdAndChannel(accountId, tenantId, u));
        }

    }

}
