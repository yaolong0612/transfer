package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import com.pg.account.sharding.infrastructure.datastream.servicebus.bean.OptBean;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeOptEventBean implements Serializable {

    private static final long serialVersionUID = 2150072138654028437L;
    @JSONField(name = "member_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @JSONField(name = "marketing_program_id")
    private int marketingProgramId;
    @JSONField(name = "update_flag")
    private char updateFlag;
    @JSONField(name = "modify_datetime")
    private Timestamp modifyDatetime;
    private List<OptBean> opts;


    public void updated() {
        this.updateFlag = 'U';
    }

}
