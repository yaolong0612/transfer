package com.pg.account.infrastructure.common.exception;


import com.alibaba.fastjson.JSONException;
import com.pg.account.interfaces.facade.v1.ShardAccountServiceRest;
import com.pg.account.interfaces.facade.v1.ShardCustomizedServiceRest;
import com.pg.account.interfaces.vo.Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.dao.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import java.util.Optional;
import java.util.Set;

import static com.pg.account.infrastructure.common.constants.AccountConstants.*;
import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.*;

/**
 * 全局统一异常处理器
 *
 * @author Jack Sun
 * @date 2019-11-25 16:36
 */
@ControllerAdvice(assignableTypes = {ShardAccountServiceRest.class, ShardCustomizedServiceRest.class})
@Slf4j
@ResponseBody
public class V1ResultExceptionHandler {

    /**
     * 解析BindingResult的异常信息
     *
     * @param bindingResult 表单异常信息
     * @return 表单详细错误信息
     */
    private static Result<String> handleErrorMessage(BindingResult bindingResult) {
        FieldError error = bindingResult.getFieldError();
        Validate.notNull(error);
        String msg = error.getDefaultMessage();
        return new Result<>(PARAMETER_PARSING_ERROR.getCode().toString(), msg == null ? PARAMETER_PARSING_ERROR.getMessage() : msg);
    }

    /**
     * 拦截自定义返回异常
     *
     * @param e 自定义返回异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ResultException.class)
    public Result<String> handleResultException(ResultException e) {
        log.warn(RESULT_EXCEPTION, e);
        return new Result<>(e.getCode().toString(), e.getMessage());
    }

    /**
     * 参数格式异常
     *
     * @param e Algorithm异常
     * @return 异常返回
     */
    @ExceptionHandler(ParamFormatException.class)
    public Result<String> handleParamFormatException(ParamFormatException e) {
        log.warn(PARAM_FORMAT_EXCEPTION, e);
        return new Result<>(e.getCode().toString(), e.getMessage());
    }

    /**
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ExceptionHandler(DbException.class)
    public Result<String> handleDbException(DbException e) {
        log.warn(DB_EXCEPTION, e);
        return new Result<>(e.getCode().toString(), e.getMessage());
    }

    /**
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ExceptionHandler(DataAccessResourceFailureException.class)
    public Result<String> handleDbException(DataAccessResourceFailureException e) {
        log.warn(DB_EXCEPTION, e);
        return new Result<>(DB_ERROR.getCode().toString(), DB_ERROR.getMessage());
    }

    /**
     * 拦截自定义DB异常
     *
     * @param e DB异常
     * @return 异常返回
     */
    @ExceptionHandler(InvalidDataAccessResourceUsageException.class)
    public Result<String> handleDbException(InvalidDataAccessResourceUsageException e) {
        log.warn(DB_EXCEPTION, e);
        return new Result<>(DB_ERROR.getCode().toString(), DB_ERROR.getMessage());
    }


    /**
     * 拦截自定义业务异常
     *
     * @param e 业务异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(BusinessException.class)
    public Result<String> handleBusinessException(BusinessException e) {
        log.warn(BUSINESS_EXCEPTION, e);
        return new Result<>(e.getCode().toString(), e.getMessage());
    }

    /**
     * 拦截自定义外部系统异常
     *
     * @param e 外部系统异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ExternalSystemException.class)
    public Result<String> handleExternalSystemException(ExternalSystemException e) {
        log.warn(EXTERNAL_SYSTEM_EXCEPTION, e);
        return new Result<>(e.getCode().toString(), e.getMessage());
    }

    /**
     * 拦截未知的异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(Exception.class)
    public Result<String> handleException(Exception e) {
        log.info("SystemErrorException", e);
        return new Result<>(ERROR.getCode().toString(), ERROR.getMessage());
    }

    /**
     * 拦截数据读取超时的异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(DataAccessException.class)
    public Result<String> handleTimeoutException(DataAccessException e) {
        log.info("TimeoutException:", e);
        return new Result<>(REDIS_ERROR.getCode().toString(), REDIS_ERROR.getMessage());
    }

    /**
     * 参数异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public Result<String> handleException(IllegalArgumentException e) {
        log.warn("IllegalArgumentException", e);
        return new Result<>(PARAMETER_PARSING_ERROR.getCode().toString(), Optional.ofNullable(e.getMessage()).orElse(PARAMETER_PARSING_ERROR.getMessage()));
    }

    /**
     * 参数异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(InvalidDataAccessApiUsageException.class)
    public Result<String> handleException(InvalidDataAccessApiUsageException e) {
        log.warn("InvalidDataAccessApiUsageException", e);
        return new Result<>(ACCOUNT_DATA_ERROR.getCode().toString(), Optional.ofNullable(e.getMessage()).orElse(ACCOUNT_DATA_ERROR.getMessage()));
    }

    /**
     * json解析异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(JSONException.class)
    public Result<String> handleException(JSONException e) {
        log.warn("JSONException", e);
        return new Result<>(PARAMETER_PARSING_ERROR.getCode().toString(), Optional.ofNullable(e.getMessage()).orElse(PARAMETER_PARSING_ERROR.getMessage()));
    }

    /**
     * 数据库异常
     *
     * @param e 异常
     * @return 异常返回
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public Result<String> handleException(DataIntegrityViolationException e) {
        log.warn("DbException", e);
        return new Result<>(DB_ERROR.getCode().toString(), DB_ERROR.getMessage());
    }

    /**
     * 400 - Bad Request
     * 拦截表单Java Validation异常
     *
     * @param e 表单参数验证异常
     * @return 异常返回
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(BindException.class)
    public Result<String> handleBindException(BindException e) {
        BindingResult bindingResult = e.getBindingResult();
        return handleErrorMessage(bindingResult);
    }

    /**
     * 400 - Bad Request
     * 缺少请求参数
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public String handleMissingServletRequestParameterException(MissingServletRequestParameterException e) {
        log.warn("缺少请求参数", e);
        return "缺少请求参数";
    }

    /**
     * 400 - Bad Request
     * 参数解析失败
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public String handleHttpMessageNotReadableException(HttpMessageNotReadableException e) {
        log.warn("参数解析失败", e);
        return "参数解析失败";
    }

    /**
     * 400 - Bad Request
     * 方法参数无效
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<String> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        BindingResult bindingResult = e.getBindingResult();
        return handleErrorMessage(bindingResult);

    }

    /**
     * 400 - Bad Request
     * 参数验证失败
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ConstraintViolationException.class)
    public Result<String> handleConstraintViolationException(ConstraintViolationException e) {
        log.warn("参数验证失败,ConstraintViolationException", e);
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();
        ConstraintViolation<?> violation = violations.iterator().next();
        return new Result<>(PARAMETER_PARSING_ERROR.getCode().toString(), violation.getMessage());
    }

    /**
     * 400 - Bad Request
     * 参数验证失败
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ValidationException.class)
    public Result<String> handleValidationException(ValidationException e) {
        log.warn("参数验证失败,ValidationException", e);
        return new Result<>(PARAMETER_PARSING_ERROR.getCode().toString(), e.getMessage());
    }


    /**
     * 404 - Not Found
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(NoHandlerFoundException.class)
    public String noHandlerFoundException(NoHandlerFoundException e) {
        log.warn("Not Found", e);
        return "Not Found";
    }

    /**
     * 405 - Method Not Allowed
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public String handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e) {
        log.warn("不支持当前请求方法", e);
        return "Http Request Method Not Supported";
    }

    /**
     * 415 - Unsupported Media Type
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public String handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException e) {
        log.warn("不支持当前媒体类型", e);
        return "Http Media Type Not Supported";
    }
}
