package com.pg.account.interfaces.command;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryOptionConfigCommand implements Serializable {

    private static final long serialVersionUID = -969882929449644345L;
    @ApiModelProperty(value = "品牌活动编号")
    private int marketingProgramId;
    @ApiModelProperty(value = "品牌编号")
    private String brandCode;
    @ApiModelProperty(value = "订阅类型")
    private String type;
    @ApiModelProperty(value = "公众号编号")
    private String publicAccount;
}
