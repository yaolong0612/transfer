package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.interfaces.dto.AttrDTO;
import com.pg.account.interfaces.dto.CounterDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.Set;

/**
 * @author Jack Sun
 * @date 2020-7-20 17:46
 */
@ApiModel(value = "AccountDTO_V2")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountDTO implements Serializable {

    private static final long serialVersionUID = 1136018717394849096L;
    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
    @ApiModelProperty(value = "Registration Source", example = "OTT", required = true)
    private String source;
    @ApiModelProperty(value = "Registration Time", example = "2020-12-10 12:12:12", required = true)
    private String registrationDate;
    @ApiModelProperty(value = "Register Store", name = "regStore", example = "大润发")
    private String regStore;
    @ApiModelProperty(value = "Customer", name = "customer", example = "PG")
    private String customer;
    @ApiModelProperty(value = "User Profile Information", name = "profile")
    @Valid
    private ProfileDTO profile;
    @ApiModelProperty(value = "Address Information", name = "address")
    @Valid
    private AddressDTO address;
    @ApiModelProperty(value = "User Attribute Information Collection", name = "attrs")
    @Valid
    private Set<AttrDTO> attributes;
    @ApiModelProperty(value = "Counter Information", name = "counter")
    @Valid
    private CounterDTO counter;
    @ApiModelProperty(value = "Job Information Collection", name = "jobs")
    @Valid
    private Set<JobDTO> jobs;
    @ApiModelProperty(value = "Education Information Collection", name = "educations")
    @Valid
    private Set<EducationDTO> educations;
    @ApiModelProperty(value = "InterpersonalRelationship Information Collection", name = "interpersonalRelationships")
    @Valid
    private Set<InterpersonalRelationshipDTO> interpersonalRelationships;


}
