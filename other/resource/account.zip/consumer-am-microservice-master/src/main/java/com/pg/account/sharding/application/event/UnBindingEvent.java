package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 */
@Getter
public class UnBindingEvent extends ApplicationEvent {

    private static final long serialVersionUID = -4322080992231165476L;
    private String flag;
    private ShardSubscription shardSubscription;
    private ShardSocialAccount shardSocialAccount;
    private boolean isRemoveUnionId;

    public UnBindingEvent(Object source) {
        super(source);
    }

    public UnBindingEvent(Object source, ShardSubscription shardSubscription, ShardSocialAccount shardSocialAccount, boolean isRemoveUnionId, String flag) {
        super(source);
        this.shardSocialAccount = shardSocialAccount;
        this.shardSubscription = shardSubscription;
        this.flag = flag;
        this.isRemoveUnionId = isRemoveUnionId;
    }

}
