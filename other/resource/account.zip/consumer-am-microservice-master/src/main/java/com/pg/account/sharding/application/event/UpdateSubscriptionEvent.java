package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 * @date 2021/6/9 21:17
 **/
@Getter
public class UpdateSubscriptionEvent extends ApplicationEvent {

    private static final long serialVersionUID = -4428101573109898212L;

    private ShardSubscription shardSubscription;

    public UpdateSubscriptionEvent(Object source, ShardSubscription shardSubscription) {
        super(source);
        this.shardSubscription = shardSubscription;
    }

    public UpdateSubscriptionEvent(Object source) {
        super(source);
    }
}
