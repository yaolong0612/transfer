package com.pg.account.interfaces.command;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author Jack Sun
 * @date 2019-6-13 16:36
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CounterCommand implements Serializable {

    private static final long serialVersionUID = -260246230774265261L;

    @ApiModelProperty(value = "注册柜台编号", example = "A-BJ-BJ-010-CT086")
    private String regCounterCode;
    @ApiModelProperty(value = "注册柜台名称", example = "华润万家北京分钟寺店")
    private String regCounterName;
    @ApiModelProperty(value = "中心柜台编号", example = "A-BJ-BJ-010-CT086")
    private String mainCounterCode;
    @ApiModelProperty(value = "中心柜台名称", example = "华润万家北京分钟寺店")
    private String mainCounterName;
    @ApiModelProperty(value = "兑换柜台编号", example = "A-BJ-BJ-010-CT086")
    private String pickupCounterCode;
    @ApiModelProperty(value = "兑换柜台名称", example = "华润万家北京分钟寺店")
    private String pickupCounterName;
    @ApiModelProperty(value = "线下首次购买柜台编号", example = "A-BJ-BJ-010-CT086")
    private String offlineFirstPurchaseCounterCode;
    @ApiModelProperty(value = "线下首次购买柜台名称", example = "华润万家北京分钟寺店")
    private String offlineFirstPurchaseCounterName;
    @ApiModelProperty(value = "首次购买柜台编号", example = "A-BJ-BJ-010-CT086")
    private String firstPurchaseCounterCode;
    @ApiModelProperty(value = "首次购买时间", example = "2020-07-04T00:00:00")
    private String firstPurchaseTime;
    @ApiModelProperty(value = "CRM兑换柜台编号", example = "A-BJ-BJ-010-CT086")
    private String crmPickupCounterCode;
}
