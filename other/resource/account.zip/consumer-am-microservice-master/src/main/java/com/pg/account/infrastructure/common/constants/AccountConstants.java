package com.pg.account.infrastructure.common.constants;

import org.springframework.stereotype.Component;

/**
 * create by Jack
 *
 * @author sunliang
 */
@Component
public class AccountConstants {

    /**
     * 基础异常码
     */
    public static final String BASE_AM_CODE = "5";
    public static final String YES = "1";
    public static final String NO = "0";
    /**
     * tenantId，系统管理员编号
     */
    public static final String ADMIN_CODE = "9999";
    public static final String ADD_INTEGRAL = "AddIntegral";
    public static final String PRODUCER_EVENT_HUB = "ProducerEventHub";
    public static final String CONSUMER_EVENT_HUB = "ConsumerEventHub";
    public static final String REPEAT_INTEGRAL = "30";
    public static final String MAX_INTEGRAL = "35";
    public static final String TRUE = "true";
    public static final String FALSE = "false";
    public static final String VERIFICATION = "verification";
    public static final String MESSAGE = "message";
    /**
     * loyalty 创建积分账号所需常量
     */
    public static final String REGION = "ML";
    public static final String REGISTER = "REGISTER";
    public static final String BINDING = "BINDING";
    /**
     * 会员修改加积分
     */
    public static final String COMPLETE_PROFILE = "COMPLETE_PROFILE";
    /**
     * 不需要创建积分账号的租户
     */
    public static final Long SKII_CODE = 10001L;
    public static final Long JI_CODE = 10005L;
    public static final Long POME_SCHOOL = 10011L;
    /**
     * Result true
     */
    public static final String RESULT_TRUE = "0";
    /**
     * Result Code
     */
    public static final String RESULT_CODE = "resultCode";
    /**
     * Result Message
     */
    public static final String RESULT_MESSAGE = "errorMsg";
    /**
     * Result Object
     */
    public static final String RESULT_OBJECT = "object";
    /**
     * Result Code
     */
    public static final String CODE = "code";
    /**
     * Y 是
     */
    public static final String Y = "Y";
    /**
     * N 否
     */
    public static final String N = "N";
    public static final String URL = "url";
    public static final String METHOD = "method";
    public static final String VALUE = "value";
    public static final String API_KEY = "apiKey";
    public static final String API_SECRET = "apiSecret";
    public static final String BRAND_ID = "brandId";
    public static final String GET = "GET";
    public static final String POST = "POST";
    public static final String PUT = "PUT";
    public static final String PATCH = "PATCH";
    public static final String DELETE = "DELETE";
    public static final String LOYALTY_TYPE = "loyaltyType";
    public static final String TEMPLATE_REGISTER_CODE = "template_Register_Code";
    public static final String DB_EXCEPTION = "DbException";
    public static final String BUSINESS_EXCEPTION = "BusinessException";
    public static final String RESULT_EXCEPTION = "ResultException";
    public static final String PARAM_FORMAT_EXCEPTION = "ParamFormatException";
    public static final String EXTERNAL_SYSTEM_EXCEPTION = "ExternalSystemException";
    public static final String SYSTEM_EXCEPTION = "SystemException";
    public static final String YYYY_MM = "yyyyMM";
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYY_MM_DD_HH_MI_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD_HH_MI_SS_SSS = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * 参数常量
     */
    public static final String OPEN_ID = "openId";
    public static final String MEMBER_ID = "memberId";
    public static final String NEW_REGISTER = "newRegister";
    public static final String USERS_ID = "usersId";
    public static final String IS_BIND = "isBind";
    public static final String BIND_DTO_LIST = "bindDTOList";
    public static final String EMAIL = "email";
    public static final String CELLPHONE = "cellphone";
    public static final String BIND_ID = "bindid";
    public static final String CHANNEL_ID = "channelId";
    public static final String UNION_ID = "unionid";
    public static final String TYPE = "type";
    public static final String MOBILE_TYPE = "M";
    public static final String EMAIL_TYPE = "E";
    public static final String UNION_ID_TYPE = "U";
    public static final String BIND_ID_TYPE = "B";
    public static final String LIMIT = "limit";


    /**
     * 符号常量
     */
    public static final String COMMA = ",";
    public static final String COLON = ":";
    public static final String EQUAL = "=";
    public static final String KEY_DELIMITER = "_";

    private AccountConstants() {
        //私有构造方法
    }

}
