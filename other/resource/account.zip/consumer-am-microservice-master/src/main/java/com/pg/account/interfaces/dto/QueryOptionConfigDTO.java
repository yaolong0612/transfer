package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@ApiModel(value = "QueryOptionConfigDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryOptionConfigDTO implements Serializable {

    private static final long serialVersionUID = -2790086724881035578L;
    @ApiModelProperty(value = "订阅ID", example = "101")
    private String optId;
    @ApiModelProperty(value = "条款内容")
    private List<TermsDTO> terms;

}
