package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author wsq
 * @date 2021/6/9 21:23
 **/
@Getter
public class UpdateAttributeEvent extends ApplicationEvent {
    private static final long serialVersionUID = 6811532305357378936L;

    private Account account;

    public UpdateAttributeEvent(Object source) {
        super(source);
    }

    public UpdateAttributeEvent(Object source, Account account) {
        super(source);
        this.account = account;
    }
}
