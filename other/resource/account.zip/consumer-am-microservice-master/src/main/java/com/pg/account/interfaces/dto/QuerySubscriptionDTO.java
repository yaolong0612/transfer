package com.pg.account.interfaces.dto;

import com.pg.account.interfaces.dto.v2.SubscriptionDTO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 * @date 2017/2/17
 */
@ApiModel(value = "QuerySubscriptionDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuerySubscriptionDTO implements Serializable {
    private static final long serialVersionUID = 1454269018282802456L;

    @ApiModelProperty(value = "租户ID", example = "10004")
    private Long tenantId;
    @ApiModelProperty(value = "订阅信息集合")
    private List<SubscriptionDTO> subscriptionBeanList;

}
