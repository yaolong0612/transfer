package com.pg.account.sharding.application.event.bean;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 人际关系信息收集
 *
 * @author xusheng
 * @date 2020/9/8 <br>
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterpersonalRelationshipBean implements Serializable {
    private static final long serialVersionUID = -8271078268406737578L;
    @JSONField(name = "relationship_name")
    private String relationshipName;
    @JSONField(name = "relationship_sequence")
    private String relationshipSequence;
    @JSONField(name = "full_name")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @Desensitized(value = DesensitizedEnum.BIRTHDAY)
    private String birthday;
    @Desensitized(value = DesensitizedEnum.GENDER)
    private String gender;
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    private String guardian;
    @JSONField(name = "create_time")
    private Timestamp createTime;
    @JSONField(name = "modify_time")
    private Timestamp modifyTime;
}
