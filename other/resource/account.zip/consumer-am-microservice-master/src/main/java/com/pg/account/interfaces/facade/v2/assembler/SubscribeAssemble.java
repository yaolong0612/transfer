package com.pg.account.interfaces.facade.v2.assembler;

import com.pg.account.interfaces.command.v2.SubscriptionCommand;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.domain.model.subscription.SubscriptionItem;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * @author lfx
 * @date 2021/6/16 9:45
 */
@Component("ShardSubscribeAssemble")
public class SubscribeAssemble {

    /**
     * 将SubscriptionCommand转入订阅聚合根
     *
     * @param tenantId                tenantId
     * @param channelId               channelId
     * @param subscriptionCommandList subscriptionCommandList
     * @author xusheng
     * @date 2021/6/17 16:31
     */
    public ShardSubscription toShardSubscription(Long tenantId, Long channelId, String memberId, Set<SubscriptionCommand> subscriptionCommandList) {
        IdentityId identityId = new IdentityId(tenantId.toString(), memberId);
        List<SubscriptionItem> subscriptionList = new ArrayList<>();
        SubscriptionItem subscriptionItem = new SubscriptionItem();
        if (Optional.ofNullable(subscriptionCommandList)
                .filter(subscriptionCommands -> !subscriptionCommands.isEmpty())
                .isPresent()) {
            //传入了订阅信息
            subscriptionCommandList.forEach(subscriptionCommand -> {
                subscriptionItem.build(subscriptionCommand.getOptId(), null, subscriptionCommand.getOptStatus(), null);
                subscriptionItem.setChannelId(channelId.toString());
            });
        } else {
            subscriptionItem.setChannelId(channelId.toString());
        }
        subscriptionList.add(subscriptionItem);
        return new ShardSubscription(identityId, subscriptionList);
    }
}
