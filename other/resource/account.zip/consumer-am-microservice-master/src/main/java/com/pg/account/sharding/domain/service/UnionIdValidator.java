package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.domain.service.annotation.UnionIdIsNecessary;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.Valid;
import java.util.Optional;

/**
 * @author lfx
 * @date 2021/11/29 14:32
 */
public class UnionIdValidator implements ConstraintValidator<UnionIdIsNecessary, @Valid ShardSocialAccount> {

    @Override
    public boolean isValid(@Valid ShardSocialAccount shardSocialAccount, ConstraintValidatorContext constraintValidatorContext) {
        for (SocialAccountItem a : shardSocialAccount.getSocialAccountList()) {
            // 天猫换成可配置的redis 或者配置文件
            if ("TMALL".equals(a.getChannel().getUnionType()) && !Optional.ofNullable(a.getUnionId()).isPresent()) {
                return false;
            }
        }
        return true;
    }
}
