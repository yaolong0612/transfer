package com.pg.account.interfaces.facade.v2;

import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.enums.QueryTypeEnum;
import com.pg.account.infrastructure.common.enums.RegisterTypeEnum;
import com.pg.account.infrastructure.common.enums.UnBindRouteEnum;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.vo.Result;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import com.pg.account.interfaces.command.v2.AccountProfileModifyCommand;
import com.pg.account.interfaces.command.v2.AccountRegisterCommand;
import com.pg.account.interfaces.command.v2.AccountSubscriptionsModifyCommand;
import com.pg.account.interfaces.command.v2.SocialAccountBindCommand;
import com.pg.account.interfaces.dto.BindDTO;
import com.pg.account.interfaces.dto.v2.*;
import com.pg.account.interfaces.facade.v1.assembler.ModifyProfileAssembler;
import com.pg.account.interfaces.facade.v2.assembler.BindAccountAssemble;
import com.pg.account.interfaces.facade.v2.assembler.ModifySubscriptionsAssembler;
import com.pg.account.interfaces.facade.v2.assembler.RegisterAccountAssembler;
import com.pg.account.interfaces.facade.v2.assembler.SubscribeAssemble;
import com.pg.account.sharding.application.AccountAppService;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.AccountStatus;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.socialaccount.repository.ShardSocialAccountRepository;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

import static com.alibaba.fastjson.JSON.parseArray;
import static com.alibaba.fastjson.JSON.parseObject;
import static com.pg.account.infrastructure.common.constants.AccountConstants.OPEN_ID;
import static com.pg.account.interfaces.facade.v1.assembler.QueryProfileAssembler.fromAccountDtoV2;

/**
 * 会员账号对外接口
 *
 * @author LC
 */
@RestController
@RequestMapping("/v2")
@Slf4j
@Validated
@Api(tags = {"V2 restful规范接口，目前只有新租户才能接入使用"})
public class ShardAccountManagementFacade {

    public static final String ACCOUNT_ID = "accountId";
    public static final String IS_BIND = "isBind";
    public static final String UNION_ID = "unionId";
    public static final String BIND_ID = "bindId";
    public static final String BIND_DTO_LIST = "bindDTOList";
    private final AccountAppService accountAppService;
    private final FetchMappingService fetchMappingService;
    private final AccountInfoDao accountInfoDao;
    private final RegisterAccountAssembler registerAccountAssembler;
    private final BindAccountAssemble bindAccountAssemble;
    private final ModifySubscriptionsAssembler modifySubscriptionsAssembler;
    private final ModifyProfileAssembler modifyProfileAssembler;
    private final SubscribeAssemble subscribeAssemble;
    private final ShardSocialAccountRepository socialAccountRepository;

    @Autowired
    public ShardAccountManagementFacade(
            AccountAppService accountAppService,
            FetchMappingService fetchMappingService,
            AccountInfoDao accountInfoDao,
            RegisterAccountAssembler registerAccountAssembler,
            BindAccountAssemble bindAccountAssemble,
            ModifySubscriptionsAssembler modifySubscriptionsAssembler,
            ModifyProfileAssembler modifyProfileAssembler,
            SubscribeAssemble subscribeAssemble,
            ShardSocialAccountRepository socialAccountRepository
    ) {

        this.accountAppService = accountAppService;
        this.fetchMappingService = fetchMappingService;
        this.accountInfoDao = accountInfoDao;
        this.registerAccountAssembler = registerAccountAssembler;
        this.bindAccountAssemble = bindAccountAssemble;
        this.modifySubscriptionsAssembler = modifySubscriptionsAssembler;
        this.modifyProfileAssembler = modifyProfileAssembler;
        this.subscribeAssemble = subscribeAssemble;
        this.socialAccountRepository = socialAccountRepository;
    }

    /**
     * 注册绑定
     *
     * @param accountRegisterCommand 注册绑定入参
     * @param tenant                 租户
     * @param channel                渠道
     * @return 返回参
     */
    @PostMapping(value = "/tenants/{tenant}/channels/{channel}/accounts")
    @ApiOperation(value = "registerBind", notes = "Register And RegisterBind According to different dimensions: The parameter type = 1 or register ,if register success httpStatus return 201 " +
            " and type = 2 or registerBind if success httpStatus return 200 ", produces = "application/json")
    @ResponseBody
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "accountRegisterCommand", name = "accountRegisterCommand", dataType = "AccountRegisterCommand", defaultValue = "AccountRegisterCommand")
    })
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Register Success"),
            @ApiResponse(code = 201, message = "RegisterBind Success"),
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    public ResponseEntity<AccountRegisterDTO> registerBind(@Valid @RequestBody AccountRegisterCommand accountRegisterCommand, @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel) {
        String type = accountRegisterCommand.getType();
        Account account = registerAccountAssembler.toAccount(tenant, channel, accountRegisterCommand);
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(tenant, channel, null, accountRegisterCommand.getBindId(), accountRegisterCommand.getUnionId());
        ShardSubscription shardSubscription = subscribeAssemble.toShardSubscription(tenant, channel, null, accountRegisterCommand.getSubscriptions());
        switch (RegisterTypeEnum.getByKeyOrValue(type)) {
            case REGISTER:
                this.accountAppService.register(account, shardSubscription);
                return new ResponseEntity<>(new AccountRegisterDTO(account.getOpenUid()), HttpStatus.CREATED);
            case REGISTER_BIND:
                this.accountAppService.registerBind(account, shardSocialAccount, shardSubscription);
                return new ResponseEntity<>(new AccountRegisterDTO(account.getOpenUid()), HttpStatus.OK);
            default:
                throw new BusinessException(ResultEnum.REGISTER_TYPE_NOT_EXIST.getCode(), ResultEnum.REGISTER_TYPE_NOT_EXIST.getV2Code(), ResultEnum.REGISTER_TYPE_NOT_EXIST.getMessage());
        }

    }

    /**
     * 根据不同的数据维度查询账号
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param type    查询类型
     * @param query   查询信息
     * @return Result<AccountQueryDTO> 主要返回openId，如果根据bindId查询会判断是否存在绑定关系，其他查询existBind默认返回false。
     */
    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/accounts")
    @ApiOperation(value = "queryAccount", notes = "Query account according to different dimensions: The parameter type of query " +
            "type = 1 or bindId(（Third-party platform unique Id）)\n" +
            "and type = 2 or unionId（The third party's social platform account unique identifier is used to associate the social binding ID\n" +
            "and type = 3 or openId and type = 4 or mobile\n" +
            "and type = 5 or bindIdAndUnionId is passed in json format，example=%7b%22bindId%22: %22test31112184112%22,%22unionId%22: %22test12111%22%7d", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "query type:1、bindId,2、unionId,3、openId,4、mobile,5、bindIdAndUnionId", name = "type", dataType = "String", example = "1 or bindId"),
            @ApiImplicitParam(required = true, value = "query parameter", name = "query", dataType = "String", example = "testBindId1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<AccountQueryDTO> queryAccount(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @RequestParam String type, @RequestParam String query) {
        AccountQueryDTO accountQueryDTO;
        Account account;
        JSONObject jsonObject = new JSONObject();
        switch (QueryTypeEnum.getByKeyOrValue(type)) {
            case BIND_ID:
                account = fetchMappingService.fetchByTenantIdAndChannelIdAndBindId(tenant.toString(), channel.toString(), query);
                jsonObject.put(ACCOUNT_ID, account.getAccountId());
                jsonObject.put(IS_BIND, true);
                break;
            case UNION_ID:
                String channelUnionIdType = Optional.ofNullable(CacheLocalConfigUtils.getChannelUnionIdType(tenant, channel)).filter(c -> !c.isEmpty()).orElseThrow(() -> new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage()));
                account = fetchMappingService.fetchByTenantIdAndUnionId(tenant.toString(), query, channelUnionIdType);
                jsonObject.put(ACCOUNT_ID, account.getAccountId());
                ShardSocialAccount socialAccount = socialAccountRepository.findByIdentityIdTenantIdAndIdentityIdAccountId(account.getTenantId(), account.getAccountId());
                Optional.ofNullable(socialAccount).map(ShardSocialAccount::getSocialAccountList).filter(s -> !s.isEmpty()).ifPresent(a -> a.removeIf(item -> !channel.toString().equals(item.getChannelId())));
                jsonObject.put(ACCOUNT_ID, Optional.ofNullable(socialAccount).map(ShardSocialAccount::getAccountId).orElseGet(account::getAccountId));
                jsonObject.put(IS_BIND, Optional.ofNullable(socialAccount).map(ShardSocialAccount::getSocialAccountList).filter(s -> !s.isEmpty()).isPresent());
                break;
            case OPEN_ID:
                account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), query);
                jsonObject.put(ACCOUNT_ID, account.getAccountId());
                jsonObject.put(IS_BIND, false);
                break;
            case MOBILE:
                account = fetchMappingService.fetchByTenantIdAndMobile(tenant.toString(), query);
                jsonObject.put(ACCOUNT_ID, account.getAccountId());
                jsonObject.put(IS_BIND, false);
                break;
            case BIND_ID_AND_UNION_ID:
                JSONObject queryJson = parseObject(query);
                jsonObject = accountAppService.fetchAccountByUnionIdAndBindId(tenant.toString(), channel.toString(), queryJson.getString(UNION_ID), queryJson.getString(BIND_ID));
                break;
            default:
                throw new BusinessException(ResultEnum.PARAMETER_PARSING_ERROR.getCode(), ResultEnum.PARAMETER_PARSING_ERROR.getV2Code(), ResultEnum.PARAMETER_PARSING_ERROR.getMessage());
        }
        ShardAccountInfo accountInfo = accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(tenant.toString(), jsonObject.getString(ACCOUNT_ID));
        accountQueryDTO = new AccountQueryDTO(accountInfo.getOpenUid(), jsonObject.getBoolean(IS_BIND));
        return new ResponseEntity<>(accountQueryDTO, HttpStatus.OK);
    }

    /**
     * 查询绑定信息
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param type    查询类型
     * @param query   查询信息
     * @return 返回参
     */
    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/socialAccounts")
    @ApiOperation(value = "queryBinding", notes = "Query binding information according to different dimensions " +
            "1. according bindId， Query the binding relationship of this member" +
            "2. according openId   Query the binding relationship of this member" +
            "3. according channelAndOpenId Query the binding relationship of this member", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "query type，1、ChannelAndBindId（第三方平台唯一Id）,2、channelAndOpenId，3、openId", name = "type", dataType = "String", example = "1"),
            @ApiImplicitParam(required = true, value = "query parameter", name = "query", dataType = "String", example = "testBindId1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    public ResponseEntity<SocialAccountDTO> queryBinding(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @RequestParam String type, @RequestParam String query) {
        JSONObject jsonObject;
        jsonObject = accountAppService.queryBinding(tenant, channel, type, query);
        SocialAccountDTO socialAccountDTO = new SocialAccountDTO(jsonObject.getString(OPEN_ID), parseArray(jsonObject.getString(BIND_DTO_LIST), BindDTO.class));
        return new ResponseEntity<>(socialAccountDTO, HttpStatus.OK);
    }


    /**
     * 查询会员信息，其中包含根据传入的fields字段返回所需要的结果
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param openId  对外开放的会员号
     * @param fields  需要查询字段
     * @return org.springframework.http.ResponseEntity<com.pg.account.interfaces.dto.AccountDTO>
     * @author YJ
     * @date 2021-5-12
     */
    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/{openId}/profiles")
    @ApiOperation(value = "queryProfile", notes = "Query account profile according to openId, Query member information according to different fields" +
            "fields include attribute、 address、profile、counter、job、interpersonal_relationship、education", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "openId", name = "openId", dataType = "String", paramType = "path", example = "1234567890"),
            @ApiImplicitParam(value = "Query fields as needed：address,attribute,counter,job,education,interpersonal_relationship", name = "fields", dataType = "String", example = "address,attribute")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<AccountDTO> queryProfile(@Valid @TenantExistValid @PathVariable Long tenant,
                                                   @PathVariable Long channel,
                                                   @PathVariable String openId,
                                                   @RequestParam(required = false) String fields) {
        AccountDTO accountDTO;
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), openId);
        JSONObject jsonObject = accountAppService.getProfile(account, fields);
        accountDTO = fromAccountDtoV2(jsonObject);
        return new ResponseEntity<>(accountDTO, HttpStatus.OK);
    }


    /**
     * 绑定
     *
     * @param socialAccountBindCommand 绑定入参
     * @param tenant                   租户
     * @param channel                  渠道
     * @return 返回参
     */
    @PostMapping(value = "/tenants/{tenant}/channels/{channel}/socialAccounts")
    @ApiOperation(value = "bind", notes = "Binding Member,Check the identity information. You have already been a member, " +
            "but the current third-party social account information has not been bound. " +
            "Please call this interface to bind.", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "socialAccountBindCommand", name = "socialAccountBindCommand", dataType = "SocialAccountBindCommand", defaultValue = "SocialAccountBindCommand")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Object> bind(@Valid @RequestBody SocialAccountBindCommand socialAccountBindCommand, @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), socialAccountBindCommand.getOpenId());
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(tenant, channel, account.getAccountId(), socialAccountBindCommand.getBindId(), socialAccountBindCommand.getUnionId());
        ShardSubscription shardSubscription = subscribeAssemble.toShardSubscription(tenant, channel, account.getAccountId(), null);
        Account deviceAccount = registerAccountAssembler.toAccount(tenant, account.getAccountId(), socialAccountBindCommand.getDevice());
        accountAppService.bind(deviceAccount, shardSocialAccount, shardSubscription);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 根据openId取消账号
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param openId  openId
     * @return httpStatus 200成功，其他错误
     */
    @DeleteMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/{openId}")
    @ApiOperation(value = "cancelAccount", notes = "Cancel the account according to openId", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "openId", name = "openId", dataType = "String", paramType = "path", example = "1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Void> cancelAccount(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String openId) {
        Account account = Account.AccountBuilder
                .anAccount()
                .tenantId(tenant.toString())
                .openUid(openId)
                .build();
        accountAppService.inactiveAccount(account);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    /**
     * 更新会员信息
     *
     * @param accountProfileModifyCommand 需要更新的参数
     * @param tenant                      租户
     * @param channel                     渠道
     * @author YJ
     * @date 2021/5/13
     */
    @PutMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/profiles")
    @ApiOperation(value = "modifyProfile", notes = "Modify user profile according to openId.Modify personal information, including: counter information, profile," +
            " address information, subscription information and user attribute information" +
            "Note: Modified personal information is not required to be transmitted, only the information that needs to be changed is modified.", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "accountProfileModifyCommand", name = "accountProfileModifyCommand", dataType = "AccountProfileModifyCommand", defaultValue = "AccountProfileModifyCommand")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Void> modifyProfile(@Valid @RequestBody AccountProfileModifyCommand accountProfileModifyCommand, @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), accountProfileModifyCommand.getOpenId());
        account = modifyProfileAssembler.toAccount(tenant, channel, account.getAccountId(), accountProfileModifyCommand);
        accountAppService.modifyAccount(account, null);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    /**
     * 根据openId查询订阅信息
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param openId  openId
     * @return httpStatus 200成功，其他错误
     */

    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/subscriptions/{openId}")
    @ApiOperation(value = "querySubscriptions", notes = "Query user subscriptions according to openId and tenantId" +
            "Note: tenantId must pass values", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "openId", name = "openId", dataType = "String", paramType = "path", example = "1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<SubscriptionQueryDTO> querySubscriptions(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String openId) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), openId);
        SubscriptionQueryDTO subscriptionQueryDTO = accountAppService.querySubscriptionsByOpenId(account);
        return new ResponseEntity<>(subscriptionQueryDTO, HttpStatus.OK);
    }


    /**
     * 修改账号订阅状态
     *
     * @param accountSubscriptionsModifyCommand 订阅变更参数
     * @param tenant                            租户
     * @param channel                           渠道
     * @return httpStatus 200成功，其他错误
     */
    @PutMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/subscriptions")
    @ApiOperation(value = "modifySubscriptions", notes = "Modify user subscriptions according to openId", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "accountSubscriptionsModifyCommand", name = "accountSubscriptionsModifyCommand", dataType = "AccountSubscriptionsModifyCommand", defaultValue = "AccountSubscriptionsModifyCommand")

    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Void> modifySubscriptions(@Valid @RequestBody AccountSubscriptionsModifyCommand accountSubscriptionsModifyCommand, @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), accountSubscriptionsModifyCommand.getOpenId());
        ShardSubscription shardSubscription = modifySubscriptionsAssembler.toShardSubscription(accountSubscriptionsModifyCommand, tenant.toString(), channel.toString(), account.getAccountId());
        accountAppService.storeShardSubscription(shardSubscription);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    /**
     * 根据memberId查询openId
     *
     * @param tenant   租户
     * @param channel  渠道
     * @param memberId 会员Id
     * @return Result<String> 返回openId。
     */
    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/openId/{memberId}")
    @ApiOperation(value = "queryOpenIdByMemberId", notes = "Query the open Id based on the memberId", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "memberId", name = "memberId", dataType = "String", paramType = "path", example = "1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<OpenIdDTO> queryOpenIdByMemberId(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String memberId) {
        ShardAccountInfo accountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountIdAndAccountStatus(tenant.toString(), memberId, AccountStatus.ACTIVE)).orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(), ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(), ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        OpenIdDTO openIdDTO = new OpenIdDTO(accountInfo.getOpenUid());
        return new ResponseEntity<>(openIdDTO, HttpStatus.OK);
    }

    /**
     * 根据openId查询memberId
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param openId  开放Id
     * @return Result<String> 返回openId。
     */
    @GetMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/memberId/{openId}")
    @ApiOperation(value = "queryMemberIdByOpenId", notes = "Query the member Id based on the openId", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "openId", name = "openId", dataType = "String", paramType = "path", example = "1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<MemberIdDTO> queryMemberIdByOpenId(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String openId) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), openId);
        MemberIdDTO memberIdDTO = new MemberIdDTO(account.getAccountId());
        return new ResponseEntity<>(memberIdDTO, HttpStatus.OK);
    }

    /**
     * 根据bindId解除绑定
     * 当绑定数据有unionId且是当前解绑的数据是unionType关联关系的最后一条，unionId也要解除绑定
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param bindId  bindId
     * @return httpStatus 200成功，其他错误
     */
    @DeleteMapping(value = "/tenants/{tenant}/channels/{channel}/socialAccounts/{bindId}")
    @ApiOperation(value = "unBind", notes = "Unbind according to bindId\n" +
            "When the bound data has unionId and the currently unbound data is the last item of the unionType association relationship, unionId should also be unbound", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "bindId", name = "bindId", dataType = "String", paramType = "path", example = "1234567890")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Void> unBind(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String bindId) {
        List<String> unBindType = bindAccountAssemble.getUnBindType(bindId);
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(tenant, channel, null, bindId, null);
        ShardSubscription shardSubscription = subscribeAssemble.toShardSubscription(tenant, channel, null, null);
        accountAppService.unBind(shardSocialAccount, shardSubscription, UnBindRouteEnum.BIND_ID_AND_CHANNEL_ID.getKey());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 根据openId和type解除绑定关系
     * type=all 解除所有绑定
     * type=channel 根据{channel}对应配置中的unionType解除有同类型unionId关联的绑定数据
     *
     * @param tenant  租户
     * @param channel 渠道
     * @param openId  openId
     * @return httpStatus 200成功，其他错误
     */
    @DeleteMapping(value = "/tenants/{tenant}/channels/{channel}/accounts/{openId}/socialAccounts/{type}")
    @ApiOperation(value = "unBindAll", notes = "According to openId and type to release the binding relationship\n" +
            "type=all to release all bindings\n" +
            "type=channel according to {channel} corresponding to the configuration of the unionType to release the binding data associated with the same type of unionId", produces = "application/json")
    @ApiImplicitParams({
            @ApiImplicitParam(required = true, value = "tenant", name = "tenant", dataType = "Long", paramType = "path", example = "10001"),
            @ApiImplicitParam(required = true, value = "channel", name = "channel", dataType = "Long", paramType = "path", example = "3"),
            @ApiImplicitParam(required = true, value = "openId", name = "openId", dataType = "String", paramType = "path", example = "1234567890"),
            @ApiImplicitParam(required = true, value = "unbind Type as need:all or wechat or TMall etc.", name = "type", dataType = "String", paramType = "path", example = "all")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Bad request", response = Result.class),
            @ApiResponse(code = 401, message = "Unauthorized", response = Result.class),
            @ApiResponse(code = 403, message = "Forbidden", response = Result.class),
            @ApiResponse(code = 404, message = "Not found", response = Result.class),
            @ApiResponse(code = 500, message = "Internal server error", response = Result.class)})
    @ResponseBody
    public ResponseEntity<Void> unBindAll(
            @PathVariable @TenantExistValid Long tenant, @PathVariable Long channel, @PathVariable String openId, @PathVariable String type) {
        Account account = fetchMappingService.fetchByTenantIdAndOpenUid(tenant.toString(), openId);
        ShardSocialAccount shardSocialAccount = bindAccountAssemble.toShardSocialAccount(tenant, channel, account.getAccountId(), null, null);
        accountAppService.unBindAll(shardSocialAccount, type);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
