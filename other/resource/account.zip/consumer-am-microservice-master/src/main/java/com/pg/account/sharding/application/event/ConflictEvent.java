package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount;
import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

import java.io.Serializable;

/**
 * @author lfx
 * @date 2022/1/20 16:04
 */
@Getter
public class ConflictEvent extends ApplicationEvent implements Serializable {

    private static final long serialVersionUID = 7578292207178698311L;
    private final Account account;
    private final ShardSocialAccount shardSocialAccount;
    private final ShardSubscription shardSubscription;

    public ConflictEvent(Object source, Account account, ShardSocialAccount shardSocialAccount,ShardSubscription shardSubscription) {
        super(source);
        this.account = account;
        this.shardSocialAccount = shardSocialAccount;
        this.shardSubscription = shardSubscription;
    }
}
