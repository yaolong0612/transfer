package com.pg.account.sharding.infrastructure.client.address;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.ExternalSystemException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.exception.enums.V3ResultEnum;
import com.pg.account.sharding.domain.service.FetchAddressService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static java.lang.Integer.parseInt;

/**
 * @author Jack
 * @date 2021-04-20 14:22
 */
@Slf4j
@Component
public class FetchAddressServiceImpl implements FetchAddressService {

    /**
     * 主地址
     */
    public static final String IS_PRIMARY = "1";
    /**
     * 家庭地址
     */
    public static final String ADDRESS_TYPE = "1";
    public static final String RESULT_CODE = "resultCode";
    public static final String ERROR_MSG = "errorMsg";
    public static final String OBJECT = "object";
    private final AddressServiceClient addressServiceClient;

    @Autowired
    public FetchAddressServiceImpl(AddressServiceClient addressServiceClient) {
        this.addressServiceClient = addressServiceClient;
    }

    /**
     * 根据会员ID查询地址信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Address
     */
    @Override
    public Address fetchByTenantIdAndAccountId(String tenantId, String accountId) {
        QueryAddressRequest queryAddressRequest = new QueryAddressRequest(Long.parseLong(tenantId), accountId, null, ADDRESS_TYPE);
        ResponseEntity<JSONObject> responseEntity;
        try {
            responseEntity = this.addressServiceClient.queryAddress(queryAddressRequest);
        } catch (Exception e) { // FeignException捕捉不了
            log.warn("FetchAddressServiceImpl-fetchByTenantIdAndAccountId. Request tenantId:{},accountId:{}. Exception:", tenantId, DesensitizedUtils.identification(accountId), e);
            throw new ExternalSystemException(ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getCode(), ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getV2Code(), ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getMessage());
        }
        Validate.notNull(responseEntity.getBody(), "查询地址返回空值");
        JSONObject jsonObject = responseEntity.getBody();
        exceptionHandler(responseEntity.getStatusCode(), jsonObject);
        if (jsonObject.containsKey(OBJECT)) {
            QueryAddressResponse queryAddressResponse = JSON.toJavaObject(jsonObject.getJSONObject(OBJECT), QueryAddressResponse.class);
            if (Optional.ofNullable(queryAddressResponse).map(QueryAddressResponse::getAddressBeanList).filter(addr -> !addr.isEmpty()).isPresent()) {
                Optional<Address> address = queryAddressResponse.getAddressBeanList().stream().filter(a -> IS_PRIMARY.equals(a.getIsPrimary())).findFirst();
                if (address.isPresent()) {
                    return address.get();
                }
            }
        }
        return null;
    } /**
     * 根据会员ID查询地址信息
     *
     * @param accountId accountId
     * @param tenantId  tenantId
     * @return Address
     */
    @Override
    public Address fetchByAccountIdAndTenant(String accountId, String tenantId) {
        QueryAddressRequest queryAddressRequest = new QueryAddressRequest(Long.parseLong(tenantId), accountId, null, ADDRESS_TYPE);
        ResponseEntity<JSONObject> responseEntity;
        try {
            responseEntity = this.addressServiceClient.queryAddress(queryAddressRequest);
        } catch (Exception e) { // FeignException捕捉不了
            log.warn("FetchAddressServiceImpl-fetchByTenantIdAndAccountId. Request tenantId:{},accountId:{}. Exception:", tenantId, DesensitizedUtils.identification(accountId), e);
            throw new BusinessException(V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getCode(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getMessage(), V3ResultEnum.ADDRESS_MICRO_SERVICE_ERROR.getFrontMessage());
        }
        Validate.notNull(responseEntity.getBody(), "查询地址返回空值");
        JSONObject jsonObject = responseEntity.getBody();
        exceptionHandler(responseEntity.getStatusCode(), jsonObject);
        if (jsonObject.containsKey(OBJECT)) {
            QueryAddressResponse queryAddressResponse = JSON.toJavaObject(jsonObject.getJSONObject(OBJECT), QueryAddressResponse.class);
            if (Optional.ofNullable(queryAddressResponse).map(QueryAddressResponse::getAddressBeanList).filter(addr -> !addr.isEmpty()).isPresent()) {
                Optional<Address> address = queryAddressResponse.getAddressBeanList().stream().filter(a -> IS_PRIMARY.equals(a.getIsPrimary())).findFirst();
                if (address.isPresent()) {
                    return address.get();
                }
            }
        }
        return null;
    }

    /**
     * 异常处理
     *
     * @param httpStatus httpStatus
     * @param jsonObject jsonObject
     */
    private void exceptionHandler(HttpStatus httpStatus, JSONObject jsonObject) {
        Integer code = parseInt(jsonObject.getString(RESULT_CODE));
        String message = jsonObject.getString(ERROR_MSG);
        if (httpStatus.is5xxServerError()) {
            throw new ExternalSystemException(code, code, message);
        } else if (httpStatus.is4xxClientError()) {
            throw new BusinessException(code, code, message);
        }
    }

}
