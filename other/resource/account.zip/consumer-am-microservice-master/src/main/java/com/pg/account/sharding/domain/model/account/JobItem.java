package com.pg.account.sharding.domain.model.account;

import com.pg.account.interfaces.command.v2.JobCommand;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;


/**
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobItem implements ValueObject<JobItem> {

    private static final long serialVersionUID = -7810480984214066759L;

    private Relation relation;
    private String name;
    private String category;
    private AddressInfo address;
    private String profession;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public static List<JobItem> toJob(Set<JobCommand> jobs) {
        ArrayList<JobItem> jobList = new ArrayList<>();
        Optional.ofNullable(jobs).ifPresent(job -> job.forEach(j -> {
            JobItem jobItem = new JobItem();
            Relation relation = new Relation();
            relation.setRelationType(RelationType.getRelation(j.getRelationship()));
            relation.setSequence(j.getRelationshipSequence());
            jobItem.setRelation(relation);
            jobItem.setName(j.getUnitName());
            jobItem.setCategory(j.getUnitCategory());
            AddressInfo address = new AddressInfo();
            address.setProvince(j.getProvince());
            address.setCity(j.getCity());
            address.setDistrict(j.getDistrict());
            address.setAddressInfo(j.getUnitAddress());
            jobItem.setAddress(address);
            jobItem.setProfession(j.getProfession());
            jobList.add(jobItem);
        }));
        return jobList;
    }

    @Override
    public boolean sameValueAs(JobItem other) {
        return this.equals(other);
    }

    public void builder(JobItem db) {
        Optional.ofNullable(db).ifPresent(job -> {
            Optional.ofNullable(this.relation).ifPresent(r -> r.builder(db.getRelation()));
            this.category = Optional.ofNullable(this.category).orElse(db.getCategory());
            Optional.ofNullable(this.address).ifPresent(a -> a.builder(db.getAddress()));
            this.name = Optional.ofNullable(this.name).orElse(db.name);
            this.profession = Optional.ofNullable(this.profession).orElse(db.profession);
            this.createTime = Optional.ofNullable(db.createTime).orElse(this.createTime);
            this.updateTime = Optional.ofNullable(this.updateTime).orElse(db.updateTime);
        });
    }
}
