package com.pg.account.infrastructure.common.filter;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.pg.account.infrastructure.common.constants.AccountConstants.POST;

/**
 * Xss攻击过滤
 *
 * @author Jack
 * @date 2018-12-27
 **/
@Slf4j
public class StreamXssFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 暂时为空
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        String contentType = request.getContentType();
        HttpServletResponse resp = (HttpServletResponse) response;
        String method = req.getMethod();
        final String contentType2 = "multipart/form-data";
        if ((contentType != null) && (contentType.startsWith(contentType2)) && (POST.equalsIgnoreCase(method))) {
            log.info("当前请求为文件上传，不进行数据收集和过滤");
        } else {
            XssStreamRequestWrapper requestWrapper = new XssStreamRequestWrapper(req);
            chain.doFilter(requestWrapper, resp);
        }
    }

    @Override
    public void destroy() {
        // 暂时为空
    }
}
