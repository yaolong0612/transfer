package com.pg.account.interfaces.command;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.infrastructure.validator.annotation.TenantExistValid;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

import static com.pg.account.infrastructure.common.utils.StringValidUtil.MOBILE_PATTERN;

/**
 * @author JackSun
 * @date 2017/3/12
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckMobileCommand implements Serializable {
    private static final long serialVersionUID = -1948198579707396767L;

    @ApiModelProperty(value = "租户ID", example = "10002", required = true)
    @NotNull(message = "tenant is not exist")
    @TenantExistValid
    private Long tenantId;
    @ApiModelProperty(value = "手机", example = "18862771234", required = true)
    @NotNull(message = "missing mobile")
    @Pattern(regexp = MOBILE_PATTERN, message = "mobile format error")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String mobile;

}
