package com.pg.account.sharding.application.event.bean;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DependentBean implements Serializable {

    private static final long serialVersionUID = 3806336803840441303L;
    @JSONField(name = "dependent_sqn")
    private String dependentSqn;
    @JSONField(name = "dependent_name")
    private String dependentName;
    @JSONField(name = "dependent_gender")
    private String dependentGender;
    @JSONField(name = "dependent_birthdate")
    private String dependentBirthdate;
    @JSONField(name = "dependent_relationship")
    private String dependentRelationship;

}
