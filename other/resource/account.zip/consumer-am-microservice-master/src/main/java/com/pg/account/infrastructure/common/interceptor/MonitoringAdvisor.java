package com.pg.account.infrastructure.common.interceptor;

import cn.com.pg.paas.monitor.infrastructure.StreamingUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.HashMap;

import static com.pg.account.infrastructure.common.exception.enums.ResultEnum.*;

/**
 * @author JackSun
 */
@Aspect
@Component
@Order(0)
@Slf4j
public class MonitoringAdvisor {
    public static final String REQUEST_TYPE = "request_type";
    public static final String REQUEST_ID = "request_id";
    public static final String ERROR_TIME = "error_time";
    public static final String ERROR_CODE = "error_code";
    public static final String ERROR_MSG = "error_msg";
    public static final String RESPONSE_TIME = "response_time";
    private final StreamingUtil streamingUtil;

    @Autowired
    public MonitoringAdvisor(StreamingUtil streamingUtil) {
        this.streamingUtil = streamingUtil;
    }




    private void sendErrorKpiEventHub(Throwable e, String requestType, int errorCode, String errorMessage) {
        long errorTime = System.currentTimeMillis();
        HashMap<String, Object> object = new HashMap<>(5);
        //建议字段固定
        object.put(REQUEST_TYPE, requestType);
        object.put(REQUEST_ID, RequestIdConverter.getRequestId());
        object.put(ERROR_TIME, errorTime);
        object.put(ERROR_CODE, errorCode);
        object.put(ERROR_MSG, errorMessage);
        streamingUtil.sendKpiEventhub(object);
    }


    @AfterThrowing(pointcut = "execution(public * com.pg.account.sharding.infrastructure.caffeine*.*(..))", throwing = "e")
    public void doAfterThrowByCaffeine(Throwable e) {
        sendErrorKpiEventHub(e, "caffeineException", CAFFEINE_ERROR.getCode(), e.getMessage());
    }

    @AfterThrowing(pointcut = "execution(public * com.pg.account.sharding.infrastructure.servicebus*.*(..))", throwing = "e")
    public void doAfterThrowByServiceBus(Throwable e) {
        sendErrorKpiEventHub(e, "serviceBus Exception", SERVICE_BUS_ERROR.getCode(), e.getMessage());
    }

    @AfterThrowing(pointcut = "execution(public * com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils*.*(..))", throwing = "e")
    public void doAfterThrowByTS(Throwable e) {
        sendErrorKpiEventHub(e, "TableStorage Exception", TABLE_STORAGE_ERROR.getCode(), e.getMessage());
    }
//
//    @Around("execution(public * com.pg.account.sharding.infrastructure.tablestorage.TableStorageUtils*.*(..))")
//    public Object monitoringTS(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "TableStorage");
//    }

//
//    @Around("execution(public * com.pg.account.infrastructure.repositories.*Repository.*(..)) || execution(* com.pg.account.sharding.infrastructure.jpa.*.*.*(..))")
//    public Object monitoringSql(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "SQL");
//    }
//
//
//    @Around("execution(public * com.pg.account.infrastructure.component.redis.RedisUtils*.*(..)) || execution(* com.pg.account.sharding.infrastructure.redis.RedisBaseUtils*.*(..))")
//    public Object monitoringRedis(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "REDIS");
//    }

//    @Around("execution(public * com.pg.account.sharding.infrastructure.datastream.servicebus.MessageOptUpdateServiceBusConsumerService*.*(..))")
//    public Object monitoringSms(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "SMS_SUBSCRIBE");
//    }
//
//    @Around("execution(public * com.pg.account.sharding.infrastructure.datastream.servicebus.SkiiC2BatchUpdateCounterServiceBusConsumerService*.*(..))")
//    public Object monitoringSkiiCounter(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "Skii_Counter_Consumer");
//    }
//
//    @Around("execution(public * com.pg.account.sharding.infrastructure.datastream.servicebus.OlayC2BatchUpdateCounterServiceBusConsumerService*.*(..))")
//    public Object monitoringOlayCounter(ProceedingJoinPoint pjp) throws Throwable {
//        return monitorExecutionTime(pjp, "Olay_Counter_Consumer");
//    }
//
//    private Object monitorExecutionTime(ProceedingJoinPoint pjp, String requestType) throws Throwable {
//        long startTime = System.currentTimeMillis();
//        Object result;
//        boolean isSuccess = true;
//        String errMsg = null;
//        try {
//            result = pjp.proceed();
//        } catch (Throwable throwable) {
//            isSuccess = false;
//            errMsg = throwable.getMessage();
//            throw throwable;
//        } finally {
//            long costTime = System.currentTimeMillis() - startTime;
//            String errorCode = isSuccess ? "0" : "9999";
//            HashMap<String, Object> object = new HashMap<>(5);
//            //建议字段固定
//            object.put(REQUEST_TYPE, requestType);
//            object.put(REQUEST_ID, RequestIdConverter.getRequestId());
//            object.put(RESPONSE_TIME, costTime);
//            object.put(ERROR_CODE, errorCode);
//            object.put(ERROR_MSG, errMsg == null ? "成功" : errMsg);
//            streamingUtil.sendKpiEventhub(object);
//        }
//        return result;
//    }

}
