package com.pg.account.interfaces.command.v2;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * @author LC
 */
@ApiModel
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributeCommand implements Serializable {

    private static final long serialVersionUID = 1956877836308522136L;
    @ApiModelProperty(value = "User attribute number", name = "attrId", example = "837804430", required = true)
    @NotEmpty(message = "missing attrId")
    private String attrId;
    @ApiModelProperty(value = "User attribute content", name = "attrVal", example = "Fill in according to the attribute type, there are JSON, Array JSON, String", required = true)
    @NotEmpty(message = "missing attrVal")
    private String attrVal;
}
