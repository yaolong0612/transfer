package com.pg.account.infrastructure.common.enums;

/**
 * @author JackSun
 * @date 2017/2/9
 */
public enum ModifyPasswordTypeEnum {
    /**
     * 修改类型
     */
    MODIFY("M"),
    RESET("R");

    private final String value;

    ModifyPasswordTypeEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
