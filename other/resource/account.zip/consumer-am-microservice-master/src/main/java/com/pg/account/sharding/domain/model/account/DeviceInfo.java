package com.pg.account.sharding.domain.model.account;

import com.pg.account.interfaces.command.DeviceCommand;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * 设备信息详情类
 * 用于存放设备的详细信息
 *
 * @author dell
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeviceInfo implements ValueObject<DeviceInfo> {

    private static final long serialVersionUID = -4586234554610889520L;
    private String os;
    private String appv;
    private String packageName;
    private String idfa;
    private String imei;
    private String oaid;
    private String mac;
    private String openudid;
    private String androidid;
    private String model;
    private String brand;
    private String adTracked;
    private String deviceId;

    /**
     * 封装设备信息
     *
     * @param deviceCommand deviceCommand
     * @return DeviceInfo
     */
    public static DeviceInfo toDeviceInfo(DeviceCommand deviceCommand) {
        if (Optional.ofNullable(deviceCommand).isPresent()) {
            return new DeviceInfo(deviceCommand.getOs(), deviceCommand.getAppv(),
                    deviceCommand.getPackageName(), deviceCommand.getIdfa(),
                    deviceCommand.getImei(), deviceCommand.getOaid(), deviceCommand.getMac(),
                    deviceCommand.getOpenudid(), deviceCommand.getAndroidid(),
                    deviceCommand.getModel(), deviceCommand.getBrand(), deviceCommand.getAdTracked(), null);
        }
        return null;
    }

    public DeviceInfo(String os,String deviceId){
        this.os = os;
        this.deviceId = deviceId;
    }

    @Override
    public boolean sameValueAs(DeviceInfo other) {
        return this.equals(other);
    }

    /**
     * 将入参的device和数据库的device合并
     *
     * @param db device from db
     */
    public void builder(DeviceInfo db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.os = Optional.ofNullable(this.os).filter(tmp -> !tmp.isEmpty()).orElse(db.getOs());
            this.appv = Optional.ofNullable(this.appv).filter(tmp -> !tmp.isEmpty()).orElse(db.getAppv());
            this.packageName = Optional.ofNullable(this.packageName).filter(tmp -> !tmp.isEmpty()).orElse(db.getPackageName());
            this.idfa = Optional.ofNullable(this.idfa).filter(tmp -> !tmp.isEmpty()).orElse(db.getIdfa());
            this.imei = Optional.ofNullable(this.imei).filter(tmp -> !tmp.isEmpty()).orElse(db.getImei());
            this.oaid = Optional.ofNullable(this.oaid).filter(tmp -> !tmp.isEmpty()).orElse(db.getOaid());
            this.mac = Optional.ofNullable(this.mac).filter(tmp -> !tmp.isEmpty()).orElse(db.getMac());
            this.openudid = Optional.ofNullable(this.openudid).filter(tmp -> !tmp.isEmpty()).orElse(db.getOpenudid());
            this.androidid = Optional.ofNullable(this.androidid).filter(tmp -> !tmp.isEmpty()).orElse(db.getAndroidid());
            this.model = Optional.ofNullable(this.model).filter(tmp -> !tmp.isEmpty()).orElse(db.getModel());
            this.brand = Optional.ofNullable(this.brand).filter(tmp -> !tmp.isEmpty()).orElse(db.getBrand());
            this.adTracked = Optional.ofNullable(this.adTracked).filter(tmp -> !tmp.isEmpty()).orElse(db.getAdTracked());
        }
    }

    public static final class DeviceInfoBuilder {
        private String os;
        private String appv;
        private String packageName;
        private String idfa;
        private String imei;
        private String oaid;
        private String mac;
        private String openudid;
        private String androidid;
        private String model;
        private String brand;
        private String adTracked;

        private DeviceInfoBuilder() {
        }

        public static DeviceInfoBuilder aDeviceInfo() {
            return new DeviceInfoBuilder();
        }

        public DeviceInfoBuilder os(String os) {
            this.os = os;
            return this;
        }

        public DeviceInfoBuilder appv(String appv) {
            this.appv = appv;
            return this;
        }

        public DeviceInfoBuilder packageName(String packageName) {
            this.packageName = packageName;
            return this;
        }

        public DeviceInfoBuilder idfa(String idfa) {
            this.idfa = idfa;
            return this;
        }

        public DeviceInfoBuilder imei(String imei) {
            this.imei = imei;
            return this;
        }

        public DeviceInfoBuilder oaid(String oaid) {
            this.oaid = oaid;
            return this;
        }

        public DeviceInfoBuilder mac(String mac) {
            this.mac = mac;
            return this;
        }

        public DeviceInfoBuilder openudid(String openudid) {
            this.openudid = openudid;
            return this;
        }

        public DeviceInfoBuilder androidid(String androidid) {
            this.androidid = androidid;
            return this;
        }

        public DeviceInfoBuilder model(String model) {
            this.model = model;
            return this;
        }

        public DeviceInfoBuilder brand(String brand) {
            this.brand = brand;
            return this;
        }

        public DeviceInfoBuilder adTracked(String adTracked) {
            this.adTracked = adTracked;
            return this;
        }

        public DeviceInfo build() {
            DeviceInfo deviceInfo = new DeviceInfo();
            deviceInfo.setOs(os);
            deviceInfo.setAppv(appv);
            deviceInfo.setPackageName(packageName);
            deviceInfo.setIdfa(idfa);
            deviceInfo.setImei(imei);
            deviceInfo.setOaid(oaid);
            deviceInfo.setMac(mac);
            deviceInfo.setOpenudid(openudid);
            deviceInfo.setAndroidid(androidid);
            deviceInfo.setModel(model);
            deviceInfo.setBrand(brand);
            deviceInfo.setAdTracked(adTracked);
            return deviceInfo;
        }

    }
}
