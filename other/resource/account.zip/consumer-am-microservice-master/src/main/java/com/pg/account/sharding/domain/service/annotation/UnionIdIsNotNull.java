package com.pg.account.sharding.domain.service.annotation;

import com.pg.account.sharding.interfaces.command.SignUpCommand;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static com.pg.account.sharding.domain.service.StringValidator.unionIdIsNecessary;
import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author lfx
 * @date 2022/2/9 14:45
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = UnionIdIsNotNull.UnionIdValidator.class)
public @interface UnionIdIsNotNull {

    String message() default "unionId must not be null";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class UnionIdValidator implements ConstraintValidator<UnionIdIsNotNull, @Valid SignUpCommand> {

        @Override
        public boolean isValid(@Valid SignUpCommand signUpCommand, ConstraintValidatorContext constraintValidatorContext) {
            return unionIdIsNecessary(signUpCommand.getTenant(), signUpCommand.getChannel(), signUpCommand.getMobile(), signUpCommand.getBindId(), signUpCommand.getUnionId());
        }
    }
}
