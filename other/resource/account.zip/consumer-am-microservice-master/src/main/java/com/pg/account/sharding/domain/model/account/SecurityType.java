package com.pg.account.sharding.domain.model.account;

/**
 * 安全类型枚举类
 *
 * @author Jack
 * @date 2021/5/27 13:59
 */
public enum SecurityType {
    /**
     * 密码
     */
    PASSWORD,
}
