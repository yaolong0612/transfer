package com.pg.account.interfaces.dto;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author JackSun
 */
@ApiModel(value = "QueryAddressesDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class QueryAddressesDTO implements Serializable {
    private static final long serialVersionUID = 7220125406245618209L;

    @ApiModelProperty(value = "租户ID", example = "10004")
    private Long tenantId;
    @ApiModelProperty(value = "会员ID", example = "1234")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String memberId;
    @ApiModelProperty(value = "地址信息")
    private List<AddressDTO> addressBeanList;

}
