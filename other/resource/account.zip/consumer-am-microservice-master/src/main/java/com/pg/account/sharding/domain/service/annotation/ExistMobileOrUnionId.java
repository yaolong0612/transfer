package com.pg.account.sharding.domain.service.annotation;


import com.pg.account.sharding.infrastructure.caffeine.LocalCacheConfigUtils;
import com.pg.account.sharding.interfaces.command.SignUpCommand;
import org.apache.commons.lang3.StringUtils;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Optional;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author guye
 * @version 1.0
 * @date 2022/1/19 11:02
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = ExistMobileOrUnionId.MobileOrUnionIdValidator.class)
public @interface ExistMobileOrUnionId {
    String message() default "最少mobile或者unionId";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class MobileOrUnionIdValidator implements ConstraintValidator<ExistMobileOrUnionId, @Valid SignUpCommand> {

        @Override
        public boolean isValid(@Valid SignUpCommand signUpCommand, ConstraintValidatorContext constraintValidatorContext) {
            String unionIdType = LocalCacheConfigUtils.getChannelUnionIdType(signUpCommand.getTenant(), signUpCommand.getChannel());
            if (StringUtils.isBlank(unionIdType)) {
                return Optional.ofNullable(signUpCommand.getMobile()).isPresent();
            } else {
                return Optional.ofNullable(signUpCommand.getUnionId()).isPresent() || Optional.ofNullable(signUpCommand.getMobile()).isPresent();
            }
        }
    }
}
