package com.pg.account.interfaces.command.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.pg.account.interfaces.command.DeviceCommand;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 注册绑定请求参数类
 *
 * @author Jack Sun
 * @date 2019-11-25 17:32
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SocialAccountBindCommand implements Serializable {

    private static final long serialVersionUID = -9066378285980352735L;

    @ApiModelProperty(value = "AM openId", name = "openId", example = "31231244657886743", required = true)
    @NotBlank(message = "missing open Id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;
    @ApiModelProperty(value = "Third party social binding ID", name = "bindId", example = "testBindID1234567890", required = true)
    @NotBlank(message = "missing binding ID")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @ApiModelProperty(value = "The third party's social platform account unique identifier is used to associate the social binding ID", name = "unionId")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String unionId;
    @ApiModelProperty(value = "Device Information", name = "device")
    private DeviceCommand device;
}
