package com.pg.account.sharding.application.event.bean.servicebus;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributeBean implements Serializable {

    private static final long serialVersionUID = -6565754055898476498L;
    @JSONField(ordinal = 1)
    private String attrId;
    @JSONField(ordinal = 2)
    private String attrValue;

}
