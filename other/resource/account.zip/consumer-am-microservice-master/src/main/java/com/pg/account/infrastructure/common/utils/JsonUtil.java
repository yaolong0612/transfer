package com.pg.account.infrastructure.common.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * json工具类
 *
 * @author xusheng
 * @date 2020/10/14 <br>
 */
@Slf4j
public class JsonUtil {

    private JsonUtil() {

    }

    /**
     * jsonObjectToString
     *
     * @param json json
     * @return string 字符串
     */
    public static String jsonObjectToString(JSONObject json) {
        StringBuilder sb = new StringBuilder();
        Set<String> keySet = json.keySet();
        List<String> keys = new ArrayList<>(keySet);
        Collections.sort(keys);
        for (String key : keys) {
            Object ob = json.get(key);
            if (ob instanceof JSONObject) {
                JSONObject b = json.getJSONObject(key);
                sb.append('&').append(key).append("={").append(jsonObjectToString(b)).append('}');
            } else if (ob instanceof JSONArray) {
                JSONArray c = json.getJSONArray(key);
                sb.append('&').append(key).append("=[").append(jsonArrayToString(c)).append(']');
            } else {
                sb.append('&').append(key).append('=').append(json.getString(key));
            }
        }
        return sb.substring(1);
    }

    /**
     * jsonArrayToString
     *
     * @param jsonArray jsonArray
     * @return String 字符串
     */
    private static String jsonArrayToString(JSONArray jsonArray) {
        List<String> list = new ArrayList<>();
        for (Object element : jsonArray) {
            String str;
            if (element instanceof JSONObject) {
                str = jsonObjectToString((JSONObject) element);
            } else {
                str = element.toString();
            }
            list.add(str);
        }
        if (!list.isEmpty()) {
            Collections.sort(list);
            StringBuilder sb = new StringBuilder();
            for (String s : list) {
                sb.append('{').append(s).append("},");
            }
            String ss = sb.toString();
            return ss.substring(0, ss.length() - 1);
        }
        return null;
    }
}
