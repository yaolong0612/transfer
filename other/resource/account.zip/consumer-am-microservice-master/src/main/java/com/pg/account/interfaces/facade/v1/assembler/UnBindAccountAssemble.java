package com.pg.account.interfaces.facade.v1.assembler;

import com.pg.account.interfaces.command.UnBindingCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.domain.model.account.Channel;
import com.pg.account.sharding.domain.model.account.IdentityId;
import com.pg.account.sharding.domain.model.account.Registration;
import com.pg.account.sharding.domain.model.socialaccount.SocialAccountItem;
import com.pg.account.sharding.infrastructure.jpa.config.ChannelDao;
import com.pg.account.sharding.infrastructure.jpa.config.ShardChannel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 组装解绑数据
 *
 * @author xusheng
 * @createDate 2021/6/8 <br>
 */
@Component("UnBindAccountAssembleV1")
public class UnBindAccountAssemble {

    private final ChannelDao channelDao;

    @Autowired
    public UnBindAccountAssemble(ChannelDao channelDao) {
        this.channelDao = channelDao;
    }

    /**
     * 封装注册绑定参数
     *
     * @param unBindingCommand bindingCommand
     * @return com.pg.account.sharding.domain.model.socialaccount.ShardSocialAccount
     * @author xusheng
     * @date 2021/6/8 18:17
     */
    public Account toAccount(UnBindingCommand unBindingCommand) {
        ShardChannel shardChannel = channelDao.findByTenantIdAndChannelId(unBindingCommand.getTenantId().toString(), unBindingCommand.getChannelId().toString());
        Channel channel = new Channel();
        Optional.ofNullable(shardChannel).ifPresent(channel::build);
        IdentityId identityId = new IdentityId(unBindingCommand.getTenantId().toString(), unBindingCommand.getMemberId());
        Registration registration = new Registration();
        registration.specialChannel(channel);
        List<SocialAccountItem> socialAccountList = new ArrayList<>();
        SocialAccountItem socialAccountItem = new SocialAccountItem();
        socialAccountItem.build(channel, null, unBindingCommand.getBindId(), unBindingCommand.getUnionId());
        socialAccountList.add(socialAccountItem);
        return new Account(identityId, null, registration, null, null, null, null);
    }

}
