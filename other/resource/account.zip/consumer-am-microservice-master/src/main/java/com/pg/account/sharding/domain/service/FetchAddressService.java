package com.pg.account.sharding.domain.service;

import com.pg.account.sharding.infrastructure.client.address.Address;

/**
 * @author Jack
 * @description
 * @date 2021/6/2 22:09
 * @modified Jack
 */
public interface FetchAddressService {

    /**
     * 根据会员ID查询地址信息
     *
     * @param tenantId  tenantId
     * @param accountId accountId
     * @return Address
     */
    Address fetchByTenantIdAndAccountId(String tenantId, String accountId);

    /**
     * 根据会员ID查询地址信息
     *
     * @param accountId accountId
     * @param tenant  tenant
     * @return Address
     */
    Address fetchByAccountIdAndTenant(String accountId, String tenant);
}
