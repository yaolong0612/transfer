package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.account.Account;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * @author yj
 * @date 2021-6-9
 */
@Getter
public class FirstModifyProfileEvent extends ApplicationEvent {
    private static final long serialVersionUID = -3984260418332518271L;
    private Account account;
    private String attrId;

    public FirstModifyProfileEvent(Object source) {
        super(source);
    }

    public FirstModifyProfileEvent(Object source, Account account, String attrId) {
        super(source);
        this.account = account;
        this.attrId = attrId;
    }
}
