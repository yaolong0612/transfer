package com.pg.account.interfaces.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@ApiModel(value = "TermsDTO_V1")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TermsDTO implements Serializable {
    private static final long serialVersionUID = 6574698271359025023L;
    @ApiModelProperty(value = "条款版本")
    private String code;
    @ApiModelProperty(value = "条款内容")
    private String content;

}
