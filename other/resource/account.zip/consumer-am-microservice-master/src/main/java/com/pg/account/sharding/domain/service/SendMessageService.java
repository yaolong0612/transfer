package com.pg.account.sharding.domain.service;

/**
 * @author Jack
 * @description
 * @date 2021/6/2 23:10
 * @modified Jack
 */
public interface SendMessageService {


    /**
     * 发送入会短信
     *
     * @param tenantId  tenantId
     * @param channelId channelId
     * @param accountId accountId
     * @param mobile    mobile
     * @param fullName  fullName
     */
    void sendMembershipSms(String tenantId, String channelId, String accountId, String mobile, String fullName);


    /**
     * 登录短信校验
     *
     * @param tenantId     tenantId
     * @param mobile       mobile
     * @param templateCode templateCode
     * @param code         code
     * @return 短信发送状态，成功true，失败false
     */
    boolean logonSmsVerifyCode(String tenantId, String mobile, String templateCode, String code);

}
