package com.pg.account.sharding.domain.service;

import com.pg.account.infrastructure.common.exception.BusinessException;
import com.pg.account.infrastructure.common.exception.enums.ResultEnum;
import com.pg.account.infrastructure.common.utils.PasswordUtils;
import com.pg.account.infrastructure.common.utils.StringValidUtil;
import com.pg.account.interfaces.command.ModifyPasswordCommand;
import com.pg.account.sharding.domain.model.account.Account;
import com.pg.account.sharding.infrastructure.jpa.account.AccountInfoDao;
import com.pg.account.sharding.infrastructure.jpa.account.ShardAccountInfo;
import com.pg.account.sharding.infrastructure.jpa.mapping.EmailMapping;
import com.pg.account.sharding.infrastructure.jpa.mapping.FetchMappingService;
import com.pg.account.sharding.infrastructure.jpa.mapping.MobileMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.pg.account.infrastructure.common.enums.ModifyPasswordTypeEnum.MODIFY;
import static com.pg.account.infrastructure.common.utils.StringValidUtil.*;

/**
 * 修改密码服务
 *
 * @author xusheng
 * @createDate 2021/6/15 <br>
 */
@Service
public class ModifyPasswordService {

    private final FetchMappingService fetchMappingService;
    private final AccountInfoDao accountInfoDao;

    @Autowired
    public ModifyPasswordService(FetchMappingService fetchMappingService,
                                 AccountInfoDao accountInfoDao) {
        this.fetchMappingService = fetchMappingService;
        this.accountInfoDao = accountInfoDao;
    }

    /**
     * 根据修改密码类型来修改密码
     *
     * @param modifyPasswordCommand modifyPasswordCommand
     * @author xusheng
     * @date 2021/6/15 10:40
     */
    public Account modifyPassword(ModifyPasswordCommand modifyPasswordCommand) {
        String accountId = null;
        if (StringValidUtil.isEmail(modifyPasswordCommand.getUsername())) {
            EmailMapping emailMapping = Optional.ofNullable(fetchMappingService.fetchEmailByTenantIdAndEmail(modifyPasswordCommand.getTenantId().toString(), modifyPasswordCommand.getUsername()))
                    .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                            ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                            ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
            accountId = emailMapping.getAccountId();
        } else if (isMobile(modifyPasswordCommand.getUsername()) && isMobileLength(modifyPasswordCommand.getUsername())) {
            MobileMapping mobileMapping = Optional.ofNullable(fetchMappingService.fetchMobileByTenantIdAndMobile(modifyPasswordCommand.getTenantId().toString(), modifyPasswordCommand.getUsername()))
                    .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                            ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                            ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
            accountId = mobileMapping.getAccountId();
        } else if (isNumber(modifyPasswordCommand.getUsername())) {
            accountId = modifyPasswordCommand.getUsername();
        }
        ShardAccountInfo shardAccountInfo = Optional.ofNullable(accountInfoDao.findByIdentityId_TenantIdAndIdentityId_AccountId(modifyPasswordCommand.getTenantId().toString(), accountId))
                .orElseThrow(() -> new BusinessException(ResultEnum.ACCOUNT_NOT_EXIST.getCode(),
                        ResultEnum.ACCOUNT_NOT_EXIST.getV2Code(),
                        ResultEnum.ACCOUNT_NOT_EXIST.getMessage()));
        if (modifyPasswordCommand.getType().equals(MODIFY.getValue()) &&
                !shardAccountInfo.getSecurity().getEncryptedCode().equals(PasswordUtils.encrypt(modifyPasswordCommand.getOldPassword().concat(shardAccountInfo.getSecurity().getSalt())))) {
            throw new BusinessException(ResultEnum.INCORRECT_PASSWORD.getCode(), ResultEnum.INCORRECT_PASSWORD.getV2Code(), ResultEnum.INCORRECT_PASSWORD.getMessage());
        }
        shardAccountInfo.getSecurity().encryptPassword(modifyPasswordCommand.getNewPassword());
        shardAccountInfo.addUpdatedTime();
        accountInfoDao.save(shardAccountInfo);
        Account account = new Account();
        account.setIdentityId(shardAccountInfo.getIdentityId());
        account.setSecurity(shardAccountInfo.getSecurity());
        return account;
    }
}
