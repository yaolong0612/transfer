//package com.pg.account.infrastructure.common.interceptor;
//
//import cn.com.pg.paas.monitor.domain.enums.SendType;
//import cn.com.pg.paas.monitor.infrastructure.StreamingUtil;
//import com.alibaba.fastjson.JSON;
//import lombok.extern.slf4j.Slf4j;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.annotation.Order;
//import org.springframework.stereotype.Component;
//
//import java.util.HashMap;
//
///**
// * @author Jack
// * @version 1
// * @description 外部系统监控
// * @date 2021-01-15 13:27
// * @modified Jack
// */
//@Aspect
//@Component
//@Slf4j
//@Order(1)
//public class ExternalSystemMonitoringAdvisor {
//
//
//    public static final String API_NAME = "apiName";
//    public static final String MONITOR_TYPE = "monitorType";
//    public static final String RESPONSE_TIME = "response_time";
//    public static final String SEND_TYPE = "sendType";
//    public static final String STATUS = "status";
//    public static final String MESSAGE = "message";
//    public static final String EXTERNAL_SYSTEM_MONITORING = "ExternalSystemMonitoring";
//    private final StreamingUtil streamingUtil;
//
//    @Autowired
//    public ExternalSystemMonitoringAdvisor(StreamingUtil streamingUtil) {
//        this.streamingUtil = streamingUtil;
//    }
//
//    @Pointcut("execution(* com.pg.account.domain.service.*.*(..)) || execution(* com.pg.account.sharding.domain.service.*.*(..))")
//    public void executionPointcut() {
//        // Do nothing
//    }
//
//    /**
//     * restful接口方法拦截,校验JavaBean
//     *
//     * @param joinPoint joinPoint
//     * @return Result
//     * @throws Throwable Throwable
//     */
//    @Around("executionPointcut()")
//    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
//        long startTime = System.currentTimeMillis();
//        Object result;
//        boolean isSuccess = true;
//        String errMsg = null;
//        try {
//            result = joinPoint.proceed();
//        } catch (Throwable throwable) {
//            isSuccess = false;
//            errMsg = throwable.getMessage();
//            throw throwable;
//        } finally {
//            long costTime = System.currentTimeMillis() - startTime;
//            String className = joinPoint.getSignature().getDeclaringType().getName();
//            String apiName = className.substring(className.lastIndexOf('.') + 1).concat("-")
//                    .concat(joinPoint.getSignature().getName());
//            try {
//                HashMap<String, Object> object = new HashMap<>(6);
//                object.put(API_NAME, apiName);
//                object.put(MONITOR_TYPE, EXTERNAL_SYSTEM_MONITORING);
//                object.put(RESPONSE_TIME, costTime);
//                object.put(SEND_TYPE, SendType.STREAM_SDK);
//                object.put(STATUS, isSuccess);
//                object.put(MESSAGE, errMsg);
//                streamingUtil.sendKpiEventhub(object);
//            } catch (Exception ex) {
//                log.error(ex.getMessage());
//            }
//        }
//        return result;
//    }
//}
