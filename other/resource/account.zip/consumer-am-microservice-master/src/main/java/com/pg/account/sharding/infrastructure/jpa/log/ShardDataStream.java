package com.pg.account.sharding.infrastructure.jpa.log;

import com.pg.account.sharding.infrastructure.jpa.shared.JpaConverterLocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.Validate;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author JackSun
 * @date 2018-7-10
 */
@Entity
@DynamicInsert
@DynamicUpdate
@Table(name = "SHARD_DATA_STREAM")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShardDataStream implements Serializable {
    private static final long serialVersionUID = 88523495999984873L;
    @Convert(converter = JpaConverterLocalDateTime.class)
    protected LocalDateTime updatedTime;
    @EmbeddedId
    private LogId logId;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "account_id")
    private String accountId;
    private String eventLabel;
    private String eventTypeId;
    private String eventType;
    private String eventChannel;
    private String eventHeaders;
    private String eventMessage;
    private String errorMessage;
    private String status;
    private String retryCount;

    public ShardDataStream(LogId logId, String tenantId, String accountId, String eventLabel, String eventTypeId, String eventType, String eventChannel, String eventHeaders, String eventMessage, String errorMessage, String status, String retryCount) {
        Validate.notNull(tenantId, "tenantId is null");
        Validate.notNull(accountId, "accountId is null");
        this.logId = logId;
        this.tenantId = tenantId;
        this.accountId = accountId;
        this.eventLabel = eventLabel;
        this.eventTypeId = eventTypeId;
        this.eventType = eventType;
        this.eventChannel = eventChannel;
        this.eventHeaders = eventHeaders;
        this.eventMessage = eventMessage;
        this.errorMessage = errorMessage;
        this.status = status;
        this.retryCount = retryCount;
        this.addCreateTime();
    }

    public void addCreateTime() {
        this.updatedTime = LocalDateTime.now();
    }


    public void changeCreateTime(LocalDateTime createTime) {
        this.logId.createdTime = createTime;
    }

    public void addUpdatedTime() {
        this.updatedTime = LocalDateTime.now();
    }


}
