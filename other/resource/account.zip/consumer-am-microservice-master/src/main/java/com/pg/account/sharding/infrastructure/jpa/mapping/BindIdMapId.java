package com.pg.account.sharding.infrastructure.jpa.mapping;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

/**
 * @author lfx
 * @date 2021/6/9 11:24
 */
@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BindIdMapId implements Serializable {
    private static final long serialVersionUID = -3894874403916577788L;
    @Column(name = "tenant_id")
    private String tenantId;
    @Column(name = "bind_id")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String bindId;
    @Column(name = "channel_id")
    private String channelId;
}
