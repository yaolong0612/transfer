package com.pg.account.infrastructure.component.client.message;

import com.alibaba.fastjson.JSONObject;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * MessageFeignClient
 *
 * @author Jack Sun
 * @date 2019-6-25 13:51
 */
@FeignClient(name = "cms-message-gateway")
public interface MessageServiceClient {

    /**
     * 发送短信
     *
     * @param sendMessageRequest 发送的短信信息
     * @return 短信发送状态
     */
    @PostMapping(value = "/api/message", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> sendMessage(@RequestBody SendMessageRequest sendMessageRequest);


    /**
     * 校验短信验证码
     *
     * @param verifyCodeRequest 短信校验信息
     * @return JSONObject
     */
    @PostMapping(value = "/api/message/code/verification", consumes = "application/json", produces = "application/json")
    ResponseEntity<JSONObject> verifyCode(@RequestBody VerifyCodeRequest verifyCodeRequest);
}
