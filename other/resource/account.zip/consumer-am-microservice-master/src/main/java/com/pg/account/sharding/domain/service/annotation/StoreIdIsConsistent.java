package com.pg.account.sharding.domain.service.annotation;


import com.pg.account.sharding.infrastructure.caffeine.CacheLocalConfigUtils;
import com.pg.account.sharding.infrastructure.redis.RedisConfigUtils;
import com.pg.account.sharding.interfaces.command.SignUpCommand;
import org.apache.commons.lang3.StringUtils;

import javax.validation.*;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @return:
 * @Author: zhubin
 * @Date: 2022/11/14 16:26
 */
@Documented
@Retention(RUNTIME)
@Target({FIELD, METHOD, PARAMETER, TYPE})
@Constraint(validatedBy = StoreIdIsConsistent.RegStoreValidator.class)
public @interface StoreIdIsConsistent {
    String message() default "storid 匹配不成功";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
    class RegStoreValidator implements ConstraintValidator<StoreIdIsConsistent, @Valid SignUpCommand>{

        @Override
        public boolean isValid(@Valid SignUpCommand signUpCommand, ConstraintValidatorContext constraintValidatorContext) {
            //redis 存在key
            if(RedisConfigUtils.isExist(signUpCommand.getTenant(),signUpCommand.getChannel())){

                //redis 校验
                String value = CacheLocalConfigUtils.getPublicAccount(signUpCommand.getTenant(),signUpCommand.getChannel());
                if(StringUtils.isNotBlank(value)){
                     return value.equals(signUpCommand.getRegStore());
                 }else{
                    if(StringUtils.isNotBlank(signUpCommand.getRegStore())){
                        return false;
                    }
                    return true;
                }
            }else {
                return false;
            }

        }
    }
}
