package com.pg.account.sharding.domain.model.subscription;

import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.Data;

import java.util.Optional;

/**
 * @author dell
 */
@Data
public class Term implements ValueObject<Term> {
    private static final long serialVersionUID = -4575479563237301142L;

    private String termId;
    private String termVersion;

    public Term() {
    }

    public Term(String termId, String termVersion) {
        this.termId = termId;
        this.termVersion = termVersion;
    }

    @Override
    public boolean sameValueAs(Term other) {
        return this.equals(other);
    }

    public void builder(Term db) {
        if (Optional.ofNullable(db).isPresent()) {
            this.termId = Optional.ofNullable(this.termId).orElse(db.getTermId());
            this.termVersion = Optional.ofNullable(this.termVersion).orElse(db.getTermVersion());
        }
    }
}
