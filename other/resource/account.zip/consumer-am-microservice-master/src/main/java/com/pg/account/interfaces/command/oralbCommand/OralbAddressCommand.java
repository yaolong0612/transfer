package com.pg.account.interfaces.command.oralbCommand;


import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 * @author YJ
 * @date 2021/9/2
 */
@ApiModel(value = "OralbAddressCommand", description = "V1 interface AddressCommand")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OralbAddressCommand implements Serializable {
    private static final long serialVersionUID = 354665685216441801L;

    @ApiModelProperty(value = "地址UUID识别编码", example = "12345556")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String addressCode;
    @ApiModelProperty(value = "是否是主地址（主：1,备：0），主地址只能存在一个，默认是主地址", example = "1", required = true)
    private String isPrimary;
    @ApiModelProperty(value = "地址类型:1、HOME 不填默认是1（HOME）", example = "1", required = true)
    private String addressType;
    @ApiModelProperty(value = "姓名", example = "孙悟空")
    @Desensitized(value = DesensitizedEnum.FULL_NAME)
    private String fullName;
    @ApiModelProperty(value = "手机", example = "188888888")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String cellphone;
    @ApiModelProperty(value = "电话", example = "0510-83195186")
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String phone;
    @ApiModelProperty(value = "省", example = "江苏省")
    private String province;
    @ApiModelProperty(value = "市", example = "无锡市")
    private String city;
    @ApiModelProperty(value = "区", example = "滨湖区")
    private String district;
    @ApiModelProperty(value = "地址详情", example = "蠡湖大道1008号")
    @Desensitized(value = DesensitizedEnum.ADDRESS)
    private String address;
    @ApiModelProperty(value = "邮编", example = "215600")
    private String postcode;
}
