package com.pg.account.infrastructure.common.filter;

import com.pg.account.infrastructure.common.interceptor.RequestIdConverter;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

/**
 * @author Jack Sun
 * @date 2019-12-6 23:13
 */
@Slf4j
@Getter
@Setter
public class AccessLogFilter extends OncePerRequestFilter {

    public static final String QUERY_STRING = "queryString";
    public static final String REQUEST_BODY = "requestBody";
    public static final String REQUEST_ID = "requestId";
    public static final String HTTP_STATUS = "httpStatus";
    public static final String REQUEST_URI = "requestUri";
    public static final String METHOD = "method";
    public static final String CONTENT_TYPE = "contentType";
    public static final String REMOTE_ADDR = "remoteAddr";
    public static final String REQUEST_QUERY_STRING = "requestQueryString";
    public static final String RESPONSE_DATA = "responseData";
    public static final String TENANT_ID = "tenantId";
    public static final String START_TIME = "startTime";
    public static final String END_TIME = "endTime";
    public static final String START_STR = "{";
    public static final String VERSION_V2 = "v2";
    public static final String LIVENESS = "/liveness";
    public static final String READINESS = "/readiness";
    public static final String PROMETHEUS = "/prometheus";
    private Map<String, Object> dimension;

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        //转换成代理类
        ContentCachingRequestWrapper wrappedRequest = new ContentCachingRequestWrapper(httpServletRequest);
        ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(httpServletResponse);
        if (((HttpServletResponse) wrappedResponse).getCharacterEncoding() == null) {
            ((HttpServletResponse) wrappedResponse).setCharacterEncoding("UTF-8");
        }
        //得到请求的URL地址中附带的参数
//        String queryString = wrappedRequest.getQueryString();
        //得到请求内容类型
//        String contentType = wrappedRequest.getContentType();
        //得到请求的资源
        String requestUri = wrappedRequest.getRequestURI();
        //得到来访者的IP地址
//        String remoteAddr = wrappedRequest.getRemoteAddr();
        //得到请求的方法
//        String method = wrappedRequest.getMethod();
        //得到请求Body参数
//        String requestBody = IOUtils.toString(wrappedRequest.getBody(), httpServletRequest.getCharacterEncoding());
//        wrappedRequest.setAttribute(QUERY_STRING, queryString);
//        wrappedRequest.setAttribute(REQUEST_BODY, requestBody);
//        wrappedRequest.setAttribute(CONTENT_TYPE, contentType);
        wrappedRequest.setAttribute(REQUEST_URI, requestUri);
//        wrappedRequest.setAttribute(REMOTE_ADDR, remoteAddr);
//        wrappedRequest.setAttribute(METHOD, method);
        filterChain.doFilter(wrappedRequest, wrappedResponse);
//        int httpStatus = httpServletResponse.getStatus();
//        String responseBody = IOUtils.toString(wrappedResponse.getContentAsByteArray(), wrappedResponse.getCharacterEncoding());
//        this.monitorAccessLog(requestUri, method, contentType, remoteAddr, queryString, requestBody, httpStatus, responseBody);
        wrappedResponse.copyBodyToResponse();
    }

    @Override
    public void destroy() {
        RequestIdConverter.remove();
    }

//    @SneakyThrows
//    @Override
//    public ApiLogExtend getCustomMetric(String returnArgs, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
//        //得到请求内容类型
//        Object contentType = httpServletRequest.getAttribute(CONTENT_TYPE);
//        //得到请求的资源
//        Object requestUri = httpServletRequest.getAttribute(REQUEST_URI);
//        if (requestUri.equals(LIVENESS) || requestUri.equals(READINESS) || requestUri.equals(PROMETHEUS)) {
//            return getApiLogExtend(returnArgs, httpServletRequest);
//        }
//        //得到来访者的IP地址
//        Object remoteAddr = httpServletRequest.getAttribute(REMOTE_ADDR);
//        //得到请求的方法
//        Object method = httpServletRequest.getAttribute(METHOD);
//        //得到请求的URL地址中附带的参数
//        Object queryString = httpServletRequest.getAttribute(QUERY_STRING);
//        //得到请求Body参数
//        Object requestBody = httpServletRequest.getAttribute(REQUEST_BODY);
//        //response的值重新塞进去
//        int httpStatus = httpServletResponse.getStatus();
//        this.monitorAccessLog(requestUri, method, contentType, remoteAddr, queryString, requestBody, httpStatus, returnArgs);
//        return getApiLogExtend(returnArgs, httpServletRequest);
//    }
//
//    private ApiLogExtend getApiLogExtend(String returnArgs, HttpServletRequest httpServletRequest) {
//        ApiLogExtend apiLogExtend = new ApiLogExtend();
//        String requestUri = httpServletRequest.getAttribute(REQUEST_URI).toString();
//        String[] split = requestUri.split("/");
//        StringBuilder builder = new StringBuilder();
//        Pattern pattern = compile("^-?\\d+(\\.\\d+)?$");
//
//        if (VERSION_V2.equals(split[1])) {
//            for (int i = 2; i < split.length; i++) {
//                Matcher isNum = pattern.matcher(split[i]);
//                if (isNum.matches()) {
//                    split[i] = "*";
//                }
//            }
//        }
//        for (String s : split) {
//            builder.append(s).append("/");
//        }
//        String uri = builder.deleteCharAt(builder.length() - 1).toString();
//        HashMap<String, Object> requestIdMap = new HashMap<>(10);
//        if (null != dimension) {
//            requestIdMap = (HashMap<String, Object>) dimension;
//            this.setDimension(null);
//        }
//        requestIdMap.put(REQUEST_ID, httpServletRequest.getAttribute(REQUEST_ID));
//        requestIdMap.put(START_TIME, httpServletRequest.getAttribute(START_TIME));
//        requestIdMap.put(REQUEST_URI, uri);
//        long endTime = System.currentTimeMillis();
//        requestIdMap.put(END_TIME, endTime);
//        apiLogExtend.setDimension(requestIdMap);
//        if (!returnArgs.startsWith(START_STR)) {
//            return apiLogExtend;
//        }
//        JSONObject returnJson = JSON.parseObject(returnArgs);
//        final String resultKey = RESULT_CODE;
//        final String resultCode = CODE;
//        if (returnJson.containsKey(resultKey)) {
//            String result = returnJson.getString(resultKey);
//            //获取result字段，判断请求是否成功
//            if (StringUtils.isNotBlank(result)) {
//                apiLogExtend.setError_code(Integer.parseInt(result));
//            }
//        } else if (returnJson.containsKey(resultCode)) {
//            Integer result = returnJson.getInteger(resultCode);
//            //获取result字段，判断请求是否成功
//            if (null != result) {
//                apiLogExtend.setError_code(result);
//            }
//        }
//        return apiLogExtend;
//    }
//
//    /**
//     * 访问日志打印
//     *
//     * @param requestUri         请求路径
//     * @param method             请求方法
//     * @param contentType        文本类型
//     * @param remoteAddr         请求地址
//     * @param requestQueryString 查询参
//     * @param requestBody        请求正文主体
//     * @param responseData       响应数据
//     */
//    private void monitorAccessLog(Object requestUri, Object method, Object contentType, Object remoteAddr, Object requestQueryString, Object requestBody, int httpStatus, String responseData) {
//        //记录监控API日志
//        HashMap<String, Object> accessLog = new HashMap<>(9);
//        accessLog.put(REQUEST_ID, RequestIdConverter.getRequestId());
//        accessLog.put(REQUEST_URI, requestUri);
//        accessLog.put(HTTP_STATUS, httpStatus);
//        accessLog.put(METHOD, method);
//        accessLog.put(CONTENT_TYPE, contentType);
//        accessLog.put(REMOTE_ADDR, remoteAddr);
//        accessLog.put(REQUEST_QUERY_STRING, requestQueryString);
//        accessLog.put(REQUEST_BODY, requestBody);
//        accessLog.put(RESPONSE_DATA, responseData);
//        dimension = accessLog;
//        JSONObject jsonObj = new JSONObject(dimension);
//        log.info("AccessLog:{}", jsonObj.toJSONString());
//    }
}
