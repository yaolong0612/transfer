package com.pg.account.sharding.domain.model.account;

import com.pg.account.interfaces.command.v2.EducationCommand;
import com.pg.account.sharding.domain.model.shared.ValueObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * 学校信息类
 *
 * @author sunli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EducationItem implements ValueObject<EducationItem> {
    private static final long serialVersionUID = 3866939458193068189L;
    private Relation relation;
    private String name;
    private String category;
    private AddressInfo address;
    private String college;
    private String major;
    private String grade;
    private String className;
    private String degree;
    private String admissionTime;
    private String graduationTime;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public static List<EducationItem> toEducation(Set<EducationCommand> educations) {
        ArrayList<EducationItem> educationList = new ArrayList<>();
        Optional.ofNullable(educations).ifPresent(edu -> edu.forEach(e -> {
            EducationItem educationItem = new EducationItem();
            Relation relation = new Relation();
            relation.setRelationType(RelationType.getRelation(e.getRelationship()));
            relation.setSequence(e.getRelationshipSequence());
            educationItem.setRelation(relation);
            educationItem.setName(e.getSchoolName());
            educationItem.setCategory(e.getSchoolCategory());
            AddressInfo address = new AddressInfo();
            address.setProvince(e.getProvince());
            address.setCity(e.getCity());
            address.setDistrict(e.getDistrict());
            address.setAddressInfo(e.getSchoolAddress());
            educationItem.setAddress(address);
            educationItem.setMajor(e.getMajor());
            educationItem.setGrade(e.getGrade());
            educationItem.setClassName(e.getClassName());
            educationItem.setDegree(e.getDegree());
            educationItem.setAdmissionTime(e.getAdmissionTime());
            educationItem.setGraduationTime(e.getGraduationTime());
            educationItem.setUpdateTime(LocalDateTime.now());
            educationList.add(educationItem);
        }));

        return educationList;
    }

    @Override
    public boolean sameValueAs(EducationItem other) {
        return this.equals(other);
    }

    public void builder(EducationItem db) {
        Optional.ofNullable(db).ifPresent(edu -> {
            Optional.ofNullable(this.relation).ifPresent(r -> r.builder(db.getRelation()));
            this.category = Optional.ofNullable(this.getCategory()).orElse(db.getCategory());
            Optional.ofNullable(this.address).ifPresent(a -> a.builder(db.getAddress()));
            this.major = Optional.ofNullable(this.getMajor()).orElse(db.getMajor());
            this.grade = Optional.ofNullable(this.getGrade()).orElse(db.getGrade());
            this.className = Optional.ofNullable(this.getClassName()).orElse(db.getClassName());
            this.degree = Optional.ofNullable(this.getDegree()).orElse(db.getDegree());
            this.college = Optional.ofNullable(this.getCollege()).orElse(db.getCollege());
            this.createTime = Optional.ofNullable(db.getCreateTime()).orElse(this.createTime);
            this.updateTime = Optional.ofNullable(this.getUpdateTime()).orElse(db.getUpdateTime());
        });
    }
}
