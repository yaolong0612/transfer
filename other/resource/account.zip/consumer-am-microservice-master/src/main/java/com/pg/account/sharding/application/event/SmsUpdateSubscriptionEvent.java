package com.pg.account.sharding.application.event;

import com.pg.account.sharding.domain.model.subscription.ShardSubscription;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * 用于SMS更新订阅状态事件
 *
 * @author xusheng
 * @date 2021/8/19 10:03
 */
@Getter
public class SmsUpdateSubscriptionEvent extends ApplicationEvent {
    private static final long serialVersionUID = 1347330811879323370L;
    private ShardSubscription shardSubscription;

    public SmsUpdateSubscriptionEvent(Object source, ShardSubscription shardSubscription) {
        super(source);
        this.shardSubscription = shardSubscription;
    }


    public SmsUpdateSubscriptionEvent(Object source) {
        super(source);
    }
}
