package com.pg.account.interfaces.dto.v2;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Set;

/**
 * @author Jack Sun
 * @date 2020-8-31 17:02
 */
@ApiModel(value = "SubscriptionQueryDTO_V2")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionQueryDTO implements Serializable {
    private static final long serialVersionUID = -2403281739555377920L;

    @ApiModelProperty(value = "AM openID", name = "openID", example = "31231244657886743", required = true)
    @Desensitized(value = DesensitizedEnum.IDENTIFICATION)
    private String openId;

    @ApiModelProperty(value = "Subscription Information", name = "subscriptions", required = true)
    private Set<SubscriptionDTO> subscriptions;
}
