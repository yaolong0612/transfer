//package com.pg.account.infrastructure.component.datastream.servicebus;
//
//import cn.com.pg.paas.stream.framework.annotation.EventHandler;
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.google.common.util.concurrent.ThreadFactoryBuilder;
//import com.microsoft.azure.spring.integration.core.AzureHeaders;
//import com.microsoft.azure.spring.integration.core.api.Checkpointer;
//import com.pg.account.application.event.UpdateCounterEvent;
//import com.pg.account.domain.model.account.Account;
//import com.pg.account.domain.model.counter.Counter;
//import com.pg.account.infrastructure.common.context.SpringContextUtil;
//import com.pg.account.infrastructure.component.datastream.channel.ServiceBusChannelConfig;
//
//import com.pg.account.infrastructure.component.uid.UidGenerator;
//import com.pg.account.infrastructure.repositories.CounterRepository;
//import lombok.extern.slf4j.Slf4j;
//import org.apache.commons.lang.Validate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.stream.annotation.EnableBinding;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.handler.annotation.Header;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.util.Objects;
//import java.util.Optional;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.LinkedBlockingQueue;
//import java.util.concurrent.ThreadPoolExecutor;
//import java.util.concurrent.TimeUnit;
//
//import static com.pg.account.infrastructure.common.constants.AccountConstants.MEMBER_ID;
//import static com.pg.account.infrastructure.component.datastream.servicebus.ServiceBusConstants.LOYALTY_FIRST_PURCHASE_QUEUE_INPUT_CHANNEL;
//import static java.lang.Long.parseLong;
//import static java.nio.charset.StandardCharsets.UTF_8;
//
///**
// * @author Jack Sun
// * @date 2019-7-15 15:43
// */
//@Slf4j
//@Service
//@EnableBinding({ServiceBusChannelConfig.class})
//public class LoyaltyFirstPurchaseServiceBusConsumerService {
//
//    public static final String MARKETING_PROGRAM_ID = "marketingProgramId";
//    public static final String FIRST_PURCHASE_STORE_CODE = "firstPurchaseStoreCode";
//    public static final String FIRST_PURCHASE_TIME = "firstPurchaseTime";
//    private final CounterRepository counterRepository;
//    private final UidGenerator uidGenerator;
//    ExecutorService executorService = new ThreadPoolExecutor(1, 2, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(10240), new ThreadFactoryBuilder().setNameFormat("LoyaltyFirstPurchaseServiceBus-pool-%d").build(), new ThreadPoolExecutor.AbortPolicy());
//
//    @Autowired
//    public LoyaltyFirstPurchaseServiceBusConsumerService(CounterRepository counterRepository, UidGenerator uidGenerator) {
//        this.counterRepository = counterRepository;
//        this.uidGenerator = uidGenerator;
//    }
//
//    /**
//     * channel:对应声明的通道名称
//     * eventTypeId: 接收来自发送端的eventTypeId，通过配置文件读取
//     *
//     * @param message      消息
//     * @param checkPointer 检查点
//     */
//    @EventHandler(channel = LOYALTY_FIRST_PURCHASE_QUEUE_INPUT_CHANNEL)
//    @Transactional(rollbackFor = Exception.class)
//    public void queueConsumerMessage(Message<Object> message, @Header(AzureHeaders.CHECKPOINTER) Checkpointer checkPointer) {
//        // 当有大量消息接收时，如果这里不使用异步，则会阻塞后面的消息
//        // 根据业务需求这里是否使用线程池异步处理接收到的消息
//        executorService.execute(() -> {
//            try {
//                // 业务处理
//                JSONObject bodyContent;
//                if (message.getPayload() instanceof byte[]) {
//                    bodyContent = JSON.parseObject(new String((byte[]) message.getPayload(), UTF_8));
//                } else {
//                    bodyContent = JSON.parseObject(message.getPayload().toString());
//                }
//                log.info("saveFirstPurchaseCounter Content:{}", bodyContent.toJSONString());
//                Validate.notNull(bodyContent);
//                JSONObject jsonObject = bodyContent.getJSONObject("jsonObject");
//                if (null != jsonObject) {
//                    this.saveFirstPurchaseCounter(jsonObject);
//                    checkPointer.success();
//                } else {
//                    log.info("jsonObject为空");
//                    checkPointer.failure();
//                }
//            } catch (Exception e) {
//                log.info("不确认消息，重新入队，交给其他实例处理,处理时出现异常:", e);
//                checkPointer.failure();
//            }
//        });
//    }
//
//
//    /**
//     * 接收message消息，进行首单柜信息更新，生成CRM领取柜
//     *
//     * @param jsonObject jsonObject
//     */
//    private void saveFirstPurchaseCounter(JSONObject jsonObject) {
//        String memberId = jsonObject.containsKey(MEMBER_ID) ? jsonObject.getString(MEMBER_ID) : null;
//        String marketingProgramId = jsonObject.containsKey(MARKETING_PROGRAM_ID) ? jsonObject.getString(MARKETING_PROGRAM_ID) : null;
//        String firstPurchaseStoreCode = jsonObject.containsKey(FIRST_PURCHASE_STORE_CODE) ? jsonObject.getString(FIRST_PURCHASE_STORE_CODE) : null;
//        String firstPurchaseTime = jsonObject.containsKey(FIRST_PURCHASE_TIME) ? jsonObject.getString(FIRST_PURCHASE_TIME) : null;
//        Long tenantId = parseLong(ConfigRedisUtils.getTenantIdByMarketingProgramId(Integer.parseInt(Objects.requireNonNull(marketingProgramId))));
//        Counter counter = counterRepository.findByTenantIdAndUsersId(tenantId, memberId);
//        Optional<Counter> counterOptional = Optional.ofNullable(counter);
//        if (counterOptional.isPresent()) {
//            counter.changeFirstPurchaseCounter(tenantId, memberId, firstPurchaseStoreCode, firstPurchaseTime);
//            counter.changeUpdatedTime();
//        } else {
//            counter = new Counter();
//            counter.specifyId(uidGenerator.getUid());
//            counter.changeFirstPurchaseCounter(tenantId, memberId, firstPurchaseStoreCode, firstPurchaseTime);
//            counter.addCreateTime();
//        }
//        counterRepository.save(counter);
//        Account account = new Account(tenantId, memberId, counter);
//        UpdateCounterEvent updatedCounterEvent = new UpdateCounterEvent(this, account);
//        SpringContextUtil.getApplicationContext().publishEvent(updatedCounterEvent);
//    }
//}
