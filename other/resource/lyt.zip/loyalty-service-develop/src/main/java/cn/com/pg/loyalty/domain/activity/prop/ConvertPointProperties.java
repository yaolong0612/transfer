package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @author vincenzo
 * @description
 * @date 2022/1/23
 */
@Getter
@Setter
public class ConvertPointProperties extends RuleProperties {
    /**
     * 次数
     */
    private int times;
    /***
     * 转换率,倍率
     */
    private int exchangeRate;
}
