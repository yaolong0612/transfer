package cn.com.pg.loyalty.domain.structure;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OrderImpact {
    /**
     * 退单重算
     */
    private boolean refundBackRoll;
    /**
     * 插单重算
     */
    private boolean insertBackRoll;

    private boolean alertBackRoll;


    public OrderImpact(boolean refundBackRoll, boolean insertBackRoll, boolean alertBackRoll) {
        this.refundBackRoll = refundBackRoll;
        this.insertBackRoll = insertBackRoll;
        this.alertBackRoll = alertBackRoll;
    }
}
