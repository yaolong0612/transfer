package cn.com.pg.loyalty.interfaces.facade;

/**
 * @author Simon
 * @date 2019/6/16 19:28
 * @description
 **/


import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.RegionV2;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.RedemptionStatus;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.dto.Language;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Validation;
import javax.validation.Validator;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Post 方式请求，参数Swagger都会验证，不用使用这个工具类
 * Get请求：参数必填，参数正则 Swagger都会验证，不用使用这个工具类
 * Get请求：Enum参数，空字符串不验证，需要使用这个参数
 *
 * @author Simon
 */
public class ParamValidator {

    private static final Pattern ML_REDEMPTION_PHONE_PATTERN = Pattern.compile("^(0|86|17951)?(13[0-9]|15[0-9]|17[0-9]|18[0-9]|16[0-9]|19[0-9]|14[0-9])[0-9]{8}$");
    private static final Pattern HKTW_REDEMPTION_ADDRESS_PATTERN = Pattern.compile("^[\\uFF00-\\uFFFF\\u4E00-\\u9FA5A-Za-z\\d\\(\\)\\（\\）\\ \\-_\\#\\~\\!\\@\\$\\%\\^\\&\\*\\+\\=\\/\\>\\<\\.\\,\\?\\\\\\}\\{\\[]+$");
    private static final Pattern ML_REDEMPTION_ADDRESS_PATTERN = Pattern.compile("^[\\uFF00-\\uFFFF\\u4E00-\\u9FA5A-Za-z\\d\\(\\)\\（\\）\\ \\-_\\#]+$");
    private static final Validator validator;
    static {
        validator= Validation.buildDefaultValidatorFactory().getValidator();
    }

    public static Validator getValidator(){
        return validator;
    }

    /**
     * 参数为null，或者参数为空字符串，或多个空字符串，报参数错误. 正常接口String类型参数会加正则验证，也不会用到这个参数
     */
    public static String stringParam(String name, String value) {
        if (StringUtils.isBlank(value)) {
            throw new SystemException("Param: ".concat(name).concat(" is empty"), ResultCodeMapper.PARAM_ERROR);
        }
        return value.trim();
    }

    public static void validateDeleteMemberIds(List<String> memberIds) {
        if (memberIds.isEmpty()) {
            throw new SystemException("Param: memberIds is empty", ResultCodeMapper.PARAM_ERROR);
        }
        int size = 100;
        if (memberIds.size() > size) {
            throw new SystemException("Param: memberIds are over 100", ResultCodeMapper.PARAM_ERROR);
        }

    }

    public static TransactionType transactionType(String transactionType) {
        if (StringUtils.isBlank(transactionType)) {
            throw new SystemException("Param: TransactionType is empty", ResultCodeMapper.PARAM_ERROR);
        }
        for (TransactionType type : TransactionType.values()) {
            if (type.name().equals(transactionType)) {
                return type;
            }
        }
        throw new SystemException("Param: TransactionType Error", ResultCodeMapper.PARAM_ERROR);
    }

    public static RedemptionStatus redemptionStatus(String value) {
        if (StringUtils.isBlank(value)) {
            throw new SystemException("Param: RedemptionStatus is empty", ResultCodeMapper.PARAM_ERROR);
        }
        for (RedemptionStatus redemptionStatus : RedemptionStatus.values()) {
            if (redemptionStatus.name().equals(value)) {
                return redemptionStatus;
            }
        }
        throw new SystemException("Param: RedemptionStatus Error", ResultCodeMapper.PARAM_ERROR);
    }

    public static DeliveryChannel deliveryChannel(String value) {
        if (StringUtils.isBlank(value)) {
            throw new SystemException("Param: DeliveryChannel is empty", ResultCodeMapper.PARAM_ERROR);
        }
        for (DeliveryChannel deliveryChannel : DeliveryChannel.values()) {
            if (deliveryChannel.name().equals(value)) {
                return deliveryChannel;
            }
        }
        throw new SystemException("Param: DeliveryChannel Error", ResultCodeMapper.PARAM_ERROR);
    }

    public static void notLessThan(String name, double num, double min) {
        if (num < min) {
            throw new SystemException("Param: ".concat(name).concat(" need >=").concat(String.valueOf(min)),
                    ResultCodeMapper.PARAM_ERROR);
        }
    }

    private ParamValidator() {
    }

    public static void phone(String region, String phone) {
        if (RegionV2.isMlRegion(region) && StringUtils.isNotEmpty(phone)) {
            Matcher matcher = ML_REDEMPTION_PHONE_PATTERN.matcher(phone);
            if (!matcher.matches()) {
                throw new SystemException("phone pattern error", ResultCodeMapper.PARAM_ERROR);
            }
        }
    }

    public static void address(String region, String address) {
        if (StringUtils.isBlank(address)) {
            return;
        }
        if (RegionV2.isMlRegion(region)) {
            Matcher matcher = ML_REDEMPTION_ADDRESS_PATTERN.matcher(address);
            if (!matcher.matches()) {
                throw new SystemException("Address pattern error", ResultCodeMapper.PARAM_ERROR);
            }
        }
        if (RegionV2.isHkRegion(region) ||
                RegionV2.isTwRegion(region)) {
            Matcher matcher = HKTW_REDEMPTION_ADDRESS_PATTERN.matcher(address);
            if (!matcher.matches()) {
                throw new SystemException("Address pattern error", ResultCodeMapper.PARAM_ERROR);
            }
        }
    }

    public static void freight(Double freight) {
        if (freight == null) {
            return;
        }
        if (freight != 0 && freight / 100 < 1) {
            throw new SystemException("Freight pattern error: must 0 or ge 100", ResultCodeMapper.PARAM_ERROR);
        }
    }

    /**
     * 是否支持区域语言
     *
     * @param language
     * @return
     */
    public static Locale validateLanguage(String language) {
        //理论上不传null，
        if (StringUtils.isEmpty(language)) {
            return null;
        }
        Optional<Locale> localeOptional = Arrays.stream(Locale.getAvailableLocales())
                .filter(locale -> locale.toString().equalsIgnoreCase(language)).findFirst();
        if (!localeOptional.isPresent()) {
            throw new SystemException("Unsupported language:".concat(language), ResultCodeMapper.PARAM_ERROR);
        }
        return localeOptional.get();
    }


    public static void validName(String name) {
        if (StringUtils.isEmpty(name)) {
            throw new SystemException("please provide query name", ResultCodeMapper.PARAM_ERROR);
        }
    }

    public static void validateDuplicateLanguage(List<Language> languageList) {

        Map<String, Long> languageMap = languageList.stream().collect(Collectors.groupingBy(Language::toString, Collectors.counting()));
        languageMap.values().forEach(count -> {
            if (count > 1) {
                throw new SystemException("存在相同多语言!", ResultCodeMapper.PARAM_ERROR);
            }
        });
    }
}
