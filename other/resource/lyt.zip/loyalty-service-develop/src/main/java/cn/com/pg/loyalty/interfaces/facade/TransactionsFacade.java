package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.*;
import cn.com.pg.loyalty.application.dependence.TransferStoreCodeResult;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCouponService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.RegionV2;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.infrastructure.lock.IdempotentLock;
import cn.com.pg.loyalty.interfaces.api.TransactionsApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.RedemptionMapper;
import cn.com.pg.loyalty.interfaces.assembler.TransactionAssembler;
import cn.com.pg.loyalty.interfaces.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Ladd
 */
@Component("TransactionsFacade")
@Slf4j
public class TransactionsFacade implements TransactionsApiDelegate {

    private static final String METHOD_LOG_INFO = "MethodName:{},操作用户{}";

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private RedemptionService redemptionService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private GiftService giftService;

    @Autowired
    private GiftCouponService giftCouponService;
    @Autowired
    private ConfigService configService;
    @Autowired
    private OrderAppService orderAppService;

    @Override
    @IdempotentLock(lockKeys = {"'interaction'", "#body.region", "#body.brand", "#body.memberId", "#body.externalBusinessId"},
            unlessWithEmpty = "#body.externalBusinessId")
    public ResponseEntity<TransactionDTO> addInteractionPoint(AddInteractionCommand body, String token) {
        log.info(METHOD_LOG_INFO, "addInteractionPoint", JwtUtils.getUsernameFromToken(token));
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        Account account = accountService.fetchAndInitialInExistSubAccount(body.getMemberId(), loyaltyStructure, body.getBrand(), body.getChannel());
        account.checkAccountAvailable(loyaltyStructure);
        Interaction interaction = TransactionAssembler.toInteraction(body, account, loyaltyStructure);
        InteractionExtraParams extraParams = TransactionAssembler.toInteractionExtraParams(body);
        AccountTransactionResult accountTransactionResult = transactionService.addInteractionPointV2(
                interaction, account, loyaltyStructure,
                body.getPointType(), extraParams, body.getPoint(),
                body.getAdjustReason(), token, body.getExternalBusinessId());
        TransactionDTO transactionDTO = TransactionAssembler.toTransactionDTO(accountTransactionResult, loyaltyStructure, body.getBrand());
        return ResponseEntity.ok(transactionDTO);
    }

    @Override
    @IdempotentLock(lockKeys = {"'interaction'", "#body.region", "#body.brand", "#body.memberId", "#body.externalBusinessId"},
            unlessWithEmpty = "#body.externalBusinessId")
    public ResponseEntity<TransactionDTO> addInteractionPointV2(AddInteractionCommandV2 body, String token) {
        log.info(METHOD_LOG_INFO, "addInteractionPoint", JwtUtils.getUsernameFromToken(token));
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        Account account = accountService.fetchAndInitialInExistSubAccount(body.getMemberId(), loyaltyStructure, body.getBrand(), body.getChannel());
        account.checkAccountAvailable(loyaltyStructure);
        Interaction interaction = TransactionAssembler.toInteraction(body, account, loyaltyStructure);
        AccountTransactionResult accountTransactionResult = transactionService.addInteractionPointV2(
                interaction, account, loyaltyStructure,
                body.getPointType(), body.getExtraParams(), body.getPoint(),
                body.getAdjustReason(), token, body.getExternalBusinessId());
        TransactionDTO transactionDTO = TransactionAssembler.toTransactionDTO(accountTransactionResult, loyaltyStructure, body.getBrand());
        return ResponseEntity.ok(transactionDTO);
    }


    @Override
    public ResponseEntity<TransactionDTO> addOrderPoint(AddOrderCommand body) {
        LocalDateTime orderDateTime = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getOrderDateTime());
        Set<OrderItem> orderItems = TransactionAssembler.orderItemDtoToOrderItem(body.getOrderItem());
        AccountTransactionResult accountTransactionResult = transactionService.addOrderPointV2(
                body.getBrand(),
                body.getRegion(),
                body.getChannel(),
                body.getMemberId(),
                body.getPointType(),
                body.getOrderId(),
                orderDateTime,
                orderItems,
                body.getStoreCode(),
                Optional.ofNullable(body.getPoint()).orElse(0));
        LoyaltyStructure loyaltyStructure =
                cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        TransactionDTO transactionDTO = TransactionAssembler.toTransactionDTO(accountTransactionResult,
                loyaltyStructure, body.getBrand());
        return ResponseEntity.ok(transactionDTO);
    }


    @Override
    public ResponseEntity<TransactionDetailDTO> findTransactionById(String transactionId, String brand,
                                                                    String region, String loyaltyId) {
        //验证Get请求中的Enum参数

        // loyaltyId 实际意义不大，以后传参传memberId即可
        Transaction transaction = transactionService.findByTransactionId(transactionId, brand, loyaltyId);
        TransactionDetailDTO transactionDetailDTO = TransactionAssembler.toTransactionDetailDTO(transaction);
        return ResponseEntity.ok(transactionDetailDTO);
    }

    @Override
    @IdempotentLock(lockKeys = {"'Redemption'", "#body.region", "#body.brand", "#body.memberId", "#body.externalBusinessId"},
            unlessWithEmpty = "#body.externalBusinessId")
    public ResponseEntity<CreateRedemptionDTO> createRedemption(CreateRedemptionCommand body) {
        String phone = body.getPhone();
        String address = body.getAddress();
        ParamValidator.phone(body.getRegion(), phone);
        ParamValidator.address(body.getRegion(), address);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        configService.checkConfig("CHANNEL", body.getChannel());
        Redemption redemption = RedemptionMapper.INSTANCE.command2Redemption(body);

        AccountTransactionResult accountTransactionResult = redemptionService.createRedemption(redemption, structure,
                Optional.ofNullable(body.getLanguage()).map(Locale::forLanguageTag).orElse(null));

        CreateRedemptionDTO createRedemptionDTO = TransactionAssembler.toCreateRedemptionDTO(structure, accountTransactionResult, body.getBrand());
        return ResponseEntity.ok(createRedemptionDTO);
    }

    @Override
    @IdempotentLock(lockKeys = {"'Redemption'", "#body.region", "#body.brand", "#body.memberId", "#body.externalBusinessId"},
            unlessWithEmpty = "#body.externalBusinessId")
    public ResponseEntity<CreateRedemptionDTO> createRedemptionV2(CreateRedemptionCommand body) {
        return createRedemption(body);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> fetchRedemptionList(String authorization, String activityId, String brand, String region, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page, String deliveryChannel, String redemptionStatus, String memberId, String channel, Boolean returnTierLevel, String language) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "fetchRedemptionList", userName);
        //验证Get请求中的Enum参数
        RedemptionStatus redemptionStatusObj = null;
        if (redemptionStatus != null) {
            redemptionStatusObj = ParamValidator.redemptionStatus(redemptionStatus);
        }
        DeliveryChannel deliveryChannelObj = null;
        if (deliveryChannel != null) {
            deliveryChannelObj = ParamValidator.deliveryChannel(deliveryChannel);
        }

        PageableResult<Redemption> pageableResult;
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        if (RegionV2.isMlRegion(region)) {
            pageableResult = redemptionService.fetchRedemptionList(activityId, brand,
                    LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                    LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                    perPage, page, memberId,
                    redemptionStatusObj,
                    deliveryChannelObj,
                    channel);
        } else {
            pageableResult = transactionService.fetchRedemptionList(activityId, brand, region,
                    LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                    LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                    perPage, page, memberId,
                    redemptionStatusObj,
                    deliveryChannelObj,
                    channel);
        }
        Map<String, Account> accountMap = new HashMap<>();
        Map<String, Store> storeMap = new HashMap<>();
        Map<String, Gift> giftMap = new HashMap<>();
        for (Redemption redemption : pageableResult.getRecords()) {
            if (!brand.equals(redemption.brand())) {
                continue;
            }
            //查询柜台信息
            String storeCode = redemption.getStoreCode();
            redemption.getGiftItemList().forEach(giftItem -> giftMap.put(giftItem.getGiftId(), cacheService.getGiftById(giftItem.getGiftId())));
            if (!StringUtils.isEmpty(storeCode) && !storeMap.containsKey(storeCode)) {
                Store store = cacheService.getStoreByStoreCode(storeCode);
                storeMap.put(storeCode, store);
            }
        }
        Map<String, Boolean> giftCancelableList = transactionService.fetchRedemptionCancelableStatus(pageableResult.getRecords());
        FetchRedemptionListDTO fetchRedemptionListDTO = TransactionAssembler.toFetchRedemptionListDTO(structure, pageableResult, storeMap, giftCancelableList, accountMap, giftMap);
        //HK PAMPERS门店多语言翻译
        giftService.translateGiftCouponForHkPampersRedemption(language, region, brand, fetchRedemptionListDTO.getRecords());
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }


    @Override
    public ResponseEntity<RedemptionDTO> fetchRedemptionById(String transactionId, String brand, String region, String memberId) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Redemption redemption = transactionService.findRedemptionById(transactionId, structure, memberId);
        Map<String, Gift> giftMap = new HashMap<>(redemption.getGiftItemList().size());
        redemption.getGiftItemList().forEach(giftItem -> giftMap.put(giftItem.getGiftId(), cacheService.getGiftById(giftItem.getGiftId())));
        RedemptionDTO dto = TransactionAssembler.toRedemptionDto(structure, redemption, giftMap, region);
        return ResponseEntity.ok(dto);
    }

    /**
     * Admin修改status或者柜台，物流单号等
     */
    @Override
    public ResponseEntity<Void> updateRedemptionInfoById(String token, String transactionId, UpdateRedemptionCommand body) {
        transactionService.updateRedemptionStatusByIdForAdmin(transactionId, body.getRedemptionStatus().name(),
                body.getLogisticsNumber(), body.getStoreCode(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getUpdateTime()));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 消费者修改收货柜台接口
     */
    @Override
    public ResponseEntity<Void> updateRedemptionStoreCodeById(String transactionId, UpdateRedemptionStoreCodeCommand body) {
        transactionService.updateRedemptionStoreCodeById(transactionId, body.getMemberId(), body.getRegion(), body.getBrand(), body.getStoreCode());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 批量转换兑换的A领取柜台到B柜台
     */
    @Override
    public ResponseEntity<TransferStoreCodeResultDTO> transferStoreCode(String authorization, TransferConsumersToAnotherStoreCodeCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "transferStoreCode", userName);
        TransferStoreCodeResult transferStoreCodeResult = transactionService.transferStoreCode(body.getActivityId(),
                body.getOriginalStoreCode(), body.getDestinationStoreCode(), body.getAcceptGiftIdList());
        TransferStoreCodeResultDTO transferStoreCodeResultDTO = new TransferStoreCodeResultDTO()
                .involvedConsumerNum(transferStoreCodeResult.getInvolvedConsumerNum())
                .involvedTransactionNum(transferStoreCodeResult.getInvolvedTransactionNum());
        return ResponseEntity.ok(transferStoreCodeResultDTO);
    }

    /**
     * 修改发货渠道
     * 修改兑换发运渠道，目前只有C2热线到家会使用
     */
    @Override
    public ResponseEntity<Void> updateRedemptionDeliveryChannel(String authorization, UpdateRedemptionDeliveryChannelCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "updateRedemptionDeliveryChannel", userName);
        String memberId = body.getMemberId();
        LoyaltyStructure loyaltyStructure =
                cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        Account account = accountService.fetchAccountByMemberId(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException("Account not found", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        transactionService.updateDeliveryChannel(account.loyaltyId(),
                body.getActivityId(),
                Store.HOT_LINE_ARRIVED_HOME,
                null,
                null,
                body.getReceiver(),
                body.getPhone(),
                body.getAddress(),
                body.getProvince(),
                body.getCity(),
                body.getDistrict(),
                DeliveryChannel.C2,
                body.getIgnoreGiftIdList());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 更新物流信息
     */
    @Override
    public ResponseEntity<Void> updateRedemptionLogisticsById(String transactionId, UpdateRedemptionLogisticsCommand cmd) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(cmd.getRegion(), cmd.getBrand());
        LogisticsVO logisticsVO = LogisticsVO.builder().receiver(cmd.getReceiver())
                .phone(cmd.getPhone()).province(cmd.getProvince()).city(cmd.getCity())
                .district(cmd.getDistrict()).address(cmd.getAddress()).email(cmd.getEmail())
                .postalCode(cmd.getPostalCode()).addressCode(cmd.getAddressCode()).build();
        transactionService.updateRedemptionLogisticsById(cmd.getMemberId(), loyaltyStructure, transactionId, logisticsVO);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> getRedemptionByStoreCode(String authorization, String activityId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page, String storeCode, String redemptionStatus) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "getRedemptionByStoreCode", userName);
        PageableResult<Redemption> pageableResult = transactionService.getRedemptionByStoreCode(activityId,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                redemptionStatus, perPage, page, storeCode);
        Map<String, Gift> giftMap = new HashMap<>();
        for (Redemption redemption : pageableResult.getRecords()) {
            //查询柜台信息
            redemption.getGiftItemList().forEach(giftItem -> giftMap.put(giftItem.getGiftId(), cacheService.getGiftById(giftItem.getGiftId())));
        }
        Map<String, Boolean> giftCancelableList = transactionService.fetchRedemptionCancelableStatus(pageableResult.getRecords());
        FetchRedemptionListDTO fetchRedemptionListDTO = TransactionAssembler.toFetchRedemptionListDTO(pageableResult, giftCancelableList, giftMap);
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> getRedemptionByStoreCodeWithoutActivityId(String authorization, String storeCode, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page, String redemptionStatus) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "getRedemptionByStoreCodeWithoutActivityId", userName);
        PageableResult<Redemption> pageableResult = transactionService.getRedemptionByStoreCodeWithoutActivityId(
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                redemptionStatus, perPage, page, storeCode);
        Map<String, Gift> giftMap = new HashMap<>();
        for (Redemption redemption : pageableResult.getRecords()) {
            //查询柜台信息
            redemption.getGiftItemList().forEach(giftItem -> giftMap.put(giftItem.getGiftId(), cacheService.getGiftById(giftItem.getGiftId())));
        }
        Map<String, Boolean> giftCancelableList = transactionService.fetchRedemptionCancelableStatus(pageableResult.getRecords());
        FetchRedemptionListDTO fetchRedemptionListDTO = TransactionAssembler.toFetchRedemptionListDTO(pageableResult, giftCancelableList, giftMap);
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }

    @Override
    public ResponseEntity<Void> updateStatusToDeliveredByStoreCode(String authorization, String storeCode, UpdateRedemptionStatusToDeliveredCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info(METHOD_LOG_INFO, "updateStatusToDeliveredByStoreCode", userName);
        LocalDateTime startAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime endAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());
        transactionService.updateRedemptionStatusToDeliveredByStoreCode(
                body.getActivityId(), storeCode, startAt, endAt, body.getIgnoreGiftIdList());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> cancelRedemptionById(String transactionId, CancelRedemptionCommand body) {
        transactionService.cancelRedemption(body.getRegion(), body.getBrand(), body.getMemberId(), transactionId, body.getGifts());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> expireRedemptionById(String transactionId, ExpireRedemptionCommand body) {
        transactionService.expiredRedemption(body.getRegion(), body.getBrand(),
                body.getMemberId(), transactionId, body.getGifts(), body.getReason());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionGiftsStatusById(String transactionId, UpdateRedemptionGiftStatusCommand body) {
        transactionService.updateRedemptionGiftStatus2Pickup(transactionId, body.getLoyaltyId(), body.getRedeemCode(), TransactionAssembler.toGiftIdList(body.getGiftIdItem()));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionGiftStatusToReceivedById(String transactionId, ReceiveRedemptionGiftsCommand body) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(
                body.getRegion(), body.getBrand());
        transactionService.updateRedemptionGiftStatusToReceivedById(transactionId, body.getMemberId(), loyaltyStructure,
                body.getRedeemCode(), TransactionAssembler.toGiftIdList(body.getGiftIdItem()));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<RedemptionGiftListStatusDTO> batchUpdateRedemptionGiftsStatus(UpdateRedemptionGiftListStatusCommand body) {
        RedemptionGiftListStatusDTO statusDTO = new RedemptionGiftListStatusDTO();
        body.getGiftIdItem().forEach(ids -> {
            GiftStatusForBatchDTO giftStatusDTO = new GiftStatusForBatchDTO();
            try {
                giftStatusDTO.setStatus(GiftStatusForBatchDTO.StatusEnum.RECEIVED);
                giftStatusDTO.setDescription("SUCCESS");
                transactionService.modifyRedemptionSingleGiftStatus(ids.getTransactionId(), ids.getGiftId(), ids.getLoyaltyId(), ids.getRedeemCode(), ids.getStoreCode());
                TimeUnit.MILLISECONDS.sleep(50);
            } catch (SystemException e) {
                log.error("C2批量更新礼品收货状态有异常", e);

                giftStatusDTO.setStatus(
                        e.resultCodeMapper() == ResultCodeMapper.PEOPLEX_GROUP_MEMBER_STATUS ?
                                GiftStatusForBatchDTO.StatusEnum.PEOPLEX_NOT_JOIN : GiftStatusForBatchDTO.StatusEnum.FAILED);
                giftStatusDTO.setDescription(e.getMessage());
            } catch (InterruptedException e) {
                log.error("线程被中断", e);
                Thread.currentThread().interrupt();
            }
            giftStatusDTO.setGiftId(ids.getGiftId());
            giftStatusDTO.setGiftName(giftService.findGiftById(ids.getGiftId()).getName());
            giftStatusDTO.setTransactionId(ids.getTransactionId());
            statusDTO.addRecordsItem(giftStatusDTO);
        });
        return ResponseEntity.ok(statusDTO);
    }

    @Override
    public ResponseEntity<Void> rejectById(String transactionId, RejectRedemptionCommand body) {
        transactionService.rejectRedemption(body.getRegion(), body.getBrand(), body.getMemberId(), transactionId, body.getGifts(), body.getReason());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<FetchRedemptionListForC2DTO> fetchRedemptionListByRedeemCode(OffsetDateTime startAt,
                                                                                       OffsetDateTime endAt,
                                                                                       String redeemCode,
                                                                                       String brand, Integer perPage,
                                                                                       Integer page) {

        PageableResult<Redemption> pageableResult = redemptionService.fetchRedemptionListByRedeemCode(
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                redeemCode,
                brand,
                RedemptionStatus.DELIVERED,
                page,
                perPage);
        FetchRedemptionListForC2DTO fetchRedemptionListDTO =
                TransactionAssembler.toFetchRedemptionListForC2DTO(pageableResult,
                        generateMetaGiftMap(pageableResult.getRecords()));
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }

    private Map<String, Gift> generateMetaGiftMap(List<Redemption> redemptionList) {
        List<String> giftIdList =
                redemptionList.stream().map(x -> x.getGiftItemList().stream()
                        .map(GiftItem::getGiftId)
                        .collect(Collectors.toList())).flatMap(List::stream).collect(Collectors.toList());
        Map<String, Gift> metaGiftMap = new HashMap<>();
        giftIdList.forEach(giftId -> metaGiftMap.put(giftId, cacheService.getGiftById(giftId)));
        return metaGiftMap;
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> fetchRedemptionListByStoreAndActivityForC2(OffsetDateTime startAt,
                                                                                             OffsetDateTime endAt,
                                                                                             String storeCode,
                                                                                             String brand,
                                                                                             Integer perPage,
                                                                                             Integer page) {

        PageableResult<Redemption> pageableResult = transactionService.getRedemptionByStoreCodeWithoutActivityId(
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt),
                null, perPage, page, storeCode);
        Map<String, Gift> giftMap = new HashMap<>();
        for (Redemption redemption : pageableResult.getRecords()) {
            //查询柜台信息
            redemption.getGiftItemList().forEach(giftItem -> giftMap.put(giftItem.getGiftId(), cacheService.getGiftById(giftItem.getGiftId())));
        }
        Map<String, Boolean> giftCancelableList = transactionService.fetchRedemptionCancelableStatus(pageableResult.getRecords());
        FetchRedemptionListDTO fetchRedemptionListDTO = TransactionAssembler.toFetchRedemptionListDTO(pageableResult, giftCancelableList, giftMap);
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }

    @Override
    public ResponseEntity<Void> batchAddInteractionPoint(BathAddInteractionCommand body) {
        String region = body.getRegion();
        String brand = body.getBrand();
        String channel = body.getChannel();
        transactionService.batchAddInteractionPoint(region, brand, channel,
                body.getPointType(), body.getPoint(), body.getMemberIds(), body.getAdjustReason());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * 取消-过期兑换
     */
    @Override
    public ResponseEntity<Void> cancelRedemptionByRedeemCode(String brand,
                                                             String region,
                                                             String redeemCode,
                                                             String redemptionStatus,
                                                             String memberId) {
        RedemptionStatus canceled = RedemptionStatus.valueOf(redemptionStatus);
        GiftItem.GiftStatus giftStatus = GiftItem.GiftStatus.valueOf(redemptionStatus);
        transactionService.cancelRedemptionByRedeemCode(region, brand,
                memberId, redeemCode, giftStatus, canceled);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> sendOrderToServiceBus(AddOrderCmd body) {
        orderAppService.sendOrderToServiceBus(body);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
