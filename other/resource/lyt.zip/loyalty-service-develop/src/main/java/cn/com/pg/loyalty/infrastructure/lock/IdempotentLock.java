package cn.com.pg.loyalty.infrastructure.lock;


import cn.com.pg.loyalty.domain.shared.SystemException;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

/**
 * @Author: Hayden
 * @CreateDate: 2021/5/27 18:19
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/5/27 18:19
 * @Version: 1.0
 * @Description: lock 实现: infrastructure/lock
 */


@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface IdempotentLock{
    /**
     * spel 语法表达:  变量 #argument，固定 'argument'
     */
    String[] lockKeys() default {};

    long expiredTime() default 60;

    TimeUnit timeUnit() default TimeUnit.MINUTES;

    Class<? extends RuntimeException>[] businessExceptions() default SystemException.class;

    /**
     * spel 语法表达，除了该值为empty,都会上锁
     *
     * @return
     */
    String unlessWithEmpty() default "";

    String errorMessage() default "Repeat request!";


}
