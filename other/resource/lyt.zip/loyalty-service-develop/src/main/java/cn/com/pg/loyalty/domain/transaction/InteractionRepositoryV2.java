package cn.com.pg.loyalty.domain.transaction;

import java.time.LocalDateTime;
import java.util.List;

public interface InteractionRepositoryV2 {
    /**
     * 查询用户交互记录: 通过externalBusinessId
     */
    List<Interaction> fetchInteractionsByExternalBusinessId(String loyaltyId, String externalBusinessId);

    List<Interaction> fetchByPointTypes(String loyaltyId, String... pointTypes);

    boolean existedExpiredPointAfter(String loyaltyId, LocalDateTime createdTime);
}
