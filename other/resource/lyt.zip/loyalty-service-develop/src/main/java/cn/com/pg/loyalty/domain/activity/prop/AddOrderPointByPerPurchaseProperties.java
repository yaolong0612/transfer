package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import java.util.List;

@Getter
@Setter
public class AddOrderPointByPerPurchaseProperties extends RuleProperties{
    /**
     * 基础倍数 1倍
     */
    @Min(1)
    private double basePointMultiple;

    /**
     * 每单加多少分
     */
    @Min(0)
    private int point; //每单加多少分

    /**
     * 等级及倍数
     */
    private List<TierMultipleRuleProperties> tierMultipleRulePropertiesList;

    private int maxPoint; //最大积分数
}
