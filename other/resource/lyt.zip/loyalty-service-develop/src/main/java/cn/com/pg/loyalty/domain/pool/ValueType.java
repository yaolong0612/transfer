package cn.com.pg.loyalty.domain.pool;

public enum ValueType {
    /**
     * 默认情况下的值，pampers代表的是成长值、其他品牌代表的是积分
     */
    DEFAULT,
    /**
     * pampers品牌代表的是积分TRANSIT
     */
    TRANSIT
}
