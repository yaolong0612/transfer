package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.shared.Entity;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Simon
 * @date 2019/6/26 23:39
 * @description 用来维护全局的Point Type类型
 **/

@Getter
@Setter
@Document(collection = "PointType", ru = "400")
@Slf4j
@NoArgsConstructor
public class PointType implements Entity<PointType> {

    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.POINT_TYPE_PARTITIONKEY;
    private String pointType;

    private String description;

    private String remark;

    private String createdBy;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    private PointTypeStatus status;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    private String updatedBy;

    /**
     * 活动的分类，活动根据Transaction Type不同，分为不同的类别
     */
    private TransactionType transactionType;

    /**
     * 积分Rule 模板
     */
    private RuleTemplate ruleTemplate;

    /**
     * 每个积分体系下，积分类型都是唯一的。在加积分时，优先使用Activity中的积分描述，如果包含多个Activity，则使用Point Type
     * 中的description
     */
    private String loyaltyStructure;

    private String typeAlias;

    private String subAlias;

    /**
     * 映射积分类型
     */
    private String mappingPointType;
    /**
     * 多语言支持
     */
    private List<PointTypeDisplayMsg> displayLanguages = new ArrayList<>();

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PointTypeDisplayMsg {
        private Locale language;
        private String description;


    }


    @Override
    public boolean sameIdentityAs(PointType other) {
        return other != null && this.id.equals(other.id);
    }

    public PointType(String pointType, String description, String remark,
                     String loyaltyStructure, String createdBy, TransactionType transactionType, RuleTemplate ruleTemplate) {
        this.id = UUIDUtil.generator();
        this.pointType = pointType;
        this.description = description;
        this.remark = remark;
        this.loyaltyStructure = loyaltyStructure;
        this.transactionType = transactionType;
        this.ruleTemplate = ruleTemplate;
        this.status = PointTypeStatus.ACTIVATED;
        this.createdTime = this.getCreatedTime() == null ? LocalDateTime.now() : this.getCreatedTime();
        this.createdBy = createdBy;
        this.updatedTime = LocalDateTime.now();
        this.updatedBy = this.createdBy;
    }

    public void configAlias(String typeAlias, String subAlias) {
        this.typeAlias = typeAlias;
        this.subAlias = subAlias;
    }

    public void delete(String updatedBy) {
        this.updatedTime = LocalDateTime.now();
        this.updatedBy = updatedBy;
        this.status = PointTypeStatus.DELETED;
    }

    public String pointType() {
        return this.pointType;
    }

    public String pointTypeId() {
        return this.id;
    }

    public String loyaltyStructure() {
        return this.loyaltyStructure;
    }

    public String description() {
        return this.description;
    }

    public boolean thisTransactionType(TransactionType transactionType) {
        return Optional.ofNullable(this.transactionType).map(transactionType1 -> transactionType1 == transactionType).orElse(false);
    }

    public boolean availablePointType() {
        return Optional.ofNullable(this.status).map(typeStatus -> typeStatus == PointTypeStatus.ACTIVATED).orElse(false);
    }

    public RuleTemplate ruleTemplate() {
        return this.ruleTemplate;
    }

    public enum PointTypeStatus {
        /**
         * 激活，删除状态
         */
        ACTIVATED, DELETED
    }


    public void addDisplayLanguages(List<PointTypeDisplayMsg> addDisplayLanguageList) {
        if (CollectionUtils.isEmpty(addDisplayLanguageList)) {
            return;
        }
        Map<Locale, PointTypeDisplayMsg> addDisplayLanguageMap = addDisplayLanguageList.stream().collect(Collectors.toMap(PointTypeDisplayMsg::getLanguage, self -> self));
        //移除本身存在的多语言,避免覆盖原有数据
        this.displayLanguages.forEach(addDisplayLanguage -> addDisplayLanguageMap.remove(addDisplayLanguage.getLanguage()));
        //正式添加新增的多语言
        this.displayLanguages.addAll(addDisplayLanguageMap.values());
    }
}
