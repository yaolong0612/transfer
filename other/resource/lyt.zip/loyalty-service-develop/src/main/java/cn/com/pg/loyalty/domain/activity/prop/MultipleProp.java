package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;
@Data
public class MultipleProp {
    /**
     * 倍数的类型  包含固定和浮动
     */
    private Type multipleType;
    /**
     * 固定倍率下才有值
     */
    private Double multipleTimes = 1.0;
    /**
     * 金额上限
     * 只有浮动倍数的时候才会有
     */
    private Integer upperLimitMoney;
    /**
     * 金额上限对应的倍数
     * 只有浮动倍数的时候才会有值
     */
    private Integer moreLimitMoneyMultiple;
    /**
     * 满足金额后的积分倍数
     * multipleType若是浮动  则可以有多个倍数
     * key表示满足多少金额
     */
    private Map<Double, Double> multiple = new HashMap<>();

    public enum Type {
        REGULAR,
        FLOAT
    }
}
