package cn.com.pg.loyalty.interfaces.web;

import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.infrastructure.monitoring.MonitoringPrinter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Simon
 */

public class SystemFilter implements Filter {

    private static final Logger log = LoggerFactory.getLogger(SystemFilter.class);


    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;
        log.info("Authorization: {}", httpServletRequest.getHeader("Authorization"));
        String correlationId = httpServletRequest.getHeader("x-request-id");
        String method = httpServletRequest.getMethod();
        RequestContext.createContext(correlationId);
        RequestContext.getCurrentContext().requestMethod(method);
        RequestContext.getCurrentContext().path(httpServletRequest.getRequestURI());
        correlationId = RequestContext.getCurrentContext().getCorrelationId();
        log.info("Http Request RequestId : " + correlationId + " Start !");
        log.info("Http Request Information : {\"URI\":\"" + httpServletRequest.getRequestURI() +
                "\",\"Method\":\"" + method +
                "\",\"Accept\":\"" + httpServletRequest.getHeader("Accept") +
                "\",\"Content-Type\":\"" + httpServletRequest.getContentType() +
                "\"}");
        chain.doFilter(request, httpServletResponse);
        printMonitorLog(httpServletResponse);
        RequestContext.cleanContext();
    }

    private void printMonitorLog(HttpServletResponse httpServletResponse) {
        int errorCode = ResultCodeMapper.SUCCESS.getCode();
        if (null != RequestContext.getCurrentContext().errorResult()) {
            errorCode = RequestContext.getCurrentContext().errorResult().getCode();
        }
        String errorMsg = "Http Status: " + httpServletResponse.getStatus();
        MonitoringPrinter.printAPIRequest(errorCode, errorMsg);
    }

    @Override
    public void destroy() {
        //DO NOTHING.
    }

    @Override
    public void init(FilterConfig filterConfig) {
        //DO NOTHING.
    }
}
