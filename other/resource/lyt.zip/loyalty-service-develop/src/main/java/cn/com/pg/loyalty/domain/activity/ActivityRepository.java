package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author        Young
 * @description   opertate  Activity Collection
 * @date          2019年4月24日 下午11:12:05
 */
@Repository
public interface ActivityRepository extends DocumentDbRepository<Activity, String> {

	List<Activity> findByTransactionType(TransactionType transactionType);

	List<Activity> findByPointType(String pointType);

	List<Activity> findActivityById(String activityId);

	/**
	 * 查询指定条件下的所有Activity
	 *
	 * @param structure      积分体系
	 * @param ruleTemplate   积分模板
	 * @param activityStatus 活动状态
	 * @param
	 * @return List<Activity>
	 */
	// TODO 需要使用者修改该方法。由于没有orderDateTime这个字段，暂时先去掉一截AndOrderDateTime，以保证项目正常启动。
	@Deprecated
	List<Activity> findByLoyaltyStructureAndRuleTemplateAndStatus(String structure, RuleTemplate[] ruleTemplate, ActivityStatus activityStatus, LocalDateTime orderDateTime);

	/**
	 *
	 * @param brand
	 * @param ruleTemplate
	 * @param status
	 * @return
	 */
	List<Activity> findByBrandAndRuleTemplateAndStatus(String brand,RuleTemplate ruleTemplate,ActivityStatus status);

	List<Activity> findByLoyaltyStructureAndPointType(String loyaltyStructure, String pointType);

	List<Activity> findByLoyaltyStructureAndTransactionType(String loyaltyStructure, String transactionType);

	/**
	 * 根据ruleTemplate 和 ActivityStatus获取Activity
	 * @param ruleTemplate
	 * @param status
	 * @return
	 */
	List<Activity> findByRuleTemplateAndStatus(RuleTemplate ruleTemplate, ActivityStatus status);

	List<Activity> findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(TransactionType interaction, String loyaltyStructure, String brand, String startAt, String endAt);

	boolean existsByExternalId(String externalId);

	@Override
	Activity save(Activity activity);

	List<Activity> findByTransactionTypeAndCreatedTimeBetweenOrderByCreatedTimeDesc(TransactionType transactionType, String startAt, String endAt);
}
