package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.*;
import cn.com.pg.loyalty.application.dependence.*;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.dmp.StoreService;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.interfaces.api.AccountsApi;
import cn.com.pg.loyalty.interfaces.api.AccountsApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.AccountAssembler;
import cn.com.pg.loyalty.interfaces.assembler.TransactionAssembler;
import cn.com.pg.loyalty.interfaces.dto.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.application.TransactionService.GIFT_ISSUED_NUM;
import static cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone;

/**
 * @author Ladd
 * <p>
 * 用户绑定注册
 */
@Component("AccountsFacade")
@Slf4j
public class AccountsFacade implements AccountsApiDelegate {

    private static final String BIRTHDAY = "birthday";
    private static final String CELLPHONE = "cellphone";
    private static final String PAMPERS = "PAMPERS";
    private static final String BRAND = "brand";
    private static final String LOYALTYID = "loyaltyId";
    private static final String INVALID = "invalid";

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountAppService accountAppService;

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private TransactionService transactionService;
    @Autowired
    private TableStorageTemplate tableStorageTemplate;
    @Autowired
    private LogisticsAgentClient logisticsAgentClient;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private AmClient amClient;

    @Autowired
    private TaskService taskService;
    @Autowired
    private ServiceBusTemplate serviceBusTemplate;

    @Autowired
    private OperationService operationService;


    @Autowired
    private StoreService storeService;

    @Override
    public ResponseEntity<AccountDTO> enrollLoyaltyAccount(@RequestBody @Valid EnrollAccountCommand body) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        Account.RegistryEvent registryEvent = Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT;
        if (body.getRegisterType() == EnrollAccountCommand.RegisterTypeEnum.BINDING) {
            registryEvent = Account.RegistryEvent.BINDING_EVENT;
        }
        Account account = accountService.register(body.getMemberId(),
                body.getBrand(),
                body.getChannel(),
                body.getBindId(), toLocalDateTimeAtDefaultZone(body.getRegistryTime()),
                body.getRegion(),
                body.getBabyBirthYearAndMonth(), registryEvent);
        Map<String,Object> pointAboutExpireMap = transactionService.calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(account, body.getBrand(), loyaltyStructure);
        AccountDTO accountDTO = AccountAssembler.toAccountDTO(account, loyaltyStructure, pointAboutExpireMap);
        return ResponseEntity.ok(accountDTO);
    }

    @Override
    public ResponseEntity<AccountDTO> findAccountByMemberId(String id, String brand, String region, String channel, String bindId) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, id);
        Map<String,Object> pointAboutExpireMap = transactionService.calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(account, brand, loyaltyStructure);
        AccountDTO accountDTO = AccountAssembler.toAccountDTO(account, loyaltyStructure, pointAboutExpireMap);
        return ResponseEntity.ok(accountDTO);
    }

    @Override
    public ResponseEntity<PointHistoryWithPointCategoryDTO> findPointHistory(String id, String brand, String region, String channel, String valueType, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer pageSize, Integer page, String pointCategory, String language) {
        Locale locale = ParamValidator.validateLanguage(language);
        AccountService.PointCategory pointCategoryEnum = StringUtils.isBlank(pointCategory) ? null : AccountService.PointCategory.valueOf(pointCategory);
        log.info("查找memberId为{},brand为{}用户的积分记录", id, brand);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        PageableResult<Transaction> resultData =
                accountService.findPointHistory(id, valueType, pageSize, page,
                        toLocalDateTimeAtDefaultZone(startAt),
                        toLocalDateTimeAtDefaultZone(endAt),
                        loyaltyStructure, pointCategoryEnum, locale);
        List<String> storeCodeList = TransactionAssembler.analyseStoreCodeFromOrder(resultData.getRecords());
        PointHistoryWithPointCategoryDTO pointHistoryDTO = TransactionAssembler.toPointHistoryWithPointCategoryDTO(resultData, loyaltyStructure, storeService.fetchStoreList(storeCodeList));
        return ResponseEntity.ok(pointHistoryDTO);
    }

    @Override
    public ResponseEntity<PointHistoryDTO> findPointHistoryWithPointType(String id, String brand,
                                                                         String region, String channel, String pointType) {

        log.info("查找memberId为{},brand为{}用户的{}积分记录", id, brand, pointType);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        List<Transaction> list = accountService.findPointHistoryWithPointType(id, loyaltyStructure, pointType);

        PointHistoryDTO pointHistoryDTO = TransactionAssembler.listToPointHistoryDTO(list);

        return ResponseEntity.ok(pointHistoryDTO);
    }

    @Override
    public ResponseEntity<RedemptionAggregationRecordDto> findRedemptionAggregationWithPointType(
            String memberId, String brand, String region, String channel, String pointType,
            OffsetDateTime startAt, OffsetDateTime endAt) {
        log.info("查找memberId为{},brand为{}用户的{} 兑换聚合记录", memberId, brand, pointType);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);

        List<Redemption> redemptionList = accountService.findPointHistoryWithPointTypeAndTransactionType(
                memberId, loyaltyStructure, pointType, TransactionType.REDEMPTION,
                toLocalDateTimeAtDefaultZone(startAt),
                toLocalDateTimeAtDefaultZone(endAt)
        );
        List<Activity> activities = cacheService.fetchActivitiesByPointTypeAndLoyaltyStruct(pointType,
                loyaltyStructure.name());
        RedemptionAggregationRecordDto recordDto = TransactionAssembler.listToRedemptionAggregationDTO(redemptionList, activities);
        return ResponseEntity.ok(recordDto);
    }

    @Override
    public ResponseEntity<AccountTierDTO> findTier(String id, String brand, String region) {
//        String brandEnum =
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, id);
        if (account == null) {
            throw new SystemException("Can't find this user", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        TierLevelSeries.TierChangeType tierChangeType = loyaltyStructure.getTierLevelSeries().getTierChangeType();
        if(!tierChangeType.equals(TierLevelSeries.TierChangeType.BY_ORDER_AMOUNT) &&
                !tierChangeType.equals(TierLevelSeries.TierChangeType.BY_AMOUNT_POINT_MAX)){
            Map<String,Object> pointAboutExpireMap = transactionService.calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(account, brand, loyaltyStructure);
            return ResponseEntity.ok(AccountAssembler.toAccountTierDTO(account, loyaltyStructure, null, pointAboutExpireMap));
        }
        List<Order> orders = transactionService.findByLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                account.loyaltyId(), brand, TransactionType.ORDER,
                LocalDateTime.now().minusYears(loyaltyStructure.tierLevelSeries().getTierEffectiveYear()),
                LocalDateTime.now());
        orders = orders.parallelStream().filter(order -> !order.groupPurchaseIs()).collect(Collectors.toList());
        Double currentPoint = orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
        Map<String,Object> pointAboutExpireMap = transactionService.calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(account, brand, loyaltyStructure);
        AccountTierDTO accountTierDTO = AccountAssembler.toAccountTierDTO(account, loyaltyStructure, currentPoint.intValue(), pointAboutExpireMap);
        return ResponseEntity.ok(accountTierDTO);
    }

    /***
     * 查询等级历史信息的方法
     * @param id AM ID
     * @param brand 品牌
     * @param region 地区
     * @param bindId Bind id
     * @return
     */
    @Override
    public ResponseEntity<TierHistoryDTO> findTierHistory(String id, String brand, String region, String bindId) {
        //该接口永久废弃
        return new ResponseEntity<>(new TierHistoryDTO(), HttpStatus.GONE);
    }

    public void testFeignAm(String memberId) {
        String tenantId = "10002";

        //调用AM获取用户生日
        AmClient.RequestEntity requestEntity = new AmClient.RequestEntity(memberId, tenantId);
        String requestJson = JSON.toJSONString(requestEntity);
        log.info("Call Am-Service requestBody is {}", requestJson);
        AmClient.CallAmResponse response = amClient.queryProfile(requestEntity);
        log.info("Call Am-Service response is {}", response);
        if (!"0".equals(response.getResultCode())) {
            log.info("Failed to call Am-Service，this error is {}, this memberId is {}", response.getErrorMsg(), memberId);
            throw new SystemException(response.getErrorMsg(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
        String birthday = null;
        Map<String, Object> map = new HashMap<>(3);
        if (response.getObject().containsKey(BIRTHDAY)) {
            birthday = (String) response.getObject().get(BIRTHDAY);
            map.put(BIRTHDAY, birthday);
        }
        if (response.getObject().containsKey(CELLPHONE)) {
            String cellphone = (String) response.getObject().get(CELLPHONE);
            map.put(CELLPHONE, cellphone);
        }
        String fullName = null;
        if (response.getObject().containsKey("addresses")) {
            List<AmClient.AddressBean> addressBeans = (List<AmClient.AddressBean>) response.getObject().get("addresses");
            if (!CollectionUtils.isEmpty(addressBeans)) {
                String addressBeanStr = JSON.toJSONString(addressBeans.get(0));
                AmClient.AddressBean addressBean = JSON.parseObject(addressBeanStr, AmClient.AddressBean.class);
                fullName = addressBean.getFullName();
            }
            map.put("fullName", fullName);
        }

        String amJsonString = JSON.toJSONString(map);
        log.info("MapJson: {}", amJsonString);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate userBirthday = null;
        if (StringUtils.isNotEmpty(birthday)) {
            userBirthday = LocalDate.parse(birthday, fmt);
        }
        log.info("userBirthday: {}", userBirthday);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> findRedemptionHistoryForC2(String memberId, String brand, String region, String channel, Boolean isHotline, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page) {
        log.info("查找memberId为{},brand为{}用户的兑换礼品记录", memberId, brand);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        PageableResult<Redemption> pageableResult =
                accountService.findRedemptionHistoryForC2(memberId, brand, region,
                        toLocalDateTimeAtDefaultZone(startAt),
                        toLocalDateTimeAtDefaultZone(endAt),
                        perPage, page, isHotline);
        return getFetchRedemptionListDTOResponseEntity(structure, brand, pageableResult);
    }

    public static void main(String[] args) {
        System.out.println(RedemptionStatus.REJECTED.name());
    }
    @Override
    public ResponseEntity<FetchRedemptionListDTO> findRedemptionHistory(String id, String brand, String region,
                                                                        String channel, String bindId, OffsetDateTime startAt,
                                                                        OffsetDateTime endAt, Integer perPage,
                                                                        Integer page, String activityId, String  redemptionStatus, String valueType) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        log.info("查找memberId为{},brand为{}用户的兑换礼品记录", id, brand);
        PageableResult<Redemption> pageableResult;
        if(StringUtils.isEmpty(redemptionStatus)){
            pageableResult =
                    accountService.findRedemptionHistory(id, brand, region,
                            toLocalDateTimeAtDefaultZone(startAt),
                            toLocalDateTimeAtDefaultZone(endAt),
                            perPage, page, activityId, valueType);
        } else {
            List<String> redemptionStatuses = new ArrayList<>();
            if (StringUtils.equals(INVALID,redemptionStatus.toLowerCase(Locale.ROOT))){
                // 失效 查询取消、过期、拒绝
                redemptionStatuses.add(RedemptionStatus.REJECTED.name());
                redemptionStatuses.add(RedemptionStatus.CANCELED.name());
                redemptionStatuses.add(RedemptionStatus.EXPIRED.name());
            } else {
                redemptionStatuses.add(redemptionStatus.toUpperCase(Locale.ROOT));
            }
            pageableResult =
                    accountService.findRedemptionHistory(id, brand, region,
                            toLocalDateTimeAtDefaultZone(startAt),
                            toLocalDateTimeAtDefaultZone(endAt),
                            perPage, page, activityId, valueType,redemptionStatuses);
        }

        return getFetchRedemptionListDTOResponseEntity(structure, brand, pageableResult);
    }

    private ResponseEntity<FetchRedemptionListDTO> getFetchRedemptionListDTOResponseEntity(LoyaltyStructure
                                                                                                   structure, String brand, PageableResult<Redemption> pageableResult) {
        Map<String, Boolean> giftCancelableList = transactionService.fetchRedemptionCancelableStatus(pageableResult.getRecords());
        Map<String, Store> storeMap = new HashMap<>();
        Map<String, Gift> giftMap = new HashMap<>();
        for (Redemption redemption : pageableResult.getRecords()) {
            if (!brand.equals(redemption.brand())) {
                continue;
            }
            //查询柜台信息
            String storeCode = redemption.getStoreCode();
            if (!StringUtils.isEmpty(storeCode)) {
                storeMap.computeIfAbsent(storeCode, key -> cacheService.getStoreByStoreCode(storeCode));
            }
            //查询imageUri信息
            List<GiftItem> giftItemList = redemption.getGiftItemList();
            for (GiftItem giftItem : giftItemList) {
                if (!giftMap.containsKey(giftItem.getGiftId())) {
                    Gift gift = cacheService.getGiftById(giftItem.getGiftId());
                    if (gift != null) {
                        giftMap.put(giftItem.getGiftId(), gift);
                    }
                }
            }
        }
        FetchRedemptionListDTO fetchRedemptionListDTO = TransactionAssembler
                .toRedemptionListByFilterRedeemCode(structure, pageableResult, storeMap,
                        giftCancelableList, null, giftMap);
        return ResponseEntity.ok(fetchRedemptionListDTO);
    }

    @Override
    public ResponseEntity<FetchOrderListDTO> findOrdersHistory(String id, String brand, String region, String channel, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page) {
        log.info("查找memberId为{},brand为{}用户的订单记录", id, brand);
        PageableResult<Order> orderPageableResult = accountService.findOrdersHistory(id, brand, region,
                toLocalDateTimeAtDefaultZone(startAt),
                toLocalDateTimeAtDefaultZone(endAt),
                perPage, page);
        FetchOrderListDTO fetchOrderListDTO = TransactionAssembler.toFetchOrderListDTO(orderPageableResult);
        return ResponseEntity.ok(fetchOrderListDTO);
    }

    @Override
    public ResponseEntity<Void> mockApiCall(String mockId) {
        if (mockId.startsWith("pampersPoint")) {
            LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(BRAND, PAMPERS);
            jsonObject.put(LOYALTYID, "6bd79da56bbe0a774f172d56f69e26fe4");
            loyaltyMessage.setJsonObject(jsonObject);
            serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.EXPIRED_PAMPERS_POINT_USER_QUEUE_NAME, loyaltyMessage);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("pampersBirthday")) {
            LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put(LOYALTYID, "201ce6870bb739ce90ecb35aa90f48bd8");
            jsonObject.put("marketingProgramId", "46");
            jsonObject.put("babyBirthYearAndMonth", "201609");
            jsonObject.put(BRAND, PAMPERS);
            jsonObject.put("region", "TW");
            loyaltyMessage.setJsonObject(jsonObject);
            serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.PAMPERS_BABY_BIRTHDAY_MONTH_QUEUE_NAME, loyaltyMessage);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("pampersNotify")) {
            LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("pointType", "REGISTER");
            jsonObject.put("memberId", "JR1a4LMSLV4J");
            jsonObject.put(LOYALTYID, "a2405fc359f548d5c9ab9055cbdf0c1bJ");
            jsonObject.put("transactionId", "e27b1fc2afb341469d741e8505b281b1");
            jsonObject.put(BRAND, PAMPERS);
            jsonObject.put("lineId", "LINE1111");
            jsonObject.put("messageType", "");
            loyaltyMessage.setJsonObject(jsonObject);
            serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.HKTW_PAMPERS_NOTIFICATION_QUEUE, loyaltyMessage);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("merge")) {
            String[] memberId = mockId.split("-");
            operationService.memberMerge(memberId[1], memberId[2], "ML", BrandV2.OLAY);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("1")) {
            testFeignAm(mockId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("order")) {
            String testStrKethy = "{\"region\":\"ML\",\"transactions\":[{\"orderDateTime\":\"2020-07-27T00:00:00\",\"orderId\":\"1b456k0017\",\"channel\":\"COUNTER\",\"realTotalAmount\":1001.0,\"brand\":\"OLAY\",\"orderItems\":[{\"purchaseQty\":1,\"transactionType\":\"010\",\"realAmount\":260.0,\"refundQty\":0,\"sku\":\"82157678\",\"retailAmount\":260.0,\"refundAmount\":0}],\"storeCode\":\"V-PG-OLAY-VI-MM709\",\"refundAmount\":0}],\"brand\":\"OLAY\",\"memberId\":\"122000005749\"}";
            taskService.sendMessageToServiceBus(testStrKethy, ServiceBusQueueTopicEnum.OLAY_QUEUE_NAME);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("del")) {
            String redisKey = "";
            String[] memberId = mockId.split("-");
            if ("m".equalsIgnoreCase(memberId[1])) {
                redisKey = cacheService.getKey(CacheService.KeyEnum.NORMAL_ORDER, memberId[2], "OLAY", "ML");
            } else {
                redisKey = cacheService.getKey(CacheService.KeyEnum.ACTIVITY_POINT_TYPE, "ML_OLAY", memberId[2]);
            }
            stringRedisTemplate.delete(redisKey);
            log.info("clear true");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("phone")) {
            List<String> phones = Arrays.asList(mockId.split(","));
            String key = "PHONE:WHITE:LIST";
            String phonel = stringRedisTemplate.opsForValue().get(key);
            phonel = phonel + "," + phones.stream().collect(Collectors.joining(","));
            stringRedisTemplate.opsForValue().set(key, phonel);
            log.info("add true");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.startsWith("smsType")) {
            LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
            RedemptionServiceBusProperties busProperties = new RedemptionServiceBusProperties();
            busProperties.setActivityId("cdde26e19e4542349d4be7c86287f944");
            busProperties.setMemberId("100000254815");
            busProperties.setRedemptionId("23a6b1ec4a084422b5ce80b6c0d145b9");
            busProperties.setAddress("南京的上海路，上海的南京路");
            busProperties.setLoyaltyId("8227e39212e4487e911991a82c279d5a");
            busProperties.setGiftNames("giftNames,giftNames");
            busProperties.setRedeemCode("SSSXXXX");
            busProperties.setBrand("OLAY");
            busProperties.setStoreName("storeName拉拉");
            busProperties.setLoyaltyStructure("ML_OLAY");
            if (mockId.equalsIgnoreCase("smsType11")) {
                busProperties.setType("NORMAL");
            } else if (mockId.equalsIgnoreCase("smsType22")) {
                busProperties.setType("TRANSFER_TO_COUNTER");
            } else {
                busProperties.setType("TRANSFER_TO_HOME");
            }
            JSONObject jsonObject = JSON.parseObject(JSON.toJSONString(busProperties));
            jsonObject.put("smsType", "tierChanged");
            jsonObject.put("preLevel", "ML_OLAY_2");
            jsonObject.put("tierLevel", "ML_OLAY_3");
            loyaltyMessage.setJsonObject(jsonObject);
            serviceBusTemplate.sendMessageAsync(ServiceBusQueueTopicEnum.SEND_MESSAGE_TO_CONSUMER_BY_SMS, loyaltyMessage);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        if (mockId.equals("refreshGiftIssuedNum")) {
            Iterable<Activity> all = activityRepository.findAll();
            for (Activity activity : all) {
                String activityId = activity.activityId();
                if (activity.getTransactionType() == TransactionType.REDEMPTION) {
                    Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
                    for (Map.Entry<String, RedemptionItem> entry : redemptionItemMap.entrySet()) {
                        String giftId = entry.getKey();
                        String key = GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
                        RedemptionItem redemptionItem = entry.getValue();
                        int issuedNum = redemptionItem.getIssuedNum();
                        stringRedisTemplate.opsForValue().set(key, String.valueOf(issuedNum));
                    }
                }
            }
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @Override
    public ResponseEntity<Void> updateAccountStatusBymemberId(String authorization, String memberId, UpdateAccountCommand updateAccountCommand) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info("MethodName{},操作用户{}", "updateAccountStatusBymemberId", userName);
        accountService.updateAccountStatusByMemberId(memberId, updateAccountCommand.getBrand(),
                updateAccountCommand.getRegion(), updateAccountCommand.getStatus().name());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateAccountProfileByMemberId(String memberId,
                                                               UpdateAccountProfileCommand updateAccountProfileCommand,
                                                               String authorization) {
        log.info("memberId为{}的用户,传入的更新字段为{}", memberId, updateAccountProfileCommand);
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info("MethodName{},操作用户{}", "updateAccountStatusBymemberId", userName);
        accountService.updateAccountProfileByMemberId(memberId,
                updateAccountProfileCommand.getBrand(),
                updateAccountProfileCommand.getRegion(),
                updateAccountProfileCommand.getBabyBirthYearAndMonth());
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> setAccountOpt(String memberId, AccountOptCommand command) {
        accountAppService.addAccountOpts(memberId, command.getBrand(),
                command.getRegion(), AccountAssembler.toOptNode(command));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<InteractionCountDTO> countMemberInteractionTimesByPointType(String id, String brand,
                                                                                      String region, String pointType) {

        log.info("查找memberId为{},brand为{}用户的{}积分记录", id, brand, pointType);

        int interactionTimes = accountService.countMemberInteractionTimesByPointType(id, region, brand, pointType);

        InteractionCountDTO interactionCountDTO = TransactionAssembler.listToInteractionCountDTO(interactionTimes);

        return ResponseEntity.ok(interactionCountDTO);
    }

    @Override
    public ResponseEntity<AccountAttrListDTO> fetchAccountAttr(FetchAccountAttrCommand fetchAccountAttrCommand) {
        LoyaltyStructure loyaltyStructure = cacheService
                .findLoyaltyStructure(fetchAccountAttrCommand.getRegion(),
                        fetchAccountAttrCommand.getBrand());

        List<Account> accountList = accountService.fetchAccountAttr(loyaltyStructure,
                fetchAccountAttrCommand.getMemberIdList());
        AccountAttrListDTO accountAttrListDTO = AccountAssembler.toAccountAttrListDTO(loyaltyStructure, accountList);
        return ResponseEntity.ok(accountAttrListDTO);
    }


    /**
     * @see AccountsApi#findMemberActivityPoint
     */
    @Override
    public ResponseEntity<AccountActivityPointDto> findMemberActivityPoint( String  memberId,
                                                                             String  brand,
                                                                             String  region,
                                                                             String  activityId,
                                                                             String  channel) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        int pointAvailable = account.availablePoint(loyaltyStructure.accountTypeOfDefault());
        Activity activity = cacheService.findActivityById(activityId);
        if (activity == null) {
            throw new SystemException("The passed activity ID does not exist", ResultCodeMapper.PARAM_ERROR);
        }
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        int pointLockDay = redemptionProperties.getOrderLockDay();
        //锁定积分
        List<Order> listOrder = orderRepositoryV2.findOrdersByOrderDateTimeBetween(account.loyaltyId(),
                LocalDateTime.now().minusDays(pointLockDay),
                LocalDateTime.now());
        List<Order> orders = Optional.ofNullable(listOrder).orElse(new ArrayList<>());
        int lockPoint = orders.stream().mapToInt(Order::point).sum();
        //锁定积分，可用积分  account积分-锁定积分=可用积分
        AccountActivityPointDto accountActivityPointDto = new AccountActivityPointDto();
        accountActivityPointDto.setLockedPoint(lockPoint);
        accountActivityPointDto.setActivityAvailPoint(Math.max(pointAvailable - lockPoint,0));
        return ResponseEntity.ok(accountActivityPointDto);
    }

    @Override
    public ResponseEntity<AvailablePointPoolDTO> findAvailablePointPoolByMemberId(String memberId, String brand, String region) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        AvailablePointPoolDTO availablePointPoolDTO = AccountAssembler.toAvailablePointPoolDTO(account);
        return ResponseEntity.ok(availablePointPoolDTO);
    }
}
