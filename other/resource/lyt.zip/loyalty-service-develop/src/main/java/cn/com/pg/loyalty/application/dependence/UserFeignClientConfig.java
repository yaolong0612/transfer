package cn.com.pg.loyalty.application.dependence;

import feign.Client;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.ssl.SSLContexts;
import org.springframework.cloud.netflix.ribbon.SpringClientFactory;
import org.springframework.cloud.openfeign.ribbon.CachingSpringLoadBalancerFactory;
import org.springframework.cloud.openfeign.ribbon.LoadBalancerFeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.net.ssl.SSLContext;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-09 10:36
 */

@Profile("dev")
@Configuration
@Slf4j
public class UserFeignClientConfig {

    @Bean
    public Client feignClient(CachingSpringLoadBalancerFactory cachingFactory, SpringClientFactory clientFactory) {
        try {
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(new TrustAllStrategy()).build();
            return new LoadBalancerFeignClient(new Client.Default(sslContext.getSocketFactory(), new NoopHostnameVerifier()),
                    cachingFactory, clientFactory);
        } catch (Exception e) {
            log.error("", e);
            return null;
        }
    }
}
