package cn.com.pg.loyalty.infrastructure.json;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import com.alibaba.fastjson.serializer.ValueFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.UnaryOperator;

@Slf4j
public class DesensitizedSerializeByFieldNameFilter implements ValueFilter {


    @Override
    public Object process(Object object, String name, Object value) {
        try {
            if(!(value instanceof String)) {
                return value;
            }
            return FieldType.judgeType(name).desensitizedValue(value);
        } catch (Exception e) {
            log.error("desensitized error: {}", e.getMessage(), e);
            return value;
        }
    }

    enum FieldType {
        DEFAULT(new ArrayList<>(1), value -> value),
        MOBILE(Arrays.asList("mobile", "phone"), DesensitizedUtils::mobilePhone),
        FULL_NAME(Arrays.asList("fullName", "receiver"), DesensitizedUtils::fullName),
        ADDRESS(Arrays.asList("address"), address -> DesensitizedUtils.address(address, address.length())),
        EMAIL(Arrays.asList("email"), DesensitizedUtils::email);

        private List<String> fieldNameList;
        private UnaryOperator<String> function;

        FieldType(List<String> fieldNameList, UnaryOperator<String> function) {
            this.fieldNameList = fieldNameList;
            this.function = function;
        }

        public static FieldType judgeType(String name) {
            FieldType[] fieldTypeList = FieldType.values();
            for(FieldType fieldType : fieldTypeList){
                if(fieldType.contains(name)){
                    return fieldType;
                }
            }
            return DEFAULT;
        }

        private boolean contains(String name) {
            if (StringUtils.isEmpty(name)) {
                return false;
            }
            return fieldNameList.contains(name);
        }

        private String desensitizedValue(Object value) {
            if (Objects.isNull(value) ) {
                return "";
            }
            return function.apply((String) value);
        }
    }
}
