package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderRepository;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
@Rule(name = "recalculate tier rule",
        description = "recalculate tier rule")
public class RecalculateTierRule {

    private static final Map<String, String> brandMap = new HashMap<>();
    private static final String REGION_ML = "ML";
    static {
        brandMap.put(BrandV2.OPTE, REGION_ML);
        brandMap.put(BrandV2.LA, REGION_ML);
        brandMap.put(BrandV2.PAMPERS, REGION_ML);
    }

    @Condition
    public boolean isExecuteRule(@Fact("account") Account account,
                                 @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        // 会员过期才能执行该规则
        return brandMap.entrySet().stream().anyMatch(set -> loyaltyStructure.contain(set.getValue(), set.getKey()))
                && account.tier(loyaltyStructure.name()) != null
                && LocalDateTime.now().isAfter(account.tier(loyaltyStructure.name()).getExpiredTime());
    }

    @Action
    public void execute(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("orderRepository") OrderRepository orderRepository) {

        //获取当前等级
        Tier tier = account.tier(loyaltyStructure.name());
        //获取等级有效期
        int tierEffectiveYear = loyaltyStructure.getTierLevelSeries().getTierEffectiveYear();
        //查询未过期的历史订单
        List<Order> orders = getHistoryOrdersThatNotExpired(account.loyaltyId(),
                loyaltyStructure.getBrands().get(0), orderRepository,tierEffectiveYear);
        //计算有效金额
        double realTotalAmount = orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
        // 重算等级
        String calculationLevel = calculationLevel(loyaltyStructure,tier, (int) realTotalAmount);
        Tier newTier = new Tier(loyaltyStructure, calculationLevel, tier.getLevel());
        account.tier(loyaltyStructure, newTier);
        log.info("等级过期计算结束：MemberId:{},更新前上一次等级:{},当前等级{},更新后的等级{},过期时间{}", account.memberId(),
                tier.getPreLevel(), newTier.getPreLevel(), newTier.getLevel(), newTier.getExpiredTime());
    }

    private List<Order> getHistoryOrdersThatNotExpired(String loyaltyId, String brand,
                                                       OrderRepository orderRepository,int tierEffectiveYear) {

        String startTime = LoyaltyDateTimeUtils.localDateTimeToDateString(LocalDateTime.now().minusYears(tierEffectiveYear));
        String endTime = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.now());
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                partitionKey, loyaltyId, brand, TransactionType.ORDER, startTime, endTime);
    }

    /**
     * 根据有效订单金额计算会员等级
     *
     * @param currentTier     当前会员等级
     * @param effectiveAmount 有效订单金额
     * @return 会员等级
     */
    private String calculationLevel(LoyaltyStructure structure, Tier currentTier, int effectiveAmount) {
        TierLevelSeries levelSeries = structure.tierLevelSeries();
        String currentLevel = currentTier.getLevel();
        String nextLevel = levelSeries.nextLevelByAmount(currentTier.getLevel(), currentTier.getTierPoint()).getLevelName();
        while (levelSeries.compare(currentLevel, nextLevel) != 0) {
            currentLevel = nextLevel;
            nextLevel = levelSeries.nextLevelByAmount(nextLevel,effectiveAmount).getLevelName();
        }
        return nextLevel;
    }

}
