package cn.com.pg.loyalty.domain.activity.prop;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author linbj
 * @date 2020/6/2 15:20
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TierMultipleRuleProperties extends RuleProperties {
    private String tierLevel; //会员等级
    private Double multiple; //等级倍数
}
