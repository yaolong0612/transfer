package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.gift.*;
import cn.com.pg.loyalty.domain.gift.GiftCoupon.CouponStatus;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.RegionV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.interfaces.dto.FetchRedemptionDTO;
import cn.com.pg.loyalty.interfaces.dto.GiftCouponCommand;
import cn.com.pg.loyalty.interfaces.dto.Language;
import cn.com.pg.loyalty.interfaces.dto.RedemptionGiftDTO;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * @author: Ysnow
 * @Date: 2019/4/29 15:18
 * @Description:
 */
@Service
@Slf4j
public class GiftService {

    @Autowired
    private GiftRepository giftRepository;

    @Autowired
    private CacheService cacheService;


    @Autowired
    private GiftCouponService giftCouponService;


    public Gift addGift(Gift gift) {
        return giftRepository.save(gift);
    }

    /**
     * 更新礼品信息
     */
    public Gift updateGift(Gift newGift) {
        List<Gift> giftList = giftRepository.findGiftById(newGift.getId());
        if (CollectionUtils.isEmpty(giftList)) {
            throw new SystemException("The update gift failed without the gift ID", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        Gift gift = giftList.get(0);
        gift.updateGift(newGift);
        log.info("Update gift information,this gift:{}", gift);
        Gift updatedGift = giftRepository.save(gift);
        cacheService.removeGiftById(gift.getId());
        return updatedGift;
    }

    /**
     * 根据giftId删除礼品数据
     *
     * @param giftId
     */
    public Gift deleteGiftById(String giftId) {
        List<Gift> giftList = giftRepository.findGiftById(giftId);
        if (CollectionUtils.isEmpty(giftList)) {
            throw new SystemException("The update gift failed without the gift ID", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        Gift gift = giftList.get(0);
        log.info("Deleting gift, gift ID is:{}", giftId);
        giftRepository.delete(gift);
        cacheService.removeGiftById(giftId);
        return gift;
    }

    /**
     * 获取商品列表
     *
     * @param brand
     * @param region
     * @param name
     * @param page
     * @param pageSize
     * @return
     */
    public PageableResult<Gift> fetchGiftList(String brand, String region, String name, String giftId, Integer pageSize, Integer page) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        List<Gift> gifts;
        if (giftId != null && name != null) {
            gifts = giftRepository.findByIdStartsWithAndNameStartsWithAndLoyaltyStructure(giftId, name, structure.name());
        } else if (giftId != null) {
            gifts = giftRepository.findByIdStartsWithAndLoyaltyStructure(giftId, structure.name());
        } else if (name != null) {
            gifts = giftRepository.findByNameIsStartingWithAndLoyaltyStructure(name, structure.name());
        } else {
            gifts = giftRepository.findByLoyaltyStructure(structure.name());
        }
        Comparator<Gift> comparator = Comparator.comparing(Gift::getUpdatedTime).reversed();
        return cacheService.generatePage(page, pageSize, gifts, comparator);
    }

    /**
     * 根据giftId查找礼品
     *
     * @param giftId
     * @return
     */
    public Gift findGiftById(String giftId) {
        List<Gift> giftList = giftRepository.findGiftById(giftId);
        if (CollectionUtils.isEmpty(giftList)) {
            throw new SystemException("The giftId is not be found ! giftId: ".concat(giftId), ResultCodeMapper.GIFT_NOT_FOUND);
        }
        return giftList.get(0);
    }

    public void addGiftCoupon(GiftCouponCommand command) {
        GiftCoupon giftCoupon = new GiftCoupon.Builder(command.getSku(), command.getGiftName(),
                command.getCouponCode(), command.getStoreName(), command.getPrice())
                .belong(command.getRegion(), command.getBrand())
                .validityDate(command.getStartAt(), command.getEndAt())
                .status(CouponStatus.ALIVE).build();
        //添加英文多语言
        if (StringUtils.isNotEmpty(command.getEnglishStoreName())) {
            GiftCoupon.GiftCouponDisplayMsg giftCouponDisplayMsg = new GiftCoupon.GiftCouponDisplayMsg(ParamValidator.validateLanguage(Language.EN_US.name()), command.getEnglishStoreName());
            giftCoupon.addGiftCouponDisplayMsg(Collections.singletonList(giftCouponDisplayMsg));
        }
        giftCouponService.addCoupon(giftCoupon);
    }

    public GiftCoupon findOneGiftCouponByBagSku(String bagSku, String brand, String region) {
        return giftCouponService.findGiftCouponByBagSku(bagSku, brand, region);
    }

    public Gift findByGiftBagSku(String bagSku, LoyaltyStructure loyaltyStructure) {
        List<Gift> gifts = giftRepository.findByBagSkuAndLoyaltyStructure(bagSku, loyaltyStructure.name());
        if (CollectionUtils.isNotEmpty(gifts)) {
            return gifts.get(0);
        }
        return null;
    }

    public void translateGiftCouponForHkPampers(String language, String region, String brand, List<RedemptionGiftDTO> records) {
        if (RegionV2.isHkRegionOrTwRegion(region) && BrandV2.PAMPERS.equals(brand) && CollectionUtils.isNotEmpty(records)) {
            Locale locale = ParamValidator.validateLanguage(language);
            for (RedemptionGiftDTO redemptionGiftDTO : records) {
                String storeName = Optional.ofNullable(this.findGiftById(redemptionGiftDTO.getGiftId()))
                        .map(item -> this.findOneGiftCouponByBagSku(item.getBagSku(), brand, region))
                        .map(item -> {
                            item.translateByLanguage(locale);
                            return item.getStoreName();
                        })
                        .orElse(null);
                redemptionGiftDTO.setStoreName(storeName);
            }
        }
    }

    public void translateGiftCouponForHkPampersRedemption(String language, String region, String brand, List<FetchRedemptionDTO> fetchRedemptionDTOList) {
        if (RegionV2.isHkRegionOrTwRegion(region) && BrandV2.PAMPERS.equals(brand) && CollectionUtils.isNotEmpty(fetchRedemptionDTOList)) {
            for (FetchRedemptionDTO fetchRedemptionDTO : fetchRedemptionDTOList) {
                Locale locale = ParamValidator.validateLanguage(language);
                GiftCoupon giftCoupon = giftCouponService.findByRegionAndBrandAndCouponCode(region, brand, fetchRedemptionDTO.getRedeemCode());
                if (giftCoupon != null) {
                    giftCoupon.translateByLanguage(locale);
                    fetchRedemptionDTO.setStoreName(giftCoupon.getStoreName());
                }
            }
        }
    }

    public Gift checkLoadGift(String giftId) {
        Gift gift = cacheService.getGiftById(giftId);
        if (gift == null) {
            throw new SystemException("The gift has been deleted by mistake. System error", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        return gift;
    }
}
