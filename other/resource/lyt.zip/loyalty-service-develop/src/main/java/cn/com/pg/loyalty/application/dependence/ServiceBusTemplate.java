package cn.com.pg.loyalty.application.dependence;


import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.ServiceBusConfig;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.Message;
import com.microsoft.azure.servicebus.QueueClient;
import com.microsoft.azure.servicebus.TopicClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * @author tangjia
 * @date 2019/6/6
 * @description ServiceBusTemplate
 */
@Slf4j
@Component
public class ServiceBusTemplate {

    @Autowired
    private ServiceBusConfig serviceBusConfig;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private KpiTemplate kpiTemplate;
    @Value("${serviceBus.generalLabel}")
    private String serviceBusGeneralLabel;
    public static final String MSG_REDIS_KEY = "REDISKEY";
    private static final String MEDIA_TYPE_JSON = "application/json";

    public void sendMessageAsync(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, LoyaltyMessage loyaltyMessage) {
        sendMessageAsync(serviceBusQueueTopicEnum, loyaltyMessage, null);
    }
    /**
     * @param serviceBusQueueTopicEnum 队列名称
     * @param loyaltyMessage           消息格式化对象
     */
    public void sendMessageAsync(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, LoyaltyMessage loyaltyMessage, LocalDateTime localDateTime) {
        long start = System.currentTimeMillis();
        LocalDateTime startDateTime = LocalDateTime.now();
        boolean isSuccess = true;
        int errorCode = ResultCodeMapper.SUCCESS.getCode();
        String errorMessage = "Success";
        String messageId = null;
        String correlationId = RequestContext.getCurrentContext().getCorrelationId();
        try {
            QueueClient queueClient = serviceBusConfig.getQueueClient(serviceBusQueueTopicEnum);
            IMessage message = generateMsg(loyaltyMessage, correlationId);
            if (localDateTime !=  null) {
                Instant instant = localDateTime.minusHours(8).toInstant(ZoneOffset.UTC);
                message.setScheduledEnqueueTimeUtc(instant);
            }
            messageId = message.getMessageId();
            queueClient.sendAsync(message).thenRunAsync(() -> {
                // 异步发送消息回调发送kpi
                //TODO 这个地方后面需要做监控
                long costTime = System.currentTimeMillis() - start;
                log.info("Send Message QueueName: {}, Cost: {}, isSuccess: {}, messageId: {}, errorMsg: {}",
                        serviceBusQueueTopicEnum.queueOrTopicName(), costTime, true, message.getMessageId(), errorMessage);

            });
        } catch (Exception e) {
            log.error("send message async error", e);
            isSuccess = false;
            errorCode = ResultCodeMapper.SEND_MESSAGE_ERROR.getCode();
            throw new SystemException(e.getMessage(), ResultCodeMapper.SEND_MESSAGE_ERROR);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            if (!isSuccess || costTime > 100) {
                Map<String, String> properties = new HashMap<>(1);
                properties.put("messageId", messageId);
                kpiTemplate.sendDependency(correlationId, serviceBusQueueTopicEnum.queueOrTopicName(),
                        KpiLog.KpiType.SEND_SERVICE_BUS, startDateTime, costTime,
                        String.valueOf(errorCode), errorMessage, isSuccess, properties);
                log.info("Send Message QueueName: {}, Cost: {}, isSuccess: {}, messageId: {}, errorMsg: {}",
                        serviceBusQueueTopicEnum.queueOrTopicName(), costTime, isSuccess, messageId, errorMessage);
            }
        }
    }

    public void sendMessage(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, LoyaltyMessage loyaltyMessage) {
        sendMessage( serviceBusQueueTopicEnum,  loyaltyMessage, null);
    }
    /**
     * @param serviceBusQueueTopicEnum
     * @param loyaltyMessage
     */
    public void sendMessage(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, LoyaltyMessage loyaltyMessage, LocalDateTime localDateTime) {
        long start = System.currentTimeMillis();
        String messageId = null;
        String correlationId = RequestContext.getCurrentContext().getCorrelationId();
        LocalDateTime startDateTime = LocalDateTime.now();
        String resultCode = String.valueOf(ResultCodeMapper.SUCCESS.getCode());
        String errorMessage = "Success";
        boolean isSuccess = true;
        try {
            QueueClient queueClient = serviceBusConfig.getQueueClient(serviceBusQueueTopicEnum);
            IMessage message = generateMsg(loyaltyMessage, correlationId);
            if (localDateTime !=  null) {
                Instant instant = localDateTime.minusHours(8).toInstant(ZoneOffset.UTC);
                message.setScheduledEnqueueTimeUtc(instant);
            }
            messageId = message.getMessageId();
            queueClient.send(message);
        } catch (Exception e) {
            log.error("send message is error: {}", e.getMessage(), e);
            resultCode = String.valueOf(ResultCodeMapper.SEND_MESSAGE_ERROR.getCode());
            errorMessage = "Send Failed";
            isSuccess = false;
            throw new SystemException(e.getMessage(), ResultCodeMapper.SEND_MESSAGE_ERROR);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            if (!isSuccess || costTime > 100) {
                Map<String, String> properties = new HashMap<>(1);
                properties.put("messageId", messageId);
                kpiTemplate.sendDependency(correlationId, serviceBusQueueTopicEnum.queueOrTopicName(),
                        KpiLog.KpiType.SEND_SERVICE_BUS, startDateTime, costTime,
                        resultCode, errorMessage, isSuccess, properties);
            }
            log.info("Send Message QueueName: {}, Cost: {}, isSuccess: {}, msgId: {}, errorMsg: {}",
                    serviceBusQueueTopicEnum.queueOrTopicName(), costTime, isSuccess, messageId, errorMessage);
        }
    }

    /**
     * 消息消费失败，释放锁，让消息再次消费
     *
     * @param serviceBusQueueTopicEnum
     * @param iMessage
     * @return
     */
    public CompletableFuture<Void> abandonAsync(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, IMessage iMessage) {
        QueueClient queueClient = serviceBusConfig.getQueueClient(serviceBusQueueTopicEnum);
        return queueClient.abandonAsync(iMessage.getLockToken());
    }

    /**
     * 消息消费成功，删除消息
     *
     * @param serviceBusQueueTopicEnum
     * @param iMessage
     * @return
     */
    public CompletableFuture<Void> completeAsync(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, IMessage iMessage) {
        QueueClient queueClient = serviceBusConfig.getQueueClient(serviceBusQueueTopicEnum);
        return queueClient.completeAsync(iMessage.getLockToken());
    }

    /**
     * 发布订阅
     *
     * @param serviceBusQueueTopicEnum 发布的topic
     * @param loyaltyMessage           loyalty 消息
     */
    public void sendTopicMessage(ServiceBusQueueTopicEnum serviceBusQueueTopicEnum, LoyaltyMessage loyaltyMessage) {
        long start = System.currentTimeMillis();
        try {
            loyaltyMessage.setUpdateTime(LocalDateTime.now());
            loyaltyMessage.setCreateDate(LocalDate.now().toString());
            IMessage message = new Message(JSON.toJSONString(loyaltyMessage).getBytes());
            message.setContentType(MEDIA_TYPE_JSON);
            message.setLabel(serviceBusGeneralLabel);
            log.info("send message success: {}", message.getMessageId());
            TopicClient topicClient = serviceBusConfig.getTopicClient(serviceBusQueueTopicEnum);
            topicClient.sendAsync(message).thenRunAsync(() -> log.info("Message acknowledged: Id = {}", message.getMessageId()));
        } catch (Exception e) {
            log.error("publish message is error: {}", e.getMessage(), e);
            throw new SystemException(e.getMessage(), ResultCodeMapper.SEND_MESSAGE_ERROR);
        } finally {
            log.info("publish Message QueueName: {}, Cost: {}", serviceBusQueueTopicEnum, System.currentTimeMillis() - start);
        }
    }

    private IMessage generateMsg(LoyaltyMessage loyaltyMessage, String correlationId) {
        loyaltyMessage.setUpdateTime(LocalDateTime.now());
        loyaltyMessage.setCreateDate(LocalDate.now().toString());
        String messageString = JSON.toJSONString(loyaltyMessage);
        long length = messageString.getBytes().length / 1024;
        String redisMessage = JSON.toJSONString(loyaltyMessage.getJsonObject());
        int size = 190;
        if (length >= size) {
            String redisKey = UUID.randomUUID().toString();
            stringRedisTemplate.opsForValue().set(redisKey, redisMessage, 3, TimeUnit.DAYS);
            JSONObject redisKeyBody = new JSONObject();
            redisKeyBody.put(MSG_REDIS_KEY, redisKey);
            loyaltyMessage.setJsonObject(redisKeyBody);
        }
        IMessage message = new Message(JSON.toJSONString(loyaltyMessage).getBytes());
        message.setLabel(serviceBusGeneralLabel);
        message.setContentType(MEDIA_TYPE_JSON);
        message.setCorrelationId(correlationId);
        return message;
    }
}
