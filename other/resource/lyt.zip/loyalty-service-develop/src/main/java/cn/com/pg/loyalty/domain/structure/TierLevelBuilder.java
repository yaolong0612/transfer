package cn.com.pg.loyalty.domain.structure;

public class TierLevelBuilder {
    private int level;
    private String levelName;
    private String levelAlias;
    private int gradingAmount;
    private int upgradeAmount;
    private int gradingPoint;
    private int upgradePoint;
    private int gradingAward;
    private int upgradeAward;

    public TierLevelBuilder level(int level) {
        this.level = level;
        return this;
    }

    public TierLevelBuilder levelName(String levelName) {
        this.levelName = levelName;
        return this;
    }

    public TierLevelBuilder levelAlias(String levelAlias) {
        this.levelAlias = levelAlias;
        return this;
    }

    public TierLevelBuilder gradingAmount(int gradingAmount) {
        this.gradingAmount = gradingAmount;
        return this;
    }

    public TierLevelBuilder upgradeAmount(int upgradeAmount) {
        this.upgradeAmount = upgradeAmount;
        return this;
    }

    public TierLevelBuilder gradingPoint(int gradingPoint) {
        this.gradingPoint = gradingPoint;
        return this;
    }

    public TierLevelBuilder upgradePoint(int upgradePoint) {
        this.upgradePoint = upgradePoint;
        return this;
    }

    public TierLevelBuilder gradingAward(int gradingAward) {
        this.gradingAward = gradingAward;
        return this;
    }

    public TierLevelBuilder upgradeAward(int upgradeAward) {
        this.upgradeAward = upgradeAward;
        return this;
    }

    public TierLevel createTierLevel() {
        TierLevel tierLevel= new TierLevel(level, levelName, levelAlias);
        tierLevel.levelPointRange(gradingPoint,upgradePoint);
        tierLevel.levelAmountRange(gradingAmount,upgradeAmount);
        tierLevel.awardPoint(gradingAward,upgradeAward);
        return tierLevel;
    }
}