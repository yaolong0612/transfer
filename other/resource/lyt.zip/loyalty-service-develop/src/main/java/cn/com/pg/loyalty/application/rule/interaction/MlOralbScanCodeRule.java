package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @description: OrlaB产品扫码rule
 * @author: Jevons Chen
 * @date: 2020-06-22 17:42
 */

@Rule(name = "Interaction rule: OralB scanCode rule",
        description = "Add Point by scanning the qrCode inside the goods")
@Slf4j
public class MlOralbScanCodeRule {
    private static final String REDIS_KEY_PREFIX = "ORALB:SCANCODE:";
    private static final long EXPIRE_TIME_SECONDS = 5L;
    private static final String SCAN_CODE_DISTRIBUTED_LOCK = "ORALB_SCANCODE_DISTRIBUTED-LOCK";


    @Condition
    public boolean isMlOralbScanCodeRule(@Fact("pointType") PointType pointType) {
        return pointType.ruleTemplate() == RuleTemplate.ML_ORALB_INTERACTION_SCAN_CODE_PLUS_POINT;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("sku") String sku,
                         @Fact("qrCode") String qrCode,
                         @Fact("interaction") Interaction interaction,
                         @Fact("pointType") PointType pointType,
                         @Fact("cacheService") CacheService cacheService,
                         @Fact("stringRedisTemplate") StringRedisTemplate stringRedisTemplate,
                         @Fact("ruleResult") RuleResult ruleResult) {
        Activity activity = activities.get(0);
        try {
            checkParams(activity, sku, qrCode, stringRedisTemplate, cacheService);
        } catch (SystemException se) {
            ruleResult.addException(se);
            return;
        }

        Optional<QrcodeItem> skuResult  = activity.getQrcodeItems().stream()
                .filter(qrCodeItem -> qrCodeItem.equalsThisSku(sku)).findFirst();
        QrcodeItem qrcodeItem = skuResult.isPresent() ? skuResult.get() : null;
        if (qrcodeItem == null) {
            ruleResult.addException(new SystemException("The sku of code scanning is not found in configured activities[" + sku + "]", ResultCodeMapper.ACTIVITY_NOT_FOUND_SCANCODE_SKU));
            return;
        }
        //获取基础积分
        int addPoint = qrcodeItem.basePoint();
        log.info("扫码基础分：{}, 总加积分：{}", qrcodeItem.basePoint(), addPoint);

        //创建交互记录
        interaction.scanCode(activity, addPoint, qrCode, sku, pointType);
        ruleResult.success();
    }

    private void checkParams(Activity activity, String sku, String qrCode, StringRedisTemplate stringRedisTemplate, CacheService cacheService) {
        //检查扫码基本参数
        if (StringUtils.isEmpty(sku) || StringUtils.isEmpty(qrCode)) {
            throw new SystemException("Errors occur in the params of scanning code,qrCode:" + qrCode + ",SKU:" + sku, ResultCodeMapper.PARAM_ERROR);
        }

        //通过分布式锁以防止扫码频繁
        String key = new StringBuilder(REDIS_KEY_PREFIX).append(":").append(qrCode).toString();
        Boolean isExists = stringRedisTemplate.opsForValue().setIfAbsent(key, SCAN_CODE_DISTRIBUTED_LOCK, EXPIRE_TIME_SECONDS, TimeUnit.SECONDS);
        if (null != isExists && !isExists) {
            throw new SystemException("Scanning QR code too frequently:" + qrCode + "，retry after a while please", ResultCodeMapper.SCAN_CODE_TOO_FAST);
        }
        //检查qrCode是否90天内是否扫过
        cacheService.checkQrCode(activity.getLoyaltyStructure(), qrCode);
    }
}
