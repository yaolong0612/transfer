package cn.com.pg.loyalty.domain.gift;


/**
 * 分布式场景，coupon code 分配
 * 使用分配池进行分配与报废池进行校验，防止初始化因为竞争，导致码重复使用。
 */
public interface CouponPool {

    void checkAndInit(String sku, String region, String brand);

    void rollCouponCodeInPool(String sku, String region, String brand, String couponCode);

    GiftCoupon allotGiftCoupon(String sku, String region, String brand);

}
