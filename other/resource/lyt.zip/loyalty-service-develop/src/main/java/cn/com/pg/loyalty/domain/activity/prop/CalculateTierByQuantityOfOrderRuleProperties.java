package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;

@Getter
@Setter
@NoArgsConstructor
public class CalculateTierByQuantityOfOrderRuleProperties extends RuleProperties{

    // 订单数量
    private int quantity;

    // 升级到指定等级
    private String tierLevel;

    private String minTier;

    @Min(1)
    private int countYear;

    public CalculateTierByQuantityOfOrderRuleProperties(int quantity, String tierLevel) {
        this.quantity = quantity;
        this.tierLevel = tierLevel;
    }

    public CalculateTierByQuantityOfOrderRuleProperties(int quantity, String tierLevel, String minTier, int countYear) {
        this.quantity = quantity;
        this.tierLevel = tierLevel;
        this.minTier = minTier;
        this.countYear = countYear;
    }
}
