package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.transaction.Redemption;

import java.util.Map;
import java.util.Set;

public interface GiftIssuedInventory {

    Long issuedGifts(Redemption redemption, Map<String,RedemptionItem> redemptionItemMap);

    void checkAndSyncIssuedInventory(Redemption redemption,Activity activity);

    void refundIssuedInventory(Redemption redemption);

    Map<String,Integer> fetchGiftsIssued(String activityId, Set<String> ids);
}
