package cn.com.pg.loyalty.domain.structure;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RegionV2 extends Config {

    public RegionV2(String name, String description) {
        super("REGION", name, description);
    }

    public static boolean isMlRegion(String region){
        return "ML".equals(region);
    }

    public static boolean isHkRegion(String region) {
        return "HK".equals(region);
    }

    public static boolean isTwRegion(String region) {
        return "TW".equals(region);
    }

    public static boolean isJpRegion(String region) {
        return "JP".equals(region);
    }

    public static boolean isHkRegionOrTwRegion(String region) {
        return isHkRegion(region) || isTwRegion(region);
    }
}
