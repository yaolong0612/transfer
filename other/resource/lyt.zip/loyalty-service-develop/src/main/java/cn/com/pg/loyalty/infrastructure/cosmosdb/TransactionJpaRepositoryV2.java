package cn.com.pg.loyalty.infrastructure.cosmosdb;


import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionJpaRepositoryV2 extends DocumentDbRepository<Transaction, String> {

    List<Transaction> findByPartitionKeyAndLoyaltyIdAndUnlockTimeGreaterThan(String pk, String loyaltyId, String start);

    List<Transaction> findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween(String pk, String loyaltyId, String start, String end);

    List<Transaction> findByPartitionKeyAndLoyaltyIdAndExpiredTimeGreaterThan(String pk, String loyaltyId, String start);


}
