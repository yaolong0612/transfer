package cn.com.pg.loyalty.infrastructure.redis;

import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.order.RollBackOrderRecoverScene;
import cn.com.pg.loyalty.domain.transaction.order.RollBackOrderSelfRecoveryAble;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class RedisRollBackOrderSelfRecovered implements RollBackOrderSelfRecoveryAble {

    @Autowired
    private CacheService cacheService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public void backupRollBackOrders(String loyaltyId, List<Order> orders) {
        String redisKey = cacheService.getKey(CacheService.KeyEnum.ROLLBACK_ORDER, loyaltyId);
        stringRedisTemplate.opsForValue().set(redisKey, JSON.toJSONString(orders));
    }

    @Override
    public List<Order> getBackupRollBackOrders(String loyaltyId) {
        String redisKey = cacheService.getKey(CacheService.KeyEnum.ROLLBACK_ORDER, loyaltyId);
        log.info("rollback order key is :{}", redisKey);
        String redisValue = stringRedisTemplate.opsForValue().get(redisKey);
        if (StringUtils.isEmpty(redisValue)) {
            return Collections.emptyList();
        }
        log.info("获取redis的回滚订单：{}", redisValue);
        return JSON.parseArray(redisValue, Order.class);
    }

    @Override
    public void deleteBackupOrders(String loyaltyId) {
        String redisKey = cacheService.getKey(CacheService.KeyEnum.ROLLBACK_ORDER, loyaltyId);
        stringRedisTemplate.delete(redisKey);
    }

    @Override
    public void backupRollBackAccountGap(String loyaltyId, RollBackOrderRecoverScene.AccountRollBackGap accountRollBackGap) {
        String redisKey = cacheService.getKey(CacheService.KeyEnum.ACCOUNT_GAP, loyaltyId);
        stringRedisTemplate.opsForValue().set(redisKey, JSON.toJSONString(accountRollBackGap));
    }

    @Override
    public RollBackOrderRecoverScene.AccountRollBackGap getBackupRollBackAccountGap(String loyaltyId) {
        String redisKey = cacheService.getKey(CacheService.KeyEnum.ACCOUNT_GAP, loyaltyId);
        String redisValue = stringRedisTemplate.opsForValue().get(redisKey);
        if (StringUtils.isEmpty(redisValue)) {
            return null;
        }
        return JSON.parseObject(redisValue, RollBackOrderRecoverScene.AccountRollBackGap.class);
    }

    @Override
    public void removeBackUps(String loyaltyId) {
        String accountGap = cacheService.getKey(CacheService.KeyEnum.ACCOUNT_GAP, loyaltyId);
        String rollbackOrder = cacheService.getKey(CacheService.KeyEnum.ROLLBACK_ORDER, loyaltyId);
        List<String> redisKey = new ArrayList<>();
        redisKey.add(accountGap);
        redisKey.add(rollbackOrder);
        batchDeleteKey(redisKey);
    }


    private void batchDeleteKey(List<String> redisKey) {
        DefaultRedisScript<Long> script = new DefaultRedisScript<>();
        script.setScriptText(getDeleteKeysScript());
        List<String> keyList = new ArrayList<>();
        for (String key : redisKey) {
            keyList.add(String.valueOf(key));
        }
        stringRedisTemplate.execute(script, keyList);
    }

    private String getDeleteKeysScript() {
        return "local keyList = KEYS\n" +
                "for i in pairs(keyList) do \n" +
                "    redis.call('DEL', keyList[i])\n" +
                "end";
    }

}
