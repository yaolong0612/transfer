package cn.com.pg.loyalty.domain.activity;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActivityLogRepository extends DocumentDbRepository<ActivityLog, String> {
}
