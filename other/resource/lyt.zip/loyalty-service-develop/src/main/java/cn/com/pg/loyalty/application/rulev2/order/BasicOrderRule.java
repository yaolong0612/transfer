package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.BasicOrderRulePropertiesV2;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/8
 */
@Rule(name = "BASIC_ORDER_RULE_V2",
        description = "calculate the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class BasicOrderRule {
    private RuleTemplate ruleTemplate = RuleTemplate.BASIC_ORDER_RULE_V2;

    /**
     * 等级奖励积分规则执行条件：
     * 1、必须查到积分模板是基础订单规则的且订单时间在活动期间内活动数大于0
     * 2、订单实付金额大于0
     *
     * @param activityList
     * @param order
     * @return
     */
    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                             @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order) {
        if (order.getRealTotalAmount() <= 0) {
            //订单金额是0,不执行加积分
            log.info("orderId:{}金额是:{}，不参与积分计算", order.getOrderId(), order.getRealTotalAmount());
            return Boolean.FALSE;
        }

        List<Activity> basicOrderActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        if (CollectionUtils.isEmpty(basicOrderActivityList)) {
            //没有订单时间在活动期间内的活动返回false,不执行加积分
            log.info("orderId:{}匹配到的基础订单积分活动数:{}", order.getOrderId(), basicOrderActivityList.size());
            return Boolean.FALSE;
        }
        //返回true 进行加积分操作
        return Boolean.TRUE;
    }

    /**
     * 按规则内容进行加积分
     *
     * @param order
     * @param activityList
     */
    @Action
    public void addPoint(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                         @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                         @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult
    ) {
        List<Activity> basicOrderActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        Activity basicOrderActivity = basicOrderActivityList.get(0);
        BasicOrderRulePropertiesV2 ruleContent = JSON.parseObject(basicOrderActivity.getRuleProperties(), BasicOrderRulePropertiesV2.class);

        //根据积分计算类型进行计算积分
        int point = ruleContent.calculatePoint(structure,order);
        PointItem pointItem = new PointItem(point, basicOrderActivity.description(), basicOrderActivity.activityId());
        competePointItems.put(pointItem, ruleContent.isCompetition());
        ruleResult.success();
    }
}
