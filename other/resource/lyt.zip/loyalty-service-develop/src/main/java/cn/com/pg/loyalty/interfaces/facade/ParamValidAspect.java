package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.ParamValidateService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Aspect
@Component
@Slf4j
@Order(2)
public class ParamValidAspect {

    @Autowired
    private ParamValidateService paramValidateService;

    @Pointcut("execution(public * cn.com.pg.loyalty.interfaces.facade.*Facade.*(..)) ")
    private void validateParamFacadePointCut() {
        //DO NOTHING.
    }

    @Around("validateParamFacadePointCut()")
    public Object validateParam(ProceedingJoinPoint pjp) throws Throwable {
        Map<String, String> paramsMap = new HashMap<>();
        LocalDateTime startTime = LocalDateTime.now();
        log.info("paramValidAspect -> start: {}", startTime.toString());
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if(Objects.nonNull(requestAttributes)) {
            ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) requestAttributes;
            HttpServletRequest request = servletRequestAttributes.getRequest();
            paramsMap.putAll(paramValidateService.exactVerifiedParam(request::getParameter));
        }
        paramsMap.putAll(paramValidateService.exactVerifiedParam(pjp.getArgs()));
        paramValidateService.validate(paramsMap);
        LocalDateTime endTime = LocalDateTime.now();
        log.info("paramValidAspect -> end: {}, cost time: {}", endTime.toString(), Duration.between(startTime,
                endTime).toMillis());
        return pjp.proceed();
    }
}
