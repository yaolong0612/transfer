package cn.com.pg.loyalty.domain.account;


import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ValueObject;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.LocalDateTime;


/**
 * @author Young
 * @date 2019年3月28日上午9:29:25
 * @description 用户等级信息
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
public class Tier implements ValueObject<Tier> {

    /**
     *
     */
    private static final long serialVersionUID = -11538596758401156L;

    /**
     * Non_Index 用户前一个等级
     */
    private String preLevel;

    /**
     * Non_Index 用户等级
     */
    private String level;

    /**
     * 回滚订单之前的等级
     */
    private String backupLevel;

    /**
     * 等级过期时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime expiredTime;

    /**
     * 等级升级时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime upgradedTime;

    /**
     * 等级积分
     */
    private int tierPoint;

    /**
     * 引起升级的订单号
     */
    private String transactionId;

    /**
     * 创建一个新的等级
     * 初始等级
     *
     * @param loyaltyStructure
     */
    public Tier(LoyaltyStructure loyaltyStructure) {
        //初始化tierPoint
        tierPoint = 0;
        level = loyaltyStructure.getTierLevelSeries().firstTierLevel();
        upgradedTime = LocalDateTime.now();
        //每个体系的过期时间不同
        expiredTime = loyaltyStructure.getTierLevelSeries().tierExpireDate(level);
        this.preLevel = level;
    }

    /**
     * 重置升级/降级等级
     *
     * @param tierLevel
     */
    public Tier(LoyaltyStructure loyaltyStructure, String tierLevel, String preLevel) {
        tierPoint = 0;
        this.preLevel = preLevel;
        level = tierLevel;
        upgradedTime = LocalDateTime.now();
        expiredTime = loyaltyStructure.getTierLevelSeries().tierExpireDate(level);
    }

    public Tier(LoyaltyStructure loyaltyStructure, String tierLevel, String preLevel, Integer tierPoint) {
        this.tierPoint = tierPoint;
        this.preLevel = preLevel;
        level = tierLevel;
        upgradedTime = LocalDateTime.now();
        expiredTime = loyaltyStructure.getTierLevelSeries().tierExpireDate(level);
    }

    public Tier(LoyaltyStructure loyaltyStructure, String tierLevel, String preLevel, LocalDateTime upgradedTime) {
        tierPoint = 0;
        this.preLevel = preLevel;
        level = tierLevel;
        this.upgradedTime = upgradedTime;
        expiredTime = loyaltyStructure.getTierLevelSeries().tierExpireDate(level, upgradedTime);
    }

    public Tier(LoyaltyStructure loyaltyStructure, String tierLevel, String preLevel, LocalDateTime upgradedTime, int tierPoint) {
        this(loyaltyStructure, tierLevel, preLevel, upgradedTime);
        this.tierPoint = tierPoint;
    }

    @Override
    public boolean sameValueAs(Tier other) {
        return this.equals(other);
    }

    /**
     * Pampers计算等级每次加积分同时也会给等级积分加上
     */
    public int addTierPoint(int point) {
        this.tierPoint += point;
        return this.tierPoint;
    }

    /**
     * 判断等级是否过期
     */
    public boolean judgeTierExpired() {
        return LocalDateTime.now().isAfter(this.expiredTime);
    }


    protected void updateTier(LoyaltyStructure loyaltyStructure, String tierLevel, LocalDateTime upgradedTime) {
        this.preLevel = this.level;
        this.level = tierLevel;
        this.upgradedTime = upgradedTime;
        expiredTime = loyaltyStructure.getTierLevelSeries().tierExpireDate(this.level);
    }
}
