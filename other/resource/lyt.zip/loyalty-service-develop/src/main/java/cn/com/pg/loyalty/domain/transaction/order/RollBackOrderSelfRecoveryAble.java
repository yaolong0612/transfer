package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.transaction.Order;

import java.util.List;

public interface RollBackOrderSelfRecoveryAble {

    /**
     * 将回滚的订单存到redis
     */
    void backupRollBackOrders(String loyaltyId, List<Order> orders);

    /**
     * 从redis获取回滚的订单
     */
    List<Order> getBackupRollBackOrders(String loyaltyId);

    /**
     * 删除redis中回滚的订单
     */
    void deleteBackupOrders(String loyaltyId);

    /**
     * 将accountGap存到redis
     *
     * @param loyalty
     * @param accountRollBackGap
     */
    void backupRollBackAccountGap(String loyalty, RollBackOrderRecoverScene.AccountRollBackGap accountRollBackGap);

    /**
     *
     */
    RollBackOrderRecoverScene.AccountRollBackGap getBackupRollBackAccountGap(String loyaltyId);

    void removeBackUps(String loyaltyId);
}
