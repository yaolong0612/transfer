package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.OrderAppService;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * @description: olay order
 * @author: Jevons Chen
 * @date: 2019-06-21 16:27
 */

@Component
@Slf4j
public class OrderConsumer extends AbstractConsumer {
    private static final LocalDateTime ORDER_DATE_TEME_IGNORE = LocalDate.of(2019, 8, 1).atTime(LocalTime.MIN);

    @Autowired
    private OrderAppService orderAppService;

    @Override
    protected void doBusiness(JSONObject message) {
        RequestOrdersMessage orderMessage = JSON.toJavaObject(message, RequestOrdersMessage.class);
        orderAppService.calculateOrders(orderMessage);
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.OLAY_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.OLAY_QUEUE_NAME;
    }
}
