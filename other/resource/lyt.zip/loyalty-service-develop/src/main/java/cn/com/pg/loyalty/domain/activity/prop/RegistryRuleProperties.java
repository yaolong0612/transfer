package cn.com.pg.loyalty.domain.activity.prop;


import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Set;

/**
 * @author Simon
 * @date 2019/4/30 15:22
 * @description
 **/
@Getter
@Setter
public class RegistryRuleProperties extends RuleProperties {

    @NotNull
    @Valid
    private Set<String> channels;

    @Min(0)
    @NotNull
    private Integer bindPoint;

    @Min(0)
    @NotNull
    private Integer registerPoint;
}
