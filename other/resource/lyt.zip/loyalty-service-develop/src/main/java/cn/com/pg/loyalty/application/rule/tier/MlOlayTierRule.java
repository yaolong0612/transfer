package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.*;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Ladd
 * @date 2019/5/3 15:38
 * @description ML Olay, 积分等级是根据订单金额计算的，计算最近一年的订单，然后算出来等级。等级有效期为一年
 **/
@Slf4j
@Rule(name = "Tier upgrade rule: ML Olay rule",
        description = "calculate the point by order")
public class MlOlayTierRule {

    @Condition
    public boolean isExecuteMlOlayTier(@Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                                       @Fact("transaction") Transaction transaction,
                                       @Fact("calculateTierExpired") Boolean tierExpired) {
        //只有ML Olay订单积分，才会导致等级变动和执行
        return loyaltyStructure.checkMlBrand(BrandV2.OLAY) && (tierExpired || transaction.getTransactionType() == TransactionType.ORDER);
    }

    @Action
    public void upgrade(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("transaction") Transaction transaction,
                        @Fact("orderRepository") OrderRepository orderRepository,
                        @Fact("transactionRepository") TransactionRepository transactionRepository,
                        @Fact("calculateTierExpired") Boolean tierExpired,
                        @Fact("ruleResult") RuleResult ruleResult) {
        //获取当前等级
        Tier tier = account.tier(loyaltyStructure.name());
        log.info("上一次等级:{}当前等级:{}", tier.getPreLevel(), tier.getLevel());
        // 升级时间
        LocalDateTime upgradeTime = tier.getUpgradedTime();
        // 当为计算等级过期时默认时间为现在主要用来在如果等级降级时是否可以降级
        LocalDateTime originalTime = LocalDateTime.now();
        // 当为计算等级过期时默认是的 startTime 和 endTime
        LocalDateTime startTime = tier.getExpiredTime().minusYears(1).plusDays(1);
        LocalDateTime endTime = LocalDateTime.now();
        Double totalAmountYearly;
        Order order;
        if (tierExpired) {
            order = null;
        } else {
            order = (Order) transaction;
        }
        if (null != order && order.groupPurchaseIs()) {
            log.info("OrderId:{}为团购则不计算等级", order.getOrderId());
            ruleResult.success();
            return;
        }
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        // 退单或者常单情况
        if (order != null) {
            // 记录用户当前最迟的一次交易时间(默认使用交易时间)
            LocalDateTime lastTransactionTime = order.getOrderDateTime();
            // 如果退单则去获取最后一次交易时间
            if (order.refundOrder()) {
                lastTransactionTime = findAccountLastTransactionTime(transactionRepository, partitionKey, account.loyaltyId());
            }
            endTime = lastTransactionTime;
            startTime = endTime.minusYears(1).plusDays(1);
            // 原始订单时间
            // 如果退单的原始订单时间在等级升级的时间之后，那么发生降级时 判断等级是否过期 是：降级、否：不降级
            // 如果退单的原始订单时间在等级升级的时间之前，那么如果发生降级，那么就直接降级，不需要判断等级是否过期
            originalTime = order.getOrderDateTime();
        }
        List<Order> orders = findOrdersPeriodTime(orderRepository, partitionKey, account.loyaltyId(), startTime, endTime);
        // 1年时间段中的有效金额
        totalAmountYearly = calculatePeriodTimeAmount(order, orders);
        Integer tierAmount = totalAmountYearly.intValue();
        log.info("开始时间{},结束时间{},这一年内的有效金额{}元", startTime, endTime, tierAmount);
        TierLevelSeries levelSeries = loyaltyStructure.tierLevelSeries();
        String currentLevel = tier.getLevel();
        String nextLevel = levelSeries.nextLevelByAmount(currentLevel, tierAmount).getLevelName();
        //计算升级/降级
        while (levelSeries.compare(currentLevel, nextLevel) != 0) {
            currentLevel = nextLevel;
            nextLevel = levelSeries.nextLevelByAmount(nextLevel, tierAmount).getLevelName();
        }
        // 如果是等级过期降级，并且用户当前等级大于等于ML_OLAY_2，降级后的等级小于ML_OLAY_2，则限制只能降级到ML_OLAY_2
        if (LocalDateTime.now().plusDays(1).isAfter(tier.getExpiredTime())
                && levelSeries.compare(tier.getLevel(), nextLevel) > 0
                && levelSeries.compare(nextLevel, "ML_OLAY_2") < 0) {
            nextLevel = "ML_OLAY_2";
        }
        //升级/降级到下一个等级(由退单那个单号升级的，然后再退单降级)
        if (levelSeries.compare(tier.getLevel(), nextLevel) < 0 ||
                (levelSeries.compare(tier.getLevel(), nextLevel) > 0 && originalTime.isBefore(upgradeTime)) ||
                (LocalDateTime.now().plusDays(1).isAfter(tier.getExpiredTime()))) {
            Tier newTier = new Tier(loyaltyStructure, nextLevel, tier.getLevel());
            account.tier(loyaltyStructure, newTier);
            log.info("ML-Olay等级发生变化：MemberId{},当前等级{},更新后的等级{},过期时间{}", account.memberId(), newTier.getPreLevel(), newTier.getLevel(), newTier.getExpiredTime());
        }
        log.info("ML-Olay等级计算结束");
        ruleResult.success();
    }

    private Double calculatePeriodTimeAmount(Order order, List<Order> orders) {
        // 过滤团购
        orders = orders.parallelStream().filter(order1 -> !order1.groupPurchaseIs()).collect(Collectors.toList());
        // 如果等级过期或者是团购
        if (order == null || order.groupPurchaseIs()) {
            return orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
        }
        // 如果退单
        if (order.refundOrder()) {
            // 将原订单删除
            orders = orders.parallelStream().filter(order1 -> !(order1.getId().equals(order.getId()))).collect(Collectors.toList());
        }
        // 加上当前订单或更新后的退单
        orders.add(order);
        return orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
    }

    /**
     * 找到用户最后一次交易时间，
     * 退单时间不算，如果没有找到返回当前时间-1年
     *
     * @param transactionRepository
     * @param partitionKey
     * @param loyaltyId
     * @return
     */
    private LocalDateTime findAccountLastTransactionTime(TransactionRepository transactionRepository, String partitionKey, String loyaltyId) {
        Optional<String> optionalT =
                transactionRepository.findMaxOrderTimeByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(partitionKey, loyaltyId, BrandV2.OLAY, TransactionType.ORDER);
        return optionalT.map(LocalDateTime::parse).orElse(LocalDateTime.now().minusYears(1));
    }

    private List<Order> findOrdersPeriodTime(OrderRepository orderRepository, String partitionKey, String loyaltyId, LocalDateTime startTime, LocalDateTime endTime) {
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(partitionKey, loyaltyId, BrandV2.OLAY, TransactionType.ORDER,
                LoyaltyDateTimeUtils.localDateTimeToString(startTime), LoyaltyDateTimeUtils.localDateTimeToString(endTime));
    }
}
