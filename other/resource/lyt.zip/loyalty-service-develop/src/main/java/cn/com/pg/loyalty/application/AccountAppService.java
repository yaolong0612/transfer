package cn.com.pg.loyalty.application;


import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.account.AccountOpt.OptNode;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.OrderRecalculateForOptDelay;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionRepository;
import cn.com.pg.loyalty.infrastructure.lock.MutexLock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Hayden on 2020/8/20 16:01.
 */
@Service
@Slf4j
public class AccountAppService {
    @Autowired
    private AccountValidateService accountValidateService;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private OperationService operationService;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private AccountOptRepository accountOptRepository;
    @Autowired
    private OrderRecalculateForOptDelay orderRecalculateForOptDelay;
    @Autowired
    private CacheService cacheService;

    @MutexLock(lockKeys = {"#brand", "#memberId"}, expiredTime = 20)
    public void recalculateAccount(String memberId, String brand, String region) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        if (!loyaltyStructure.pointExpire(ValueType.DEFAULT).isOrderDelayExpired()) {
            log.warn("不支持回滚,brand:{},{}", brand, memberId);
            return;
        }
        Account account = accountValidateService.validate(loyaltyStructure, memberId);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Transaction> allTransactions = transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(
                partitionKey, account.loyaltyId());
        account.resetInfo(brand);
        operationService.rollbackPoint(loyaltyStructure, allTransactions, account);
        accountRepository.save(account);

    }

    public void addAccountOpts(String memberId, String brand, String region, OptNode node) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountValidateService.validate(loyaltyStructure, memberId);
        AccountOpt accountOpt = accountOptRepository.fetchAccountOptByLoyaltyId(account.loyaltyId());
        if (accountOpt == null) {
            accountOpt = new AccountOpt(memberId, loyaltyStructure.marketingProgramId(), account.loyaltyId());
        }
        accountOpt.addOpt(node);
        accountOptRepository.save(accountOpt);
        orderRecalculateForOptDelay.recalculateOrder(account, brand, node);
    }
}

