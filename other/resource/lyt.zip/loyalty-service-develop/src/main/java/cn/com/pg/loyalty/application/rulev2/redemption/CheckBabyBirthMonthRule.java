package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.activity.prop.Scope;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

@Slf4j
@Rule(name = "宝宝生日月控制",
        description = "宝宝生日月", priority = 2)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
@Component
public class CheckBabyBirthMonthRule {

    @Condition
    public boolean validateRule(
            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        //宝宝生日月仅pampers支持
        return ruleProperties.getBabyBirthMonthScope() != null && BrandV2.PAMPERS.equals(redemption.brand());
    }

    @Action
    public void executeRule(
            @Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {

        String birthMonth = account.getBabyBirthYearAndMonth();
        if (StringUtils.isEmpty(birthMonth) || birthMonth.length() != 6) {
            throw new SystemException("宝宝生日信息异常", ResultCodeMapper.BABY_BIRTH_LIMIT);
        }

        Scope monthScope = ruleProperties.getBabyBirthMonthScope();
        if (!account.checkBabyBirthMonth(monthScope.getLower(), monthScope.getUpper())) {
            throw new SystemException("宝宝生日月不在限制范围", ResultCodeMapper.BABY_BIRTH_LIMIT);
        }

    }
}
