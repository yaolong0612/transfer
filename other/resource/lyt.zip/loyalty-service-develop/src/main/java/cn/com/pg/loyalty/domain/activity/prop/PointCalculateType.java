package cn.com.pg.loyalty.domain.activity.prop;

public enum PointCalculateType {
    /**
     * 固定积分计算
     */
    FIXED {
        @Override
        public int calculatePoint(double baseAmount, int basePoint, int maximumBonusPoints, double bonusPointMultiple) {
            return basePoint;
        }

    },
    /**
     * 倍率积分计算
     */
    MULTIPLE {
        @Override
        public int calculatePoint(double baseAmount, int basePoint, int maximumBonusPoints, double bonusPointMultiple) {
            int point = (int) Math.ceil(baseAmount * bonusPointMultiple);
            //如果设置了最大积分上限，需要进行比较设置最后积分得值 当maxBosPoint=0时表示不设置上限
            if (maximumBonusPoints <= 0) {
                return point;
            }
            return Math.min(maximumBonusPoints, point);
        }
    };

    public abstract int calculatePoint(double baseAmount, int basePoint, int maximumBonusPoints, double bonusPointMultiple);
}
