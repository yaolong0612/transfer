package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:46
 */

@Getter
@Setter
public class SingleProductMultipleProperties extends RuleProperties {

    @Min(0)
    private int multiple;
    private boolean competition;
    @Min(0)
    private int givenLimitPoint;
    @NotNull
    private List<String> skuS;
    private String productName;
    /**
     * 只能传3个渠道：JD，TMALL, COUNTER
     */
    @Valid
    @NotNull
    private List<String> channels = new ArrayList<>();
    @NotNull
    private List<String> storeCodes = new ArrayList<>();
    private String exemptionPeriodStartAt;
    private String exemptionPeriodEndAt;

    public LocalDateTime exemptionPeriodStartAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodStartAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodStartAt);
        }
        return localDateTime;
    }

    public LocalDateTime exemptionPeriodEndAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodEndAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodEndAt);
        }
        return localDateTime;
    }
}
