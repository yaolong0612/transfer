package cn.com.pg.loyalty.domain.account;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class SubAccounts extends HashMap<String, SubAccount> {

    public static final String SUB_KEY = "_SUB";

    protected LocalDate fetchLastExpireDate() {
        return this.values().stream().min(Comparator.comparing(SubAccount::pointAboutExpiredDateWithDefault))
                .map(SubAccount::getPointAboutExpiredDate)
                .orElse(null);
    }

    protected SubAccount subAccount(String brand) {
        return this.get(brand);
    }

    protected SubAccount subAccount(String brand, boolean extraSubAccount) {
        String key = getRegisterKey(brand, extraSubAccount);
        return this.get(key);
    }

    protected SubAccount anySubAccount(String brand) {
        SubAccount subAccount = subAccount(brand);
        if (subAccount == null) {
            subAccount = subAccount(brand, true);
        }
        return subAccount;
    }

    /**
     * @param extraSubAccount: false->默认账号 true->替换账户：例如 pampaers 成长值账户
     */
    public SubAccount registerSubAccount(String brand, boolean extraSubAccount, SubAccount subAccount) {
        String key = getRegisterKey(brand, extraSubAccount);
        return this.putIfAbsent(key, subAccount);
    }

    /**
     * 是否有注册账号
     */
    public boolean hasRegister(String brand, boolean extraSubAccount) {
        String key = getRegisterKey(brand, extraSubAccount);
        return this.containsKey(key);
    }

    /**
     * 是否注册品牌账号中的其中一个
     */
    public boolean hasRegisterAny(String brand) {
        String key = getRegisterKey(brand, true);
        return this.containsKey(brand) || this.containsKey(key);
    }


    public boolean hasAnyBindChannel(String brand, String channel) {
        return hasBindChannel(brand, channel, true)
                || hasBindChannel(brand, channel, false);
    }

    public boolean hasBindChannel(String brand, String channel, boolean extraSubAccount) {
        SubAccount subAccount = subAccount(brand, extraSubAccount);
        if (subAccount == null) {
            return false;
        }
        return subAccount.getBindList().containsKey(channel);
    }

    public List<SubAccount> subAccounts(boolean extraSubAccount) {
        List<SubAccount> subAccounts = new ArrayList<>();
        this.forEach((k, v) -> {
            if (k.contains(SUB_KEY) ^ !extraSubAccount) {
                subAccounts.add(v);
            }
        });
        return subAccounts;
    }

    private String getRegisterKey(String brand, boolean extraSubAccount) {
        String key = brand;
        if (extraSubAccount) {
            key = getSubKey(brand);
        }
        return key;
    }

    private String getSubKey(String brand) {
        return brand + SUB_KEY;
    }


}
