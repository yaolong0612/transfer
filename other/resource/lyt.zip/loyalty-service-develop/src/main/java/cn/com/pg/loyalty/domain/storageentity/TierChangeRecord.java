package cn.com.pg.loyalty.domain.storageentity;

import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.infrastructure.storage.StorageEntity;
import com.microsoft.azure.storage.table.TableServiceEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-06 11:23
 */

@Getter
@Setter
@ToString
@NoArgsConstructor
@StorageEntity(name = "TierChangeRecordV2")
public class TierChangeRecord extends TableServiceEntity {

    private String loyaltyId;
    private String memberId;
    private String marketingProgramId;
    private String loyaltyStructure;
    private String preLevel;
    private String tierLevel;
    private String upgradedTime;
    private String expiredTime;
    private String region;
    private String subAccountList;

    public TierChangeRecord(String partitionKey, String rowKey) {
        this.partitionKey = partitionKey;
        this.rowKey = rowKey;
    }

    public String tierLevel(LoyaltyStructure loyaltyStructure) {
        return loyaltyStructure.tierLevelSeries().getLevelByName(tierLevel).getLevelAlias();
    }
}
