package cn.com.pg.loyalty.domain.transaction;

/**
 * @author Simon
 * @date 2019年4月23日下午4:25:03
 * @description
 */
public enum RedemptionStatus {
    /**
     * 创建订单状态
     */
    CREATED(true,true,true),
    /**
     * 发货状态
     */
    DELIVERED(false,true,false),
    /**
     * 完成状态
     */
    ACCOMPLISHED(false,true,false),
    /**
     * 拒绝状态
     */
    REJECTED(false,false,false),
    /**
     * 取消兑换
     */
    CANCELED(false,false,false),
    /**
     * 支付完成
     */
    PAYED(false,true,false),
    /**
     * 过期
     */
    EXPIRED(false,false,false);

    RedemptionStatus(boolean allowCancel, boolean allowReject, boolean allowExpire) {
        this.allowCancel = allowCancel;
        this.allowReject = allowReject;
        this.allowExpire = allowExpire;
    }

    private final boolean allowCancel;
    private final boolean allowReject;
    private final boolean allowExpire;


    public boolean isAllowCancel() {
        return allowCancel;
    }

    public boolean isAllowReject() {
        return allowReject;
    }

    public boolean isAllowExpire() {
        return allowExpire;
    }

}
