package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;

import java.time.LocalDateTime;

/**
 * @Author: Hayden
 * @CreateDate: 2021/4/14 17:07
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/4/14 17:07
 * @Version: 1.0
 * @Description:
 */
public enum PeriodDateType {

    /**
     * 天数差
     */
    BY_DAY {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return localDateTime.minusDays(interval);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return localDateTime;
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return localDateTime.plusDays(interval);
        }
    },

    /**
     * 月份相减
     */
    BY_MONTH {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return localDateTime.minusMonths(interval);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return localDateTime;
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return localDateTime.plusMonths(interval);
        }
    },
    /**
     * 年份相减
     */
    BY_YEAR {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return localDateTime.minusYears(interval);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return localDateTime;
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return localDateTime.plusYears(interval);
        }
    },

    /**
     * 按天计算
     */
    BY_NATURE_DAY {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return localDateTime.minusDays(interval-1L).withHour(0).withMinute(0).withSecond(0).withNano(0);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return LoyaltyDateTimeUtils.getEndTimeOfDay(localDateTime);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return LoyaltyDateTimeUtils.getEndTimeOfDay(localDateTime).plusDays(interval-1L);
        }
    },
    /**
     * 按季度计算
     */
    BY_NATURE_QUARTER {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            LocalDateTime first=LoyaltyDateTimeUtils.getStartDayOfQuarter(localDateTime);
            return first.minusMonths(3L*(interval-1L));
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return LoyaltyDateTimeUtils.getEndDayOfQuarter(localDateTime);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return LoyaltyDateTimeUtils.getEndDayOfQuarter(localDateTime.plusMonths((interval-1L)*3L));

        }
    },
    /**
     * 自然月
     */
    BY_NATURAL_MONTH {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return LoyaltyDateTimeUtils.getFirstDayOfThisMonth(localDateTime.minusMonths(interval - 1L));
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return LoyaltyDateTimeUtils.getLastDayOfThisMonth(localDateTime);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return LoyaltyDateTimeUtils.getLastDayOfThisMonth(localDateTime.plusMonths(interval-1L));

        }
    },
    /**
     * 自然年
     */
    BY_NATURAL_YEAR {
        @Override
        public LocalDateTime periodStartDate(LocalDateTime localDateTime,int interval) {
            return LoyaltyDateTimeUtils.getFirstDayOfYear(localDateTime.minusYears(interval - 1L));
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime) {
            return LoyaltyDateTimeUtils.getLastDayOfYear(localDateTime);
        }

        @Override
        public LocalDateTime periodEndDate(LocalDateTime localDateTime, int interval) {
            return LoyaltyDateTimeUtils.getLastDayOfYear(localDateTime.plusYears(interval-1L));

        }
    };


    public abstract LocalDateTime periodStartDate(LocalDateTime localDateTime, int interval);

    public abstract LocalDateTime periodEndDate(LocalDateTime localDateTime);

    public abstract LocalDateTime periodEndDate(LocalDateTime localDateTime,int interval);


}
