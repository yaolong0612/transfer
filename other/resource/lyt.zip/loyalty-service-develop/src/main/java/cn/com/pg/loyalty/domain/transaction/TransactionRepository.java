package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.pool.ValueType;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * 查询Transaction List使用这个方法
 * @Author
 */
@Repository
public interface TransactionRepository {

    Transaction save(Transaction entity);

    void deleteById(String id, String partitionKey);

    List<Transaction> findTransactionsByPartitionKeyAndLoyaltyId(String partitionKey, String loyaltyId);

    List<Transaction> fetchBurnByPartitionKeyAndLoyaltyIdAndTransactionTypeOrPointLessThanAndCreatedTimeBetween(String partitionKey, String loyaltyId, String transactionType, int point, String startAt, String endAt);

    List<Transaction>  fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween(String partitionKey, String loyaltyId, String transactionType, int point, String startAt, String endAt);

    List<Transaction> fetchByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween(String partitionKey, String loyaltyId, String startAt, String endAt);

    /**
     * 获取某个用户某事件段过期交易记录
     * @param partitionKey
     * @param loyaltyId
     * @param brand
     * @param startAt
     * @param endAt
     * @return
     */
    List<Transaction> findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(String partitionKey, String loyaltyId, String startAt, String endAt, Set<String> brand);

    /**
     * 查找某个人的获取积分的记录
     * @param partitionKey
     * @param loyaltyId
     * @param transactionType
     * @param availablePoint
     * @return
     */
    List<Transaction> findByPartitionKeyAndLoyaltyIdAndTransactionTypeNotAndAvailablePointGreaterThanOrderByCreatedTime(String partitionKey,String loyaltyId,TransactionType transactionType, int availablePoint);

    List<Transaction> findByPartitionKeyAndId(String transactionPartitionKey, String transactionId);

    List<Transaction> findByPartitionKeyAndLoyaltyIdAndExpiredTimeLessThanAndBrandInAndTransactionStatusNotExpire(String partitionKey, String loyaltyId, String endAt, Set<String> brands);

    /**
     * 查询某个人的积分记录
     * @param pointType
     * @param partitionKey
     * @param loyaltyId
     * @return
     */
    List<Transaction> findByPartitionKeyAndLoyaltyIdAndPointType(String partitionKey, String loyaltyId, String pointType);

    Optional<String> findMaxOrderTimeByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(String partitionKey, String loyaltyId, String brand, TransactionType transactionType);

    Optional<String> findMaxCreatedTimeOfAddTransaction(String loyaltyId,ValueType valueType);

    List<Transaction> findTransactionsWitTypeAndCreateTimeBetween(String loyaltyId, ValueType valueType, LocalDateTime startTime, LocalDateTime endTime);

    List<Transaction> fetchByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId, String startAt, String endAt);
}
