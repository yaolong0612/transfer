package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.InteractionRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * @description:
 * @author: Artermus wang on 2022-01-24 18:06
 */
@Rule(name = "Delivery ",
        description = "检查发运设置校验", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
public class CheckDeliveryRule {
    @Autowired
    private CacheService cacheService;
    @Autowired
    private InteractionRepositoryV2 interactionRepositoryV2;

    @Condition
    public boolean matchRule() {
        return true;
    }


    @Action
    public void executeRule(
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties
    ) {
        redemption.bindDelivery(ruleProperties.getDeliveryChannel());
        if (DeliveryChannel.C2.sameValueAs(redemption.getDeliveryChannel())) {
            setDefaultStoreCode(redemption, account);
            checkStoreCode(redemption);
            return;
        }

        if (redemption.getDeliveryChannel().sendLogisticsService()) {
            checkLogisticDeliveryInfo(redemption, ruleProperties);
        }
    }

    private void setDefaultStoreCode(Redemption redemption, Account account) {
        if (StringUtils.isBlank(redemption.storeCode())) {
            redemption.storeCode(account.subAccount(redemption.brand()).getFirstPurchaseStoreCode());
        }
    }

    private void checkLogisticDeliveryInfo(Redemption redemption, RedemptionProperties ruleProperties) {
        if (!ruleProperties.isAllowDeliverDirectly()) {
            return;
        }
        redemption.checkLogisticUserInfo();

    }

    private void checkStoreCode(Redemption redemption) {
        if (BrandV2.SKII.equals(redemption.brand())) {
            return;
        }
        if (StringUtils.isNotBlank(redemption.storeCode())) {
            Store store = cacheService.getStoreByStoreCode(redemption.storeCode());
            if (store == null) {
                throw new SystemException("Can't find counter whose code is[" + redemption.storeCode() + "]", ResultCodeMapper.PARAM_ERROR);
            }
            redemption.checkStoreAvailable(store);
            redemption.addStoreName(store.getStoreName());
        }
    }

}
