package cn.com.pg.loyalty.application.rulev2.redemption;


import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.application.EventAppService;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import cn.com.pg.loyalty.interfaces.dto.Event;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT;

@Rule(name = "SettlementRedemptionRule",
        description = "结算积分", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.REDEMPTION)
public class SettlementRedemptionRule {

    @Autowired
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;
    @Autowired
    private MessageService messageService;
    @Autowired
    private CacheService cacheService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private EventAppService eventAppService;

    @Condition
    public boolean matchRule() {
        return true;
    }

    @Action
    public void executeRule(@Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties,
                            @Fact(RuleParamNameConfig.TRANSACTION_CALCULATE_RESULT) AccountTransactionResult calculateResult,
                            @Fact(RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        try {
            account.calculatePoint(redemption, structure);
            //保存到数据库前 需要发延时消息到transaction event的queue 代替function的功能
            eventAppService.publishEvent(redemption.getId(), Event.EventSourceTypeEnum.TRANSACTION,
                    redemption.getTransactionType().name(), redemption.getPartitionKey());
            batchUpdateDBComponentImpl.saveAccountAndTransactionV2(account, redemption);
            calculateResult.setAccount(account);
            calculateResult.setTransaction(redemption);
        } catch (Exception e) {
            log.warn("save account and transaction fail");
            ruleResult.addException(new SystemException("save fail", ResultCodeMapper.UNEXPECTED_ERROR));
            return;
        }
        //同步库存
        if (ruleProperties.isReductionInventory()) {
            messageService.sendToSyncInventoryToDB(redemption, false);
        }
        syncRedemptionPointForActivity(structure, redemption.activityId(), redemption.point());
    }

    public void syncRedemptionPointForActivity(LoyaltyStructure loyaltyStructure, String activityId, int point) {
        String key = cacheService.getKey(CacheService.KeyEnum.PERSISTENT_AGGREGATION_REDEMPTION, loyaltyStructure.name());
        stringRedisTemplate.opsForHash().increment(key, activityId, point);
    }

}
