package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.activity.Coupon;
import cn.com.pg.loyalty.domain.activity.CouponGateway;
import cn.com.pg.loyalty.domain.activity.GiftIssuedInventory;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION;
import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES;

@Rule(name = "BindCoupon",
        description = "绑定coupon系统,使用券码替换兑换码", priority = Integer.MIN_VALUE + 1)
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.REDEMPTION)
public class BindCouponRule {

    @Autowired
    private CouponGateway couponGateway;
    @Autowired
    private GiftIssuedInventory giftIssuedInventory;

    @Condition
    public boolean validateRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        //锁定天数大于0
        return ruleProperties.isBindCoupon();
    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption) {

        try {
            Coupon coupon = couponGateway.instanceCoupon(redemption.getMemberId(), redemption.brand());
            //设置券码
            redemption.bindCouponCode(coupon);
        } catch (Exception e) {
            giftIssuedInventory.refundIssuedInventory(redemption);
            throw e;
        }

    }
}
