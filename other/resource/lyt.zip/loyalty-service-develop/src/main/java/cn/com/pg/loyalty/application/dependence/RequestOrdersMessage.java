package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.application.dto.RequestOrderCommand;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validator;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RequestOrdersMessage {
    /**
     * 大陆为MemberId
     */
    @NotBlank(message = "memberId not null")
    private String memberId;
    /**
     * 品牌
     */
    @NotBlank(message = "brand not null")
    private String brand;

    /**
     * 区域
     */
    @NotBlank(message = "region not null")
    private String region;
    /**
     * 该用户当天指定品牌的下的全渠道所有订单
     */
    @Valid
    @NotEmpty
    private List<RequestOrderCommand> transactions;

    public boolean noRefundOrders() {
        return transactions.stream().noneMatch(RequestOrderCommand::refundRequest);
    }

    public boolean allRefundOrders() {
        return transactions.stream().allMatch(RequestOrderCommand::refundRequest);
    }

    public RequestOrdersMessage findRefundOrderMessage() {
        List<RequestOrderCommand> commands = transactions.stream()
                .filter(RequestOrderCommand::refundRequest).collect(Collectors.toList());
        return new RequestOrdersMessage(memberId, brand, region, commands);
    }

    public RequestOrdersMessage findNonRefundOrderMessage() {
        List<RequestOrderCommand> commands = transactions.stream()
                .filter(command -> !command.refundRequest()).collect(Collectors.toList());
        return new RequestOrdersMessage(memberId, brand, region, commands);
    }

    public void valid() {
        Validator validator = ParamValidator.getValidator();
        Set<ConstraintViolation<RequestOrdersMessage>> violationSet = validator.validate(this);
        Iterator<ConstraintViolation<RequestOrdersMessage>> iterator = violationSet.iterator();
        if (iterator.hasNext()) {
            ConstraintViolation<RequestOrdersMessage> violation = iterator.next();
            String errorMsg = violation.getPropertyPath() + violation.getMessage();
            throw new SystemException(errorMsg, ResultCodeMapper.PARAM_ERROR);
        }
    }
}
