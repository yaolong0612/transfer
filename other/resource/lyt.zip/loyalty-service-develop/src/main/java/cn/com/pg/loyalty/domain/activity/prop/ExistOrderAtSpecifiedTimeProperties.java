package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * @description: 订单加固定分
 * @author: lin.bj
 * @date: 2020-02-10 14:02
 */

@Getter
@Setter
public class ExistOrderAtSpecifiedTimeProperties extends RuleProperties {
    // 额外赠送倍数
    private int multiple;
    private LocalDateTime effectStartTime;
    private LocalDateTime effectEndTime;
    // 是否参与竞争
    private boolean competition;
}
