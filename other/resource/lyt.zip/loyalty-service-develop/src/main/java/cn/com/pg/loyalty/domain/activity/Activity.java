package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.activity.prop.RuleProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import io.netty.util.internal.StringUtil;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Simon
 * @date 2019/4/15 18:47
 * @description Loyalty Activity, 主要是配置选项，给Admin使用，加积分依据这个配置规则
 **/
@Getter
@Setter
@Document(collection = "Activity", ru = "400")
@Slf4j
@NoArgsConstructor
@ToString
public class Activity implements Entity<Activity> {

    /**
     * 唯一活动id，所有的活动以此ID为唯一标识
     */
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.ACTIVITY_PARTITIONKEY;
    /**
     * 活动名称
     */
    private String activityName;

    private String brand;

    /**
     * 活动的分类，活动根据Transaction Type不同，分为不同的类别
     */
    private TransactionType transactionType;

    /**
     * 创建人
     */
    private String createdBy;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    /**
     * 更新人
     */
    private String updatedBy;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    /**
     * 生效时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime startAt;

    /**
     * 结束时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime endAt;

    /**
     * 活动时间，只有初始状态的活动才可以被修改删除。 已经激活的活动不可以修改，只可以将生效时间改成结束（等同于失效）
     */
    private ActivityStatus status;

    /**
     * 前端配置，需要认真对待，会直接展示给消费者
     */
    private String description;

    /**
     * 积分Rule 模板
     */
    private RuleTemplate ruleTemplate;

    /**
     * Rule Template 需要的参数，参数结构与每个模板有关
     * 严格格式为JSON字符串
     */
    private String ruleProperties;

    /**
     * campaign的ID
     */
    private String externalId;
    /**
     * 礼品包
     */
    private Map<String, RedemptionItem> gifts = new HashMap<>();

    /**
     * 扫码加积分 skus
     */
    private List<QrcodeItem> qrcodeItems = new ArrayList<>();
    /***
     * 积分体系
     */
    private String loyaltyStructure;
    /**
     * 活动的备注
     */
    private String remark;
    /**
     * 活动优先级
     */
    private Integer priority;

    /**
     * 同类互斥活动，拥有同一个pointType
     */
    private String pointType;

    /**
     * 活动通知消息模板
     */
    private String msgTemplate;

    /**
     * 多语言支持
     */
    private List<Activity.ActivityDisplayMsg> displayLanguages = new ArrayList<>();

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ActivityDisplayMsg {
        private Locale language;
        private String description;

    }


    public void addDisplayLanguages(List<Activity.ActivityDisplayMsg> addDisplayLanguageList) {
        if (CollectionUtils.isEmpty(addDisplayLanguageList)) {
            return;
        }
        Map<Locale, Activity.ActivityDisplayMsg> addDisplayLanguageMap = addDisplayLanguageList.stream().collect(Collectors.toMap(Activity.ActivityDisplayMsg::getLanguage, self -> self));
        //如果已激活活动，必须移除本身存在的多语言,避免覆盖原有数据
        if (this.status == ActivityStatus.ACTIVATE) {
            this.displayLanguages.stream().forEach(addDisplayLanguage -> {
                if (addDisplayLanguageMap.containsKey(addDisplayLanguage.getLanguage())) {
                    addDisplayLanguageMap.remove(addDisplayLanguage.getLanguage());
                }
            });
            //正式添加新增的多语言
            addDisplayLanguageMap.values().stream().forEach(addDisplayLanguage -> this.displayLanguages.add(addDisplayLanguage));
        }
        if (this.status == ActivityStatus.INITIAL) {
            //未激活直接覆盖
            this.displayLanguages = addDisplayLanguageList;
        }
    }

    @Override
    public boolean sameIdentityAs(Activity other) {
        return other != null && other.id.equals(this.id);
    }

    public RuleTemplate ruleTemplate() {
        return ruleTemplate;
    }


    public static class Builder {

        private String activityName;

        private String brand;

        private TransactionType transactionType;

        @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
        private LocalDateTime startAt;

        @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
        private LocalDateTime endAt;

        private ActivityStatus status;

        private String description;

        private RuleTemplate ruleTemplate;

        private String ruleProperties;

        private String externalId;

        private List<QrcodeItem> qrcodeItems = new ArrayList<>();

        private LoyaltyStructure loyaltyStructure;

        private String remark;

        private Integer priority;

        private String pointType;

        private String msgTemplate;

        private String createdBy;

        @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
        private LocalDateTime createdTime;

        private String updatedBy;

        @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
        private LocalDateTime updatedTime;

        private Builder(String activityName, LoyaltyStructure structure, String brand,
                        TransactionType transactionType, String description, String remark) {
            this.activityName = activityName;
            this.transactionType = transactionType;
            this.createdTime = LocalDateTime.now();
            this.updatedTime = LocalDateTime.now();
            this.loyaltyStructure = structure;
            this.brand = brand;
            this.status = ActivityStatus.INITIAL;
            this.description = description;
            this.remark = remark;
        }

        public static Builder interactionBuilder(String activityName, LoyaltyStructure structure, String brand,
                                                 String description, String remark) {
            return new Builder(activityName, structure, brand, TransactionType.INTERACTION, description, remark);
        }

        public static Builder orderBuilder(String activityName, LoyaltyStructure structure, String brand,
                                           String description, String remark) {
            return new Builder(activityName, structure, brand, TransactionType.ORDER, description, remark);
        }

        public static Builder redemptionBuilder(String activityName, LoyaltyStructure structure, String brand,
                                                String description, String remark) {
            return new Builder(activityName, structure, brand, TransactionType.REDEMPTION, description, remark);
        }

        public static Builder tierBuilder(String activityName, LoyaltyStructure structure, String brand,
                                           String description, String remark) {
            return new Builder(activityName, structure, brand, TransactionType.TIER, description, remark);
        }

        public Builder validityTime(LocalDateTime startAt, LocalDateTime endAt) {
            if (startAt.isAfter(endAt)) {
                throw new SystemException("开始时间不能大于结束时间", ResultCodeMapper.PARAM_ERROR);
            }
            this.startAt = startAt;
            this.endAt = endAt;
            return this;
        }

        public Builder buildRule(PointType pointType, String ruleProperties, int priority) {
            this.pointType = pointType.getPointType();
            this.ruleTemplate = pointType.getRuleTemplate();
            this.ruleProperties = ruleProperties;
            this.priority = priority;

            return this;
        }

        public Builder qrcodeItems(List<QrcodeItem> qrcodeItems) {
            this.qrcodeItems = qrcodeItems;
            return this;
        }


        public Builder createBy(String createdBy, LocalDateTime createdTime) {
            this.createdBy = createdBy;
            this.createdTime = createdTime;
            this.updatedTime = createdTime;
            return this;
        }

        public Builder updateBy(String updatedBy, LocalDateTime updatedTime) {
            this.updatedBy = updatedBy;
            this.updatedTime = updatedTime;
            return this;
        }

        public Builder externalId(String externalId) {
            this.externalId = externalId;
            return this;
        }

        public Builder msgTemplate(String msgTemplate) {
            this.msgTemplate = msgTemplate;
            return this;
        }

        public Builder status(ActivityStatus status) {
            this.status = status;
            return this;
        }

        public Activity build() {
            Activity activity = new Activity();
            activity.id = UUIDUtil.generator();
            activity.createdTime = this.createdTime;
            activity.createdBy = this.createdBy;
            this.updateActivity(activity);
            return activity;
        }

        public void updateActivity(Activity activity) {
            if (activity.status == ActivityStatus.ACTIVATE) {
                throw new SystemException("当前活动已在激活状态，不能再进行修改",
                        ResultCodeMapper.ACTIVITY_NOT_UPDATE_STATUS);
            }
            activity.activityName = this.activityName;
            activity.brand = this.brand;
            activity.loyaltyStructure = this.loyaltyStructure.name();
            activity.transactionType = this.transactionType;
            activity.status = this.status;
            activity.description = this.description;
            activity.remark = this.remark;
            activity.startAt = this.startAt;
            activity.endAt = this.endAt;
            activity.pointType = this.pointType;
            activity.ruleTemplate = this.ruleTemplate;
            activity.ruleProperties = this.ruleProperties;
            activity.priority = this.priority;
            activity.externalId = this.externalId;
            activity.msgTemplate = this.msgTemplate;
            activity.qrcodeItems = this.qrcodeItems;
            activity.updatedBy = this.updatedBy;
            activity.updatedTime = this.updatedTime;
            //序列化后保存，去除可能多余字段，方便有效测试
            amendRuleProperties(activity);
        }

        private void amendRuleProperties(Activity activity) {
            activity.ruleProperties = JSON.toJSONString(activity.ruleProperties());
        }

    }

    public void addRedemptionItem(Gift gift, RedemptionItem redemptionItem, LoyaltyStructure structure) {
        if (gift == null) {
            throw new SystemException("未找到对应的礼品元数据", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        if (existGift(redemptionItem.getGiftId())) {
            throw new SystemException("该兑换项已经存在，不能再次添加", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        if (!StringUtils.equals(this.loyaltyStructure, gift.getLoyaltyStructure())) {
            throw new SystemException("礼品和活动积分体系不匹配", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        checkRedemptionItem(redemptionItem, structure);
        this.gifts.put(redemptionItem.getGiftId(), redemptionItem);
        this.updatedTime = LocalDateTime.now();
    }

    private void checkRedemptionItem(RedemptionItem redemptionItem, LoyaltyStructure structure) {
        if (redemptionItem.getTierLevel() == null) {
            redemptionItem.setTierLevel(structure.tierLevelSeries().firstTierLevel());
        }
        if (redemptionItem.getStartAt() == null) {
            redemptionItem.setStartAt(this.startAt);
        }
        if (redemptionItem.getEndAt() == null) {
            redemptionItem.setEndAt(this.endAt);
        }
        if (!this.transactionType.sameValueAs(TransactionType.REDEMPTION)) {
            throw new SystemException("非兑换活动不能设置礼品", ResultCodeMapper.PARAM_ERROR);
        }
        if (!structure.tierLevelSeries().hasTierLevel(redemptionItem.getTierLevel())) {
            throw new SystemException("限制等级和活动积分体系不匹配", ResultCodeMapper.PARAM_ERROR);
        }
        if (redemptionItem.getStartAt().isBefore(this.startAt) || redemptionItem.getStartAt().isAfter(this.endAt)) {
            throw new SystemException("礼品开始时间要在活动有效期内", ResultCodeMapper.PARAM_ERROR);
        }
        if (redemptionItem.getEndAt().isBefore(this.startAt) || redemptionItem.getEndAt().isAfter(this.endAt)) {
            throw new SystemException("礼品结束时间要在活动有效期内", ResultCodeMapper.PARAM_ERROR);
        }
    }

    public void updateRedemptionItem(RedemptionItem redemptionItem, LoyaltyStructure loyaltyStructure) {
        if (!existGift(redemptionItem.getGiftId())) {
            throw new SystemException("兑换项不存在，不能修改", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        checkRedemptionItem(redemptionItem, loyaltyStructure);
        RedemptionItem oldRedemptionItem = this.gifts.get(redemptionItem.getGiftId());
        if (oldRedemptionItem != null) {
            redemptionItem.setStock(oldRedemptionItem.getStock());
            redemptionItem.setIssuedNum(oldRedemptionItem.getIssuedNum());
        }
        this.gifts.put(redemptionItem.getGiftId(), redemptionItem);
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 删除礼包Gift
     *
     * @param giftId 礼品ID
     */
    public void deleteRedemptionItem(String giftId, Integer issuedNum) {
        if (this.transactionType != TransactionType.REDEMPTION) {
            throw new SystemException("当前活动类型不对！请检查！", ResultCodeMapper.PARAM_ERROR);
        }
        if (issuedNum != null && issuedNum > 0) {
            throw new SystemException("该礼品已被兑换，不能删除！", ResultCodeMapper.PARAM_ERROR);
        }
        if (!this.gifts.containsKey(giftId)) {
            throw new SystemException("礼品不存在", ResultCodeMapper.GIFT_NOT_FOUND);
        }
        this.gifts.remove(giftId);
        this.updatedTime = LocalDateTime.now();
    }

    public void delete() {
        if (this.status == ActivityStatus.ACTIVATE) {
            throw new SystemException("当前活动已被激活，不能被删除！", ResultCodeMapper.ACTIVITY_NOT_DELETE);
        }
    }

    public void end() {
        if (activityIsEnd()) {
            throw new SystemException("活动已结束，不能修改", ResultCodeMapper.PARAM_ERROR);
        }
        LocalDateTime now = LocalDateTime.now();
        if (this.status == ActivityStatus.ACTIVATE && now.isAfter(this.startAt)
                && now.isBefore(this.endAt)) {
            this.endAt = LocalDateTime.now();
            this.updatedTime = now;
        }
    }

    public void activate() {
        if (activityIsEnd()) {
            throw new SystemException("活动已结束，不能修改", ResultCodeMapper.PARAM_ERROR);
        }
        this.status = ActivityStatus.ACTIVATE;
        this.updatedTime = LocalDateTime.now();
    }


    /**
     * 修改礼品库存数据
     */
    public void updateGiftInventory(String giftId, Integer amount) {
        if (this.gifts.containsKey(giftId)) {
            this.gifts.get(giftId).updateStock(amount);
            this.updatedTime = LocalDateTime.now();
        } else {
            throw new SystemException("在活动中没有找到对应的礼品！请检查！", ResultCodeMapper.ACTIVITY_NOT_FOUND_GIFT);
        }

    }

    /**
     * 检查活动是否在有效的时间范围内,并且活动是否在激活状态
     */
    public void checkAvailable(LocalDateTime sometime) {
        if (this.startAt.isAfter(sometime)) {
            throw new SystemException("Activity hasn't started", ResultCodeMapper.ACTIVITY_NOT_AVAILABLE_ERROR);
        }
        if (this.endAt.isBefore(sometime)) {
            throw new SystemException("Activity is overdue", ResultCodeMapper.ACTIVITY_NOT_AVAILABLE_ERROR);
        }

        if (this.status != ActivityStatus.ACTIVATE) {
            throw new SystemException("Activity is not in ACTIVATE status", ResultCodeMapper.ACTIVITY_NOT_AVAILABLE_ERROR);
        }
    }

    public static Comparator<Activity> updatedTimeDescComparator() {
        return (o1, o2) -> o2.updatedTime.compareTo(o1.updatedTime);
    }

    public boolean activityIsNotStart() {
        LocalDateTime now = LocalDateTime.now();
        return status == ActivityStatus.ACTIVATE && now.isBefore(startAt);
    }

    public boolean activityIsEnd() {
        LocalDateTime now = LocalDateTime.now();
        return status == ActivityStatus.ACTIVATE && now.isAfter(endAt);
    }

    public boolean available() {
        LocalDateTime now = LocalDateTime.now();
        if (status != ActivityStatus.ACTIVATE) {
            return false;
        }
        return !now.isBefore(startAt) && !now.isAfter(endAt);
    }

    public boolean available(LocalDateTime indicatedDateTime) {
        if (status != ActivityStatus.ACTIVATE) {
            return false;
        }
        return !indicatedDateTime.isBefore(startAt) && !indicatedDateTime.isAfter(endAt);
    }

    public RuleProperties ruleProperties() {
        return Optional.ofNullable(this.ruleTemplate).map(
                ruleTemplate1 -> (RuleProperties) com.alibaba.fastjson.JSON.parseObject(this.ruleProperties, ruleTemplate1.getRulePropertiesClazz())
        ).orElseGet(() -> com.alibaba.fastjson.JSON.parseObject(this.ruleProperties, RedemptionProperties.class));
    }

    public String description() {
        return this.description;
    }

    public String activityId() {
        return this.id;
    }

    public String pointType() {
        return this.pointType;
    }


    public boolean thisBrandActivity(String paramBrand) {
        return this.brand.equals(paramBrand);
    }

    public boolean existGift(String giftId) {
        for (String item : this.gifts.keySet()) {
            if (item.equals(giftId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 生成10位物流活动id,兑换时调物流接口会用到
     */
    public String logisticsActivityId() {
        int hashcode = this.id.hashCode();
        if (hashcode < 0) {
            hashcode = -hashcode;
        }
        return String.format("%010d", hashcode);
    }

    public boolean giftAvailable(String id) {
        Map<String, RedemptionItem> map = this.gifts;
        if (map.get(id) == null) {
            return false;
        }
        return map.get(id).availablePeriod();
    }

    public void addQrcodeSkuItem(QrcodeItem qrcodeItem) {
        String baseSku = qrcodeItem.getSku();
        boolean existSkuOrNotFlag = false;
        for (QrcodeItem item : this.qrcodeItems) {
            if (baseSku != null && baseSku.equalsIgnoreCase(item.getSku())) {
                existSkuOrNotFlag = true;
            }
        }
        if (existSkuOrNotFlag) {
            throw new SystemException("该SKU已经存在,请勿重复添加!", ResultCodeMapper.QRCODE_ACTIVITY_SKU_EXIST);
        }
        this.qrcodeItems.add(qrcodeItem);
        this.updatedTime = LocalDateTime.now();
    }

    public void deleteQrcodeSku(String skuCode) {
        QrcodeItem oldQrcodeItem = null;
        for (QrcodeItem item : this.qrcodeItems) {
            if (!StringUtil.isNullOrEmpty(skuCode) && skuCode.equalsIgnoreCase(item.getSku())) {
                oldQrcodeItem = item;
            }
        }
        if (oldQrcodeItem == null) {
            throw new SystemException("没有找到该sku码对应的数据", ResultCodeMapper.SCAN_CODE_ERROR);
        }
        this.qrcodeItems.remove(oldQrcodeItem);
        this.updatedTime = LocalDateTime.now();
    }

    public void updateQrcodeSkuItem(QrcodeItem qrcodeItem) {
        QrcodeItem oldQrcodeItem = null;
        for (QrcodeItem item : this.qrcodeItems) {
            if (!StringUtil.isNullOrEmpty(qrcodeItem.getSku()) && qrcodeItem.getSku().equalsIgnoreCase(item.getSku())) {
                oldQrcodeItem = item;
            }
        }
        if (oldQrcodeItem == null) {
            throw new SystemException("没有找到该sku码对应的数据", ResultCodeMapper.SCAN_CODE_ERROR);
        }
        this.qrcodeItems.remove(oldQrcodeItem);
        this.qrcodeItems.add(qrcodeItem);
    }

    public List<QrcodeItem> qrcodeItems() {
        return Optional.ofNullable(this.qrcodeItems).orElse(new ArrayList<>());
    }

    public Activity addMsgTemplate(String msgTemplate) {
        this.msgTemplate = msgTemplate;
        return this;
    }

    public void checkOwnStructure(LoyaltyStructure structure) {
        if (StringUtils.equals(structure.name(), loyaltyStructure)) {
            return;
        }
        throw new SystemException("The credit system input is different from the configuration of the activity, which cannot be redeemed for gifts",
                ResultCodeMapper.NO_SAME_LOYALTY_STRUCTURE);
    }

    public void checkRedemptionProperties() {
        //2.判断是否配置了兑换活动规则，如果没有配置就直接返回错误
        if (!(this.ruleProperties() instanceof RedemptionProperties)) {
            throw new SystemException("There is no exchange rule, the activity is wrong", ResultCodeMapper.PARAM_ERROR);
        }
    }

    public boolean matchRuleTemplate(RuleTemplate template) {
        return template.equals(this.ruleTemplate);
    }

    /**
     * 判断取消兑换时间是否在禁止兑换时期后：
     * 当选择了N号，整个活动的兑换礼品在发生兑换后的下月N号(包括N号)后禁止取消兑换
     * 但允许业务做reject
     *
     */

    public boolean judgeInLimitCancelPeriod(LocalDateTime redeemTime) {
        RedemptionProperties properties = (RedemptionProperties) this.ruleProperties();
        Integer limitCancelDay = properties.getLimitCancelDay();
        if (limitCancelDay == null || limitCancelDay <= 0) {
            //找不到对应的配置 或者配置小于等于0，表示活动不需要限制取消兑换
            return false;
        }
        //得到禁止取消兑换的开始日期
        LocalDateTime limitCancelDateStart = LocalDateTime.of(redeemTime.getYear(), redeemTime.getMonthValue(), limitCancelDay, 0, 0, 0).plusMonths(1);
        LocalDateTime now = LocalDateTime.now();
        //进行当前时间验证是否发生在兑换后的第二月第limitCancelDay天前：可取消兑换期内
        return !now.isBefore(limitCancelDateStart);
    }

}
