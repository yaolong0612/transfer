package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.application.utils.LimitTimeUtils;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.activity.prop.NumMappingPoint;
import cn.com.pg.loyalty.domain.activity.prop.ScanCodeBonusPoints;
import cn.com.pg.loyalty.domain.activity.prop.ScanCodePlusPointProperties;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author: Ysnow
 * @Date: 2019/5/30 14:30
 * @Description:
 */
@Rule(name = "Interaction rule: Pampers sweep rule",
        description = "When consumers buy goods, they can scan the qr code inside the goods and add credits")
@Slf4j
public class HkTwPampersScanCodeRule {

    /**
     * 扫码加积分的分布式锁，这里是基本的条件，
     * 实际用的时候还分拼接上qrCode，保证qrCode重复的，请求会被阻塞。
     * 扫码成功后，分布式锁并不会马上删除，而是让它自动过期。
     */
    private static final String SCAN_CODE_DISTRIBUTED_LOCK_KEY = "Interaction_Scan_Code_Plus_Point";
    private static final String SCAN_CODE_DISTRIBUTED_LOCK_VALUE = "TRUE";

    /**
     * 保存这个CODE 3秒
     */
    private static final int CODE_SLEEP_TIME = 2;

    /**
     * 保存这个account 分布式锁2秒
     */
    private static final int ACCOUNT_SLEEP_TIME = 6;

    private static final DateTimeFormatter MONTH_FORMATTER = DateTimeFormatter.ofPattern("yyyyMM");

    @Condition
    public boolean isHKTWPAMPERSScanCode(@Fact("pointType") PointType pointType,
                                         @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        //如果是台湾或者香港就用这个规则引擎。
        return Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType.pointType())
                && (loyaltyStructure.checkTwBrand(BrandV2.PAMPERS)
                || loyaltyStructure.checkHkBrand(BrandV2.PAMPERS));
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activityList, @Fact("interaction") Interaction interaction,
                         @Fact("qrCode") String qrCode, @Fact("sku") String sku,
                         @Fact("account") Account account,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("stringRedisTemplate") StringRedisTemplate stringRedisTemplate,
                         @Fact("pointType") PointType pointType,
                         @Fact("cacheService") CacheService cacheService) {
        try {
            checkParam(activityList, qrCode, sku, stringRedisTemplate, account, pointType, cacheService);

            Activity activity = activityList.get(0);
            List<QrcodeItem> qrcodeItems = activity.qrcodeItems();
            Optional<QrcodeItem> isExistsSku = qrcodeItems.stream()
                    .filter(qrcodeItem -> qrcodeItem.equalsThisSku(sku)).findFirst();
            QrcodeItem qrcodeItem = isExistsSku.orElse(null);
            if (qrcodeItem == null) {
                throw new SystemException("This sku does not exist. Input param error",
                        ResultCodeMapper.SCAN_CODE_SKU_INEXIST);
            }
            //获取扫码加积分的规则属性
            ScanCodePlusPointProperties scanCodePlusPointProperties = (ScanCodePlusPointProperties) activity.ruleProperties();
            List<Interaction> historyInteractions = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(interaction.partitionKey(),
                    pointType.pointType(), interaction.getLoyaltyId(), BrandV2.PAMPERS);
            historyInteractions = historyInteractions.stream().filter(interaction1 -> StringUtils.isNotBlank(interaction1.qrCode())).collect(Collectors.toList());
            String currentMonth = LocalDate.now().format(MONTH_FORMATTER);
            long thisMonthScanCodeTimes = historyInteractions.stream().filter(interaction1 -> interaction1.getCreatedTime().format(MONTH_FORMATTER).equals(currentMonth)).count();
            // 扫码限制
            // 每個會員每天最多掃碼積分5次
            // 每個會員每三個月最多積分15次
            // 每個會員每六個月最多積分30次
            List<NumMappingPoint> numMappingPoints = LimitTimeUtils.fetchHktwPampersScanLimit();
            Map<Integer, Long> limitSizeMap = LimitTimeUtils.checkLimit(historyInteractions, numMappingPoints);
            Map<Integer, Long> checkVisitMap = numMappingPoints.stream().collect(Collectors.toMap(NumMappingPoint::num, numMappingPoint -> limitSizeMap.get(numMappingPoint.getNum())));
            log.info("历史扫码次数：{}", JSON.toJSONString(checkVisitMap));
            //一共扫码的次数
            int totalScanCodeTimes = historyInteractions.size();
            List<PointItem> pointItems = calculatePoint(totalScanCodeTimes, thisMonthScanCodeTimes,
                    scanCodePlusPointProperties.getScanCodeBonusPoints(),
                    qrcodeItem, activity);
            interaction.scanCode(activity, qrCode, sku, pointType, pointItems);
        } catch (SystemException e) {
            ruleResult.addException(e);
            return;
        }
        //设置规则引擎执行成功标志
        ruleResult.success();
    }

    private void checkParam(List<Activity> activityList, String qrCode, String sku, StringRedisTemplate stringRedisTemplate, Account account, PointType pointType, CacheService cacheService) {
        if (CollectionUtils.isEmpty(activityList) || StringUtils.isEmpty(qrCode) || StringUtils.isEmpty(sku)) {
            throw new SystemException("Scan qrCode params:" + qrCode + ",SKU:" + sku, ResultCodeMapper.PARAM_ERROR);
        }
        //获取用户的分布式锁,如果没有获取到，扫码频率太快，稍后重试
        String scanAccountDistributedLockKey = SCAN_CODE_DISTRIBUTED_LOCK_KEY.concat("-").concat(account.getId()).concat("-Lock");
        if (!stringRedisTemplate.opsForValue().setIfAbsent(scanAccountDistributedLockKey,
                SCAN_CODE_DISTRIBUTED_LOCK_VALUE, ACCOUNT_SLEEP_TIME, TimeUnit.SECONDS)) {
            throw new SystemException("Scan code is too fast:" + scanAccountDistributedLockKey + ", please try again later", ResultCodeMapper.SCAN_CODE_TOO_FAST);
        }

        //锁定这个码，防止多个人同时进行扫码操作
        String scanQrCodeDistributedLockKey = SCAN_CODE_DISTRIBUTED_LOCK_KEY.concat("-").concat(qrCode).concat("-Lock");
        if (!stringRedisTemplate.opsForValue().setIfAbsent(scanQrCodeDistributedLockKey, SCAN_CODE_DISTRIBUTED_LOCK_VALUE, CODE_SLEEP_TIME, TimeUnit.SECONDS)) {
            throw new SystemException("Scan this code at same time:" + qrCode + ", please try again later", ResultCodeMapper.SCAN_CODE_TOO_FAST);
        }

        // 检查qrcode是否扫过
        cacheService.checkQrCode(pointType.getLoyaltyStructure(), qrCode);
    }

    public List<PointItem> calculatePoint(int totalScanCodeTimes, long thisMonthScanCodeTimes, ScanCodeBonusPoints scanCodeBonusPoints,
                                          QrcodeItem qrcodeItem, Activity activity) {
        //计算基础积分
        double basicDoublePoint;
        if (totalScanCodeTimes == 0) {
            //首次扫码
            basicDoublePoint = qrcodeItem.getBasePoint() * qrcodeItem.getMultiple() * 1.0 + qrcodeItem.getExtraPoint();
        } else {
            basicDoublePoint = qrcodeItem.getBasePoint();
        }
        //double类型向上取整，并转为int类型
        int basicPoint = (int) Math.ceil(basicDoublePoint);
        List<PointItem> pointItems = new ArrayList<>();
        pointItems.add(new PointItem(basicPoint, "Basic Point", activity.getId()));
        //计算额外积分
        int bonusPoint = 0;
        int startTimes = scanCodeBonusPoints.getStartTimes();
        int limitTimes = scanCodeBonusPoints.getTotalPoint() / scanCodeBonusPoints.getPerPoint() + startTimes - 1;
        if (startTimes <= thisMonthScanCodeTimes + 1 && thisMonthScanCodeTimes + 1 <= limitTimes) {
            bonusPoint = scanCodeBonusPoints.getPerPoint();
            pointItems.add(new PointItem(bonusPoint, "Bonus Point", activity.getId()));
        }
        return pointItems;
    }
}
