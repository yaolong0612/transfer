package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.PeriodDateLimitProperties;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: Hayden
 * @CreateDate: 2021/5/10 9:55
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/5/10 9:55
 * @Version: 1.0
 * @Description:
 */
@Rule(name = "LimitOrderPointPeriodDateRule",
        description = "限制获取积分上限")
@Slf4j
@Component
@Register(scope = RuleScope.AFTER_LIMIT_RULE, ruleType = RuleType.ORDER)
public class LimitOrderPointPeriodDateRule {

    private final static RuleTemplate LIMIT_ORDER_POINT_PERIOD_DATE_RULE = RuleTemplate.LIMIT_ORDER_POINT_PERIOD_DATE_RULE;
    @Autowired
    private TransactionRepositoryV2 transactionRepositoryV2;
    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList) {
        return activityList.stream().anyMatch(activity -> activity.matchRuleTemplate(LIMIT_ORDER_POINT_PERIOD_DATE_RULE));
    }

    @Action
    public void runRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                        @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order requestOrder,
                        @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activities,
                        @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        List<Activity> activityList = activities.stream()
                .filter(activity -> activity.matchRuleTemplate(LIMIT_ORDER_POINT_PERIOD_DATE_RULE))
                .collect(Collectors.toList());
        for (Activity activity : activityList) {
            executeActivityRule(account, requestOrder, activity);
        }

        ruleResult.success();
    }

    private void executeActivityRule(Account account, Order requestOrder, Activity activity) {
        PeriodDateLimitProperties limitProperties = (PeriodDateLimitProperties) activity.ruleProperties();
        LocalDateTime startTime = limitProperties.getType()
                .periodStartDate(requestOrder.getOrderDateTime(), limitProperties.getInterval());
        LocalDateTime endTime = limitProperties.getType().periodEndDate(requestOrder.getOrderDateTime());
        int transactionPoint = sumOrderPoint(account, startTime, endTime);

        if (limitProperties.isLimitTotalAddPoint()) {
            transactionPoint += sumTransactionPoint(account, startTime, endTime);
        }

        int remainPoint = limitProperties.getLimitNum() - requestOrder.point() - transactionPoint;
        if (remainPoint < 0) {
            if (Math.abs(remainPoint) > requestOrder.point()) {
                remainPoint = -requestOrder.point();
            }
            PointItem pointItem = new PointItem(remainPoint, activity.description(), activity.activityId());
            requestOrder.addPoint(pointItem);
        }
    }

    private int sumTransactionPoint(Account account, LocalDateTime startTime, LocalDateTime endTime) {
        return transactionRepositoryV2.fetchInteractions(account.loyaltyId(), startTime, endTime)
                .stream().filter(transaction -> !StringUtils.equals(transaction.getPointType(),
                        Transaction.PointTypeEnum.REDEMPTION_CANCEL.name()))
                .filter(transaction -> transaction.point() > 0).mapToInt(Transaction::point).sum();
    }

    private int sumOrderPoint(Account account, LocalDateTime startTime, LocalDateTime endTime) {
        return orderRepositoryV2.findOrdersByOrderDateTimeBetween(account.loyaltyId(), startTime, endTime)
                .stream().mapToInt(Transaction::point).sum();
    }

}
