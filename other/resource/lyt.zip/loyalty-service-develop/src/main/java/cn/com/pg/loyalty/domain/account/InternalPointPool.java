package cn.com.pg.loyalty.domain.account;

import lombok.Getter;

import java.time.LocalDate;
import java.util.*;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;

/**
 * 内部积分池：保存用户即将积分、即将过期时间。
 * 允许积分为负数，防止订单重算回滚导致即将过期时间回滚提前
 * 如需要计算积分相关请使用：statementPointPool
 */
public class InternalPointPool extends TreeMap<LocalDate, Integer> {

    private final static LocalDate CONSUME_POINT_DATE = LocalDate.of(1999,1,1);

    public PointPoolNode calculatePool(LocalDate expiredDate, int point) {
        this.calculatePoint(expiredDate, point);
        this.mergeExpiredNode();
        return this.fetchFirstExpireNode();
    }

    public PointPoolNode fetchFirstExpireNode() {
        TreeMap<LocalDate, Integer> statementPool = statementPointPool();
        if (statementPool.isEmpty()) {
            return PointPoolNode.empty();
        }
        Entry<LocalDate, Integer> entry = statementPool.firstEntry();
        return new PointPoolNode(entry.getKey(), entry.getValue());
    }

    /**
     * 过期积分处理
     *
     * @return
     */
    public int expirePoint() {
        int mergePoint = mergeExpiredPointNode();
        if (mergePoint < 0) {
            this.put(CONSUME_POINT_DATE, mergePoint);
            return 0;
        }
        return mergePoint;
    }

    private int mergeExpiredPointNode() {
        Iterator<Entry<LocalDate, Integer>> iterator = this.entrySet().iterator();
        int mergePoint = 0;
        while (iterator.hasNext()) {
            Entry<LocalDate, Integer> next = iterator.next();
            if (!LocalDate.now().isAfter(next.getKey())) {
                break;
            }
            mergePoint += next.getValue();
            iterator.remove();
        }
        return mergePoint;
    }

    private int fetchExpirePoint() {
        return statementPointPool().entrySet().stream().filter(entry -> LocalDate.now().isAfter(entry.getKey()))
                .flatMapToInt(entry -> IntStream.of(entry.getValue())).sum();
    }

    public List<PointPoolNode> fetchLastMonthNode(int month) {
        TreeMap<LocalDate, Integer> statementPool = statementPointPool();
        List<PointPoolNode> nodes = new ArrayList<>();
        LocalDate maxDate = LocalDate.now().plusMonths(month);
        statementPool.forEach(((localDate, point) -> {
            if (!maxDate.isBefore(localDate)) {
                nodes.add(new PointPoolNode(localDate, point));
            }
        }));
        return nodes;
    }

    public LocalDate fetchFloorKeyLastMonth(int month) {
        return this.statementPointPool().floorKey(LocalDate.now().plusMonths(month));
    }

    /**
     * 获取结算后的积分池。使用积分池可能存在负数、0积分记录
     */
    public TreeMap<LocalDate, Integer> statementPointPool() {
        TreeMap<LocalDate, Integer> statement = new TreeMap<>();
        AtomicInteger statePoint = new AtomicInteger();
        this.forEach((expiredDate, point) -> {
            int stagePoint = statePoint.addAndGet(point);
            if (stagePoint > 0) {
                statement.put(expiredDate, stagePoint);
                statePoint.set(0);
            }
        });
        return statement;
    }

    @Getter
    public static class PointPoolNode {
        private final LocalDate expireDate;
        private final int point;

        public PointPoolNode(LocalDate expireDate, int point) {
            this.expireDate = expireDate;
            this.point = point;
        }

        public static PointPoolNode empty() {
            return new PointPoolNode(null, 0);
        }
    }

    private void addPoint(LocalDate expiredDate, int point) {
        if (expiredDate.isBefore(LocalDate.now())) {
            return;
        }
        this.computeIfPresent(expiredDate, (k, p) -> p += point);
        this.putIfAbsent(expiredDate, point);
    }

    private void consumerPoint(int point) {
        this.computeIfPresent(CONSUME_POINT_DATE, (k, p) -> p -= point);
        this.putIfAbsent(CONSUME_POINT_DATE, -point);
    }

    private void rollbackPoint(LocalDate expiredDate, int point) {
        if (expiredDate.isBefore(LocalDate.now())) {
            return;
        }
        this.computeIfPresent(expiredDate, (k, p) -> p -= point);
        this.putIfAbsent(expiredDate, -point);
    }

    /**
     * 计算积分池
     *
     * @param expiredDate:当积分为负时，可以为null
     * @param point:积分为负时扣减积分
     */
    private void calculatePoint(LocalDate expiredDate, int point) {
        if (point == 0) {
            return;
        }
        if (point > 0) {
            addPoint(expiredDate, point);
            return;
        }
        if (expiredDate != null) {
            rollbackPoint(expiredDate, Math.abs(point));
            return;
        }
        consumerPoint(Math.abs(point));
    }

    private void mergeExpiredNode() {
        if (fetchExpirePoint() > 0) {
            return;
        }
        int mergePoint = mergeExpiredPointNode();
        if (mergePoint < 0) {
            this.put(CONSUME_POINT_DATE, mergePoint);
        }
    }

}
