package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AdjustPointTimesProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author cooltea
 */
@Rule(name = "wechat enterprises bind rule",
        description = "bind wechat enterprises add point")
@Slf4j
public class AdjustPointTimesRule {

    @Condition
    public boolean isAdjustPointTimesRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointTimesRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_TIMES;
    }

    @Action
    public void addPoint(@Fact("loyaltyStructure") LoyaltyStructure structure,
                         @Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("account") Account account,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("brand") String brand,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("point") Integer innerPoint) {
        Activity activity = activities.get(0);
        AdjustPointTimesProperties timesProperties = (AdjustPointTimesProperties) activity.ruleProperties();
        // 查看该用户是否已经加过该活动类型的积分
        List<Interaction> interactions = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(interaction.partitionKey(), activity.pointType(), interaction.getLoyaltyId(), brand);
        Integer limit = Optional.ofNullable(timesProperties.getLimit()).orElse(0);
        if (limit > 0 && interactions.size() >= limit) {
            ruleResult.addException(new SystemException("The operation of adding this type of bonus points of this user exceeds limited times ：" + limit + "，The times of user's operation：" + interactions.size(), ResultCodeMapper.POINT_EXCEED_LIMIT_FREQUENCY));
            return;
        }
        Integer point = timesProperties.addPoint();
        if (!timesProperties.allowNegative() && point < 0) {
            Integer accountAvailablePoint = account.availablePoint(structure.accountTypeOfDefault());
            if (point + accountAvailablePoint < 0) {
                ruleResult.addException(new SystemException("Requiring" + point + "points to adjust the bonus points of user,user dosen't have enough bonus points to use" + accountAvailablePoint, ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                return;
            }
        }
        int givenPoint = Optional.ofNullable(innerPoint).orElse(0);
        if (givenPoint > 0) {
            point = givenPoint;
        }
        interaction.addPoint(activity, point);
        LocalDateTime expiredTime = timesProperties.expiredTime(interaction.getCreatedTime());
        if (expiredTime != null) {
            interaction.updateExpireTime(expiredTime);
        }
        ruleResult.success();
    }
}
