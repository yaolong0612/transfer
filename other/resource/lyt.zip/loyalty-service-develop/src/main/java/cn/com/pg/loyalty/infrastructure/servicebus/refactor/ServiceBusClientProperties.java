package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class ServiceBusClientProperties {
    /**
     * 类型  存在topic与queue同名的情况
     */
    private ServiceBusBinder.ServiceBusType type = ServiceBusBinder.ServiceBusType.QUEUE;
    /**
     * 实体的名称
     */
    private String name;
    /**
     * 绑定的枚举
     */
    private ServiceBusBinder binging;
    /**
     * 描述
     */
    private String description;
    /**
     * 指定订阅的主题
     */
    private String topic;
    private int concurrency = 1;
    /**
     * 存放consumer 对象
     */
    private Object user;
    private Object client;
    private String connectionString;
    /**
     * 标签,一个account对应一个
     */
    private String generalLabel;
}