package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.*;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;



@Slf4j
@Rule(name = "calculate the point by order",
        description = "calculate the point by order")
public class CalculateTierByOrderRule {

    /**
     * 会员体系及等级有效期
     * 为了不影响其他品牌，这里进行了品牌过滤。考虑到积极对会员体系重构，暂时先做的简单一些
     */
    private static final Map<String, String> tierAndExpiredTimeMap = new HashMap<>();

    static {
        tierAndExpiredTimeMap.put(BrandV2.OPTE, "ML");
        tierAndExpiredTimeMap.put(BrandV2.LA, "ML");
        tierAndExpiredTimeMap.put(BrandV2.PAMPERS, "ML");

    }


    @Condition
    public boolean isExecuteRule(@Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                                 @Fact("transaction") Transaction transaction) {
        return tierAndExpiredTimeMap.entrySet().stream().anyMatch(set -> loyaltyStructure.contain(set.getValue(),
                set.getKey()))
                && transaction.getTransactionType() == TransactionType.ORDER;
    }

    @Action
    public void upgrade(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("transaction") Transaction transaction,
                        @Fact("orderRepository") OrderRepository orderRepository,
                        @Fact("transactionRepository") TransactionRepository transactionRepository,
                        @Fact("messageService") MessageService messageService,
                        @Fact("ruleResult") RuleResult ruleResult) {

        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        Integer expiredTime = loyaltyStructure.pointExpire(transaction).getPointEffectiveYear();
        Order order = (Order) transaction;
        //查询未过期的历史订单
        List<Order> orders = fetchNotExpiredHistoryOrders(order, expiredTime, partitionKey,
                account, transactionRepository, orderRepository);
        //计算有效金额
        int effectiveAmount = calculatePeriodTimeAmount(order, orders).intValue();
        //获取当前等级
        Tier tier = account.tier(loyaltyStructure.name());
        String calculationLevel = calculationLevel(loyaltyStructure, tier, effectiveAmount);

        int compareLevel = loyaltyStructure.getTierLevelSeries().compare(tier.getLevel(), calculationLevel);
        // 升级
        boolean tierUp = compareLevel < 0;
        // 降级
        boolean tierDown = compareLevel > 0;
        //退单的原始订单时间在升级之前
        boolean upBefore = order.getOrderDateTime().isBefore(tier.getUpgradedTime());
        //等级过期
        boolean tierExpired = LocalDateTime.now().plusDays(1).isAfter(tier.getExpiredTime());
        if (tierUp || tierExpired || (tierDown && upBefore)) {
            Tier newTier = new Tier(loyaltyStructure, calculationLevel, tier.getLevel());
            account.tier(loyaltyStructure, newTier);
            log.info("等级发生变化：MemberId:{},更新前上一次等级:{},当前等级{},更新后的等级{},过期时间{}",
                    account.memberId(), tier.getPreLevel(), newTier.getPreLevel(), newTier.getLevel(), newTier.getExpiredTime());
        }
        sendAwardEvent(loyaltyStructure, messageService, order, tier, compareLevel);
        log.info("等级计算结束");
        ruleResult.success();
    }

    private void sendAwardEvent(LoyaltyStructure loyaltyStructure, MessageService messageService, Order order, Tier tier, int compareLevel) {
        int awardPoint = calculateAwardPoint(loyaltyStructure, tier, compareLevel);
        if (awardPoint == 0) {
            return ;
        }
        InteractionMessage message = InteractionMessage
                .createTierAwardMessage(loyaltyStructure, order.getMemberId(), awardPoint, order.getCreatedTime());
        messageService.sendMessageForAddInteractionPoint(message, 1);
    }

    private int calculateAwardPoint(LoyaltyStructure loyaltyStructure, Tier tier, int compareLevel) {

        if (compareLevel == 0) {
            return 0;
        }
        if (compareLevel < 0) {
            return loyaltyStructure.getTierLevelSeries().calculateUpgradeAwardPoints(tier.getLevel(), Math.abs(compareLevel));
        }
        return -loyaltyStructure.getTierLevelSeries().calculateRefundAwardPoints(tier.getLevel(), Math.abs(compareLevel));
    }




    private List<Order> findOrdersPeriodTime(OrderRepository orderRepository, String partitionKey, String loyaltyId, LocalDateTime startTime, LocalDateTime endTime, String brand) {
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(partitionKey, loyaltyId, brand, TransactionType.ORDER,
                LoyaltyDateTimeUtils.localDateTimeToString(startTime), LoyaltyDateTimeUtils.localDateTimeToString(endTime));
    }

    /**
     * 根据有效订单金额计算会员等级
     *
     * @param tier            当前会员等级
     * @param effectiveAmount 有效订单金额
     * @return 会员等级
     */
    private String calculationLevel(LoyaltyStructure structure, Tier tier, int effectiveAmount) {
        TierLevelSeries levelSeries = structure.tierLevelSeries();
        String currentLevel = tier.getLevel();
        String nextLevel = levelSeries.nextLevelByAmount(currentLevel, effectiveAmount).getLevelName();
        while (levelSeries.compare(currentLevel, nextLevel) != 0) {
            currentLevel = nextLevel;
            nextLevel = levelSeries.nextLevelByAmount(currentLevel, effectiveAmount).getLevelName();
        }

        return nextLevel;
    }

    private Double calculatePeriodTimeAmount(Order order, List<Order> orders) {
        // 如果退单
        if (order.refundOrder()) {
            // 将原订单删除
            orders = orders.parallelStream().filter(order1 -> !(order1.getId().equals(order.getId()))).collect(Collectors.toList());
        }
        // 加上当前订单或更新后的退单
        orders.add(order);
        return orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
    }

    private List<Order> fetchNotExpiredHistoryOrders(Order order,
                                                     int expiredTime,
                                                     String partitionKey,
                                                     Account account,
                                                     TransactionRepository transactionRepository,
                                                     OrderRepository orderRepository) {
        Optional<String> optional = transactionRepository.findMaxOrderTimeByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(
                partitionKey, account.loyaltyId(), order.brand(), TransactionType.ORDER);
        if (!optional.isPresent()) {
            return new ArrayList<>();
        }
        LocalDateTime lastTransactionTime = LocalDateTime.parse(optional.get());
        LocalDateTime endTime = lastTransactionTime;
        if (!order.refundOrder() && order.getOrderDateTime().isAfter(lastTransactionTime)) {
            endTime = order.getOrderDateTime();
        }
        LocalDateTime startTime = endTime.minusYears(expiredTime);
        return findOrdersPeriodTime(orderRepository, partitionKey, account.loyaltyId(), startTime, endTime, order.brand());
    }

}
