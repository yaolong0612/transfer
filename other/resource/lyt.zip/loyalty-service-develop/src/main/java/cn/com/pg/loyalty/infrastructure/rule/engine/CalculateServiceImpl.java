package cn.com.pg.loyalty.infrastructure.rule.engine;

import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.CalculateService;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class CalculateServiceImpl implements CalculateService {


    @Lookup
    public RuleEngineSupportV2 getRuleEngineSupportV2() {
        //多例模式的使用方法，带有LookUp注解，在使用的时候会去getBean操作，从而实现多例效果
        return null;
    }

    @Override
    public AccountTransactionResult calculateOrderPoint(PointType pointType, Order order, Account account,
                                                        LoyaltyStructure loyaltyStructure, List<Activity> activityList,
                                                        int point) {
        Map<PointItem, Boolean> competePointItems = new ConcurrentHashMap<>(10);
        getRuleEngineSupportV2().addFact(RuleParamNameConfig.RULE_PARAM_POINT_TYPE, pointType)
                .addFact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER, order)
                .addFact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES, activityList)
                .addFact(RuleParamNameConfig.RULE_PARAM_BRAND_STR, order.brand())
                .addFact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS, competePointItems)
                .addFact(RuleParamNameConfig.RULE_PARAM_POINT_STR, point)
                .calculateOrderPoint();
        account.calculatePoint(order, loyaltyStructure);
        return new AccountTransactionResult(account, order);
    }

    @Override
    public AccountTransactionResult calculateRedemption(LoyaltyStructure structure, Redemption redemption, Account account, Activity activity,
                                                        List<Redemption> redemptionRecords, Locale language) {
        RedemptionProperties properties = (RedemptionProperties) activity.ruleProperties();
        AccountTransactionResult calculateResult = new AccountTransactionResult();
        getRuleEngineSupportV2()
                .addFact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE, structure)
                .addFact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION, redemption)
                .addFact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES, properties)
                .addFact(RuleParamNameConfig.RULE_PARAM_ACTIVITY, activity)
                .addFact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS, redemptionRecords)
                .addFact(RuleParamNameConfig.LANGUAGE, language)
                .addFact(RuleParamNameConfig.TRANSACTION_CALCULATE_RESULT, calculateResult)
                .calculateRedemptionPoint();
        return calculateResult;
    }

}
