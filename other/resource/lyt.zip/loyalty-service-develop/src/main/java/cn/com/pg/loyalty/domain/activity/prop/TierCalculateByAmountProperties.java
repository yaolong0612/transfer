package cn.com.pg.loyalty.domain.activity.prop;


import lombok.Data;

@Data
public class TierCalculateByAmountProperties extends BaseTierProperties {
}
