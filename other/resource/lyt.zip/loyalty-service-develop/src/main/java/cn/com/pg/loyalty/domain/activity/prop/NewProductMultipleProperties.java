package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:44
 */

@Getter
@Setter
public class NewProductMultipleProperties extends RuleProperties {

    @Min(0)
    private int multiple;
    @Min(0)
    private int givenLimitPoint;
    private boolean competition;
    @NotNull
    @Valid
    private List<NewProductChannelSet> channels = new ArrayList<>();

    private String exemptionPeriodStartAt;
    private String exemptionPeriodEndAt;

    public LocalDateTime exemptionPeriodStartAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodStartAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodStartAt);
        }
        return localDateTime;
    }

    public LocalDateTime exemptionPeriodEndAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodEndAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodEndAt);
        }
        return localDateTime;
    }
}
