package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.ActivitiesService;
import cn.com.pg.loyalty.application.GiftService;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityStatus;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.api.ActivitiesApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.ActivityAssembler;
import cn.com.pg.loyalty.interfaces.dto.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Ladd
 */
@Component("ActivitiesFacade")
public class ActivitiesFacade implements ActivitiesApiDelegate {

    @Autowired
    private ActivitiesService activitiesService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private GiftService giftService;

    @Override
    public ResponseEntity<PointTypeActivityListDTO> findActivityListByPointType(String pointType, String brand,
                                                                                String region, Boolean onlyAvailable, String language) {
//
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        List<Activity> activities;
        if (Boolean.TRUE.equals(onlyAvailable)) {
            activities = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(pointType, loyaltyStructure.name());
        } else {
            activities = cacheService.fetchActivitiesByPointTypeAndLoyaltyStruct(pointType, loyaltyStructure.name());
            activities = activities.stream().filter(activity -> activity.getStatus() == ActivityStatus.ACTIVATE)
                    .collect(Collectors.toList());
        }
        activities = activities.parallelStream().filter(activity -> activity.thisBrandActivity(brand)).collect(Collectors.toList());
        // 再排序。按照更新时间排序
        Comparator<Activity> comparator = Comparator.comparing(Activity::getUpdatedTime).reversed();
        activities.sort(comparator);
        Map<String, Gift> giftMap = new HashMap<>();
        for (Activity activity : activities) {
            Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
            for (String key : redemptionItemMap.keySet()) {
                Gift gift = cacheService.getGiftById(key);
                if (gift != null ) {
                    giftMap.putIfAbsent(key,gift);
                }
            }
        }
        Map<String, Integer> activityPointMap = transactionService.getRedemptionPointAggregation(activities);
        PointTypeActivityListDTO pointTypeActivityListDTOs = ActivityAssembler
                .toPointTypeActivityListDTO(activities, loyaltyStructure, giftMap, activityPointMap);
        //HK PAMPERS门店多语言
        if (CollectionUtils.isNotEmpty(pointTypeActivityListDTOs.getRecords())) {
            for (ActivityDetailDTO activityDetailDTO : pointTypeActivityListDTOs.getRecords()) {
                Activity activity = cacheService.findActivityById(activityDetailDTO.getActivityId());
                if (activity.getTransactionType().equals(TransactionType.REDEMPTION)) {
                    giftService.translateGiftCouponForHkPampers(language, region, brand, activityDetailDTO.getGifts());
                }
            }
        }
        return ResponseEntity.ok(pointTypeActivityListDTOs);
    }


    /**
     * 添加Interaction
     * LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone
     *
     * @param authorization
     * @param body
     * @return
     */
    @Override
    public ResponseEntity<ActivityDTO> addInteractionActivity(String authorization, AddInteractionActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        Activity activity = activitiesService.addInteractionActivity(userName,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getDescription(),
                body.getBrand(),
                body.getRegion(),
                body.getExternalCode(),
                body.getProperties(),
                body.getRemark(),
                body.getPriority(),
                body.getMsgTemplate(),
                ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages())
        );
        ActivityDTO activityDTO = ActivityAssembler.toActivityDTO(activity);
        return new ResponseEntity<>(activityDTO, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ActivityDTO> addOrderActivity(String authorization, AddOrderActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        Activity activity = activitiesService.addOrderActivity(
                userName,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getDescription(),
                body.getBrand(),
                body.getRegion(),
                body.getExternalCode(),
                body.getProperties(),
                body.getRemark(),
                body.getPriority(),
                ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages()));
        ActivityDTO activityDTO = ActivityAssembler.toActivityDTO(activity);
        return new ResponseEntity<>(activityDTO, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ActivityDTO> addRedemptionActivities(String authorization, AddRedemptionActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        Activity activity = activitiesService.addRedemptionActivity(userName, body, ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages()));
        ActivityDTO activityDTO = ActivityAssembler.toActivityDTO(activity);
        return new ResponseEntity<>(activityDTO, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ActivityDTO> addTierActivity(String authorization, AddTierActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        Activity activity = activitiesService.addTierActivity(
                userName,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getDescription(),
                body.getBrand(),
                body.getRegion(),
                body.getExternalCode(),
                body.getProperties(),
                body.getRemark(),
                body.getPriority());
        ActivityDTO activityDTO = ActivityAssembler.toActivityDTO(activity);
        return new ResponseEntity<>(activityDTO, HttpStatus.OK);
    }
    /***
     * 添加礼包到活动中
     * @param authorization 用户会话token
     * @param activityId 活动ID
     * @param body  请求的参数
     * @return 返回http status
     */
    @Override
    public ResponseEntity<Void> addSingleRedemptionGift(String authorization, String activityId, AddRedemptionGiftCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ParamValidator.freight(body.getFreight());
        LocalDateTime startAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime endAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());
        RedemptionItem redemptionItem = new RedemptionItem(body.getStock(), body.getGiftId(), body.getLimit(),
                body.getPoint(), Optional.ofNullable(body.getTransitPoint()).orElse(0),body.getTierLevel(),
                body.getLogisticsGiftId(), Optional.ofNullable(body.getFreight()).orElse(0.0),
                Optional.ofNullable(body.getPriority()).orElse(0), startAt, endAt);
        redemptionItem.configGroup(body.getGroupName());
        redemptionItem.setGradeName(body.getGradeName());

        activitiesService.addSingleRedemptionGift(userName, activityId, redemptionItem);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateSingleRedemptionGift(String authorization, String activityId, String giftId, UpdateRedemptionGiftCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ParamValidator.freight(body.getFreight());
        LocalDateTime startAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime endAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());
        RedemptionItem redemptionItem = new RedemptionItem(body.getStock(), giftId, body.getLimit(),
                body.getPoint(),Optional.ofNullable(body.getTransitPoint()).orElse(0), body.getTierLevel(),
                body.getLogisticsGiftId(), Optional.ofNullable(body.getFreight()).orElse(0.0),
                Optional.ofNullable(body.getPriority()).orElse(0), startAt, endAt);
        redemptionItem.configGroup(body.getGroupName());
        redemptionItem.setGradeName(body.getGradeName());
        activitiesService.updateSingleRedemptionGift(userName, activityId, redemptionItem);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteInteractionActivityById(String authorization, String activityId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteActivityById(userName, activityId, TransactionType.INTERACTION);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteOrderActivityById(String authorization, String activityId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteActivityById(userName, activityId, TransactionType.ORDER);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteRedemptionActivityById(String authorization, String activityId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteActivityById(userName, activityId, TransactionType.REDEMPTION);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteTierActivityById(String authorization, String activityId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteActivityById(userName, activityId, TransactionType.TIER);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteSingleGiftByGiftId(String authorization, String activityId, String giftId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteSingleGiftByGiftId(userName, activityId, giftId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<InteractionActivityListDTO> findInteractionActivityList(String authorization, String brand, String region, Integer perPage, Integer page, OffsetDateTime startAt, OffsetDateTime endAt, String name) {
        PageableResult<Activity> result = activitiesService.queryInteractionActivities(region,
                brand, name, perPage, page,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt));
        InteractionActivityListDTO interactionActivityListDTO = ActivityAssembler.toInteractionActivityListDTO(result);
        return ResponseEntity.ok(interactionActivityListDTO);
    }

    @Override
    public ResponseEntity<OrderActivityListDTO> findOrderActivityList(String authorization, String brand, String region, Integer perPage, Integer page, OffsetDateTime startAt, OffsetDateTime endAt, String name) {
        PageableResult<Activity> result = activitiesService.queryOrderActivities(region,
                brand, name, perPage, page, LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt));
        OrderActivityListDTO orderActivityListDTO = ActivityAssembler.toOrderActivityListDTO(result);
        return ResponseEntity.ok(orderActivityListDTO);
    }

    @Override
    public ResponseEntity<RedemptionActivityListDTO> findRedemptionActivityList(String authorization, String brand, String region, Integer perPage, Integer page, OffsetDateTime startAt, OffsetDateTime endAt, String name, String pointType, String language) {
        PageableResult<Activity> pageableResult = activitiesService.queryRedemptionActivities(region,
                brand, pointType, name, perPage, page,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt));
        Map<String, Gift> giftMap = new HashMap<>();

        for (Activity activity : pageableResult.getRecords()) {
            Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
            for (String key : redemptionItemMap.keySet()) {
                Gift gift = cacheService.getGiftById(key);
                if (gift != null ) {
                    giftMap.putIfAbsent(key,gift);
                }
            }
        }

        RedemptionActivityListDTO redemptionActivityListDTO = ActivityAssembler.toRedemptionActivityListDTO(pageableResult,giftMap);
        return ResponseEntity.ok(redemptionActivityListDTO);
    }

    @Override
    public ResponseEntity<TierActivityListDTO> findTierActivityList(String authorization, String brand, String region, Integer perPage, Integer page, OffsetDateTime startAt, OffsetDateTime endAt, String name) {
        PageableResult<Activity> result = activitiesService.queryTierActivities(region,
                brand, name, perPage, page, LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(startAt),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(endAt));
        TierActivityListDTO tierActivityListDTO = ActivityAssembler.toTierActivityListDTO(result);
        return ResponseEntity.ok(tierActivityListDTO);
    }

    @Override
    public ResponseEntity<InteractionActivityDetailsDTO> findInteractionActivityById(String authorization, String activityId) {
        Activity activity = activitiesService.queryInteractionActivityById(activityId);
        InteractionActivityDetailsDTO interactionActivityDetailsDTO = ActivityAssembler.toInteractionActivityDetailsDTO(activity);
        return ResponseEntity.ok(interactionActivityDetailsDTO);
    }

    @Override
    public ResponseEntity<OrderActivityDetailsDTO> findOrderActivityById(String authorization, String activityId) {
        Activity activity = activitiesService.queryOrderActivityById(activityId);
        OrderActivityDetailsDTO orderActivityDetailsDTO = ActivityAssembler.toOrderActivityDetailsDTO(activity);
        return ResponseEntity.ok(orderActivityDetailsDTO);
    }

    @Override
    public ResponseEntity<RedemptionActivityForC2ListDTO> fetchRedemptionActivityListDeliveredByC2(OffsetDateTime createdTimeFrom, OffsetDateTime createdTimeTo) {
        OffsetDateTime queryCreatedTimeTo = (createdTimeTo != null) ? createdTimeTo : OffsetDateTime.now();
        OffsetDateTime queryCreatedTimeFrom = (createdTimeFrom != null) ? createdTimeFrom : queryCreatedTimeTo.minusYears(1);
        List<Activity> activities = activitiesService.fetchRedemptionActivityListDeliveredByC2(
                TransactionType.REDEMPTION,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(queryCreatedTimeFrom),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(queryCreatedTimeTo)
        );
        RedemptionActivityForC2ListDTO redemptionActivityForC2ListDTO = ActivityAssembler.toRedemptionActivityListForC2DTO(activities);
        return ResponseEntity.ok(redemptionActivityForC2ListDTO);

    }

    @Override
    public ResponseEntity<RedemptionActivityDetailsDTO> findRedemptionActivityById(String authorization, String activityId, String language) {
        Activity activity = activitiesService.queryRedemptionActivityById(activityId);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
        List<Gift> gifts = new ArrayList<>();
        for (String key : redemptionItemMap.keySet()) {
            Gift gift = cacheService.getGiftById(key);
            if (gift != null) {
                gifts.add(gift);
            }
        }
        List<Activity> activities = new ArrayList<>();
        activities.add(activity);
        Map<String, Integer> activityPointMap = transactionService.getRedemptionPointAggregation(activities);
        RedemptionActivityDetailsDTO redemptionActivityDetailsDTO = ActivityAssembler
                .toRedemptionActivityDetailsDTO(activity, loyaltyStructure, redemptionItemMap, gifts, activityPointMap);
        //HK PAMPERS门店多语言
        giftService.translateGiftCouponForHkPampers(language, loyaltyStructure.getRegion(), activity.getBrand(), redemptionActivityDetailsDTO.getRecords());
        return ResponseEntity.ok(redemptionActivityDetailsDTO);
    }

    @Override
    public ResponseEntity<TierActivityDetailsDTO> findTierActivityById(String authorization, String activityId) {
        Activity activity = activitiesService.queryTierActivityById(activityId);
        TierActivityDetailsDTO tierActivityDetailsDTO = ActivityAssembler.toTierActivityDetailsDTO(activity);
        return ResponseEntity.ok(tierActivityDetailsDTO);
    }

    @Override
    public ResponseEntity<ActivityGiftListDTO> findGiftListByActivityId(String activityId, Boolean fetchExpired,
                                                                        Integer perPage, Integer page, String giftIdOrName, String language) {
        ParamValidator.validateLanguage(language);
        Activity activity = activitiesService.queryRedemptionActivityById(activityId);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        Map<String, RedemptionItem> redemptionItemMap = null;
        if (Boolean.TRUE.equals(fetchExpired)) {
            redemptionItemMap = activity.getGifts();
        } else {
            redemptionItemMap = activity.getGifts().entrySet().stream()
                    .filter(item -> item.getValue().availablePeriod())
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        }
        Map<String, Gift> giftMap = new HashMap<>();
        Map<String, GiftCoupon> couponMap = new HashMap<>();
        for (Map.Entry<String, RedemptionItem> entry : redemptionItemMap.entrySet()) {
            String giftId = entry.getKey();
            RedemptionItem redemptionItem = entry.getValue();
            Integer issuedNum = cacheService.getIssuedNum(activityId, giftId);
            redemptionItem.setIssuedNum(issuedNum);
            if (!giftMap.containsKey(giftId)) {
                Gift gift = cacheService.getGiftById(giftId);
                if(gift == null){
                    continue;
                }
                if (gift.couponGift()) {
                    GiftCoupon giftCoupon = giftService.findOneGiftCouponByBagSku(gift.getBagSku(), activity.getBrand(), loyaltyStructure.getRegion());
                    if (giftCoupon != null) {
                        couponMap.put(gift.getBagSku(), giftCoupon);
                    }
                }
                giftMap.put(giftId, gift);
            }
        }
        List<RedemptionGiftDTO> giftDTOS = ActivityAssembler.toRedemptionGiftDTOList(redemptionItemMap,
                new ArrayList<>(giftMap.values()), couponMap, language);
        if (!StringUtils.isEmpty(giftIdOrName)) {
            giftDTOS = giftDTOS.stream()
                    .filter(giftDTO -> StringUtils.equalsAny(giftIdOrName, giftDTO.getGiftId(), giftDTO.getGiftName()))
                    .collect(Collectors.toList());
        }
        int totalSize = giftDTOS.size();
        PageableResult<RedemptionGiftDTO> pageableResult = cacheService
                .generatePage(page, perPage, giftDTOS, null);
        ActivityGiftListDTO activityGiftListDTO = ActivityAssembler
                .toActivityGiftListDTO(activity, pageableResult.getRecords(), totalSize);
        //HK PAMPERS门店多语言
        giftService.translateGiftCouponForHkPampers(language, loyaltyStructure.getRegion(), activity.getBrand(), activityGiftListDTO.getRecords());
        return ResponseEntity.ok(activityGiftListDTO);
    }

    @Override
    public ResponseEntity<Void> modifyInteractionActivity(String authorization, String activityId, UpdateInteractionActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.updateInteractionActivityInfo(userName, activityId,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                body.getDescription(),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getProperties(),
                body.getRemark(),
                body.getPriority(),
                body.getMsgTemplate(),
                ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages()));
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> modifyOrderActivity(String authorization, String activityId, UpdateOrderActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.updateOrderActivityInfo(userName, activityId,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                body.getDescription(),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getProperties(),
                body.getRemark(),
                body.getPriority(),
                ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages()));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> modifyTierActivity(String authorization, String activityId, UpdateTierActivityCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.updateTierActivityInfo(userName, activityId,
                body.getActivityName(),
                body.getPointType(),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt()),
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt()),
                body.getDescription(),
                ActivityStatus.valueOf(body.getStatus().name()),
                body.getProperties(),
                body.getRemark(),
                body.getPriority());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> modifyRedemptionActivityById(String authorization, String activityId, UpdateRedemptionActivityCommand body) {
        //1.判断所有的礼品是否有添加或者删除或者减少的
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.updateRedemptionActivityInfo(userName, activityId, body, ActivityAssembler.toActivityDisplayMsg(body.getDisplayLanguages()));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> modifyRedemptionGiftInventory(String authorization, String activityId, String giftId, UpdateInventoryCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.modifyGiftInventory(userName, activityId, giftId, body.getAmount());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateInteractionActivityStatus(String authorization, String activityId, UpdateStatusCommand body) {
        // 前端展示活动状态时：ACTIVITY/END 当用户将状态 ACTIVITY -> END
        // 到后端后将前端的结束END状态改成后端对应的INITIAL状态
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ActivityStatus activityStatus = ActivityStatus.ACTIVATE;
        if (body.getStatus() == UpdateStatusCommand.StatusEnum.END) {
            activityStatus = ActivityStatus.INITIAL;
        }
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.INTERACTION, activityStatus);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateOrderActivityStatus(String authorization, String activityId, UpdateStatusCommand body) {
        // 前端展示活动状态时：ACTIVITY/END 当用户将状态 ACTIVITY -> END
        // 到后端后将前端的结束END状态改成后端对应的INITIAL状态
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ActivityStatus activityStatus = ActivityStatus.ACTIVATE;
        if (body.getStatus() == UpdateStatusCommand.StatusEnum.END) {
            activityStatus = ActivityStatus.INITIAL;
        }
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.ORDER, activityStatus);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateTierActivityStatus(String authorization, String activityId, UpdateStatusCommand body) {
        // 前端展示活动状态时：ACTIVITY/END 当用户将状态 ACTIVITY -> END
        // 到后端后将前端的结束END状态改成后端对应的INITIAL状态
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ActivityStatus activityStatus = ActivityStatus.ACTIVATE;
        if (body.getStatus() == UpdateStatusCommand.StatusEnum.END) {
            activityStatus = ActivityStatus.INITIAL;
        }
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.TIER, activityStatus);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionActivityStatus(String authorization, String activityId, UpdateStatusCommand body) {
        // 前端展示活动状态时：ACTIVITY/END 当用户将状态 ACTIVITY -> END
        // 到后端后将前端的结束END状态改成后端对应的INITIAL状态
        String userName = JwtUtils.getUsernameFromToken(authorization);
        ActivityStatus activityStatus = ActivityStatus.ACTIVATE;
        if (body.getStatus() == UpdateStatusCommand.StatusEnum.END) {
            activityStatus = ActivityStatus.INITIAL;
        }
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.REDEMPTION, activityStatus);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    /**
     * @param authorization tj
     * @param activityId    活动id
     * @param body          添加sku
     * @return 返回
     */
    @Override
    public ResponseEntity<Void> addQrcodeSkuForActivity(String authorization, String activityId, AddQrcodeActivitySkuCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        QrcodeItem qrcodeItem = new QrcodeItem(body.getSku(), QrcodeItem.ProductTypeEnum.valueOf(body.getProductType().name()),
                body.getBasePoint(), body.getExtraPoint(), body.getMultiple(), body.getDescription());
        activitiesService.addQrcodeSkuForActivity(userName, activityId, qrcodeItem);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> deleteQrcodeActivitySkuByActivityIdAndSku(String authorization, String activityId, String skuCode) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        activitiesService.deleteQrcodeActivitySkuByActivityIdAndSku(userName, activityId, skuCode);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<QrcodeActivitySkuListDTO> findQrcodeActivitySkuListByActivityId(String authorization, String activityId, Integer perPage, Integer page, String skuId) {
        //根据前端传过来的activityId进行分页查询
        Activity activity = activitiesService.queryInteractionActivityById(activityId);
        List<QrcodeItem> skus = activity.getQrcodeItems();
        if (!CollectionUtils.isEmpty(skus) && StringUtils.isNotEmpty(skuId)) {
            skus = skus.stream().filter(qrCodeItem -> qrCodeItem.getSku().equals(skuId)).collect(Collectors.toList());
        }
        int totalSize = skus.size();
        PageableResult<QrcodeItem> pageableResult = cacheService.generatePage(page, perPage, skus, null);
        skus = pageableResult.getRecords();
        QrcodeActivitySkuListDTO activitySkuListDTO = ActivityAssembler.toActivitySkuListDTO(skus, totalSize);
        return ResponseEntity.ok(activitySkuListDTO);
    }

    @Override
    public ResponseEntity<Void> updateQrcodeActivitySku(String authorization, String activityId, UpdateQrcodeActivitySkuCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        QrcodeItem qrcodeItem = new QrcodeItem(body.getSku(), QrcodeItem.ProductTypeEnum.valueOf(body.getProductType().name()),
                body.getBasePoint(), body.getExtraPoint(), body.getMultiple(), body.getDescription());
        activitiesService.updateQrcodeActivitySku(userName, activityId, qrcodeItem);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> addActivityDisplayLanguages(String authorization,
                                                            String transactionType,
                                                            String activityId,
                                                            List<ActivityDisplayMsgDTO> displayLanguages) {

        activitiesService.addDisplayLanguages(JwtUtils.getUsernameFromToken(authorization), TransactionType.valueOf(transactionType.toUpperCase()), activityId, ActivityAssembler.toActivityDisplayMsg(displayLanguages));
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
