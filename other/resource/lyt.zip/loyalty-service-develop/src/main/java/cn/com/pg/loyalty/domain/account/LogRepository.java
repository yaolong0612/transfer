package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.Log;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

/**
 * 
 * @author 		Young
 * @date   		2019年4月23日下午4:08:16
 * @description  AccountRepository
 */
@Repository
public interface LogRepository extends DocumentDbRepository<Log, String> {
	@Override
	Log save(Log log);
}
