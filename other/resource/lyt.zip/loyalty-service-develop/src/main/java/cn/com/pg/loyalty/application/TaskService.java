package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.LoyaltyMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.application.dependence.ServiceBusTemplate;
import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.storageentity.AccountByBirthYearMonth;
import cn.com.pg.loyalty.domain.storageentity.TierChangeRecord;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-05 16:02
 */

@Service
@Slf4j
public class TaskService {

    private static final String TIER_RECALCULATE = "_TierTask_";
    private static final String BABY_BIRTH = "_BabyBirth_";
    private static final String SUCCESS = "SUCCESS";
    private static final String REGION = "ML";
    private static final String ACCOUNT_INFO = "account";
    private static final String LOYALTY_STRUCTURE = "loyaltyStructure";

    private static final int DAY_OF_BABY_BIRTHDAY = 1;
    private static final long MONTHS_OF_ONE_YEARS_OLD = 12;
    private static final long MONTHS_OF_TWO_YEARS_OLD = 24;
    private static final long MONTHS_OF_THREE_MONTHS_YEARS_OLD = 3;
    private static final long HALF_A_DAY = 12L;
    private static final String MESSAGE_SERVICE = "messageService";

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private AccountService accountService;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;

    @Autowired
    private ServiceBusTemplate serviceBusTemplate;

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private MessageService messageService;
    @Autowired
    private AccountValidateService accountValidateService;
    @Autowired
    private TierRulesCalculateAble tierRulesCalculateEngine;

    public void tierExpiredRecalculate(LoyaltyStructure loyaltyStructure, TierChangeRecord tierChangeRecord) {

        String loyaltyId = tierChangeRecord.getLoyaltyId();

        //判断redis key有没有执行过
        String tierRecalculateKey = loyaltyId.concat(TIER_RECALCULATE).concat(loyaltyStructure.name());
        String keyValue = stringRedisTemplate.opsForValue().get(tierRecalculateKey);
        if (SUCCESS.equalsIgnoreCase(keyValue)) {
            return;
        }
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        if (account == null) {
            throw new SystemException("ACCOUNT_NOT_FOUND", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, true));
        tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, true));
        account.setUpdatedTime(LocalDateTime.now());
        accountRepository.save(account);
        //等级重算成功存储Redis12小时
        stringRedisTemplate.opsForValue().set(tierRecalculateKey, SUCCESS, HALF_A_DAY, TimeUnit.HOURS);
    }

    public void addPointByBabyBirthdayMonth(LoyaltyStructure loyaltyStructure, AccountByBirthYearMonth accountMessage) {
        String loyaltyId = accountMessage.getLoyaltyId();
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        if (account == null) {
            throw new SystemException("ACCOUNT_NOT_FOUND", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        String birthYearAndMonth = account.getBabyBirthYearAndMonth();
        if (StringUtils.isEmpty(birthYearAndMonth)) {
            return;
        }
        String brand = accountMessage.getBrand();
        //判断redis key有没有执行过
        String keyValue = stringRedisTemplate.opsForValue().get(loyaltyId.concat(BABY_BIRTH).concat(birthYearAndMonth));
        if (StringUtils.isNotEmpty(keyValue) && keyValue.equalsIgnoreCase(SUCCESS)) {
            return;
        }

        int year = Integer.parseInt(birthYearAndMonth.substring(0, 4));
        int month = Integer.parseInt(birthYearAndMonth.substring(4, 6));
        LocalDate babyBirthday = LocalDate.of(year, month, DAY_OF_BABY_BIRTHDAY);
        //当月1日逐条计算上一月年满1岁或2岁的宝宝生日月积分
        LocalDate lastMonth = LocalDate.now().minusMonths(1);
        LocalDate firthDayOfLastMonth = lastMonth.with(TemporalAdjusters.firstDayOfMonth());
        //获取宝宝月龄
        long months = ChronoUnit.MONTHS.between(babyBirthday, firthDayOfLastMonth);

        List<Activity> temp;
        PointType pointType;
        if (months != MONTHS_OF_ONE_YEARS_OLD && months != MONTHS_OF_TWO_YEARS_OLD && months != MONTHS_OF_THREE_MONTHS_YEARS_OLD) {
            return;
        } else if (months == MONTHS_OF_THREE_MONTHS_YEARS_OLD) {
            //宝宝3个月时，赠送一次300分
            temp = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_3.name(), loyaltyStructure.name());
            pointType = cacheService.validatePointType(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_3.name(), loyaltyStructure.name(), TransactionType.INTERACTION);
        } else if (months == MONTHS_OF_ONE_YEARS_OLD) {
            //宝宝一岁时，赠送一次300分
            temp = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_12.name(), loyaltyStructure.name());
            pointType = cacheService.validatePointType(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_12.name(), loyaltyStructure.name(), TransactionType.INTERACTION);
        } else {
            //宝宝二岁时，赠送一次300分
            temp = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_24.name(), loyaltyStructure.name());
            pointType = cacheService.validatePointType(Transaction.PointTypeEnum.BABY_BIRTHDAY_MONTH_24.name(), loyaltyStructure.name(), TransactionType.INTERACTION);
        }
        List<Activity> activities = temp.parallelStream().filter(activity -> activity.thisBrandActivity(brand)).collect(Collectors.toList());
        if (activities.isEmpty()) {
            throw new SystemException("RULE_TEMPLATE_NOT_FOUND", ResultCodeMapper.UNEXPECTED_ERROR);
        }

        //新增一条Interaction记录
        Interaction interaction = new Interaction(loyaltyId, brand, ChannelV2.INTERNAL, loyaltyStructure,
                account.getMemberId());
        //触发宝宝生日月积分规则引擎
        RuleEngineSupport ruleEngineSupport = RuleEngineSupport.babyBirthdayMonthRuleEngineSupportBuild();
        ruleEngineSupport.addFact("activities", activities)
                .addFact(ACCOUNT_INFO, account)
                .addFact("pointType", pointType)
                .addFact("brand", brand)
                .addFact("interaction", interaction)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact("interactionRepository", interactionRepository)
                .addFact("point", 0)  //解决报错的冲突
                .fire();

        RuleEngineSupport.tierRuleEngineSupportBuild().addFact(ACCOUNT_INFO, account)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact("transaction", interaction)
                .addFact("orderRepository", orderRepository)
                .addFact("transactionRepository", transactionRepository)
                .addFact("calculateTierExpired", false)
                .addFact(MESSAGE_SERVICE, messageService)
                .fire();
        account.calculatePoint(interaction, loyaltyStructure);
        batchUpdateDBComponentImpl.saveTransactionAndAccount(interaction, account);

        //加积分成功存储Redis 12小时
        String key = loyaltyId.concat(BABY_BIRTH).concat(birthYearAndMonth);
        String executeFlag = SUCCESS;
        stringRedisTemplate.opsForValue().set(key, executeFlag, HALF_A_DAY, TimeUnit.SECONDS);
    }

    public void handleFirstCounter(Account account, LoyaltyStructure loyaltyStructure, Order earliestOrder, String brand) {
        if (!BrandV2.OLAY.equals(brand)) {
            return;
        }
        //取出时间最早的那条order来处理首单柜信息
        boolean firstCounterFlag = updateFirstPurchase(account, earliestOrder, brand,loyaltyStructure);
        if (firstCounterFlag) {
            //首单柜若有更新则发送ServiceBus
            SubAccount subAccount = account.subAccount(brand, loyaltyStructure.accountTypeOfDefault());
            Map<String, Object> map = new HashMap<>(4);
            map.put("memberId", account.getMemberId());
            map.put("marketingProgramId", loyaltyStructure.marketingProgramId());
            map.put("firstPurchaseStoreCode", subAccount.getFirstPurchaseStoreCode());
            map.put("firstPurchaseTime", subAccount.getFirstPurchaseTime());
            String jsonString = JSON.toJSONString(map);
            sendMessageToServiceBus(jsonString, ServiceBusQueueTopicEnum.OLAY_FIRST_COUNTER_QUEUE_NAME);
            log.info("OrderId:{}已执行首单柜逻辑,首次交易时间是:{}", earliestOrder.getOrderId(), earliestOrder.getOrderDateTime());
        }
    }

    private boolean updateFirstPurchase(Account account, Order earliestOrder, String brand,LoyaltyStructure structure) {
        SubAccount subAccount = account.subAccount(brand,structure.accountTypeOfDefault());
        String firstPurchaseStoreCode = subAccount.getFirstPurchaseStoreCode();
        if (StringUtils.isEmpty(firstPurchaseStoreCode) || subAccount.getFirstPurchaseTime() == null
                || (earliestOrder.getOrderDateTime().isBefore(subAccount.getFirstPurchaseTime()))) {
            //首单信息为空或订单交易时间早于首单时间则更新首单柜信息
            subAccount.firstPurchaseStoreCode(earliestOrder.getStoreCode(), earliestOrder.getOrderDateTime());
            return true;
        }
        long months = ChronoUnit.MONTHS.between(subAccount.getFirstPurchaseTime(), earliestOrder.getOrderDateTime());
        if (months >= MONTHS_OF_TWO_YEARS_OLD) {
            //当前交易时间往前追溯2年
            List<Order> historyOrders = orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                    PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                    brand, TransactionType.ORDER,
                    LoyaltyDateTimeUtils.localDateTimeToString(earliestOrder.getOrderDateTime().minusYears(2)),
                    LoyaltyDateTimeUtils.localDateTimeToString(earliestOrder.getOrderDateTime()));
            historyOrders = historyOrders.stream().filter(order1 -> !order1.groupPurchaseIs()).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(historyOrders)) {
                subAccount.firstPurchaseStoreCode(earliestOrder.getStoreCode(), earliestOrder.getOrderDateTime());
                log.info("OrderId:{}为满2年后再次购买,交易时间是:{}", earliestOrder.getOrderId(), earliestOrder.getOrderDateTime());
                return true;
            }
        }
        return false;
    }

    /**
     * 推送信息到Service Bus
     *
     * @param jsonString
     * @param serviceBusQueueTopicEnum
     */
    public void sendMessageToServiceBus(String jsonString, ServiceBusQueueTopicEnum serviceBusQueueTopicEnum) {
        JSONObject jsonObject = JSON.parseObject(jsonString);
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessage(serviceBusQueueTopicEnum, loyaltyMessage);
    }

    public void updateLogisticsStatus(String transactionId, String deliverCompany, RedemptionStatus status, String reason, String memberId, String brand, String deliveryNumber) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(REGION, brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(partitionKey, transactionId);
        if (redemptionList.isEmpty()) {
            log.error("获取不到兑换订单：{}", transactionId);
            throw new SystemException("获取不到兑换订单", ResultCodeMapper.PARAM_ERROR);
        }
        Redemption redemption = redemptionList.get(0);
        redemption.updateLogisticsCallBack(deliverCompany, reason, status, deliveryNumber);
        redemptionRepository.save(redemption);
    }
}

