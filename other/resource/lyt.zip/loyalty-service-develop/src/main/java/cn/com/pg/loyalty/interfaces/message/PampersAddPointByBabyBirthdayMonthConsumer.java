package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TaskService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.storageentity.AccountByBirthYearMonth;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-28 19:16
 */

@Component
@Slf4j
public class PampersAddPointByBabyBirthdayMonthConsumer extends AbstractConsumer {

    @Autowired
    private TaskService taskService;
    @Autowired
    private CacheService cacheService;

    @Override
    protected void doBusiness(JSONObject message) {
        AccountByBirthYearMonth accountMessage = JSON.toJavaObject(message, AccountByBirthYearMonth.class);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(accountMessage.getRegion(), accountMessage.getBrand());
        taskService.addPointByBabyBirthdayMonth(loyaltyStructure, accountMessage);
        log.info("任务【帮宝适宝宝生日月积分队列】处理完成.........");

    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.PAMPERS_BABY_BIRTHDAY_MONTH_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.PAMPERS_BABY_BIRTHDAY_MONTH_QUEUE_NAME;
    }
}
