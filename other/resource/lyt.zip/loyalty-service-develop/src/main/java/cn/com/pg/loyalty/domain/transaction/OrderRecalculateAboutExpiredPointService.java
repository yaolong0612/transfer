package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics.SubAccountType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.weaver.ast.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.*;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: Hayden
 * @CreateDate: 2021/1/27 19:34
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/1/27 19:34
 * @Version: 1.0
 * @Description:
 */
@Service
public class OrderRecalculateAboutExpiredPointService {
    @Autowired
    TransactionRepositoryV2 transactionRepositoryV2;
    @Autowired
    AccountRepositoryV2 accountRepositoryV2;
    @Autowired
    MessageService messageService;
    @Autowired
    InteractionRepositoryV2 interactionRepositoryV2;

    public void triggerRecalculateAboutExpiredPoint(LoyaltyStructure structure, Account account, List<Order> requestOrders) {
        if (!structure.pointExpire().isOrderDelayExpired()) {
            return;
        }
        if (CollectionUtils.isEmpty(requestOrders)) {
            return;
        }

        List<Order> sortedOrders = requestOrders.stream().sorted(Comparator.comparing(Order::getOrderDateTime)
                .thenComparing(Order.comparatorByOrderCreatedTimeAsc())).collect(Collectors.toList());
        //订单计算会生成ID，判断是否有继承，需要提前判定
        boolean hasInheritanceOrder = requestOrders.parallelStream().anyMatch(o -> !StringUtils.isEmpty(o.getId()));
        String brand = requestOrders.get(0).getBrand();
        if (hasInheritanceOrder) {
            messageService.pushOrderAffectExpiredEvent(account.memberId(), brand, account.getRegion());
            return;
        }
        LocalDate pointAboutExpired = account.pointAboutExpiredDateWithDefault(brand, structure);
        Order lastOrder = sortedOrders.get(sortedOrders.size() - 1);
        //如果订单时间在即将过期时间后，未正常过期，重算
        if (lastOrder.getOrderDateTime().toLocalDate().isAfter(pointAboutExpired)) {
            messageService.pushOrderAffectExpiredEvent(account.memberId(), brand, account.getRegion());
            return;
        }
        LocalDateTime minOrderDateTime = sortedOrders.get(0).getOrderDateTime();
        boolean existed = interactionRepositoryV2.existedExpiredPointAfter(account.loyaltyId(), minOrderDateTime);
        if (existed) {
            messageService.pushOrderAffectExpiredEvent(account.memberId(), brand, account.getRegion());
            return;
        }
        calculateAboutExpiredForOrderDelay(structure, account, lastOrder);
    }

    private void calculateAboutExpiredForOrderDelay(LoyaltyStructure structure, Account account, Order lastOrder) {
        LocalDateTime orderTime = lastOrder.getOrderDateTime();
        LocalDateTime orderNextDay = LoyaltyDateTimeUtils.getBeginTimeOfDate(orderTime.plusDays(1));
        List<Transaction> interactions = transactionRepositoryV2
                .fetchInteractions(account.loyaltyId(), orderNextDay, LocalDateTime.now());
        int point = interactions.parallelStream().filter(interaction -> interaction.point() > 0)
                .mapToInt(Transaction::getPoint).sum();
        int aboutExpirePoint = account.availablePoint(SubAccountType.DEFAULT) - point;
        if (aboutExpirePoint < 0) {
            aboutExpirePoint = 0;
        }
        account.subAccount(lastOrder.brand(), SubAccountType.DEFAULT).updateAboutExpired(aboutExpirePoint,
                structure.pointExpire(ValueType.DEFAULT).orderPointExpiredTime(orderTime).toLocalDate());
        accountRepositoryV2.saveRetrievable(account);
    }
}
