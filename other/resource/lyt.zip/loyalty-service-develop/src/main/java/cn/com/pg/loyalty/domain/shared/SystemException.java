package cn.com.pg.loyalty.domain.shared;

/**
 * @author Simon
 * <p>
 * 自定义异常
 */

public class SystemException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private ResultCodeMapper resultCodeMapper;
    private int subCode;

    public SystemException(String errorMsg, ResultCodeMapper resultCodeMapper) {
        super(errorMsg);
        this.resultCodeMapper = resultCodeMapper;
    }

    public SystemException(String errorMsg, ResultCodeMapper resultCodeMapper, int subCode) {
        super(errorMsg);
        this.resultCodeMapper = resultCodeMapper;
        this.subCode = subCode;
    }

    public SystemException(ResultCodeMapper resultCodeMapper) {
        super(resultCodeMapper.name());
        this.resultCodeMapper = resultCodeMapper;
    }

    public int errorCode() {
        if (subCode > 0) {
            return resultCodeMapper.getCode() * 100 + subCode;
        }
        return resultCodeMapper().getCode();
    }

    public ResultCodeMapper resultCodeMapper() {
        return resultCodeMapper;
    }

}
