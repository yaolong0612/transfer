package cn.com.pg.loyalty.domain.activity.prop;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import java.util.HashSet;
import java.util.Set;

/**
 * @author Hayden on 2020/9/27 18:26.
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderSkuUpAmountExtraPointProperties extends RuleProperties{

    @Min(1)
    private double minAmount;
    @Min(0)
    private int timesOfYear;
    @Min(1)
    private int extraPoint;

    private Set<String> channels = new HashSet<>();

    private boolean compete;

    @NotEmpty
    private Set<String> skus = new HashSet<>();

    public boolean containSku(String sku) {
        return this.skus.contains(sku);
    }

    public boolean conformChannel(String channel) {
        return CollectionUtils.isEmpty(channels) || channels.contains(channel);
    }


}
