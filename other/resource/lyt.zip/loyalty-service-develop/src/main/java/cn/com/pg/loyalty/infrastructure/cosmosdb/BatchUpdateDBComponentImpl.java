package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.application.utils.RetryTemplate;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.BatchUpdateDBComponent;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @author Simon
 * @date 2019/6/12 11:34
 * @description
 **/
@Component
@Slf4j
public class BatchUpdateDBComponentImpl implements BatchUpdateDBComponent {

    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private MessageService messageService;

    @Override
    public void saveTransactionAndAccount(Transaction transaction, Account account) {
        long start = System.currentTimeMillis();
        accountRepository.save(account);
        log.info("saveTransactionAndAccount >> loyaltyId: {}, saveTime: {}，account: {}", account.loyaltyId(), LocalDateTime.now(), account);
        saveTransaction(transaction);
        log.info("Batch Cost Time: {}", System.currentTimeMillis() - start);
    }

    @Override
    public void saveAccountAndTransactionV2(Account account, Transaction... transactionList) {
        long start = System.currentTimeMillis();
        accountRepository.save(account);
        log.info("saveTransactionAndAccount >> loyaltyId: {}, saveTime: {},account:{} ", account.loyaltyId(), LocalDateTime.now(), account);
        for (Transaction transaction : transactionList) {
            saveTransaction(transaction);
        }
        log.info("Batch Cost Time: {}", System.currentTimeMillis() - start);
    }


    private void saveTransaction(Transaction transaction) {
        try {
            RetryTemplate.retry(() -> transactionRepository.save(transaction), 3);
            log.info("保存Transaction数据成功");
        } catch (Exception e) {
            log.info("save transaction error, msg: {}, it will send to service bus", e.getMessage());
            messageService.sendSaveTransactionAndAccountFailedMessage(transaction);
        }
    }

}
