package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Getter
@Setter
public class MLPampersScanCodeProperties extends RuleProperties {
    private Integer fixedPoint;

    /**
     * 连续扫码积分
     */
    private List<NumMappingPoint> seriesMonthPoints = new ArrayList<>();

    /**
     * 连续扫码达到最大后获得积分
     */
    private Integer maxPoint;
    /**
     * 积分类型  DEFAULT,TRANSIT
     */
    private String valueType;

    public Integer maxPoint() {
        return Optional.ofNullable(maxPoint).orElse(0);
    }

    public List<NumMappingPoint> seriesMonthPoints() {
        return Optional.ofNullable(this.seriesMonthPoints).orElse(new ArrayList<>());
    }

}
