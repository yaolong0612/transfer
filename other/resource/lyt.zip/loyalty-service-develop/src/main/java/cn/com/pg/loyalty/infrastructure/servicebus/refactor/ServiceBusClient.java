package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.application.dependence.LoyaltyMessage;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.ServiceBusConfig;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.Message;
import com.microsoft.azure.servicebus.QueueClient;
import com.microsoft.azure.servicebus.TopicClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.time.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class ServiceBusClient {
    @Autowired
    private ServiceBusConfigRefactor serviceBusConfig;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private KpiTemplate kpiTemplate;
    public static final String MSG_REDIS_KEY = "REDISKEY";
    private static final String MEDIA_TYPE_JSON = "application/json";

    public void sendMessage(JSONObject message, ServiceBusBinder serviceBusBinder) {
        sendMessage(message, serviceBusBinder, null, false);
    }

    public void sendScheduleMessage(JSONObject message, ServiceBusBinder serviceBusBinder, LocalDateTime schduleTime) {
        sendMessage(message, serviceBusBinder, schduleTime, false);
    }

    public void sendMessageAsyn(JSONObject message, ServiceBusBinder serviceBusBinder) {
        sendMessage(message, serviceBusBinder, null, true);
    }

    public void sendScheduleMessageAsyn(JSONObject message, ServiceBusBinder serviceBusBinder, LocalDateTime schduleTime) {
        sendMessage(message, serviceBusBinder, schduleTime, true);
    }

    /**
     * 发布订阅
     *
     * @param serviceBusBinder 发布的topic
     * @param messageBody      loyalty 消息
     */
    public void publishTopicMessage(JSONObject messageBody, Map<String, Object> propertiesMap, ServiceBusBinder serviceBusBinder) {
        long start = System.currentTimeMillis();
        ServiceBusClientProperties serviceBusClientProperties = serviceBusConfig.getClientByName(serviceBusBinder);
        String type = serviceBusClientProperties.getType().name();
        if (!ServiceBusBinder.ServiceBusType.TOPIC.name().equalsIgnoreCase(type)) {
            throw new SystemException("please get a right binder", ResultCodeMapper.SERVICE_BUS_ERROR);
        }
        try {
            LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
            loyaltyMessage.setJsonObject(messageBody);
            IMessage message = new Message(JSON.toJSONBytes(loyaltyMessage));
            message.setLabel(serviceBusClientProperties.getGeneralLabel());
            message.setContentType(MEDIA_TYPE_JSON);
            message.setProperties(propertiesMap);
            log.info("send message success: {}", message.getMessageId());
            TopicClient topicClient = (TopicClient) serviceBusClientProperties.getClient();
            topicClient.sendAsync(message).thenRunAsync(() -> {
                log.info("Message acknowledged: Id = {}", message.getMessageId());
            });
        } catch (Exception e) {
            log.error("publish message is error: {}", e.getMessage());
            throw new SystemException(e.getMessage(), ResultCodeMapper.SEND_MESSAGE_ERROR);
        } finally {
            log.info("publish Message QueueName: {}, Cost: {}", serviceBusBinder.name(), System.currentTimeMillis() - start);
        }
    }

    private void sendMessage(JSONObject messageBody, ServiceBusBinder serviceBusBinder, LocalDateTime scheduleTime, boolean isAsyn) {
        ServiceBusClientProperties queueClient = serviceBusConfig.getClientByName(serviceBusBinder);
        String type = queueClient.getType().name();
        if (!ServiceBusBinder.ServiceBusType.QUEUE.name().equalsIgnoreCase(type)) {
            throw new SystemException("please get a right binder", ResultCodeMapper.SERVICE_BUS_ERROR);
        }
        long start = System.currentTimeMillis();
        LocalDateTime startDateTime = LocalDateTime.now();
        boolean isSuccess = true;
        int errorCode = ResultCodeMapper.SUCCESS.getCode();
        String correlationId = RequestContext.getCurrentContext().getCorrelationId();
        String errorMessage = "Success";
        String messageId = null;
        try {
            String generalLabel = queueClient.getGeneralLabel();
            QueueClient client = (QueueClient) queueClient.getClient();
            IMessage message = generateMsg(messageBody, generalLabel, correlationId);
            if (scheduleTime != null) {
                message.setScheduledEnqueueTimeUtc(localDateTimeToUTC(scheduleTime));
            }
            messageId = message.getMessageId();
            if (isAsyn) {
                client.sendAsync(message);
            } else {
                client.send(message);
            }
        } catch (InterruptedException e) {
            log.error(ServiceBusConfig.CURRENT_THREAD_EXCEPTION, e.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("register message  handler failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            log.error("send message async error", e);
            isSuccess = false;
            errorCode = ResultCodeMapper.SEND_MESSAGE_ERROR.getCode();
            throw new SystemException(e.getMessage(), ResultCodeMapper.SEND_MESSAGE_ERROR);
        } finally {
            long costTime = System.currentTimeMillis() - start;
            if (!isSuccess || costTime > 100) {
                Map<String, String> properties = new HashMap<>(1);
                properties.put("messageId", messageId);
                kpiTemplate.sendDependency(correlationId, serviceBusBinder.name(),
                        KpiLog.KpiType.SEND_SERVICE_BUS, startDateTime, costTime,
                        String.valueOf(errorCode), errorMessage, isSuccess, properties);
                log.info("Send Message QueueName: {}, Cost: {}, isSuccess: {}, messageId: {}, errorMsg: {}",
                        serviceBusBinder.name(), costTime, isSuccess, messageId, errorMessage);
            }
        }
    }

    public Instant localDateTimeToUTC(LocalDateTime schduleTime) {
        ZoneId systemDefault = ZoneId.systemDefault();
        ZonedDateTime dateAndTimeInDefault = ZonedDateTime.of(schduleTime, systemDefault);
        ZonedDateTime utcDate = dateAndTimeInDefault.withZoneSameInstant(ZoneOffset.UTC);
        return Instant.from(utcDate);
    }

    public IMessage generateMsg(JSONObject messageBody, String serviceBusGeneralLabel, String correlationId) {
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        loyaltyMessage.setJsonObject(messageBody);
        String messageString = JSON.toJSONString(loyaltyMessage);
        long length = messageString.getBytes().length / 1024;
        int size = 190;
        if (length >= size) {
            String redisKey = UUID.randomUUID().toString();
            stringRedisTemplate.opsForValue().set(redisKey, messageString, 3, TimeUnit.DAYS);
            JSONObject redisKeyBody = new JSONObject();
            redisKeyBody.put(MSG_REDIS_KEY, redisKey);
            loyaltyMessage.setJsonObject(redisKeyBody);
        }
        IMessage message = new Message(JSON.toJSONBytes(loyaltyMessage));
        message.setLabel(serviceBusGeneralLabel);
        message.setContentType(MEDIA_TYPE_JSON);
        message.setCorrelationId(correlationId);
        return message;
    }
}
