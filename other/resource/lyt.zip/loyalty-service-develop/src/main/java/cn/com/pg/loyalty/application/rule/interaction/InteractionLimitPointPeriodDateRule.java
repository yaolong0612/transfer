package cn.com.pg.loyalty.application.rule.interaction;


import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.activity.*;
import cn.com.pg.loyalty.domain.activity.prop.PeriodDateLimitProperties;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.transaction.*;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.*;

import java.util.*;

@Rule(name = "interaction limit point", description = "limit total point period date rule")
public class InteractionLimitPointPeriodDateRule {

    @Condition
    public boolean matchRule(@Fact("activities") List<Activity> activityList) {
        Activity activity = matchActivity(activityList);
        return activity != null;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activityList,
                         @Fact("interaction") Interaction interaction,
                         @Fact("account") Account account,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("transactionRepository") TransactionRepository transactionRepository
    ) {
        Activity activity = matchActivity(activityList);
        if (activity == null) {
            return;
        }
        PeriodDateLimitProperties limitProperties = (PeriodDateLimitProperties) activity.ruleProperties();
        String startTime = LoyaltyDateTimeUtils.localDateTimeToString(limitProperties.getType()
                .periodStartDate(interaction.getCreatedTime(), limitProperties.getInterval()));
        String endTime = LoyaltyDateTimeUtils.localDateTimeToString(
                limitProperties.getType().periodEndDate(interaction.getCreatedTime()));
        String pk = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Transaction> transactions = transactionRepository
                .fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween(pk,
                        account.loyaltyId(), TransactionType.REDEMPTION.name(), 0, startTime, endTime);
        int point = transactions.stream()
                .filter(transaction -> !StringUtils.equals(transaction.getPointType(),
                        Transaction.PointTypeEnum.REDEMPTION_CANCEL.name()))
                .filter(transaction -> filterTransactions(limitProperties, transaction))
                .mapToInt(Transaction::point).sum();
        int remainPoint = limitProperties.getLimitNum() - point - interaction.point();
        if (remainPoint < 0) {
            if (Math.abs(remainPoint) > interaction.point()) {
                remainPoint = -interaction.point();
            }
            PointItem pointItem = new PointItem(remainPoint, activity.description(), activity.activityId());
            interaction.addPoint(pointItem);
        }
        //设置规则引擎执行成功标志
        ruleResult.success();
    }

    private boolean filterTransactions(PeriodDateLimitProperties limitProperties, Transaction transaction) {
        return limitProperties.isLimitTotalAddPoint() || transaction.getTransactionType() == TransactionType.INTERACTION;
    }

    private Activity matchActivity(List<Activity> activityList) {
        Activity activity = null;
        Optional<Activity> activityOpt = activityList.stream()
                .filter(atv -> RuleTemplate.INTERACTION_LIMIT_POINT_PERIOD_DATE_RULE == atv.ruleTemplate())
                .findFirst();
        if (activityOpt.isPresent()) {
            activity = activityOpt.get();
        }
        return activity;
    }

}
