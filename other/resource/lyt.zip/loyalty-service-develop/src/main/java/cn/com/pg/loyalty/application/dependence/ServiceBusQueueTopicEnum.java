package cn.com.pg.loyalty.application.dependence;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author tangjia
 * @date 2019/6/6
 * ServiceBusQueueTopicEnum
 */
public enum ServiceBusQueueTopicEnum {

    /**
     * 调度中心 consumer
     */
    SCHEDULE_CENTER("q_schedule_center", ServiceBusType.QUEUE),
    /**
     * 返回调度中心queue
     */
    SCHEDULE_CENTER_RSP("q_schedule_center_rsp", ServiceBusType.QUEUE),
    /**
     * olay queue name
     */
    OLAY_QUEUE_NAME("q_order_olay", ServiceBusType.QUEUE),
    /**
     * olay refund queue name
     */
    OLAY_REFUND_QUEUE_NAME("q_refund_order_olay", ServiceBusType.QUEUE),
    /**
     * olay first counter queue name
     */
    OLAY_FIRST_COUNTER_QUEUE_NAME("q_first_counter_olay", ServiceBusType.QUEUE),
    /**
     * pampers baby birthday month queue name
     */
    PAMPERS_BABY_BIRTHDAY_MONTH_QUEUE_NAME("q_baby_birthday_month_pampers_tw", ServiceBusType.QUEUE),
    /**
     * tier expired queue name
     */
    TIER_EXPIRED_QUEUE_NAME("q_tier_expired_olay", ServiceBusType.QUEUE),

    /**
     * 修改兑换状态的队列
     */
    UPDATE_REDEMPTION_STATUS_QUEUE_NAME("update_redemption_status_queue", ServiceBusType.QUEUE),
    /**
     * C2兑换获取用户手机号和名称队列
     */
    C2_FIND_NAME_AND_MOBILE_QUEUE("q_c2_name_mobile_queue", ServiceBusType.QUEUE),

    /**
     * 发货状态队列
     */
    DELIVER_GOODS_QUEUE_NAME("deliver_goods_queue", ServiceBusType.QUEUE),
    /**
     * 处理用户积分过期队列
     */
    EXPIRED_POINT_USER_QUEUE_NAME("q_expired_point_user_olay", ServiceBusType.QUEUE),
    /**
     * 处理帮宝适用户积分过期队列
     */
    EXPIRED_PAMPERS_POINT_USER_QUEUE_NAME("q_pampers_point_expired_v3", ServiceBusType.QUEUE),
    /**
     * 处理帮宝适用户积分过期队列
     */
    MIGRATE_ORDER_REFUND_QUEUE_NAME("q_migrate_order_refund_olay", ServiceBusType.QUEUE),
    /**
     * 同步库存
     */
    SYNCHRONIZE_REDIS_INVENTORY_TO_DATABASE_QUEUE_NAME("synchronize_redis_inventory_to_database_queue", ServiceBusType.QUEUE),
    /**
     * 多个保存动作中失败容灾queue
     */
    DISASTER_RECOVERY_QUEUE("q_disaster_recovery", ServiceBusType.QUEUE),

    /**
     * 发送短信队列
     */
    SEND_MESSAGE_TO_CONSUMER_BY_SMS("send_message_to_consumer_by_sms", ServiceBusType.QUEUE),

    /**
     * 转柜信息队列
     */
    SEND_MESSAGE_FOR_TRANSFERSTORE("q_olay_sms_queue", ServiceBusType.QUEUE),
    /**
     * 帮宝适物流发货状态
     */
    LOGISTICS_CALL_BACK_QUEUE("q_back_logistics_shipping_number", ServiceBusType.QUEUE),

    /**
     * 帮宝适消息通知队列
     */
    HKTW_PAMPERS_NOTIFICATION_QUEUE("q_hktw_notification_quene", ServiceBusType.QUEUE),

    /**
     * 等级变化主题
     */
    TOPIC_TIER_CHANGED("t_tier_changed", ServiceBusType.TOPIC),
    /**
     * 帮宝适支付订单支付完成主题
     */
    T_PAMPERS_LOGISTICS_REDEMPTION("t_pampers_logistics_redemption", ServiceBusType.TOPIC),
    /**
     * 帮宝适支付订单支付完成积分系统订阅
     */
    SUBSCRIBE_LOYALTY_REDEMPTION("s_loyalty_consumer", T_PAMPERS_LOGISTICS_REDEMPTION),

    /**
     * 创建账户队列
     */
    ASYNC_ENROLL_ACCOUNT_QUEUE("q_async_enroll_account", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * OPTE退单队列
     */
    OPTE_REFUND_ORDER_QUEUE_NAME("q_opte_refund_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * OPTE订单队列
     */
    OPTE_NORMAL_ORDER_QUEUE_NAME("q_opte_normal_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * BRAUN退单队列
     */
    BRAUN_REFUND_ORDER_QUEUE_NAME("q_braun_refund_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * BRAUN订单队列
     */
    BRAUN_NORMAL_ORDER_QUEUE_NAME("q_braun_normal_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * GILLETTE退单队列
     */
    GILLETTE_REFUND_ORDER_QUEUE_NAME("q_gillette_refund_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * GILLETTE订单队列
     */
    GILLETTE_NORMAL_ORDER_QUEUE_NAME("q_gillette_normal_order", ServiceBusType.QUEUE, ActiveProfile.ML),
    /**
     * 生日月积分
     */
    BIRTHDAY_POINT("q_add_birthday_point", ServiceBusType.QUEUE, ActiveProfile.ML),

    /**
     * ORALB订单队列
     */
    ORALB_NORMAL_ORDER_QUEUE_NAME("q_oralb_normal_order", ServiceBusType.QUEUE, ActiveProfile.ML),

    /**
     * ORALB退单队列
     */
    ORALB_REFUND_ORDER_QUEUE_NAME("q_oralb_refund_order", ServiceBusType.QUEUE, ActiveProfile.ML);


    /**
     * 是queue还是topic名称还是订阅名称
     */
    private String queueOrTopicName;

    private ServiceBusQueueTopicEnum topicEnum;
    /**
     * 服务总线类型
     */
    private ServiceBusType serviceBusType;

    private ActiveProfile activeProfile;

    ServiceBusQueueTopicEnum(String queueOrTopicName, ServiceBusType serviceBusType) {
        this.queueOrTopicName = queueOrTopicName;
        this.serviceBusType = serviceBusType;
        this.activeProfile = ActiveProfile.ALL;
    }

    ServiceBusQueueTopicEnum(String queueOrTopicName, ServiceBusQueueTopicEnum topic) {
        this.queueOrTopicName = queueOrTopicName;
        this.serviceBusType = ServiceBusType.SUBSCRIBE;
        this.topicEnum = topic;
        this.activeProfile = ActiveProfile.ALL;
    }

    ServiceBusQueueTopicEnum(String queueOrTopicName, ServiceBusType serviceBusType, ActiveProfile activeProfile) {
        this.queueOrTopicName = queueOrTopicName;
        this.serviceBusType = serviceBusType;
        this.activeProfile = activeProfile;
    }

    ServiceBusQueueTopicEnum(String queueOrTopicName, ServiceBusQueueTopicEnum topic, ActiveProfile activeProfile) {
        this.queueOrTopicName = queueOrTopicName;
        this.serviceBusType = ServiceBusType.SUBSCRIBE;
        this.topicEnum = topic;
        this.activeProfile = activeProfile;
    }

    public ServiceBusQueueTopicEnum topicEnum() {
        return topicEnum;
    }

    public ActiveProfile activeProfile() {
        return activeProfile;
    }

    public String queueOrTopicName() {
        return this.queueOrTopicName;
    }

    public ServiceBusType serviceBusType() {
        return this.serviceBusType;
    }

    static public ServiceBusQueueTopicEnum fetchServiceBusQueueTopicEnumByName(String name, ServiceBusType serviceBusType) {
        List<ServiceBusQueueTopicEnum> serviceBusQueueTopicEnumlist = Arrays.stream(ServiceBusQueueTopicEnum.values()).filter(item -> item.queueOrTopicName.equals(name) && item.serviceBusType() == serviceBusType).collect(Collectors.toList());
        return serviceBusQueueTopicEnumlist.size() == 0 ? null : serviceBusQueueTopicEnumlist.get(0);
    }

    /**
     * @author tangjia
     * @date 2019/6/6
     * ServiceBusType
     */
    public enum ServiceBusType {
        /**
         * 队列
         */
        QUEUE,
        /**
         * 主题
         */
        TOPIC,
        /**
         * 订阅
         */
        SUBSCRIBE
    }

    public enum ActiveProfile {
        ALL,
        TW,
        ML
    }
}
