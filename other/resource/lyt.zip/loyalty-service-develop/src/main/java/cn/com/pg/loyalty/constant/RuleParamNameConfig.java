package cn.com.pg.loyalty.constant;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/20
 */
public class RuleParamNameConfig {
    public static final String RULE_PARAM_NAME_ACCOUNT = "account";
    public static final String RULE_PARAM_NAME_LOYALTY_ID = "loyaltyId";
    public static final String RULE_PARAM_NAME_ORDER = "order";
    public static final String RULE_PARAM_NAME_REDEMPTION = "redemption";
    public static final String RULE_PARAM_BRAND_STR = "brand";
    public static final String RULE_PARAM_POINT_TYPE = "pointType";
    public static final String RULE_PARAM_POINT_STR = "point";
    public static final String RULE_PARAM_ACTIVITIES = "activities";
    public static final String RULE_PARAM_ACTIVITY = "activity";
    public static final String RULE_PARAM_CHANNEL = "channel";
    public static final String RULE_PARAM_LOYALTY_STRUCTURE = "loyaltyStructure";
    public static final String RULE_PARAM_COMPETE_POINT_ITEMS = "competePointItems";
    public static final String RULE_PARAM_REDEMPTION_PROPERTIES = "redemptionProperties";
    public static final String RULE_PARAM_REDEMPTION_VALUE_TYPE = "valueType";
    public static final String RULE_PARAM_EXTERNAL_BUSINESS_ID = "externalBusinessId";
    public static final String RULE_PARAM_REDEMPTION_GiftItemMap = "paramGiftItemMap";
    public static final String RULE_PARAM_REDEMPTION_RECORDS = "redemptionList";
    public static final String RULE_PARAM_REDEMPTION_DIRECT_DELIVERED = "directDelivered";

    public static final String RULE_PARAM_COMPETE_RULE_RESULT = "ruleResult";
    public static final String LANGUAGE = "LANGUAGE";
    public static final String TRANSACTION_CALCULATE_RESULT="TRANSACTION_CALCULATE_RESULT";
    public static final String RULE_PARAM_COMMON_PROPERTIES = "commonProperties";
    public static final String RULE_PARAM_TIER_CHANGE_SCENE = "tierChangeScene";

}
