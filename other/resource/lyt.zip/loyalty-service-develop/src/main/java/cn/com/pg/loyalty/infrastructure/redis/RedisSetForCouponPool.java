package cn.com.pg.loyalty.infrastructure.redis;

import cn.com.pg.loyalty.domain.gift.CouponPool;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCouponRepository;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RedisSetForCouponPool implements CouponPool {

    @Autowired
    private StringRedisTemplate redisTemplate;
    @Autowired
    private GiftCouponRepository giftCouponRepository;

    private static final String COUPON_CACHE = "COUPON";
    private static final String DELIMITER = ":";
    private static final String COUPON_USED = "COUPON:USED";
    private static final String COUPON_LOCKED = "COUPON:LOCKED";

    @Override
    public void checkAndInit(String sku, String region, String brand) {
        String key = getAllotPoolKey(sku, region, brand);
        if (hasPool(key)) {
            return;
        }
        if (lockedInitCouponPool(sku, region, brand, key)) return;
        checkAndInit(sku, region, brand);
    }

    private boolean lockedInitCouponPool(String sku, String region, String brand, String key) {
        Boolean setup = redisTemplate.opsForValue().setIfAbsent(COUPON_LOCKED, "1", 10, TimeUnit.SECONDS);
        if (Boolean.TRUE.equals(setup)) {
            //双向检测
            if (hasPool(key)) {
                redisTemplate.delete(COUPON_LOCKED);
                return true;
            }
            List<GiftCoupon> giftCoupons = giftCouponRepository.findUsableCouponLimit(sku, region, brand, 200);
            if (CollectionUtils.isEmpty(giftCoupons)) {
                return true;
            }
            String[] couponCodes = giftCoupons.stream().map(GiftCoupon::getCouponCode).toArray(String[]::new);
            redisTemplate.opsForSet().add(key, couponCodes);
            LocalDateTime lastDayStart = LocalDate.now().plusDays(1).atStartOfDay();
            Date date = Date.from(lastDayStart.atZone(TimeZone.getDefault().toZoneId()).toInstant());
            redisTemplate.expireAt(key, date);
            redisTemplate.delete(COUPON_LOCKED);
            return true;
        }
        return false;
    }

    @Override
    public void rollCouponCodeInPool(String sku, String region, String brand, String couponCode) {
        String key = getUsedKey(sku, region, brand);
        redisTemplate.opsForSet().remove(key, couponCode);
    }

    /**
     * 从分配池中分配，再与报废池中进行对比，防止初始化时因竞争插入已经使用的。
     */
    @Override
    public GiftCoupon allotGiftCoupon(String sku, String region, String brand) {
        String key = getAllotPoolKey(sku, region, brand);
        String code = redisTemplate.opsForSet().pop(key);
        if (StringUtils.isEmpty(code)) {
            throw new SystemException("No coupon allot", ResultCodeMapper.UNDER_STOCK);
        }
        boolean addUsedPool = isAddUsedPool(sku, region, brand, code);
        if (!addUsedPool) {
            return allotGiftCoupon(sku, region, brand);
        }

        Optional<GiftCoupon> giftCouponOptional = giftCouponRepository.findByCode(sku, region, brand, code);
        if (!giftCouponOptional.isPresent()) {
            return allotGiftCoupon(sku, region, brand);
        }
        GiftCoupon giftCoupon = giftCouponOptional.get();

        //如果已经被使用，说明报废池存在问题，重新初始化
        if (giftCoupon.beUsed()) {
            initUsedCouponPool(sku, region, brand);
            return allotGiftCoupon(sku, region, brand);
        }
        //如果不能使用，说明分配池出现问题，清空,重新初始化
        if (giftCoupon.canNotBeUsed()) {
            clearAllotPool(sku, region, brand);
            lockedInitCouponPool(sku, region, brand, key);
            return allotGiftCoupon(sku, region, brand);
        }
        return giftCoupon;
    }

    private boolean isAddUsedPool(String sku, String region, String brand, String code) {
        String usedKey = getUsedKey(sku, region, brand);
        Long addNum = redisTemplate.opsForSet().add(usedKey, code);
        redisTemplate.expire(usedKey, 7, TimeUnit.DAYS);
        return addNum != null && addNum.intValue() > 0;
    }

    private boolean hasPool(String key) {
        return Boolean.TRUE.equals(redisTemplate.hasKey(key));
    }

    public void initUsedCouponPool(String sku, String region, String brand) {
        String key = getUsedKey(sku, region, brand);
        List<String> couponCodes = giftCouponRepository.findLastDaysUsedCoupon(sku, region, brand, 2)
                .stream().map(GiftCoupon::getCouponCode).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(couponCodes)) {
            return;
        }
        redisTemplate.opsForSet().add(key, couponCodes.toArray(new String[0]));
    }

    private void clearAllotPool(String sku, String region, String brand) {
        String key = getAllotPoolKey(sku, region, brand);
        redisTemplate.delete(key);
    }

    private String getAllotPoolKey(String sku, String region, String brand) {
        return COUPON_CACHE.concat(DELIMITER).concat(region)
                .concat(DELIMITER).concat(brand).concat(DELIMITER).concat(sku);
    }

    private String getUsedKey(String sku, String region, String brand) {
        return COUPON_USED.concat(DELIMITER).concat(region)
                .concat(DELIMITER).concat(brand).concat(DELIMITER).concat(sku);
    }
}
