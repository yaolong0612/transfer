package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.CacheService.KeyEnum;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Hayden on 2020/9/21 17:57.
 */
@Slf4j
@Service
public class AccountLockedService {
    @Autowired
    private CacheService cacheService;
    private static final long LOCKED_TIME = 1000 * 60 * 5L;

    public boolean lockedUpCompetitionMember(String region, String brand, String memberId) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        String key = getKey(memberId, loyaltyStructure);
        boolean isSet = cacheService.lockedUpCompetition(key, LOCKED_TIME);
        log.info("add lock account: {} ,{}", key, isSet);
        return isSet;
    }


    public void deleteMemberLock(String region, String brand, String memberId) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        String key = getKey(memberId, loyaltyStructure);
        log.info("delete account lock: {}", key);
        cacheService.deleteKey(key);
    }

    private String getKey(String memberId, LoyaltyStructure loyaltyStructure) {
        return cacheService.getKey(KeyEnum.ACCOUNT_LOCK, loyaltyStructure.name(), memberId);
    }
}
