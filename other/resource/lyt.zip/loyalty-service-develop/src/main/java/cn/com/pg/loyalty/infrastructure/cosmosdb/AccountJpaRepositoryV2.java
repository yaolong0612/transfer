package cn.com.pg.loyalty.infrastructure.cosmosdb;



import cn.com.pg.loyalty.domain.account.Account;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 
 * @author 		Young
 * @date   		2019年4月23日下午4:08:16
 * @description  AccountRepository
 */
@Repository
public interface AccountJpaRepositoryV2 extends DocumentDbRepository<Account, String> {

	/**
	 * 一个会员体系下，根据member id只能找到一个Account, 有member id的情况下，没有分区键
	 * @param memberId
	 * @param marketingProgramId
	 * @return
	 */
	List<Account> findByMemberIdAndMarketingProgramId(String memberId, String marketingProgramId);

	/**
	 * 根据分区键和主键查询
	 * @param partitionKey
	 * @param id
	 * @return
	 */
	List<Account> findByPartitionKeyAndId(String partitionKey, String id);

	List<Account> findByMarketingProgramIdAndMemberIdIn(String marketingProgramId,List<String> memberIds);

	@Override
	Account save(Account account);

}
