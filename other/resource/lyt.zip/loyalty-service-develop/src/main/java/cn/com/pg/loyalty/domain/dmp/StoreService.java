package cn.com.pg.loyalty.domain.dmp;

import cn.com.pg.loyalty.domain.shared.CacheService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author vincenzo
 * @description
 * @date 2022/3/18
 */
@Slf4j
@Service
public class StoreService {
    @Autowired
    private CacheService cacheService;

    /**
     * 根据id列表查询门店信息
     *
     * @param storeCodeList
     * @return
     */
    public List<Store> fetchStoreList(List<String> storeCodeList) {
        List<Store> storeList = new ArrayList<>();
        storeCodeList.forEach(storeCode -> Optional.ofNullable(cacheService.getStoreByStoreCode(storeCode)).ifPresent(storeList::add));
        return storeList;
    }
}
