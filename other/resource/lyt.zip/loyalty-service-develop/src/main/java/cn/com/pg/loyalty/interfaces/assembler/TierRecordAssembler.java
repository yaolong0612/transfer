package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.storageentity.TierChangeRecord;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.interfaces.dto.TierHistoryDTO;
import cn.com.pg.loyalty.interfaces.dto.TierRecordDTO;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * @author Yong
 * @date 2019年5月21日下午5:55:44
 * @description Assembler for TierHistoryDTO
 */
public class TierRecordAssembler {

    public static TierHistoryDTO tierRecordsToHistoryDto(LoyaltyStructure structure, Iterable<TierChangeRecord> tierChangeRecords) {
        TierHistoryDTO dto = new TierHistoryDTO();
        List<TierChangeRecord> tierChangeRecordList = new ArrayList<>(5);
        tierChangeRecords.forEach(tierChangeRecord -> {
            tierChangeRecordList.add(tierChangeRecord);
        });
        tierChangeRecordList.sort(Comparator.comparing(TierChangeRecord::getUpgradedTime));
        TierChangeRecord lastTierChangeRecord = null;
        for (TierChangeRecord tierChangeRecord : tierChangeRecordList) {
            TierRecordDTO trd = new TierRecordDTO();
            trd.upgradedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(
                    LoyaltyDateTimeUtils.stringToLocalDateTime(validator(tierChangeRecord.getUpgradedTime()))))
                    .expiredTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(
                            LoyaltyDateTimeUtils.stringToLocalDateTime(validator(tierChangeRecord.getExpiredTime()))))
                    .tierId(tierChangeRecord.getRowKey())
                    .tierLevel(tierChangeRecord.tierLevel(structure));
            if (lastTierChangeRecord != null) {
                trd.previousTierLevel(lastTierChangeRecord.tierLevel(structure));
            }
            dto.addRecordsItem(trd);
            lastTierChangeRecord = tierChangeRecord;
        }
        return dto;
    }

    private static String validator(String time) {
        int length = 23;
        if (time.length() > length){
            time = time.substring(0,23);
        }
        return time;
    }
}
