package cn.com.pg.loyalty.application.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HktwNotificationDTO {
    private String pointType;
    private String memberId;
    private String loyaltyId;
    private String transactionId;
    private String brand;
    private String messageType;

    @Getter
    public enum MessageType{
        // 首次注册
        REGISTER("新入會員任務"),

        // 首次扫码
        SCAN_CODE_FIRST("首購見面禮"),

        // 每月第二次扫码
        SCAN_CODE_MONTH_SECOND("忠實客戶獎勵禮"),

        // 宝宝周岁
        BABY_BIRTHDAY("寶寶周歲歡慶禮"),

        // 积分过期
        POINT_EXPIRED("积分过期");

        private String description;

        MessageType(String description){
            this.description = description;
        }
    }
}
