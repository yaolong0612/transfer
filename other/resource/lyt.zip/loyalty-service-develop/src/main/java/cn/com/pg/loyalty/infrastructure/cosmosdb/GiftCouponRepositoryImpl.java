package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCoupon.CouponStatus;
import cn.com.pg.loyalty.domain.gift.GiftCouponRepository;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import com.microsoft.azure.documentdb.*;
import com.microsoft.azure.spring.data.cosmosdb.core.convert.MappingDocumentDbConverter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class GiftCouponRepositoryImpl implements GiftCouponRepository {

    @Autowired
    GiftCouponJpaRepository giftCouponJpaRepository;
    @Autowired
    private DocumentClient documentClient;
    @Autowired
    private CosmosDbConfig cosmosDbConfig;
    @Autowired
    private MappingDocumentDbConverter mappingDocumentDbConverter;

    @Override
    public GiftCoupon save(GiftCoupon giftCoupon) {
        return giftCouponJpaRepository.save(giftCoupon);
    }

    @Override
    public List<GiftCoupon> findUsableCouponLimit(String sku, String region, String brand, int limit) {
        String now = LoyaltyDateTimeUtils.localDateToDataString(LocalDate.now());
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter("@sku", sku),
                new SqlParameter("@region", region),
                new SqlParameter("@brand", brand),
                new SqlParameter("@endAt", now),
                new SqlParameter("@startAt", now),
                new SqlParameter("@limit", limit));
        String sql = "select TOP @limit * from c where c.bagSku= @sku and c.region= @region and c.brand= @brand" +
                " and c.status='ALIVE' and c.startAt<= @startAt and c.endAt>= @endAt ";
        SqlQuerySpec sqs = new SqlQuerySpec(sql, spc);
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(PartitionKeyUtils.GIFT_PARTITIONKEY));
        FeedResponse<Document> response = documentClient
                .queryDocuments(cosmosDbConfig.getCollectionLink(GiftCoupon.class), sqs, feedOptions);
        Iterator<Document> it = response.getQueryIterator();
        log.info("charge:{}",response.getRequestCharge());
        List<GiftCoupon> result = new ArrayList<>();
        while (it.hasNext()) {
            Document document = it.next();
            if (document != null) {
                result.add(mappingDocumentDbConverter.read(GiftCoupon.class, document));
            }
        }
        return result;
    }

    @Override
    public Optional<GiftCoupon> findByCode(String sku, String region, String brand, String couponCode) {
        return giftCouponJpaRepository.findByBagSkuAndRegionAndBrandAndCouponCode(sku, region, brand, couponCode)
                .stream().findFirst();
    }

    @Override
    public List<GiftCoupon> findByMemberIdAndBrandAndRegion(String memberId, String brand, String region) {
        return giftCouponJpaRepository.findByMemberIdAndBrandAndRegion(memberId, brand, region);
    }

    @Override
    public List<GiftCoupon> findMemberCouponByTransactionId(String memberId, String brand, String region, String transactionId) {
        return giftCouponJpaRepository.findByMemberIdAndBrandAndRegionAndTransactionId(memberId, brand, region, transactionId);
    }


    @Override
    public GiftCoupon findTopByBagSku(String bagSku, String brand, String region) {
        long start = System.currentTimeMillis();
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter("@sku", bagSku),
                new SqlParameter("@region", region),
                new SqlParameter("@brand", brand),
                new SqlParameter("@limit", 1));
        String sql = "select TOP @limit * from c where c.bagSku= @sku and c.region= @region and c.brand= @brand";
        SqlQuerySpec sqs = new SqlQuerySpec(sql, spc);
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(PartitionKeyUtils.GIFT_PARTITIONKEY));
        FeedResponse<Document> response = documentClient
                .queryDocuments(cosmosDbConfig.getCollectionLink(GiftCoupon.class), sqs, feedOptions);
        Iterator<Document> it = response.getQueryIterator();
        log.info("charge:{},cost: {}",response.getRequestCharge(),System.currentTimeMillis()-start);
        if (it.hasNext()) {
            return mappingDocumentDbConverter.read(GiftCoupon.class, it.next());
        }
        return null;
    }

    @Override
    public List<GiftCoupon> findByRegionAndBrandAndStoreName(String region, String brand, String storeName) {
        return giftCouponJpaRepository.findByRegionAndBrandAndStoreName(region, brand, storeName);
    }


    @Override
    public List<GiftCoupon> findLastDaysUsedCoupon(String sku, String region, String brand, int lastDays) {
        LocalDateTime startTime = LocalDate.now().atStartOfDay().minusDays(lastDays);
        return giftCouponJpaRepository.findByBagSkuAndRegionAndBrandAndStatusAndUpdatedTimeGreaterThan(
                sku, region, brand, CouponStatus.USED, startTime);
    }

    @Override
    public List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSku(String region, String brand, String storeName, String bagSku) {
        return giftCouponJpaRepository.findByRegionAndBrandAndStoreNameAndBagSku(region, brand, storeName, bagSku);
    }

    @Override
    public List<GiftCoupon> findByRegionAndBrandAndStoreNameAndCreatedTimeBetween(String region, String brand, String storeName, String start, String end) {
        return giftCouponJpaRepository.findByRegionAndBrandAndStoreNameAndCreatedTimeBetween(region, brand, storeName, start, end);
    }

    @Override
    public List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSkuAndCreatedTimeBetween(String region, String brand, String storeName, String bagSku, String start, String end) {
        return giftCouponJpaRepository.findByRegionAndBrandAndStoreNameAndBagSkuAndCreatedTimeBetween(region, brand, storeName, bagSku, start, end);
    }

    @Override
    public List<GiftCoupon> findByRegionAndBrandAndCouponCode(String region, String brand, String couponCode) {
        return giftCouponJpaRepository.findByRegionAndBrandAndCouponCode(region,brand,couponCode);
    }
}
