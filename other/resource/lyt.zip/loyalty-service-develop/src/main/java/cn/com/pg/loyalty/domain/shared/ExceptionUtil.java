package cn.com.pg.loyalty.domain.shared;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2020-02-18 18:22
 */
public class ExceptionUtil {

    private ExceptionUtil() {
        throw new IllegalStateException("ExceptionUtil class");
    }

    /**
     * 设定截取日志的行数
     */
    private static final int MAXSIZE = 10;

    /**
     * 构造异常堆栈信息
     * @param ex
     * @return
     */
    public static String getStackTraceErrorMessage(Throwable ex) {
        if (null == ex) {
            return null;
        }
        String stackTrace = getStackTraceString(ex);
        String exceptionString = ex.toString();
        String exceptionMessage = ex.getMessage();
        return String.format("%s : %s %n %s", exceptionString, exceptionMessage, stackTrace);
    }

    /**
     * 打印异常堆栈信息
     * @param ex
     * @return
     */
    private static String getStackTraceString(Throwable ex){
        StackTraceElement[] traceElements = ex.getStackTrace();
        if (null != traceElements && traceElements.length > 0) {
            return Arrays.stream(traceElements).limit(MAXSIZE).map(StackTraceElement::toString)
                    .collect(Collectors.joining("\n"));
        }
        return null;
    }
}
