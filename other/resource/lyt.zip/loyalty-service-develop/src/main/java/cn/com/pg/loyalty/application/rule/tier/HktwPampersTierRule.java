package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-03 19:03
 */

@Rule(name = "Tier upgrade rule: Pampers rule",
        description = "calculate tier by point")
public class HktwPampersTierRule {

    private static final int POINT_OF_PURPLE = 500;
    private static final int POINT_OF_GOLD = 1500;
    private static final String ACTIVITY_ID_TIER_AWARD_POINT = "TIER_AWARD_POINT";
    private static final String ACTIVITY_DESCRIPTION_TIER_AWARD_POINT = "bonus points of tier";

    @Condition
    public boolean isExecuteHktwPampersTier(@Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        //只有HK/TW Pampers订单积分，才会导致等级变动和执行. 如果是年底积分算积分过期，Job会去执行
        return (loyaltyStructure.checkHkBrand(BrandV2.PAMPERS) || loyaltyStructure.checkTwBrand(BrandV2.PAMPERS));
    }

    @Action
    public void upgrade(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("transaction") Transaction transaction,
                        @Fact("ruleResult") RuleResult ruleResult) {
        //获取当前等级
        Tier tier = account.tier(loyaltyStructure.name());
        TierLevelSeries tierLevelSeries=loyaltyStructure.tierLevelSeries();
        String currentTier = tier.getLevel();
        int tierPoint;
        if (!tier.judgeTierExpired()) {
            //等级没有过期
            tierPoint = tier.addTierPoint(transaction.getPoint() > 0 ? transaction.getPoint() : 0);
            //获取当前等级及计算加积分后得到升级/降级后的等级
            String nextLevel =tierLevelSeries.nextLevelByPoint(currentTier,tierPoint).getLevelName();
            //升级到下一个等级
            if (tierLevelSeries.compare(currentTier,nextLevel) < 0) {
                //重置TierPoint
                Tier newTier = new Tier(loyaltyStructure, nextLevel, tier.getLevel());
                //更新等级
                account.tier(loyaltyStructure, newTier);
                //升级额外赠送500/1500升级积分
                PointItem pointItem = new PointItem();
                if (tierLevelSeries.getLevelByName(newTier.getLevel()).getLevel()==2) {
                    pointItem.setActivityId(ACTIVITY_ID_TIER_AWARD_POINT);
                    pointItem.setDescription(ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
                    pointItem.setPoint(POINT_OF_PURPLE);
                    //给TierPoint加上升级成功后的额外赠送的500升级积分
                    newTier.addTierPoint(POINT_OF_PURPLE);
                } else {
                    pointItem.setActivityId(ACTIVITY_ID_TIER_AWARD_POINT);
                    pointItem.setDescription(ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
                    pointItem.setPoint(POINT_OF_GOLD);
                    //给TierPoint加上升级成功后的额外赠送的1500升级积分
                    newTier.addTierPoint(POINT_OF_GOLD);
                }
                //加总积分
                transaction.addPoint(pointItem);
            }
        } else {
            //等级已过期，重置TierPoint
            String nextLevel =tierLevelSeries.nextLevelByPoint( tier.getLevel(),tier.getTierPoint()).getLevelName();
            Tier newTier = new Tier(loyaltyStructure, nextLevel, tier.getLevel());
            if (tierLevelSeries.compare(currentTier,nextLevel)==0) {
                //等级过期且保级成功,则分别加500/1500保级积分
                PointItem pointItem = new PointItem();
                if (tierLevelSeries.getLevelByName(tier.getLevel()).getLevel()==1) {
                    account.tier(loyaltyStructure, newTier);
                    ruleResult.success();
                    return;
                }
                if (tierLevelSeries.getLevelByName(tier.getLevel()).getLevel()==2) {
                    //给TierPoint加上升级成功后的额外赠送的500升级积分
                    newTier.addTierPoint(POINT_OF_PURPLE);
                    pointItem.setActivityId(ACTIVITY_ID_TIER_AWARD_POINT);
                    pointItem.setDescription(ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
                    pointItem.setPoint(POINT_OF_PURPLE);
                } else {
                    //给TierPoint加上升级成功后的额外赠送的1500升级积分
                    newTier.addTierPoint(POINT_OF_GOLD);
                    pointItem.setActivityId(ACTIVITY_ID_TIER_AWARD_POINT);
                    pointItem.setDescription(ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
                    pointItem.setPoint(POINT_OF_GOLD);
                }
                //加总积分
                transaction.addPoint(pointItem);
                account.tier(loyaltyStructure, newTier);
            } else {
                //等级过期且未达到保级，只能逐级降级
                account.tier(loyaltyStructure, newTier);
            }
        }
        ruleResult.success();
    }
}
