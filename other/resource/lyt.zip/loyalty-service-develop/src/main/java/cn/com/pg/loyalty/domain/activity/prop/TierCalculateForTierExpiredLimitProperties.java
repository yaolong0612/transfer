package cn.com.pg.loyalty.domain.activity.prop;

import lombok.*;

@Data
public class TierCalculateForTierExpiredLimitProperties extends RuleProperties{

    /**
     * 等级过期只允许降级到该等级
     */
    private String minTier;
}
