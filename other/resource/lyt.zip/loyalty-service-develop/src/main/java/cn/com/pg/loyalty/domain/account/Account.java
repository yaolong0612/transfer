package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.account.InternalPointPool.PointPoolNode;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics.SubAccountType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.PointExpire;
import cn.com.pg.loyalty.domain.structure.TierLevel;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.PointValueObject.PointValue;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/**
 * @author Young
 * @date 2019年4月2日上午10:20:11
 * @description Account用户信息类
 */
@Document(collection = "Account", ru = "400")
@Getter
@Setter
@ToString
@Slf4j
@NoArgsConstructor
public class Account implements Entity<Account> {

    /**
     * 唯一Loyalty ID
     */
    @Id
    private String id;

    @PartitionKey
    private String partitionKey;
    /**
     * 用户所属区域
     */
    private String region;

    /**
     * 会员系统用户ID：AM，Janrain
     */
    private String memberId;

    /**
     * AM TenantId, 如果是Janrain，需要Loyalty自己指定
     */
    private String marketingProgramId;

    /**
     * 该积分体系下的用户等级信息
     */
    private Map<String, Tier> tierList = new HashMap<>();
    /**
     * 子账户列表，每个品牌一个子账户
     */
    private SubAccounts subAccountList = new SubAccounts();

    /**
     * 宝宝出生日期：yyyyMM
     */
    private String babyBirthYearAndMonth;
    /**
     * 账户创建时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    /**
     * 账户更新时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    /**
     * 所有子账户最近下一次过期的时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate lastPointExpireDate;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate lastTierExpireDate;

    /**
     * 账户状态
     */
    private Map<String, AccountStatus> accountStatus = new HashMap<>();

    /**
     * 可用积分聚合aggregation，map结构
     * expiredPointKey yyyy-MM-dd 例:2021-12-31,2021-12-31
     */
    private InternalPointPool availablePointPool = new InternalPointPool();

    /**
     * 获取Loyalty ID
     */
    public String loyaltyId() {
        return this.id;
    }

    public String memberId() {
        return this.memberId;
    }

    public String region() {
        return this.region;
    }

    /**
     * 注册一个新的Account
     */
    public Account(String memberId, LoyaltyStructure structure) {
        this.id = UUIDUtil.generateLoyaltyId(memberId, structure);
        this.memberId = memberId;
        this.marketingProgramId = structure.getMarketingProgramId();
        this.region = structure.getRegion();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        //init partitionKey
        this.partitionKey = PartitionKeyUtils.getAccountPartitionKey(this.id);
    }

    public void updateAccountStatus(LoyaltyStructure loyaltyStructure, String status) {
        String structureName = loyaltyStructure.getName();
        if (Account.AccountStatus.CLOSED.equals(accountStatus.get(structureName))) {
            throw new SystemException("account is in closed status,can not be modified", ResultCodeMapper.ACCOUNT_STATUS_CLOSED);
        }
        if (accountStatus.get(structureName).name().equals(status)) {
            throw new SystemException("Modification is not needed because the present status of account equals to the status that is expected to change to", ResultCodeMapper.ACCOUNT_NOT_UPDATE_STATUS);
        }
        accountStatus.put(structureName, AccountStatus.valueOf(status));
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 校验所传状态是否为ACTIVATED
     */
    public void checkAccountAvailable(LoyaltyStructure loyaltyStructure) {
        if (AccountStatus.ACTIVATED != this.accountStatus.get(loyaltyStructure.getName())) {
            throw new SystemException("ACCOUNT_STATUS_NOT_ACTIVATED", ResultCodeMapper.ACCOUNT_STATUS_NOT_ACTIVATED);
        }
    }

    /**
     * 直接把Event返回，用来做加积分逻辑。暂时不采用事件抛出机制实现
     * 更改：加入了替换子账户（成长值等）逻辑，做过渡使用
     */
    public RegistryEvent register(LoyaltyStructure structure, String brand, String channel, String bindId,
                                  LocalDateTime registerTime) {
        RegistryEvent registryEvent = null;
        boolean extraSubAccount = structure.subAccountType(ValueType.DEFAULT).callExtraSubAccount();
        if (!subAccountList.hasRegisterAny(brand)) {
            //对品牌来说，是新member，需要注册
            registryEvent = RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT;
            subAccountList.registerSubAccount(brand, extraSubAccount, new SubAccount(channel, bindId, registerTime));
        } else if (!subAccountList.hasAnyBindChannel(brand, channel)) {
            //对品牌来说，是绑定事件
            registryEvent = RegistryEvent.BINDING_EVENT;
            subAccountList.subAccount(brand, extraSubAccount).bind(channel, bindId);
        }
        //如果积分状态为空，则激活
        accountStatus.putIfAbsent(structure.name(), AccountStatus.ACTIVATED);
        //如果会员不能加积分，则将事件设置为空
        if (!accountStatus.get(structure.getName()).judgeAddPoint()) {
            registryEvent = null;
        }
        // 如果Tier为空，需要初始化等级
        tierList.putIfAbsent(structure.name(), new Tier(structure));
        this.updatedTime = LocalDateTime.now();
        return registryEvent;
    }

    public boolean newMember4Brand(String brand) {
        return subAccount(brand) == null;
    }

    public void babyBirthYearAndMonth(String babyBirthYearAndMonth) {
        this.babyBirthYearAndMonth = babyBirthYearAndMonth;
    }

    public String babyBirthYearAndMonth() {
        return this.babyBirthYearAndMonth;
    }

    /**
     * 计算交互积分：加积分|减积分
     * 开启积分池：维护积分池
     */
    public void calculatePoint(Interaction interaction, LoyaltyStructure structure) {
        SubAccount subAccount = this.adapterSubAccount(structure, interaction);
        this.updatedTime = LocalDateTime.now();
        if (interaction.getPoint() > 0) {
            subAccount.addPoint(interaction.getPoint(), interaction.expiredDate(), interaction.getUnlockTime());
            calculatePointPool(structure, subAccount, interaction.expiredDate(), interaction.getPoint());
            this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
            return;
        }
        subAccount.consumePoint(Math.abs(interaction.getPoint()));
        calculatePointPool(structure, subAccount, interaction.expiredDate(), interaction.getPoint());
        this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
    }

    /**
     * 计算订单积分：加积分
     * 订单延迟过期：重算即将过期积分|时间
     * 积分池：维护
     */
    public void calculatePoint(Order order, LoyaltyStructure structure) {
        SubAccount subAccount = this.adapterSubAccount(structure, order);
        subAccount.calculateOrder(order);
        this.updatedTime = LocalDateTime.now();
        //添加积分条目
        calculatePointPool(structure, subAccount, order.expiredDate(), order.getPoint());
        this.triggerOrderRenewExpired(subAccount, structure, order);
        this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
    }

    /**
     * 回滚订单
     */
    public void rollBackPoint(Order order, LoyaltyStructure structure) {
        if (order.point() <= 0) {
            return;
        }
        SubAccount subAccount = this.adapterSubAccount(structure, order);
        subAccount.rollBack(order);
        this.updatedTime = LocalDateTime.now();
        calculatePointPool(structure, subAccount, order.expiredDate(), -order.getPoint());
        this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
    }

    /**
     * 兑换扣减积分
     */
    public void calculatePoint(Redemption redemption, LoyaltyStructure structure) {
        int point = Math.abs(redemption.getPoint());
        SubAccount subAccount = this.adapterSubAccount(structure, redemption);
        if (availablePoint(structure.subAccountType(redemption)) < point) {
            throw new SystemException("Not enough points are available for conversion", ResultCodeMapper.NOT_ENOUGH_POINT_ERROR);
        }
        subAccount.consumePoint(point);
        this.updatedTime = LocalDateTime.now();
        //兑换扣减积分情况维护到availablePointPool
        calculatePointPool(structure, subAccount, null, -point);
        this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
    }

    /**
     * 取消兑换
     */
    public void cancelRedemption(Interaction interaction, LoyaltyStructure structure) {
        SubAccount subAccount = this.adapterSubAccount(structure, interaction);
        subAccount.cancelRedemption(interaction.point(), interaction.getExpiredTime().toLocalDate());
        this.updatedTime = LocalDateTime.now();
        calculatePointPool(structure, subAccount, interaction.expiredDate(), interaction.getPoint());
        this.lastPointExpireDate = this.subAccountList.fetchLastExpireDate();
    }

    /**
     * 订单延迟过期：会触发即将过期积分重算
     * 后期如果这种规则过多，可以考虑抽象成规则策略
     */
    private void triggerOrderRenewExpired(SubAccount subAccount, LoyaltyStructure structure, Order order) {
        if (!structure.getPointExpire().isOrderDelayExpired()) {
            return;
        }
        LocalDate expiredDate = structure.pointExpire(order).orderPointExpiredDate(order.getOrderDateTime());
        subAccount.delayExpired(order.point(), order.getOrderDateTime().toLocalDate(), expiredDate);
    }

    /**
     * 会员未来3个月将过期积分
     *
     * @return
     */
    public Integer calculatePointAboutExpireInFuture3Months(String brand, Map<String, Object> pointAboutExpireMap) {
        if (!BrandV2.OLAY.equals(brand)) {
            return (Integer) Optional.ofNullable(pointAboutExpireMap.get("pointAboutExpireInFuture3Months")).orElse(0);
        }
        return this.availablePointPool.fetchLastMonthNode(3).stream()
                .mapToInt(PointPoolNode::getPoint).sum();

    }

    public String getTheLastPointAboutExpireDateInFuture3Months(String brand, Map<String, Object> pointAboutExpireMap) {
        if (!BrandV2.OLAY.equals(brand)) {
            return Optional.ofNullable(pointAboutExpireMap.get("theLastPointAboutExpireDateInFuture3Months")).orElse("").toString();
        }
        //查找treeMap中不大于指定key的最大key值
        LocalDate availablePointPoolKey = this.availablePointPool.fetchFloorKeyLastMonth(3);
        if (availablePointPoolKey == null || availablePointPoolKey.isBefore(LocalDate.now())) {
            return "";
        }
        return availablePointPoolKey.toString();
    }


    public void rollBackTier(Order order, LoyaltyStructure structure) {
        this.tierList.get(structure.name()).setLevel(order.getCurrentLevel());
        this.updatedTime = LocalDateTime.now();
    }

    public void backupCurrentLevel(LoyaltyStructure structure) {
        Tier tier = this.tierList.get(structure.name());
        if (tier != null) {
            tier.setBackupLevel(tier.getLevel());
        }
    }

    public void clearBackupLevel(LoyaltyStructure structure) {
        this.tierList.get(structure.name()).setBackupLevel(null);
    }


    public void updateTier(LoyaltyStructure structure, String newLevel, LocalDateTime upgradeTime) {
        Tier currentTier = this.tier(structure.name());
        currentTier.updateTier(structure, newLevel, upgradeTime);
        this.lastTierExpireDate = currentTier.getExpiredTime().toLocalDate();
    }


    private void calculatePointPool(LoyaltyStructure structure, SubAccount subAccount,
                                    LocalDate expiredDate, int point) {
        PointExpire pointExpire = structure.getPointExpire();
        if (!pointExpire.useInternalPointPool()) {
            return;
        }
        PointPoolNode firstNode = availablePointPool.calculatePool(expiredDate, point);
        subAccount.updateAboutExpired(firstNode.getPoint(), firstNode.getExpireDate());
    }

    /**
     * 实现积分过期
     *
     * @return 过期积分
     */
    public int doExpirePoint(LoyaltyStructure loyaltyStructure) {
        String brand = loyaltyStructure.getBrands().get(0);
        SubAccount subAccount = subAccount(brand);
        int expirePoint = needExpirePoint(loyaltyStructure, subAccount);
        //过期积分不能大于可用积分
        expirePoint = subAccount.expiredPoint(expirePoint);

        if (loyaltyStructure.pointExpire().useDefaultExpireDate()) {
            subAccount.updateAboutExpired(subAccount.getPointAvailable(),
                    LocalDate.now().with(TemporalAdjusters.lastDayOfYear()));
        }

        if (loyaltyStructure.getPointExpire().isUsePointPool()) {
            PointPoolNode node = this.availablePointPool.fetchFirstExpireNode();
            subAccount.updateAboutExpired(node.getPoint(), node.getExpireDate());
        }
        return expirePoint;
    }

    private int needExpirePoint(LoyaltyStructure loyaltyStructure, SubAccount subAccount) {
        if (loyaltyStructure.getPointExpire().isUsePointPool()) {
            return availablePointPool.expirePoint();
        }
        return subAccount.getPointAboutExpire();
    }

    public int availablePoint(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getPointAvailable).sum();
    }

    public int ownPoint(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::ownPoint).sum();
    }

    public int pointAboutExpire(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getPointAboutExpire).sum();
    }

    public int totalPoint(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getTotalPoint).sum();
    }

    public int pointUsed(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getPointUsed).sum();
    }

    /**
     * 获取过期积分
     */
    public int pointExpired(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getPointExpired).sum();
    }

    public int pointLocked(SubAccountType subAccountType) {
        return this.subAccountList.subAccounts(subAccountType.callExtraSubAccount()).stream().mapToInt(SubAccount::getPointLocked).sum();
    }

    /**
     * 设置即将过期积分
     */
    public void pointAboutExpire(String brand, int pointAboutExpire) {
        SubAccount subAccount = subAccount(brand);
        subAccount.pointAboutExpire(pointAboutExpire);
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 根据loyaltyStructure 设置其子下某个品牌积分过期
     */
    public void pointExpired(String expiredBrand, Integer expiredPoint) {
        SubAccount subAccount = this.getSubAccountList().get(expiredBrand);
        subAccount.expiredPoint(expiredPoint);
        this.updatedTime = LocalDateTime.now();
    }

    public void initWillExpiredPoint(LoyaltyStructure loyaltyStructure) {
        for (String brand : loyaltyStructure.getBrands()) {
            SubAccount subAccount = this.getSubAccountList().get(brand);
            subAccount.pointAboutExpire(0);
        }
        this.updatedTime = LocalDateTime.now();
    }

    @Override
    public boolean sameIdentityAs(final Account other) {
        return other != null && this.id.equals(other.id);
    }

    public Tier tier(String structureName) {
        return this.tierList.get(structureName);
    }

    public void tier(LoyaltyStructure loyaltyStructure, Tier tier) {
        this.tierList.put(loyaltyStructure.name(), tier);
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 版本更换做一些数据的兼容，方便进行计算
     * 如：olay默认过期时间是年底,为方便subAccount计算即将过期积分，默认赋值
     */
    public SubAccount adapterSubAccount(LoyaltyStructure structure, Transaction transaction) {
        SubAccount subAccount = subAccount(transaction.brand(), structure.subAccountType(transaction));
        PointExpire pointExpire = structure.pointExpire(transaction);
        //不使用默认过期时间：直接返回

        if (!pointExpire.useDefaultExpireDate()) {
            return subAccount;
        }
        if (subAccount.getPointAboutExpiredDate() == null) {
            //如果按年过期，1年有效，并且不使用积分池，默认过期时间是年底
            subAccount.setPointAboutExpiredDate(LoyaltyDateTimeUtils.getLastDayOfYear(LocalDateTime.now()).toLocalDate());
        }
        return subAccount;
    }

    /**
     * 大陆pampers默认使用替换账户
     */
    public SubAccount subAccount(String brand, SubAccountType subAccountType) {
        if (SubAccountType.DEFAULT.equals(subAccountType)) {
            return subAccountList.subAccount(brand);
        }
        boolean extra = subAccountType.callExtraSubAccount();
        //如果已经注册
        if (subAccountList.hasRegister(brand, extra)) {
            return subAccountList.subAccount(brand, extra);
        }
        //2者都没有注册
        if (!subAccountList.hasRegisterAny(brand)) {
            throw new SystemException("Account error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        SubAccount subAccount = subAccountList.subAccount(brand, !extra);
        SubAccount newSubAccount = new SubAccount();
        //只注册了其中一个：复制一个子账号到另一个账户，并将积分相关字段清0.
        BeanUtils.copyProperties(subAccount, newSubAccount);
        newSubAccount.initPoint();
        subAccountList.registerSubAccount(brand, extra, newSubAccount);
        return newSubAccount;
    }

    /**
     * SubAccountType:DEFAULT
     * 注意SubAccountType 不同于ValueType,必须经过loyaltyStructure于ValueType 进行计算获取
     */
    public SubAccount subAccount(String brand) {
        return subAccount(brand, SubAccountType.DEFAULT);
    }

    public void updatePurchaseInfo(LoyaltyStructure structure, int purchaseTimes, Order order) {
        SubAccount subAccount = this.subAccount(order.brand(), structure.subAccountType(order));
        subAccount.updatePurchaseInfo(order.getOrderDateTime(), order.getStoreCode(), purchaseTimes);
    }

    public void calculatePoint(LocalDate pointAboutExpiredDate, PointValue pointValue) {
        String brand = pointValue.brand();
        SubAccount subAccount = this.getSubAccountList().get(brand);
        subAccount.calculatePoint(pointValue, pointAboutExpiredDate);
    }

    /**
     * 重置账号：使用于积分重算
     */
    public void resetInfo(String brand) {
        SubAccount subAccount = this.getSubAccountList().get(brand);
        subAccount.resetInfo();
        this.updatedTime = LocalDateTime.now();
    }

    public void updatePointInfo(String brand, int usedPoint, int totalPoint) {
        this.updatedTime = LocalDateTime.now();
        SubAccount subAccount = this.getSubAccountList().get(brand);
        subAccount.updatePointInfo(usedPoint, totalPoint);
    }

    public void updateRegistryTime(LocalDateTime registryTime, String brand) {
        SubAccount subAccount = this.getSubAccountList().get(brand);
        subAccount.updateRegistryTime(registryTime);
    }

    public void pointAboutExpiredDate(String brand, LocalDate pointAboutExpiredDate) {
        SubAccount subAccount = this.getSubAccountList().get(brand);
        subAccount.updateAboutExpiredDate(pointAboutExpiredDate);
        this.updatedTime = LocalDateTime.now();
    }

    public void updateTierExpiredTime(LoyaltyStructure loyaltyStructure, LocalDateTime tierExpiredTime) {
        Tier tier = this.tier(loyaltyStructure.name());
        tier.setExpiredTime(tierExpiredTime);
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 注册事件
     */
    public enum RegistryEvent {
        /**
         * 对品牌来说，新会员注册事件
         */
        BRAND_MEMBER_REGISTRY_EVENT {
            @Override
            public RuleTemplate ruleTemplate() {
                return RuleTemplate.INTERACTION_REGISTRY_POINT;
            }
        },
        BINDING_EVENT {
            @Override
            public RuleTemplate ruleTemplate() {
                return RuleTemplate.INTERACTION_REGISTRY_POINT;
            }
        };

        public abstract RuleTemplate ruleTemplate();

    }

    public enum AccountStatus {
        /**
         * ACTIVATED
         */
        ACTIVATED(true),
        /**
         * LOCKED
         */
        LOCKED(false),
        /**
         * CLOSED
         */
        CLOSED(false);

        AccountStatus(boolean addPoint) {
            this.addPoint = addPoint;
        }

        private final boolean addPoint;

        public boolean judgeAddPoint() {
            return addPoint;
        }


    }

    /**
     * 根据TierPoint计算保级积分
     */
    public int gradingPoint(LoyaltyStructure structure) {
        Tier tier = tier(structure.name());
        return structure.getTierLevelSeries().gradingPoint(tier.getLevel(), tier.getTierPoint());
    }

    public int gradingPoint(LoyaltyStructure structure, int amount) {
        Tier tier = tier(structure.name());
        return structure.getTierLevelSeries().gradingPoint(tier.getLevel(), amount);
    }

    /**
     * 根据TierPoint计算升级积分
     */
    public int upgradePoint(LoyaltyStructure structure) {
        Tier tier = tier(structure.name());
        return structure.getTierLevelSeries().upgradePoint(tier.getLevel(), tier.getTierPoint());
    }

    public int upgradePoint(LoyaltyStructure structure, int amount) {
        Tier tier = tier(structure.name());
        return structure.getTierLevelSeries().upgradePoint(tier.getLevel(), amount);
    }

    public TierLevel nextTierLevel(LoyaltyStructure structure) {
        Tier tier = tier(structure.name());
        return structure.tierLevelSeries().nextLevel(tier.getLevel());
    }

    public String partitionKey() {
        if (StringUtils.isNotBlank(this.partitionKey)) {
            return this.partitionKey;
        }
        if (StringUtils.isBlank(this.id)) {
            throw new SystemException("loyaltyId 为空", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        return PartitionKeyUtils.getAccountPartitionKey(this.id);
    }

    /**
     * SKII 使用，不影响pamper重构
     */
    public void mergeAccount(Account originalAccount, String brand) {
        SubAccount originalSubAccount = originalAccount.subAccountList.get(brand);
        SubAccount subAccount = this.subAccountList.get(brand);
        subAccount.mergeAccount(originalSubAccount.getTotalPoint(), originalSubAccount.getPointAvailable(),
                originalSubAccount.getPointAboutExpire(), originalSubAccount.getPointUsed(),
                originalSubAccount.getTotalPurchaseTimes(), originalSubAccount.getPointExpired());
        this.updatedTime = LocalDateTime.now();
    }

    public String bindId(String brand, String channel) {
        SubAccount subAccount = this.getSubAccountList().get(brand);
        if (subAccount != null) {
            return subAccount.bindList().get(channel);
        }
        return null;
    }

    public LocalDateTime registryTime(String brand) {
        LocalDateTime registryTime = subAccountList.anySubAccount(brand).getCreatedTime();
        if (registryTime == null) {
            return this.createdTime;
        }
        return registryTime;
    }

    public LocalDate pointAboutExpiredDateWithDefault(String brand, LoyaltyStructure structure) {
        SubAccount subAccount = this.subAccount(brand, structure.accountTypeOfDefault());
        if (subAccount == null) {
            throw new SystemException("The brand sub account not exist", ResultCodeMapper.PARAM_ERROR);
        }
        LocalDate aboutExpiredDate = subAccount.getPointAboutExpiredDate();
        if (structure.getPointExpire().matchPointExpiredWay(PointExpire.PointExpiredWay.BY_YEAR)) {
            return aboutExpiredDate;
        }
        return Optional.ofNullable(aboutExpiredDate)
                .orElse(structure.pointExpire(ValueType.DEFAULT).pointExpiredDate(LocalDateTime.now()));
    }

    public LocalDate pointAboutExpiredDate(String brand, LoyaltyStructure structure) {
        LocalDate localDate = this.pointAboutExpiredDateWithDefault(brand, structure);
        if (!BrandV2.OLAY.equals(brand)) {
            return localDate;
        }
        //olay account如果没有即将过期积分时间，则默认返回今年年底
        return Optional.ofNullable(localDate).orElse(LoyaltyDateTimeUtils.getLastDayOfThisYear().toLocalDate());
    }

    public boolean checkBabyBirthMonth(int lower, int upper) {
        if (StringUtils.isEmpty(this.babyBirthYearAndMonth)) {
            return false;
        }
        int year = Integer.parseInt(this.babyBirthYearAndMonth.substring(0, 4));
        int month = Integer.parseInt(this.babyBirthYearAndMonth.substring(4, 6));
        LocalDate minBabyBirthday = LocalDate.of(year, month, 1).plusMonths(lower);
        LocalDate maxBabyBirthday = minBabyBirthday.plusMonths((long) upper - lower).with(TemporalAdjusters.lastDayOfMonth());
        // 当前日期不早于最小日期限制，不晚于最大日期限制
        return !LocalDate.now().isBefore(minBabyBirthday) && !LocalDate.now().isAfter(maxBabyBirthday);
    }

}
