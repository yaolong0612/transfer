package cn.com.pg.loyalty.infrastructure.storage;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.table.CloudTableClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Simon
 * @date 2019/6/21 0:27
 * @description
 **/
@Configuration
@Slf4j
public class TableStorageConfig {
    @Value("${azure.table.connectionString}")
    private String tableStorageConnectionString;

    @Bean
    public CloudTableClient cloudTableClient() {
        try {
            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.parse(tableStorageConnectionString);
            return cloudStorageAccount.createCloudTableClient();
        } catch (Exception exception) {
            log.error("Connection Table Storage Error", exception);
            throw new SystemException("Connection Table Storage Error", ResultCodeMapper.TABLE_STORAGE_ERROR);
        }
    }


}
