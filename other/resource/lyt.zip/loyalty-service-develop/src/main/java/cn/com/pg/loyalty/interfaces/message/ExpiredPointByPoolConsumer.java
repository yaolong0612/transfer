package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusClient;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toMap;

/**
 * @description:
 * @author: Artermus wang on 2022-09-08 10:34
 */

@Component
@Slf4j
public class ExpiredPointByPoolConsumer extends AbstractConsumerV2 {

    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private ServiceBusClient serviceBusClient;
    @Autowired
    private CacheService cacheService;

    @Override
    protected void doBusiness(JSONObject message) {
        JSONArray jsonArr = message.getJSONArray("jsonArr");
        List<Massage> massages = jsonArr.toJavaList(Massage.class);
        List<Object>  transactionParamList = new ArrayList<>();
        Map<String,String> partitionKeys = massages.stream().collect(toMap(massage ->  massage.loyaltyId, massage -> massage.transactionPartitionKey));
        List<String> ids = massages.stream().map(massage -> massage.loyaltyId).collect(Collectors.toList());
        try {
            for (Account account : accountRepository.findAllById(ids)) {
                LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(account);
                int expired = account.doExpirePoint(loyaltyStructure);
                accountRepositoryV2.saveRetrievable(account);
                if (expired == 0) {
                    continue;
                }
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("memberId", account.getMemberId());
                jsonObject1.put("transactionPartitionKey", partitionKeys.get(account.loyaltyId()));
                jsonObject1.put("brand", message.getString("brand"));
                jsonObject1.put("loyaltyId", account.loyaltyId());
                jsonObject1.put("point", expired);
                jsonObject1.put("transactionId", UUIDUtil.generator());
                transactionParamList.add(jsonObject1);
            }
        }catch (Exception e){
            log.error("批量处理数据失败: {}",e.getMessage());
            throw new SystemException(e.getMessage(),ResultCodeMapper.UNEXPECTED_ERROR);
        }finally {
            JSONObject messageSend = new JSONObject();
            messageSend.put("transactionParamList",transactionParamList);
            serviceBusClient.sendMessage(messageSend,ServiceBusBinder.QUEUE_SYNC_EXPIRED);
        }

    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.QUEUE_EXPIRED_POINT_BY_POOL;
    }
    @Data
    static class Massage{
        String loyaltyId;
        String transactionPartitionKey;
    }
}
