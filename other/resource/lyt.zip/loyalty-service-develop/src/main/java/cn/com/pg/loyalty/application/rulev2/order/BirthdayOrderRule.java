package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.dependence.AmClient;
import cn.com.pg.loyalty.application.dependence.AmClientSupport;
import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.BirthdayOrderPropertiesV2;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/1
 */
@Rule(name = "BIRTHDAY_ORDER_RULE_V2",
        description = "calculate the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class BirthdayOrderRule {

    @Autowired
    private AmClientSupport amClientSupport;

    private RuleTemplate ruleTemplate = RuleTemplate.BIRTHDAY_ORDER_RULE_V2;

    private static final DateTimeFormatter FM_DAY_TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static final String ALL_CHANNEL = "ALL";

    /**
     * 生日订单积分规则执行条件：
     * 1、必须查到积分模板是生日月的且有订单时间在活动期间内活动数大于0
     * 2、判断渠道是否满足
     * 3、判断订单时间是否在生日月内
     *
     * @param activityList
     * @param order
     * @return
     */
    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList, @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order, @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure loyaltyStructure) {
        if (order.getRealTotalAmount() <= 0) {
            //订单金额是0,不执行加积分
            log.info("orderId:{}金额是:{}，不参与积分计算", order.getOrderId(), order.getRealTotalAmount());
            return Boolean.FALSE;
        }
        List<Activity> birthdayActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);

        log.info("orderId:{}匹配到的生日月积分活动数:{}", order.getOrderId(), birthdayActivityList.size());
        if (CollectionUtils.isEmpty(birthdayActivityList)) {
            //没有订单时间在活动期间内的活动返回false,不执行加积分
            log.info("orderId:{}匹配到的生日月积分活动数:{}", order.getOrderId(), birthdayActivityList.size());
            return Boolean.FALSE;
        }
        //由于在fetchBirthdayActivityByOrderTime方法内按优先级从大到小排序活动了，只取第一个最优先活动
        Activity birthdayActivity = birthdayActivityList.get(0);
        BirthdayOrderPropertiesV2 ruleContent = JSON.parseObject(birthdayActivity.getRuleProperties(), BirthdayOrderPropertiesV2.class);
        //活动未配置渠道，抛出异常
        if (CollectionUtils.isEmpty(ruleContent.getChannels())) {
            log.info("activity did not config channel");
            return Boolean.FALSE;
        }
        //活动规则配置了渠道，且配置的渠道不包括订单的渠道，不需要加积分直接返回,如果配置了ALL则进入下一流程
        if (CollectionUtils.isNotEmpty(ruleContent.getChannels()) && (!ruleContent.getChannels().contains(ALL_CHANNEL) && !ruleContent.getChannels().contains(order.getChannel()))) {
            log.info("activityId:{}配置了渠道{},但订单渠道{}不在其内", birthdayActivity.getId(), ruleContent.getChannels().toString(), order.getChannel());
            return Boolean.FALSE;
        }
        String memberId = order.getMemberId();
        //调AM出异常则return
        AmClient.OptimizedProfileDTO profileDTO;
        try {
            profileDTO = amClientSupport.queryProfile(memberId, loyaltyStructure.getAmTenantId());
        } catch (Exception e) {
            log.error("call am birthDay error: {}", e.getMessage());
            return Boolean.FALSE;
        }
        //判断是本人生日还是孩子生日，并且判断订单时间是否在生日月内
        switch (ruleContent.getBirthdayType()) {
            case BABY:
                return matchBabyBirthDay(profileDTO.getBabyBirthdays(), memberId, order.getOrderDateTime().toLocalDate());
            case SELF:
                return matchSelfBirthDay(profileDTO.getBirthday(), memberId, order.getOrderDateTime().toLocalDate());
            default:
                return Boolean.FALSE;
        }
    }

    /**
     * 判断是否在member生日月内
     *
     * @param birthday
     * @param memberId
     * @param orderDate
     * @return
     */
    private boolean matchSelfBirthDay(String birthday, String memberId, LocalDate orderDate) {
        //本人生日，查询AM系统是订单时间是否在本人生日月内
        if (StringUtils.isEmpty(birthday)) {
            log.info("memberId:{}的未填写本人生日,不进行生日月加积分", memberId);
            return Boolean.FALSE;
        }
        LocalDate userBirthday = LoyaltyDateTimeUtils.stringToLocalDate(birthday);
        log.info("memberId:{}的生日是{}", memberId, userBirthday.toString());
        return isInBirthdayMonth(userBirthday, orderDate);
    }


    /**
     * 判断是否在baby生日月内
     *
     * @param babies
     * @param memberId
     * @param orderDate
     * @return
     */
    private boolean matchBabyBirthDay(List<AmClient.AttrBaby> babies, String memberId, LocalDate orderDate) {
        //宝宝生日
        if (CollectionUtils.isEmpty(babies)) {
            log.info("查询不到用户: {}, 的宝宝生日月,不进行用户宝宝生日月加积分流程", memberId);
            return Boolean.FALSE;
        }
        String babyBirthdayStr = babies.get(babies.size() - 1).getBirthday();
        if (StringUtils.isBlank(babyBirthdayStr)) {
            log.error("获取不到用户的宝宝生日, 不进行宝宝生日月加积分流程");
            return Boolean.FALSE;
        }
        LocalDateTime babyBirthday = LocalDateTime.parse(babyBirthdayStr + " 23:59:59", FM_DAY_TIME);
        log.info("memberId:{}的宝宝生日是{}", memberId, babyBirthdayStr);
        return isInBirthdayMonth(babyBirthday.toLocalDate(), orderDate);
    }


    /**
     * 判断订单时间是否在生日月内
     *
     * @param birthday
     * @param orderDate
     * @return
     */
    private boolean isInBirthdayMonth(LocalDate birthday, LocalDate orderDate) {
        return birthday.getMonth() == orderDate.getMonth();
    }


    /**
     * 按规则内容进行加积分
     *
     * @param order
     * @param activityList
     */
    @Action
    public void addPoint(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                         @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                         @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        List<Activity> birthdayActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        Activity birthdayActivity = birthdayActivityList.get(0);
        BirthdayOrderPropertiesV2 ruleContent = JSON.parseObject(birthdayActivity.getRuleProperties(), BirthdayOrderPropertiesV2.class);
        int point = ruleContent.calculatePoint(structure, order);
        PointItem pointItem = new PointItem(point, birthdayActivity.description(), birthdayActivity.activityId());
        competePointItems.put(pointItem, ruleContent.isCompetition());
        ruleResult.success();
    }
}
