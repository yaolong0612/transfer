package cn.com.pg.loyalty.interfaces.assembler;


import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.Gift.GiftDisplayMsg;
import cn.com.pg.loyalty.domain.gift.GiftItem;
import cn.com.pg.loyalty.interfaces.dto.AddGiftCommand;
import cn.com.pg.loyalty.interfaces.dto.GiftDisplayMsgDTO;
import cn.com.pg.loyalty.interfaces.dto.ProductDTO;
import cn.com.pg.loyalty.interfaces.dto.UpdateGiftCommand;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GiftMapper {

    GiftMapper INSTANCE = Mappers.getMapper(GiftMapper.class);




    @Mapping(target = "loyaltyStructure", source = "structure")
    @Mapping(target = "createdBy", source = "createdBy")
    @Mapping(target = "name", source = "command.giftName")
    @Mapping(target = "marketPrice", source = "command.price")
    @Mapping(target = "items", source = "command.products")
    @Mapping(target = "imageUri", source = "command.image")
    @Mapping(target = "couponUrls", source = "command.urls")
    @Mapping(target = "type",source = "command.giftType")
    Gift addCmd2Gift(AddGiftCommand command, String structure, String createdBy);



    @Mapping(target = "id", source = "giftId")
    @Mapping(target = "loyaltyStructure", source = "structure")
    @Mapping(target = "name", source = "command.giftName")
    @Mapping(target = "marketPrice", source = "command.price")
    @Mapping(target = "items", source = "command.products")
    @Mapping(target = "imageUri", source = "command.image")
    @Mapping(target = "couponUrls", source = "command.urls")
    Gift updateCmd2Gift(UpdateGiftCommand command,String giftId,String structure);



    GiftItem productDto2GiftItem(ProductDTO dto);

    @Mapping(target = "name", source = "dto.giftName")
    @Mapping(target = "items", source = "dto.products")
    GiftDisplayMsg dto2DisplayMsg(GiftDisplayMsgDTO dto);
}
