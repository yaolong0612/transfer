package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.structure.OrderImpact;
import cn.com.pg.loyalty.domain.transaction.Order;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class RefundOrderEarliestRollBackTimeFinder implements OrderEarliestRollBackTimeFindAble {
    @Override
    public LocalDateTime findEarliestRollBackTime(OrderImpact orderImpact, List<Order> requestOrders, Map<String, Order> associatedOrdersMap) {
        if (!orderImpact.isRefundBackRoll()) {
            return LocalDateTime.MAX;
        }
        return requestOrders.stream().filter(order -> associatedOrdersMap.containsKey(order.channelUnitOrderId()))
                .filter(order -> order.realTotalAmount() <= 0)
                .min(Comparator.comparing(Order::getOrderDateTime))
                .map(Order::getOrderDateTime)
                .orElse(LocalDateTime.MAX);
    }
}
