package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.application.rule.interaction.*;
import cn.com.pg.loyalty.application.rule.tier.CalculateTierByQuantityOfOrderRule;
import cn.com.pg.loyalty.application.rulev2.order.*;
import cn.com.pg.loyalty.application.rulev2.tier.*;
import cn.com.pg.loyalty.domain.activity.prop.*;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Simon
 * @date 2019年4月23日下午4:19:28
 * @description RuleTemplate
 */
@Slf4j
@Getter
public enum RuleTemplate implements ValueObject<RuleTemplate> {
    /**
     * 所有的积分模板都需要统一维护到这里 INTERACTION_REGISTRY_POINT
     */
    INTERACTION_REGISTRY_POINT(RegistryRule.class, RegistryRuleProperties.class, "Interaction Registry模板"),
    /**
     * 绑定模板
     */
    INTERACTION_BIND_POINT(RegistryRule.class, RegistryRuleProperties.class, "Interaction Bind模板"),
    /**
     * Olay订单加积分模板
     */
    OLAY_ORDER_POINT,
    /**
     * 线上节假日多倍积分模板
     */
    OLAY_ONLINE_HOLIDAY_MULTIPLE,
    /**
     * 多档多倍积分
     */
    MULTIPLE_GRADE_POINT,
    /**
     * 节假日购买达到指定金额，赠送一次额外积分目标
     */
    OLAY_REACH_AMOUNT_BONUS_ONCE_MULTIPLE,
    /**
     * Olay订单加积分_新品全单多倍积分模板
     */
    OLAY_NEW_PRODUCT_MULTIPLE,
    /**
     * Olay订单加积分_单品多倍积分模板
     */
    OLAY_SINGLE_PRODUCT_MULTIPLE,
    /**
     * Olay订单加积分_新客二回双倍积分模板
     */
    OLAY_SECOND_PURCHASE_MULTIPLE,
    /**
     * Olay订单加积分_等级规则积分模板
     */
    OLAY_TIER_RULE_MULTIPLE,
    /**
     * Olay订单加积分_生日月双倍积分模板
     */
    OLAY_BIRTHDAY_MONTH_RULE_MULTIPLE,
    /**
     * Olay订单加积分_基础积分模板
     */
    OLAY_BASE_POINT_RULE_MULTIPLE,

    /**
     * 直接调用接口添加多少积分模板
     */
    INTERACTION_ADJUST_POINT_BY_CLIENT(AdjustPointByClientRule.class, DefaultProperties.class, "直接调用接口添加多少积分模板"),
    /**
     * 订单直接调用接口添加多少积分模板
     */
    ORDER_ADJUST_POINT_BY_CLIENT,
    /**
     * 客服调用接口添加多少积分模板
     */
    INTERACTION_ADJUST_POINT_BY_MANAGER(AdjustPointByManagerRule.class, DefaultProperties.class, "客服调用接口添加多少积分模板"),

    /**
     * 使用模板有限制次数加积分模板
     */
    INTERACTION_ADJUST_POINT_TIMES(AdjustPointTimesRule.class, AdjustPointTimesProperties.class, "使用模板有限制次数加积分模板"),
    /**
     * 每天加积分次数限制模板
     */
    INTERACTION_ADJUST_POINT_TIMES_PER_DAY(AdjustPointTimesPerDayRule.class, AdjustPointTimesProperties.class, "每天加积分次数限制模板"),
    /**
     * 每个月加积分次数限制模板
     */
    INTERACTION_ADJUST_POINT_TIMES_PER_MONTH(AdjustPointTimesPerMonthRule.class, AdjustPointTimesProperties.class, "每个月加积分次数限制模板"),
    /**
     * 每季度加积分次数限制模板
     */
    INTERACTION_ADJUST_POINT_TIMES_PER_QUARTER(AdjustPointTimesPerQuarterRule.class, AdjustPointTimesProperties.class, "每季度加积分次数限制模板"),
    /**
     * 每年加积分次数限制模板
     */
    INTERACTION_ADJUST_POINT_TIMES_PER_YEAR(AdjustPointTimesPerYearRule.class, AdjustPointTimesProperties.class, "每年加积分次数限制模板"),

    /**
     * INTERACTION_SCAN_CODE_PLUS_POINT模板
     */
    INTERACTION_SCAN_CODE_PLUS_POINT(HkTwPampersScanCodeRule.class, ScanCodePlusPointProperties.class, "INTERACTION_SCAN_CODE_PLUS_POINT模板"),
    /**
     * ml pampers 扫码加积分模板
     */
    ML_PAMPERS_INTERACTION_SCAN_CODE(MlPampersScanCodeRule.class, MLPampersScanCodeProperties.class, "大陆帮宝适扫码加积分模板"),
    /**
     * 第一次扫tape 拉拉裤
     */
    ML_PAMPERS_SCAN_PANTS_CODE(Object.class, DefaultProperties.class, "大陆帮宝适扫码拉拉裤加积分模板"),
    /**
     * 每日签到积分模板
     */
    ML_INTERACTION_DAILY_ATTENDANCE(DailyAttendanceRule.class, DailyAttendanceProperties.class, "每日签到积分模板"),
    /**
     * ml pampers 订单积分模板
     */
    ML_PAMPERS_ORDER_POINT,
    /**
     * 根据购物单位计算订单积分模板
     */
    ADD_ORDER_POINT_BY_PURCHASE_UNIT,
    /**
     * ml pampers 日常订单积分模板
     */
    ML_PAMPERS_NORMAL_ORDER,
    /**
     * ml pampers KCP订单积分
     */
    ML_PAMPERS_KCP_ORDER,
    /**
     * 含有指定SKU赠送订单额外积分模板
     */
    SPECIFY_SKU_ADD_ORDER_POINT,
    /**
     * ml pampers 生日月订单积分
     */
    ML_PAMPERS_BIRTHDAY_ORDER,
    /**
     * ml pampers 会员日订单积分
     */
    ML_PAMPERS_MEMBER_ORDER,
    /**
     * olay扫码加积分模板
     */
    ML_OLAY_INTERACTION_SCAN_CODE_PLUS_POINT(MlOlayScanCodeRule.class, MlOlayScanCodePlusPointProperties.class, "ML_OLAY_INTERACTION_SCAN_CODE_PLUS_POINT模板"),

    /**
     * OralB扫码加积分模板
     */
    ML_ORALB_INTERACTION_SCAN_CODE_PLUS_POINT(MlOralbScanCodeRule.class, MlOralbScanCodePlusPointProperties.class, "ML_ORALB_INTERACTION_SCAN_CODE_PLUS_POINT模板"),
    /**
     * 每购买多次加额外积分
     */
    PURCHASE_MANY_TIMES_PLUS_EXTRA_POINT,

    REDEMPTION_TEMPLATE(Object.class, RedemptionProperties.class, "兑换积分模板"),

    ORDER_BASE_POINT,

    ORDER_MULTIPLE_POINT,

    ORDER_TIER_POINT,

    INTERACTION_ADJUST_POINT_PER_PERIOD(AdjustPointPeriodTimeRule.class, PeriodTimeAddPointProperties.class, "交互积分,每五分钟触发一次"),

    ADD_ORDER_POINT_BY_PER_PURCHASE,

    ADD_ORDER_TIER_POINT_BY_PER_PURCHASE,

    FIRST_ORDER_ADD_POINT_RULE,

    INTERACTION_ADJUST_POINT_BY_FIRST_ORDER_LIMIT_DAYS(AdjustPointByFirstOrderLimitDaysRule.class, AdjustPointByOrderLimitProperties.class, "购买订单后限期参加活动规则"),

    ORDER_SKU_OVER_AMOUNT_POINT,
    /**
     * 在指定日期内存在订单，注册后第一笔订单双倍积分规则
     */
    EXIST_ORDER_AT_SPECIFIED_TIME_RULE,

    AT_SPECIFIED_ORDER_TIME_MULTIPLE_POINT,

    ADD_POINT_BEFORE_REGISTER_TIME,

    /**
     * 限制订单加积分：一段时间内存在加积分上限
     */
    ORDER_LIMIT_POINT_PERIOD_DATE_RULE,


    LIMIT_ORDER_POINT_PERIOD_DATE_RULE(LimitOrderPointPeriodDateRule.class, PeriodDateLimitProperties.class, "限定日期内,限定加积分数量 v2"),

    /**
     * 限制交互加积分：一段时间内存在加积分上限
     */
    INTERACTION_LIMIT_POINT_PERIOD_DATE_RULE(InteractionLimitPointPeriodDateRule.class, PeriodDateLimitProperties.class, "限定日期内,限定加积分数量"),

    /**
     * 互动积分，限制在注册第二天起到第几天内允许加积分 根据SKII肌肤测试诞生
     */
    INTERACTION_ADD_POINT_IN_LIMIT_DAYS_BY_REGISTER_TIME(AddPointInLimitDaysByRegisterTimeRule.class, AddPointInLimitDaysByRegisterTimeProperties.class, "注册日后n天内发起加积分"),


    /**
     * 交互_ 多条件(时间 次数、 渠道 、等级)调整积分
     */
    INTERACTION_ADJUST_POINT_IN_COMPLEX_CONDITION(AdjustPointInComplexConditionRule.class, AdjustPointInComplexConditionProperties.class, "按次数渠道限制加等级折扣积分"),

    INTERACTION_CONVERT_POINT_RULE(ConvertPointRule.class, ConvertPointProperties.class, "过渡积分转换积分规则"),


    /**
     * order common properties
     */
    MULTIPLE_POINT_ORDER_RULE(MultiplePointOrderRule.class, MultiplePointOrderProperties.class, "订单最基本的模板"),


    /**
     * ml skii order store properties
     */
    SKII_STORE_POINT_ORDER_RULE(MultiplePointOrderRule.class, MlSkiiStoreOrderProperties.class, "skii柜台积分"),
    /**
     * 重构后生日月订单规则
     */

    BIRTHDAY_ORDER_RULE_V2(BirthdayOrderRule.class, BirthdayOrderPropertiesV2.class, "整合后生日月订单规则"),
    /*
     * 重构后等级奖励订单规则
     */

    TIRE_ORDER_RULE_V2(TireOrderRule.class, TireOrderPropertiesV2.class, "整合后等级奖励订单规则"),

    /**
     * 重构后基础订单规则
     */
    BASIC_ORDER_RULE_V2(BasicOrderRule.class, BasicOrderRulePropertiesV2.class, "订单最基本的模板"),

    /*
     *重构后团购订单限制规则
     */
    GROUP_PURCHASE_ORDER_EXCLUDE_RULE(GroupPurchaseOrderExcludeRule.class, GroupPurchaseOrderExcludePropertiesV2.class, "排除团购订单规则模板"),

    /**
     * 重构后客户端订单动态调整积分
     */
    ORDER_ADJUST_POINT_BY_CLIENT_V2(AddPointByClientRule.class, DefaultProperties.class, "订单直接调用接口添加多少积分模板"),

    ORDER_ADD_POINT_BY_SKU_RULE(AddOrderPointBySkuRule.class, AddOrderPointBySkuProperties.class, "根据sku添加积分（空瓶回收）"),

    /**
     * 指定时间前订单为历史订单,不获取积分
     */
    ORDER_PASSED_CUSTOM_RULE,


    ORDER_BIRTHDAY_MULTI,

    ORDER_OPT_OUT_LIMIT(Object.class, RuleProperties.class,"opt out 不加积分"),

    TIER_CALCULATE_BY_AMOUNT_RULE(TierCalculateByAmountRule.class,TierCalculateByAmountProperties.class,"根据订单金额计算等级"),

    TIER_CALCULATE_BY_POINT_RULE(TierCalculateByPointRule.class,TierCalculateByPointProperties.class,"根据有效积分计算等级"),

    TIER_CALCULATE_BY_ORDERS_QUANTITY_RULE(TierCalculateByOrdersQuantity.class,TierCalculateByOrdersQuantityProperties.class,"根据订单数量计算等级"),

    CALCULATE_TIER_BY_QUANTITY_OF_ORDER_RULE(CalculateTierByQuantityOfOrderRule.class,
            CalculateTierByQuantityOfOrderRuleProperties.class, "根据购买订单数量升级到指定等级"),

    TIER_CALCULATE_FOR_LEVEL_CHANGE_LIMIT_RULE(TierCalculateForLevelChangeLimitRule.class,TierCalculateForLevelChangeLimitRule.class,"限制用户一次性升降级数"),

    TIER_CALCULATE_FOR_TIER_EXPIRED_LIMIT_RULE(TierCalculateForTierExpiredLimitRule.class,TierCalculateForTierExpiredLimitProperties.class,"限制用户等级过期的最低等级"),
    ;



    Class<?> ruleTemplateClazz;

    Class<?> rulePropertiesClazz;

    String description;

    RuleTemplate() {

    }

    RuleTemplate(Class<?> ruleTemplateClazz, Class<?> rulePropertiesClazz, String description) {
        this.ruleTemplateClazz = ruleTemplateClazz;
        this.description = description;
        this.rulePropertiesClazz = rulePropertiesClazz;
    }

    public static RuleTemplate getRuleTemplateById(String ruleTemplateId) {
        RuleTemplate ruleTemplate = null;
        try {
            ruleTemplate = RuleTemplate.valueOf(ruleTemplateId);
        } catch (Exception e) {
            throw new SystemException("传入的ruleTemplateId不正确请重新输入！", ResultCodeMapper.PARAM_ERROR);
        }
        return ruleTemplate;

    }

    public Class<?> ruleTemplateClazz() {
        return this.ruleTemplateClazz;
    }

    @Override
    public boolean sameValueAs(final RuleTemplate other) {
        return this == other;
    }
}
