package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.OperationService;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountOpt;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.interfaces.api.OperationsApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.AccountAssembler;
import cn.com.pg.loyalty.interfaces.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-09-04 22:36
 */

@Component("OperationsFacade")
@Slf4j
public class OperationsFacade implements OperationsApiDelegate {

    @Autowired
    private OperationService operationService;
    @Autowired
    private CacheService cacheService;
    @Autowired
    private TransactionService transactionService;

    @Override
    public ResponseEntity<Void> mergeAccount(String authorization, MergeAccountCommand mergeAccountCommand) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info("MethodName{},操作用户{}", "mergeAccount", userName);
        operationService.memberMerge(mergeAccountCommand.getOriginalMemberId(), mergeAccountCommand.getTargetMemberId(),
                mergeAccountCommand.getRegion(),
                mergeAccountCommand.getBrand());
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<QrCodeUsedInfo> findCodeUsedRecord(String authorization, String qrCode, String brand) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        log.info("MethodName{},操作用户{}", "findCodeUsedRecord", userName);
        Interaction codeRecord = operationService.findCodeUsedRecord(qrCode, brand);
        QrCodeUsedInfo qrCodeUsedInfo = new QrCodeUsedInfo();
        qrCodeUsedInfo.createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(codeRecord.getCreatedTime()));
        qrCodeUsedInfo.memberId(codeRecord.getMemberId());
        qrCodeUsedInfo.qrCode(qrCode);
        return ResponseEntity.ok(qrCodeUsedInfo);
    }

    @Override
    public ResponseEntity<Void> deleteAccountsInBatch(AccountDeletedInBatchCommand body) {
        ParamValidator.validateDeleteMemberIds(body.getMemberIds());
        operationService.sendAccounts2Bus(body);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<AccountDTO> mergeAccount4Skii(MergeAccountsCommand mergeAccountsCommand) {
        log.info("SKII会员合并");
        String region = mergeAccountsCommand.getRegion();
        String brand = mergeAccountsCommand.getBrand();
        MergeAccountsCommand.OptTypeEnum optTypeEnum = mergeAccountsCommand.getOptType();
        Account account = operationService.mergeAccount4Skii(mergeAccountsCommand.getOriginalMemberIds(),
                mergeAccountsCommand.getTargetMemberId(), region, brand,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(mergeAccountsCommand.getRegistryTime()),
                mergeAccountsCommand.getChannel(), mergeAccountsCommand.getBindId(),
                optTypeEnum != null ? AccountOpt.OptType.valueOf(optTypeEnum.toString()) : null,
                LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(mergeAccountsCommand.getOptTime()));
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Map<String,Object> pointAboutExpireMap = transactionService.calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(account, brand, loyaltyStructure);
        AccountDTO accountDTO = AccountAssembler.toAccountDTO(account, loyaltyStructure, pointAboutExpireMap);
        return ResponseEntity.ok(accountDTO);
    }
}
