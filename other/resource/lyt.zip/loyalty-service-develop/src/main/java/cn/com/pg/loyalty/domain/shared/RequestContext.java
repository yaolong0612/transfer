package cn.com.pg.loyalty.domain.shared;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * @author Simon
 * RequestContext
 */

@Data
public class RequestContext {

    /**
     * 每个请求的requestId
     */
    private String correlationId;

    /**
     * 请求时间
     */
    private LocalDateTime startDateTime;

    /**
     * 请求路径
     */
    private String path;

    /**
     * 请求方法Post/Get/Delete
     */
    private String requestMethod = "NONE";

    /**
     * 请求的唯一名词：API Method，Service Bus Queue Name
     */
    private String operationName;

    /**
     * 消息唯一ID
     */
    private String messageId;
    /**
     * 异常处理
     */
    private SystemException systemException;

    private ResultCodeMapper errResultCodeMapper;

    private final static ThreadLocal<RequestContext> REQUEST_CONTEXT_POOL;

    static {
        REQUEST_CONTEXT_POOL = new ThreadLocal<>();
    }

    private RequestContext() {
    }

    public static RequestContext getCurrentContext() {
        return REQUEST_CONTEXT_POOL.get();
    }

    public static void createContext(String correlationId) {
        REQUEST_CONTEXT_POOL.remove();
        RequestContext context = new RequestContext();
        context.startDateTime = LocalDateTime.now();
        if (StringUtils.isEmpty(correlationId)) {
            correlationId = UUIDUtil.generator();
        }
        context.correlationId = correlationId;
        MDC.put("correlationId", correlationId);
        REQUEST_CONTEXT_POOL.set(context);
    }

    public static void cleanContext() {
        REQUEST_CONTEXT_POOL.remove();
    }

    public void operationName(String operationName) {
        this.operationName = operationName;
    }

    public void requestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public void path(String path) {
        this.path = path;
    }

    public void error(SystemException systemException) {
        this.systemException = systemException;
        if (systemException != null) {
            this.errResultCodeMapper = systemException.resultCodeMapper();
        }
    }

    public void error(ResultCodeMapper errResultCodeMapper) {
        this.errResultCodeMapper = errResultCodeMapper;
    }

    public long costTime() {
        return System.currentTimeMillis() - startDateTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    public ResultCodeMapper errorResult() {
        return this.errResultCodeMapper;
    }

}
