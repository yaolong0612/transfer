package cn.com.pg.loyalty.application.dto;


import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
public class RequestOrderCommand {

    //重算订单继承
    private String id;
    /**
     * C2,Tmall,Jd订单中的TRANSACTION_ID(原始订单号)
     */
    @NotNull(message = "orderId not null")
    private String orderId;

    @NotNull(message = "channel not null")
    private String channel;

    private String brand;

    /**
     * 重算订单继承：订单为最终状态使用，增量更新使用associateTransactionId。
     */
    private String refundOrderId;
    /**
     * 店铺编号
     */
    private String storeCode;

    @NotNull(message = "realTotalAmount not null")
    @Min(value = 0)
    private Double realTotalAmount = 0.0;
    @Min(0)
    private Double refundAmount = 0.0;
    /**
     * 用户该笔订单总实付金额,
     */
    private Double originalTotalAmount=0.0;
    /**
     * 退单号
     */
    private boolean refund;
    /**
     * 如果有退货，此为原始积分
     */
    private Integer originalPoint=0;

    @NotNull
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime orderDateTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime orderUpdateTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime refundOrderDateTime;

    @Valid
    @NotEmpty
    private Set<RequestOrderItemDTO> orderItems = new HashSet<>();

    /**
     * 关联原单ID:增量变更使用
     */
    private String associateTransactionId;


    //重算订单继承
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime createdTime;

    //重算订单继承
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime expiredTime;

    public String originalOrderId() {
        if (refundAmount <= 0) {
            return orderId;
        }
        if (StringUtils.isNotBlank(id)) {
            return orderId;
        }
        if(StringUtils.isBlank(associateTransactionId)){
            return orderId;
        }
        return associateTransactionId;
    }

    public String channelUnitOriginOrderId() {
        return channel.concat("_").concat(originalOrderId());
    }

    public boolean refundRequest() {
        return refundAmount > 0 && StringUtils.isBlank(id);
    }

    public String refundId() {
        return orderId;
    }

    public double refundAmount() {
        return refundAmount;
    }

    public LocalDateTime adapterRefundOrderDateTime() {
        if (refundOrderDateTime != null) {
            return refundOrderDateTime;
        }
        if (orderUpdateTime != null) {
            return orderUpdateTime;
        }
        return orderDateTime;
    }
}
