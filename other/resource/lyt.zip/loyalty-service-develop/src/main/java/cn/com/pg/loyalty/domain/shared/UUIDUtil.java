package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

/**
 * @description: 生成不带‘-’的UUID
 * @author: Jevons Chen
 * @date: 2019-05-30 11:10
 */
public class UUIDUtil {

    /**
     * @return 获取不带‘-’的UUID
     */
    public static String generator() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * 由于数据迁移的原因，ML Olay 品牌的Loyalty ID由 UUID生成
     * 其它所有品牌的Loyalty ID都是由Member ID生成
     * 由于相同的member id，Account相同，所以生成loyalty id时，根据marketing program id。
     *
     * @param memberId
     * @param loyaltyStructure
     * @return
     */
    public static String generateLoyaltyId(String memberId, LoyaltyStructure loyaltyStructure) {
        if (StringUtils.isEmpty(memberId) || loyaltyStructure == null) {
            throw new SystemException("Generate loyalty id error, member id & loyalty structure is empty", ResultCodeMapper.PARAM_ERROR);
        }
        if (loyaltyStructure.checkMlBrand(BrandV2.OLAY)) {
            return generator();
        }
        return getLoyaltyId(memberId, loyaltyStructure);
    }

    /**
     * 根据member id获取loyalty id。ML Olay不能获取，直接返回null
     * 生成33位ID
     * 为了避免和Olay老的loyalty id冲突
     * 由于相同的member id，Account相同，所以生成loyalty id时，根据marketing program id。
     *
     * @param memberId
     * @param loyaltyStructure
     * @return
     */
    public static String getLoyaltyId(String memberId, LoyaltyStructure loyaltyStructure) {
        if (loyaltyStructure.checkMlBrand(BrandV2.OLAY)) {
            return null;
        }
        String rawId = loyaltyStructure.getMarketingProgramId().concat("-").concat(memberId);
        //为了防止被解密，使用sha256
        rawId = DigestUtils.sha256Hex(rawId);
        //使用md5将位数压缩到32位
        rawId = DigestUtils.md5Hex(rawId);
        return rawId.concat(memberId.substring(memberId.length() - 1));
    }

    private UUIDUtil() {
    }
}
