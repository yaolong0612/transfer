package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author LMR
 */
@Data
@NoArgsConstructor
public class RedemptionGradesProperties implements CommonProperties {

    private Set<GiftGrade> grades = new TreeSet<>();

    public void addGrade(RedemptionGradesProperties.GiftGrade grade) {
        grades.add(grade);
    }

    public boolean isEmpty() {
        return this.grades.isEmpty();
    }

    @Override
    public boolean checkGroupStatus(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGrade grade = fetchGiftGrade(redemptionItemMap, giftItem);
        if (grade == null) {
            return false;
        }
        return grade.isGroupMember();
    }
    @Override
    public boolean checkJoinEnterpriseWechatForBC(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGrade grade = fetchGiftGrade(redemptionItemMap, giftItem);
        if (grade == null) {
            return false;
        }
        return grade.isJoinEnterpriseWechatForBC();
    }


    @Override
    public int fetchTotalLimitQuantity(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGrade grade = fetchGiftGrade(redemptionItemMap, giftItem);
        if (grade == null) {
            return 0;
        }
        return grade.getTotalLimitQuantity();
    }

    @Override
    public PurchaseLimit fetchPurchaseLimit(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGrade grade = fetchGiftGrade(redemptionItemMap, giftItem);
        if (grade == null) {
            return null;
        }
        return grade.getPurchaseLimit();
    }

    @Override
    public RuleLable fetchLable() {
        return RuleLable.GRADE;
    }

    @Override
    public CommonProperties fetchNext() {
        return null;
    }

    private GiftGrade fetchGiftGrade(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        // ***查询挡位名为 组名-挡位名
        String name = this.fetchName(redemptionItemMap, giftItem);
        if (StringUtils.isEmpty(name)) {
            return null;
        }
        return this.grades.stream()
                .filter(grade -> grade.getGroupName().concat("-").concat(grade.getName()).equals(name))
                .findFirst().orElse(null);
    }

    @Override
    public boolean checkMutex(Map<String, RedemptionItem> redemptionItemMap, List<GiftItem> giftItemList, List<GiftItem> historyGiftItemList) {
        ArrayList<GiftItem> giftItems = new ArrayList<>(giftItemList);
        giftItems.addAll(historyGiftItemList);
        // 兑换的每一个礼品都需要判断
        for (GiftItem giftItem : giftItemList) {
            RedemptionItem redemptionItem = redemptionItemMap.get(giftItem.getGiftId());
            // 需要根据组名进行过滤，只和当前兑换礼品所在组下的挡位互斥
            Set<String> nameSet = giftItems.stream()
                    .filter(item -> redemptionItemMap.get(item.getGiftId()).getGroupName().equals(redemptionItem.getGroupName()))
                    .map(item -> this.fetchName(redemptionItemMap, item))
                    .filter(StringUtils::isNotEmpty).collect(Collectors.toSet());
            if (nameSet.size() > 1) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean fetchMutex(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGrade grade = fetchGiftGrade(redemptionItemMap, giftItem);
        if (grade == null) {
            return false;
        }
        return grade.isMutex();
    }

    @Data
    @NoArgsConstructor
    public static class GiftGrade implements Comparable<RedemptionGradesProperties.GiftGrade> {
        // 挡位
        private String name;
        // 挡位所属的组名
        private String groupName;
        // 挡位间互斥
        private boolean mutex;
        // 是否入群
        private boolean groupMember;
        // 是否加入BC企业微信
        private boolean joinEnterpriseWechatForBC;

        // 限制一个挡位的礼品允许兑换的数量
        private int totalLimitQuantity;
        // 购买次数限制
        private PurchaseLimit purchaseLimit;

        @Override
        public int compareTo(GiftGrade giftGrade) {
            return this.getGroupName().concat("-").concat(this.name)
                    .compareTo(giftGrade.groupName.concat("-").concat(giftGrade.name));
        }
    }
}
