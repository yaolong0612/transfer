package cn.com.pg.loyalty.application.dto;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.RedemptionStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.beanutils.BeanUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/12
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class RedemptionDto extends TransactionDto {

    /**
     * 兑换礼包列表
     */
    List<GiftPackageDto> giftPackageList = new ArrayList<>(4);


    /**
     * 订单状态
     */
    private RedemptionStatus redemptionStatus;

    /**
     * 收货柜台
     */
    private String storeCode;


    /**
     * 兑换唯一的标识码,这个兑换码TODO
     */
    private String redeemCode;

    /**
     * 发货渠道
     */
    private DeliveryChannel deliveryChannel;
    /**
     * 收货人
     */
    private String receiver;

    /**
     * 收货人电话
     */
    private String phone;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate pickUpDate;


    public static RedemptionDto build(Redemption source) {
        try {
            RedemptionDto target = new RedemptionDto();
            BeanUtils.copyProperties(target, source);
            return target;
        } catch (Exception e) {
            throw new SystemException("无法正常转换兑换信息做topic消息", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
    }
}
