package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dto.RedemptionDto;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/12
 */
@Component
@Slf4j
public class DeliveryGoodsConsumerV2 extends AbstractConsumerV2 {
    @Autowired
    private TransactionService transactionService;

    @Override
    public void doBusiness(JSONObject message) {
        RedemptionDto redemptionDto = JSON.toJavaObject(message, RedemptionDto.class);
        transactionService.deliversGoods(redemptionDto.getId(), redemptionDto.getPartitionKey(), redemptionDto.getActivityId(), redemptionDto.getMemberId());
        log.info("兑换id：{} 已发送Logistics信息", redemptionDto.getId());
    }


    @Override
    public ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.S_DELIVER_GOODS;
    }
}
