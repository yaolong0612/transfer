package cn.com.pg.loyalty.domain.dmp;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-27 17:20
 */

@Repository
public interface StoreRepository extends DocumentDbRepository<Store, String> {

    List<Store> findStoreById(String id);

    @Override
    Store save(Store store);
}
