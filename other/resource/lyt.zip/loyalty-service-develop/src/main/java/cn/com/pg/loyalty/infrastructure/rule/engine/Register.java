package cn.com.pg.loyalty.infrastructure.rule.engine;

import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface Register {

    RuleScope scope() default RuleScope.CALCULATE_RULE;

    RuleType ruleType() default RuleType.ORDER;

    RuleLable[] ruleLables() default {};

}
