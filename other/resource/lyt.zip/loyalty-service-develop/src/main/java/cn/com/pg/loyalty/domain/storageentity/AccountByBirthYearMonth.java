package cn.com.pg.loyalty.domain.storageentity;

import cn.com.pg.loyalty.infrastructure.storage.StorageEntity;
import com.microsoft.azure.storage.table.TableServiceEntity;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Simon
 * @date 2019/6/22 23:40
 * @description 分区键逻辑：marketingProgramId +“-”+babyBirthYearAndMonth
 **/
@Getter
@Setter
@ToString
@NoArgsConstructor
@StorageEntity(name = "AccountByBirthYearMonthV2")
public class AccountByBirthYearMonth extends TableServiceEntity {
    private String loyaltyId;
    private String marketingProgramId;
    private String babyBirthYearAndMonth;
    private String brand;
    private String region;

    public AccountByBirthYearMonth(String partitionKey, String rowKey) {
        this.partitionKey = partitionKey;
        this.rowKey = rowKey;
    }
}
