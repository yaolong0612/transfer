package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.ChannelSet3;
import cn.com.pg.loyalty.domain.activity.prop.MultiplePointOrderProperties;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics.SubAccountType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.domain.activity.prop.ChannelSet3.Scope.EXCLUDE;
import static java.util.stream.Collectors.groupingBy;

@Rule(name = "MultiplePointOrderRule",
        description = "calculate the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class MultiplePointOrderRule {
    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CacheService cacheService;

    private static final String ALL_CHANNEL = "ALL";

    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList) {
        return activityList.stream().anyMatch(activity -> RuleTemplate.MULTIPLE_POINT_ORDER_RULE.equals(activity.ruleTemplate()));
    }

    @Action
    public void addPoint(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                         @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                         @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                         @Fact(RuleParamNameConfig.RULE_PARAM_BRAND_STR) String brand,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                         @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure loyaltyStructure,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        log.info("执行订单计算任务，订单号:{}", order.getOrderId());
        for (Activity activity : activityList) {
            if (!RuleTemplate.MULTIPLE_POINT_ORDER_RULE.equals(activity.ruleTemplate())) {
                continue;
            }
            MultiplePointOrderProperties ruleProperties = JSON.parseObject(activity.getRuleProperties(), MultiplePointOrderProperties.class);
            boolean competition = ruleProperties.isCompetition();
            List<ChannelSet3> channelSets = ruleProperties.getChannels();
            for (ChannelSet3 channelSet : channelSets) {
                //配置指定渠道或者ALL 允许通过
                boolean flag = channelSet.getChannel().equals(order.channel()) || ALL_CHANNEL.equals(channelSet.getChannel());
                if (!flag) {
                    log.info("activity channel not config, activityId: {}, channel: {}", activity.activityId(),
                            order.channel());
                    continue;
                }
                //条件限制
                if (!haveRight(channelSet, account, brand, order, loyaltyStructure, activity)) {
                    //如果发现没有权限参与  则直接返回
                    log.info("the member: {} not have right,the activityId: {}", account.memberId(),activity.getId());
                    continue;
                }
                //计算积分
                int calculatePoint = calculatePoint(channelSet, account, brand, activity, order, loyaltyStructure);
                // 超过赠送积分上限，以配置的上限值为准，默认无上限配置为0
                if (Objects.nonNull(ruleProperties.getUpperLimitPoint()) && ruleProperties.getUpperLimitPoint() > 0 && calculatePoint > ruleProperties.getUpperLimitPoint()) {
                    calculatePoint = ruleProperties.getUpperLimitPoint();
                }
                //传入的积分大于0，则默认为加固定积分
                putPointItem(competePointItems,  activity, competition, calculatePoint);
                //符合一个ChannelSet3就退出
                break;
            }
        }
        log.info("执行订单多倍积分规则完成，订单号:{}", order.getOrderId());
        ruleResult.success();
    }

    private void putPointItem(Map<PointItem, Boolean> competePointItems,
                              Activity activity, boolean competition, int calculatePoint) {
        if (calculatePoint == 0) {
            return;
        }
        competePointItems.put(new PointItem(calculatePoint, activity.description(), activity.activityId()), competition);
    }

    private int calculatePoint(ChannelSet3 channelSet3, Account account,
                               String brand, Activity activity,
                               Order order, LoyaltyStructure structure) {
        ChannelSet3.Type multipleType = channelSet3.getMultipleType();
        ChannelSet3.SkuEnum skuParticipateType = channelSet3.getSkuParticipateType();
        int point = 0;
        Double realTotalAmount = order.realTotalAmount();
        if (ChannelSet3.Type.REGULAR.equals(multipleType)) {
            // 如果sku作为算分条件有配置，则只加配置的sku分数
            if (ChannelSet3.SkuEnum.CALCULATE.equals(skuParticipateType)) {
                List<String> skuList = channelSet3.getSkuConfig().stream()
                        .filter(item -> ChannelSet3.Scope.INCLUDE.equals(item.getScope()))
                        .map(item -> Arrays.asList(StringUtils.split(item.getSkus(), ",")))
                        .flatMap(Collection::stream)
                        .collect(Collectors.toList());
                realTotalAmount = order.getOrderItems().stream().filter(item -> skuList.contains(item.getSku()))
                        .mapToDouble(OrderItem::getRealAmount).sum();
            }
            //固定倍数只会有一个值
            double baseAmount = structure.amountRate().exchange2BaseAmount(realTotalAmount);
            point = (int) Math.ceil(channelSet3.getMultipleTimes() * baseAmount);
        } else if (ChannelSet3.Type.FLOAT.equals(multipleType)) {
            List<ChannelSet3.LimitMoneyAndMultiple> multipleList = channelSet3.getMultiple();
            List<ChannelSet3.LimitMoneyAndMultiple> sortedLimitPoints =
                    multipleList.stream().sorted(Comparator.comparing(ChannelSet3.LimitMoneyAndMultiple::getMoney).reversed()).collect(Collectors.toList());
            //已经存在一个基础订单积分了，因此这里给0.0
            double mul = 0.0;
            for (ChannelSet3.LimitMoneyAndMultiple limitMoneyAndMultiple : sortedLimitPoints) {
                //已经经过倒叙排序了
                if (realTotalAmount >= limitMoneyAndMultiple.getMoney()) {
                    mul = limitMoneyAndMultiple.getMultiple();
                    break;
                }
            }
            double totalAmount = order.realTotalAmount();
            //如果订单金额超过最大金额
            if (totalAmount > channelSet3.getUpperLimitMoney()) {
                //超过限制部分的金额
                double upperLimitAmount = totalAmount - channelSet3.getUpperLimitMoney();
                totalAmount = channelSet3.getUpperLimitMoney();
                //超过最大金额限制部分的积分
                point += Math.ceil(upperLimitAmount * channelSet3.getMoreLimitMoneyMultiple());
            }
            double baseAmount = structure.amountRate().exchange2BaseAmount(totalAmount);
            point += Math.ceil(baseAmount * mul);
        }
        return point;
    }

    private boolean haveRight(ChannelSet3 channelSet3, Account account,
                              String brand, Order order, LoyaltyStructure loyaltyStructure, Activity activity) {
        //指定柜台条件
        if (!matchPartakeStoreCodeCondition(channelSet3, order)) {
            return Boolean.FALSE;
        }
        //指定sku条件
        if (!matchPartakeSkuCodeCondition(channelSet3, order)) {
            return Boolean.FALSE;
        }
        //等级和积分条件
        if (!matchTierAndPointCondition(account,order, channelSet3)) {
            return Boolean.FALSE;
        }
        //订单条件
        return matchPartakeOrderCondition(account, brand, activity, channelSet3, order, loyaltyStructure);
    }

    private boolean matchPartakeSkuCodeCondition(ChannelSet3 channelSet3, Order order) {
        if (CollectionUtils.isEmpty(channelSet3.getSkuConfig())) {
            //没有配置表示所有都可以参与
            return Boolean.TRUE;
        }
        return channelSet3.getSkuConfig().get(0).getScope().matchSkuCondition(order, channelSet3);
    }

    private boolean matchPartakeStoreCodeCondition(ChannelSet3 channelSet3, Order order) {
        String orderStoreCode = order.getStoreCode();
        if (StringUtils.isEmpty(orderStoreCode) || !ChannelV2.COUNTER.equals(order.channel()) || CollectionUtils.isEmpty(channelSet3.getStoreCodeConfig())) {
            //若是没有配置storeCode，则不校验
            return Boolean.TRUE;
        }
        Store storeByStoreCode = cacheService.getStoreByStoreCode(orderStoreCode);
        Map<ChannelSet3.Scope, List<ChannelSet3.StoreCode>> storeMap =
                channelSet3.getStoreCodeConfig().stream().collect(groupingBy(ChannelSet3.StoreCode::getScope,
                        Collectors.toList()));
        // storeType 提取
        Set<String> includeStoreType = collectCondition(storeMap, ChannelSet3.Scope.INCLUDE, ChannelSet3.StoreCode::getStoreType);
        Set<String> excludeStoreType = collectCondition(storeMap, EXCLUDE, ChannelSet3.StoreCode::getStoreType);
        // storeCode 提取
        Set<String> includeStoreCode = collectCondition(storeMap, ChannelSet3.Scope.INCLUDE,
                item -> Arrays.asList(StringUtils.split(item.getStoreCodes(), ",")));
        Set<String> excludeStoreCode = collectCondition(storeMap, EXCLUDE,
                item -> Arrays.asList(StringUtils.split(item.getStoreCodes(), ",")));
        List<Boolean> result = new ArrayList<>();
        if (Objects.nonNull(storeByStoreCode)) {
            // storeType: TEMPORARY/DS/ESTORE(TMALL/JD/OTHERS/VIRTUAL)/ORC
            result.add(matchStoreCondition(ChannelSet3.Scope.INCLUDE, storeByStoreCode.storeType().name(),
                    includeStoreType));
            result.add(matchStoreCondition(EXCLUDE, storeByStoreCode.storeType().name(),
                    excludeStoreType));
        }
        result.add(matchStoreCondition(ChannelSet3.Scope.INCLUDE, orderStoreCode, includeStoreCode));
        result.add(matchStoreCondition(EXCLUDE, orderStoreCode, excludeStoreCode));
        if (!result.contains(Boolean.FALSE)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public Set<String> collectCondition(Map<ChannelSet3.Scope, List<ChannelSet3.StoreCode>> storeMap,
                                        ChannelSet3.Scope scope,
                                        Function<ChannelSet3.StoreCode, List<String>> function) {
        return storeMap.getOrDefault(scope, new ArrayList<>())
                .stream()
                .map(function)
                .filter(CollectionUtils::isNotEmpty)
                .flatMap(Collection::stream)
                .collect(Collectors.toSet());
    }


    public boolean matchStoreCondition(ChannelSet3.Scope scope, String value, Set<String> conditionList) {
        if (CollectionUtils.isEmpty(conditionList)) {
            // 配置为空，无需校验
            return Boolean.TRUE;
        }
        if (ChannelSet3.Scope.INCLUDE.equals(scope) && conditionList.contains(value)) {
            return Boolean.TRUE;
        }
        if (EXCLUDE.equals(scope) && !conditionList.contains(value)) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }



    private boolean matchTierAndPointCondition(Account account, Order order, ChannelSet3 channelSet3) {
        Integer pointLimit = Optional.ofNullable(channelSet3.getPointLimit()).orElse(0);
        ChannelSet3.Relation pointTierRelation = channelSet3.getPointTierRelation();
        List<String> tiersLimit = channelSet3.getTierLimit();
        if ((pointLimit == null || pointLimit == 0) && CollectionUtils.isEmpty(tiersLimit)) {
            //都没有配置表示没有该条件限制
            return Boolean.TRUE;
        }
        //如果是AND，则表示积分和等级的条件是需要同时满足
        if (ChannelSet3.Relation.AND.equals(pointTierRelation)) {
            //等级不在配置的项目中或者积分不够标准,结束后面的逻辑
            return tiersLimit.stream().anyMatch(level -> order.getCurrentLevel().equals(level)) &&
                    pointLimit <= account.availablePoint(SubAccountType.DEFAULT);
        } else {
            //等级不在配置的项目中且积分不够标准，结束后面的逻辑
            return tiersLimit.stream().anyMatch(level -> order.getCurrentLevel().equals(level)) ||
                    (pointLimit > 0 && pointLimit <= account.availablePoint(SubAccountType.DEFAULT));
        }
    }

    private boolean matchPartakeOrderCondition(Account account, String brand,
                                               Activity activity, ChannelSet3 channelSet3, Order order,
                                               LoyaltyStructure structure) {
        List<Integer> partakeOrders = channelSet3.getPartakeOrders();
        SubAccount subAccount = account.subAccount(brand, structure.accountTypeOfDefault());
        if (CollectionUtils.isEmpty(partakeOrders)) {
            //没有配置表示所有都可以参与
            return Boolean.TRUE;
        }
        // 距首次购买时间限制
        if (Objects.nonNull(channelSet3.getTimePeriodType()) && Objects.nonNull(channelSet3.getTimePeriod())) {
            LocalDateTime secondOrderEndTime = null;
            LocalDateTime inspectionTime = channelSet3.getInspectionTime();
            if (Objects.isNull(subAccount.getFirstPurchaseTime())) {
                return Boolean.FALSE;
            }

            if (Objects.nonNull(inspectionTime) && subAccount.getFirstPurchaseTime().isAfter(inspectionTime)) {
                return Boolean.FALSE;
            }

            switch (channelSet3.getTimePeriodType()) {
                case MONTH:
                    secondOrderEndTime = subAccount.getFirstPurchaseTime().plusMonths(channelSet3.getTimePeriod());
                    break;
                case DAY:
                    secondOrderEndTime = subAccount.getFirstPurchaseTime().plusDays(channelSet3.getTimePeriod());
                    break;
                default:
                    break;
            }
            if (secondOrderEndTime == null || secondOrderEndTime.isBefore(order.getOrderDateTime())) {
                return Boolean.FALSE;
            }
        }
        //查询活动期间的订单
        List<Order> orders =
                orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                        PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                        brand, TransactionType.ORDER,
                        activity.getStartAt().toString(),
                        activity.getEndAt().toString());
        List<Order> filteredOrders = orders.stream()
                // 过滤团购
                .filter(item -> !item.groupPurchaseIs())
                // 过滤全部退单的
                .filter(item -> !item.refundAllOrder())
                // 退单时过滤原单
                .filter(item -> !item.getOrderId().equals(order.getOrderId()))
                // 过滤同渠道
                .filter(item -> channelSet3.getChannel().equals(ALL_CHANNEL)
                        || order.channel().equals(item.channel()))
                .collect(Collectors.toList());
        // 已获得过活动奖励积分不加分,防止重复插单的情况
        Map<String, Long> bonusTimesMap = filteredOrders.stream()
                .map(Order::getPointItems)
                .flatMap(Collection::stream)
                .map(PointItem::getActivityId)
                .collect(groupingBy(Function.identity(), Collectors.counting()));
        if (partakeOrders.size() <= bonusTimesMap.getOrDefault(activity.activityId(), 0L)) {
            return Boolean.FALSE;
        }
        List<Order> filterByOrderDateTimeOrders = filteredOrders.stream()
                // 只取订单时间之前的参与判断
                .filter(item -> !item.getOrderDateTime().isAfter(order.getOrderDateTime()))
                // 订单时间相同只取同一createdTime之前的
                .filter(item -> !(item.getOrderDateTime().isEqual(order.getOrderDateTime())
                        && item.getCreatedTime().isAfter(order.getCreatedTime())))
                .collect(Collectors.toList());
        //活动期间的已存在订单量必须少于指定的第几单中至少一个  count - 1 == orders.size()表示当前订单可参与活动
        return partakeOrders.stream().anyMatch(count -> count - 1 == filterByOrderDateTimeOrders.size());
    }
}
