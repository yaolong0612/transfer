package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.GiftService;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCouponService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.interfaces.api.CouponApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.GiftAssembler;
import cn.com.pg.loyalty.interfaces.dto.AddHKPampersStoreNameDisplayMsgCommand;
import cn.com.pg.loyalty.interfaces.dto.CouponDTO;
import cn.com.pg.loyalty.interfaces.dto.CouponListDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@Component("CouponFacade")
public class CouponFacade implements CouponApiDelegate {

    @Autowired
    private GiftCouponService couponService;
    @Autowired
    private GiftService giftService;
    @Autowired
    private CacheService cacheService;

    @Override
    public ResponseEntity<CouponListDTO> fetchCouponList(String brand, String region, String memberId,String language) {
        Locale locale = ParamValidator.validateLanguage(language);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        List<GiftCoupon> coupons = couponService.findByMemberId(brand, region, memberId,locale);
        List<CouponDTO> records = coupons.stream().sorted(Comparator.comparing(GiftCoupon::getCreatedTime).reversed()).map(giftCoupon -> {
            Gift gift = giftService.findByGiftBagSku(giftCoupon.getBagSku(), loyaltyStructure);
            return GiftAssembler.toCouponDto(giftCoupon, gift);
        }).collect(Collectors.toList());
        CouponListDTO couponListDTO = new CouponListDTO();
        couponListDTO.setTotalSize(records.size());
        couponListDTO.setRecords(records);
        return ResponseEntity.ok(couponListDTO);
    }

    @Override
    public ResponseEntity<Void> addHKPampersStoreNameDisplayMsg(AddHKPampersStoreNameDisplayMsgCommand body) {
        couponService.addHKPampersStoreNameDisplayMsg(body);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
