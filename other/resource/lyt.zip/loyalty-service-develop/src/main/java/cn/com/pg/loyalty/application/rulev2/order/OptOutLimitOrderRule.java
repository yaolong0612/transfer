package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.AccountOpt;
import cn.com.pg.loyalty.domain.account.AccountOptRepository;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: Hayden
 * @CreateDate: 2021/4/14 18:08
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/4/14 18:08
 * @Version: 1.0
 * @Description:
 */
@Rule(name = "Opt Rule",
        description = "limit add the point opt out")
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.ORDER)
public class OptOutLimitOrderRule {

    @Resource
    private AccountOptRepository accountOptRepository;


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList) {
        return activityList.stream().anyMatch(activity -> activity.matchRuleTemplate(RuleTemplate.ORDER_OPT_OUT_LIMIT));
    }

    @Action
    public void runRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order requestOrder,
                        @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult result) {
        AccountOpt accountOpt = accountOptRepository.fetchAccountOptByLoyaltyId(requestOrder.getLoyaltyId());
        if (!requestOrder.catchOptOut(accountOpt)) {
            result.success();
            return;
        }
        requestOrder.optOutOrder();
        result.end();
    }
}
