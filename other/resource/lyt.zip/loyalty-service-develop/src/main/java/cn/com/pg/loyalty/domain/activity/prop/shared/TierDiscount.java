package cn.com.pg.loyalty.domain.activity.prop.shared;

import lombok.Getter;
import lombok.Setter;

/**
 * 等级折扣
 *
 * @author vincenzo
 * @description
 * @date 2022/1/19
 */
@Getter
@Setter
public class TierDiscount {
    /**
     * 等级id
     */
    private String tierLimit;
    /**
     * 折扣率
     */
    private double discount;

}
