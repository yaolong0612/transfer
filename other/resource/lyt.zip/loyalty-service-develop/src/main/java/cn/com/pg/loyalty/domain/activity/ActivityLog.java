package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

/**
 * @author Simon
 * @date 2019/6/26 23:33
 * @description
 **/
@Getter
@Setter
@Document(collection = "ActivityLog", ru = "400")
@Slf4j
@NoArgsConstructor
public class ActivityLog {
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.ACTIVITY_LOG_PARTITIONKEY;
    private String activityId;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    private String operator;

    private OperationType operationType;

    private Activity activity;

    public ActivityLog(String operator, OperationType operationType, Activity activity) {
        this.id = UUIDUtil.generator();
        this.activityId = activity.activityId();
        this.createdTime = LocalDateTime.now();
        this.operator = operator;
        this.operationType = operationType;
        this.activity = activity;
    }

    public enum OperationType {
        ADD,
        UPDATE,
        DELETE
    }
}
