package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.transaction.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Service
public class InteractionRepositoryImplV2 implements InteractionRepositoryV2 {

    @Autowired
    private InteractionRepository interactionRepository;

    @Override
    public List<Interaction> fetchInteractionsByExternalBusinessId(String loyaltyId, String externalBusinessId) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        return interactionRepository.findByPartitionKeyAndLoyaltyIdAndExternalBusinessIdAndTransactionType(
                pk, loyaltyId, externalBusinessId, TransactionType.INTERACTION);
    }

    @Override
    public List<Interaction> fetchByPointTypes(String loyaltyId, String... pointTypes) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        return interactionRepository.findByPartitionKeyAndLoyaltyIdAndPointTypeIn(pk, loyaltyId, Arrays.asList(pointTypes));
    }

    @Override
    public boolean existedExpiredPointAfter(String loyaltyId, LocalDateTime createdTime) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String createdAt= LoyaltyDateTimeUtils.localDateTimeToString(createdTime);
        return interactionRepository.existsByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeAfterAndPointGreaterThan(pk,loyaltyId,
                Transaction.PointTypeEnum.SYSTEM_EXPIRED_POINT.name(), createdAt,0);
    }
}
