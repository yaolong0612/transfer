package cn.com.pg.loyalty.domain.account;

/**
 * @author lvyanlin
 * @date 2022/6/17 18:02
 */
public interface CheckMemberGroupTagGateway {

    boolean isWechatGroupFriend(String memberId, String brand);

    boolean judgeJoinEnterpriseWechatForBC(String memberId, String brand);
}
