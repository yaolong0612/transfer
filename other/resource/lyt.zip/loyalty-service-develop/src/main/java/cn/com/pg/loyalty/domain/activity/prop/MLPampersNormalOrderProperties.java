package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Optional;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 * 日常订单积分
 */

@Getter
@Setter
public class MLPampersNormalOrderProperties extends RuleProperties {

    /**
     * 订单基础积分数
     */
    @Min(0)
    @NotNull
    private Integer basePoint;

    public Integer basePoint() {
        return Optional.ofNullable(basePoint).orElse(0);
    }
}
