package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.application.rule.interaction.*;
import cn.com.pg.loyalty.application.rule.tier.*;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rule;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.DefaultRulesEngine;

import java.util.Map;

/**
 * @author Simon
 * @date 2019/5/4 18:24
 * @description
 **/
@Getter
@Slf4j
public class RuleEngineSupport {

    private RulesEngine rulesEngine;

    private Facts facts;

    private Rules rules;

    private RuleResult ruleResult;

    public RuleEngineSupport() {
        rulesEngine = new DefaultRulesEngine();
        facts = new Facts();
        ruleResult = new RuleResult();
        facts.put("ruleResult", ruleResult);
        rules = new Rules();
    }

    public RuleEngineSupport addFact(String name, Object object) {
        facts.put(name, object);
        return this;
    }

    public RuleEngineSupport registerRule(Object rule) {
        this.rules.register(rule);
        return this;
    }

    public RuleEngineSupport fire() {
        rulesEngine.fire(rules, facts);
        Map<Rule, Boolean> ruleBooleanMap = rulesEngine.check(rules, facts);
        boolean flag = true;
        for (Map.Entry<Rule, Boolean> entry : ruleBooleanMap.entrySet()) {
            if (Boolean.TRUE.equals(entry.getValue())) {
                flag = false;
                break;
            }
        }
        if (flag) {
            return this;
        }
        checkAnyResult();
        return this;
    }

    /**
     * 如果有任何异常，就将异常抛出
     */
    private void checkAnyResult() {
        log.info("Check the Rule Result");
        if (!ruleResult.getSystemExceptions().isEmpty()) {
            log.info("Exception number: {}", ruleResult.getSystemExceptions().size());
            throw ruleResult.getSystemExceptions().get(0);
        }
        //强制检查执行rule的时候是否存在异常
        if (!ruleResult.isSuccess()) {
            log.info("Check result is not success");
            throw new SystemException("Execute Rule error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }




   /**
     * 创建与等级相关的rule engine
     *
     * @return
     */
    public static RuleEngineSupport tierRuleEngineSupportBuild() {
        RuleEngineSupport ruleEngineSupport = new RuleEngineSupport();
        MlOlayTierRule mlOlayTierRule = new MlOlayTierRule();
        HktwPampersTierRule hktwPampersTierRule = new HktwPampersTierRule();
        CalculateTierByPointRule calculateTierByPointRule = new CalculateTierByPointRule();
        CalculateTierByQuantityOfOrderRule calculateTierByQuantityOfOrderRule =
                new CalculateTierByQuantityOfOrderRule();

        ruleEngineSupport.registerRule(mlOlayTierRule)
                .registerRule(hktwPampersTierRule)
                .registerRule(calculateTierByPointRule)
                .registerRule(new CalculateTierByOrderRule())
                .registerRule(calculateTierByQuantityOfOrderRule);
        return ruleEngineSupport;
    }

    /**
     * 等级过期重算等级
     *
     * @return
     */
    public static RuleEngineSupport tierExpiredRecalculateRuleEngineSupportBuild() {
        RuleEngineSupport ruleEngineSupport = new RuleEngineSupport();

        ruleEngineSupport.registerRule(new MlOlayTierRule())
                .registerRule(new HktwPampersTierRule())
                .registerRule(new RecalculateTierRule())
                .registerRule(new CalculateTierByQuantityOfOrderRule());
        return ruleEngineSupport;
    }

    /**
     * 交互积分的规则引擎，宝宝生日月加积分
     *
     * @return
     */
    public static RuleEngineSupport babyBirthdayMonthRuleEngineSupportBuild() {
        RuleEngineSupport ruleEngineSupport = new RuleEngineSupport();
        // 限制次数的调整积分
        AdjustPointTimesRule adjustPointTimesRule = new AdjustPointTimesRule();
        ruleEngineSupport.registerRule(adjustPointTimesRule);
        return ruleEngineSupport;
    }

    /**
     * 交互积分的规则引擎，例如，签到积分，扫码加积分，宝宝生日月加积分
     *
     * @return
     */
    public static RuleEngineSupport interactionRuleEngineSupportBuild() {
        RuleEngineSupport ruleEngineSupport = new RuleEngineSupport();
        //扫码加积分
        HkTwPampersScanCodeRule hkTwPampersScanCodeRule = new HkTwPampersScanCodeRule();
        MlOlayScanCodeRule mlOlayScanCodeRule = new MlOlayScanCodeRule();
        MlOralbScanCodeRule mlOralbScanCodeRule = new MlOralbScanCodeRule();
        // 手动调节积分
        AdjustPointByClientRule adjustPointRule = new AdjustPointByClientRule();
        //客服管理员调节积分
        AdjustPointByManagerRule adjustPointByManagerRule = new AdjustPointByManagerRule();
        // 限制次数的调整积分
        AdjustPointTimesRule adjustPointTimesRule = new AdjustPointTimesRule();
        // 每天限制加分次数
        AdjustPointTimesPerDayRule adjustPointTimesPerDayRule = new AdjustPointTimesPerDayRule();
        // 每月限制加分次数
        AdjustPointTimesPerMonthRule adjustPointTimesPerMonthRule = new AdjustPointTimesPerMonthRule();
        // 每季度限制加分次数
        AdjustPointTimesPerQuarterRule adjustPointTimesPerQuarterRule = new AdjustPointTimesPerQuarterRule();
        // 每年限制加分次数
        AdjustPointTimesPerYearRule adjustPointTimesPerYearRule = new AdjustPointTimesPerYearRule();
        MlPampersScanCodeRule mlPampersScanCodeRule = new MlPampersScanCodeRule();
        DailyAttendanceRule dailyAttendanceRule = new DailyAttendanceRule();
        AdjustPointPeriodTimeRule adjustPointPeriodTimeRule = new AdjustPointPeriodTimeRule();
        AddPointInLimitDaysByRegisterTimeRule addPointInLimitDaysByRegisterTimeRule = new AddPointInLimitDaysByRegisterTimeRule();
        ruleEngineSupport.registerRule(hkTwPampersScanCodeRule)
                .registerRule(adjustPointRule)
                .registerRule(mlOlayScanCodeRule)
                .registerRule(mlOralbScanCodeRule)
                .registerRule(adjustPointTimesRule)
                .registerRule(adjustPointTimesPerDayRule)
                .registerRule(adjustPointTimesPerQuarterRule)
                .registerRule(adjustPointTimesPerYearRule)
                .registerRule(adjustPointTimesPerMonthRule)
                .registerRule(mlPampersScanCodeRule)
                .registerRule(dailyAttendanceRule)
                .registerRule(adjustPointByManagerRule)
                .registerRule(new AdjustPointByFirstOrderLimitDaysRule())
                .registerRule(adjustPointPeriodTimeRule)
                .registerRule(addPointInLimitDaysByRegisterTimeRule)
                .registerRule(new AdjustPointInComplexConditionRule())
                .registerRule(new ConvertPointRule());

        return ruleEngineSupport;
    }

    public static RuleEngineSupport interactionLimitAfterCalculate() {
        RuleEngineSupport ruleEngineSupport = new RuleEngineSupport();
        ruleEngineSupport.registerRule(new InteractionLimitPointPeriodDateRule());
        return ruleEngineSupport;
    }


}
