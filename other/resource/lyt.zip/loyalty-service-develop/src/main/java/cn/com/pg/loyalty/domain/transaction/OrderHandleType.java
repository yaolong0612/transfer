package cn.com.pg.loyalty.domain.transaction;

/**
 * 
 * @author 		Naive
 * @date   		2019年5月16日下午3:51:46
 * @description 用来协助处理订单
 */
public enum OrderHandleType {
	/**
	 * 从ServiceBus中接收的订单中时间最早的那笔
	 */
	EARLIEST_ORDER_ONE_DAY,
	/**
	 * 退单
	 */
	CHARGE_BACK,
	/**
	 * 团购
	 */
	GROUP_PURCHASE,
	/**
	 * 普通订单
	 */
	NORMAL;
}
