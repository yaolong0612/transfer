package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
/**
 * @description:
 * @author: Jevons Chen
 * @date: 2020-02-10 14:02
 */

@Getter
@Setter
public class OrderAddPointByPurchaseUnitProperties extends RuleProperties{

    /**
     * 订单基础积分
     */
    @Min(0)
    @NotNull
    private Integer pointEachUnit;
}
