package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class ExtraSubAccountTactics {
    private PointExpire pointExpire;
    private ExtraTactics extraTactics;

    public ExtraSubAccountTactics(PointExpire pointExpire, ExtraTactics extraTactics) {
        if (extraTactics == null || pointExpire == null) {
            throw new SystemException("Tactics config pampers not null", ResultCodeMapper.PARAM_ERROR);
        }
        this.pointExpire = pointExpire;
        this.extraTactics = extraTactics;
    }

    public static ExtraSubAccountTactics createDefault() {
        return new ExtraSubAccountTactics(new PointExpire(), ExtraTactics.NONE);
    }

    /**
     * 扩展账号策略：修改是必须非常注意，否则会取错账户，和积分过期配置
     */
    public enum ExtraTactics {
        /**
         * 默认账户不生效
         */
        NONE() {
            @Override
            SubAccountType subAccountType(ValueType valueType) {
                return SubAccountType.DEFAULT;
            }
        },
        /**
         * 使用额外账户,默认账户作为过渡积分账户
         */
        EXTRA_AS_DEFAULT_ACCOUNT() {
            @Override
            SubAccountType subAccountType(ValueType valueType) {
                if(valueType==null){
                    return SubAccountType.EXTRA_AS_DEFAULT_CALL_TRANSIT;
                }
                if (ValueType.TRANSIT.equals(valueType)) {
                    return SubAccountType.EXTRA_AS_DEFAULT_CALL_TRANSIT;
                }
                return SubAccountType.EXTRA_AS_DEFAULT_CALL_DEFAULT;
            }
        },
        /**
         * 使用默认账户，额外开启过渡积分账户
         */
        EXTRA_AS_TRANSIT_SUB_ACCOUNT() {
            @Override
            SubAccountType subAccountType(ValueType valueType) {
                if(valueType==null){
                    return SubAccountType.EXTRA_AS_TRANSIT_CALL_TRANSIT;
                }
                if (ValueType.TRANSIT.equals(valueType)) {
                    return SubAccountType.EXTRA_AS_TRANSIT_CALL_TRANSIT;
                }
                return SubAccountType.EXTRA_AS_TRANSIT_CALL_DEFAULT;
            }
        };

        abstract SubAccountType subAccountType(ValueType valueType);

    }

    /**
     * 是否应该查询扩展子账号
     */
    public enum SubAccountType {
        DEFAULT() {
            @Override
            public boolean callExtraSubAccount() {
                return false;
            }

        },
        EXTRA_AS_DEFAULT_CALL_DEFAULT() {
            @Override
            public boolean callExtraSubAccount() {
                return true;
            }

        },
        EXTRA_AS_DEFAULT_CALL_TRANSIT() {
            @Override
            public boolean callExtraSubAccount() {
                return false;
            }

        },
        EXTRA_AS_TRANSIT_CALL_DEFAULT() {
            @Override
            public boolean callExtraSubAccount() {
                return false;
            }
        },
        EXTRA_AS_TRANSIT_CALL_TRANSIT() {
            @Override
            public boolean callExtraSubAccount() {
                return true;
            }
        };

        public abstract boolean callExtraSubAccount();

    }
}
