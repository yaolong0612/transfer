package cn.com.pg.loyalty.infrastructure.monitoring;

import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import com.microsoft.applicationinsights.TelemetryClient;
import com.microsoft.applicationinsights.TelemetryConfiguration;
import com.microsoft.applicationinsights.telemetry.Duration;
import com.microsoft.applicationinsights.telemetry.EventTelemetry;
import com.microsoft.applicationinsights.telemetry.RemoteDependencyTelemetry;
import com.microsoft.applicationinsights.telemetry.RequestTelemetry;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static cn.com.pg.loyalty.application.TransactionService.KPI_ADD_INTERACTION_POINT;
import static cn.com.pg.loyalty.application.TransactionService.KPI_ADD_ORDER_POINT;

/**
 * @author xingliangzhan
 * @date 2019/8/4
 * TODO 需要增加KPI打印实现逻辑
 * DEV 环境也加载出来，防止系统报错
 */
@Slf4j
@Component
@Conditional(AzureKpiTemplate.AzureAndDevKPITemplateCondition.class)
public class AzureKpiTemplate implements KpiTemplate {
    private static final String MESSAGE = "message";

    @Autowired
    private TelemetryClient telemetryClient;
    @Autowired
    private TelemetryConfiguration telemetryConfiguration;

    public static class AzureAndDevKPITemplateCondition implements Condition {
        @Override
        public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {
            for (String activeProfile : conditionContext.getEnvironment().getActiveProfiles()) {
                if (activeProfile.equals("dev")) {
                    return true;
                }
                if (activeProfile.equals("tw")) {
                    return true;
                }
                if (activeProfile.equals("jp")) {
                    return true;
                }
            }
            return false;
        }
    }

    @Override
    public void send(HashMap<String, Object> object) {
        log.info("KpiTemplate send : {}", object.toString());
    }

    @Override
    public void sendRequest(String path, String requestMethod, String operationName, LocalDateTime requestDateTime,
                            long costTime, int errorCode, String errorMsg, String correlationId) {
        if (telemetryConfiguration.isTrackingDisabled()) {
            return;
        }
        Date requestTime = Date.from(requestDateTime.atZone(ZoneId.systemDefault()).toInstant());
        RequestTelemetry requestTelemetry = new RequestTelemetry(operationName, requestTime, costTime,
                String.valueOf(errorCode), errorCode == ResultCodeMapper.SUCCESS.getCode());
        requestTelemetry.setId(correlationId);
        requestTelemetry.setSource(KpiLog.KpiType.API_REQUEST.name());
        requestTelemetry.setHttpMethod(requestMethod);
        requestTelemetry.getContext().getOperation().setId(correlationId);
        if (StringUtils.isNotEmpty(errorMsg)) {
            requestTelemetry.getProperties().put(MESSAGE, errorMsg);
        }
        requestTelemetry.getProperties().put("path", path);
        telemetryClient.trackRequest(requestTelemetry);
    }

    @Override
    public void sendConsumingMessage(String messageId, String operationName, LocalDateTime consumingDateTime,
                                     long costTime, int errorCode, String errorMsg, String correlationId) {
        if (telemetryConfiguration.isTrackingDisabled()) {
            return;
        }
        Date requestTime = Date.from(consumingDateTime.atZone(ZoneId.systemDefault()).toInstant());
        RequestTelemetry requestTelemetry = new RequestTelemetry(operationName, requestTime, costTime,
                String.valueOf(errorCode), errorCode == ResultCodeMapper.SUCCESS.getCode());
        requestTelemetry.setId(correlationId);
        requestTelemetry.setSource(KpiLog.KpiType.CONSUME_SERVICE_BUS.name());
        requestTelemetry.getContext().getOperation().setId(correlationId);
        if (StringUtils.isNotEmpty(errorMsg)) {
            requestTelemetry.getProperties().put(MESSAGE, errorMsg);
        }
        if (StringUtils.isNotEmpty(messageId)) {
            requestTelemetry.getProperties().put("messageId", messageId);
        }
        telemetryClient.trackRequest(requestTelemetry);
    }

    @Override
    public void sendDependency(String correlationId, String operationName, KpiLog.KpiType kpiType, LocalDateTime dateTime,
                               long costTime, String resultCode, String message, boolean isSuccess, Map<String, String> properties) {
        if (telemetryConfiguration.isTrackingDisabled()) {
            return;
        }
        RemoteDependencyTelemetry telemetry = new RemoteDependencyTelemetry();
        telemetry.setCommandName(operationName);
        telemetry.setDuration(new Duration(costTime));
        telemetry.setId(correlationId);
        telemetry.setName(operationName);
        telemetry.setResultCode(resultCode);
        telemetry.setSuccess(isSuccess);
        telemetry.setTarget(kpiType.name());
        telemetry.setType(kpiType.name());
        if (properties != null) {
            telemetry.getProperties().putAll(properties);
        }
        if (StringUtils.isNotEmpty(message)) {
            telemetry.getProperties().put(MESSAGE, message);
        }
        telemetryClient.trackDependency(telemetry);
    }

    @Override
    public void sendKpi(String memberId, int point, String brand, String kpiName,
                        String channel, PointType pointType, Map<String, String> properties) {
        LocalDateTime sendTime = LocalDateTime.now();
        if (telemetryConfiguration.isTrackingDisabled()) {
            return;
        }
        Date time = Date.from(sendTime.atZone(ZoneId.systemDefault()).toInstant());
        EventTelemetry telemetry = new EventTelemetry();
        telemetry.setSequence(RequestContext.getCurrentContext().getCorrelationId());
        telemetry.setTimestamp(time);
        telemetry.getProperties().put("loyaltyPoint", String.valueOf(point));
        telemetry.getProperties().put("loyaltyKpiName", kpiName);
        if (KPI_ADD_INTERACTION_POINT.equals(kpiName) || KPI_ADD_ORDER_POINT.equals(kpiName)) {
            telemetry.getProperties().put("loyaltyUnionKpiName", "EARN_POINT");
        }
        telemetry.getProperties().put("loyaltyKpiType", KpiLog.KpiType.KPI.name());
        telemetry.getProperties().put("loyaltyBrand", String.valueOf(brand));
        telemetry.getProperties().put("loyaltyId", memberId);
        telemetry.getProperties().put("loyaltyChannel", String.valueOf(channel == null ? "DEFAULT-CHANNEL" : channel));
        if (pointType != null) {
            telemetry.getProperties().put("loyaltyPointDescription", pointType.description());
            telemetry.getProperties().put("loyaltyPointType", pointType.pointType());
            telemetry.getProperties().put("loyaltyStructure", pointType.getLoyaltyStructure());
        }
        if (properties != null) {
            telemetry.getProperties().putAll(properties);
        }
        telemetryClient.trackEvent(telemetry);
    }

}
