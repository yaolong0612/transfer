package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:51
 */
@Data
public class ChannelSet {

    @NotNull
    @Valid
    private OnlineHolidayChannel channelName;
    @Min(0)
    private double baseAmount;
    @Min(0)
    private int lessThenBaseMultiple;
    @Min(0)
    private int moreThenBaseMultiple;
    @Min(0)
    private double multiplePointLimitAmount;
    private List<String> storeCodes = new ArrayList<>();

    /**
     * 只有这5个渠道才会用到这个活动模板，20211222新增VIP
     */
    public enum OnlineHolidayChannel {
        /**
         * 线下JD
         */
        JD,
        /**
         * 线下TMALL
         */
        TMALL,
        /**
         * 百货商店
         */
        DS,
        /**
         * 商业超市
         */
        ORC,
        /**
         * C2柜台
         */
        COUNTER,
        /**
         * 临时柜
         */
        TEMPORARY,
        /**
         * 微信渠道
         */
        WECHAT,
        /**
         * 小程序
         */
        WECHAT_MINI_PROGRAM,
        /**
         * 唯品会
         */

        VIP,
        /**
         * 抖音
         */
        DOUYIN


    }
}
