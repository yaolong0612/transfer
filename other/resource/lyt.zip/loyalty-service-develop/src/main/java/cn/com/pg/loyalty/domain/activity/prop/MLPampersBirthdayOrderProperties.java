package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 * 、宝宝生日月
 */

@Getter
@Setter
public class MLPampersBirthdayOrderProperties extends RuleProperties {

    /**
     * 积分数
     */
    @Min(0)
    @NotNull
    private Integer basePoint;

    /**
     * 是否需要区分订单渠道，需要：填写相应的channel 不需要：留空
     */
    List<String> channels = new ArrayList<>();

    /**
     * 是否与其他加积分竞争：多个活动取值最高分
     * false: 不参与 直接作为相加中一项
     * true: 参与竞争
     */
    private Boolean competition;

    public Integer basePoint() {
        return Optional.ofNullable(basePoint).orElse(0);
    }

    public Boolean competition() {
        return Optional.ofNullable(competition).orElse(false);
    }

    public List<String> channels() {
        return Optional.ofNullable(channels).orElse(new ArrayList<>());
    }
}
