package cn.com.pg.loyalty.domain.pool;

import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.shared.Entity;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

@Slf4j
@Document(collection = "PointPool", ru = "400")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class PointPool implements Entity<PointPool> {
    /**
     * 积分池id，对应的是loyaltyId
     */
    @Id
    @PartitionKey
    private String id;

    /**
     * 可用积分聚合aggregation，map结构
     * expiredPointKey yyyyMMdd 例:20211231,20211231
     */
    private TreeMap<LocalDate, Item> availablePointPool = new TreeMap<>();

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    public PointPool(String id) {
        if (StringUtils.isEmpty(id)) {
            throw new SystemException("the pool id is empty", ResultCodeMapper.PARAM_ERROR);
        }
        //为了节省空间，积分池的id绑定的就是loyaltyId
        this.id = id;
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    @Override
    public boolean sameIdentityAs(PointPool other) {
        return other != null && id.equals(other.id);
    }

    @Data
    @NoArgsConstructor
    public static class Item {
        //积分，考虑到数据的大小问题，只用最简单的表示方式
        private int p;
        //订单数量
        private int oc;

        public Item(int point, int orderCount) {
            this.p = point;
            this.oc = orderCount;
        }

        public void addOrderCount(int orderCount) {
            this.oc += Math.abs(orderCount);
        }

        public void deductOrderCount(int orderCount) {
            this.oc -= Math.abs(orderCount);
        }

        public void addPoint(int point) {
            this.p += Math.abs(point);
        }

        public void deductPoint(int point) {
            this.p -= point;
        }

        public Item add(int point, int orderCount) {
            addPoint(point);
            addOrderCount(orderCount);
            return this;
        }

        public Item deduct(int point, int orderCount) {
            deductPoint(point);
            deductOrderCount(orderCount);
            return this;
        }
    }

    public void addInPool(int point, LocalDate expiredDate, int orderCount) {
        if (point < 0 || expiredDate == null) {
            return;
        }
        this.availablePointPool.computeIfPresent(expiredDate, (k, item) -> item.add(point, orderCount));
        this.availablePointPool.putIfAbsent(expiredDate, new Item(point, orderCount));
        this.updatedTime = LocalDateTime.now();
    }

    public void deductInPool(int point, LocalDate expiredDate, int orderCount, boolean orderDelay) {
        if (point <= 0) {
            return;
        }
        Iterator<Map.Entry<LocalDate, Item>> iterator = availablePointPool.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<LocalDate, Item> entry = iterator.next();
            LocalDate key = entry.getKey();
            Item item = entry.getValue();
            if (expiredDate != null && key.isBefore(expiredDate)) {
                continue;
            }
            int availablePoint = item.getP();
            if (availablePoint > point) {
                item.deduct(point, orderCount);
                break;
            }
            item.deduct(availablePoint, orderCount);
            if (!orderDelay || item.getOc() <= 0) {
                iterator.remove();
            }
            point -= availablePoint;
            orderCount = 0;
        }
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 订单延迟过期暂时不做处理
     * 针对过期时间小于当前问题：service 添加告警或作其它处理
     */
    public void updateAboutExpired(SubAccount subAccount, boolean orderDelay) {
        if (availablePointPool.size() == 0) {
            subAccount.updateAboutExpired(0, null);
            return;
        }
        Iterator<Map.Entry<LocalDate, Item>> iterator = availablePointPool.entrySet().iterator();
        if (!orderDelay) {
            updateAboutForNoOrderDelay(subAccount, iterator);
        }

    }

    private void updateAboutForNoOrderDelay(SubAccount subAccount, Iterator<Map.Entry<LocalDate, Item>> iterator) {
        while (iterator.hasNext()) {
            Map.Entry<LocalDate, Item> entry = iterator.next();
            LocalDate key = entry.getKey();
            Item item = entry.getValue();
            if (item.getP() > 0) {
                log.info("update about expired:{},{}", item.getP(), key);
                subAccount.updateAboutExpired(item.getP(), key);
            }
        }
    }

}
