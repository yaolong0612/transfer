package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusProperties.Client;
import cn.com.pg.loyalty.interfaces.message.AbstractConsumerV2;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.microsoft.azure.servicebus.*;
import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Getter
@Configuration
@ConfigurationProperties(prefix = "servicebus")
public class ServiceBusConfigRefactor {

    private Map<String, ServiceBusProperties> accounts = new HashMap<>();

    public static final String CURRENT_THREAD_EXCEPTION = "current thread throw exception, message is: {}";

    private static final EnumMap<ServiceBusBinder, ServiceBusClientProperties> clientMap = new EnumMap<>(ServiceBusBinder.class);

    private static final EnumMap<ServiceBusBinder, Object> consumers = new EnumMap<>(ServiceBusBinder.class);

    private static final EnumMap<ServiceBusBinder, Object> senders = new EnumMap<>(ServiceBusBinder.class);

    private Map<String, Integer> retryTimesMap = new HashMap<>(60);

    @Autowired
    private ApplicationContext context;


    /**
     * 初始化
     * Exception
     */
    @PostConstruct
    public void init() {
        log.info("init service bus... ");
        filterConsumerAndSender();
        createClients();
        registerMessageHandler();
        log.info("service bus is ok!");
    }

    public void filterConsumerAndSender() {
        Map<ServiceBusBinder, AbstractConsumerV2> consumerMap = context.getBeansOfType(AbstractConsumerV2.class)
                .entrySet().stream().collect(Collectors.toMap(item -> getServiceBusBinderByConsumer(item.getValue()), Map.Entry::getValue));
        accounts.forEach((channel, account) -> filterConsumerAndSender(account, consumerMap));
    }

    private ServiceBusBinder getServiceBusBinderByConsumer(AbstractConsumerV2 consumer) {
        ServiceBusBinder serviceBusBinder;
        try {
            Class<? extends AbstractConsumerV2> consumerClazz = consumer.getClass();
            Method getQueueSubscribeEnumMethod = consumerClazz.getDeclaredMethod("getServiceBusBinder");
            getQueueSubscribeEnumMethod.setAccessible(true);
            serviceBusBinder = (ServiceBusBinder) getQueueSubscribeEnumMethod.invoke(consumer);
        } catch (Exception e) {
            log.error("getServiceBusBinder error : {}", ExceptionUtil.getStackTraceErrorMessage(e));
            throw new SystemException("getServiceBusBinder error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return serviceBusBinder;
    }


    private void filterConsumerAndSender(ServiceBusProperties account, Map<ServiceBusBinder, AbstractConsumerV2> consumerMap) {
        if (account.getSender() != null) {
            account.getSender().forEach((key, consumer) -> fillSenderAndConsumer(account, consumer, senders, consumerMap));
        }
        if (account.getConsumer() != null) {
            List<Client> accountConsumers = filterConfigConsumersWithHandler(account, consumerMap);
            accountConsumers.forEach(consumer -> fillSenderAndConsumer(account, consumer, consumers, consumerMap));
        }
    }

    private List<Client> filterConfigConsumersWithHandler(ServiceBusProperties account, Map<ServiceBusBinder, AbstractConsumerV2> consumerMap) {
        List<Client> accountConsumers = new ArrayList<>();
        Collection<Client> configConsumers = account.getConsumer().values();
        Map<ServiceBusBinder, Client> collect = configConsumers.parallelStream().collect(Collectors.toMap(Client::getBinging, Function.identity()));
        consumerMap.keySet().forEach(serviceBusBinder -> {
            if (!collect.containsKey(serviceBusBinder)) {
                throw new SystemException("Exist bus consumer not config " + serviceBusBinder, ResultCodeMapper.PARAM_ERROR);
            }
            accountConsumers.add(collect.get(serviceBusBinder));
        });
        return accountConsumers;
    }

    private void fillSenderAndConsumer(ServiceBusProperties account, ServiceBusProperties.Client consumer, Map<ServiceBusBinder, Object> consumers, Map<ServiceBusBinder, AbstractConsumerV2> consumerMap) {
        if (consumer.getBinging() == null) {
            throw new SystemException("your service bus properties dont have binging", ResultCodeMapper.PARAM_ERROR);
        }
        ServiceBusBinder serviceBusBinder = consumer.getBinging();
        ServiceBusClientProperties serviceBusClientProperties = new ServiceBusClientProperties();
        BeanUtils.copyProperties(consumer, serviceBusClientProperties);
        serviceBusClientProperties.setConnectionString(account.getConnectionString());
        serviceBusClientProperties.setGeneralLabel(account.getGeneralLabel());
        serviceBusClientProperties.setUser(consumerMap.get(serviceBusBinder));
        consumers.put(serviceBusBinder, serviceBusClientProperties);
    }

    private void createClients() {
        createClientsByParams(senders);
        createClientsByParams(consumers);
    }

    public void createClientsByParams(Map<ServiceBusBinder, Object> params) {
        params.forEach((serviceBusBinder, o) -> {
            ServiceBusClientProperties client = (ServiceBusClientProperties) o;
            String type = client.getType().name();
            switch (type) {
                case "QUEUE":
                    createQueueClients(serviceBusBinder, client);
                    break;
                case "TOPIC":
                    createTopicClient(serviceBusBinder, client);
                    break;
                case "SUBSCRIBE":
                    createTopicSubscription(serviceBusBinder, client);
                    break;
                default:
                    throw new SystemException("the properties not right, please check the type", ResultCodeMapper.PARAM_ERROR);
            }
        });
    }

    private void registerMessageHandler() {
        consumers.forEach((key, client) -> {
            ServiceBusClientProperties serviceBusClient = (ServiceBusClientProperties) client;
            try {
                if (serviceBusClient.getUser() instanceof IMessageHandler) {
                    if (ServiceBusBinder.ServiceBusType.SUBSCRIBE.equals(serviceBusClient.getType())) {
                        ((SubscriptionClient) (clientMap.get(key).getClient())).registerMessageHandler(
                                (IMessageHandler) (serviceBusClient.getUser()),
                                createMessageHandlerOptions(serviceBusClient.getConcurrency()),
                                createExecutorService(serviceBusClient.getConcurrency()));
                    } else {
                        ((QueueClient) (clientMap.get(key).getClient())).registerMessageHandler(
                                (IMessageHandler) serviceBusClient.getUser(),
                                createMessageHandlerOptions(serviceBusClient.getConcurrency()),
                                createExecutorService(serviceBusClient.getConcurrency()));
                    }
                }
            } catch (InterruptedException e) {
                log.error(CURRENT_THREAD_EXCEPTION, e.getMessage());
                // Restore interrupted state...
                Thread.currentThread().interrupt();
                throw new SystemException("register message  handler failed", ResultCodeMapper.UNEXPECTED_ERROR);
            } catch (ServiceBusException e) {
                log.error(CURRENT_THREAD_EXCEPTION, e.getMessage());
                throw new SystemException("register message  handler failed", ResultCodeMapper.SERVICE_BUS_ERROR);
            }
        });
    }

    /**
     * 卸载bean对象前关闭client
     * <p>
     * ServiceBusException
     */
    @PreDestroy
    public void closeTheClients() {
        clientMap.forEach((key, client) -> {
            try {
                ICloseable closeableClient = (ICloseable) client.getClient();
                closeableClient.close();
            } catch (Exception e) {
                log.error("close service bus client error, message: {}", e.getMessage());
                throw new SystemException("close service bus client error, message", ResultCodeMapper.SERVICE_BUS_ERROR);
            }
        });
    }

    /**
     * 创建QueueClient
     */
    private QueueClient createQueueClient(String queueName, String connectionString) throws ServiceBusException, InterruptedException {
        ConnectionStringBuilder csb = new ConnectionStringBuilder(connectionString, queueName);
        return new QueueClient(csb, ReceiveMode.PEEKLOCK);
    }

    private void sleepForRetry() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException exception) {
            log.error(CURRENT_THREAD_EXCEPTION, exception.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("thread sleep error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    /**
     * 创建多个client
     *
     * @param binder queue名字
     */
    private void createQueueClients(ServiceBusBinder binder, ServiceBusClientProperties client) {
        String queueNameKey = "QUEUE:" + binder;
        try {
            QueueClient queueClient = createQueueClient(client.getName(), client.getConnectionString());
            client.setClient(queueClient);
            clientMap.put(binder, client);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(queueNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建QueueClient {} 失败：{}", client.getName(), e.getMessage());
                throw new SystemException("create queue client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create queue client fail, retry more times");
            createQueueClients(binder, client);
        }
    }

    public boolean canRetry(String queueNameKey) {
        if (retryTimesMap.get(queueNameKey) == null) {
            retryTimesMap.put(queueNameKey, 0);
        } else {
            retryTimesMap.put(queueNameKey, retryTimesMap.get(queueNameKey) + 1);
        }
        return (retryTimesMap.get(queueNameKey) == null ? 0 : retryTimesMap.get(queueNameKey)) < 2;
    }

    public ExecutorService createExecutorService(int size) {
        return new ThreadPoolExecutor(0, size, 5L,
                TimeUnit.MINUTES, new LinkedBlockingQueue<>(), new ThreadFactoryBuilder().setNameFormat("consumer-%d").build());
    }

    public MessageHandlerOptions createMessageHandlerOptions(int size) {
        return new MessageHandlerOptions(size, false, Duration.ofMinutes(1));
    }

    public ServiceBusClientProperties getClientByName(ServiceBusBinder binder) {
        if (!clientMap.containsKey(binder)) {
            log.warn("Queue: {} is not exist", binder);
            throw new SystemException("Queue is not Exist", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return clientMap.get(binder);
    }

    private void createTopicClient(ServiceBusBinder binder, ServiceBusClientProperties client) {
        String topicNameKey = "TOPIC:" + binder;
        try {
            TopicClient topicClient = new TopicClient(new ConnectionStringBuilder(client.getConnectionString(), client.getName()));
            client.setClient(topicClient);
            clientMap.put(binder, client);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(topicNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建topicClient {} 失败：{}", client.getName(), e.getMessage());
                throw new SystemException("topic queue client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create topic client :{} fail, retry more times", client.getName());
            createTopicClient(binder, client);
        }
    }

    /**
     * @param binder 绑定的订阅
     * @param client service client
     */
    private void createTopicSubscription(ServiceBusBinder binder, ServiceBusClientProperties client) {
        String topicNameKey = "SUBSCRIPTION:" + binder;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(client.getTopic().toLowerCase()).append("/subscriptions/").append(client.getName());
            SubscriptionClient subscriptionClient = new SubscriptionClient(new ConnectionStringBuilder(client.getConnectionString(), sb.toString()), ReceiveMode.PEEKLOCK);
            client.setClient(subscriptionClient);
            clientMap.put(binder, client);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(topicNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建subscriptionClient {} 失败：{}", client.getName(), e.getMessage());
                throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create subscription consumer fail, retry more times");
            createTopicSubscription(binder, client);
        }
    }

    public static ServiceBusClientProperties fetchClient(ServiceBusBinder busBinder) {
        return clientMap.get(busBinder);
    }

}
