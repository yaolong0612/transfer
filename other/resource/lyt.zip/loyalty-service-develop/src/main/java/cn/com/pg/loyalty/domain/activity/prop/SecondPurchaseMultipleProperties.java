package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-05 18:13
 */

@Getter
@Setter
public class SecondPurchaseMultipleProperties extends RuleProperties {

    /**
     * 是否参与竞争
     */
    private boolean competition;
    /**
     * 默认距离第一次购买4M之内
     */
    @Min(0)
    private int monthsInPeriod;
    /**
     * 默认赠送积分上限2000
     */
    @Min(0)
    private int maximumBonusPoints;
    /**
     * 默认赠送积分倍数 2-1倍基础积分
     */
    @Min(0)
    private int bonusPointMultiple;

}
