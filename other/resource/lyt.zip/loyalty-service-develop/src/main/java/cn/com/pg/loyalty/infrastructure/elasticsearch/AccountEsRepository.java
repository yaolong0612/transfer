package cn.com.pg.loyalty.infrastructure.elasticsearch;


import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Slf4j
@Repository
public class  AccountEsRepository {
    @Autowired
    private EsTemplate esTemplate;

    @KpiLog(name = "ESClient-fetchAccountAttr", type = KpiLog.KpiType.ES, onlyFailure = true, timeout =
            50)
    public List<Account> fetchAccountAttr(LoyaltyStructure loyaltyStructure, List<String> memberIdList) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        boolQueryBuilder.filter(QueryBuilders.termQuery("marketingProgramId", loyaltyStructure.marketingProgramId()))
                .filter(QueryBuilders.termsQuery("memberId", memberIdList));
        PageableResult<Account> pageableResult = esTemplate.pageQuery("account", boolQueryBuilder, 1, 100,
                Account.class);
        return pageableResult.getRecords();
    }
}
