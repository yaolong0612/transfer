package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.shared.ValueObject;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;

/***
 *@author simonMeng
 *@version 1.0
 *@Date 2019/5/5 19:04
 */
@Getter
@Setter
@Slf4j
@EqualsAndHashCode
@NoArgsConstructor
public class RedemptionItem implements ValueObject<RedemptionItem> {
    /**
     * 礼包库存数量
     */
    private Integer stock;
    /**
     * 礼品包被兑换的数量
     */
    private Integer issuedNum;
    /***
     * 礼包ID
     */
    private String giftId;

    /**
     * 这个礼品限制兑换多少件
     */
    private int limitQuantity;

    /**
     * 兑换一个礼品需要所少积分，ml pampers兑换成长值
     */
    private int point;

    /**
     * ml pamper礼品兑换积分
     */
    private Integer transitPoint;

    /**
     * 兑换礼品需要达到的最低等级。
     */
    private String tierLevel;

    /**
     * 发货的物流礼品ID，添加活动的ID一起添加
     */
    private String logisticsGiftId;

    /**
     * 兑换活动中gifts 增加(freight)运费字段
     */
    private Double freight;

    /**
     * 返回giftList给前端时按priority降序排序
     */
    private Integer priority;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime startAt;

    /**
     * 结束时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime endAt;

    private String groupName;

    private String gradeName;

    @Override
    public boolean sameValueAs(RedemptionItem other) {
        return this.equals(other);
    }

    public RedemptionItem(int stock, String giftId, int limitQuantity,
                          int point, int transitPoint, String tierLevel, String logisticsGiftId,
                          double freight, int priority, LocalDateTime startAt, LocalDateTime endAt) {
        this.stock = stock;
        this.issuedNum = 0;
        /*
         * 礼品排序值
         */
        this.priority = priority;
        this.giftId = giftId;
        this.limitQuantity = limitQuantity;
        this.point = point;
        this.transitPoint = transitPoint;
        this.tierLevel = tierLevel;
        this.logisticsGiftId = logisticsGiftId;
        this.freight = freight;
        this.startAt = startAt;
        this.endAt = endAt;
        checkParams();
    }

    public void configGroup(String groupName) {
        this.groupName = groupName;
    }

    private void checkParams() {
        if (freight == null) {
            return;
        }
        if (freight != 0 && freight / 100 < 1) {
            throw new SystemException("Freight pattern error: must 0 or ge 100", ResultCodeMapper.PARAM_ERROR);
        }
        if (!startAt.isBefore(endAt)) {
            throw new SystemException("start time is before end time", ResultCodeMapper.PARAM_ERROR);
        }

    }

    public void addStock(int stock) {
        this.stock += stock;
    }

    public void updateStock(Integer stock) {
        int tempStock = this.stock + stock;
        if (0 != this.issuedNum && this.issuedNum > tempStock) {
            throw new SystemException("修改的库存不能少于已兑换数量！请检查！", ResultCodeMapper.GIFT_UPDATE_STOCK_ERROR);
        }
        this.stock = tempStock;
    }

    public int availableStock() {
        int availableStock = this.stock - this.issuedNum;
        return Math.max(availableStock, 0);
    }

    public boolean availablePeriod() {
        return !LocalDateTime.now().isBefore(startAt) && !LocalDateTime.now().isAfter(endAt);
    }

    public String logisticsGiftId() {
        return this.logisticsGiftId;
    }

    /**
     * 根据ruleProperties的RuleLable返回对应 组名或挡位名
     * @param ruleLable
     * @return 组名或挡位名
     */
    public String getNameWithLable(RuleLable ruleLable){
        if(RuleLable.GROUP.equals(ruleLable)){
            return this.groupName;
        }
        if(RuleLable.GRADE.equals(ruleLable)){
            return this.groupName.concat("-").concat(this.gradeName);
        }
        return null;
    }
}
