package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.domain.structure.BrandV2.OLAY;

@Rule(name = "after limit rule of order", priority = Integer.MAX_VALUE,
        description = "calculate the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class OrderSettlePointRule {

    private static final String OLAY_SBD_FLAG = "SBD";

    @Condition
    public boolean matchRule() {
        return true;
    }

    @Action
    public void addPoint(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                         @Fact(RuleParamNameConfig.RULE_PARAM_POINT_TYPE) PointType pointType,
                         @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activities,
                         @Fact(RuleParamNameConfig.RULE_PARAM_BRAND_STR) String brand,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult
    ) {

        if (OLAY.equals(brand)) {
            //目前只有olay有所谓的SBD订单加积分活动需要与SBD兑换活动联动
            List<String> sbdActivityIds = filterSBDActivity(activities);
            //竞争逻辑
            order.calculateCompetePointForOlay(competePointItems, pointType, sbdActivityIds);
        } else {
            //竞争逻辑
            order.calculateCompetePoint(competePointItems, pointType);
        }
        ruleResult.success();

    }

    private List<String> filterSBDActivity(List<Activity> onlineHolidayActivities) {
        return onlineHolidayActivities.stream()
                .filter(activity -> activity.getActivityName().contains(OLAY_SBD_FLAG))
                .map(Activity::getId).collect(Collectors.toList());
    }


}
