package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.activity.prop.BaseTierProperties;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
@Slf4j
public class TierRuleCalculator<T extends Transaction> {
    private final Tier tier;
    private T transaction;
    private T lastTransaction;
    private final BaseTierProperties baseTierProperties;
    private final TierLevelSeries tierLevelSeries;

    protected TierRuleCalculator(Tier tier, BaseTierProperties baseTierProperties, TierLevelSeries tierLevelSeries) {
        this.tier = tier;
        this.baseTierProperties = baseTierProperties;
        this.tierLevelSeries = tierLevelSeries;
    }

    protected boolean matchTransaction(Transaction transaction, Class<T> clazz) {
        try {
            this.transaction = clazz.cast(transaction);
            return true;
        } catch (ClassCastException e) {
            log.error("rule catch exception:",e);
            return false;
        }
    }

    public LocalDateTime fetchUpgradeTime() {
        return Optional.ofNullable(lastTransaction).map(Transaction::getCreatedTime)
                .orElse(LocalDateTime.now());
    }


    public String calculateLevel(FetchCountItemAble<T> fetchCountItemAble,
                                    CountTierScoreAble<T> countTierScoreAble,
                                    Function<T, LocalDateTime> timeFunction,
                                    Predicate<T> transactionFilterPredicate) {
        int score = calculateScore(fetchCountItemAble, countTierScoreAble, timeFunction, transactionFilterPredicate);
        return baseTierProperties.getTierLevels().calculateTier(score, tierLevelSeries);
    }

    private int calculateScore(FetchCountItemAble<T> fetchCountItemAble,
                               CountTierScoreAble<T> countTierScoreAble,
                               Function<T, LocalDateTime> timeFunction,
                               Predicate<T> predicate) {
        TierScoreCountScope defaultScope = getTierScoreDefaultFuzzyScope();
        List<T> countItems = fetchCountTransactions(fetchCountItemAble, defaultScope);
        lastTransaction = countItems.stream().max(Comparator.comparing(timeFunction)).orElse(null);
        TierScoreCountScope calculateScope = calculateTierScoreCountScope(timeFunction);
        countItems = countItems.stream()
                .filter(predicate)
                .filter(item -> calculateScope.inScope(timeFunction.apply(item)))
                .collect(Collectors.toList());
        return countTierScoreAble.count(countItems);
    }

    private List<T> fetchCountTransactions(FetchCountItemAble<T> fetchCountItemAble, TierScoreCountScope defaultScope) {
        List<T> countItems = fetchCountItemAble.fetch(defaultScope);
        if (transaction == null) {
            return countItems;
        }
        countItems = countItems.parallelStream()
                .filter(item -> !item.getId().equals(transaction.getId()))
                .collect(Collectors.toList());
        countItems.add(transaction);
        return countItems;
    }


    @Getter
    public static class TierScoreCountScope {
        LocalDateTime startAt;
        LocalDateTime endAt;

        public TierScoreCountScope(LocalDateTime startAt, LocalDateTime endAt, LocalDateTime minStartTime) {
            this.endAt = endAt;
            this.startAt = startAt;
            if (minStartTime != null && startAt.isBefore(minStartTime)) {
                this.startAt = minStartTime;
            }
        }

        public boolean inScope(LocalDateTime time) {
            return time.isAfter(startAt) && !time.isAfter(endAt);
        }

    }


    private TierScoreCountScope getTierScoreDefaultFuzzyScope() {
        LocalDateTime endTime = LocalDateTime.now();
        //在过期范围内往前1年
        LocalDateTime minStartTime = baseTierProperties.getMinCountStartTime();
        LocalDateTime startTime = baseTierProperties.getCountStartTime(endTime, tier.getUpgradedTime()).minusYears(1);
        return new TierScoreCountScope(startTime, endTime, minStartTime);
    }

    /**
     * 计算统计时间范围
     */
    private TierScoreCountScope calculateTierScoreCountScope(Function<T, LocalDateTime> timeFunction) {

        LocalDateTime lastTransactionTime = Optional.ofNullable(lastTransaction).map(timeFunction).orElse(null);
        LocalDateTime endTime = calculateScopeEndTime(lastTransactionTime);
        LocalDateTime minStartTime = baseTierProperties.getMinCountStartTime();
        LocalDateTime startTime = baseTierProperties.getCountStartTime(endTime, tier.getUpgradedTime());
        return new TierScoreCountScope(startTime, endTime, minStartTime);
    }

    private LocalDateTime calculateScopeEndTime(LocalDateTime lastTransactionTime) {
        LocalDateTime calculateTime = LocalDateTime.of(LocalDate.now(), LocalTime.MIN);
        LocalDate tierExpireDate = tier.getExpiredTime().toLocalDate();
        if (lastTransactionTime == null) {
            return calculateTime;
        }
        if (lastTransactionTime.plusYears(tierLevelSeries.getTierEffectiveYear())
                .isBefore(LocalDateTime.now())) {
            return calculateTime;
        }

        if (tierExpireDate.isBefore(lastTransactionTime.toLocalDate())) {
            return lastTransactionTime;
        }

        if (tierExpireDate.isBefore(LocalDate.now())) {
            return calculateTime;
        }

        return lastTransactionTime;
    }

    public interface CountTierScoreAble<T extends Transaction> {
        int count(List<T> countItems);
    }

    public interface FetchCountItemAble<T extends Transaction> {
        List<T> fetch(TierScoreCountScope scope);
    }

}
