package cn.com.pg.loyalty.domain.transaction;


import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import org.apache.commons.lang3.EnumUtils;

/**
 * @author: Ysnow
 * @Date: 2019/7/1 15:24
 * @Description:
 */
public class GiftItem {
    private String giftId;
    private String giftName;
    private Integer point;
    private Integer quantity;
    private GiftStatus giftStatus;
    private String description;

    public GiftItem() {
        this.giftStatus = GiftStatus.NOT_RECEIVED;
    }

    public GiftItem(String giftId, String giftName, Integer point, Integer quantity, GiftStatus giftStatus, String description) {
        this.giftId = giftId;
        this.giftName = giftName;
        this.point = point;
        this.quantity = quantity;
        this.giftStatus = giftStatus;
        this.description = description;
    }

    public void updateByGift(Gift gift) {
        this.giftName = gift.getName();
        this.description = gift.getDescription();
    }

    public void updatePoint(int point) {
        this.point = point;
    }

    public String getGiftId() {
        return giftId;
    }

    public void setGiftId(String giftId) {
        this.giftId = giftId;
    }

    public String getGiftName() {
        return giftName;
    }

    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public GiftStatus getGiftStatus() {
        return giftStatus;
    }

    public void setGiftStatus(GiftStatus giftStatus) {
        this.giftStatus = giftStatus;
    }

    public enum GiftStatus {
        NOT_RECEIVED(true, true, true),
        RECEIVED(true, true, false),
        CANCELED(false, false, false),
        REJECTED(false, false, false),
        EXPIRED(false, false, false);

        private boolean allowCancel;
        private boolean allowReject;
        private boolean allowExpire;

        GiftStatus(boolean allowCancel, boolean allowReject, boolean allowExpire) {
            this.allowCancel = allowCancel;
            this.allowReject = allowReject;
            this.allowExpire = allowExpire;
        }

        public boolean isAllowCancel() {
            return allowCancel;
        }

        public boolean isAllowReject() {
            return allowReject;
        }

        public boolean isAllowExpire() {
            return allowExpire;
        }
    }

    //校验该礼品是否允许做：拒绝、取消、过期操作
    public void validateAllowChangeTo(GiftStatus newGiftStatus) {
        if (!allowChangeTo(newGiftStatus)) {
            throw new SystemException(
                    "The Gift " + this.giftId + " was " + this.giftStatus.name().toLowerCase()
                            + ",can't " + newGiftStatus.name().toLowerCase() + ".", ResultCodeMapper.PARAM_ERROR);
        }
    }

    //校验该礼品是否允许做：拒绝、取消、过期操作
    public boolean allowChangeTo(GiftStatus newGiftStatus) {
        if (newGiftStatus == GiftStatus.CANCELED) {
            return this.giftStatus.isAllowCancel();
        }
        if (newGiftStatus == GiftStatus.REJECTED) {
            return this.giftStatus.isAllowReject();
        }
        if (newGiftStatus == GiftStatus.EXPIRED) {
            return this.giftStatus.isAllowExpire();
        }
        return false;
    }

    public void receiveGift() {
        if (this.giftStatus != GiftStatus.NOT_RECEIVED) {
            throw new SystemException("This Gift has been received or cancelled, can not pickup again.", ResultCodeMapper.PARAM_ERROR);
        }
        this.giftStatus = GiftStatus.RECEIVED;
    }

    public boolean received() {
        return this.giftStatus.equals(GiftStatus.RECEIVED);
    }

    public boolean unReceived() {
        return this.giftStatus.equals(GiftStatus.NOT_RECEIVED);
    }

    public boolean canceled() {
        return GiftStatus.CANCELED.equals(this.giftStatus);
    }

    public boolean rejected() {
        return GiftStatus.REJECTED.equals(giftStatus);
    }

    public boolean expired() {
        return this.giftStatus.equals(GiftStatus.EXPIRED);
    }

    public boolean finished() {
        return !this.giftStatus.equals(GiftStatus.NOT_RECEIVED);
    }

    public String getDescription() {
        return description;
    }

    /**
     * 只有未收货的礼品，才可以取消兑换
     *
     * @return
     */
    public boolean cancelable() {
        return this.giftStatus == GiftStatus.NOT_RECEIVED;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean effective() {
        return GiftStatus.NOT_RECEIVED == giftStatus || GiftStatus.RECEIVED == giftStatus;
    }
}
