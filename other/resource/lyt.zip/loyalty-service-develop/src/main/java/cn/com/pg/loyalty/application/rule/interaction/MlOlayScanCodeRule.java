package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;

import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @author: Ysnow
 * @Date: 2019/5/30 14:30
 * @Description:
 */
@Rule(name = "Interaction rule: Olay sweep rule",
        description = "When consumers buy goods, they can scan the qr code inside the goods and add credits")
@Slf4j
public class MlOlayScanCodeRule {

    /**
     * 扫码加积分的分布式锁，这里是基本的条件，
     * 实际用的时候还分拼接上qrCode，保证qrCode重复的，请求会被阻塞。
     * 扫码成功后，分布式锁并不会马上删除，而是让它自动过期。
     */
    private static final String SCAN_CODE_ACCOUNT_KEY = "SCANCODE:QRCODE:";
    private static final String SCAN_CODE_DISTRIBUTED_LOCK_VALUE = "TRUE";
    /**
     * 保存这个CODE 2秒
     */
    private static final int CODE_SLEEP_TIME = 2;



    @Condition
    public boolean isMLOlayScanCode(@Fact("pointType") PointType pointType,
                                    @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        return Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType.pointType())
                && loyaltyStructure.checkMlBrand(BrandV2.OLAY);
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activityList, @Fact("interaction") Interaction interaction,
                         @Fact("qrCode") String qrCode,
                         @Fact("sku") String sku,
                         @Fact("newMember")Boolean newMember,
                         @Fact("account") Account account,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("stringRedisTemplate") StringRedisTemplate stringRedisTemplate,
                         @Fact("pointType") PointType pointType,
                         @Fact("cacheService") CacheService cacheService) {
        // 校验参数是由有异常 是则返回 异常会放进ruleResult 然后抛出
        try {
            checkParamHasError(stringRedisTemplate, qrCode, sku, activityList, pointType, cacheService);
        } catch (SystemException se) {
            ruleResult.addException(se);
            return;
        }
        Activity activity = activityList.get(0);
        Optional<QrcodeItem> optionalSku = activity.qrcodeItems().
                stream().filter(qrcodeItem -> qrcodeItem.getSku().equals(sku)).findFirst();
        QrcodeItem scanCodeSku = optionalSku.isPresent() ? optionalSku.get() : null;
        if (scanCodeSku == null) {
            ruleResult.addException(new SystemException("sku has not been configured in the configuration of activities: " + sku, ResultCodeMapper.SCAN_CODE_SKU_INEXIST));
            return;
        }
        int addPoint;
        //老会员扫WHIPS类型的码加双倍积分
        if (!newMember && scanCodeSku.productTypeIsThisType(QrcodeItem.ProductTypeEnum.WHIPS)) {
            addPoint = scanCodeSku.basePoint() * 2;
        } else {
            addPoint = scanCodeSku.basePoint();
        }
        log.info("是否新会员: {}, 扫码基础分：{}, 总加积分：{}", newMember, scanCodeSku.basePoint(), addPoint);
        interaction.scanCode(activity, addPoint, qrCode, sku, pointType);
        //设置规则引擎执行成功标志
        ruleResult.success();
    }

    private void checkParamHasError(StringRedisTemplate stringRedisTemplate, String qrCode, String sku, List<Activity> activities, PointType pointType, CacheService cacheService) {
        if (activities == null || activities.size() == 0) {
            throw new SystemException("Can't find the scan QR code and earn bonus points activity of OLAY, qrCode:"+ qrCode +",sku:"+ sku, ResultCodeMapper.NOT_AVAILABLE_ACTIVITY);
        }
        if (StringUtils.isBlank(qrCode) || StringUtils.isBlank(sku)) {
            throw new SystemException("qrCode or sku is null,qrCode:"+qrCode+",sku:"+sku, ResultCodeMapper.PARAM_ERROR);
        }
        //锁定这个码，防止多个人同时进行扫码操作
        String qrCodeLockKey = SCAN_CODE_ACCOUNT_KEY.concat(qrCode);
        if (!stringRedisTemplate.opsForValue().setIfAbsent(qrCodeLockKey, SCAN_CODE_DISTRIBUTED_LOCK_VALUE, CODE_SLEEP_TIME, TimeUnit.SECONDS)) {
            throw new SystemException("Scanning QR code too frequently:" + qrCode + ",retry after a while please", ResultCodeMapper.SCAN_CODE_TOO_FAST);
        }
        // 判断qrcode是否90天内是否扫过
        cacheService.checkQrCode(pointType.getLoyaltyStructure(), qrCode);
    }
}
