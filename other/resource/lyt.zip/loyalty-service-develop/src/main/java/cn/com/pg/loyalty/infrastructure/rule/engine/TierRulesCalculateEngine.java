package cn.com.pg.loyalty.infrastructure.rule.engine;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.account.TierRulesCalculateAble;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 等级计算规则引擎实现
 */
@Component
public class TierRulesCalculateEngine implements TierRulesCalculateAble {

    @Autowired
    private MessageService messageService;
    @Autowired
    private AccountRepositoryV2 accountRepository;
    @Autowired
    private CacheService cacheService;

    @Override
    public void calculateTiersRule(TierChangeScene tierChangeScene) {
        List<Activity> availableActivities = cacheService.fetchUniquePointTypeAvailableActivities(
                TransactionType.TIER, tierChangeScene.getStructure().name(), LocalDateTime.now());
        getRuleEngineSupportV2()
                .addFact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE, tierChangeScene)
                .addFact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES, availableActivities)
                .addFact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE, tierChangeScene.getStructure())
                .addFact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT, new RuleResult())
                .calculateTier();
        tierChangeScene.getAccount().backupCurrentLevel(tierChangeScene.getStructure());
        tierChangeScene.calculateFinalTier();
    }

    @Override
    public void calculateAwardPoint(TierChangeScene tierChangeScene) {
        Account account = tierChangeScene.getAccount();
        LoyaltyStructure structure = tierChangeScene.getStructure();
        int tierAwardPoint = tierChangeScene.calculateTierAwardPoint();
        if (account.tier(structure.name()).getBackupLevel() != null) {
            account.clearBackupLevel(structure);
            accountRepository.save(account);
        }
        if (tierAwardPoint != 0) {
            InteractionMessage message = InteractionMessage.createTierAwardMessage(structure,
                    account.memberId(), tierAwardPoint, LocalDateTime.now());
            messageService.sendMessageForAddInteractionPoint(message, 1);
        }
    }

    @Lookup
    public RuleEngineSupportV2 getRuleEngineSupportV2() {
        //多例模式的使用方法，带有LookUp注解，在使用的时候会去getBean操作，从而实现多例效果
        return null;
    }
}
