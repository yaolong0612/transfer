package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.*;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

import java.util.List;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

@Component
@Rule(name = "ExecuteGroupRule", description = "执行RuleLabel为Group的规则", priority = Integer.MAX_VALUE)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION,
        ruleLables = {RuleLable.REDMPTION, RuleLable.GROUP, RuleLable.GRADE})
public class RunNextRuleWithLabel {

    @Condition
    public boolean matchRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties) {
        return properties.fetchNext() != null;
    }

    @Action
    public void runRulesWithLabel(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                                  @Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
                                  @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                                  @Fact(RULE_PARAM_ACTIVITY) Activity activity,
                                  @Fact(RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords) {
        getRuleEngineSupportV2()
                .addFact(RULE_PARAM_REDEMPTION_PROPERTIES, properties.fetchNext())
                .addFact(RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(RULE_PARAM_NAME_REDEMPTION, redemption)
                .addFact(RULE_PARAM_ACTIVITY, activity)
                .addFact(RULE_PARAM_REDEMPTION_RECORDS, redemptionRecords)
                .calculateLabelRule(properties.fetchNext().fetchLable(), RuleType.REDEMPTION);
    }

    @Lookup
    public RuleEngineSupportV2 getRuleEngineSupportV2() {
        return null;
    }
}
