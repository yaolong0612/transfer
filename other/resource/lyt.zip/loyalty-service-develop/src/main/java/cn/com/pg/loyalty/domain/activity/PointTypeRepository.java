package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PointTypeRepository extends DocumentDbRepository<PointType, String> {

    List<PointType> findByLoyaltyStructureAndStatus(String loyaltyStructure, PointType.PointTypeStatus status);

    List<PointType> findByPointTypeAndLoyaltyStructure(String pointType,String loyaltyStructure);

    List<PointType> findPointTypeById(String id);

    List<PointType> findByLoyaltyStructureAndStatusAndTransactionType(String loyaltyStructure, PointType.PointTypeStatus status, TransactionType transactionType);
}
