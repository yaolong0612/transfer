package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.ParamValidateService;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.application.dependence.LoyaltyMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum.ServiceBusType;
import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.ServiceBusConfig;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusClientProperties;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.*;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static cn.com.pg.loyalty.application.dependence.ServiceBusTemplate.MSG_REDIS_KEY;

/**
 * @author cooltea on 2019/6/26 17:48.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Slf4j
public abstract class AbstractConsumer implements IMessageHandler {

    @Autowired
    private ServiceBusConfig serviceBusConfig;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private KpiTemplate kpiTemplate;
    private static final String MEDIA_TYPE_TEXT = "text/plain";
    @Value("${serviceBus.generalLabel}")
    private String serviceBusGeneralLabel;

    @Autowired
    private ParamValidateService paramValidateService;

    private static final String MESSAGE_ID_PREFIX = "Q-MID-PRE-";

    private static final List<ResultCodeMapper> NOT_NEED_RETRY_CODES = new ArrayList<>();
    private static final List<ServiceBusQueueTopicEnum> UN_CHECK_LABEL_QUEUE = new ArrayList<>();
    private static final List<ResultCodeMapper> DELAY_RETRY_QUEUE_CODES = new ArrayList<>();

    static {
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.ACCOUNT_REGISTER_FREQUENTLY);
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.ACTIVITY_NOT_FOUND);
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.POINT_TYPE_NOT_FOUND);

        DELAY_RETRY_QUEUE_CODES.add(ResultCodeMapper.OPERATION_TOO_FAST);

        UN_CHECK_LABEL_QUEUE.add(ServiceBusQueueTopicEnum.ASYNC_ENROLL_ACCOUNT_QUEUE); //AM注册账户
    }

    /**
     * Loyalty Service 定义，所有的消息必须是Json格式
     *
     * @param message
     * @return
     */
    @Override
    public CompletableFuture<Void> onMessageAsync(IMessage message) {
        String sourceCorrelationId = message.getCorrelationId();
        RequestContext.createContext(null);
        long startTime = System.currentTimeMillis();
        LocalDateTime startDateTime = LocalDateTime.now();
        String messageId = message.getMessageId();
        log.info("---------Message Staring---------- message Id: {}, Source Correlation Id: {}", messageId, sourceCorrelationId);
        String label = message.getLabel();
        ServiceBusQueueTopicEnum queueEnum = getQueueSubscribeEnum();
        String operationName = queueEnum.queueOrTopicName() + "-onMessageConsumer";
        RequestContext.getCurrentContext().operationName(operationName);
        RequestContext.getCurrentContext().setMessageId(messageId);
        log.info("---Message Start Execute--- Queue Name: {}, Label: {}, MessageId: {}, Queue Type: {}",
                queueEnum.queueOrTopicName(), label, messageId, queueEnum.serviceBusType());
        boolean isConsumable = shouldConsumerMessage(message, queueEnum);
        if (!isConsumable) {
            return abandonMessage(message, queueEnum);
        }
        boolean isSuccess = true;
        int errorCode = ResultCodeMapper.SUCCESS.getCode();
        String errMsg = "";
        try {
            final String messageExecutedVal = "1";
            String messageIdDuplicateVal = stringRedisTemplate.opsForValue().get(MESSAGE_ID_PREFIX.concat(messageId));
            if (messageExecutedVal.equals(messageIdDuplicateVal)) {
                log.info("消息重复: {}", messageId);
                isSuccess = false;
                errorCode = ResultCodeMapper.MESSAGE_DUPLICATED.getCode();
                errMsg = "消息推送重复".concat(messageId);
                return completeMessage(message, queueEnum);
            }
            List<byte[]> binaryData = message.getMessageBody().getBinaryData();
            LoyaltyMessage loyaltyMessage = JSON.parseObject(new String(binaryData.get(0)), LoyaltyMessage.class);
            JSONObject messageBody = getMessageBody(loyaltyMessage, queueEnum);
            if (messageBody == null) {
                log.info("获取到Message Body为空");
                isSuccess = false;
                errorCode = ResultCodeMapper.MESSAGE_EMPTY.getCode();
                errMsg = "Message Body为空";
                //没必要重试
                return completeMessage(message, queueEnum);
            }
            Map<String, String> paramMap = paramValidateService.exactVerifiedParam(messageBody);
            paramValidateService.validate(paramMap);
            this.doBusiness(messageBody);
            stringRedisTemplate.opsForValue().set(MESSAGE_ID_PREFIX.concat(messageId), messageExecutedVal,
                    5L, TimeUnit.MINUTES);
            log.info("消息处理成功");
            return completeMessage(message, queueEnum);
        } catch (SystemException e) {
            ResultCodeMapper codeMapper = e.resultCodeMapper();
            isSuccess = false;
            errMsg = e.getMessage();
            errorCode = codeMapper.getCode();
            log.error("消费队列消息SystemException异常：{}", e.getMessage());
            // 判断抛出的异常是否需要重试
            if (notNeedRetryCode(codeMapper)) {
                log.info("不需要重试，直接结束");
                return completeMessage(message, queueEnum);
            }
            if (needQueueRetryDelay(codeMapper, queueEnum)) {
                log.info("不需要重试，直接结束");
                return delayQueueMessage(message, queueEnum);
            }
        } catch (Exception e) {
            isSuccess = false;
            errMsg = e.getMessage();
            errorCode = ResultCodeMapper.UNEXPECTED_ERROR.getCode();
            log.error("消费队列信息异常: {}", ExceptionUtil.getStackTraceErrorMessage(e));
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            String correlationId = RequestContext.getCurrentContext().getCorrelationId();
            kpiTemplate.sendConsumingMessage(messageId, operationName, startDateTime, costTime, errorCode, errMsg, correlationId);
            log.info("消息处理完成, Result: {}, Cost: {}, MessageId: {}, Name: {}, Code: {}, Msg: {}", isSuccess, costTime,
                    messageId, operationName, errorCode, errMsg);
        }
        CompletableFuture<Void> completableFuture = abandonMessage(message, queueEnum);
        RequestContext.cleanContext();
        return completableFuture;
    }

    private JSONObject getMessageBody(LoyaltyMessage loyaltyMessage, ServiceBusQueueTopicEnum queueEnum) {
        log.info("获取到: {}队列信息: {}", queueEnum.queueOrTopicName(), JSON.toJSONString(loyaltyMessage));
        JSONObject messageBody = loyaltyMessage.getJsonObject();
        if (messageBody == null) {
            log.info("消息体为空");
            return null;
        }
        if (messageBody.containsKey(MSG_REDIS_KEY)) {
            log.info("大消息，从redis中获取");
            String bigMessageRedisKey = messageBody.getString(MSG_REDIS_KEY);
            String bigMessageValue = stringRedisTemplate.opsForValue().get(bigMessageRedisKey);
            if (StringUtils.isEmpty(bigMessageValue)) {
                log.info("big message value is null");
                return null;
            }
            messageBody = JSON.parseObject(bigMessageValue);
        }
        return messageBody;
    }

    /**
     * 完成消息并释放锁
     *
     * @param message
     * @return
     */
    private CompletableFuture<Void> completeMessage(IMessage message, ServiceBusQueueTopicEnum queueEnum) {
        CompletableFuture<Void> completableFuture = null;
        if (ServiceBusQueueTopicEnum.ServiceBusType.SUBSCRIBE.equals(queueEnum.serviceBusType())) {
            SubscriptionClient subscriptionClient = serviceBusConfig.getSubscribeClient(queueEnum);
            completableFuture = subscriptionClient.completeAsync(message.getLockToken());
        } else {
            QueueClient queueClient = serviceBusConfig.getQueueClient(queueEnum);
            completableFuture = queueClient.completeAsync(message.getLockToken());
        }
        log.info("完成消息结束");
        return completableFuture;
    }

    /**
     * 中断消息并释放锁，让其它客户端重新消费
     *
     * @param message
     * @return
     */
    private CompletableFuture<Void> abandonMessage(IMessage message, ServiceBusQueueTopicEnum queueEnum) {
        CompletableFuture<Void> completableFuture = null;
        if (ServiceBusType.SUBSCRIBE.equals(queueEnum.serviceBusType())) {
            SubscriptionClient subscriptionClient = serviceBusConfig.getSubscribeClient(queueEnum);
            completableFuture = subscriptionClient.abandonAsync(message.getLockToken());
        } else {
            QueueClient queueClient = serviceBusConfig.getQueueClient(queueEnum);
            completableFuture = queueClient.abandonAsync(message.getLockToken());
        }
        log.info("中断消息结束");
        return completableFuture;
    }

    private CompletableFuture<Void> delayQueueMessage(IMessage message, ServiceBusQueueTopicEnum queueEnum) {
        CompletableFuture<Void> completableFuture;
        if (ServiceBusType.QUEUE.equals(queueEnum.serviceBusType())) {

            try {
                QueueClient queueClient = serviceBusConfig.getQueueClient(queueEnum);
                message.setScheduledEnqueueTimeUtc(Instant.now().plusSeconds(5));
                queueClient.send(message);
                completableFuture = queueClient.completeAsync(message.getLockToken());
                log.info("完成消息结束");
                return completableFuture;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (ServiceBusException e) {
                return abandonMessage(message, queueEnum);
            }

        }
        throw new SystemException("the service bus consumer properties is not queue, please check it", ResultCodeMapper.SERVICE_BUS_ERROR);
    }

    protected boolean notNeedRetryCode(ResultCodeMapper codeMapper) {
        return NOT_NEED_RETRY_CODES.contains(codeMapper);
    }

    protected boolean needQueueRetryDelay(ResultCodeMapper codeMapper, ServiceBusQueueTopicEnum properties) {
        return DELAY_RETRY_QUEUE_CODES.contains(codeMapper)
                && ServiceBusQueueTopicEnum.ServiceBusType.QUEUE.equals(properties.serviceBusType());
    }

    protected abstract void doBusiness(JSONObject jsonObject);

    protected abstract String getLabel();

    protected abstract ServiceBusQueueTopicEnum getQueueSubscribeEnum();

    @Override
    public void notifyException(Throwable throwable, ExceptionPhase exceptionPhase) {

    }

    /**
     * 判断是否消费该消息
     */
    private boolean shouldConsumerMessage(IMessage message, ServiceBusQueueTopicEnum queueEnum) {

        //由于Function发过来的消息，无法设置Label，content type，如果是这种content type，则认为是function过来的消息。（作为约定）普通消息不允许这种格式
        if (MEDIA_TYPE_TEXT.equalsIgnoreCase(message.getContentType())) {
            log.info("这个地方是从Function过来的！！！！");
            return true;
        }
        // 指定队列不判断label
        if (UN_CHECK_LABEL_QUEUE.contains(queueEnum)) {
            return true;
        }
        //设置这个是为了在本地好测试，每个人的message互不影响，靠label区分。生产环境不存在这样的逻辑
        boolean isThisLabelQueueMsg = Optional.ofNullable(message.getLabel())
                .map(labelQueue -> labelQueue.contentEquals(serviceBusGeneralLabel)).orElse(false);
        if (!isThisLabelQueueMsg) {
            log.info("消息不是本Label的，返回队列让其它Consumer消费");
        }
        return isThisLabelQueueMsg;
    }
}
