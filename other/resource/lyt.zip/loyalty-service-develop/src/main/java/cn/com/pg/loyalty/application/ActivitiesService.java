package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.*;
import cn.com.pg.loyalty.domain.activity.prop.RuleProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.dto.AddRedemptionActivityCommand;
import cn.com.pg.loyalty.interfaces.dto.UpdateRedemptionActivityCommand;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @author Simon
 * @date 2019/4/28 11:50
 * @description
 **/
@Service
@Slf4j
public class ActivitiesService {

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private ActivityLogRepository activityLogRepository;

    @Autowired
    private PointTypeRepository pointTypeRepository;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private Validator validator;


    /**
     * 添加Interaction活动的方法
     */
    public Activity addInteractionActivity(String userName, String activityName, String pointType,
                                           LocalDateTime startAt, LocalDateTime endAt, ActivityStatus status,
                                           String description, String brand, String region, String externalId,
                                           String properties, String remark, Integer priority, String msgTemplate, List<Activity.ActivityDisplayMsg> displayMsgList) {
        checkExternalId(externalId);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.INTERACTION);
        Activity activity = Activity.Builder.interactionBuilder(activityName, structure, brand, description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt)
                .createBy(userName, LocalDateTime.now())
                .status(status)
                .externalId(externalId)
                .msgTemplate(msgTemplate)
                .build();
        activity.addDisplayLanguages(displayMsgList);
        validateRuleProperties(activity);
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        Activity savedActivity = activityRepository.save(activity);
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.ADD, savedActivity);
        return savedActivity;
    }

    /**
     * 添加Order活动的方法
     */
    public Activity addOrderActivity(String userName, String activityName, String pointType, LocalDateTime startAt,
                                     LocalDateTime endAt, ActivityStatus status, String description,
                                     String brand, String region, String externalId, String properties,
                                     String remark, Integer priority, List<Activity.ActivityDisplayMsg> displayMsgList) {
        checkExternalId(externalId);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.ORDER);
        Activity activity = Activity.Builder.orderBuilder(activityName, structure, brand, description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt)
                .createBy(userName, LocalDateTime.now())
                .status(status).externalId(externalId)
                .build();
        activity.addDisplayLanguages(displayMsgList);
        validateRuleProperties(activity);
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        cacheService.clearActivities(TransactionType.ORDER, structure.name());
        cacheService.clearActivitiesV2(TransactionType.ORDER, structure.name());
        Activity savedActivity = activityRepository.save(activity);
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.ADD, savedActivity);
        return savedActivity;
    }


    /**
     * 添加Redemption活动的方法
     */
    public Activity addRedemptionActivity(String userName, AddRedemptionActivityCommand body, List<Activity.ActivityDisplayMsg> displayMsgList) {
        checkExternalId(body.getExternalCode());
        String brand = body.getBrand();
        String region = body.getRegion();
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        PointType pointType = fetchAndCheckPointType(structure, body.getPointType(), TransactionType.REDEMPTION);
        LocalDateTime startAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime endAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());

        Activity activity = Activity.Builder
                .redemptionBuilder(body.getActivityName(), structure, brand, body.getDescription(), body.getRemark())
                .buildRule(pointType, body.getProperties(), body.getPriority())
                .validityTime(startAt, endAt)
                .createBy(userName, LocalDateTime.now())
                .status(ActivityStatus.valueOf(body.getStatus().name()))
                .externalId(body.getExternalCode())
                .msgTemplate(body.getMsgTemplate())
                .build();
        activity.addDisplayLanguages(displayMsgList);
        validateRuleProperties(activity);
        Activity savedActivity = activityRepository.save(activity);
        //初始化issuedNum缓存
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        saveOperationLog(userName, ActivityLog.OperationType.ADD, savedActivity);
        return savedActivity;
    }

    /**
     * 添加Tier活动的方法
     */
    public Activity addTierActivity(String userName, String activityName, String pointType, LocalDateTime startAt,
                                     LocalDateTime endAt, ActivityStatus status, String description,
                                     String brand, String region, String externalId, String properties,
                                     String remark, Integer priority) {
        checkExternalId(externalId);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.TIER);
        Activity activity = Activity.Builder.tierBuilder(activityName, structure, brand, description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt)
                .createBy(userName, LocalDateTime.now())
                .status(status).externalId(externalId)
                .build();
        //activity.addDisplayLanguages(displayMsgList);
        validateRuleProperties(activity);
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        cacheService.clearActivities(TransactionType.TIER, structure.name());
        cacheService.clearActivitiesV2(TransactionType.TIER, structure.name());
        Activity savedActivity = activityRepository.save(activity);
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.ADD, savedActivity);
        return savedActivity;
    }


    /***
     * 添加礼包到现有的Redemption活动中
     */
    public Activity addSingleRedemptionGift(String userName, String activityId, RedemptionItem redemptionItem) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        Gift gift = cacheService.getGiftById(redemptionItem.getGiftId());
        // 添加兑换礼品信息
        activity.addRedemptionItem(gift, redemptionItem, structure);
        Activity updatedActivity = activityRepository.save(activity);
        //移除缓存
        cacheService.removeActivityById(activityId);
        //初始化已兑换数量为0，保存到redis
        cacheService.initIssuedNum(activityId, gift.getId());
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, updatedActivity);
        return updatedActivity;
    }

    public Activity updateSingleRedemptionGift(String userName, String activityId, RedemptionItem redemptionItem) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        Gift gift = cacheService.getGiftById(redemptionItem.getGiftId());
        // 更新兑换礼品信息
        activity.updateRedemptionItem(redemptionItem, structure);
        Activity updatedActivity = activityRepository.save(activity);
        //移除缓存
        cacheService.removeActivityById(activityId);
        //初始化已兑换数量为0，保存到redis
        if (!activity.existGift(redemptionItem.getGiftId())) {
            cacheService.initIssuedNum(activityId, gift.getId());
        }
        cacheService.removeActivityPointType(structure.name(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, updatedActivity);
        return updatedActivity;
    }

    public void deleteActivityById(String userName, String activityId, TransactionType transactionType) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, transactionType);
        //判断是否可删除
        activity.delete();
        //删除activity
        activityRepository.delete(activity);
        //移除缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //移除issuedNum缓存
        if (TransactionType.REDEMPTION.sameValueAs(transactionType)) {
            Map<String, RedemptionItem> gifts = activity.getGifts();
            for (String giftId : gifts.keySet()) {
                cacheService.removeIssuedNum(activityId, giftId);
            }
        }
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.DELETE, activity);
    }

    public void deleteSingleGiftByGiftId(String userName, String activityId, String giftId) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
        int issuedNum = cacheService.getIssuedNum(activityId, giftId);
        activity.deleteRedemptionItem(giftId, issuedNum);
        //保存修改的activity
        activityRepository.save(activity);
        //移除活动缓存
        cacheService.removeActivityById(activityId);
        //移除issuedNum缓存
        cacheService.removeIssuedNum(activityId, giftId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());

        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    /***
     * 修改Activity活动状态
     */
    public void updateActivityStatus(String userName, String activityId, TransactionType transactionType, ActivityStatus activityStatus) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, transactionType);
        if (ActivityStatus.INITIAL.sameValueAs(activityStatus)) {
            activity.end();
        } else {
            activity.activate();
        }
        activityRepository.save(activity);
        //移除缓存
        cacheService.clearActivitiesV2(transactionType,activity.getLoyaltyStructure());
        cacheService.clearActivities(transactionType,activity.getLoyaltyStructure());

        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    /***
     * 更新Interaction Activity信息的方法
     * @param activityId 活动ID
     */
    public void updateInteractionActivityInfo(String userName, String activityId, String activityName, String pointType,
                                              LocalDateTime startAt, LocalDateTime endAt, String description,
                                              ActivityStatus activityStatus, String properties, String remark,
                                              Integer priority, String msgTemplate, List<Activity.ActivityDisplayMsg> activityDisplayMsgList) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.INTERACTION);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.INTERACTION);
        Activity.Builder.interactionBuilder(activityName, structure, activity.getBrand(), description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt)
                .updateBy(userName, LocalDateTime.now())
                .status(activityStatus)
                .msgTemplate(msgTemplate)
                .updateActivity(activity);
        activity.addDisplayLanguages(activityDisplayMsgList);
        validateRuleProperties(activity);
        activityRepository.save(activity);
        //移除缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    /***
     * 更新Order Activity信息的方法
     * @param activityId 活动ID
     */
    public void updateOrderActivityInfo(String userName, String activityId, String activityName, String pointType,
                                        LocalDateTime startAt, LocalDateTime endAt, String description,
                                        ActivityStatus activityStatus, String properties, String remark, Integer priority, List<Activity.ActivityDisplayMsg> activityDisplayMsgList) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.ORDER);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.ORDER);
        Activity.Builder.orderBuilder(activityName, structure, activity.getBrand(), description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt).updateBy(userName, LocalDateTime.now())
                .status(activityStatus).updateActivity(activity);
        activity.addDisplayLanguages(activityDisplayMsgList);
        validateRuleProperties(activity);
        activityRepository.save(activity);
        //移除缓存
        cacheService.clearActivities(activity.getTransactionType(),activity.getLoyaltyStructure());
        cacheService.clearActivitiesV2(activity.getTransactionType(),activity.getLoyaltyStructure());
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    /***
     * 更新Tier Activity信息的方法
     * @param activityId 活动ID
     */
    public void updateTierActivityInfo(String userName, String activityId, String activityName, String pointType,
                                        LocalDateTime startAt, LocalDateTime endAt, String description,
                                        ActivityStatus activityStatus, String properties, String remark, Integer priority) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.TIER);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        PointType pt = fetchAndCheckPointType(structure, pointType, TransactionType.TIER);
        Activity.Builder.tierBuilder(activityName, structure, activity.getBrand(), description, remark)
                .buildRule(pt, properties, priority)
                .validityTime(startAt, endAt).updateBy(userName, LocalDateTime.now())
                .status(activityStatus).updateActivity(activity);
        validateRuleProperties(activity);
        activityRepository.save(activity);
        //移除缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }


    /***
     * 更新Redemption Activity信息的方法
     */
    public void updateRedemptionActivityInfo(String userName, String activityId, UpdateRedemptionActivityCommand body, List<Activity.ActivityDisplayMsg> activityDisplayMsgList) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure());
        PointType pointType = fetchAndCheckPointType(structure, body.getPointType(), TransactionType.REDEMPTION);
        LocalDateTime startAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime endAt = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());

        Activity.Builder.redemptionBuilder(body.getActivityName(), structure, activity.getBrand(),
                body.getDescription(), body.getRemark())
                .buildRule(pointType, body.getProperties(), body.getPriority())
                .validityTime(startAt, endAt)
                .updateBy(userName, LocalDateTime.now())
                .status(ActivityStatus.valueOf(body.getStatus().name()))
                .msgTemplate(body.getMsgTemplate())
                .updateActivity(activity);

        activity.addDisplayLanguages(activityDisplayMsgList);
        validateRuleProperties(activity);
        activityRepository.save(activity);
        //移除活动缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }


    /***
     * 修改礼品库存的方法
     * @param activityId 活动ID
     * @param giftId 礼品Id
     * @param amount 库存数量
     */
    public void modifyGiftInventory(String userName, String activityId, String giftId, Integer amount) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
        activity.updateGiftInventory(giftId, amount);
        activityRepository.save(activity);
        //清除缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }


    /**
     * 根据品牌，活动名称分页查询Interaction活动
     */
    public PageableResult<Activity> queryInteractionActivities(String region, String brand, String name, Integer perPage, Integer page, LocalDateTime startAt, LocalDateTime endAt) {
        // 先按活动优先级排序，然后再按更新时间排序
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        List<Activity> activities = activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.INTERACTION, structure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt));
        Comparator<Activity> comparator = Comparator.comparing(Activity::getUpdatedTime).reversed();
        activities = cacheService.filterActivity(activities, structure.name(), brand, name, null, null, null, comparator);
        return cacheService.generatePage(page, perPage, activities, null);
    }

    public PageableResult<Activity> queryRedemptionActivities(String region, String brand, String pointType, String name, Integer perPage, Integer page, LocalDateTime startAt, LocalDateTime endAt) {
        // 先按活动优先级排序，然后再按更新时间排序
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        List<Activity> activities = activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.REDEMPTION, structure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt));
        List<Activity> finalActivities = new ArrayList<>();
        if (StringUtils.isEmpty(pointType)) {
            finalActivities = activities;
        } else {
            for (Activity activity : activities) {
                if (pointType.equals(activity.getPointType())) {
                    finalActivities.add(activity);
                }
            }
        }
        Comparator<Activity> comparator = Comparator.comparing(Activity::getUpdatedTime).reversed();
        finalActivities = cacheService.filterActivity(finalActivities, structure.name(), brand, name, null, null, null, comparator);
        return cacheService.generatePage(page, perPage, finalActivities, null);
    }

    /**
     * 根据品牌，活动名称分页查询ORDER活动
     */
    public PageableResult<Activity> queryOrderActivities(String region, String brand, String name, Integer perPage, Integer page, LocalDateTime startAt, LocalDateTime endAt) {
        // 先按活动优先级排序，然后再按更新时间排序
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        List<Activity> activities = activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.ORDER, structure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt));
        Comparator<Activity> comparator = Comparator.comparing(Activity::getUpdatedTime).reversed();
        activities = cacheService.filterActivity(activities, structure.name(), brand, name, null, null, null, comparator);
        return cacheService.generatePage(page, perPage, activities, null);
    }

    /**
     * 根据品牌，活动名称分页查询TIER活动
     */
    public PageableResult<Activity> queryTierActivities(String region, String brand, String name, Integer perPage, Integer page, LocalDateTime startAt, LocalDateTime endAt) {
        // 先按活动优先级排序，然后再按更新时间排序
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        List<Activity> activities = activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.TIER, structure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt));
        Comparator<Activity> comparator = Comparator.comparing(Activity::getUpdatedTime).reversed();
        activities = cacheService.filterActivity(activities, structure.name(), brand, name, null, null, null, comparator);
        return cacheService.generatePage(page, perPage, activities, null);
    }

    /***
     * 根据活动ID查询Gift信息。
     */
    public Activity queryRedemptionActivityById(String activityId) {
        return getActivityAndCheckIfNullAndType(activityId, TransactionType.REDEMPTION);
    }

    public Activity queryInteractionActivityById(String activityId) {
        return getActivityAndCheckIfNullAndType(activityId, TransactionType.INTERACTION);
    }

    public Activity queryOrderActivityById(String activityId) {
        return getActivityAndCheckIfNullAndType(activityId, TransactionType.ORDER);
    }

    public Activity queryTierActivityById(String activityId) {
        return getActivityAndCheckIfNullAndType(activityId, TransactionType.TIER);
    }

    /**
     * 检查ExternalId的方法（新加活动的时候）
     *
     * @param externalId
     */
    private void checkExternalId(String externalId) {
        if (externalId == null) {
            return;
        }
        boolean exists = activityRepository.existsByExternalId(externalId);
        if (exists) {
            throw new SystemException("externalCode is exist, can not add again.", ResultCodeMapper.ACTIVITY_EXTERNALID_EXITS);
        }
    }

    private PointType fetchAndCheckPointType(LoyaltyStructure loyaltyStructure, String pointType, TransactionType transactionType) {
        if (StringUtils.isEmpty(pointType)) {
            throw new SystemException("PointType can not be empty", ResultCodeMapper.PARAM_ERROR);
        }
        List<PointType> pointTypes = pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED);
        for (PointType pt : pointTypes) {
            if (pointType.equals(pt.getPointType()) && transactionType.sameValueAs(pt.getTransactionType())) {
                return pt;
            }
        }
        throw new SystemException("The pointType is not exist or activity transaction type not match the pointType's transaction type", ResultCodeMapper.PARAM_ERROR);
    }

    private Activity getActivityAndCheckIfNull(String activityId) {
        List<Activity> activityList = activityRepository.findActivityById(activityId);
        if (activityList.isEmpty()) {
            throw new SystemException("活动信息没有找到, 请检查.", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        return activityList.get(0);
    }

    private Activity getActivityAndCheckIfNullAndType(String activityId, TransactionType transactionType) {
        Activity activity = getActivityAndCheckIfNull(activityId);
        if (!activity.getTransactionType().sameValueAs(transactionType)) {
            throw new SystemException("活动类型不匹配！请检查！", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        return activity;
    }


    private void saveOperationLog(String operator, ActivityLog.OperationType operationType, Activity activity) {
        ActivityLog activityLog = new ActivityLog(operator, operationType, activity);
        activityLogRepository.save(activityLog);
    }


    private void validateRuleProperties(Activity activity) {
        Set<ConstraintViolation<RuleProperties>> violationSet = validator.validate(activity.ruleProperties());
        Iterator<ConstraintViolation<RuleProperties>> iterator = violationSet.iterator();
        if (iterator.hasNext()) {
            ConstraintViolation<RuleProperties> violation = iterator.next();
            String errorMsg = violation.getPropertyPath() + violation.getMessage();
            throw new SystemException(errorMsg, ResultCodeMapper.PARAM_ERROR);
        }
    }

    public void addQrcodeSkuForActivity(String userName, String activityId, QrcodeItem qrcodeItem) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.INTERACTION);
        if (!(Transaction.PointTypeEnum.SCAN_CODE.toString().equals(activity.getPointType())
                || Transaction.PointTypeEnum.SCAN_CODE_TRANSIT.toString().equals(activity.getPointType()))) {
            throw new SystemException("The pointType is not match !", ResultCodeMapper.PARAM_ERROR);
        }
        activity.addQrcodeSkuItem(qrcodeItem);
        activityRepository.save(activity);
        //删除缓存
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.ADD, activity);
    }

    public void updateQrcodeActivitySku(String userName, String activityId, QrcodeItem qrcodeItem) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.INTERACTION);
        if (!Transaction.PointTypeEnum.SCAN_CODE.toString().equals(activity.getPointType())) {
            throw new SystemException("The pointType is not match", ResultCodeMapper.PARAM_ERROR);
        }
        activity.updateQrcodeSkuItem(qrcodeItem);
        activityRepository.save(activity);
        //删除缓存
        cacheService.removeActivityById(activityId);
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    public void deleteQrcodeActivitySkuByActivityIdAndSku(String userName, String activityId, String skuCode) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, TransactionType.INTERACTION);
        if (!Transaction.PointTypeEnum.SCAN_CODE.toString().equals(activity.getPointType())) {
            throw new SystemException("The pointType is not match ", ResultCodeMapper.PARAM_ERROR);
        }
        activity.deleteQrcodeSku(skuCode);
        //保存删除sku后的activity
        activityRepository.save(activity);
        //移除活动缓存
        cacheService.removeActivityById(activityId);
        //移除issuedNum缓存
        cacheService.removeActivityPointType(activity.getLoyaltyStructure(), activity.getPointType());
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.DELETE, activity);
    }

    public List<Activity> fetchRedemptionActivityListDeliveredByC2(TransactionType transactionType, LocalDateTime startAt, LocalDateTime endAt) {
        return activityRepository.findByTransactionTypeAndCreatedTimeBetweenOrderByCreatedTimeDesc(
                transactionType,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt));
    }

    /**
     * 对已存在的活动新增多语言
     *
     * @param userName
     * @param transactionType
     * @param activityId
     * @param activityDisplayMsgList
     */
    public void addDisplayLanguages(String userName, TransactionType transactionType, String activityId, List<Activity.ActivityDisplayMsg> activityDisplayMsgList) {
        Activity activity = getActivityAndCheckIfNullAndType(activityId, transactionType);
        activity.addDisplayLanguages(activityDisplayMsgList);
        //保存activity
        activityRepository.save(activity);
        //移除活动缓存
        cacheService.removeActivityById(activityId);
        //增加日志
        saveOperationLog(userName, ActivityLog.OperationType.UPDATE, activity);
    }

    public Activity checkRedemptionActivity(String activityId, LoyaltyStructure loyaltyStructure) {
        //1.获取activity
        Activity activity = cacheService.findActivityById(activityId);
        if (activity == null) {
            throw new SystemException("The passed activity ID does not exist", ResultCodeMapper.PARAM_ERROR);
        }
        //判断兑换是否在本次活动时间的范围之内,以及是否已经激活
        activity.checkAvailable(LocalDateTime.now());
        //判断是否是同一个积分体系
        activity.checkOwnStructure(loyaltyStructure);
        //2.判断是否配置了兑换活动规则，如果没有配置就直接返回错误
        activity.checkRedemptionProperties();
        return activity;
    }
}
