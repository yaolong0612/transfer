package cn.com.pg.loyalty.application.dependence;

import lombok.Getter;
import lombok.Setter;

/**
 * @author tangjia
 * @date 2019/7/5
 *  Subscribe
 */
@Setter
@Getter
public class Subscribe{
    /**
     * 订阅的主题
     */
    private ServiceBusQueueTopicEnum topicEnum;
    /**
     * 订阅的消费者
     */
    private Object object;

    /**
     * 有参构造
     * @param topicEnum  订阅的主题
     * @param object     订阅的消费者
     */
    public Subscribe(ServiceBusQueueTopicEnum topicEnum, Object object) {
        this.topicEnum = topicEnum;
        this.object = object;
    }
}