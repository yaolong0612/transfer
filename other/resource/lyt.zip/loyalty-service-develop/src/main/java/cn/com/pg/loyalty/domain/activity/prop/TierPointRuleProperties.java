package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.List;


/**
 * @author linbj
 * @date 2020/6/2 15:29
 */
@Getter
@Setter
public class TierPointRuleProperties extends RuleProperties {
    private int maxPoint; //最大积分数
    private List<TierMultipleRuleProperties> tierMultipleRulePropertiesList; //等级及倍数

}
