package cn.com.pg.loyalty.domain.transaction;

import lombok.*;

/**
 * @author lmr
 */
@Data
public class RedemptionExpiredSendMessage {
    private String memberId;
    private String brand;
    private String amTenantId;
    private String month;
}
