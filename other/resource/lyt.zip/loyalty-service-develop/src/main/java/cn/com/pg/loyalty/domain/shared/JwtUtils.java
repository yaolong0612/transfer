package cn.com.pg.loyalty.domain.shared;

import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.util.Map;

/**
 * @author: Ysnow
 * @Date: 2019/6/4 17:41
 * @Description: JWT的工具类
 */
public class JwtUtils {

    /**
     *
     * @param token token可以有两种格式。一种为
     * @return
     */
    public static String getUsernameFromToken(String token){
        String username;
        try {
            token = token.trim();
            String[] splits = token.split(" ");
            if (splits.length > 1) {
                token = splits[splits.length - 1];
            }
            DecodedJWT decodeToken = JWT.decode(token);
            Map<String, Claim> map = decodeToken.getClaims();
            Claim claim = map.get("Username");
            if (claim == null) {
                claim = map.get("account");
            }
            if (claim == null) {
                claim = map.get("shortname");
            }
            if (claim == null) {
                for (Map.Entry<String, Claim> entry : map.entrySet()) {
                    String key = entry.getKey();
                    Claim value = entry.getValue();
                    if (key.contains("name") || key.contains("Name")) {
                        claim = value;
                        break;
                    }
                }
            }
            if (claim == null) {
                username = "unknown";
            } else {
                username = claim.asString();
            }
        } catch (Exception e) {
            username = "unknown";
        }
        return username;
    }
}
