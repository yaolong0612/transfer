package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.RedemptionServiceBusProperties;
import cn.com.pg.loyalty.application.SmsService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.storageentity.TierChangeRecord;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.ExceptionPhase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author: Ysnow
 * @Date: 2019/6/13 18:31
 */
@Component
@Slf4j
public class SendMessageConsumer extends AbstractConsumer {

    @Autowired
    private SmsService smsService;
    @Autowired
    private CacheService cacheService;

    private static final ServiceBusQueueTopicEnum QUEUE_NAME = ServiceBusQueueTopicEnum.SEND_MESSAGE_TO_CONSUMER_BY_SMS;
    private String brand = BrandV2.OLAY;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        String type = jsonObject.getString(SmsService.SMS_TYPE);
        if (SmsService.REDEMPTION_TRANSFER_TYPE.equals(type)){
            RedemptionServiceBusProperties redemptionServiceBusProperties = JSON.toJavaObject(jsonObject,RedemptionServiceBusProperties.class);
            // 目前只有olay的有转柜，adminPortal组装数据的时候没传，暂时写死
            redemptionServiceBusProperties.setLoyaltyStructure("ML_OLAY");
            smsService.sendCounterTransferSMS(redemptionServiceBusProperties, jsonObject);
            log.info("Send a message to inform consumers to receive the gift redemption status,this consumer phoneNumber is {}",redemptionServiceBusProperties.getActivityId());
        }
        /**
        *
        暂时注释 olay等级变更短信通知 等业务通知放开
        if (SmsService.TIER_CHANGE_TYPE.equals(type)) {
            TierChangeRecord tierMessage = JSON.parseObject(jsonObject.toJSONString(), TierChangeRecord.class);
            LoyaltyStructure loyaltyStructure =cacheService.findLoyaltyStructureById(tierMessage.getLoyaltyStructure());
            if (loyaltyStructure!=null) {
                String memberId = tierMessage.getMemberId();
                String loyaltyId = tierMessage.getLoyaltyId();
                String originalTier = tierMessage.getPreLevel();
                String currentTier = tierMessage.getTierLevel();
                smsService.sendTierChangeSMS(memberId, loyaltyId, brand, originalTier, currentTier, loyaltyStructure);
            }
        }
        *
        *
        * */
    }

    @Override
    protected String getLabel() {
        return QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return QUEUE_NAME;
    }

    @Override
    public void notifyException(Throwable throwable, ExceptionPhase exceptionPhase) {
         //Do nothing.
    }
}
