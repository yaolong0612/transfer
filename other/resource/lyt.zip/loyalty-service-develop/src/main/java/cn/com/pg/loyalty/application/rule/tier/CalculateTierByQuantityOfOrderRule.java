package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.CalculateTierByQuantityOfOrderRuleProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevel;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Rule(name = "calculateTierByQuantityOfOrderRule",
        description = "upgrade to tier based on the quantity of order")
public class CalculateTierByQuantityOfOrderRule {

    @Condition
    public boolean isExecuteRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activities) {
        return activities.stream().map(Activity::getRuleTemplate)
                .anyMatch(item -> item.equals(RuleTemplate.CALCULATE_TIER_BY_QUANTITY_OF_ORDER_RULE));
    }

    @Action
    public void upgrade(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("transaction") Transaction transaction,
                        @Fact("orderRepository") OrderRepository orderRepository,
                        @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activities,
                        @Fact("ruleResult") RuleResult ruleResult,
                        @Fact("calculateTierExpired") Boolean tierExpired) {
        Order order = null;
        String brand = transaction.brand();
        LocalDateTime availableTime = account.getTierList().get(loyaltyStructure.name()).getExpiredTime();
        //正单和退单计算等级使用订单时间查询活动，等级过期使用等级过期时间
        if (!tierExpired) {
            order = (Order) transaction;
            if (order.getRealTotalAmount() <= 0 && !order.refundOrder()) {
                log.info("orderId:{}, 实付金额小于等于0，无需走当前规则", order.getOrderId());
                return;
            }
            availableTime = order.getOrderDateTime();
        }
        List<Activity> matchActivityList =
                RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activities,
                        availableTime,
                        RuleTemplate.CALCULATE_TIER_BY_QUANTITY_OF_ORDER_RULE);
        Activity activity = matchActivityList.get(0);
        CalculateTierByQuantityOfOrderRuleProperties ruleProperties = JSON.parseObject(activity.getRuleProperties(),
                CalculateTierByQuantityOfOrderRuleProperties.class);
        // 获取消费者最近一年订单
        List<Order> rawOrderList =
                orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                        PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()),
                        account.loyaltyId(), brand, TransactionType.ORDER,
                        LoyaltyDateTimeUtils.localDateTimeToString(availableTime.minusYears(1)),
                        LoyaltyDateTimeUtils.localDateTimeToString(availableTime));
        // 过滤团购，退单的情况
        List<Order> orderList = filterOrder(order, rawOrderList);
        // 不是等级过期且订单实付金额大于0的情况下需加上当前订单
        if (order != null && order.realTotalAmount() > 0) {
            orderList.add(order);
        }
        // 判断订单金额，年消费累计大于更高一级升级金额的无需判断，走正常的等级金额计算
        double totalAmountInRecentYear = orderList.stream().mapToDouble(Order::getRealTotalAmount).sum();
        TierLevel higherLevel = loyaltyStructure.getTierLevelSeries().nextLevel(ruleProperties.getTierLevel());
        if (totalAmountInRecentYear >= higherLevel.getGradingAmount()) {
            log.info("最近一年累计购买金额大于更高一级的金额，无需走当前规则");
            return;
        }
        // 判断订单数量，大于指定数量，则升级
        if (orderList.size() < ruleProperties.getQuantity()) {
            log.info("最近一年购买指定sku订单数量不满足条件，purchaseNum:{}", orderList.size());
            return;
        }
        Tier tier = account.tier(loyaltyStructure.getName());
        if (loyaltyStructure.tierLevelSeries().compare(tier.getLevel(),
                ruleProperties.getTierLevel()) != 0) {
            Tier newTier = new Tier(loyaltyStructure, ruleProperties.getTierLevel(), tier.getLevel());
            account.tier(loyaltyStructure, newTier);
            log.info("等级发生变化: MemberId:{},更新前上一次等级:{},当前等级{},更新后的等级{},过期时间{}",
                    account.memberId(), tier.getPreLevel(), newTier.getPreLevel(), newTier.getLevel(), newTier.getExpiredTime());
        }
        log.info("有效订单满足条件升级到指定等级，等级计算结束");
        ruleResult.success();
    }

    private List<Order> filterOrder(Order order, List<Order> rawOrderList) {
        //order为null说明是等级过期
        if (order == null) {
            return rawOrderList.stream().filter(item -> item.getRealTotalAmount() > 0 && !item.groupPurchaseIs())
                    .collect(Collectors.toList());
        }
        return rawOrderList.stream().filter(item -> item.getRealTotalAmount() > 0 && !item.groupPurchaseIs())
                // 当退单进来规则时，需过滤原单
                .filter(item -> !item.channelUnitOrderId().equals(order.channelUnitOrderId()))
                .collect(Collectors.toList());
    }
}
