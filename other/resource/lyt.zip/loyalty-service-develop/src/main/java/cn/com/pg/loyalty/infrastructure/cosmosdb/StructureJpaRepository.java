package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Repository
public interface StructureJpaRepository extends DocumentDbRepository<LoyaltyStructure, String> {


    default List<LoyaltyStructure> findLoyaltyStructures() {
        List<LoyaltyStructure> structures = new ArrayList<>();
        Iterable<LoyaltyStructure> iterator = this.findAll();
        iterator.forEach(structures::add);
        return structures;
    }
}
