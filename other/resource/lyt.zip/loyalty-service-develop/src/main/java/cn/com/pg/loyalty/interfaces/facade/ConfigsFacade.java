package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.ConfigService;
import cn.com.pg.loyalty.domain.structure.Config;
import cn.com.pg.loyalty.interfaces.api.ConfigsApiDelegate;
import cn.com.pg.loyalty.interfaces.dto.ConfigCommand;
import cn.com.pg.loyalty.interfaces.dto.ConfigDTO;
import cn.com.pg.loyalty.interfaces.dto.ConfigListDTO;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component("configFacade")
public class ConfigsFacade implements ConfigsApiDelegate {

    private final ConfigService configService;

    @Autowired
    public ConfigsFacade(ConfigService configService) {
        this.configService = configService;
    }

    @Override
    public ResponseEntity<Void> createConfig(ConfigCommand configCommand) {
        configService.createConfig(toConfig(configCommand));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ConfigListDTO> fetchConfigByType(String configType) {
        List<Config> configList = configService.findByType(configType);
        ConfigListDTO configListDTO = toConfigListDTO(configList);
        return ResponseEntity.ok(configListDTO);
    }

    @Override
    public ResponseEntity<Void> deleteConfigById(String id) {
        configService.deleteConfigById(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ConfigDTO> fetchConfigById(String id) {
        Config config = configService.fetchConfigById(id);
        return ResponseEntity.ok(toConfigDTO(config));
    }

    private ConfigListDTO toConfigListDTO(List<Config> configList) {
        ConfigListDTO result = new ConfigListDTO();
        if(CollectionUtils.isNotEmpty(configList)){
            List<ConfigDTO> configDTOList = configList.stream().map(this::toConfigDTO).collect(Collectors.toList());
            result.records(configDTOList);
            result.totalSize(configDTOList.size());
        }
        return result;
    }

    private Config toConfig(ConfigCommand configCommand) {
        return new Config(configCommand.getType().name(), configCommand.getName(), configCommand.getDescription());
    }

    private ConfigDTO toConfigDTO(Config config){
        ConfigDTO configDTO = new ConfigDTO();
        configDTO.id(config.id());
        configDTO.name(config.name());
        configDTO.type(config.type());
        configDTO.description(config.description());
        return configDTO;
    }
}
