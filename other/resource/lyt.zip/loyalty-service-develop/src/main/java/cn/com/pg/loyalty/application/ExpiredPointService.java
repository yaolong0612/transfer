package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.LoyaltyMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.application.dependence.ServiceBusTemplate;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionRepository;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author cooltea on 2019/6/22 10:33.
 * @version 1.0
 * @email cooltea007@163.com
 */
@Service
@Slf4j
public class ExpiredPointService {

    private static final String YEAR_TYPE = "YEAR";
    private static final String MONTH_TYPE = "MONTH";

    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private AccountService accountService;
    @Autowired
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;
    @Autowired
    private ServiceBusTemplate serviceBusTemplate;
    @Autowired
    private CacheService cacheService;

    /**
     * 处理用户某年的过期积分
     *
     * @param brand
     * @param loyaltyId
     * @param expiredYear 需要处理的过期积分的日期（那一年）
     * @return 当可用积分大于零时才返回那年的总积分和过期的总积分
     */
    public Account expiredPointByYear(String brand, String loyaltyId, Integer expiredYear) {
        log.info("计算过期积分品牌：{}, loyaltyId:{}，年份：{}", brand, loyaltyId, expiredYear);
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        LoyaltyStructure loyaltyStructure = getLoyaltyStructureBy(account, brand, loyaltyId);
        int accountAvailablePoint = account.availablePoint(loyaltyStructure.accountTypeOfDefault());
        log.info("开始计算过期积分用户，可用积分：{}，用户详情：{}", accountAvailablePoint, JSON.toJSONString(account));
        // 查找某个用户某一年的某些品牌所有需要过期的交易积分记录
        List<Transaction> transactions = fetchTransactionsByYear(loyaltyStructure, loyaltyId, expiredYear, expiredYear);
        List<Transaction> hasExpireRecordTransactions = filterAvailableTransactionAndHasExpireRecord(transactions);
        int allRecordAvailablePoints = hasExpireRecordTransactions.parallelStream().mapToInt(Transaction::getAvailablePoint).sum();
        if (allRecordAvailablePoints < 0) {
            Transaction transaction = transactions.get(0);
            // 如果这一年的记录为负数那么说明用户这一年有佘积分 插入一条负值availablePoint续佘到下一年
            LocalDateTime createTime = transaction.getCreatedTime().plusYears(1);
            String channel = transaction.channel();
            createSettlementTransaction(loyaltyStructure, loyaltyId, account.memberId(), channel, createTime, allRecordAvailablePoints, YEAR_TYPE);
        }
        log.info("用户总的可用积分：{}，准备过期用户积分：{}，(取两者最小值)", accountAvailablePoint, allRecordAvailablePoints);
        hasExpireRecordTransactions.forEach(transaction -> doExpiredPoint(transaction, account, allRecordAvailablePoints, accountAvailablePoint));
        log.info("完成计算过期积分用户：{}", JSON.toJSONString(account));
        return account;
    }

    private void createSettlementTransaction(LoyaltyStructure loyaltyStructure, String loyaltyId, String memberId, String channel, LocalDateTime createTime, Integer availablePoint, String yearOrMonth) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        LocalDateTime startTime = LocalDateTime.of(createTime.toLocalDate(), LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(createTime.toLocalDate(), LocalTime.MAX);
        if (YEAR_TYPE.equalsIgnoreCase(yearOrMonth)) {
            startTime = LocalDateTime.of(LocalDate.of(createTime.getYear(), 1, 1), LocalTime.MIN);
            endTime = LocalDateTime.of(LocalDate.of(createTime.getYear(), 12, 31), LocalTime.MAX);
        }
        if (MONTH_TYPE.equalsIgnoreCase(yearOrMonth)) {
            LocalDate expireMonth = LocalDate.of(createTime.getYear(), createTime.getMonth(), 1);
            startTime = LocalDateTime.of(expireMonth, LocalTime.MIN);
            endTime = LocalDateTime.of(expireMonth.with(TemporalAdjusters.lastDayOfMonth()), LocalTime.MAX);
        }
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        Set<String> brands = new HashSet<>(loyaltyStructure.brands());
        boolean existsSettlementTransaction = interactionRepository.existsByPartitionKeyAndLoyaltyIdAndTransactionStatusAndCreatedTimeBetweenAndBrandIn(partitionKey, loyaltyId, Transaction.TransactionStatus.SETTLEMENT, startAt, endAt, brands);
        // 不存在插入新的一条记录
        if (!existsSettlementTransaction) {
            Optional<String> oBrand = loyaltyStructure.brands().stream().findFirst();
            if (oBrand.isPresent()) {
                Interaction interaction = new Interaction(loyaltyId,
                        oBrand.get(), channel, loyaltyStructure, memberId, Transaction.TransactionStatus.SETTLEMENT, createTime, availablePoint);
                transactionRepository.save(interaction);
            }
        }
    }

    /**
     * 处理用户某月的过期积分
     *
     * @param brand
     * @param loyaltyId
     * @param expiredYear  需要处理的过期积分积分相对应的的那个月分的年
     * @param expiredMonth 需要处理的过期积分积分日期（那月）
     * @return 当可用积分大于零时才返回那天的总积分和过期的总积分
     */
    public Account expiredPointByMonth(String brand, String loyaltyId, Integer expiredYear, Integer expiredMonth) {
        log.info("计算过期积分品牌：{}, loyaltyId:{}，年份：{}, 月份：{}", brand, loyaltyId, expiredYear, expiredMonth);
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        LoyaltyStructure loyaltyStructure = getLoyaltyStructureBy(account, brand, loyaltyId);
        int accountAvailablePoint = account.availablePoint(loyaltyStructure.accountTypeOfDefault());
        log.info("开始计算过期积分用户，可用积分：{}，用户详情：{}", accountAvailablePoint, JSON.toJSONString(account));
        // 查找某个用户某一月的某些品牌所有需要过期的交易积分记录
        List<Transaction> transactions = fetchTransactionsByMonth(loyaltyStructure, loyaltyId, expiredYear, expiredMonth);
        List<Transaction> hasExpireRecordTransactions = filterAvailableTransactionAndHasExpireRecord(transactions);
        int allRecordAvailablePoints = hasExpireRecordTransactions.parallelStream().mapToInt(Transaction::getAvailablePoint).sum();
        if (allRecordAvailablePoints < 0) {
            Transaction transaction = transactions.get(0);
            // 如果这个月的记录为负数那么说明用户这个月有佘积分 插入一条负值availablePoint续佘到下月
            LocalDateTime createTime = transaction.getCreatedTime().plusMonths(1);
            String channel = transaction.channel();
            createSettlementTransaction(loyaltyStructure, loyaltyId, account.memberId(), channel, createTime, allRecordAvailablePoints, MONTH_TYPE);
        }
        log.info("用户总的可用积分：{}，准备过期用户积分：{}，(取两者最小值)", accountAvailablePoint, allRecordAvailablePoints);
        hasExpireRecordTransactions.forEach(transaction -> doExpiredPoint(transaction, account, allRecordAvailablePoints, accountAvailablePoint));
        log.info("完成计算过期积分用户：{}", JSON.toJSONString(account));
        return account;
    }

    /**
     * 处理用户某天的过期积分 这个方法还不可用
     *
     * @param brand1
     * @param loyaltyId
     * @param expiredDay
     * @return
     */
    public Account expiredPointByDay(String brand1, String loyaltyId, LocalDate expiredDay) {
        //该方法大概还不可用
        log.info("计算过期积分品牌：{}, loyaltyId:{}，日期：{}", brand1, loyaltyId, expiredDay.toString());
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        LoyaltyStructure loyaltyStructure = getLoyaltyStructureBy(account, brand1, loyaltyId);
        int accountAvailablePoint = account.availablePoint(loyaltyStructure.accountTypeOfDefault());
        log.info("开始计算过期积分用户，可用积分：{}，用户信息：{}", accountAvailablePoint, JSON.toJSONString(account));
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.of(expiredDay, LocalTime.MAX));
        Set<String> brands = new HashSet<>(loyaltyStructure.brands());
        List<Transaction> transactions = transactionRepository.findByPartitionKeyAndLoyaltyIdAndExpiredTimeLessThanAndBrandInAndTransactionStatusNotExpire(partitionKey, loyaltyId, endAt, brands);
        transactions = filterTransaction(transactions);
        // 按天分组统计当天的要过期积分
        Map<String, Integer> dailyMap = transactions.stream().collect(
                Collectors.groupingBy(transaction -> LoyaltyDateTimeUtils.localDateTimeToDateString(transaction.getExpiredTime()),
                        Collectors.summingInt(Transaction::getAvailablePoint)));
        log.info("需要过期的日积分：{}", JSON.toJSONString(dailyMap));
        // 按天分分组
        Map<String, List<Transaction>> listMap = transactions.stream().collect(
                Collectors.groupingBy(transaction -> LoyaltyDateTimeUtils.localDateTimeToDateString(transaction.getExpiredTime())));
        listMap.forEach((strDay, dailyTransactions) -> {
            int dailyAvailablePoints = dailyMap.get(strDay);
            dailyTransactions.forEach(transaction -> doExpiredPoint(transaction, account, dailyAvailablePoints, accountAvailablePoint));
        });
        log.info("已完成计算过期积分用户：{}", JSON.toJSONString(account));
        return account;
    }

    public Account willExpiredPointsByYear(String brand, String loyaltyId, Integer expiredYear) {
        log.info("计算即将过期积分品牌：{}, loyaltyId:{}，年份：{}", brand, loyaltyId, expiredYear);
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        LoyaltyStructure loyaltyStructure = getLoyaltyStructureBy(account, brand, loyaltyId);
        List<Transaction> transactions = fetchTransactionsByYear(loyaltyStructure, loyaltyId, expiredYear, expiredYear);
        log.info("开始计算即将过期积分用户：{}", JSON.toJSONString(account));
        calculateWillExpiredPoint(transactions, account, loyaltyStructure);
        accountRepository.save(account);
        return account;
    }

    public Account willExpiredPointsByMonth(String brand, String loyaltyId, int willExpiredYear, int willExpiredMonth) {
        log.info("计算即将过期积分品牌：{}, loyaltyId:{}，年份：{}, 月份：{}", brand, loyaltyId, willExpiredYear, willExpiredMonth);
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        LoyaltyStructure loyaltyStructure = getLoyaltyStructureBy(account, brand, loyaltyId);
        log.info("开始计算即将过期积分用户：{}", JSON.toJSONString(account));
        List<Transaction> transactions = fetchTransactionsByMonth(loyaltyStructure, loyaltyId, willExpiredYear, willExpiredMonth);
        calculateWillExpiredPoint(transactions, account, loyaltyStructure);
        accountRepository.save(account);
        // 台湾香港帮宝适,推送积分即将过期通知
        if (loyaltyStructure.checkHkBrand(BrandV2.PAMPERS) || loyaltyStructure.checkTwBrand(BrandV2.PAMPERS)) {
            int pointAboutExpire = account.pointAboutExpire(loyaltyStructure.accountTypeOfDefault());
            if (pointAboutExpire > 0) {
                LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("messageType", "POINT_EXPIRED");
                jsonObject.put("loyaltyId", loyaltyId);
                loyaltyMessage.setJsonObject(jsonObject);
                serviceBusTemplate.sendMessageAsync(ServiceBusQueueTopicEnum.HKTW_PAMPERS_NOTIFICATION_QUEUE, loyaltyMessage);
            }
        }
        return account;
    }

    private LoyaltyStructure getLoyaltyStructureBy(Account account, String brand, String loyaltyId) {
        if (account == null) {
            log.error("获取不到用户：{}", loyaltyId);
            throw new SystemException("没有找到该用户: " + loyaltyId, ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        return cacheService.findLoyaltyStructure(account.getRegion(), brand);
    }

    public void calculateWillExpiredPoint(List<Transaction> transactions, Account account, LoyaltyStructure loyaltyStructure) {
        transactions = filterTransaction(transactions);
        log.info("过滤不满足条件的记录后还剩记录数：{}", transactions.size());
        int availablePoint = account.availablePoint(loyaltyStructure.accountTypeOfDefault());
        // 按品牌统计即将过期积分
        Map<String, Integer> listMap = transactions.stream().collect(Collectors.groupingBy(Transaction::brand,
                Collectors.summingInt(Transaction::availablePoint)));
        int willExpiredPoint = transactions.stream().mapToInt(Transaction::getAvailablePoint).sum();
        log.info("总户总可用积分：{}, 即将过期总积分：{},是否需要计算即将过期积分：{}, 按品牌计算即将过期的积分：{}", availablePoint, willExpiredPoint, willExpiredPoint > 0, JSON.toJSONString(listMap));
        // 计算过期积分时初始化所有即将过期为0
        account.initWillExpiredPoint(loyaltyStructure);
        // 如果可用积分比总的即将过期积分多平摊到每个积分体系品牌
        if (willExpiredPoint > 0) {
            if (availablePoint > 0 && availablePoint >= willExpiredPoint) {
                // 设置用户积分体系下对应品牌的即将过期积分
                listMap.forEach(account::pointAboutExpire);
            } else if (availablePoint > 0) {
                // 否则全部设置到某个品牌
                Optional<String> optionalBrand = listMap.keySet().stream().findFirst();
                optionalBrand.ifPresent(s -> account.pointAboutExpire(s, availablePoint));
            }
            log.info("计算完成即将过期积分用户：{}", JSON.toJSONString(account));
        }
    }

    private void doExpiredPoint(Transaction transaction, Account account, Integer allRecordAvailablePoints, Integer accountAvailablePoint) {
        int recordAvailablePoint = transaction.getAvailablePoint();
        if (recordAvailablePoint != 0 && Transaction.TransactionStatus.EXPIRED != transaction.getTransactionStatus()) {
            // 设置交易记录积分过期
            transaction.expire();
            if (allRecordAvailablePoints > 0 && accountAvailablePoint > 0) {
                String brand = transaction.getBrand();
                account.pointExpired(brand, transaction.getAvailablePoint());
                batchUpdateDBComponentImpl.saveTransactionAndAccount(transaction, account);
            } else {
                transactionRepository.save(transaction);
            }
        }
    }


    private List<Transaction> fetchTransactions(LoyaltyStructure loyaltyStructure, String loyaltyId, LocalDateTime startTime, LocalDateTime entTime) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(entTime);
        Set<String> brands = new HashSet<>(loyaltyStructure.brands());
        return transactionRepository.findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(partitionKey,
                loyaltyId, startAt, endAt, brands);
    }

    private List<Transaction> fetchTransactionsByYear(LoyaltyStructure loyaltyStructure, String loyaltyId, Integer startYear, Integer endYear) {
        LocalDateTime startTime = LocalDateTime.of(LocalDate.of(startYear, 1, 1), LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(LocalDate.of(endYear, 12, 31), LocalTime.MAX);
        return fetchTransactions(loyaltyStructure, loyaltyId, startTime, endTime);
    }

    private List<Transaction> fetchTransactionsByMonth(LoyaltyStructure loyaltyStructure, String loyaltyId, Integer expireYar, Integer expiredMonth) {
        LocalDate expireMonth = LocalDate.of(expireYar, expiredMonth, 1);
        LocalDateTime startTime = LocalDateTime.of(expireMonth, LocalTime.MIN);
        LocalDateTime endTime = LocalDateTime.of(expireMonth.with(TemporalAdjusters.lastDayOfMonth()), LocalTime.MAX);
        return fetchTransactions(loyaltyStructure, loyaltyId, startTime, endTime);
    }



    /**
     * 过滤兑换订单，获取状态为 ACTIVATE,USED的Interaction和 order订单
     *
     * @param transactions
     * @return
     */
    private List<Transaction> filterTransaction(List<Transaction> transactions) {
        return transactions.parallelStream()
                .filter(transaction -> !transaction.redemptionType())
                .filter(Transaction::statusActivateOrUsed)
                .collect(Collectors.toList());
    }

    /**
     * 排除lock 和 delay 状态的
     *
     * @param transactions
     * @return
     */
    private List<Transaction> filterAvailableTransactionAndHasExpireRecord(List<Transaction> transactions) {
        return transactions.parallelStream()
                .filter(transaction -> !transaction.redemptionType())
                .filter(Transaction::statusAvailableOrExpire)
                .collect(Collectors.toList());
    }
}
