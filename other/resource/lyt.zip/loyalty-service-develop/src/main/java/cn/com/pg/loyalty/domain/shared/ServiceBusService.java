package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.infrastructure.servicebus.ServiceBusConfig;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusConfigRefactor;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.Message;
import com.microsoft.azure.servicebus.QueueClient;
import com.microsoft.azure.servicebus.TopicClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author vincenzo
 * @description
 * @date 2021/11/25
 */
@Service
@Slf4j
public class ServiceBusService {
    @Autowired
    private ApplicationContext context;

    @Value("${serviceBus.generalLabel}")
    private String serviceBusGeneralLabel;

    public void distributeDataToServiceBus(String data, String aimName, ServiceBusQueueTopicEnum.ServiceBusType serviceBusType) {
        this.checkEnforceability();
        Object object = ServiceBusConfig.fetchClient(aimName, serviceBusType);
        if (object == null && ServiceBusBinder.fetchBinderByName(aimName) == null) {
            throw new SystemException("目标service bus对象不存在", ResultCodeMapper.PARAM_ERROR);
        }
        //由于新旧2种方式并存，需要判断
        Object client = object == null ? ServiceBusConfigRefactor.fetchClient(ServiceBusBinder.valueOf(aimName)).getClient() : object;
        IMessage message = new Message(data.getBytes());
        message.setLabel(serviceBusGeneralLabel);
        message.setTimeToLive(Duration.ofDays(20));
        message.setContentType("application/json");
        try {
            switch (serviceBusType) {
                case QUEUE:
                    QueueClient queueClient = (QueueClient) client;
                    queueClient.send(message);
                    break;
                case TOPIC:
                    TopicClient topicClient = (TopicClient) client;
                    topicClient.send(message);
                    break;
                default:
                    throw new SystemException("非法service bus 类型", ResultCodeMapper.PARAM_ERROR);
            }
        } catch (InterruptedException e) {
            log.error("service bus发送消息(ServiceBusService) Interrupted!");
            // Restore interrupted state...
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            log.info("service bus发送消息异常: {}", e.getMessage());
            throw new SystemException("service bus发送消息异常", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    /**
     * 生产环境禁止执行流程，抛出异常
     */
    public void checkEnforceability() {
        List<String> currentActiveProfileList = Arrays.asList(context.getEnvironment().getActiveProfiles()).stream().map(String::toUpperCase).collect(Collectors.toList());
        List<String> prodProfileList = currentActiveProfileList.stream().filter(item -> item.contains("prod") || item.contains("PROD")).collect(Collectors.toList());
        if (prodProfileList.isEmpty()) {
            return;
        }
        throw new SystemException("目标方法未实现", ResultCodeMapper.PARAM_ERROR);
    }
}
