package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.domain.activity.PointType;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xingliangzhan
 * @date 2019/8/4
 */
public interface KpiTemplate {
    void send(HashMap<String, Object> object);

    /**
     * 推送请求类型的监控日志，接口请求
     *
     * @param path            接口请求路径
     * @param requestMethod   GET POST PUT 等
     * @param operationName     接口请求方法名称
     * @param requestDateTime
     * @param costTime
     * @param errorCode
     * @param errorMsg
     */
    default void sendRequest(String path, String requestMethod, String operationName, LocalDateTime requestDateTime,
                             long costTime, int errorCode, String errorMsg, String correlationId) {
    }

    /**
     * 监控消费队列消息
     * @param messageId
     * @param operationName
     * @param consumingDateTime
     * @param costTime
     * @param errorCode
     * @param errorMsg
     * @param correlationId
     */
    void sendConsumingMessage(String messageId, String operationName, LocalDateTime consumingDateTime,
                             long costTime, int errorCode, String errorMsg, String correlationId);

    void sendDependency(String correlationId, String operationName, KpiLog.KpiType kpiType, LocalDateTime dateTime,
                        long costTime, String resultCode, String message, boolean isSuccess, Map<String, String> properties);

    /**
     * 推送积分相关kpi监控方法
     * @param memberId        会员号
     * @param point            积分
     * @param brand            品牌
     * @param channel          渠道
     * @param pointType        积分类型
     */
    void sendKpi(String memberId, int point, String brand, String kpiName,
                 String channel, PointType pointType, Map<String, String> properties);

}
