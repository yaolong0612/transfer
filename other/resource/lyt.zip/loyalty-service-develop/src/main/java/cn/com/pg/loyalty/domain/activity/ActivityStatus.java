package cn.com.pg.loyalty.domain.activity;


import cn.com.pg.loyalty.domain.shared.ValueObject;

/**
 * @author Simon
 * @date 2019年4月23日下午4:18:38
 * @description ActivityStatus
 */
public enum ActivityStatus implements ValueObject<ActivityStatus> {
    /**
     * INITIAL
     */
    INITIAL,
    /**
     * ACTIVITY
     */
    ACTIVATE;

    @Override
    public boolean sameValueAs(final ActivityStatus other) {
        return this.equals(other);
    }
}
