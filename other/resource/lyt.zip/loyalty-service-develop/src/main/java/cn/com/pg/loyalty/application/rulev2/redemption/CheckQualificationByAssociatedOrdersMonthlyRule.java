package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.activity.prop.PurchaseLimit;
import cn.com.pg.loyalty.domain.activity.prop.PurchaseLimit.RedemptionQualificationType;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @description: (Olay)兑换购买限制规则
 * @author: Jevons Chen
 * @date: 2020-03-30 15:35
 */

@Slf4j
@Rule(name = "Check Redemption Qualification Rule",
        description = "Calculate Redemption Qualification for finding Orders by Month or Absolute Time",
        priority = 2)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION, ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
@Component
public class CheckQualificationByAssociatedOrdersMonthlyRule {

    @Autowired
    private OrderRepositoryV2 orderRepository;

    @Condition
    public boolean isExecuteCheckQualificationByAssociatedOrdersMonthlyRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                                                                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                                                                            @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        return redemption.getGiftItemList().stream()
                .anyMatch(giftItem -> checkPurchaseLimit(properties.fetchPurchaseLimit(activity.getGifts(), giftItem)));
    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        List<GiftItem> giftItemList = redemption.getGiftItemList();
        //查询用户的所有历史订单
        List<Order> allOrderRecords = orderRepository.findMemberOrdersByLoyaltyId(account, redemption.brand());
        for (GiftItem giftItem : giftItemList) {
            PurchaseLimit purchaseLimit = properties.fetchPurchaseLimit(activity.getGifts(), giftItem);
            if (!checkPurchaseLimit(purchaseLimit)) {
                continue;
            }
            log.info("ByAssociatedOrdersMonthly规则：{}", JSON.toJSONString(purchaseLimit));
            int month = purchaseLimit.getMonth();
            //根据限制时间对用户历史订单进行过滤
            List<Order> historyOrders = fetchHistoryOrders(month, allOrderRecords);
            long orderTimes = getOrderTimes(purchaseLimit, historyOrders);
            if (purchaseLimit.getPurchaseRecords() > orderTimes) {
                log.info("购买记录为:{}次, 礼品要求次数：{}次", orderTimes, purchaseLimit.getPurchaseRecords());
                throw new SystemException("Purchase times are below the minimum requirement",
                        ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS, month);
            }
        }
        log.info("兑换按月购买限制验证通过: {}, 当前Lable:{}", redemption, properties.fetchLable());
    }

    /**
     * 根据时间限制对用户历史订单进行过滤
     *
     * @param month
     * @param allOrderRecords
     */
    private List<Order> fetchHistoryOrders(int month, List<Order> allOrderRecords) {
        //查询用户历史的所有订单
        if (month <= 0) {
            return allOrderRecords;
        }
        //有限制时间则根据计算出的开始结束时间进行过滤
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusMonths(month);
        return allOrderRecords.stream()
                .filter(order -> !order.getOrderDateTime().toLocalDate().isBefore(startDate)
                        && !order.getOrderDateTime().toLocalDate().isAfter(endDate))
                .collect(Collectors.toList());
    }

    /**
     * 根据配置的sku和channel对用户历史订单进行过滤并返回有效订单次数
     *
     * @param purchaseLimit
     * @param historyOrders
     * @return
     */
    private long getOrderTimes(PurchaseLimit purchaseLimit, List<Order> historyOrders) {
        List<String> skus = purchaseLimit.getSkus();
        List<String> channelsLimit = purchaseLimit.getChannelsLimit();
        //sku和渠道都没有配置，直接返回point>0的订单数
        if (CollectionUtils.isEmpty(skus) && CollectionUtils.isEmpty(channelsLimit)) {
            return historyOrders.stream().filter(order -> order.point() > 0).count();
        }
        //配置了sku，没有配置渠道，根据sku进行过滤并返回sku的购买次数
        if (CollectionUtils.isEmpty(channelsLimit)) {
            return historyOrders.stream()
                    .filter(order -> order.point() > 0)
                    .map(Order::orderItems)
                    .flatMap(Collection::stream)
                    .filter(orderItem -> skus.contains(orderItem.getSku()))
                    .mapToInt(OrderItem::getPurchaseQty).sum();
        }
        //配置了渠道，没有配置sku，根据渠道进行过滤并返回该渠道的订单数
        if (CollectionUtils.isEmpty(skus)) {
            return historyOrders.stream()
                    .filter(order -> order.point() > 0 && channelsLimit.contains(order.channel()))
                    .count();
        }
        //sku和渠道都配置了，根据sku和渠道进行过滤并返回sku的购买次数
        return historyOrders.stream()
                .filter(order -> order.point() > 0 && channelsLimit.contains(order.channel()))
                .map(Order::orderItems)
                .flatMap(Collection::stream)
                .filter(orderItem -> skus.contains(orderItem.getSku()))
                .mapToInt(OrderItem::getPurchaseQty).sum();
    }

    /**
     * 判断purchaseLimit中是否配置了该规则
     *
     * @param purchaseLimit
     * @return
     */
    private boolean checkPurchaseLimit(PurchaseLimit purchaseLimit) {
        return purchaseLimit != null &&
                RedemptionQualificationType.MONTH.equals(purchaseLimit.getRedemptionQualificationType()) &&
                purchaseLimit.getMonth() >= 0;
    }
}
