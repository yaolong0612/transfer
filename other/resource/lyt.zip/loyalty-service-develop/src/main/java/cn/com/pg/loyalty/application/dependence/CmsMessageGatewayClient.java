package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: Ysnow
 * @Date: 2019/6/26 13:57
 * @Description:请求SMS的微服务
 */
// url = "https://qa-zuul-b2c.cn-xnp-cloud-pg.com.cn/api/cms-message-gateway/api"
@FeignClient(value = "cms-message-gateway")
public interface CmsMessageGatewayClient {

    /**
     * 请求SMS微服务
     * @param messageEntity
     * @return
     */
    @KpiLog(name = "CmsMessageGatewayClient-sendMessage", type = KpiLog.KpiType.API_CALL, timeout = 50, onlyFailure = true)
    @RequestMapping(value = "/api/message", method = RequestMethod.POST)
    String sendMessage(MessageEntity messageEntity);

    class MessageEntity {

        private String templateCode;
        @Desensitized(DesensitizedEnum.MOBILE_PHONE)
        private String mobile;
        private List<ParamEntity> paramEntityList = new ArrayList<>();
        private String brand;
        public static MessageEntity create(String templateCode, String mobile) {
            return new MessageEntity(templateCode, mobile);
        }

        public MessageEntity() {
        }

        public MessageEntity(String templateCode, String mobile) {
            super();
            this.templateCode = templateCode;
            this.mobile = mobile;
        }

        public MessageEntity(String templateCode, String mobile, List<ParamEntity> paramEntityList, String brand) {
            this.templateCode = templateCode;
            this.mobile = mobile;
            this.paramEntityList = paramEntityList;
            this.brand = brand;
        }
        public MessageEntity mobile(String mobile) {
            this.mobile = mobile;
            return this;
        }
        public MessageEntity templateCode(String templateCode) {
            this.templateCode = templateCode;
            return this;
        }
        public MessageEntity brand(String brand) {
            this.brand = brand;
            return this;
        }
        public MessageEntity putParam(String paramName, String paramValue) {
            ParamEntity paramEntity = new ParamEntity(paramName, paramValue);
            this.paramEntityList.add(paramEntity);
            return this;
        }
        public String getTemplateCode() {
            return templateCode;
        }

        public void setTemplateCode(String templateCode) {
            this.templateCode = templateCode;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public List<ParamEntity> getParamEntityList() {
            return paramEntityList;
        }

        public void setParamEntityList(List<ParamEntity> paramEntityList) {
            this.paramEntityList = paramEntityList;
        }

        public String getBrand() {
            return brand;
        }

        public void setBrand(String brand) {
            this.brand = brand;
        }
    }

    class ParamEntity {
        private String paramName;
        private String paramValue;

        public ParamEntity() {
        }

        public ParamEntity(String paramName, String paramValue) {
            this.paramName = paramName;
            this.paramValue = paramValue;
        }

        public String getParamName() {
            return this.paramName;
        }

        public void setParamName(String paramName) {
            this.paramName = paramName;
        }

        public String getParamValue() {
            return this.paramValue;
        }

        public void setParamValue(String paramValue) {
            this.paramValue = paramValue;
        }
    }
}
