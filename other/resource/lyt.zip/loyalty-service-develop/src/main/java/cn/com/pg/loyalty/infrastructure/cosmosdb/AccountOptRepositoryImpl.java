package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.account.AccountExtension.PartnerType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: Hayden
 * @CreateDate: 2021/3/5 16:57
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/5 16:57
 * @Version: 1.0
 * @Description:
 */
@Repository
@Slf4j
public class AccountOptRepositoryImpl implements AccountOptRepository {

    @Autowired
    private AccountOptJpaRepository accountOptJpaRepository;

    @Override
    public void save(AccountOpt accountOpt) {
        accountOptJpaRepository.save(accountOpt);
    }

    @Override
    public AccountOpt fetchAccountOptByLoyaltyId(String loyaltyId) {
        List<AccountOpt> accountOptList = accountOptJpaRepository
                .findAccountOptByLoyaltyIdAndType(loyaltyId, PartnerType.OPTION);
        return accountOptList.stream().findFirst().orElse(null);
    }
}
