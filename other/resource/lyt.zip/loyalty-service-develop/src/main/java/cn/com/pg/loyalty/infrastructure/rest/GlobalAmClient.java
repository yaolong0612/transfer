package cn.com.pg.loyalty.infrastructure.rest;


import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "GlobalAmClient", url = "${am.url}")
public interface GlobalAmClient {

    @PostMapping(value = "/api/authenticate", consumes = MediaType.APPLICATION_JSON_VALUE)
    AmToken generateToken(TokenRequestEntity entity, @RequestHeader("Ocp-Apim-Subscription-Key") String key);

    @GetMapping(value = "/am-service/api/am-user-detail/{memberId}", consumes = MediaType.APPLICATION_JSON_VALUE)
    AmDetailsResponse fetchAmDetail(@PathVariable String memberId, @RequestHeader("Ocp-Apim-Subscription-Key") String key,
                                    @RequestHeader("Authorization") String token);


    @Getter
    @Setter
    @NoArgsConstructor
    class AmToken {
        @JsonAlias(value = "id_token")
        private String idToken;

        public AmToken(String idToken) {
            this.idToken = idToken;
        }

        public String generateToken() {
            if (idToken == null) {
                throw new SystemException("Get token data error", ResultCodeMapper.CALL_AM_ERROR);
            }
            return "Bearer " + idToken;
        }
    }


    @Getter
    @Setter
    @NoArgsConstructor
    class TokenRequestEntity {
        private String username;
        private String password;
        private boolean rememberMe = true;

        public TokenRequestEntity(String username, String password, boolean rememberMe) {
            this.username = username;
            this.password = password;
            this.rememberMe = rememberMe;
        }
    }

    @Getter
    @Setter
    @NoArgsConstructor
    class AmDetailsResponse {
        private AmProfile profile;

        public AmDetailsResponse(String birthday) {
            this.profile = new AmProfile();
            this.profile.setBirthday(birthday);
        }
    }

    @Getter
    @Setter
    class AmProfile {
        //其它信息暂时不获取
        private String birthday;
    }

}
