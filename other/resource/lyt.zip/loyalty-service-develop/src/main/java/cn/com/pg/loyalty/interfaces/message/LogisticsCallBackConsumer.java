package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TaskService;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dependence.LogisticCallBackMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.transaction.RedemptionStatus;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author cooltea on 2019/6/22 10:35.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Component
@Slf4j
public class LogisticsCallBackConsumer extends AbstractConsumer {

    private ServiceBusQueueTopicEnum LOGISTICS_QUEUE_NAME = ServiceBusQueueTopicEnum.LOGISTICS_CALL_BACK_QUEUE;

    @Autowired
    private TaskService taskService;
    @Autowired
    private TransactionService transactionService;

    @Override
    protected void doBusiness(JSONObject message) {
        LogisticCallBackMessage logisticMsg = JSON.toJavaObject(message, LogisticCallBackMessage.class);
        RedemptionStatus status = RedemptionStatus.DELIVERED;
        if (logisticMsg.getStatus() == LogisticCallBackMessage.StatusEnum.REJECTED) {
            transactionService.rejectRedemption("ML",logisticMsg.getBrand(),
                    logisticMsg.getMemberId(),logisticMsg.getTransactionId(),null,"rejected by logistics");
        } else {
            taskService.updateLogisticsStatus(logisticMsg.getTransactionId(), logisticMsg.getDeliverCompany(),
                    status, logisticMsg.getReason(), logisticMsg.getMemberId(), logisticMsg.getBrand(), logisticMsg.getDeliveryNumber());
        }
        log.info("任务【物流状态更新队列】处理完成.........");
    }

    @Override
    protected String getLabel() {
        return LOGISTICS_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return LOGISTICS_QUEUE_NAME;
    }
}
