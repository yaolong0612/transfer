package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class OrderPassedCustomProperties extends RuleProperties{

    private List<String> channels;
    private LocalDateTime customTime;
}
