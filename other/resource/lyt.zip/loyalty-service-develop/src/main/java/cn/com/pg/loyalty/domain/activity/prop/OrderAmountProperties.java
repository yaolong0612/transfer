package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Ladd
 * @description
 **/
@Getter
@Setter
public class OrderAmountProperties extends RuleProperties {

    /**
     * 积分计算比率
     */
    private double rate;

    /**
     * 积分计算取整方式，ceil/floor/round
     */
    private Compute compute;

    /**
     * 积分计算取整方式
     */
    public enum Compute {
        CEIL,FLOOR,ROUND
    }



}
