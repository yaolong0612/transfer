package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.prop.NumMappingPoint;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION;

/**
 * @description:
 * @author: Artermus wang on 2022-01-23 14:15
 */
@Rule(name = "礼品兑换次数校验",
        description = "redemption valid check", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
public class CheckTimesAndQuantityLimitRule {


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        return ruleProperties.getRedemptionTimesCalculationType() != null
                || ruleProperties.getTotalLimitQuantity() > 0;
    }

    @Action
    public void checkRedemptionTimes(
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords,
            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {


        validTotalQuantityLimit(redemptionRecords, redemption, ruleProperties);
        validPeriodLimit(redemptionRecords, redemption, ruleProperties);
    }

    private void validPeriodLimit(List<Redemption> redemptionRecords, Redemption redemption,
                                  RedemptionProperties ruleProperties) {
        if (ruleProperties.getRedemptionTimesCalculationType() == null) {
            return;
        }
        List<NumMappingPoint> numMappingPoints = ruleProperties.limitTime();
        for (NumMappingPoint numMappingPoint : numMappingPoints) {
            log.info("CheckRedemptionTimesByQuarter规则：{}", JSON.toJSONString(numMappingPoint));
            LocalDateTime startTime = ruleProperties.getRedemptionTimesCalculationType()
                    .searchStartTime(numMappingPoint.num());
            ruleProperties.getLimitType().validLimit(redemptionRecords, startTime,
                    redemption.getGiftItemList(), numMappingPoint.pointOrSize());
        }
    }

    private void validTotalQuantityLimit(List<Redemption> redemptionRecords,
                                         Redemption redemption, RedemptionProperties ruleProperties) {
        if (ruleProperties.getTotalLimitQuantity() <= 0) {
            return;
        }
        List<Redemption> allRecords = new ArrayList<>(redemptionRecords);
        allRecords.add(redemption);
        int redemptionQuantity = allRecords.stream()
                .map(Redemption::getGiftItemList).flatMap(Collection::stream)
                .filter(GiftItem::effective)
                .mapToInt(GiftItem::getQuantity).sum();
        if (redemptionQuantity > ruleProperties.getTotalLimitQuantity()) {
            throw new SystemException("exceeds the total gift limitation of times", ResultCodeMapper.LIMIT_ERROR);
        }
    }
}
