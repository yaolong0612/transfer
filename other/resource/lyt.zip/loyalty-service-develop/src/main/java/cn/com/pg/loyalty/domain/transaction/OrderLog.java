package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-27 11:04
 */

@Getter
@Setter
@Document(collection = "OrderLog", ru = "400")
@Slf4j
@NoArgsConstructor
public class OrderLog {

    @Id
    private String id;
    @PartitionKey
    private String partitionKey;
    private String orderId;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    private Order order;

    public OrderLog(Order order) {
        this.id = UUIDUtil.generator();
        this.order = order;
        this.orderId = order.getOrderId();
        this.createdTime = LocalDateTime.now();
        this.partitionKey = order.partitionKey();
    }
}
