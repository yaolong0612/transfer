package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.MindTreeMessageClient;
import cn.com.pg.loyalty.application.dependence.SmpMessageClient;
import cn.com.pg.loyalty.application.dto.HktwNotificationDTO;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.RegionV2;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class HktwNotificationService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private SmpMessageClient smpMessageClient;

    @Autowired
    private MindTreeMessageClient mindTreeMessageClient;

    @Autowired
    private InteractionRepository interactionRepository;

    private static final String COMPANY_CODE = "PMPS-TWN";
    private static final String HKTWPAMPERS_SENDMESSAGE_PREFIX = "HKTWPAMPERSNOTIFY:SENDMESSAGE:";
    private static final String SMP_SENDMESSAGE_TOKEN = "HKTWPAMPERSNOTIFY:SMP:TOKEN";
    private static final Long SMP_SENDMESSAGE_TOKEN_EXPIRED = 25L;

    private static final Map<String, String> MESSAGE_CONTENT = new HashMap<>();
    private static final String MESSAGE_MISSION_SUFFIX = "_MISSION";
    private static final String MESSAGE_POINT_EXPIRED_SUFFIX = "_POINT_EXPIRED";
    private static final DateTimeFormatter MESSAGE_POINT_EXPIRED_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter MINDTREE_POINT_EXPIRED_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String BABY_BIRTH_POINTTYPE_PREFIX = "BABY_BIRTHDAY_MONTH";

    @Value("${smp.username}")
    private String userName;

    @Value("${smp.password}")
    private String password;

    @Value("${smp.url}")
    private String smpUrl;

    @Value("${mind-tree.subscription-key}")
    private String mindTreeSubscriptionKey;

    @Autowired
    private CacheService cacheService;

    static {
        /**
         *
         * Point expiration message:
         * TW : 你尚餘的500分將於10/8/2019到期, 請於到期日前盡快兌換禮品。謝謝！
         * Mission complete message:
         * TW : 恭喜您已成功完成此積分任務 - MISSION_NAME！您目前總積分為500。請前往禮品區兌換喜歡的禮品，謝謝。
         */
        MESSAGE_CONTENT.put("TW_PAMPERS" + MESSAGE_MISSION_SUFFIX, "恭喜您已成功完成此積分任務 - %s！您目前總積分為%s。請前往禮品區兌換喜歡的禮品，謝謝。");
        MESSAGE_CONTENT.put("TW_PAMPERS" + MESSAGE_POINT_EXPIRED_SUFFIX, "你尚餘的%s分將於%s到期, 請於到期日前盡快兌換禮品。謝謝！");
    }

    public void sendMissionMessage(Account account, String pointType, String transactionId) {
        if (Transaction.PointTypeEnum.REGISTER.name().equals(pointType) && isRegisterMission(account, transactionId)) {
            sendMessage(account, HktwNotificationDTO.MessageType.REGISTER);
            // 发送成功，缓存1天
            stringRedisTemplate.opsForValue().set(HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.REGISTER.name()).concat(":").concat(account.loyaltyId()), "true", 1L, TimeUnit.DAYS);
        } else if (Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType) && isFirstScanMission(account, transactionId)) {
            // 首次扫码
            sendMessage(account, HktwNotificationDTO.MessageType.SCAN_CODE_FIRST);
            stringRedisTemplate.opsForValue().set(HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.SCAN_CODE_FIRST.name()).concat(":").concat(account.loyaltyId()), "true", 30L, TimeUnit.DAYS);
        } else if (Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType) && isSecScanMission(account, transactionId)) {
            //当月第二次扫码
            sendMessage(account, HktwNotificationDTO.MessageType.SCAN_CODE_MONTH_SECOND);
            stringRedisTemplate.opsForValue().set(HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.SCAN_CODE_MONTH_SECOND.name()).concat(":").concat(account.loyaltyId()), "true", 30L, TimeUnit.DAYS);
        } else if (pointType.contains(BABY_BIRTH_POINTTYPE_PREFIX) && isBabyBirthMission(account, transactionId)) {
            sendMessage(account, HktwNotificationDTO.MessageType.BABY_BIRTHDAY);
            stringRedisTemplate.opsForValue().set(HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.BABY_BIRTHDAY.name()).concat(":").concat(account.loyaltyId()), "true", 1L, TimeUnit.DAYS);
        }
    }

    public void sendPointExpiredMessage(Account account) {
        String loyaltyId = account.loyaltyId();
        String key = HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.POINT_EXPIRED.name()).concat(":").concat(loyaltyId);
        String flag = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(flag)) {
            log.info("loyaltyId: {}, 已有对应的call smp api记录", loyaltyId);
            return;
        }
        sendMessage(account, HktwNotificationDTO.MessageType.POINT_EXPIRED);
        LocalDateTime currentDay = LocalDateTime.now();
        LocalDateTime lastDayOfThisMonth = LoyaltyDateTimeUtils.getLastDayOfThisMonth();
        Duration duration = Duration.between(currentDay, lastDayOfThisMonth);
        long expiredTime = duration.toMillis();
        stringRedisTemplate.opsForValue().set(HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.POINT_EXPIRED.name()).concat(":").concat(account.loyaltyId()), "true", expiredTime, TimeUnit.MILLISECONDS);
    }

    private boolean isRegisterMission(Account account, String transactionId) {
        String loyaltyId = account.loyaltyId();
        String key = HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.REGISTER.name()).concat(":").concat(loyaltyId);
        String flag = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(flag)) {
            log.info("loyaltyId: {}, 已有对应的call smp api记录", loyaltyId);
            return false;
        }
        List<Interaction> interactionList = interactionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        if (CollectionUtils.isEmpty(interactionList)) {
            return false;
        }
        Interaction interaction = interactionList.get(0);
        LocalDateTime createdTime = account.getCreatedTime();
        LocalDateTime updatedTime = account.getUpdatedTime();
        Duration duration = Duration.between(createdTime, updatedTime);
        long internal = duration.toMillis();
        // 如果更新时间-创建时间在1s内,表明是注册
        return internal < 1000L || Transaction.PointTypeEnum.REGISTER.name().equals(interaction.getPointType());
    }

    private void sendMessage(Account account, HktwNotificationDTO.MessageType messageType) {
        LoyaltyStructure structure=cacheService.findLoyaltyStructure(account);
        String region = account.getRegion();
        if (RegionV2.isTwRegion(region)) {
            String lineId = account.bindId(BrandV2.PAMPERS, ChannelV2.LINE);
            String messageContent = getMessageContent(structure, messageType, account);
            callSmpApi(account.loyaltyId(), lineId, messageContent);
        } else if (RegionV2.isHkRegion(region) && HktwNotificationDTO.MessageType.POINT_EXPIRED == messageType) {
            // hk只有发送积分即将过期消息
            Integer pointsAboutToExpire = account.pointAboutExpire(structure.accountTypeOfDefault());
            LocalDateTime lastDayOfThisMonth = LoyaltyDateTimeUtils.getLastDayOfThisMonth();
            String expiryDate = lastDayOfThisMonth.format(MINDTREE_POINT_EXPIRED_FORMATTER);
            callMindTreeApi(account.memberId(), pointsAboutToExpire, expiryDate);
        }
    }

    private boolean isFirstScanMission(Account account, String transactionId) {
        String loyaltyId = account.loyaltyId();
        String key = HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.SCAN_CODE_FIRST.name()).concat(":").concat(loyaltyId);
        String flag = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(flag)) {
            log.info("loyaltyId: {}, 存在对应的call smp api记录", loyaltyId);
            return false;
        }
        List<Interaction> interactionList =
                interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), Transaction.PointTypeEnum.SCAN_CODE.name(), loyaltyId, BrandV2.PAMPERS);
        if (CollectionUtils.isEmpty(interactionList)) {
            return false;
        }
        Comparator<Interaction> comparator = Comparator.comparing(Interaction::getCreatedTime);
        interactionList.sort(comparator);
        Interaction firstScanInteraction = interactionList.get(0);
        return transactionId.equals(firstScanInteraction.getId());
    }

    private boolean isSecScanMission(Account account, String transactionId) {
        String loyaltyId = account.loyaltyId();
        String key = HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.SCAN_CODE_MONTH_SECOND.name()).concat(":").concat(loyaltyId);
        String flag = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(flag)) {
            log.info("loyaltyId: {}, 存在对应的call smp api记录", loyaltyId);
            return false;
        }
        LocalDateTime firstDayOfThisMonth = LoyaltyDateTimeUtils.getFirstDayOfThisMonth();
        LocalDateTime lastDayOfThisMonth = LoyaltyDateTimeUtils.getLastDayOfThisMonth();
        List<Interaction> interactionList = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), Transaction.PointTypeEnum.SCAN_CODE.name(), loyaltyId,
                BrandV2.PAMPERS, LoyaltyDateTimeUtils.localDateTimeToString(firstDayOfThisMonth),
                LoyaltyDateTimeUtils.localDateTimeToString(lastDayOfThisMonth));
        if (CollectionUtils.isEmpty(interactionList)) {
            return false;
        }
        Comparator<Interaction> comparator = Comparator.comparing(Interaction::getCreatedTime);
        interactionList.sort(comparator);
        // 取当月第二次扫码记录，对比transactionId是否一致
        if (CollectionUtils.isNotEmpty(interactionList) && interactionList.size() > 1) {
            Interaction secMonthInteraction = interactionList.get(1);
            return secMonthInteraction.getId().equals(transactionId);
        }
        return false;
    }


    private boolean isBabyBirthMission(Account account, String transactionId) {
        String loyaltyId = account.loyaltyId();
        String key = HKTWPAMPERS_SENDMESSAGE_PREFIX.concat(HktwNotificationDTO.MessageType.BABY_BIRTHDAY.name()).concat(":").concat(loyaltyId);
        String flag = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(flag)) {
            log.info("loyaltyId: {}, 当月已有对应的call smp api记录", loyaltyId);
            return false;
        }
        List<Interaction> interactionList = interactionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        if (CollectionUtils.isEmpty(interactionList)) {
            return false;
        }
        Interaction interaction = interactionList.get(0);
        return interaction.getPointType().contains(BABY_BIRTH_POINTTYPE_PREFIX);
    }

    public String getMessageContent(LoyaltyStructure loyaltyStructure, HktwNotificationDTO.MessageType messageType, Account account) {
        String messageContent = null;
        switch (messageType) {
            case REGISTER:
            case BABY_BIRTHDAY:
            case SCAN_CODE_FIRST:
            case SCAN_CODE_MONTH_SECOND:
                messageContent = MESSAGE_CONTENT.get(loyaltyStructure.name() + MESSAGE_MISSION_SUFFIX);
                messageContent = String.format(messageContent, messageType.getDescription(), account.availablePoint(loyaltyStructure.accountTypeOfDefault()));
                return messageContent;
            case POINT_EXPIRED:
                messageContent = MESSAGE_CONTENT.get(loyaltyStructure.name() + MESSAGE_POINT_EXPIRED_SUFFIX);
                LocalDateTime lastDayOfThisMonth = LoyaltyDateTimeUtils.getLastDayOfThisMonth();
                messageContent = String.format(messageContent, account.pointAboutExpire(loyaltyStructure.accountTypeOfDefault()), MESSAGE_POINT_EXPIRED_FORMATTER.format(lastDayOfThisMonth));
                return messageContent;
            default:
                return messageContent;
        }
    }

    public String generateSmpToken() {
        String token = stringRedisTemplate.opsForValue().get(SMP_SENDMESSAGE_TOKEN);
        if (StringUtils.isNotEmpty(token)) {
            return token;
        }
        SmpMessageClient.TokenRequestEntity tokenRequestEntity = new SmpMessageClient.TokenRequestEntity();
        tokenRequestEntity.setPassword(password);
        tokenRequestEntity.setUsername(userName);
        tokenRequestEntity.setRememberMe(true);
        log.info("call smpApi => username:{},password:{},url:{}", userName, password, smpUrl);
        SmpMessageClient.CallSmpResponse callSmpResponse = smpMessageClient.generateToken(tokenRequestEntity);
        token = "Bearer ".concat(callSmpResponse.getId_token());
        stringRedisTemplate.opsForValue().set(SMP_SENDMESSAGE_TOKEN, token, SMP_SENDMESSAGE_TOKEN_EXPIRED, TimeUnit.MINUTES);
        return token;
    }

    public void callSmpApi(String loyaltyId, String lineId, String messageContent) {
        if (StringUtils.isEmpty(lineId)) {
            log.info("loyaltyId:{}的lineId为空！", loyaltyId);
            throw new SystemException("调用smpApi传入的lineId为空", ResultCodeMapper.PARAM_ERROR);
        }
        try {
            String token = generateSmpToken();
            SmpMessageClient.SendMessageRequestEntity requestEntity = new SmpMessageClient.SendMessageRequestEntity();
            requestEntity.setCompanyCode(COMPANY_CODE);
            List<String> contents = new ArrayList<>();
            contents.add(messageContent);
            requestEntity.setLineId(lineId);
            requestEntity.setContents(contents);
            SmpMessageClient.CallSmpResponse callSmpResponse = smpMessageClient.sendMessage(requestEntity, token);
            log.info("call smp api success，response: {}, memberId {}", JSON.toJSONString(callSmpResponse), loyaltyId);
        } catch (Exception e) {
            log.error("call smp api error: {}", e.getMessage());
            throw new SystemException("调用smpApi失败！", ResultCodeMapper.CALL_SMP_ERROR);
        }
    }

    private void callMindTreeApi(String memberId, Integer pointsAboutToExpire, String expiryDate) {
        try {
            MindTreeMessageClient.SendMessageRequestItem sendMessageRequestItem = new MindTreeMessageClient.SendMessageRequestItem(memberId, pointsAboutToExpire, expiryDate);
            List<MindTreeMessageClient.SendMessageRequestItem> requestEntity = new ArrayList<>();
            requestEntity.add(sendMessageRequestItem);
            mindTreeMessageClient.sendPointExpiredMessage(requestEntity, mindTreeSubscriptionKey);
        } catch (Exception e) {
            log.error("call mindTree api error: {}", e.getMessage());
            throw new SystemException("调用mindTreeApi失败！", ResultCodeMapper.CALL_MINDTREE_ERROR);
        }
    }

}
