package cn.com.pg.loyalty.infrastructure.rest;

import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

//https://qa-zuul-b2c.cn-xnp-cloud-pg.com.cn/api/micro-service-coupon/v2/api/coupon/instance
@FeignClient(value = "micro-service-coupon")
//@FeignClient(name = "coupon",url = "https://qa-zuul-b2c.cn-xnp-cloud-pg.com.cn/api/micro-service-coupon")
public interface CouponRequestClient {

    /**
     * 添加券
     */
    @PostMapping(value = "/v2/api/coupon/instance", consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "CouponRequestClient-getInstance", type = KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 500)
    ResultDTO instanceCoupon(@RequestBody InstanceEntity requestEntity);

    /**
     * 取消兑换
     */
    @PostMapping(value = "/v2/api/coupon/cancel", consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "CouponRequestClient-getCancel", type = KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 500)
    ResultDTO cancelCoupon(@RequestBody CancelEntity cancelEntity);

    /**
     * 核销券
     */
    @PostMapping(value = "/v2/api/coupon/redemption", consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "CouponRequestClient-getRedemption", type = KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 500)
    ResultDTO redemptionCoupon(@RequestBody RedemptionEntity redemptionEntity);

    @Getter
    @Setter
    @ToString
    class ResultDTO {
        private String couponTemplateId;
        private String couponId;
        private String outerCouponId;
        private String memberId;
        private String memberIdExtra;
        private String code;
        private String sendCouponTime;
        private String verified;
        private String verifyTime;
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime startTime;
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime endTime;
        private String couponTemplate;
        private String platformName;
        private String appId;
        private String channel;
        private String source;
        private String errorCode;
        private String errorMessage;
    }

    @Setter
    @Getter
    @ToString
    @NoArgsConstructor
    class InstanceEntity {

        private String couponTemplateId;

        private String platformName;

        private CouponUser user;

        public InstanceEntity(String memberId, String couponTemplateId, String platformName) {
            this.user = new CouponUser(memberId, null, null);
            this.couponTemplateId = couponTemplateId;
            this.platformName = platformName;
        }
    }

    @Setter
    @Getter
    @ToString
    @AllArgsConstructor
    class CouponUser {

        private String memberId;

        private String unionId;

        private String userId;

    }

    @Setter
    @Getter
    @ToString
    class CancelEntity {

        private String couponTemplateId;

        private String code;

        private String platformName;

        private boolean needReturnPoint;

        private CouponUser user;

        public CancelEntity(String couponTemplateId, String code, String platformName,
                            boolean needReturnPoint, String memberId) {
            this.couponTemplateId = couponTemplateId;
            this.code = code;
            this.platformName = platformName;
            this.needReturnPoint = needReturnPoint;
            this.user = new CouponUser(memberId, null, null);
        }
    }

    @Setter
    @Getter
    @ToString
    @AllArgsConstructor
    class RedemptionEntity {

        private String couponTemplateId;

        private String code;

        private String platformName;

        private String verificationTime;

        private CouponUser user;

        public RedemptionEntity(String couponTemplateId, String code, String platformName,
                                String verificationTime, String memberId) {
            this.couponTemplateId = couponTemplateId;
            this.code = code;
            this.platformName = platformName;
            this.verificationTime = verificationTime;
            this.user = new CouponUser(memberId, null, null);
        }
    }
}
