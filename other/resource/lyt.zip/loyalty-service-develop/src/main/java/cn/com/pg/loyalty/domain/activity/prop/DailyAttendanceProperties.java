package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Getter
@Setter
public class DailyAttendanceProperties extends RuleProperties {

    @Min(0)
    @NotNull
    private Integer basePoint;
    @Min(1)
    @NotNull
    private Integer incrementPoint;
    @Min(0)
    @NotNull
    private Integer maxPoint;
}
