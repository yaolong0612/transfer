package cn.com.pg.loyalty.application.dependence;

import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

/**
 * @author tangjia
 * @date 2019/6/6
 * @description LoyaltyMessage
 */
@Getter
@Setter
@ToString
public class LoyaltyMessage {
    /**
     * 消息主键
     */
    private String id;
    /**
     * 消息名称
     */
    private String name;
    /**
     * 消息参数
     */
    private String param;
    /**
     * 消息状态
     */
    private Character status;
    /**
     * 创建日期
     */
    private String createDate;
    /**
     * 最后更新时间
     */
    private LocalDateTime updateTime;
    /**
     * 发送次数
     */
    private int count;
    /**
     * 若是自己封装的参数可使用此属性
     */
    private JSONObject jsonObject;
}
