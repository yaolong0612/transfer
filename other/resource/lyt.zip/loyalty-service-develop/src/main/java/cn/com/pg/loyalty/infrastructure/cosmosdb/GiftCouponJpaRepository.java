package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCoupon.CouponStatus;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface GiftCouponJpaRepository extends DocumentDbRepository<GiftCoupon,String> {

    List<GiftCoupon> findByBagSkuAndRegionAndBrandAndCouponCode(String sku, String region, String brand, String code);

    List<GiftCoupon> findByBagSkuAndRegionAndBrandAndStatusAndUpdatedTimeGreaterThan(String bagSku, String region, String brand, CouponStatus status, LocalDateTime updatedTime);

    List<GiftCoupon> findByMemberIdAndBrandAndRegion(String memberId, String brand, String region);

    List<GiftCoupon> findByMemberIdAndBrandAndRegionAndTransactionId(String memberId, String brand, String region, String transactionId);

    List<GiftCoupon> findByBagSku(String bagSku);

    GiftCoupon findTopByBagSku(String bagSku,String brand, String region);

    List<GiftCoupon> findByRegionAndBrandAndStoreName(String region, String brand,String storeName);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSku(String region, String brand,String storeName,String bagSku);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndCreatedTimeBetween(String region, String brand, String storeName, String start, String end);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSkuAndCreatedTimeBetween(String region, String brand, String storeName, String bagSku, String start, String end);

    List<GiftCoupon> findByRegionAndBrandAndCouponCode(String region, String brand, String couponCode);
}
