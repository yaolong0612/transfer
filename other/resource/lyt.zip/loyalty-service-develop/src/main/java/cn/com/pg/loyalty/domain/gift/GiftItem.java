package cn.com.pg.loyalty.domain.gift;

import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * @author Simon
 * 礼品条目
 */
@Getter
@Setter
@NoArgsConstructor
public class GiftItem implements ValueObject<GiftItem> {

    /**
     *
     */
    private static final long serialVersionUID = 4485091510509709622L;

    private String sku;

    private String name;

    private Integer quantity;


    public GiftItem(String sku, String name, Integer quantity) {
        this.sku = sku;
        this.name = name;
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        GiftItem giftItem = (GiftItem) o;

        return new EqualsBuilder()
                .append(quantity, giftItem.quantity)
                .append(sku, giftItem.sku)
                .append(name, giftItem.name)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(sku)
                .append(name)
                .append(quantity)
                .toHashCode();
    }

    @Override
    public boolean sameValueAs(GiftItem other) {
        return this.equals(other);
    }

}
