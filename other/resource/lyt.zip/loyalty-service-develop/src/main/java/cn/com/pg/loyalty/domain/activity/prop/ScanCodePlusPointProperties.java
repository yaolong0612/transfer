package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.HibernateValidator;

import javax.validation.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author: Ysnow
 * @Date: 2019/5/30 13:55
 * @Description:扫码加积分属性
 */
@Setter
@Getter
public class ScanCodePlusPointProperties extends RuleProperties {

    /**
     * 每个月的最多扫码加积分次数。
     */
    private int limitMaxQuantity;

    /**
     * 基础加积分的属性
     */
    @Valid
    @NotNull
    private List<ScanCodeBasicRewardPoints> scanCodeBasicRewardPointsList;

    /**
     * 额外加积分的属性
     */
    @Valid
    private ScanCodeBonusPoints scanCodeBonusPoints;

    public ScanCodePlusPointProperties() {
        scanCodeBasicRewardPointsList = new ArrayList<>();
    }

    public ScanCodePlusPointProperties(int limitMaxQuantity, List<ScanCodeBasicRewardPoints> scanCodeBasicRewardPointsList, ScanCodeBonusPoints scanCodeBonusPoints) {
        this.limitMaxQuantity = limitMaxQuantity;
        this.scanCodeBasicRewardPointsList = scanCodeBasicRewardPointsList;
        this.scanCodeBonusPoints = scanCodeBonusPoints;
    }

}
