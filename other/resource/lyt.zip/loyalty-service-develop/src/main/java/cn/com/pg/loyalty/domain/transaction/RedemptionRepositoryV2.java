package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.Account;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RedemptionRepositoryV2 {
    List<Redemption> findInActivityNotInRedemptionStatus(Account account, String activityId,List<String> status);
}
