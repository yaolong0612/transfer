package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @author LMR
 */
@Rule(name = "CheckLimitQuantityRule", description = "组内及挡位内礼品兑换数量限制规则", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION,
        ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
public class CheckLimitQuantityRule {
    @Condition
    public boolean matchRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                             @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                             @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        // 分组或挡位最大限制兑换数量设置大于0则进入规则
        return redemption.getGiftItemList().stream()
                .anyMatch(giftItem -> properties.fetchTotalLimitQuantity(activity.getGifts(), giftItem) > 0);
    }

    @Action
    public void checkLimitQuantity(@Fact(RULE_PARAM_ACTIVITY) Activity activity,
                                   @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                                   @Fact(RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords,
                                   @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties) {
        List<Redemption> allRecords = new ArrayList<>(redemptionRecords);
        allRecords.add(redemption);
        for (GiftItem giftItem : redemption.getGiftItemList()) {
            if (properties.fetchTotalLimitQuantity(activity.getGifts(), giftItem) <= 0) {
                continue;
            }
            String name = properties.fetchName(activity.getGifts(), giftItem);
            // 根据组或挡位统计礼品
            int redemptionQuantity = allRecords.stream()
                    .map(Redemption::getGiftItemList)
                    .flatMap(Collection::stream)
                    .filter(item -> item.effective() &&
                            StringUtils.isNotEmpty(properties.fetchName(activity.getGifts(), item)) &&
                            name.equals(properties.fetchName(activity.getGifts(), item)))
                    .mapToInt(GiftItem::getQuantity).sum();
            if (properties.fetchTotalLimitQuantity(activity.getGifts(), giftItem) < redemptionQuantity) {
                throw new SystemException("超出兑换次数限制", ResultCodeMapper.LIMIT_ERROR);
            }
        }
    }
}
