package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

/**
 * @Author: Hayden
 * @CreateDate: 2021/3/19 10:20
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/19 10:20
 * @Version: 1.0
 * @Description:
 */
@Document(collection = "AccountExtension", ru = "400")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class AccountExtension {
    /**
     * 唯一Loyalty ID
     */
    @Id
    protected String id;

    protected String loyaltyId;

    @PartitionKey
    protected String partitionKey;

    protected String memberId;

    protected String marketingProgramId;

    protected PartnerType type;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime updatedTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime createdTime;

    public AccountExtension(String memberId, String marketingProgramId, String loyaltyId, PartnerType type) {
        this.memberId = memberId;
        this.marketingProgramId = marketingProgramId;
        this.loyaltyId = loyaltyId;
        this.id = UUIDUtil.generator();
        this.type = type;
        this.partitionKey = PartitionKeyUtils.getAccountPartitionKey(loyaltyId);
        this.updatedTime = LocalDateTime.now();
        this.createdTime=LocalDateTime.now();
    }


    public  enum PartnerType {
        /**
         * 设置opt in/out
         */
        OPTION;
    }
}
