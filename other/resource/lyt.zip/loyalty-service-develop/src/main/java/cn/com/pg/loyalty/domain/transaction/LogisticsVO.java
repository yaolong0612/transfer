package cn.com.pg.loyalty.domain.transaction;


import lombok.*;

@Getter
@Builder
public class LogisticsVO {

    @NonNull
    private String receiver;
    @NonNull
    private String phone;

    private String postalCode;
    @NonNull
    private String province;
    @NonNull
    private String city;
    @NonNull
    private String district;
    @NonNull
    private String address;
    @NonNull
    private String addressCode;

    private String email;

}
