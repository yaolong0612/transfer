package cn.com.pg.loyalty;

import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.interfaces.web.SystemFilter;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.ehcache.Cache;
import org.ehcache.config.builders.ExpiryPolicyBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.ehcache.config.builders.UserManagedCacheBuilder;
import org.ehcache.config.units.MemoryUnit;
import org.ehcache.expiry.ExpiryPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.TimeZone;

/**
 * @author Simon
 * @date 2019年4月22日下午3:44:16
 * Loyalty-Service启动类
 */
@SpringBootApplication
@EnableSwagger2
@EnableEurekaClient
@EnableFeignClients
@Slf4j
public class LoyaltyApplication {

    public static final String APP_NAME = "cms-loyalty-service";
    public static final String TW_PROFILE = "tw";
    public static final String JP_PROFILE = "jp";

    @Autowired
    private ApplicationContext context;


    public static void main(String[] args) {
        log.info("+++++++============+++++++：Loyalty-Service run version: 1.8.0");
        SpringApplication.run(LoyaltyApplication.class, args);
        log.info("+++++++============+++++++：Loyalty-Service is OK!!: 1.8.0");
    }

    @PostConstruct
    void setDefaultTimezone() {
        List<String> profiles = Arrays.asList(context.getEnvironment().getActiveProfiles());
        if (profiles.contains(JP_PROFILE)) {
            TimeZone.setDefault(TimeZone.getTimeZone(ZoneOffset.UTC));
            return;
        }
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
    }


    @PostConstruct
    void initPartitionKey() {
        List<String> profiles = Arrays.asList(context.getEnvironment().getActiveProfiles());
        log.info("...............init partitionKey starting {}...........", JSON.toJSONString(profiles));
        int accountPartitionNum = 64;
        int accountVirtualNum = 128;
        int transactionPartitionNum = 512;
        int transactionVirtualNum = 512;
        if (profiles.contains(TW_PROFILE)) {
            log.info("init partitionKey region is: {}", TW_PROFILE);
            accountPartitionNum = 4;
            accountVirtualNum = 16;
            transactionPartitionNum = 16;
            transactionVirtualNum = 64;
        }
        PartitionKeyUtils.initAccount(accountPartitionNum, accountVirtualNum);
        PartitionKeyUtils.initTransaction(transactionPartitionNum, transactionVirtualNum);
        log.info("...............init partitionKey ended ..............");
    }

    /**
     * 配置Filter
     */
    @Bean
    @Order(Integer.MIN_VALUE)
    @Qualifier("apiMonitoringFilter")
    public FilterRegistrationBean<SystemFilter> apiMonitoringFilter() {
        FilterRegistrationBean<SystemFilter> registration = new FilterRegistrationBean<>();
        // 注入Filter
        registration.setFilter(new SystemFilter());
        // 拦截规则
        registration.addUrlPatterns("/*");
        return registration;
    }

    @Primary
    @Bean(name = "cosmosdbObjectMapper")
    public ObjectMapper objectMapper() {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(OffsetDateTime.class, new JsonSerializer<OffsetDateTime>() {
            @Override
            public void serialize(OffsetDateTime offsetDateTime, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
                jsonGenerator.writeString(DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(offsetDateTime));
            }
        });
        objectMapper.registerModule(simpleModule);
        objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        return objectMapper;
    }

    @Bean(name = "redisTemplate")
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(Object.class));
        redisTemplate.afterPropertiesSet();
        return redisTemplate;
    }

    /**
     * 初始化restTemplate
     *
     * @return
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean(name = "systemMemoryCache")
    public Cache<String, Object> memoryCache() {
        log.info("init the memory cache");
        //创建Resource Pool，放到内存中，不持久化. 缓存大小为500M
        ResourcePoolsBuilder resourcePoolsBuilder =
                ResourcePoolsBuilder.newResourcePoolsBuilder().heap(500, MemoryUnit.MB);
        //配置过期策略，从创建时2分钟过期，后面根据内存使用情况进行调整
        ExpiryPolicy<Object, Object> expiryPolicy =
                ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofMinutes(2));

        return UserManagedCacheBuilder.newUserManagedCacheBuilder(String.class, Object.class)
                .withResourcePools(resourcePoolsBuilder)
                .withSizeOfMaxObjectGraph(10000L)
                .withExpiry(expiryPolicy)
                .build(true);
    }

}
