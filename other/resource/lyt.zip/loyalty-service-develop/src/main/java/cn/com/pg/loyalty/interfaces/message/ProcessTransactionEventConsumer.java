package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.EventAppService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.dto.Event;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/10
 */
@Slf4j
@Component
public class ProcessTransactionEventConsumer extends AbstractConsumerV2 {

    @Autowired
    private EventAppService eventAppService;
    @Autowired
    private Validator validator;

    @Override
    protected void doBusiness(JSONObject message) {
        Event event = JSON.toJavaObject(message, Event.class);
        Set<ConstraintViolation<Event>> violationSet = validator.validate(event);
        if (!CollectionUtils.isEmpty(violationSet)) {
            throw new SystemException("Event param error", ResultCodeMapper.PARAM_ERROR);
        }
        eventAppService.processEvent(event);
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_TRANSACTION_EVENT;
    }
}
