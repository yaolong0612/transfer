package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountService;
import cn.com.pg.loyalty.application.HktwNotificationService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.application.dto.HktwNotificationDTO;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 * @author YAOZL
 */
@Component
@Slf4j
public class HktwPampersMessageConsumer extends AbstractConsumer{

    @Autowired
    private HktwNotificationService hktwNotificationService;

    @Autowired
    private AccountService accountService;

    private static final String MESSAGE_TYPE_MISSION = "MISSION";
    private static final String MESSAGE_TYPE_POINT_EXPIRED = "POINT_EXPIRED";

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        LocalDateTime start = LocalDateTime.now();
        HktwNotificationDTO hktwNotificationMessage = JSON.toJavaObject(jsonObject, HktwNotificationDTO.class);
        String messageType = hktwNotificationMessage.getMessageType();
        String loyaltyId = hktwNotificationMessage.getLoyaltyId();
        String pointType = hktwNotificationMessage.getPointType();
        String transactionId = hktwNotificationMessage.getTransactionId();
        Account account = accountService.fetchAccountByLoyaltyId(loyaltyId);
        if (account == null) {
            log.error("loyaltyId: {}, 查无account", loyaltyId);
            throw new SystemException("ACCOUNT_NOT_FOUND", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        if(MESSAGE_TYPE_MISSION.equals(messageType)){
            hktwNotificationService.sendMissionMessage(account, pointType, transactionId);
        }else if(MESSAGE_TYPE_POINT_EXPIRED.equals(messageType)){
            hktwNotificationService.sendPointExpiredMessage(account);
        }
        LocalDateTime end = LocalDateTime.now();
        Duration duration = Duration.between(start,end);
        log.info("HKTW Notification结束, cost: {} ms", duration.toMillis());
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.HKTW_PAMPERS_NOTIFICATION_QUEUE.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.HKTW_PAMPERS_NOTIFICATION_QUEUE;
    }
}
