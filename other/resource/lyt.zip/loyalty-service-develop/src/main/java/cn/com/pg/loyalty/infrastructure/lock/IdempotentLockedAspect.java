package cn.com.pg.loyalty.infrastructure.lock;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Method;

/**
 * @Author: Hayden
 * @CreateDate: 2021/5/28 14:53
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/5/28 14:53
 * @Version: 1.0
 * @Description:
 */
@Slf4j
@Component
@Aspect
public class IdempotentLockedAspect {

    public static final Class<IdempotentLock> IDEMPOTENT_LOCK_CLASS = IdempotentLock.class;

    @Resource
    Lock lock;

    @Pointcut("@annotation(cn.com.pg.loyalty.infrastructure.lock.IdempotentLock)")
    public void idempotentPointCut() {
        // Do nothing because of point cut.
    }

    @Around("idempotentPointCut()")
    public Object doIdempotentAround(ProceedingJoinPoint point) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        Method method = methodSignature.getMethod();

        Object[] arguments = point.getArgs();
        LocalVariableTableParameterNameDiscoverer discoverer = new LocalVariableTableParameterNameDiscoverer();
        String[] parameterNames = discoverer.getParameterNames(method);
        IdempotentLock idempotentLock = method.getAnnotation(IDEMPOTENT_LOCK_CLASS);
        return IdempotentLockPointCutAdvice.pointAdviceWithLock(point, idempotentLock, lock, parameterNames, arguments);
    }


}
