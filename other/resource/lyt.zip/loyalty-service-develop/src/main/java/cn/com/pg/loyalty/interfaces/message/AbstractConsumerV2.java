package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.ParamValidateService;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.application.dependence.LoyaltyMessage;
import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusClientProperties;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusConfigRefactor;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.*;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;

import javax.annotation.Resource;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static cn.com.pg.loyalty.application.dependence.ServiceBusTemplate.MSG_REDIS_KEY;

@Slf4j
public abstract class AbstractConsumerV2 implements IMessageHandler {

    @Autowired
    private ServiceBusConfigRefactor serviceBusConfigRefactor;

    @Resource
    private RedisTemplate<String, Object> redisTemplate;
    @Autowired
    private KpiTemplate kpiTemplate;
    private static final String MEDIA_TYPE_TEXT = "text/plain";

    private static final String MESSAGE_ID_PREFIX = "Q-MID-PRE-";
    /**
     * 消息重试计数前缀
     */
    private static final String MESSAGE_ID_RETRY_COUNT_PREFIX = "MESSAGE_ID_RETRY_COUNT";

    private static final List<ResultCodeMapper> NOT_NEED_RETRY_CODES = new ArrayList<>();
    private static final List<ServiceBusBinder> UN_CHECK_LABEL_QUEUE = new ArrayList<>();
    //只针对队列
    private static final List<ResultCodeMapper> DELAY_RETRY_QUEUE_CODES = new ArrayList<>();
    /**
     * 消息重试上限次数
     */
    private static final int MESSAGE_RETRY_UPPER_BOUND = 3;
    /**
     * 消息重试延迟秒数
     */
    private static final int MESSAGE_RETRY_DELAY_SECONDS = 10;

    static {
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.ACCOUNT_REGISTER_FREQUENTLY);
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.ACTIVITY_NOT_FOUND);
        NOT_NEED_RETRY_CODES.add(ResultCodeMapper.POINT_TYPE_NOT_FOUND);

        DELAY_RETRY_QUEUE_CODES.add(ResultCodeMapper.OPERATION_TOO_FAST);
        DELAY_RETRY_QUEUE_CODES.add(ResultCodeMapper.REDEMPTION_NOT_FOUND);

        //异步通知加交互积分队列
        UN_CHECK_LABEL_QUEUE.add(ServiceBusBinder.Q_ASYNC_ADD_INTERACTION_POINT);
    }

    @Autowired
    private ParamValidateService paramValidateService;

    /**
     * 消息重试自增方法
     */
    private void incrementMessageRetryCount(String messageId) {
        String key = MESSAGE_ID_RETRY_COUNT_PREFIX.concat(messageId);
        //如果不存在， 返回0的Integer对象 已测试验证
        Integer incrementCount = (Integer) redisTemplate.opsForValue().get(key);
        Optional<Integer> op = Optional.ofNullable(incrementCount);
        if (op.isPresent()) {
            incrementCount += 1;
        } else {
            incrementCount = 0;
        }

        log.info("消息id:{} 重试计数：{}", messageId, incrementCount);
        //先默认key是5分钟的生命
        redisTemplate.opsForValue().set(key, incrementCount, 5, TimeUnit.MINUTES);
    }

    /**
     * 判断是否满足停止重试条件
     *
     * @param messageId
     * @return
     */
    private boolean needStopRetry(String messageId) {
        String key = MESSAGE_ID_RETRY_COUNT_PREFIX.concat(messageId);
        Integer incrementCount = (Integer) redisTemplate.opsForValue().get(key);
        return incrementCount >= MESSAGE_RETRY_UPPER_BOUND;
    }

    @Override
    public CompletableFuture<Void> onMessageAsync(IMessage message) {
        String sourceCorrelationId = message.getCorrelationId();
        RequestContext.createContext(sourceCorrelationId);
        long startTime = System.currentTimeMillis();
        LocalDateTime startDateTime = LocalDateTime.now();
        String messageId = message.getMessageId();
        log.info("---------Message Staring---------- message Id: {}, Source Correlation Id: {}", messageId, sourceCorrelationId);
        String label = message.getLabel();
        ServiceBusBinder binder = getServiceBusBinder();
        String operationName = binder.name() + "-onMessageConsumer";
        RequestContext.getCurrentContext().operationName(operationName);
        RequestContext.getCurrentContext().setMessageId(messageId);
        ServiceBusClientProperties client = serviceBusConfigRefactor.getClientByName(binder);
        log.info("---Message Start Execute--- Queue Name: {}, Label: {}, MessageId: {}, Queue Type: {}",
                binder.name(), label, messageId, client.getType());
        boolean isConsumable = shouldConsumerMessage(message, binder, client.getGeneralLabel());
        if (!isConsumable) {
            return abandonMessage(message, client);
        }
        boolean isSuccess = true;
        int errorCode = ResultCodeMapper.SUCCESS.getCode();
        String errMsg = "";
        try {
            final String messageExecutedVal = "1";
            String messageIdDuplicateVal = (String) redisTemplate.opsForValue().get(MESSAGE_ID_PREFIX.concat(messageId));
            if (messageExecutedVal.equals(messageIdDuplicateVal)) {
                log.info("消息重复: {}", messageId);
                isSuccess = false;
                errorCode = ResultCodeMapper.MESSAGE_DUPLICATED.getCode();
                errMsg = "消息推送重复".concat(messageId);
                return completeMessage(message, client);
            }
            List<byte[]> binaryData = message.getMessageBody().getBinaryData();
            if (binaryData == null) {
                throw new SystemException("the message body is null", ResultCodeMapper.SERVICE_BUS_ERROR);
            }
            JSONObject messageBody = getMessageBody(binaryData, client);
            if (messageBody == null) {
                log.info("获取到Message Body为空");
                isSuccess = false;
                errorCode = ResultCodeMapper.MESSAGE_EMPTY.getCode();
                errMsg = "Message Body为空";
                //没必要重试
                return completeMessage(message, client);
            }
            Map<String, String> paramMap = paramValidateService.exactVerifiedParam(messageBody);
            paramValidateService.validate(paramMap);
            incrementMessageRetryCount(messageId);
            this.doBusiness(messageBody);
            redisTemplate.opsForValue().set(MESSAGE_ID_PREFIX.concat(messageId), messageExecutedVal,
                    5L, TimeUnit.MINUTES);
            log.info("消息处理成功");
            return completeMessage(message, client);
        } catch (SystemException e) {
            ResultCodeMapper codeMapper = e.resultCodeMapper();
            isSuccess = false;
            errMsg = e.getMessage();
            errorCode = codeMapper.getCode();
            log.error("消费队列消息SystemException异常：{}", e.getMessage());
            // 判断抛出的异常是否需要重试
            if (notNeedRetryCode(codeMapper)) {
                log.info("不需要重试，直接结束");
                return completeMessage(message, client);
            }

            if (needQueueRetryDelay(codeMapper, client)) {
                log.info("不需要重试，直接结束");
                return delayQueueMessage(message, client);
            }

        } catch (Exception e) {
            isSuccess = false;
            errMsg = e.getMessage();
            errorCode = ResultCodeMapper.UNEXPECTED_ERROR.getCode();
            long costTime = System.currentTimeMillis() - startTime;
            log.error("消费队列信息异常: {}", ExceptionUtil.getStackTraceErrorMessage(e));
            String correlationId = RequestContext.getCurrentContext().getCorrelationId();
            kpiTemplate.sendConsumingMessage(messageId, operationName, startDateTime, costTime, errorCode, errMsg, correlationId);
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            log.info("消息处理完成, Result: {}, Cost: {}, MessageId: {}, Name: {}, Code: {}, Msg: {}", isSuccess, costTime,
                    messageId, operationName, errorCode, errMsg);
        }
        CompletableFuture<Void> completableFuture = abandonMessage(message, client);
        RequestContext.cleanContext();
        return completableFuture;
    }

    protected boolean notNeedRetryCode(ResultCodeMapper codeMapper) {
        return NOT_NEED_RETRY_CODES.contains(codeMapper);
    }

    protected boolean needQueueRetryDelay(ResultCodeMapper codeMapper, ServiceBusClientProperties properties) {
        return DELAY_RETRY_QUEUE_CODES.contains(codeMapper)
                && ServiceBusBinder.ServiceBusType.QUEUE.equals(properties.getType());
    }

    private JSONObject getMessageBody(List<byte[]> binaryData, ServiceBusClientProperties client) {
        LoyaltyMessage loyaltyMessage = JSON.parseObject(new String(binaryData.get(0)), LoyaltyMessage.class);
        log.info("获取到: {}队列信息: {}", client.getName(), JSON.toJSONString(loyaltyMessage));
        JSONObject messageBody = loyaltyMessage.getJsonObject();
        if (messageBody == null) {
            log.info("消息体为空");
            return null;
        }
        if (messageBody.containsKey(MSG_REDIS_KEY)) {
            log.info("大消息，从redis中获取");
            String bigMessageRedisKey = messageBody.getString(MSG_REDIS_KEY);
            String bigMessageValue = (String) redisTemplate.opsForValue().get(bigMessageRedisKey);
            if (StringUtils.isEmpty(bigMessageValue)) {
                log.info("big message value is null");
                return null;
            }
            messageBody = JSON.parseObject(bigMessageValue);
        }
        return messageBody;
    }

    private boolean shouldConsumerMessage(IMessage message, ServiceBusBinder serviceBusBinder, String label) {
        //由于Function发过来的消息，无法设置Label，content type，如果是这种content type，则认为是function过来的消息。（作为约定）普通消息不允许这种格式
        if (MEDIA_TYPE_TEXT.equalsIgnoreCase(message.getContentType())) {
            log.info("这个地方是从Function过来的！！！！");
            return true;
        }
        // 指定队列不判断label
        if (UN_CHECK_LABEL_QUEUE.contains(serviceBusBinder)) {
            return true;
        }
        //设置这个是为了在本地好测试，每个人的message互不影响，靠label区分。生产环境不存在这样的逻辑
        boolean isThisLabelQueueMsg = Optional.ofNullable(message.getLabel())
                .map(labelQueue -> labelQueue.contentEquals(label)).orElse(false);
        if (!isThisLabelQueueMsg) {
            log.info("消息不是本Label的，返回队列让其它Consumer消费");
        }
        return isThisLabelQueueMsg;
    }

    /**
     * 完成消息并释放锁
     *
     * @param message
     * @return
     */
    private CompletableFuture<Void> completeMessage(IMessage message, ServiceBusClientProperties client) {
        CompletableFuture<Void> completableFuture;
        if (ServiceBusBinder.ServiceBusType.SUBSCRIBE.equals(client.getType())) {
            SubscriptionClient subscriptionClient = (SubscriptionClient) client.getClient();
            completableFuture = subscriptionClient.completeAsync(message.getLockToken());
        } else if (ServiceBusBinder.ServiceBusType.QUEUE.equals(client.getType())) {
            QueueClient queueClient = (QueueClient) client.getClient();
            completableFuture = queueClient.completeAsync(message.getLockToken());
        } else {
            throw new SystemException("the service bus consumer properties is error, please check it", ResultCodeMapper.SERVICE_BUS_ERROR);
        }
        log.info("完成消息结束");
        return completableFuture;
    }


    private CompletableFuture<Void> delayQueueMessage(IMessage message, ServiceBusClientProperties client) {
        CompletableFuture<Void> completableFuture;
        if (ServiceBusBinder.ServiceBusType.QUEUE.equals(client.getType())) {
            try {
                if (needStopRetry(message.getMessageId())) {
                    //需要中断消息重试，并把消息丢进死信里
                    log.info("消息id:{}重试超过次数上限,进入死信", message.getMessageId());
                    return deadLetterMessage(message, client);
                }
                QueueClient queueClient = (QueueClient) client.getClient();
                message.setScheduledEnqueueTimeUtc(Instant.now().plusSeconds(MESSAGE_RETRY_DELAY_SECONDS));
                queueClient.send(message);
                completableFuture = queueClient.completeAsync(message.getLockToken());
                log.info("完成消息结束");
                return completableFuture;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (ServiceBusException e) {
                return abandonMessage(message, client);
            }
        }
        throw new SystemException("the service bus consumer properties is not queue, please check it", ResultCodeMapper.SERVICE_BUS_ERROR);
    }

    /**
     * 中断消息并释放锁，让其它客户端重新消费
     *
     * @param message
     * @return
     */
    private CompletableFuture<Void> abandonMessage(IMessage message, ServiceBusClientProperties client) {
        CompletableFuture<Void> completableFuture;
        if (ServiceBusBinder.ServiceBusType.SUBSCRIBE.equals(client.getType())) {
            SubscriptionClient subscriptionClient = (SubscriptionClient) client.getClient();
            completableFuture = subscriptionClient.abandonAsync(message.getLockToken());
        } else if (ServiceBusBinder.ServiceBusType.QUEUE.equals(client.getType())) {
            QueueClient queueClient = (QueueClient) client.getClient();
            completableFuture = queueClient.abandonAsync(message.getLockToken());
        } else {
            throw new SystemException("the properties about service consumer is error, please check it", ResultCodeMapper.PARAM_ERROR);
        }
        log.info("中断消息结束");
        return completableFuture;
    }

    /**
     * 将消息变成死信
     *
     * @param message
     * @param client
     */
    private CompletableFuture<Void> deadLetterMessage(IMessage message, ServiceBusClientProperties client) {
        CompletableFuture<Void> completableFuture;
        if (ServiceBusBinder.ServiceBusType.SUBSCRIBE.equals(client.getType())) {
            SubscriptionClient subscriptionClient = (SubscriptionClient) client.getClient();
            completableFuture = subscriptionClient.deadLetterAsync(message.getLockToken());
        } else if (ServiceBusBinder.ServiceBusType.QUEUE.equals(client.getType())) {
            QueueClient queueClient = (QueueClient) client.getClient();
            completableFuture = queueClient.deadLetterAsync(message.getLockToken());
        } else {
            throw new SystemException("the properties about service consumer is error, please check it", ResultCodeMapper.PARAM_ERROR);
        }
        log.info("将消息变为死信结束");
        return completableFuture;
    }


    protected abstract void doBusiness(JSONObject message);

    protected abstract ServiceBusBinder getServiceBusBinder();

    @Override
    public void notifyException(Throwable throwable, ExceptionPhase exceptionPhase) {
    }

}
