package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.structure.BrandV2;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

/**
 * @author: Ysnow
 * @Date: 2019/6/12 17:04
 * @Description:
 */
public class RandomUtils {

    private RandomUtils(){}
    private static final int MAX_NUMBER_STRING = 34;
    private static final  char[] REDEEM_CODE = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K',
            'L', 'M', 'N',  'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
            'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

    private static final int MAX_LIMIT_CODE_NUMBER = 8;

    private static final SecureRandom random = new SecureRandom();

    /**
     * 获取速记的兑换码
     * @return
     */
    public static String getRandomRedeemCode(){
        int randomNumber;
        int count = 0;
        StringBuffer stringBuffer = new StringBuffer("");
        while(count < MAX_LIMIT_CODE_NUMBER){
            randomNumber = Math.abs(random.nextInt(MAX_NUMBER_STRING));
            if (randomNumber >= 0 && randomNumber < MAX_NUMBER_STRING) {
                stringBuffer.append(REDEEM_CODE[randomNumber]);
                count ++;
            }
        }
        return stringBuffer.toString();
    }
    /**
     * 加密生成领取码
     *
     * @param content 需要加密的内容
     * @param encKey 加密的密匙
     * @return
     */
    public static String getRedeemCode(String content, String encKey, String brand, String transactionId) {
        try {
            if (BrandV2.SKII.equals(brand)) {
                encKey = transactionId;
            }
            String encryptResultStr = null;
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128, new SecureRandom(encKey.getBytes()));
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");// 创建密码器
            byte[] byteContent = content.getBytes(StandardCharsets.UTF_8);
            cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化
            byte[] result = cipher.doFinal(byteContent);
            encryptResultStr=parseByte2HexStr(result);
            return encryptResultStr.substring(0,MAX_LIMIT_CODE_NUMBER); // 加密
        }catch (Exception e){
            throw new SystemException("生成领取码异常", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }
    /**将二进制转换成16进制
     * @param buf
     * @return
     */
    public static String parseByte2HexStr(byte[] buf) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < buf.length; i++) {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1) {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }
}

