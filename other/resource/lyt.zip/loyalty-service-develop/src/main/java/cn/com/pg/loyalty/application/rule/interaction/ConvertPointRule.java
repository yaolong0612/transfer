package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.ConvertPointProperties;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2022/1/23
 */
@Rule(name = "INTERACTION_CONVERT_POINT_RULE",
        description = "customer service add point")
@Slf4j
public class ConvertPointRule {

    private static final RuleTemplate ruleTemplate = RuleTemplate.INTERACTION_CONVERT_POINT_RULE;

    @Condition
    public boolean matchCondition(@Fact("pointType") PointType pointType, @Fact("convertPoint") Boolean isConvertPoint) {
        return pointType.ruleTemplate() == ruleTemplate && isConvertPoint;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("point") Integer clientPoint,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("account") Account account,
                         @Fact("transitPointInteraction") Interaction transitPointInteraction,
                         @Fact("pointType") PointType pointType,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        //判断提交的转换积分是否大于可用积分
        Integer transitPoint = account.availablePoint(loyaltyStructure.subAccountType(ValueType.TRANSIT));
        //消费者从前端输入的积分是正数
        if (clientPoint <= 0 || clientPoint > transitPoint) {
            ruleResult.addException(new SystemException("member have no available point to convert ", ResultCodeMapper.POINT_EXCEED_LIMIT_FREQUENCY));
            return;
        }
        /**
         * 只查询指定积分类型的成长积分记录
         */
        List<Interaction> interactionList = interactionRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndPointTypeAndValueType(interaction.partitionKey(), account.loyaltyId(), interaction.getBrand(), pointType.getPointType(), ValueType.DEFAULT);
        int times = interactionList.size();
        // 由于交互活动按积分类型指定，理论上同一个积分类型一个活动，如果多个活动，取最高优先级
        List<Activity> activityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activities, interaction.getCreatedTime(), ruleTemplate);
        Activity activity = activityList.get(0);
        ConvertPointProperties ruleContent = (ConvertPointProperties) activity.ruleProperties();
        //判断转换积分次数是否使用完毕
        if (times >= ruleContent.getTimes()) {
            ruleResult.addException(new SystemException("  opportunities of converting is used out ", ResultCodeMapper.ACTIVITY_EXCEED_TIMES));
            return;
        }
        int newTypePoint = clientPoint / ruleContent.getExchangeRate();
        if (newTypePoint == 0) {
            ruleResult.addException(new SystemException("the exchange point should bigger than " + ruleContent.getExchangeRate(), ResultCodeMapper.PARAM_ERROR));
        }
        interaction.addPoint(activity, newTypePoint);
        //设置该条记录是成长积分
        interaction.setValueType(ValueType.DEFAULT);
        int remainedPoint = clientPoint % ruleContent.getExchangeRate();
        transitInteraction(transitPointInteraction, clientPoint, activity, remainedPoint);
        ruleResult.success();
    }

    private void transitInteraction(Interaction transitPointInteraction, Integer clientPoint, Activity activity, int remainedPoint) {
        transitPointInteraction.setValueType(ValueType.TRANSIT);
        // 由于消费者从前端输入是正数的过渡积分需要加负号
        transitPointInteraction.addPoint(activity, remainedPoint - clientPoint);
    }
}
