package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.DailyAttendanceProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author cooltea on 2019/8/7 17:43.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Rule(name = "Interaction rule:daily attendance rule",
        description = "daily attendance")
@Slf4j
public class DailyAttendanceRule {

    /**
     * 主要用来防止重复点击签到
     */
    private static String REDIS_KEY_PREFIX = "DAILY:BRAND:";
    private static long EXPIRE_TIME_SECONDS = 20L;
    private static final DateTimeFormatter ofPattern = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @Condition
    public boolean isPampersDailyRule(@Fact("pointType") PointType pointType) {
        return pointType.ruleTemplate() == RuleTemplate.ML_INTERACTION_DAILY_ATTENDANCE;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("pointType") PointType pointType,
                         @Fact("interaction") Interaction interaction,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("brand") String brand,
                         @Fact("stringRedisTemplate") StringRedisTemplate stringRedisTemplate,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        Activity activity = activities.get(0);
        DailyAttendanceProperties property = (DailyAttendanceProperties)activity.ruleProperties();

        if (property.getBasePoint() == null || property.getIncrementPoint() == null || property.getMaxPoint() == null) {
            String s = new StringBuilder("basePoint:").append(property.getBasePoint())
                    .append("incrementPoint:").append(property.getIncrementPoint())
                    .append("maxPoint:").append(property.getMaxPoint())
                    .append(",all three params can't be null").toString();
            log.error("配置活动的properties:{}有误退出rule不进行签到加积分流程", JSON.toJSONString(property));
            ruleResult.addException(new SystemException(s, ResultCodeMapper.PARAM_ERROR));
            return;
        }

        LocalDate localDate = LocalDate.now();
        String key = new StringBuilder(REDIS_KEY_PREFIX).append(pointType.pointType()).append(":")
                .append(localDate).append(":").append(brand).append(":").append(interaction.getLoyaltyId()).toString();
        Boolean isExists = stringRedisTemplate.opsForValue().setIfAbsent(key, activity.pointType(), EXPIRE_TIME_SECONDS, TimeUnit.SECONDS);
        if (isExists != null && !isExists) {
            log.info("今日: {}签到频繁，不进行签到加积分流程", localDate.toString());
            ruleResult.addException(new SystemException("Signing in too frequently", ResultCodeMapper.ATTENDANCE_FREQUENTLY));
            return;
        }
        log.info("进行:{}每日: {}签到加积分流程", brand, localDate.toString());
        Integer addPoint;
        int  serialDays = 0;
        boolean todayIsExists = false;
        int maxPeriodDay = 0;
        // 计算用户是否连续签到
        if (property.getIncrementPoint() != 0) {
            maxPeriodDay = (property.getMaxPoint() - property.getBasePoint()) / property.getIncrementPoint();
        }
        String startTime = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.of(localDate.minusDays(maxPeriodDay), LocalTime.MIN));
        String endTime = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.of(localDate, LocalTime.MAX));
        List<Interaction> interactions = interactionRepository
                .findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(interaction.partitionKey(), pointType.pointType(), interaction.getLoyaltyId(), brand, startTime, endTime);
        List<String> dates = interactions.stream().map(Transaction::getCreatedTime)
                .map(createTime -> createTime.format(ofPattern))
                .sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        LocalDate temp = localDate;
        log.info("签到积分活动基础积分: {}, 每日增长积分: {}, 连续签到: {}天, 可获取签到最大积分: {}", property.getBasePoint(),
                property.getIncrementPoint(), maxPeriodDay, property.getMaxPoint());
        // 计算连续签到多少日时达到最大值
        for (String dateStr : dates) {
            if (dateStr.equalsIgnoreCase(localDate.toString())){
                // 如果今天日期已经加过就退出
                todayIsExists = true;
                break;
            }
            temp = temp.minusDays(1);
            if (dateStr.equalsIgnoreCase(temp.toString())) {
                serialDays++;
                continue;
            }
            break;
        }
        log.info("用户连续签到天数：{}, 今天: {}是否已签到: {}", serialDays, localDate.toString(), todayIsExists);
        if (todayIsExists) {
            log.info("今日: {}已签签到，不进行签到加积分流程", localDate.toString());
            ruleResult.addException(new SystemException("Today has already signed in", ResultCodeMapper.ATTENDANCE_FREQUENTLY));
            return;
        }
        addPoint = property.getBasePoint() + serialDays * property.getIncrementPoint();
        addPoint = addPoint > property.getMaxPoint() ? property.getMaxPoint() : addPoint;
        interaction.addPoint(activity, addPoint);
        log.info("用户签到加积分：{}, 交互记录：{}", addPoint, JSON.toJSONString(interaction));
        ruleResult.success();
    }

}
