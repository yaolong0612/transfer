package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.application.dto.RequestOrderCommand;
import cn.com.pg.loyalty.application.dto.RequestOrderItemDTO;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderItem;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper
public interface OrderMapper {
    OrderMapper INSTANCE = Mappers.getMapper(OrderMapper.class);

    List<Order> request2Orders(List<RequestOrderCommand> requestOrders);

    Set<OrderItem> dto2OrderItems(Set<RequestOrderItemDTO> dto);

    Order copyOrder(Order order);
}
