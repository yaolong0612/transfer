package cn.com.pg.loyalty.domain.transaction;


import cn.com.pg.loyalty.domain.shared.ValueObject;

/**
 * @author Simon
 * @date 2019年4月23日下午4:23:48
 * @description DeliveryChannel
 */
public enum DeliveryChannel implements ValueObject<DeliveryChannel> {
    /**
     * 兑换礼品后，去柜台取货
     */
    C2(false),

    /**
     * 是调用物流微服务发货
     */
    LOGISTICS(true),

    /**
     * 不需要，是通过灵发送礼品的
     */
    NONE(false),

    /**
     * 定泰新的物流发运商
     */
    LOGISTICS_DINGTAI(true),

    /**
     * 人工发货方式
     */
    MANUAL(false);

    private boolean logisticsDelivery;

    DeliveryChannel(boolean logisticsDelivery) {
        this.logisticsDelivery = logisticsDelivery;
    }

    @Override
    public boolean sameValueAs(final DeliveryChannel other) {
        return this.equals(other);
    }

    public boolean sendLogisticsService() {
        return this.logisticsDelivery;
    }
}
