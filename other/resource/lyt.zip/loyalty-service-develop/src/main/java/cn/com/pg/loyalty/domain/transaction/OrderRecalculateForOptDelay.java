package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountOpt.OptNode;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @Author: Hayden
 * @CreateDate: 2021/3/12 9:51
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/12 9:51
 * @Version: 1.0
 * @Description:
 */
@Service
public class OrderRecalculateForOptDelay {

    @Autowired
    private MessageService messageService;

    @Autowired
    private OrderRepository orderRepository;

    public void recalculateOrder(Account account, String brand, OptNode optNode) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        String optTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(optNode.getOptDate());
        List<Order> orders = orderRepository
                .findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeGreaterThan(
                        pk, account.loyaltyId(), brand, TransactionType.ORDER, optTimeStr);
        if (!CollectionUtils.isEmpty(orders)) {
            orders.forEach(order -> order.setOrderUpdateTime(order.getOrderUpdateTime().plusSeconds(1)));
            messageService.send2RecalculateOrders(account.memberId(), account.getRegion(), orders);
        }
    }
}
