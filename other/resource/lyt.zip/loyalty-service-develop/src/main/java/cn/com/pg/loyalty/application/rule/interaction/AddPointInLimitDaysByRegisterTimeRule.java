package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AddPointInLimitDaysByRegisterTimeProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2021/10/20
 */
@Rule(name = "interaction add point in limit days by registerTime", description = "interaction add point in limit days by registerTime")
@Slf4j
public class AddPointInLimitDaysByRegisterTimeRule {

    @Condition
    public boolean isAdjustPointRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADD_POINT_IN_LIMIT_DAYS_BY_REGISTER_TIME;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("account") Account account,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("pointType") PointType pointType,
                         @Fact("ruleResult") RuleResult ruleResult) {
        //理论上一个交互积分类型只有一个有效活动
        Activity activity = activities.get(0);
        AddPointInLimitDaysByRegisterTimeProperties properties = JSON.parseObject(activity.getRuleProperties(),
                AddPointInLimitDaysByRegisterTimeProperties.class);
      //校验积分模板配置是否正确
        if (properties.getLimitDays()<=0 || properties.getLimitTimes() <=0 || properties.getPoint() <= 0) {
            String s = new StringBuilder("limitDays:").append(properties.getLimitDays())
                    .append("point:").append(properties.getPoint())
                    .append("limitTimes:").append(properties.getLimitTimes())
                    .append(",all three params can't be 0").toString();
            log.error("配置活动id{}的properties:{}有误退出rule不进行加积分流程",activity.getId(), activity.getRuleProperties());
            ruleResult.addException(new SystemException(s, ResultCodeMapper.PARAM_ERROR));
            return;
        }

        SubAccount subAccount =account.getSubAccountList().get(interaction.getBrand());
        LocalDateTime registerTime=LoyaltyDateTimeUtils.getBeginTimeOfDate(subAccount.getCreatedTime());
       //生成有效期开始日期
        LocalDateTime startTime=generateAimDate(registerTime,1);
        //生成有效期结束日期
        LocalDateTime endTime=LoyaltyDateTimeUtils.getEndTimeOfDay(generateAimDate(registerTime,properties.getLimitDays()));
        LocalDateTime currentTime=LocalDateTime.now();
        //判断申请加积分时间是否在有效期内
        if(currentTime.isBefore(startTime)||currentTime.isAfter(endTime)){
            log.info("会员: {} 注册时间{}  在当前时间{}由于不在有效期startTime:{}----endTime: {}，不进行积分类型{}加积分流程", account.getMemberId(),registerTime,currentTime,startTime,endTime,interaction.getPointType());
            ruleResult.addException(new SystemException("Not in  effective period", ResultCodeMapper.LIMIT_ERROR));
            return;
        }
       //首先查询在指定日期内是否达到加积分次数上限
      int addPointTimesCount=  countByPointTypeInLimitPeriod(
                interactionRepository,interaction.getPartitionKey(),pointType.getPointType(),interaction.getLoyaltyId(),interaction.getBrand(),
              LoyaltyDateTimeUtils.localDateTimeToString(startTime) ,LoyaltyDateTimeUtils.localDateTimeToString(endTime));
       if(addPointTimesCount>=properties.getLimitTimes()){
           log.info("会员: {} 达到加积分上限不进行积分类型{}加积分流程，当前加积分次数{}", account.getMemberId(),interaction.getPointType(),addPointTimesCount);
           ruleResult.addException(new SystemException(" add point times is limited", ResultCodeMapper.LIMIT_ERROR));
           return;
        }
        //校验通过加积分
        interaction.addPoint(activity,properties.getPoint());
        log.info("注册时间{} 有效期{}----{},完成加积分: {}",registerTime,startTime,endTime, JSON.toJSONString(interaction));
        ruleResult.success();
    }

    /**
     * 根据会员id和积分类型查询消费者注册日起在n天内是否存在相关积分类型的交互加积分
     *
     */
    private  int countByPointTypeInLimitPeriod(InteractionRepository interactionRepository, String transactionPartitionKey , String pointType, String loyaltyId, String brand, String startTime, String endTime){
        List<Interaction> interactions = interactionRepository
                .findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(transactionPartitionKey, pointType, loyaltyId, brand, startTime, endTime);
        return interactions.size();
    }



    /**
     * 生成指定日期
     * @param registerDate
     * @param limitDays
     * @return
     */
    private  LocalDateTime generateAimDate(LocalDateTime registerDate,int limitDays){
        return  registerDate.plusDays(limitDays);
    }

}



