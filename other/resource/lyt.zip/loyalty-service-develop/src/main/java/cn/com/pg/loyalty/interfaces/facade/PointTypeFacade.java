package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.PointTypeService;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.api.PointTypesApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.PointTypeAssembler;
import cn.com.pg.loyalty.interfaces.dto.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("PointTypeFacade")
public class PointTypeFacade implements PointTypesApiDelegate {

    @Autowired
    private PointTypeService pointTypeService;
    @Autowired
    private CacheService cacheService;


    @Override
    public ResponseEntity<PointTypeListDTO> fetchPointTypeList(String authorization, String brand, String region, String status, String transactionType) {
        //验证Get请求中的Enum参数

        TransactionType tsType = null;
        if (!StringUtils.isEmpty(transactionType)) {
            tsType = ParamValidator.transactionType(transactionType);
        }
        List<PointType> pageableResult = pointTypeService.fetchPointTypeList(brand, region,
                PointType.PointTypeStatus.valueOf(status), tsType);
        PointTypeListDTO pointTypeListDTO = PointTypeAssembler.toPointTypeListDTO(pageableResult);
        return ResponseEntity.ok(pointTypeListDTO);
    }


    @Override
    public ResponseEntity<AddPointTypeDTO> addPointType(String authorization, AddPointTypeCommand body) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(body.getRegion(),
                body.getBrand());

        PointType pointType = pointTypeService.addPointType(PointTypeAssembler.toPointType(body, loyaltyStructure, JwtUtils.getUsernameFromToken(authorization)));
        AddPointTypeDTO addPointTypeDTO = new AddPointTypeDTO();
        addPointTypeDTO.pointTypeId(pointType.getId());
        return ResponseEntity.ok(addPointTypeDTO);
    }

    @Override
    public ResponseEntity<Void> deletePointTypeById(String authorization, String pointTypeId) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        pointTypeService.deleteById(pointTypeId, userName);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PointTypeDTO> fetchPointTypeById(String authorization, String pointTypeId) {
        PointType pointType = pointTypeService.findById(pointTypeId);
        PointTypeDTO pointTypeDTO = PointTypeAssembler.toPointTypeDTO(pointType);
        return ResponseEntity.ok(pointTypeDTO);
    }


    @Override
    public ResponseEntity<Void> addPointTypeDisplayLanguages(String authorization,
                                                             String pointTypeId,
                                                             List<PointTypeDisplayMsgDTO> displayLanguages) {
        pointTypeService.addDisplayLanguages(pointTypeId, PointTypeAssembler.toPointTypeDisplayMsgList(displayLanguages));
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
