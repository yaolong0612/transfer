package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.interfaces.dto.CreateRedemptionCommand;
import cn.com.pg.loyalty.interfaces.dto.GiftIdQuantityCommand;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RedemptionMapper {

    RedemptionMapper INSTANCE = Mappers.getMapper(RedemptionMapper.class);


    @Mapping(target = "giftItemList", source = "command.giftIdQuantityItem")
    @Mapping(target = "storeCode",source = "command.receivingStoreCode")
    Redemption command2Redemption(CreateRedemptionCommand command);

    GiftItem command2GiftItem(GiftIdQuantityCommand command);
}
