package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.GiftService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.dto.GiftCouponCommand;
import com.alibaba.fastjson.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Set;

import static cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder.Q_COUPON_CODE;

@Component
public class CouponCodeConsumer extends AbstractConsumerV2 {
    @Autowired
    private Validator validator;
    @Autowired
    private GiftService giftService;

    @Override
    protected void doBusiness(JSONObject message) {
        GiftCouponCommand couponCommand = message.toJavaObject(GiftCouponCommand.class);
        Set<ConstraintViolation<GiftCouponCommand>> violationSet = validator.validate(couponCommand);
        if (!CollectionUtils.isEmpty(violationSet)) {
            throw new SystemException("Coupon param error", ResultCodeMapper.PARAM_ERROR);
        }
        giftService.addGiftCoupon(couponCommand);

    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return Q_COUPON_CODE;
    }
}
