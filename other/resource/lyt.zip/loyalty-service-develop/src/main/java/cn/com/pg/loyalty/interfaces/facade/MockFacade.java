package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.MockService;
import cn.com.pg.loyalty.interfaces.api.MockApiDelegate;
import cn.com.pg.loyalty.interfaces.dto.UpdateMockAccountCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component("MockFacade")
public class MockFacade implements MockApiDelegate {

    @Autowired
    private MockService mockService;

    @Override
    public ResponseEntity<Void> updateAccountById(String loyaltyId, UpdateMockAccountCommand updateMockAccountCommand) {
        mockService.updateAccountById(loyaltyId, updateMockAccountCommand);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
