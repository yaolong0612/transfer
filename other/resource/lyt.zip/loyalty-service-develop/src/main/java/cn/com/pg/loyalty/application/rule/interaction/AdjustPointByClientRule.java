package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.List;

/**
 * @author cooltea
 */
@Rule(name = "adjust point rule",
        description = "add point")
@Slf4j
public class AdjustPointByClientRule {

    @Condition
    public boolean isAdjustPointRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_BY_CLIENT;
    }

    @Action
    public void addPoint(@Fact("loyaltyStructure") LoyaltyStructure structure,
                         @Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("account") Account account,
                         @Fact("point") Integer point,
                         @Fact("reason") String reason,
                         @Fact("ruleResult") RuleResult ruleResult) {
        log.info("client端手动调整的积分数：{}", point);
        if (point < 0) {
            Integer accountAvailablePoint = account.availablePoint(structure.accountTypeOfDefault());
            if (point + accountAvailablePoint < 0) {
                ruleResult.addException(new SystemException("Requiring " + point + "points to adjust the bonus points of user,user dosen't have enough bonus points to use" + accountAvailablePoint, ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                return;
            }
        }
        interaction.addPoint(activities.get(0),point,reason);
        log.info("client端手动调整完成,记录interaction: {}", JSON.toJSONString(interaction));
        ruleResult.success();
    }
}
