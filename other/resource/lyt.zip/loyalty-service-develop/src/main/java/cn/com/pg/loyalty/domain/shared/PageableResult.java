package cn.com.pg.loyalty.domain.shared;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author Simon
 * @date 2019/5/15 16:27
 * @description
 **/
@Getter
public class PageableResult<T> {
    private int totalSize;
    private List<T> records;

    public PageableResult(int totalSize, List<T> records) {
        this.totalSize = totalSize;
        this.records = records;
    }
}
