package cn.com.pg.loyalty.infrastructure.lock;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.util.StringUtils;

import java.util.List;

public class IdempotentLockPointCutAdvice {


    private static final String DELIMITER = ":";
    public static final String LOCK_DIR = "IDEM_DIR" + DELIMITER;
    /**
     *增强切点功能：加锁
     */
    public static Object pointAdviceWithLock(ProceedingJoinPoint point, IdempotentLock lockable, Lock lock,
                                             String[] parameterNames, Object[] arguments) throws Throwable {
        SpELParseUtils spELParseUtils = SpELParseUtils.init(parameterNames, arguments);
        if (unlessWithEmpty(lockable, spELParseUtils)) {
            return point.proceed();
        }
        List<String> keys = spELParseUtils.parseKeys(lockable.lockKeys());
        return completeLockAndExec(point, lockable,lock, keys);
    }

    /**
     * 判断unlessWithEmpty 值，如果为null ，不上锁
     */
    private static boolean unlessWithEmpty(IdempotentLock lockable, SpELParseUtils spELParseUtils) {
        String unlessEmptyKey = lockable.unlessWithEmpty();
        if (StringUtils.isEmpty(unlessEmptyKey)) {
            return false;
        }
        return StringUtils.isEmpty(spELParseUtils.parseKey(unlessEmptyKey));
    }

    /**
     *上锁
     */
    private static Object completeLockAndExec(ProceedingJoinPoint point, IdempotentLock lockable,Lock lock,
                                              List<String> keys) throws Throwable {
        String lockKey = LOCK_DIR + String.join(DELIMITER, keys);
        boolean locked = lock.tryLock(lockKey, lockable.expiredTime(), lockable.timeUnit());
        if (!locked) {
            throw new SystemException("Repeat request!", ResultCodeMapper.REQUEST_REPEAT);
        }
        try {
            return point.proceed();
        } catch (Exception e) {
            return handException(lockable,lock, lockKey, e);
        }
    }

    /**
     *处理异常：非业务异常，删除锁
     */
    private static Object handException(IdempotentLock lockable, Lock lock,String lockKey, Exception e)  {
        Class<? extends RuntimeException>[] businessExceptions = lockable.businessExceptions();
        for (Class<? extends RuntimeException> businessException : businessExceptions) {
            if (businessException.equals(e.getClass())) {
                throw (RuntimeException)e;
            }
        }
        lock.deleteLock(lockKey);
        throw new SystemException(e.getMessage(),ResultCodeMapper.UNEXPECTED_ERROR);
    }

    private IdempotentLockPointCutAdvice() {
    }
}
