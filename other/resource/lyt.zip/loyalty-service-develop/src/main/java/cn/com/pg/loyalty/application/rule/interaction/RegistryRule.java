package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.RegistryRuleProperties;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Simon
 * @date 2019/4/17 23:07
 * @description
 **/
@Rule(name = "Interaction rule: registry rule",
        description = "if consumer registry in loyalty, then add registry point, one person just add one time")
@Slf4j
public class RegistryRule {

    @Condition
    public boolean isRegistry(@Fact("ruleTemplate") RuleTemplate ruleTemplate) {
        return ruleTemplate.ruleTemplateClazz() == this.getClass();
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("account") Account account,
                         @Fact("interaction") Interaction interaction,
                         @Fact("brand") String brand,
                         @Fact("channel") String channel,
                         @Fact("pointType") PointType pointType,
                         @Fact("registryEvent") Account.RegistryEvent event,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Interaction> interactions = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(
                partitionKey, pointType.pointType(), account.loyaltyId(), brand);
        activities = activities.stream().filter(activity -> activity.thisBrandActivity(brand)).collect(Collectors.toList());
        // 没有加过该品牌积分
        if (interactions.size() == 0) {
            doAddPoint(activities, channel, event, interaction, pointType);
        } else {
            // 获取channel所在活动中的所有相关channels
            Set<String> activitySet = activities.stream()
                    .filter(activity -> ((RegistryRuleProperties) activity.ruleProperties()).getChannels().contains(channel))
                    .map(activity -> ((RegistryRuleProperties) activity.ruleProperties()).getChannels())
                    .flatMap(Collection::stream)
                    .collect(Collectors.toSet());
            log.info("获取到活动相关的积分体系channels: {}", JSON.toJSONString(activitySet));
            // 这个用户是否已经加过某个体系的渠道积分（如：微信和小程序 渠道不同，但是同一个体系 只能加一次）
            Set<String> interactionsSet = interactions.stream().map(Transaction::channel).collect(Collectors.toSet());
            Optional<String> isExists = interactionsSet.stream().filter(activitySet::contains).findAny();
            log.info("是否已加过注册/绑定积分: {}, 记录channels: {}", isExists.isPresent(), JSON.toJSONString(interactionsSet));
            if (!isExists.isPresent()) {
                // 用户没有加过该类型积分，去加积分
                doAddPoint(activities, channel, event, interaction, pointType);
            }
        }
        ruleResult.success();
    }

    private void doAddPoint(List<Activity> activities, String channel, Account.RegistryEvent event, Interaction interaction, PointType pointType) {
        Activity availableActivity = null;
        RegistryRuleProperties ruleProperties;
        Integer addPoint = 0;
        for (Activity activity : activities) {
            ruleProperties = (RegistryRuleProperties) activity.ruleProperties();
            if (ruleProperties.getChannels().contains(channel) && event == Account.RegistryEvent.BINDING_EVENT) {
                availableActivity = activity;
                addPoint = ruleProperties.getBindPoint();
                break;
            }
            if (ruleProperties.getChannels().contains(channel) &&
                    event == Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT) {
                availableActivity = activity;
                addPoint = ruleProperties.getRegisterPoint();
                break;
            }
        }
        log.info("执行注册/绑定加积分动作选中的活动: {}, addPoint: {}", JSON.toJSONString(availableActivity), addPoint);
        // 加积分
        if (availableActivity != null) {
            interaction.addPoint(availableActivity, pointType, addPoint);
        }
    }

}
