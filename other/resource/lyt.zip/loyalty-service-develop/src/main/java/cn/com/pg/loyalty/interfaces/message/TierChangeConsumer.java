package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TaskService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.storageentity.TierChangeRecord;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-29 14:35
 */

@Component
@Slf4j
public class TierChangeConsumer extends AbstractConsumer {

    @Autowired
    private TaskService taskService;
    @Autowired
    private CacheService cacheService;

    @Override
    protected void doBusiness(JSONObject message){
        TierChangeRecord tierMessage = JSON.toJavaObject(message, TierChangeRecord.class);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructureById(tierMessage.getLoyaltyStructure());
        taskService.tierExpiredRecalculate(loyaltyStructure, tierMessage);
        log.info("任务【等级过期队列】处理完成.........");
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.TIER_EXPIRED_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.TIER_EXPIRED_QUEUE_NAME;
    }
}
