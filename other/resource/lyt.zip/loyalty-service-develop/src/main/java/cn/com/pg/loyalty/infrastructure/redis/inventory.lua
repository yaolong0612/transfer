for num, key in pairs(KEYS) do
    if (redis.call('EXISTS', key) ~= 1) then
        return -1;
    end
    local issued = tonumber(ARGV[num * 2 - 1]);
    local inventory = tonumber(ARGV[num * 2]);
    local hasIssued = redis.call('GET', key)
    if (tonumber(hasIssued) + issued > inventory) then
        return 0;
    end
end
for num, key in pairs(KEYS) do
    local issued = tonumber(ARGV[num * 2 - 1]);
    redis.call('INCRBY', key, issued)
end
return 1

for num, key in pairs(KEYS) do
redis.call('SETNX', key, ARGV[num]);
end

for num, key in pairs(KEYS) do
if (redis.call('EXISTS', key) == 1) then
redis.call('DECRBY', key, ARGV[num]);
end
end

return ARGV[1][1]