package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.*;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 * kcp期间订单积分
 */

@Getter
@Setter
public class MLPampersKCPOrderProperties extends RuleProperties {

    /**
     * 积分数
     */
    @Min(0)
    @NotNull
    private Integer basePoint;

    /**
     * 购买指定sku获得额外积分 sku列表
     */
    Set<String> skuS = new HashSet<>();
    /**
     * 购买指定sku额外积分
     */
    @Min(0)
    @NotNull
    private Integer extraPoint;
    /**
     * 购买指定sku加额外积分是否有次数限制
     * 0：不限制
     */
    private Integer extraPointLimit = 0;
    /**
     * 配置首购次购..单数积分
     */
    private List<NumMappingPoint> purchasePointMap = new ArrayList<>();

    /**
     * 是否需要区分订单渠道，需要：填写相应的channel 不需要：留空
     */
    List<String> channels = new ArrayList<>();

    /**
     * 是否与其他加积分竞争：多个活动取值最高分
     * false: 不参与 直接作为相加中一项
     * true: 参与竞争
     */
    private Boolean competition;

    public Integer basePoint() {
        return Optional.ofNullable(basePoint).orElse(0);
    }
    public Set<String> skuS() {
        return Optional.ofNullable(skuS).orElse(new HashSet<>());
    }
    public Integer extraPoint() {
        return Optional.ofNullable(extraPoint).orElse(0);
    }
    public Integer extraPointLimit() {
        return Optional.ofNullable(extraPointLimit).orElse(0);
    }
    public List<NumMappingPoint> purchasePointMap() {
        return Optional.ofNullable(purchasePointMap).orElse(new ArrayList<>());
    }
    public Boolean competition() {
        return Optional.ofNullable(competition).orElse(false);
    }

    public List<String> channels() {
        return Optional.ofNullable(channels).orElse(new ArrayList<>());
    }
}
