package cn.com.pg.loyalty.domain.pool;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDate;

import static cn.com.pg.loyalty.domain.pool.PoolMessage.EventType.*;

@Data
@ToString
@NoArgsConstructor
public class PoolMessage {
    private String eventId;
    //维护的积分
    private int point;
    //维护的是积分还是成长值
    private ValueType valueType;
    //品牌
    private String brand;
    //积分池的key
    private LocalDate key;
    //对应积分池的id
    private String poolId;
    //订单数量
    private int orderCount;
    //region
    private String region;
    //是否需要重新维护账户的即将过期积分
    private boolean needRecalculate;

    public PoolMessage(LoyaltyStructure structure, Transaction transaction, Account account) {
        this(structure, transaction, account, false);
    }

    public PoolMessage(LoyaltyStructure structure, Transaction transaction, Account account, boolean rollBack) {
        if (transaction.getLoyaltyId() == null) {
            throw new SystemException("please provide poolId", ResultCodeMapper.PARAM_ERROR);
        }
        EventType eventType = getEventType(transaction, rollBack);
        if (eventType == null) {
            throw new SystemException("event error", ResultCodeMapper.PARAM_ERROR);
        }
        this.eventId= UUIDUtil.generator();
        this.region = account.region();
        this.point = eventType.eventPoint(transaction, account.ownPoint(structure.subAccountType(transaction)));
        this.key = eventType.expiredDate(transaction);
        this.poolId = transaction.getLoyaltyId();
        this.orderCount = eventType.eventOrderCount(transaction);
        this.brand = transaction.brand();
        this.valueType = transaction.valueType(structure);
        //重新计算账户的即将过期积分
        this.needRecalculate = account.adapterSubAccount(structure, transaction).needRecalculatePointAboutExpire();

    }

    public Integer point() {
        return this.point;
    }

    public ValueType valueType() {
        return this.valueType;
    }

    public LocalDate key() {
        return this.key;
    }

    public String poolId() {
        return this.poolId;
    }

    public String loyaltyId() {
        return this.poolId;
    }

    public String brand() {
        return this.brand;
    }

    public int orderCount() {
        return this.orderCount;
    }


    public EventType getEventType(Transaction transaction, boolean rollBack) {
        if (TransactionType.REDEMPTION.equals(transaction.getTransactionType())) {
            return DEDUCT_REDEMPTION_POINT;
        }
        if (TransactionType.INTERACTION.equals(transaction.getTransactionType())) {
            if (rollBack) {
                return ROLL_INTERACTION_POINT;
            }
            if (transaction.point() > 0) {
                return ADD_POINT;
            }
            return DEDUCT_INTERACTION_POINT;
        }
        if (TransactionType.ORDER.equals(transaction.getTransactionType())) {
            if (rollBack) {
                return REFUND_ORDER_POINT;
            }
            Order order = (Order) transaction;
            if (order.refundOrder()) {
                return REFUND_ORDER_POINT;
            }
            return ADD_POINT;
        }
        return null;
    }

    public enum EventType {
        /**
         * 退单事件,操作的是map中与之对应的key
         */
        REFUND_ORDER_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                Order order = (Order) transaction;
                return -Math.abs(order.refundPoint());
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                Order order = (Order) transaction;
                if (order.point() <= 0) return -1;
                return 0;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return transaction.getExpiredTime().toLocalDate();
            }
        },

        ROLL_ORDER_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                return -Math.abs(transaction.point());
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                return 1;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return transaction.getExpiredTime().toLocalDate();
            }
        },

        /**
         * 扣减积分事件，操作的是最后面的key
         */
        DEDUCT_INTERACTION_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                return -Math.abs(transaction.point());
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                return 0;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return null;
            }
        },

        ROLL_INTERACTION_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                return -Math.abs(transaction.point());
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                return 0;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return transaction.getExpiredTime().toLocalDate();
            }
        },

        DEDUCT_REDEMPTION_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                return -Math.abs(transaction.point());
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                return 0;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return null;
            }
        },

        /**
         * 加积分事件，
         */
        ADD_POINT() {
            @Override
            int eventPoint(Transaction transaction, int accountAvailablePoint) {
                if (accountAvailablePoint <= 0) {
                    return 0;
                }
                int point = Math.abs(transaction.point());
                return Math.min(point, accountAvailablePoint);
            }

            @Override
            int eventOrderCount(Transaction transaction) {
                if (TransactionType.ORDER.equals(transaction.getTransactionType())) {
                    return 1;
                }
                return 0;
            }

            @Override
            LocalDate expiredDate(Transaction transaction) {
                return transaction.getExpiredTime().toLocalDate();
            }
        };


        abstract int eventPoint(Transaction transaction, int accountAvailablePoint);

        abstract int eventOrderCount(Transaction transaction);

        abstract LocalDate expiredDate(Transaction transaction);
    }

}
