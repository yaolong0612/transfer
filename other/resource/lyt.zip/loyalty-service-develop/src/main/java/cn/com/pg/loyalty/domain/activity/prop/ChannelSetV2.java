package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:51
 */
@Data
public class ChannelSetV2 {

    @NotNull
    @Valid
    private OnlineHolidayChannel channelName;
    private List<Grade> grades;
    @Min(0)
    private double multiplePointLimitAmount;
    /**
     * 超过限制金额部分的倍数
     */
    @Min(0)
    private double moreThanLimitMultiple;

    private List<String> storeCodes = new ArrayList<>();

    public List<Grade> grades(){
        //给grade加上默认，防止配置的时候漏配一倍积分的项
        if (!this.grades.stream().anyMatch(grade -> grade.getBaseAmount() == 0)){
            Grade grade = new Grade(0, 1);
            this.grades.add(grade);
        }
        return this.grades;
    }

    /**
     * 只有这5个渠道才会用到这个活动模板, 20211222新增VIP
     */
    public enum OnlineHolidayChannel {
        /**
         * 线下JD
         */
        JD,
        /**
         * 线下TMALL
         */
        TMALL,
        /**
         * 百货商店
         */
        DS,
        /**
         * 商业超市
         */
        ORC,
        /**
         * C2柜台
         */
        COUNTER,
        /**
         * 临时柜
         */
        TEMPORARY,
        /**
         * 微信渠道
         */
        WECHAT,
        /**
         * 小程序
         */
        WECHAT_MINI_PROGRAM,

        /**
         * 唯品会
         */
        VIP,
        /**
         * 抖音
         */
        DOUYIN

    }
}
