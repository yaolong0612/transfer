package cn.com.pg.loyalty.application.rule.tier;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevel;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.Transaction.PointTypeEnum;
import cn.com.pg.loyalty.domain.transaction.TransactionRepository;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;



@Slf4j
@Rule(name = "calculate the tier by point",
        description = "calculate the tier by point")
public class CalculateTierByPointRule {
    private static final String ACTIVITY_DESCRIPTION_TIER_AWARD_POINT = "bonus points of tier";
    private static final String RETURN_ACTIVITY_DESCRIPTION_TIER_AWARD_POINT = "refund order trigger tier down, return bonus points of tier";

    /**
     * 会员体系及等级有效期
     * 为了不影响其他品牌，这里进行了品牌过滤。考虑到积极对会员体系重构，暂时先做的简单一些
     */
    private static final Map<String, String> tierAndExpiredTimeMap = new HashMap<>();



    @Condition
    public boolean isExecuteRule(@Fact("account") Account account,
                                 @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                                 @Fact("transaction") Transaction transaction) {
        boolean matchStructure = tierAndExpiredTimeMap.entrySet().stream()
                .anyMatch(set -> loyaltyStructure.contain(set.getValue(), set.getKey()));
        if (!matchStructure) {
            return false;
        }
        if (loyaltyStructure.tierLevelSeries().tierLevelNums() <= 1) {
            return false;
        }
        boolean expired = account.tier(loyaltyStructure.name()).judgeTierExpired();
        //过期
        if (expired) {
            return true;
        }
        //不过期
        if (transaction == null) {
            return false;
        }

        if (!ValueType.DEFAULT.equals(transaction.valueType(loyaltyStructure))) {
            return false;
        }
        boolean isOrder = transaction.getTransactionType() == TransactionType.ORDER;
        //有效的交互积分
        boolean isEffInteraction = transaction.getTransactionType() == TransactionType.INTERACTION && transaction.point() > 0;

        return isOrder || isEffInteraction;
    }

    /**
     * @param account
     * @param loyaltyStructure
     * @param transaction
     * @param transactionRepository
     * @param messageService
     * @param ruleResult            1.计算之前先判断等级是否已经过期了，过期了则需要先重算等级
     *                              2.account数据恢复后，进行等级计算
     */
    @Action
    public void upgrade(@Fact("account") Account account,
                        @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                        @Fact("transaction") Transaction transaction,
                        @Fact("transactionRepository") TransactionRepository transactionRepository,
                        @Fact("messageService") MessageService messageService,
                        @Fact("ruleResult") RuleResult ruleResult) {

        LocalDateTime endAt = calculateEndTime(loyaltyStructure, account, transaction, transactionRepository);
        LocalDateTime startAt = endAt.minusYears(loyaltyStructure.tierLevelSeries().getTierEffectiveYear());

        Tier newTier = calculateTierLevel(loyaltyStructure, account, transaction, startAt, endAt, transactionRepository);
        calculateAwardPoint(account, loyaltyStructure, transaction, messageService, newTier.getLevel());
        account.tier(loyaltyStructure, newTier);
        ruleResult.success();
        log.info("等级计算结束");
    }

    private void calculateAwardPoint(Account account, LoyaltyStructure loyaltyStructure, Transaction transaction,
                                     MessageService messageService, String calculationLevel) {
        TierLevelSeries levelSeries = loyaltyStructure.tierLevelSeries();
        Tier tier = account.tier(loyaltyStructure.name());

        //比较时升级或者降级
        int compareLevelGap = levelSeries.compare(calculationLevel, tier.getLevel());
        if (compareLevelGap == 0) {
            if (tier.judgeTierExpired()) {
                addGradAward(loyaltyStructure, account, messageService, levelSeries, tier.getLevel());
            }
            return;
        }
        if (compareLevelGap > 0) {
            addAwardPoint(loyaltyStructure, account, messageService, tier.getLevel(), compareLevelGap, levelSeries);
            return;
        }
        if (changeTierAfterRefund(loyaltyStructure, account, transaction)) {
            refundAwardPoint(loyaltyStructure, transaction, messageService, tier.getLevel(), compareLevelGap, levelSeries);
        }
    }


    private void addGradAward(LoyaltyStructure loyaltyStructure, Account account,
                              MessageService messageService, TierLevelSeries levelSeries, String preLevel) {
        TierLevel currentLevel = levelSeries.currentLevel(preLevel);
        if (currentLevel.getGradingAward() > 0) {
            int point = Math.abs(currentLevel.getGradingAward());
            InteractionMessage message = createRewardMessage(loyaltyStructure, account, point);
            messageService.sendMessageForAddInteractionPoint(message, 1);
        }
    }


    private void refundAwardPoint(LoyaltyStructure loyaltyStructure, Transaction transaction, MessageService messageService,
                                  String preLevel, int compareLevelGap, TierLevelSeries levelSeries) {
        TierLevel lastTierLevel = levelSeries.currentLevel(preLevel);
        for (int i = 0; i < Math.abs(compareLevelGap); i++) {
            if (lastTierLevel.getUpgradeAward() > 0) {
                int point = -lastTierLevel.getUpgradeAward();
                InteractionMessage message = createRefundRewardMessage(loyaltyStructure, transaction, point);
                messageService.sendMessageForAddInteractionPoint(message, i + 1);
            }
            lastTierLevel = levelSeries.lastLevel(lastTierLevel.getLevelName());
        }
    }

    private void addAwardPoint(LoyaltyStructure loyaltyStructure, Account account, MessageService messageService,
                               String preLevel, int compareLevelGap, TierLevelSeries levelSeries) {
        TierLevel nextTierLevel = levelSeries.currentLevel(preLevel);
        for (int i = 0; i < compareLevelGap; i++) {
            nextTierLevel = levelSeries.nextLevel(nextTierLevel.getLevelName());
            if (nextTierLevel.getUpgradeAward() > 0) {
                int point = Math.abs(nextTierLevel.getUpgradeAward());
                InteractionMessage message = createRewardMessage(loyaltyStructure, account, point);
                messageService.sendMessageForAddInteractionPoint(message, i + 1);
            }
        }
    }

    private InteractionMessage createRewardMessage(LoyaltyStructure loyaltyStructure, Account account, int point) {
        return InteractionMessage.createDefault(loyaltyStructure, account.memberId(), PointTypeEnum.TIER_REWARD.name(),
                point, ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
    }


    private InteractionMessage createRefundRewardMessage(LoyaltyStructure loyaltyStructure, Transaction transaction,
                                                         int point) {
        InteractionMessage message = InteractionMessage.createDefault(loyaltyStructure, transaction.getMemberId(),
                PointTypeEnum.TIER_REWARD_REFUND.name(), point, RETURN_ACTIVITY_DESCRIPTION_TIER_AWARD_POINT);
        message.setCreatedTime(transaction.getCreatedTime());
        return message;
    }

    private LocalDateTime calculateEndTime(LoyaltyStructure structure, Account account, Transaction transaction,
                                           TransactionRepository transactionRepository) {
        Tier tier = account.tier(structure.name());
        LocalDateTime lastEndDay = LoyaltyDateTimeUtils.getEndTimeOfDay(LocalDateTime.now()).minusDays(1);
        LocalDateTime expiredNowUpTime = lastEndDay.minusYears(structure.tierLevelSeries().getTierEffectiveYear());

        Optional<String> optional = transactionRepository.findMaxCreatedTimeOfAddTransaction(account.loyaltyId(), ValueType.DEFAULT);
        LocalDateTime endAt = optional.map(LoyaltyDateTimeUtils::stringToLocalDateTime).orElse(expiredNowUpTime);

        boolean expired = account.tier(structure.name()).judgeTierExpired();

        if (expired && endAt.isBefore(tier.getExpiredTime())) {
            endAt = tier.getExpiredTime();
        }

        if (transaction != null && endAt.isBefore(transaction.getCreatedTime())) {
            endAt = transaction.getCreatedTime();
        }

        if (!endAt.isAfter(expiredNowUpTime)) {
            endAt = lastEndDay;
        }

        return endAt;
    }

    private boolean triggerByOrderRefund(Transaction transaction) {
        if (transaction == null) {
            return false;
        }
        if (!(transaction instanceof Order)) {
            return false;
        }
        return ((Order) transaction).refundOrder();

    }

    private Tier calculateTierLevel(LoyaltyStructure structure, Account account,
                                    Transaction transaction, LocalDateTime startAt,
                                    LocalDateTime endAt, TransactionRepository transactionRepository) {
        List<Transaction> transactions = transactionRepository
                .findTransactionsWitTypeAndCreateTimeBetween(account.loyaltyId(), ValueType.DEFAULT, startAt, endAt);
        transactions = filterAddPointTransactions(transactions);

        List<Transaction> rewards = new ArrayList<>();
        //如果退单后有等级变动，
        if (changeTierAfterRefund(structure, account, transaction)) {
            rewards = getRewardTransactionsAfterRefund(transaction, transactions);
            transactions.removeAll(rewards);
            transactions = filterRefundOrder(transactions, transaction);
        }
        if (transaction != null) {
            transactions.add(transaction);
        }

        int point = transactions.stream().mapToInt(Transaction::point).sum();
        int rewardPoint = rewards.stream().mapToInt(Transaction::point).sum();
        int totalPoint = point + rewardPoint;
        Tier tier = account.tier(structure.name());

        String calculationLevel = calculationLevel(structure, tier.getLevel(), totalPoint);
        int compareLevelGap = structure.tierLevelSeries().compare(calculationLevel, tier.getLevel());
        //如果升级,表示不是退单
        if (compareLevelGap > 0) {
            return new Tier(structure, calculationLevel, tier.getLevel(), endAt, totalPoint);
        }
        //如果存在奖励积分，逐级回退奖励积分
        calculationLevel = tier.getLevel();

        List<Transaction> refundRewards = new ArrayList<>();
        for (Transaction reward : rewards) {
            totalPoint -= reward.point();
            calculationLevel = calculationLevel(structure, calculationLevel, totalPoint);
            compareLevelGap = structure.tierLevelSeries().compare(calculationLevel, tier.getLevel());
            if (compareLevelGap >= -1) {
                break;
            }
            refundRewards.add(reward);
        }
        rewards.removeAll(refundRewards);
        //延后没有回退的奖励积分
        rewards.forEach(item -> {
            item.setCreatedTime(endAt);
            item.setUpdatedTime(LocalDateTime.now());
            transactionRepository.save(item);
        });


        if (StringUtils.equals(tier.getLevel(), calculationLevel)) {
            tier.setTierPoint(totalPoint);
            return tier;
        }
        return new Tier(structure, calculationLevel, tier.getLevel(), endAt, totalPoint);
    }

    private List<Transaction> getRewardTransactionsAfterRefund(Transaction transaction, List<Transaction> transactions) {
        return transactions.stream()
                .filter(item -> rewardAfterRefundOrder(transaction, item))
                .filter(item -> item.point() > 0)
                .sorted(Comparator.comparing(Transaction::getCreatedTime).reversed()
                        .thenComparingInt(Transaction::point).reversed())
                .collect(Collectors.toList());
    }

    private List<Transaction> filterRefundOrder(List<Transaction> transactions, Transaction transaction) {
        return transactions.stream()
                .filter(item -> (!item.getId().equals(transaction.getId()))).collect(Collectors.toList());

    }


    private List<Transaction> filterAddPointTransactions(List<Transaction> transactions) {
        return transactions.stream()
                .filter(item -> TransactionType.REDEMPTION != item.getTransactionType())
                .filter(item -> item.point() > 0)
                .collect(Collectors.toList());

    }

    private boolean changeTierAfterRefund(LoyaltyStructure structure, Account account, Transaction transaction) {
        if (!triggerByOrderRefund(transaction)) {
            return false;
        }
        return !account.tier(structure.name()).getUpgradedTime().isBefore(transaction.getCreatedTime());
    }

    private boolean rewardAfterRefundOrder(Transaction order, Transaction tra) {
        return PointTypeEnum.TIER_REWARD.name().equals(tra.getPointType()) && !tra.getCreatedTime().isBefore(order.getCreatedTime());
    }

    /**
     * 根据有效订单金额计算会员等级
     */
    private String calculationLevel(LoyaltyStructure structure, String currentLevel, int tierPoint) {
        TierLevelSeries levelSeries = structure.tierLevelSeries();
        String nextLevel = levelSeries.nextLevelByPoint(currentLevel, tierPoint).getLevelName();
        while (levelSeries.compare(currentLevel, nextLevel) != 0) {
            currentLevel = nextLevel;
            nextLevel = levelSeries.nextLevelByPoint(currentLevel, tierPoint).getLevelName();
        }
        return nextLevel;
    }

}
