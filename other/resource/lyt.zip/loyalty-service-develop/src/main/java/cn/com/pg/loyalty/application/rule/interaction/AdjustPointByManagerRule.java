package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.List;

/**
 * @description:
 * @author: Artemus wang on 2019-07-09 15:12
 */
@Rule(name = "customer service adjust point rule",
        description = "customer service add point")
@Slf4j
public class AdjustPointByManagerRule {

    @Condition
    public boolean isAdjustPointByCsRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointTimesRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_BY_MANAGER;
    }

    @Action
    public void addPoint(
            @Fact("loyaltyStructure") LoyaltyStructure structure,
            @Fact("activities") List<Activity> activities,
            @Fact("interaction") Interaction interaction,
            @Fact("point") Integer point,
            @Fact("ruleResult") RuleResult ruleResult,
            @Fact("account") Account account,
            @Fact("token") String token,
            @Fact("reason") String reason
    ) {
        log.info("manager手动调整积分：{}", point);
        Activity activity = activities.get(0);
        String userName = null;
        try {
            if (StringUtils.isBlank(token)) {
                throw new SystemException("token must",ResultCodeMapper.PARAM_ERROR);
            }
            userName = JwtUtils.getUsernameFromToken(token);
        } catch (Exception e) {
            ruleResult.addException(new SystemException("Param: ".concat("authorization").concat(" is empty or wrong"), ResultCodeMapper.PARAM_ERROR));
            return;
        }
        if (point < 0) {
            Integer accountAvailablePoint = account.availablePoint(structure.accountTypeOfDefault());
            if (point + accountAvailablePoint < 0) {
                ruleResult.addException(new SystemException("Requiring" + point + "points to adjust the bonus points of user,user dosen't have enough bonus points to use" + accountAvailablePoint, ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                return;
            }
        }
        interaction.addPoint(activity, point, reason, userName);
        log.info("manager 手动调整积分完成, 记录interaction: {}", JSON.toJSONString(interaction));
        ruleResult.success();
    }

}
