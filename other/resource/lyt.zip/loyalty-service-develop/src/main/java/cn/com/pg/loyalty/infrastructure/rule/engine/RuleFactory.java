package cn.com.pg.loyalty.infrastructure.rule.engine;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Map;

@Component
public class RuleFactory implements ApplicationContextAware {
    /**
     * 注册rule
     * @param applicationContext
     * @throws BeansException
     */
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        registryRules(applicationContext);
    }

    private void registryRules(ApplicationContext applicationContext) {
        Map<String, Object> beans = applicationContext.getBeansWithAnnotation(Register.class);
        //注册rule
        registryRules(beans);
        registryRulesWithLabel(beans);
    }

    protected void registryRules(Map<String, Object> rules) {
        RuleContext.initContext();
        for (Object rule : rules.values()) {
            Register register = rule.getClass().getAnnotation(Register.class);
            RuleType ruleType = register.ruleType();
            RuleScope scope = register.scope();
            RuleLable[] ruleLabels = register.ruleLables();
            RuleContext.RuleParam ruleParam = new RuleContext.RuleParam(scope, ruleType, ruleLabels, rule);
            if (!RuleScope.BEFORE_LIMIT_RULE.equals(scope) && !RuleScope.CALCULATE_RULE.equals(scope)
                    && !RuleScope.AFTER_LIMIT_RULE.equals(scope)){
                continue;
            }
            RuleContext.RULES.get(scope).add(ruleParam);
        }
    }

    protected void registryRulesWithLabel(Map<String, Object> rules) {
        RuleContext.initContextWithLabel();
        for (Object rule : rules.values()) {
            Register register = rule.getClass().getAnnotation(Register.class);
            RuleType ruleType = register.ruleType();
            RuleScope scope = register.scope();
            RuleLable[] ruleLabels = register.ruleLables();
            RuleContext.RuleParam ruleParam = new RuleContext.RuleParam(scope, ruleType, ruleLabels, rule);
            if (ruleLabels.length <= 0){
                continue;
            }
            Arrays.stream(ruleLabels).forEach(ruleLabel -> RuleContext.LABEL_RULES.get(ruleLabel).add(ruleParam));
        }
    }
}
