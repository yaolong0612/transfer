package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/1
 */
@Getter
@Setter
public class BirthdayOrderPropertiesV2 extends BasicOrderRulePropertiesV2 {


    /**
     * 是否需要区分订单渠道，需要：填写相应的channel 不需要：留空
     * 未填写 全渠道适配，填写了只适配填写的渠道
     */
    private List<String> channels = new ArrayList<>();
    /**
     * 生日类型
     */
    @NotNull
    @Valid
    private BIRTHDAY_TYPE birthdayType;


    /**
     * 只有这5个渠道才会用到这个活动模板
     */
    public enum BIRTHDAY_TYPE {
        /**
         * 会员本人
         */
        SELF,
        /**
         * 宝宝生日
         */
        BABY,
    }

}
