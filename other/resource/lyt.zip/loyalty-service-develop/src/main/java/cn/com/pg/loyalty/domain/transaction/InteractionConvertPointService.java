package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * 交互活动转换积分记录Service
 *
 * @author vincenzo
 * @description
 * @date 2022/1/25
 */
@Slf4j
@Service
public class InteractionConvertPointService {

    public Optional<Interaction> checkAndGenerateDeductTransitPointInteraction(boolean convertPoint, Interaction pointInteraction, LoyaltyStructure loyaltyStructure, int clientPoint, Activity activity) {
        if (activity.ruleTemplate() != RuleTemplate.INTERACTION_CONVERT_POINT_RULE || (Boolean.FALSE.equals(convertPoint) || clientPoint <= 0)) {
            return Optional.empty();
        }
        //生成转换记录
        Interaction transitPointInteraction = new Interaction(pointInteraction.getLoyaltyId(), pointInteraction.getBrand(), pointInteraction.getChannel(), loyaltyStructure, pointInteraction.getMemberId(), pointInteraction.getExternalBusinessId());
        transitPointInteraction.updateValueType(loyaltyStructure,ValueType.TRANSIT);
        // 由于消费者从前端输入是正数的过渡积分需要加负号
        transitPointInteraction.addPoint(activity, -clientPoint);
        return Optional.of(transitPointInteraction);
    }
}
