package cn.com.pg.loyalty.infrastructure.monitoring;

import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.time.LocalDateTime;

/**
 * @author xingliangzhan
 * @date 2019/8/5
 * KpiLogger注解Aop
 */
@Slf4j
@Aspect
@Component
public class KpiLogAop implements Ordered {

    private static final String LOG_INFO = "OperationName: {}, isSuccess: {}, errorCode: {}, cost: {},errorMsg:{}, correlationId: {}";

    @Autowired
    private KpiTemplate kpiTemplate;

    /**
     * 注解 @KpiLog执行前后AOP
     *
     * @param pjp
     * @return
     * @throws Throwable
     */
    @Around("@annotation(cn.com.pg.loyalty.application.dependence.KpiLog)")
    public Object aroundMethod(ProceedingJoinPoint pjp) throws Throwable {
        final long startTime = System.currentTimeMillis();
        LocalDateTime startDateTime = LocalDateTime.now();
        Object response;
        String errorCode = String.valueOf(ResultCodeMapper.SUCCESS.getCode());
        String errorMessage = "Success";
        boolean isSuccess = true;
        MethodSignature ms = (MethodSignature) pjp.getSignature();
        Method method = ms.getMethod();
        String name = method.getAnnotation(KpiLog.class).name();
        KpiLog.KpiType kpiType = method.getAnnotation(KpiLog.class).type();
        long timeout = method.getAnnotation(KpiLog.class).timeout();
        boolean onlyFailure = method.getAnnotation(KpiLog.class).onlyFailure();
        try {
            if (StringUtils.isBlank(name)) {
                name = method.getName();
            }
            response = pjp.proceed();
        } catch (Throwable throwable) {
            log.error("KpiLog Around error, error message is {}", throwable.getMessage(), throwable);
            errorCode = String.valueOf(ResultCodeMapper.UNEXPECTED_ERROR.getCode());
            isSuccess = false;
            errorMessage = throwable.getMessage();
            throw throwable;
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            boolean isSend = false;
            //只有costTime > timeout的数据才会发送kpi
            if (costTime > timeout) {
                isSend = true;
            }
            //如果onlyFailure=true，只有失败的才会发送kpi
            if (!onlyFailure || !isSuccess) {
                isSend = true;
            }
            log.info(LOG_INFO, name,
                    isSuccess, errorCode, costTime, errorMessage, getCorrelationId());
            if (isSend) {
                kpiTemplate.sendDependency(getCorrelationId(), name, kpiType, startDateTime, costTime,
                        errorCode, errorMessage, isSuccess, null);
            }
        }
        return response;
    }

    @Around("@within(org.springframework.stereotype.Repository)")
    public Object monitoring(ProceedingJoinPoint pjp) throws Throwable {
        LocalDateTime startLocalDateTime = LocalDateTime.now();
        long startTime = System.currentTimeMillis();
        Object result = null;
        boolean isSuccess = true;
        String errMsg = null;
        try {
            result = pjp.proceed();
        } catch (Throwable throwable) {
            isSuccess = false;
            errMsg = throwable.getMessage();
            throw throwable;
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            String className = pjp.getSignature().getDeclaringType().getName();
            String apiName = className.substring(className.lastIndexOf('.') + 1).concat("-").concat(pjp.getSignature().getName());
            String errorCode = isSuccess ? String.valueOf(ResultCodeMapper.SUCCESS.getCode()) : String.valueOf(ResultCodeMapper.UNEXPECTED_ERROR.getCode());
            log.info(LOG_INFO, apiName,
                    isSuccess, errorCode, costTime, errMsg, getCorrelationId());
            if (!isSuccess || costTime > 100) {
                kpiTemplate.sendDependency(getCorrelationId(), apiName, KpiLog.KpiType.SQL, startLocalDateTime, costTime,
                        errorCode, errMsg, isSuccess, null);

            }
        }
        return result;
    }

    @Around("target(org.springframework.data.redis.core.RedisTemplate)")
    public Object monitoringRedis(ProceedingJoinPoint pjp) throws Throwable {
        long startTime = System.currentTimeMillis();
        LocalDateTime startLocalDateTime = LocalDateTime.now();
        Object result = null;
        boolean isSuccess = true;
        String errMsg = null;
        try {
            result = pjp.proceed();
        } catch (Throwable throwable) {
            isSuccess = false;
            errMsg = throwable.getMessage();
            throw throwable;
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            String className = pjp.getSignature().getDeclaringType().getName();
            String apiName = className.substring(className.lastIndexOf('.') + 1).concat("-").concat(pjp.getSignature().getName());
            String errorCode = isSuccess ? String.valueOf(ResultCodeMapper.SUCCESS.getCode()) : String.valueOf(ResultCodeMapper.UNEXPECTED_ERROR.getCode());
            log.info(LOG_INFO, apiName,
                    isSuccess, errorCode, costTime, errMsg, getCorrelationId());
            if (!isSuccess || costTime > 100) {
                kpiTemplate.sendDependency(getCorrelationId(), apiName, KpiLog.KpiType.REDIS, startLocalDateTime, costTime,
                        errorCode, errMsg, isSuccess, null);
            }
        }
        return result;
    }

    @Override
    public int getOrder() {
        return Integer.MIN_VALUE;
    }

    private String getCorrelationId() {
        RequestContext requestContext = RequestContext.getCurrentContext();
        if (requestContext == null) {
            return "";
        } else {
            return requestContext.getCorrelationId();
        }
    }
}
