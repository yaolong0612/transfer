package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @author: Ysnow
 * @Date: 2019/6/27 20:34
 * @Description:
 */
@Getter
@Setter
public class MlOlayScanCodePlusPointProperties extends RuleProperties {
    private String description = "No Need Properties";
}
