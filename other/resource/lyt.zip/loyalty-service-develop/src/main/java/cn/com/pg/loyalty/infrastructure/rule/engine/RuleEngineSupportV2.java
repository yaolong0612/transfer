package cn.com.pg.loyalty.infrastructure.rule.engine;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rule;
import org.jeasy.rules.api.Rules;
import org.jeasy.rules.api.RulesEngine;
import org.jeasy.rules.core.DefaultRulesEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Getter
@Slf4j
@Scope(value = "prototype")
@Component
public class RuleEngineSupportV2 {

    private RulesEngine rulesEngine;

    private Facts facts;

    private Rules rules;

    private RuleResult ruleResult;

    @Autowired
    private RuleContext ruleContext;

    public RuleEngineSupportV2() {
        rulesEngine = new DefaultRulesEngine();
        facts = new Facts();
        ruleResult = new RuleResult();
        facts.put(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT, ruleResult);
        rules = new Rules();
    }

    public RuleEngineSupportV2 addFact(String name, Object object) {
        facts.put(name, object);
        return this;
    }

    public RuleEngineSupportV2 registerRule(Object rule) {
        this.rules.register(rule);
        return this;
    }

    public void skipOnFirstFailedRule(boolean skip) {
        rulesEngine.getParameters().setSkipOnFirstFailedRule(skip);
    }

    public void throwExceptionAfterFail() {
        rulesEngine.getRuleListeners().clear();
        rulesEngine.getRuleListeners().add(new ThrowFailListener());
    }

    public RuleEngineSupportV2 fire() {
        rulesEngine.fire(rules, facts);
        Map<Rule, Boolean> ruleBooleanMap = rulesEngine.check(rules, facts);
        boolean flag = true;
        for (Map.Entry<Rule, Boolean> entry : ruleBooleanMap.entrySet()) {
            if (Boolean.TRUE.equals(entry.getValue())) {
                flag = false;
                break;
            }
        }
        if (flag) {
            return this;
        }
        checkAnyResult();
        rules.clear();
        return this;
    }

    /**
     * 如果有任何异常，就将异常抛出
     */
    private void checkAnyResult() {
        log.info("Check the Rule Result");
        if (!ruleResult.getSystemExceptions().isEmpty()) {
            log.info("Exception number: {}", ruleResult.getSystemExceptions().size());
            throw ruleResult.getSystemExceptions().get(0);
        }
    }

    public void buildRulesEngineSupport(List<Object> rules) {
        rules.forEach(this::registerRule);
    }

    public void calculateOrderPoint() {
        ruleContext.calculateOrderPoint(this);
    }

    public void calculateInteractionPoint(RuleEngineSupportV2 ruleEngineSupportV2) {
        ruleContext.calculateInteractionPoint(this);
    }

    public void calculateRedemptionPoint() {
        ruleContext.calculateRedemptionPoint(this);
    }

    public void calculateLabelRule(RuleLable ruleLable, RuleType ruleType) {
        ruleContext.calculateLabelRule(ruleLable, ruleType, this);
    }

    public void calculateTier() {
        ruleContext.calculateTier(this);
    }
}
