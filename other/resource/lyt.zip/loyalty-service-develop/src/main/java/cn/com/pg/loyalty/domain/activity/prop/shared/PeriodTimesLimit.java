package cn.com.pg.loyalty.domain.activity.prop.shared;

/**
 * @author vincenzo
 * @description
 * @date 2022/1/19
 */

import cn.com.pg.loyalty.domain.activity.prop.PeriodDateType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 时间段内次数限制
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PeriodTimesLimit {
    /**
     * 限定时间方式
     */
    private PeriodDateType type;

    /**
     * 时间间隔
     */
    private int interval;
    /**
     * 加减积分次数
     */
    private Integer times;


}
