package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.TableStorageTemplate;
import cn.com.pg.loyalty.application.rule.interaction.RegistryRule;
import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.lock.MutexLock;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Simon
 * Account Service
 */
@Service
@Slf4j
public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private BatchUpdateDBComponent batchUpdateDBComponent;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private TransactionRepositoryV2 transactionRepositoryV2;
    @Autowired
    private InteractionRepository interactionRepository;

    @Autowired
    private TableStorageTemplate tableStorageTemplate;

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;

    @Autowired
    private MessageService messageService;

    @Autowired
    private TierRulesCalculateAble tierRulesCalculateEngine;

    private static final String USER_REGISTER_LOCK = "ACCOUNT:LOCK:MEMBER_ID:";
    private static final int LOCK_TIME_SECONDS = 1;

    public enum PointCategory {
        /**
         * 支出
         */
        BURN,
        /**
         * 收入
         */
        EARN
    }

    /**
     * 注册：注册+绑定，注册
     * 绑定：绑定
     * 对品牌来说，如果是新用户，也算作注册
     *
     * @param memberId
     * @param brand
     * @param channel
     * @param bindId
     * @param region
     * @return
     */
    @MutexLock(lockKeys = {"#brand", "#memberId"}, expiredTime = 20)
    public Account register(String memberId, String brand, String channel, String bindId, LocalDateTime registerTime,
                            String region, String babyBirthYearAndMonth, Account.RegistryEvent registryEvent) {
        String redisKey = USER_REGISTER_LOCK.concat(brand).concat(":").concat(memberId);
        try {
            Boolean isExists = stringRedisTemplate.opsForValue().setIfAbsent(redisKey, memberId, LOCK_TIME_SECONDS, TimeUnit.SECONDS);
            if (isExists != null && !isExists) {
                log.error("注册频繁memberId: {}", memberId);
                throw new SystemException("Registrating frequently is not allowed", ResultCodeMapper.ACCOUNT_REGISTER_FREQUENTLY);
            }
            LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
            Account account = fetchAccountByMemberId(loyaltyStructure, memberId);
            if (account == null) {
                account = new Account(memberId, loyaltyStructure);
            }
            account.register(loyaltyStructure, brand, channel, bindId, registerTime);
            log.info(registryEvent.name());
            account.babyBirthYearAndMonth(babyBirthYearAndMonth);
            // 如果pointType查不到，那么activities 也会为空 怎不走加分代码
            String pointTypeName = Transaction.PointTypeEnum.REGISTER.name();
            long startTime = System.currentTimeMillis();
            Optional<PointType> optionalPointType = cacheService.findByPointTypeAndLoyaltyStructureAndTransactionType(pointTypeName, loyaltyStructure.name(), TransactionType.INTERACTION);
            List<Activity> activities = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(pointTypeName, loyaltyStructure.name());
            log.info("fetchAvailableActivitiesByPointType-costTime: {}ms", System.currentTimeMillis() - startTime);
            Interaction interaction = new Interaction(account.loyaltyId(), brand, channel, loyaltyStructure, memberId);
            boolean needSaveInteraction = false;
            if (!CollectionUtils.isEmpty(activities) && optionalPointType.isPresent()) {
                RuleEngineSupport registryRuleEngine = new RuleEngineSupport();
                registryRuleEngine.addFact("activities", activities)
                        .addFact("account", account)
                        .addFact("interaction", interaction)
                        .addFact("brand", brand)
                        .addFact("channel", channel)
                        .addFact("pointType", optionalPointType.get())
                        .addFact("registryEvent", registryEvent)
                        .addFact("interactionRepository", interactionRepository)
                        .addFact("ruleTemplate", registryEvent.ruleTemplate());
                RegistryRule registryRule = new RegistryRule();
                registryRuleEngine.registerRule(registryRule).fire();

                tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, interaction));
                tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, false));

                if (interaction.point() != 0) {
                    needSaveInteraction = true;
                    account.calculatePoint(interaction, loyaltyStructure);
                }
                log.info("processing registryRuleEngine-costTime: {}ms", System.currentTimeMillis() - startTime);
            }
            log.info("保存到数据库");
            //如果加积分，需要计算等级，则需要加上等级的计算。olay暂时不需要
            if (needSaveInteraction) {
                batchUpdateDBComponent.saveTransactionAndAccount(interaction, account);
                messageService.sendMessage4PointPool(new PoolMessage(loyaltyStructure, interaction, account));
            } else {
                accountRepository.save(account);
            }
            //由于Olay的Loyalty ID不是根据Member id生成，所以需要缓存在redis中
            if (loyaltyStructure.checkMlBrand(BrandV2.OLAY)) {
                cacheService.cacheMemberIdLoyaltyIdMapping(loyaltyStructure.marketingProgramId(),
                        memberId, account.loyaltyId());
            }
            log.info("end register/bind costTime: {}ms", System.currentTimeMillis() - startTime);
            return account;
        } finally {
            stringRedisTemplate.delete(redisKey);
        }
    }

    public PageableResult<Transaction> findPointHistory(String memberId, String valueType, Integer pageSize, Integer page,
                                                        LocalDateTime start, LocalDateTime end, LoyaltyStructure loyaltyStructure,
                                                        PointCategory pointCategory, Locale language) {
        if (null == page || null == pageSize) {
            page = 1;
            pageSize = 100;
        }
        String startTimeStampStr = null;
        if (start == null) {
            start = LocalDateTime.now().minusYears(2);
        } else {
            startTimeStampStr = String.valueOf(start.toEpochSecond(ZoneOffset.MAX));
        }
        String endTimeStampStr = null;
        if (end == null) {
            end = LocalDateTime.now();
        } else {
            endTimeStampStr = String.valueOf(end.toEpochSecond(ZoneOffset.MAX));
        }
        String redisKey;
        if (PointCategory.BURN == pointCategory) {
            redisKey = cacheService.getKey(CacheService.KeyEnum.FIND_POINT_HISTORY, loyaltyStructure.name(), memberId,
                    PointCategory.BURN.name(), startTimeStampStr, endTimeStampStr, valueType);
        } else if (PointCategory.EARN == pointCategory) {
            redisKey = cacheService.getKey(CacheService.KeyEnum.FIND_POINT_HISTORY, loyaltyStructure.name(), memberId,
                    PointCategory.EARN.name(), startTimeStampStr, endTimeStampStr, valueType);
        } else {
            redisKey = cacheService.getKey(CacheService.KeyEnum.FIND_POINT_HISTORY, loyaltyStructure.name(), memberId,
                    startTimeStampStr, endTimeStampStr, valueType);
        }
        //先从redis中获取总数且根据page和perPage获取score范围内得值
        PageableResult<Transaction> transactionPageableResult = cacheService.fetchPageableTransactionResult(page, pageSize, redisKey);
        if (transactionPageableResult != null) {
            return transactionPageableResult;
        }

        //通过DB查询
        Account account = fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Transaction> transactions;
        if (PointCategory.BURN == pointCategory) {
            transactions = transactionRepository.fetchBurnByPartitionKeyAndLoyaltyIdAndTransactionTypeOrPointLessThanAndCreatedTimeBetween(
                    partitionKey, account.loyaltyId(), TransactionType.REDEMPTION.name(), 0, LoyaltyDateTimeUtils.localDateTimeToString(start), LoyaltyDateTimeUtils.localDateTimeToString(end));
        } else if (PointCategory.EARN == pointCategory) {
            transactions = transactionRepository.fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween(
                    partitionKey, account.loyaltyId(), TransactionType.REDEMPTION.name(), 0, LoyaltyDateTimeUtils.localDateTimeToString(start), LoyaltyDateTimeUtils.localDateTimeToString(end));
        } else {
            transactions = transactionRepository.fetchByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween(partitionKey, account.loyaltyId(),
                    LoyaltyDateTimeUtils.localDateTimeToString(start), LoyaltyDateTimeUtils.localDateTimeToString(end));
        }
        if (loyaltyStructure.checkMlBrand(BrandV2.PAMPERS)) {
            if (valueType == null || StringUtils.isEmpty(valueType)) {
                transactions = transactions.stream().filter(transaction ->
                        transaction.point() != 0
                ).collect(Collectors.toList());
            } else if (ValueType.TRANSIT.name().equals(valueType)) {
                transactions = transactions.stream().filter(transaction ->
                        (ValueType.TRANSIT.equals(transaction.valueType(loyaltyStructure)))
                                && transaction.point() != 0
                ).collect(Collectors.toList());
            } else {
                transactions = transactions.stream().filter(transaction ->
                        ValueType.DEFAULT.equals(transaction.valueType(loyaltyStructure)) && transaction.point() != 0
                ).collect(Collectors.toList());
            }
        }
        if (loyaltyStructure.checkMlBrand(BrandV2.SKII)) {
            transactions = transactions.stream()
                    .filter(transaction -> !StringUtils.equals(transaction.getPointType(), "MIGRATION_ORDER"))
                    .collect(Collectors.toList());
        }
        setTmallStoreToDescription(loyaltyStructure, transactions);
        //对transaction 进行多语言转换
        translateByLanguage(loyaltyStructure.name(), language, transactions);
        cacheService.setPageableValueToRedis(redisKey, pageSize, transactions, Transaction.comparatorByTransactionCreatedTimeDesc(), 30);
        return cacheService.generatePage(page, pageSize, transactions, Transaction.comparatorByTransactionCreatedTimeDesc());
    }

    /**
     * 对transaction 进行多语言转换
     *
     * @param loyaltyStructure
     * @param language
     * @param transactions
     */
    private void translateByLanguage(String loyaltyStructure, Locale language, List<Transaction> transactions) {
        //没有目标语言原样返回
        if (language == null || CollectionUtils.isEmpty(transactions)) {
            return;
        }

        for (Transaction transaction : transactions) {
            String pointTypeStr = transaction.getPointType();
            //对pointyType翻译
            Optional<PointType> pointTypeOption = cacheService.findByPointTypeAndLoyaltyStructureAndTransactionType(pointTypeStr, loyaltyStructure, transaction.getTransactionType());
            pointTypeOption.ifPresent(pointType -> {
                Optional<PointType.PointTypeDisplayMsg> pointTypeDisplayMsg = pointType.getDisplayLanguages().stream().filter(disLangugae -> language.equals(disLangugae.getLanguage())).findFirst();
                //如果找得到设置覆盖，找不到使用默认的
                pointTypeDisplayMsg.ifPresent(dis -> transaction.setDescription(dis.getDescription()));
            });

            //对pointItem进行翻译
            transaction.getPointItems().forEach(pointItem -> {
                Activity activity = cacheService.findActivityById(pointItem.getActivityId());
                Optional<Activity.ActivityDisplayMsg> activityDisplayMsg = activity.getDisplayLanguages().stream().filter(disLangugae -> language.equals(disLangugae.getLanguage())).findFirst();
                //如果找得到设置覆盖，找不到使用默认的
                activityDisplayMsg.ifPresent(dis -> pointItem.setDescription(dis.getDescription()));
            });
        }
    }

    /**
     * 返回积分历史记录时专门添加StoreCode字段给LA_Tmall
     *
     * @param transactions
     */
    private void setTmallStoreToDescription(LoyaltyStructure loyaltyStructure, List<Transaction> transactions) {
        if (!loyaltyStructure.checkMlBrand(BrandV2.LA)) {
            return;
        }
        for (Transaction transaction : transactions) {
            if (!ChannelV2.TMALL.equals(transaction.channel()) || transaction.getTransactionType() != TransactionType.ORDER) {
                continue;
            }
            Order order = (Order) transaction;
            StringBuilder sb = new StringBuilder("[");
            sb.append(order.getStoreCode());
            sb.append("]");
            sb.append(transaction.getDescription());
            transaction.setDescription(sb.toString());
        }
    }

    public List<Transaction> findPointHistoryWithPointType(String memberId, LoyaltyStructure loyaltyStructure, String pointType) {
        Account account = fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        cacheService.validatePointType(pointType, loyaltyStructure.name());
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        return transactionRepository.findByPartitionKeyAndLoyaltyIdAndPointType(partitionKey, account.loyaltyId(), pointType);
    }

    /**
     * 根据pointType
     */
    public <T extends Transaction> List<T> findPointHistoryWithPointTypeAndTransactionType(
            String memberId, LoyaltyStructure loyaltyStructure, String pointType, TransactionType transactionType,
            LocalDateTime startAt, LocalDateTime endAt) {

        if (Objects.isNull(startAt)) {
            startAt = LocalDateTime.MIN;
        }
        if (Objects.isNull(endAt)) {
            endAt = LocalDateTime.MAX;
        }
        final LocalDateTime endTime = endAt;
        final LocalDateTime startTime = startAt;

        Account account = fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        cacheService.validatePointType(pointType, loyaltyStructure.name(), transactionType);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Transaction> transactions = transactionRepository.findByPartitionKeyAndLoyaltyIdAndPointType(partitionKey, account.loyaltyId(), pointType);
        return transactions.stream().filter(transaction ->
                transaction.getCreatedTime().isBefore(endTime) && transaction.getCreatedTime().isAfter(startTime)
        ).map(transaction -> (T) transaction).collect(Collectors.toList());

    }

    /**
     * 根据member id获取Account
     *
     * @param loyaltyStructure
     * @param memberId
     * @return
     */
    public Account fetchAccountByMemberId(LoyaltyStructure loyaltyStructure, String memberId) {
        String loyaltyId = UUIDUtil.getLoyaltyId(memberId, loyaltyStructure);
        if (loyaltyId == null) {
            //大陆Olay无法获取到Loyalty id，需要去redis中获取
            log.info("从Redis中获取Loyalty Id，Loyalty Structure: {}", loyaltyStructure);
            loyaltyId = cacheService.fetchLoyaltyId(loyaltyStructure.marketingProgramId(), memberId);
        }
        Account account = null;
        long startTime = System.currentTimeMillis();
        if (StringUtils.isEmpty(loyaltyId)) {
            log.warn("缓存中无法获取到Loyalty Id：{}, Loyalty structure: {}", memberId, loyaltyStructure);
            //需要跨分区查询
            account = CollectionUtils.lastElement(accountRepository.findByMemberIdAndMarketingProgramId(memberId,
                    loyaltyStructure.marketingProgramId()));
            if (account != null) {
                //把mapping缓存到redis
                cacheService.cacheMemberIdLoyaltyIdMapping(loyaltyStructure.marketingProgramId(),
                        memberId, account.loyaltyId());
            }
            log.info("findByMemberIdAndMarketingProgramId-costTime: {}ms", System.currentTimeMillis() - startTime);
        } else {
            account = fetchAccountByLoyaltyId(loyaltyId);
            log.info("findByPartitionKeyAndId-costTime: {}ms", System.currentTimeMillis() - startTime);
        }
        return account;
    }

    public Account fetchAccountByLoyaltyId(String loyaltyId) {
        String partitionKey = PartitionKeyUtils.getAccountPartitionKey(loyaltyId);
        List<Account> accounts = accountRepository.findByPartitionKeyAndId(partitionKey, loyaltyId);
        return CollectionUtils.lastElement(accounts);
    }

    /**
     * 获取并检查Account是否为空，如果为空，抛出404错误
     *
     * @param loyaltyStructure
     * @param memberId
     * @return
     */
    public Account fetchAccountByMemberIdAndCheck(LoyaltyStructure loyaltyStructure, String memberId) {
        Account account = fetchAccountByMemberId(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        return account;
    }

    /**
     * 检查Account是否存在，如果不存在抛出404错误
     * 检查SubAccount是否存在，如果不存在，并且是Post，Put场景，自动初始化SubAccount。
     * 有些情况下SubAccount不存在，所以有这样的操作
     *
     * @return
     */
    public Account fetchAndInitialInExistSubAccount(String memberId, LoyaltyStructure loyaltyStructure, String brand, String channel) {
        Account account = fetchAccountByMemberId(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        if (account.newMember4Brand(brand)) {
            //bind id肯定为空，如果bindid不为空，肯定是有子账户的
            account.register(loyaltyStructure, brand, channel, null, LocalDateTime.now());
        }
        return account;
    }

    public PageableResult<Redemption> findRedemptionHistory(String memberId, String brand, String region, LocalDateTime startAt, LocalDateTime endAt, Integer perPage, Integer page, String activityId, String valueType,List<String> redemptionStatuses) {
        //检查account存在
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(structure, memberId);
        String loyaltyId = account.loyaltyId();
        List<Redemption> redemptionList = null;
        if (startAt != null && endAt != null) {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusIn(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId,
                    LoyaltyDateTimeUtils.localDateTimeToString(startAt), LoyaltyDateTimeUtils.localDateTimeToString(endAt),
                    TransactionType.REDEMPTION,redemptionStatuses);

        } else {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndRedemptionStatusIn(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId, TransactionType.REDEMPTION, redemptionStatuses);
        }
        redemptionList = redemptionList.stream().filter(Redemption::visibleIsNot).filter(redemption -> {
            if (!StringUtils.isEmpty(valueType)) {
                return ValueType.valueOf(valueType).equals(redemption.valueType(structure));
            }
            return true;
        }).filter(redemption -> {
            if (!StringUtils.isEmpty(activityId)) {
                return redemption.filterByActivityId(activityId);
            }
            return true;
        }).collect(Collectors.toList());
        return cacheService.generatePage(page, perPage, redemptionList, Redemption.comparatorByRedemptionCreatedTimeDesc());
    }
    public PageableResult<Redemption> findRedemptionHistory(String memberId, String brand, String region, LocalDateTime startAt, LocalDateTime endAt, Integer perPage, Integer page, String activityId, String valueType) {
        //检查account存在
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(structure, memberId);
        String loyaltyId = account.loyaltyId();
        List<Redemption> redemptionList = null;
        if (startAt != null && endAt != null) {
            //Migration状态的数据，不需要展示给前端
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId,
                    LoyaltyDateTimeUtils.localDateTimeToString(startAt), LoyaltyDateTimeUtils.localDateTimeToString(endAt),
                    TransactionType.REDEMPTION);
        } else {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionType(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId, TransactionType.REDEMPTION);
        }
        redemptionList = redemptionList.stream().filter(Redemption::visibleIsNot).filter(redemption -> {
            if (!StringUtils.isEmpty(valueType)) {
                return ValueType.valueOf(valueType).equals(redemption.valueType(structure));
            }
            return true;
        }).filter(redemption -> {
            if (!StringUtils.isEmpty(activityId)) {
                return redemption.filterByActivityId(activityId);
            }
            return true;
        }).collect(Collectors.toList());
        return cacheService.generatePage(page, perPage, redemptionList, Redemption.comparatorByRedemptionCreatedTimeDesc());
    }

    public PageableResult<Redemption> findRedemptionHistoryForC2(String memberId, String brand, String region, LocalDateTime startAt,
                                                                 LocalDateTime endAt, Integer perPage, Integer page, Boolean isHotLine) {
        //检查account存在
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(structure, memberId);
        String loyaltyId = account.loyaltyId();
        List<Redemption> redemptionList = null;
        if (startAt != null && endAt != null) {
            //Migration状态的数据，不需要展示给前端
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId,
                    LoyaltyDateTimeUtils.localDateTimeToString(startAt), LoyaltyDateTimeUtils.localDateTimeToString(endAt),
                    TransactionType.REDEMPTION);
        } else {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionType(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId, TransactionType.REDEMPTION);
        }
        List<Redemption> finalList = new ArrayList<>();
        for (Redemption redemption : redemptionList) {
            if (Boolean.TRUE.equals(isHotLine)) {
                if (Transaction.PointTypeEnum.HOTLINE_REDEMPTION.name().equals(redemption.getPointType())) {
                    finalList.add(redemption);
                }
            } else {
                if (!Transaction.PointTypeEnum.HOTLINE_REDEMPTION.name().equals(redemption.getPointType())) {
                    finalList.add(redemption);
                }
            }
        }
        finalList = finalList.stream().filter(Redemption::visibleIsNot).collect(Collectors.toList());
        return cacheService.generatePage(page, perPage, finalList, Redemption.comparatorByRedemptionCreatedTimeDesc());
    }

    public PageableResult<Order> findOrdersHistory(String memberId, String brand, String region, LocalDateTime startAt, LocalDateTime endAt, Integer perPage, Integer page) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(structure, memberId);
        String loyaltyId = account.loyaltyId();
        List<Order> orderList = null;
        if (startAt != null && endAt != null) {
            orderList = orderRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(
                    PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId,
                    LoyaltyDateTimeUtils.localDateTimeToString(startAt), LoyaltyDateTimeUtils.localDateTimeToString(endAt),
                    TransactionType.ORDER);
            orderList = orderList.stream().filter(Order::visibleIsNot).collect(Collectors.toList());
            return cacheService.generatePage(page, perPage, orderList, Order.comparatorByOrderCreatedTimeDesc());
        }

        orderList = orderRepository.findByPartitionKeyAndLoyaltyIdAndTransactionType(
                PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), loyaltyId, TransactionType.ORDER);
        orderList = orderList.stream().filter(Order::visibleIsNot).collect(Collectors.toList());
        return cacheService.generatePage(page, perPage, orderList, Order.comparatorByOrderCreatedTimeDesc());
    }

    public void updateAccountStatusByMemberId(String memberId, String brand, String region, String status) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberId(structure, memberId);
        if (account == null) {
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        account.updateAccountStatus(structure, status);
        //保存更新状态
        accountRepository.save(account);
    }

    public void updateAccountProfileByMemberId(String memberId, String brand, String region, String babyBirthYearAndMonth) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(structure, memberId);
        if (!StringUtils.isEmpty(babyBirthYearAndMonth)) {
            account.babyBirthYearAndMonth(babyBirthYearAndMonth);
        }
        accountRepository.save(account);
    }

    public int countMemberInteractionTimesByPointType(String memberId, String region, String brand, String pointType) {

        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.of(LocalDate.now(), LocalTime.MIN));
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.of(LocalDate.now(), LocalTime.MAX));
        List<Interaction> interactionList = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(
                partitionKey, pointType, account.loyaltyId(), brand, startAt, endAt);
        return interactionList.size();
    }

    public List<Account> fetchAccountAttr(LoyaltyStructure loyaltyStructure, List<String> memberIdList) {
        return accountRepositoryV2.findAccounts(loyaltyStructure, memberIdList);
    }

    /**
     * 计算策略：锁定积分-不用解锁的积分
     */
    public void unlockPointAndAddPointAvailable(String loyaltyId, String brand, LocalDate unlockTime) {
        Account account = fetchAccountByLoyaltyId(loyaltyId);
        if (account == null) {
            log.warn("id  not found:{}", loyaltyId);
            throw new SystemException("account not fount", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(account);
        //不存在锁定期：脏数据,直接返回
        if (structure.noLockTime()) {
            return;
        }
        SubAccount subAccount = account.subAccount(brand, structure.accountTypeOfDefault());
        LocalDate lastUnlockTime = subAccount.getUnlockTime();
        //解锁的日期不能早于或等于已解锁的日期
        if (null != lastUnlockTime && (!unlockTime.isAfter(lastUnlockTime))) {
            return;
        }
        List<Transaction> transactions = transactionRepositoryV2
                .fetchByUnlockTimeAfter(loyaltyId, unlockTime);

        int pointLocked = transactions.stream().filter(transaction -> transaction.point() > 0)
                .filter(transaction -> transaction.getTransactionType() != TransactionType.REDEMPTION)
                .mapToInt(Transaction::point).sum();

        subAccount.updateUnlockPoint(pointLocked, unlockTime);
        accountRepository.save(account);
    }
}
