package cn.com.pg.loyalty.application.dto;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/12
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class TransactionDto {

    protected String id;
    /**
     * 积分id
     */
    protected String loyaltyId;
    /**
     * 会员系统用户ID：AM，Janrain
     */
    private String memberId;
    /**
     * 通过构造方法或Set方法将Brand转为String,该字段也可用来筛选
     * 指定品牌下的订单
     */
    protected String brand;

    /**
     * PartitionKey
     */
    protected String partitionKey;
    /**
     * Transaction渠道
     */
    protected String channel;
    /**
     * Transaction类型，该字段会配合 brandName进行数据筛选
     */
    protected TransactionType transactionType;

    /**
     * 交易状态
     */
    private Transaction.TransactionStatus transactionStatus;


    /**
     * 与积分描述一一对应
     */
    protected String pointType;

    /**
     * 活动ID, 如果有多个activity，就以point item为准，本字段可以为空。只有Redemption会用到
     */
    protected String activityId;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime createdTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime updatedTime;


}
