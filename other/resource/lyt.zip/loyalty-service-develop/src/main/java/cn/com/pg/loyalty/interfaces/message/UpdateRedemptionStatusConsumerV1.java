package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dependence.UpdateRedemptionStatusMessage;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author: Dong
 * @date: 2019-11-29
 * @description: 更改各个品牌积分兑换状态为支付状态
 **/
@Component
@Slf4j
public class UpdateRedemptionStatusConsumerV1 extends AbstractConsumerV2 {

    @Autowired
    private TransactionService transactionService;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        log.info("开始处理商城支付队列消息");
        UpdateRedemptionStatusMessage updateRedemptionStatusMessage = JSON.toJavaObject(jsonObject, UpdateRedemptionStatusMessage.class);
        transactionService.redemptionPayedStatus(updateRedemptionStatusMessage.getBrand(), updateRedemptionStatusMessage.getMemberId(),updateRedemptionStatusMessage.getTransactionId());
        log.info("任务【商城支付订单更新状态队列】处理完成.........");
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.S_LOGISTICS_REDEMPTION_CONSUMER;
    }

}
