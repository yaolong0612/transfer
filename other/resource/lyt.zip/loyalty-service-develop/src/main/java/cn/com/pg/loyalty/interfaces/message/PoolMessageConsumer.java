package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountService;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.pool.PointPool;
import cn.com.pg.loyalty.domain.pool.PointPoolRepository;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.infrastructure.lock.IdempotentLock;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class PoolMessageConsumer extends AbstractConsumerV2 {
    @Autowired
    private PointPoolRepository pointPoolRepository;
    @Autowired
    private AccountService accountService;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private CacheService cacheService;

    @Override
    protected void doBusiness(JSONObject message) {
        PoolMessage poolMessage = JSON.toJavaObject(message, PoolMessage.class);
        verifyParams(poolMessage);
        calculatePointPool(poolMessage);
    }

    @IdempotentLock(lockKeys = {"'pool'", "#poolMessage.eventId"}, unlessWithEmpty = "#poolMessage.eventId",
           expiredTime = 7, timeUnit = TimeUnit.DAYS)
    public void calculatePointPool(PoolMessage poolMessage) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(poolMessage.getRegion(), poolMessage.getBrand());
        if (!structure.pointExpire(poolMessage.valueType()).useExternalPointPool()) {
            return;
        }
        log.info("维护会员{}的积分池,积分信息:{}", poolMessage.poolId(), poolMessage);
        PointPool pointPool = pointPoolRepository.findById(poolMessage.poolId())
                .orElse(new PointPool(poolMessage.poolId()));
        int point = poolMessage.point();
        boolean orderDelay = structure.pointExpire(poolMessage.valueType()).isOrderDelayExpired();
        if (point < 0) {
            pointPool.deductInPool(Math.abs(point), poolMessage.key(), poolMessage.orderCount(), orderDelay);
        } else {
            pointPool.addInPool(point, poolMessage.key(), poolMessage.orderCount());
        }
        pointPoolRepository.save(pointPool);
        if (poolMessage.isNeedRecalculate()) {
            Account account = accountService.fetchAccountByLoyaltyId(poolMessage.loyaltyId());
            if (account == null) {
                throw new SystemException("NOT FOUND ACCOUNT", ResultCodeMapper.PARAM_ERROR);
            }
            SubAccount subAccount = account.subAccount(poolMessage.brand(), structure.subAccountType(poolMessage.valueType()));
            pointPool.updateAboutExpired(subAccount, orderDelay);
            accountRepository.save(account);
        }
        log.info("会员：{}的积分池维护成功", poolMessage.poolId());
    }

    private void verifyParams(PoolMessage poolMessage) {
        if (poolMessage.poolId() == null) {
            throw new SystemException("the pool id is null.", ResultCodeMapper.PARAM_ERROR);
        }
        if (poolMessage.point() == 0) {
            throw new SystemException("no handle for point 0.", ResultCodeMapper.PARAM_ERROR);
        }
    }


    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_SYNC_POINT_POOL;
    }
}
