package cn.com.pg.loyalty.domain.gift;


import java.util.List;
import java.util.Optional;

public interface GiftCouponRepository {

    GiftCoupon save(GiftCoupon giftCoupon);

    List<GiftCoupon> findUsableCouponLimit(String sku, String region, String brand, int limit);

    List<GiftCoupon> findLastDaysUsedCoupon(String sku, String region, String brand,int lastDays);

    Optional<GiftCoupon> findByCode(String sku, String region, String brand, String couponCode);

    List<GiftCoupon> findByMemberIdAndBrandAndRegion(String memberId, String brand, String region);

    List<GiftCoupon> findMemberCouponByTransactionId(String memberId, String brand, String region, String transactionId);

    GiftCoupon findTopByBagSku(String bagSku,String brand, String region);

    List<GiftCoupon> findByRegionAndBrandAndStoreName(String region, String brand,String storeName);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSku(String region, String brand,String storeName,String bagSku);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndCreatedTimeBetween(String region, String brand, String storeName, String start, String end);

    List<GiftCoupon> findByRegionAndBrandAndStoreNameAndBagSkuAndCreatedTimeBetween(String region, String brand, String storeName,String bagSku, String start, String end);

    List<GiftCoupon> findByRegionAndBrandAndCouponCode(String region, String brand, String couponCode);
}
