package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-08-27 7:49
 */
@Data
public class NewProductChannelSet {

    @NotNull
    @Valid
    private NewProductChannel channelName;
    @NotNull
    private List<String> storeCodes = new ArrayList<>();
    @NotNull
    @Valid
    private List<ProductSet> products = new ArrayList<>();

    /**
     * 只有这3个渠道才会用到这个活动模板,20211222新增VIP
     */
    public enum NewProductChannel {
        /**
         * 线下JD
         */
        JD,
        /**
         * 线下TMALL
         */
        TMALL,
        /**
         * 线下柜台
         */
        COUNTER,

        /**
         * 微信渠道
         */
        WECHAT,
        /**
         * 小程序
         */
        WECHAT_MINI_PROGRAM,

        /**
         * 唯品会
         */
        VIP,
        /**
         * 抖音
         */
        DOUYIN

    }
}
