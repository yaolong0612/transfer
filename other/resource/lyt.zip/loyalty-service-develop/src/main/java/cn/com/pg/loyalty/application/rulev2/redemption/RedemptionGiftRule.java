package cn.com.pg.loyalty.application.rulev2.redemption;


import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.GiftIssuedInventory;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCouponRepository;
import cn.com.pg.loyalty.domain.gift.GiftCouponService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_ACTIVITY;

@Rule(name = "RedemptionGift",
        description = "兑换礼品",priority = Integer.MIN_VALUE)
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.REDEMPTION)
public class RedemptionGiftRule {

    public static final String GIFT_STOCK_TO_REDEEM_GIFT = "Insufficient gift stock to redeem gift";

    @Autowired
    private GiftCouponService giftCouponService;
    @Autowired
    private GiftIssuedInventory giftIssuedInventory;
    @Autowired
    private CacheService cacheService;
    @Autowired
    private GiftCouponRepository giftCouponRepository;
    @Autowired
    private ActivityRepository activityRepository;

    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        return ruleProperties.isReductionInventory();
    }

    @Action
    public void executeRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_ACTIVITY) Activity activity,
                            @Fact(RuleParamNameConfig.LANGUAGE) Locale language,
                            @Fact(RuleParamNameConfig.TRANSACTION_CALCULATE_RESULT) AccountTransactionResult calculateResult) {

        List<Gift> gifts = loadGiftsMeta(redemption);
        GiftCoupon giftCoupon = redemptionCoupon(redemption, account, gifts, language);

        int issuedTag = issuedGift(redemption, activity, 0);
        if (issuedTag != 1 && Objects.nonNull(giftCoupon)) {
            giftCouponService.rollbackCoupon(giftCoupon);
        }
        if (issuedTag == 0) {
            throw new SystemException(GIFT_STOCK_TO_REDEEM_GIFT, ResultCodeMapper.UNDER_STOCK);
        }
        if (issuedTag == -1) {
            throw new SystemException(ResultCodeMapper.UNEXPECTED_ERROR);
        }
        if (Objects.nonNull(giftCoupon)) {
            giftCouponRepository.save(giftCoupon);
            calculateResult.setGiftCoupon(giftCoupon);
        }

    }

    private List<Gift> loadGiftsMeta(Redemption redemption) {
        List<Gift> gifts = new ArrayList<>();
        redemption.getGiftItemList().forEach(giftItem -> {
            Gift gift = cacheService.getGiftById(giftItem.getGiftId());
            if (gift == null) {
                throw new SystemException("The gift has been deleted by mistake. System error", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            gifts.add(gift);
        });
        return gifts;
    }

    private int issuedGift(Redemption redemption, Activity activity, int retryTimes) {
        if (retryTimes > 2) {
            return -1;
        }

        long issued = giftIssuedInventory.issuedGifts(redemption, activity.getGifts());
        if (issued == -1) {
            List<Activity> activityList = activityRepository.findActivityById(activity.activityId());
            if (activityList.isEmpty()) {
                return -1;
            }
            activity = activityList.get(0);
            giftIssuedInventory.checkAndSyncIssuedInventory(redemption, activity);
            issuedGift(redemption, activity, retryTimes + 1);
        }
        return (int) issued;
    }

    private GiftCoupon redemptionCoupon(Redemption redemption, Account account,
                                        List<Gift> gifts, Locale language) {

        List<Gift> couponGifts = gifts.stream().filter(Gift::couponGift).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(couponGifts)) {
            return null;
        }
        if (gifts.size() > 1) {
            throw new SystemException("Coupon redemption limit one gift", ResultCodeMapper.PARAM_ERROR);
        }
        Gift gift = gifts.get(0);
        GiftItem giftItem = redemption.getGiftItemList().stream()
                .filter(item -> StringUtils.equals(gift.getId(), item.getGiftId())).findFirst()
                .orElseThrow(() -> new SystemException(ResultCodeMapper.UNEXPECTED_ERROR));
        if (giftItem.getQuantity() > 1) {
            throw new SystemException("Coupon redemption limit one gift", ResultCodeMapper.PARAM_ERROR);
        }
        GiftCoupon giftCoupon = giftCouponService.allocateCoupon(account, redemption, gift.getBagSku());
        redemption.updateByGiftCoupon(giftCoupon, language);
        return giftCoupon;
    }

}
