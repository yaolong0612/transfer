package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-06 10:39
 */

@Getter
@Setter
public class BirthdayMonthMultipleProperties extends RuleProperties {

    /**
     * 是否参与竞争
     */
    private boolean competition;
    /**
     * 默认赠送积分上限2000
     */
    @Min(0)
    private int maximumBonusPoints;
    /**
     * 赠送积分倍数 1倍
     */
    @Min(0)
    private int bonusPointMultiple;
}
