package cn.com.pg.loyalty.application.dto;

import lombok.*;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/12
 */
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GiftItemDto {
    private String sku;

    private String name;

    private Integer quantity;
}
