package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.CheckMemberGroupTagGateway;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @author lvyanlin
 * @date 2022/6/17 17:30
 */
@Slf4j
@Rule(name = "peopleX客户群成员状态校验",
        description = "peopleX客户群成员状态校验")
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION,
        ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
@Component
public class CheckPeopleXGroupChatStatusRule {

    @Autowired
    private CheckMemberGroupTagGateway gateway;

    @Condition
    public boolean matchRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                             @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                             @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        return redemption.getGiftItemList().stream().anyMatch(giftItem ->
                properties.checkGroupStatus(activity.getGifts(), giftItem));
    }

    @Action
    public void checkPeopleXGroupChatStatus(@Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
                                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption) {
        boolean groupFriend = gateway.isWechatGroupFriend(account.memberId(), redemption.brand());
        if (!groupFriend) {
            throw new SystemException("未入企业微信群,添加加好友", ResultCodeMapper.PEOPLEX_GROUP_MEMBER_STATUS);
        }
    }
}
