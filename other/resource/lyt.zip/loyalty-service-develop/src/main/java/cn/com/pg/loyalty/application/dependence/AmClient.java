package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedEnum;
import cn.com.pg.desenitize.infrastructure.desensitized.annotation.Desensitized;
import com.alibaba.fastjson.JSONObject;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-06 17:49
 */
//  url = "https://qa-zuul-b2c.cn-xnp-cloud-pg.com.cn/api/cms-account-micro-service"
@FeignClient(value = "cms-account-micro-service")
public interface AmClient {

    /**
     * 调用AM queryProfile方法
     * @param requestEntity
     * @return
     */
    @KpiLog(name = "AmClient-queryUserProfile", type= KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    @RequestMapping(value = "/AccountServiceRest/queryProfile", method = RequestMethod.POST)
    CallAmResponse queryProfile(RequestEntity requestEntity);

    @Getter
    @Setter
    @ToString
    @EqualsAndHashCode
    class RequestEntity{
        private String memberId;
        private String tenantId;

        public RequestEntity(String memberId, String tenantId) {
            this.memberId = memberId;
            this.tenantId = tenantId;
        }
    }

    @Getter
    @Setter
    @ToString
    class CallAmResponse {
        private String resultCode;
        private String errorMsg;
        private JSONObject object;
    }

    @Getter
    @Setter
    @ToString
    class ProfileDTO {
        private List<AddressBean> addresses = new ArrayList<>();
        private List<AttrBean> attrs = new ArrayList<>();
        private List<AttrBaby> babyBirthdays = new ArrayList<>();
        private String birthday;
        private String cellphone;
        // 取第一个地址的fullName
        private String fullName;
        private String nickname;
        private CounterBean counter;
    }

    @Getter
    @Setter
    @ToString
    class OptimizedProfileDTO {
        @Desensitized(value = DesensitizedEnum.BIRTHDAY)
        private String birthday;
        @Desensitized(value = DesensitizedEnum.MOBILE_PHONE)
        private String cellphone;
        // 取第一个地址的fullName
        @Desensitized(value = DesensitizedEnum.FULL_NAME)
        private String fullName;
        private List<AttrBaby> babyBirthdays = new ArrayList<>();
    }

    @Getter
    @Setter
    class AttrBean {
        private String attrId;
        private String attrVal;
        private Long id;
    }

    @Setter
    @Getter
    class AttrBaby {
        private String birthday;
        private String createTime;
        private String gender;
        private String seq;
    }

    @Getter
    @Setter
    class CounterBean {
        private String crmPickupCounterCode;
        private String firstPurchaseCounterCode;
        private String firstPurchaseTime;
        private String mainCounterCode;
        private String mainCounterName;
        private String offlineFirstPurchaseCounterCode;
        private String offlineFirstPurchaseCounterName;
        private String pickupCounterCode;
        private String pickupCounterName;
        private String regCounterCode;
        private String regCounterName;
    }

    @Getter
    @Setter
    @ToString
    class AddressBean {
        private String address;
        private String addressCode;
        private Long addressId;
        private String addressType;
        private String cellphone;
        private String city;
        private String district;
        private String fullName;
        private String isPrimary;
        private String phone;
        private String postcode;
        private String province;
    }
}
