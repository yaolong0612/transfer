package cn.com.pg.loyalty.infrastructure.lock;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import org.aspectj.lang.ProceedingJoinPoint;

import java.util.List;

public class MutexLockPointCutAdvice {

    private static final String DELIMITER = ":";
    public static final String LOCK_DIR = "MUTEX_DIR" + DELIMITER;

    /**
     * 增强切点功能：加锁
     */
    public static Object pointAdviceWithLock(ProceedingJoinPoint point, MutexLock lockable, Lock lock,
                                             String[] parameterNames, Object[] arguments) throws Throwable {
        SpELParseUtils spELParseUtils = SpELParseUtils.init(parameterNames, arguments);
        List<String> keys = spELParseUtils.parseKeys(lockable.lockKeys());
        return completeLockAndExec(point, lockable, lock, keys);
    }


    /**
     * 上锁
     */
    private static Object completeLockAndExec(ProceedingJoinPoint point, MutexLock lockable, Lock lock,
                                              List<String> keys) throws Throwable {
        int retryTime = 0;
        String lockKey = LOCK_DIR + String.join(DELIMITER, keys);
        boolean locked = lock.tryLock(lockKey, lockable.expiredTime(), lockable.timeUnit());
        while (!locked) {
            if (retryTime > lockable.maxTryTimes()) {
                throw new SystemException(lockable.errorMessage(), ResultCodeMapper.OPERATION_TOO_FAST);
            }
            retryTime++;
            Thread.sleep(lockable.tryLockSleepMsecs());
            locked = lock.tryLock(lockKey, lockable.expiredTime(), lockable.timeUnit());
        }
        try {
            return point.proceed();
        } catch (Exception e) {
            return handException(lockable, e);
        } finally {
            lock.deleteLock(lockKey,lockable.releaseLockSleepMsecs());
        }
    }

    /**
     * 处理异常：非业务异常，删除锁
     */
    private static Object handException(MutexLock lockable, Exception e) {
        Class<? extends RuntimeException>[] businessExceptions = lockable.businessExceptions();
        for (Class<? extends RuntimeException> businessException : businessExceptions) {
            if (businessException.equals(e.getClass())) {
                throw (RuntimeException) e;
            }
        }
        throw new SystemException(e.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
    }

    private MutexLockPointCutAdvice() {
    }
}
