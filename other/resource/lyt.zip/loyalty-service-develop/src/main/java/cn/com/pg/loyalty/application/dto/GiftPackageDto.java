package cn.com.pg.loyalty.application.dto;

import cn.com.pg.loyalty.domain.transaction.GiftItem;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/12
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GiftPackageDto {
    private String giftId;
    private String giftName;
    private Integer quantity;
    private GiftItem.GiftStatus giftStatus;
    private String imageUri;
    private List<GiftItemDto> giftItem = new ArrayList<>();
}
