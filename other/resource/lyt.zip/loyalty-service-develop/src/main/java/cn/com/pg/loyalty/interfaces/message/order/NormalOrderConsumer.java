package cn.com.pg.loyalty.interfaces.message.order;

import cn.com.pg.loyalty.application.OrderAppService;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.message.AbstractConsumerV2;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @description: 除了SKII、OLAY
 * @author: Artermus wang on 2021-11-24 16:56
 */
@Component
@Slf4j
public class NormalOrderConsumer extends AbstractConsumerV2 {

    @Autowired
    private OrderAppService orderAppService;

    @Override
    protected void doBusiness(JSONObject message) {
        RequestOrdersMessage orderMessage = JSON.toJavaObject(message, RequestOrdersMessage.class);
        orderAppService.calculateOrders(orderMessage);
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_NORMAL_ORDER;
    }
}
