package cn.com.pg.loyalty.domain.activity.prop;


import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @author LC
 */
@Getter
@Setter
public class PurchaseManyTimesPerPeriodProperties extends RuleProperties{
    /**
     * 积分数
     */
    @Min(0)
    @NotNull
    private Integer point;

    /**
     * 购买次数
     */
    @Min(0)
    @NotNull
    private Integer purchaseTimes;

    /**
     * 指定多次购买时间段(month)
     */
    @Min(0)
    @NotNull
    private Integer period;

    /**
     * 是否需要区分订单渠道，需要：填写相应的channel 不需要：留空
     */
    List<String> channels = new ArrayList<>();

    /**
     * 是否与其他加积分竞争：多个活动取值最高分
     * false: 不参与 直接作为相加中一项
     * true: 参与竞争
     */
    @NotNull
    private Boolean competition;
}
