package cn.com.pg.loyalty.domain.gift;

import cn.com.pg.loyalty.domain.shared.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Document(collection = "GiftCoupon", ru = "400")
@Getter
@Setter
@NoArgsConstructor
public class GiftCoupon {
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.GIFT_PARTITIONKEY;
    private String bagSku;
    private String giftName;
    private String couponCode;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate startAt;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate endAt;

    private String storeName;

    private CouponStatus status;
    //使用者
    private String memberId;
    //面额说明
    private String price;

    private String region;

    private String brand;

    private String transactionId;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    public enum CouponStatus {
        ALIVE,
        EXPIRED,
        USED
    }

    /**
     * 多语言支持
     */
    private List<GiftCouponDisplayMsg> displayLanguages = new ArrayList<>();

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class GiftCouponDisplayMsg {
        private Locale language;
        private String storeName;
    }

    public void addGiftCouponDisplayMsg(List<GiftCouponDisplayMsg> displayMsgList) {
        if (!CollectionUtils.isEmpty(displayMsgList)) {
            Map<Locale, GiftCouponDisplayMsg> couponDisplayMsgMap = displayMsgList.stream().collect(Collectors.toMap(GiftCouponDisplayMsg::getLanguage, self -> self));
            //原先存在相同的多语言，先去除,避免覆盖原有数据
            this.displayLanguages.forEach(languageMsg -> couponDisplayMsgMap.remove(languageMsg.getLanguage()));
            //添加多语言
            this.displayLanguages.addAll(couponDisplayMsgMap.values());
        }
    }

    public void translateByLanguage(Locale language) {
        //没有目标语言原样返回
        if (language == null) {
            return;
        }
        //翻译storeName
        Optional<GiftCoupon.GiftCouponDisplayMsg> couponDisplayMsg = this.getDisplayLanguages().stream().filter(giftCouponDisplayMsg -> language.equals(giftCouponDisplayMsg.getLanguage())).findFirst();
        couponDisplayMsg.ifPresent(displayMsg -> this.setStoreName(displayMsg.getStoreName()));
    }


    public void usedBy(String memberId, String transactionId) {
        if (canNotBeUsed()) {
            throw new SystemException("The coupon code can not be used", ResultCodeMapper.PARAM_ERROR);
        }
        this.memberId = memberId;
        this.status = CouponStatus.USED;
        this.transactionId = transactionId;
        this.updatedTime = LocalDateTime.now();
    }

    public void expired() {
        this.status = CouponStatus.EXPIRED;
        this.updatedTime = LocalDateTime.now();
    }

    public boolean canNotBeUsed() {
        LocalDate now = LocalDate.now();
        return CouponStatus.ALIVE != status || startAt.isAfter(now)
                || endAt.isBefore(now);
    }

    public boolean beUsed() {
        return CouponStatus.USED == status;
    }

    public void updateValidityDate(LocalDate startAt, LocalDate endAt) {
        this.startAt = startAt;
        this.endAt = endAt;
        this.updatedTime = LocalDateTime.now();
    }

    public static class Builder {
        private String sku;
        private String giftName;
        private String couponCode;
        private LocalDate startAt;
        private LocalDate endAt;
        private String storeName;
        private GiftCoupon.CouponStatus status;
        private String price;
        private String region;
        private String brand;

        public Builder(String sku, String giftName, String couponCode,
                       String storeName, String price) {
            this.sku = sku;
            this.giftName = giftName;
            this.couponCode = couponCode;
            this.storeName = storeName;
            this.price = price;
        }

        public Builder validityDate(LocalDate startAt, LocalDate endAt) {
            if (endAt.isBefore(startAt)) {
                throw new SystemException("end date can not before start date", ResultCodeMapper.PARAM_ERROR);
            }
            this.startAt = startAt;
            this.endAt = endAt;
            return this;
        }

        public Builder status(CouponStatus status) {
            this.status = status;
            return this;
        }

        public Builder belong(String region, String brand) {
            this.region = region;
            this.brand = brand;
            return this;
        }


        public GiftCoupon build() {
            GiftCoupon giftCoupon = new GiftCoupon();
            giftCoupon.id = UUIDUtil.generator();
            giftCoupon.bagSku = sku;
            giftCoupon.giftName = giftName;
            giftCoupon.couponCode = couponCode;
            giftCoupon.startAt = startAt;
            giftCoupon.endAt = endAt;
            giftCoupon.storeName = storeName;
            giftCoupon.status = status;
            giftCoupon.price = price;
            giftCoupon.region = region;
            giftCoupon.brand = brand;
            giftCoupon.createdTime = LocalDateTime.now();
            giftCoupon.createdTime = LocalDateTime.now();
            return giftCoupon;
        }

    }

}
