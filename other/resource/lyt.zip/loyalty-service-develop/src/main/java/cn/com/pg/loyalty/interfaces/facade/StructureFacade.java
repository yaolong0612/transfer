package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.StructureService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.*;
import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics.ExtraTactics;
import cn.com.pg.loyalty.domain.structure.PointExpire.PointExpiredWay;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries.CalculateWay;
import cn.com.pg.loyalty.interfaces.api.StructuresApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.LoyaltyStructureAssembler;
import cn.com.pg.loyalty.interfaces.dto.AddStructureCommand;
import cn.com.pg.loyalty.interfaces.dto.FetchStructureListDto;
import cn.com.pg.loyalty.interfaces.dto.StructureDto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component("StructureFacade")
public class StructureFacade implements StructuresApiDelegate {

    @Autowired
    private StructureService structureService;

    @Override
    public ResponseEntity<StructureDto> addLoyaltyStructure(String authorization, AddStructureCommand body) {
        String userName = JwtUtils.getUsernameFromToken(authorization);
        List<TierLevel> tierLevels = body.getTierLevels().stream().map(LoyaltyStructureAssembler::toTierLevelV2)
                .collect(Collectors.toList());

        TierLevelSeries tierLevelSeries = new TierLevelSeries(
                TierLevelSeries.TierChangeType.valueOf(body.getTierChangeType()),
                TierLevelSeries.TierExpiredWay.valueOf(body.getTierExpiredWay()),
                body.getPointEffectiveYear(), tierLevels, CalculateWay.valueOf(body.getCalculateWay()),
                body.getPointEffectiveYear());

        List<String> brands = body.getBrands();
        ExtraSubAccountTactics extraSubAccountTactics = null;
        if (body.isOpenExtraSubAccount()) {
            extraSubAccountTactics = new ExtraSubAccountTactics(
                    new PointExpire(PointExpiredWay.valueOf(body.getExtraPointExpiredWay()),
                            body.getExtraPointEffectiveYear(), body.isExtraUsePointPool(), body.isExtraOrderDelayExpired(), PointExpire.ExpiredDateCalculateWay.valueOf(body.getPointExpiredDateCalculateWay())),
                    ExtraTactics.valueOf(body.getExtraTactics().toString()));
        }

        LoyaltyStructure loyaltyStructure = new LoyaltyStructure
                .Builder(body.getName(), body.getRegion(),
                brands, body.getMarketingProgramId(), body.getAmTenantId())
                .amountRate(new ExchangeRate(body.getAmountRate()))
                .pointExpire(new PointExpire(PointExpire.PointExpiredWay.valueOf(body.getPointExpiredWay()),
                        body.getPointEffectiveYear(), body.isUsePointPool(), body.isOrderDelayExpired(), PointExpire.ExpiredDateCalculateWay.valueOf(body.getPointExpiredDateCalculateWay())))
                .createdBy(userName)
                .extraTactics(body.isOpenExtraSubAccount(), extraSubAccountTactics)
                .tierLevelSeries(tierLevelSeries)
                .orderImpact(new OrderImpact(body.isRefundOrderBackRoll(),
                        body.isInsertOrderBackRoll(), body.isAlertOrderBackRoll()))
                .build();

        structureService.addLoyaltyStructure(loyaltyStructure);
        StructureDto structureDto = LoyaltyStructureAssembler.toStructureDto(body);
        return ResponseEntity.ok(structureDto);
    }

    @Override
    public ResponseEntity<StructureDto> findLoyaltyStructureById(String authorization, String name) {
        JwtUtils.getUsernameFromToken(authorization);
        ParamValidator.validName(name);
        LoyaltyStructure loyaltyStructure = structureService.findLoyaltyStructureById(name);
        if (loyaltyStructure == null) {
            throw new SystemException("loyalty structure not found", ResultCodeMapper.STRUCTURE_NOT_FOUND);
        }
        StructureDto structureDto = LoyaltyStructureAssembler.toStructureDto(loyaltyStructure);
        return ResponseEntity.ok(structureDto);
    }

    @Override
    public ResponseEntity<FetchStructureListDto> findLoyaltyStructures(String authorization, String name) {
        JwtUtils.getUsernameFromToken(authorization);
        List<LoyaltyStructure> structures = new ArrayList<>();
        if (!StringUtils.isEmpty(name)) {
            LoyaltyStructure structure = structureService.findLoyaltyStructureById(name);
            if (structure != null) {
                structures.add(structure);
            }

        } else {
            structures = structureService.findLoyaltyStructures();
        }
        FetchStructureListDto structureDto = LoyaltyStructureAssembler.toStructureListDto(structures);
        return ResponseEntity.ok(structureDto);
    }
}
