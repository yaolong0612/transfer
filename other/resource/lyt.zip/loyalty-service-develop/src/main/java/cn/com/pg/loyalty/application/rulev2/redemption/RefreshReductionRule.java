package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.jeasy.rules.api.Facts;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 按月刷新兑换数量限制规则
 *
 * @author vincenzo
 * @description
 * @date 2022/9/13
 */
@Rule(name = "RefreshReductionRule",
        description = "按月刷新兑换数量限制规则", priority = Integer.MIN_VALUE)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
public class RefreshReductionRule {


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        return ruleProperties.isRefreshReduction();
    }

    @Action
    public void executeRule(Facts facts) {
        List<Redemption> redemptionRecords = facts.get(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS);
        facts.put(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS, fetchCurrentMonthRedemptions(redemptionRecords));
    }

    /**
     * 获取当月的兑换记录排除历史兑换记录，传给其他rule使用-以达到目的：
     * 刷新上个月的兑换数量限制，相当于第二月新建了一个相同信息的活动让消费者重新兑换
     *
     * @param redemptionRecords
     * @return
     */
    List<Redemption> fetchCurrentMonthRedemptions(List<Redemption> redemptionRecords) {
        //有限制时间则根据计算出的开始结束时间进行过滤
        LocalDateTime current = LocalDateTime.now();
        LocalDateTime start = LoyaltyDateTimeUtils.getFirstDayOfThisMonth(current);
        //时间范围  当月1号 <= time
        return redemptionRecords.stream()
                .filter(redemp -> redemp.getCreatedTime().isAfter(start) || redemp.getCreatedTime().isEqual(start))
                .collect(Collectors.toList());


    }

}
