package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.OrderAppService;
import cn.com.pg.loyalty.application.dependence.OrderMessage;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;

/**
 * @description: SKII正单/改单/退单均使同一个队列，配置按先进先出原则
 * @author: Jevons Chen
 * @date: 2020-08-18 16:54
 */

@Component
@Slf4j
public class SkiiOrderConsumer extends AbstractConsumerV2 {

    @Autowired
    private OrderAppService orderAppService;

    @Override
    protected void doBusiness(JSONObject message) {
        log.info("skill order receive msg: {}", message);
        RequestOrdersMessage orderMessage = JSON.toJavaObject(message, RequestOrdersMessage.class);
        orderAppService.calculateOrders(orderMessage);
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_SKII_ORDER_QUEUE_NAME;
    }

    private void paramValidator(OrderMessage orderMessage, List<Order> orders) {
        orders.forEach(order -> {
            ParamValidator.stringParam("orderId", order.getOrderId());
            ParamValidator.stringParam("realTotalAmount", Optional.ofNullable(order.getRealTotalAmount()).map(String::valueOf).orElse(null));
            ParamValidator.notLessThan("realTotalAmount", order.realTotalAmount(), 0);
            ParamValidator.stringParam("orderDateTime", Optional.ofNullable(order.getOrderDateTime()).map(LoyaltyDateTimeUtils::localDateTimeToString).orElse(null));
            ParamValidator.stringParam("orderUpdateTime", Optional.ofNullable(order.getOrderUpdateTime()).map(LoyaltyDateTimeUtils::localDateTimeToString).orElse(null));
            ParamValidator.stringParam("orderItems", CollectionUtils.isEmpty(order.getOrderItems()) ? null : JSON.toJSONString(order.getOrderItems()));
            order.getOrderItems().forEach(orderItem -> ParamValidator.stringParam("sku", orderItem.getSku()));
        });
    }
}
