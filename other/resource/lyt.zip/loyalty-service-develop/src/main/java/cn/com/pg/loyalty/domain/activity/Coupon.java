package cn.com.pg.loyalty.domain.activity;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Coupon {
    private String code;
    private LocalDateTime startAt;
    private LocalDateTime endAt;


}
