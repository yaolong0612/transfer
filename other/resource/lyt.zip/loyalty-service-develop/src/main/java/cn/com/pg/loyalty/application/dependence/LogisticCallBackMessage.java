package cn.com.pg.loyalty.application.dependence;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author cooltea on 2019/9/16 18:05.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Getter
@Setter
public class LogisticCallBackMessage implements Serializable {
    private String reason;
    private String logisticsId;
    private String deliverCompany;
    private String brand;
    private String deliveryNumber;
    private String transactionId;
    private String memberId;
    private StatusEnum status;

    public enum StatusEnum {
        SHIPPED,
        REJECTED
    }
}
