package cn.com.pg.loyalty.domain.shared;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Simon
 * @date 2019/5/4 18:40
 * @description
 **/
@Getter
public class RuleResult {
    private List<SystemException> systemExceptions;
    private boolean success;
    private boolean endTag;

    public RuleResult(){
        systemExceptions = new ArrayList<>();
    }

    public void addException(SystemException exception) {
        systemExceptions.add(exception);
    }

    public void success(){
        this.success = true;
    }

    public void end(){
        this.endTag = true;
    }
}
