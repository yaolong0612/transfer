package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class ExchangeRate {
    private double rate = 1.0;

    public ExchangeRate(double rate) {
        if (rate <= 0) {
            throw new SystemException("rate must gt 0", ResultCodeMapper.PARAM_ERROR);
        }
        this.rate = rate;
    }

    public double exchange2BaseAmount(double amount) {
        return amount * rate;
    }

}
