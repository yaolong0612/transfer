package cn.com.pg.loyalty.infrastructure.rest;

import cn.com.pg.loyalty.domain.shared.AccountDetailGateway;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.rest.GlobalAmClient.AmDetailsResponse;
import cn.com.pg.loyalty.infrastructure.rest.GlobalAmClient.AmToken;
import cn.com.pg.loyalty.infrastructure.rest.GlobalAmClient.TokenRequestEntity;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class GlobalAccountDetailGatewayImpl implements AccountDetailGateway {

    public static final String CALL_AM_DETAILS_ERROR = "Call am details error";
    @Autowired
    private GlobalAmClient globalAmClient;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Value(value = "${am.username}")
    private String userName;
    @Value(value = "${am.password}")
    private String password;
    @Value(value = "${am.subscription-key}")
    private String subKey;

    private static final String TOKEN_KEY = "GLOBAL:AM:TOKEN";
    private static final int MAX_RETRY_TIMES = 1;

    @Override
    public String birthday(String memberId) {
        return fetchBirthday(memberId, 0);
    }


    private String fetchBirthday(String memberId, int hasRetriedTimes) {
        String token = fetchTokenWithCache();
        try {
            AmDetailsResponse response = globalAmClient.fetchAmDetail(memberId, subKey, token);
            if (response.getProfile() == null) {
                throw new SystemException("Call am details data error", ResultCodeMapper.CALL_AM_ERROR);
            }
            return response.getProfile().getBirthday();
        } catch (FeignException e) {
            log.warn(CALL_AM_DETAILS_ERROR, e);
            if (e.status() == 401) {
                stringRedisTemplate.delete(TOKEN_KEY);
                if (hasRetriedTimes < MAX_RETRY_TIMES) {
                    hasRetriedTimes += 1;
                    return fetchBirthday(memberId, hasRetriedTimes);
                }
            }
            if (e.status() == 400) {
                return null;
            }
            throw new SystemException(CALL_AM_DETAILS_ERROR, ResultCodeMapper.CALL_AM_ERROR);
        } catch (Exception ignored) {
            log.warn(CALL_AM_DETAILS_ERROR, ignored);
            throw new SystemException(CALL_AM_DETAILS_ERROR, ResultCodeMapper.CALL_AM_ERROR);
        }
    }

    private String fetchTokenWithCache() {
        String token = stringRedisTemplate.opsForValue().get(TOKEN_KEY);
        if (token != null) {
            return token;
        }
        try {
            TokenRequestEntity entity = new TokenRequestEntity(userName, password, true);
            AmToken amToken = globalAmClient.generateToken(entity, subKey);
            token = amToken.generateToken();
            stringRedisTemplate.opsForValue().set(TOKEN_KEY, token, 6, TimeUnit.HOURS);
            return token;
        } catch (Exception e) {
            log.warn("call token error", e);
            throw new SystemException("Call token error", ResultCodeMapper.CALL_AM_ERROR);
        }
    }


}
