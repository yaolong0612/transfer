package cn.com.pg.loyalty.infrastructure.lock;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class SpELParseUtils {


    private final ExpressionParser parser = new SpelExpressionParser();
    private final EvaluationContext context = new StandardEvaluationContext();

    private SpELParseUtils(@NonNull String[] parameterNames, @NonNull Object[] arguments) {
        Assert.isTrue(arguments.length == parameterNames.length, "参数key 与值长度不等");
        for (int i = 0; i < parameterNames.length; i++) {
            context.setVariable(parameterNames[i], arguments[i]);
        }
    }

    public static SpELParseUtils init(@NonNull String[] parameterNames, @NonNull Object[] arguments) {
        return new SpELParseUtils(parameterNames, arguments);
    }

    public List<String> parseKeys(@NonNull String[] lockKeys) {
        List<String> keys = new ArrayList<>();
        for (String lockKey : lockKeys) {
            keys.add(this.parseKey(lockKey));
        }
        return keys;
    }

    public String parseKey(@NonNull String key) {
        Expression expression = parser.parseExpression(key);
        return  expression.getValue(context, String.class);
    }

}
