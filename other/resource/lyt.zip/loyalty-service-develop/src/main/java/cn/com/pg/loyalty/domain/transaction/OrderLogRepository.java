package cn.com.pg.loyalty.domain.transaction;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-25 11:26
 */

@Repository
public interface OrderLogRepository extends DocumentDbRepository<OrderLog, String> {
}
