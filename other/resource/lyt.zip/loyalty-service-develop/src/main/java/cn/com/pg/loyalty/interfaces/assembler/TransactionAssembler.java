package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.interfaces.dto.*;
import cn.com.pg.loyalty.interfaces.dto.PointRecordDTO.TransactionCategoryEnum;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * @author Ladd
 */

public class TransactionAssembler {


    public static TransactionDTO toTransactionDTO(AccountTransactionResult accountTransactionResult,
                                                  LoyaltyStructure loyaltyStructure, String brand) {
        Tier tier = accountTransactionResult.getAccount().tier(loyaltyStructure.name());
        return new TransactionDTO().pointAvailable(accountTransactionResult.getAccount()
                .availablePoint(loyaltyStructure.accountTypeOfDefault()))
                .tier(loyaltyStructure.tierLevelSeries().getLevelByName(tier.getLevel()).getLevelAlias())
                .transitPoint(accountTransactionResult.getAccount().availablePoint(loyaltyStructure.subAccountType(ValueType.TRANSIT)))
                .pointIssued(accountTransactionResult.getTransaction().getPoint())
                .transactionId(accountTransactionResult.getTransaction().getId())
                .transactionPointExpiredDate(accountTransactionResult.getTransaction()
                        .getExpiredTime().toLocalDate().toString())
                .lockPoint(accountTransactionResult.getAccount().pointLocked(loyaltyStructure.subAccountType(ValueType.DEFAULT)))
                .loyaltyId(accountTransactionResult.getTransaction().getLoyaltyId())
                .pointItem(accountTransactionResult.getTransaction().getPointItems().
                        stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()));
    }

    public static PointItemDTO toPointItemDTO(PointItem pointItem) {
        PointItemDTO pointItemDTO = new PointItemDTO();
        pointItemDTO.activityId(pointItem.getActivityId())
                .point(pointItem.getPoint())
                .description(pointItem.getDescription());
        return pointItemDTO;
    }

    public static TransactionDetailDTO toTransactionDetailDTO(Transaction transaction) {
        if (transaction instanceof Interaction) {
            return new TransactionDetailDTO().transactionId(transaction.getId()).
                    point(transaction.getPoint())
                    .createdDate(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(transaction.getCreatedTime()))
                    .createBy(((Interaction) transaction).getCreateBy())
                    .adjustReason(((Interaction) transaction).getAdjustReason());
        } else {
            return new TransactionDetailDTO().transactionId(transaction.getId()).
                    point(transaction.getPoint());
        }
    }

    public static PointHistoryWithPointCategoryDTO toPointHistoryWithPointCategoryDTO(PageableResult<Transaction> pageableResult, LoyaltyStructure loyaltyStructure, List<Store> storeList) {
        PointHistoryWithPointCategoryDTO pointHistoryDTO = new PointHistoryWithPointCategoryDTO();
        List<Transaction> transactionList = pageableResult.getRecords();
        int totalSize = pageableResult.getTotalSize();
        pointHistoryDTO.setTotalSize(totalSize);
        Map<String, String> storeMap = fetchMapMapFromStore(storeList);
        if (totalSize > 0) {
            List<PointRecordWithPointCategoryDTO> pointRecordDTOList = transactionList.stream().map(transaction -> toPointRecordWithPointCategoryDTO(transaction, loyaltyStructure, storeMap)).collect(Collectors.toList());
            pointHistoryDTO.setRecords(pointRecordDTOList);
        }
        return pointHistoryDTO;
    }

    private static Map<String, String> fetchMapMapFromStore(List<Store> storeList) {
        return storeList.stream().filter(distinctByKey(Store::getId)).collect(Collectors.toMap(Store::getId, Store::getStoreName));
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    public static List<String> analyseStoreCodeFromOrder(List<Transaction> transactionList) {
        List<String> storeCodeList = transactionList.stream()
                .filter(item -> item.getTransactionType() == TransactionType.ORDER && ((Order) item).getStoreCode() != null).map(item -> ((Order) item).getStoreCode()).collect(Collectors.toList());
        return storeCodeList;
    }

    public static PointHistoryDTO listToPointHistoryDTO(List<Transaction> list) {
        PointHistoryDTO pointHistoryDTO = new PointHistoryDTO();
        if (!CollectionUtils.isEmpty(list)) {
            List<PointRecordDTO> pointRecordDTOList = list.stream().map(TransactionAssembler::toPointRecordDTO).collect(Collectors.toList());
            pointHistoryDTO.setRecords(pointRecordDTOList);
            pointHistoryDTO.setTotalSize(pointRecordDTOList.size());
        } else {
            pointHistoryDTO.setTotalSize(0);
        }
        return pointHistoryDTO;
    }

    public static RedemptionAggregationRecordDto listToRedemptionAggregationDTO(List<Redemption> list,
                                                                                List<Activity> activities) {
        RedemptionAggregationRecordDto pointHistoryAggregationRecordDto = new RedemptionAggregationRecordDto();
        Map<String, List<Redemption>> listMap = list.stream().collect(Collectors.groupingBy(Transaction::getActivityId));
        Map<String, Activity> activityMap = activities.parallelStream().collect(Collectors.toMap(Activity::activityId, activity -> activity));
        listMap.forEach((id, rs) -> {
            RedemptionAggregationDTO redemptionAggregationDTO = new RedemptionAggregationDTO();
            Activity activity = activityMap.get(id);
            if (!Objects.isNull(activity)) {
                redemptionAggregationDTO.setActivityId(id);
                int totalPoint = rs.parallelStream().mapToInt(Redemption::getPoint).sum();
                int times = rs.parallelStream().map(Redemption::getGiftItemList).mapToInt(items ->
                        items.parallelStream().mapToInt(GiftItem::getQuantity).sum()
                ).reduce(Integer::sum).orElse(0);
                redemptionAggregationDTO.setPoint(totalPoint);
                redemptionAggregationDTO.setTimes(times);
                redemptionAggregationDTO.setActivityName(activity.getActivityName());
                redemptionAggregationDTO.setDescription(activity.description());
                pointHistoryAggregationRecordDto.addRecordsItem(redemptionAggregationDTO);
            }
        });
        return pointHistoryAggregationRecordDto;
    }


    public static PointRecordDTO toPointRecordDTO(Transaction transaction) {
        PointRecordDTO pointRecordDTO = new PointRecordDTO();
        pointRecordDTO.loyaltyId(transaction.getLoyaltyId())
                .channel(transaction.getChannel())
                .description(Transaction.PointTypeEnum.ORDER_POINT_MIGRATION.name().equals(transaction.getPointType()) ? Transaction.PointTypeEnum.ORDER_POINT_MIGRATION.remark() : transaction.getDescription())
                .point(transaction.getPoint())
                .pointType(transaction.getPointType())
                .transactionCategory(TransactionCategoryEnum.valueOf(transaction.getTransactionType().name()))
                .transactionDateTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(transaction.getCreatedTime()))
                .transactionId(transaction.getId())
                .transactionStatus(PointRecordDTO.TransactionStatusEnum.fromValue(transaction.getTransactionStatus().name()))
                .pointItems(transaction.getPointItems().stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()));

        if (transaction instanceof Order) {
            Order order = (Order) transaction;
            pointRecordDTO.setOrderStoreCode(order.getStoreCode());
        }

        if (transaction instanceof Redemption) {
            Redemption redemption = (Redemption) transaction;
            pointRecordDTO.setPickupStoreCode(redemption.getStoreCode());
            pointRecordDTO.setRedeemCode(redemption.getRedeemCode());
        }
        if (transaction instanceof Interaction) {
            Interaction interaction = (Interaction) transaction;
            pointRecordDTO.setAdjustReason(interaction.getAdjustReason());
            pointRecordDTO.setCreateBy(interaction.getCreateBy());
            //增加一个人工调整积分的审计图片链接
            pointRecordDTO.setImageUriList(interaction.getImageUriList());
        }
        return pointRecordDTO;
    }

    public static PointRecordWithPointCategoryDTO toPointRecordWithPointCategoryDTO(Transaction transaction, LoyaltyStructure loyaltyStructure, Map<String, String> storeMap) {
        PointRecordWithPointCategoryDTO pointRecordDTO = new PointRecordWithPointCategoryDTO();
        pointRecordDTO.valueType(PointRecordWithPointCategoryDTO.ValueTypeEnum.fromValue(transaction.valueType(loyaltyStructure).name()));
        pointRecordDTO.loyaltyId(transaction.getLoyaltyId())
                .channel(transaction.getChannel())
                .description(transaction.getDescription())
                .description(Transaction.PointTypeEnum.ORDER_POINT_MIGRATION.name().equals(transaction.getPointType()) ? Transaction.PointTypeEnum.ORDER_POINT_MIGRATION.remark() : transaction.getDescription())
                .point(transaction.getPoint())
                .pointType(transaction.getPointType())
                .transactionCategory(PointRecordWithPointCategoryDTO.TransactionCategoryEnum.fromValue(transaction.getTransactionType().name()))
                .transactionDateTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(transaction.getCreatedTime()))
                .transactionId(transaction.getId())
                .transactionStatus(PointRecordWithPointCategoryDTO.TransactionStatusEnum.fromValue(transaction.getTransactionStatus().name()))
                .pointItems(Optional.ofNullable(transaction.getPointItems()).orElse(new ArrayList<>())
                        .stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()))
                .valueType(PointRecordWithPointCategoryDTO.ValueTypeEnum.fromValue(transaction.valueType(loyaltyStructure).name()));
        TransactionType transactionType = transaction.getTransactionType();
        if (transactionType == TransactionType.ORDER) {
            Order order = (Order) transaction;
            pointRecordDTO.setOrderStoreCode(order.getStoreCode());
            pointRecordDTO.setPointCategory(PointRecordWithPointCategoryDTO.PointCategoryEnum.EARN);
            pointRecordDTO.setStoreName(storeMap.get(order.getStoreCode()));
        }
        if (transactionType == TransactionType.REDEMPTION) {
            Redemption redemption = (Redemption) transaction;
            pointRecordDTO.setPickupStoreCode(redemption.getStoreCode());
            if (redemption.returnRedeemCode()) {
                pointRecordDTO.setRedeemCode(redemption.getRedeemCode());
            }
            pointRecordDTO.setPointCategory(PointRecordWithPointCategoryDTO.PointCategoryEnum.BURN);
        }
        if (transactionType == TransactionType.INTERACTION) {
            Interaction interaction = (Interaction) transaction;
            pointRecordDTO.setAdjustReason(interaction.getAdjustReason());
            pointRecordDTO.setCreateBy(interaction.getCreateBy());
            if (transaction.getPoint() >= 0) {
                pointRecordDTO.setPointCategory(PointRecordWithPointCategoryDTO.PointCategoryEnum.EARN);
            } else {
                pointRecordDTO.setPointCategory(PointRecordWithPointCategoryDTO.PointCategoryEnum.BURN);
            }
        }

        //设置积分过期日期(只有交互和订单类型需要)
        if (transaction.getExpiredTime()!=null && (transactionType == TransactionType.INTERACTION || transactionType == TransactionType.ORDER)) {
            pointRecordDTO.setExpireDate(LoyaltyDateTimeUtils.localDateToDataString(transaction.getExpiredTime().toLocalDate()));
        }
        return pointRecordDTO;
    }

    public static Redemption toRedemption(CreateRedemptionCommand body) {
        String brand = body.getBrand();
        String channel = body.getChannel();
        Redemption redemption = new Redemption(brand, channel, body.getReceiver(),
                body.getPhone(), body.getProvince(),
                body.getCity(), body.getDistrict(), body.getAddress(), body.getReceivingStoreCode(),
                body.getPostalCode(), body.getMemberId(), body.getFreight(), body.getPickUpDate(),
                body.getExternalBusinessId(), ValueType.valueOf(body.getValueType().name()));
        redemption.setRedeemCode(body.getRedeemCode());
        redemption.email(body.getEmail());
        return redemption;
    }

    public static CreateRedemptionDTO toCreateRedemptionDTO(LoyaltyStructure structure, AccountTransactionResult accountTransactionResult, String brand) {
        Account account = accountTransactionResult.getAccount();
        SubAccount subAccount = account.subAccount(brand, structure.subAccountType(accountTransactionResult.getTransaction()));
        GiftCoupon giftCoupon = accountTransactionResult.getGiftCoupon();
        CreateRedemptionDTO createRedemptionDTO = new CreateRedemptionDTO();
        createRedemptionDTO.setPointCost(accountTransactionResult.getTransaction().getPoint());
        createRedemptionDTO.setTransactionId(accountTransactionResult.getTransaction().getId());
        createRedemptionDTO.setPointAvailable(subAccount.getPointAvailable());
        createRedemptionDTO.setExpiredTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(accountTransactionResult.getTransaction().getExpiredTime()));
        createRedemptionDTO.setRedeemCode(((Redemption) accountTransactionResult.getTransaction()).getRedeemCode());
        if (giftCoupon != null) {
            createRedemptionDTO.couponStartAt(giftCoupon.getStartAt().toString());
            createRedemptionDTO.couponEndAt(giftCoupon.getEndAt().toString());
        }
        createRedemptionDTO.setStoreName(((Redemption) accountTransactionResult.getTransaction()).getStoreName());
        return createRedemptionDTO;
    }

    /**
     * PageableResult<Redemption>转为成FetchRedemptionDTO
     *
     * @param pageableResult
     * @return
     */
    public static FetchRedemptionListDTO toFetchRedemptionListDTO(LoyaltyStructure structure, PageableResult<Redemption> pageableResult,
                                                                  Map<String, Store> storeMap, Map<String, Boolean> giftCancelableList,
                                                                  Map<String, Account> accountMap, Map<String, Gift> giftMap) {
        FetchRedemptionListDTO fetchRedemptionListDTO = new FetchRedemptionListDTO();
        fetchRedemptionListDTO.setTotalSize(pageableResult.getTotalSize());
        List<FetchRedemptionDTO> fetchRedemptionDTOList = toFetchRedemptionDTOList(structure, pageableResult.getRecords(), storeMap,
                giftCancelableList, accountMap, giftMap, true);
        fetchRedemptionListDTO.setRecords(fetchRedemptionDTOList);
        return fetchRedemptionListDTO;
    }

    public static RedemptionDTO toRedemptionDto(LoyaltyStructure structure, Redemption redemption, Map<String, Gift> giftMap, String region) {
        RedemptionDTO dto = new RedemptionDTO();
        dto.setActivityId(redemption.getActivityId());
        dto.setBrand(redemption.brand());
        dto.setChannel(redemption.getChannel());
        dto.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getCreatedTime()));
        dto.setLoyaltyId(redemption.getLoyaltyId());
        dto.setPoint(redemption.getPoint());
        dto.setStoreCode(redemption.getStoreCode());
        dto.setFreight(redemption.getFreight());
        dto.setDescription(redemption.getDescription());
        dto.setReason(redemption.getReason());
        dto.setRedemptionStatus(redemption.getRedemptionStatus().name());
        dto.setMemberId(redemption.getMemberId());
        dto.setTransactionId(redemption.getId());
        dto.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getUpdatedTime()));
        dto.setRedeemCode(redemption.getRedeemCode());
        dto.setDeliveryChannel(redemption.getDeliveryChannel().name());
        dto.setDeliveryNumber(redemption.getDeliveryNumber());
        dto.setDeliveryCompany(redemption.getDeliveryCompany());
        dto.setReceiverName(desensitizedName(redemption.getReceiver()));
        dto.phone(desensitizedPhoneNumber(redemption.getPhone()));
        dto.setAddress(desensitizedAddress(redemption));
        dto.valueType(redemption.valueType(structure).name());
        dto.setPointItems(redemption.getPointItems().stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()));
        List<GiftItemDTO> giftItemDTOList = new ArrayList<>(4);
        int redemptionQuantity = 0;
        for (GiftItem giftItem : redemption.getGiftItemList()) {
            redemptionQuantity += giftItem.getQuantity();
            Gift gift = giftMap.get(giftItem.getGiftId());
            GiftItemDTO giftItemDTO = new GiftItemDTO();
            giftItemDTO.giftId(giftItem.getGiftId())
                    .giftName(giftItem.getGiftName())
                    .quantity(giftItem.getQuantity())
                    .giftStatus(GiftItemDTO.GiftStatusEnum.fromValue(giftItem.rejected() ?
                            GiftItem.GiftStatus.CANCELED.name() : giftItem.getGiftStatus().name()))
                    .point(giftItem.getPoint())
                    .description(giftItem.getDescription())
                    .imageUri(Optional.ofNullable(gift).map(Gift::getImageUri).orElse(null))
                    .products(GiftAssembler.toProductDTOs(gift));
            giftItemDTOList.add(giftItemDTO);
        }
        dto.setQuantity(redemptionQuantity);
        dto.setTransactionStatus(redemption.getTransactionStatus().name());
        dto.setGiftItems(giftItemDTOList);
        return dto;
    }

    public static FetchRedemptionListDTO toRedemptionListByFilterRedeemCode(LoyaltyStructure structure, PageableResult<Redemption> pageableResult,
                                                                            Map<String, Store> storeMap, Map<String, Boolean> giftCancelableList,
                                                                            Map<String, Account> accountMap, Map<String, Gift> giftMap) {
        FetchRedemptionListDTO fetchRedemptionListDTO = new FetchRedemptionListDTO();
        fetchRedemptionListDTO.setTotalSize(pageableResult.getTotalSize());
        List<FetchRedemptionDTO> fetchRedemptionDTOList = toFetchRedemptionDTOList(structure, pageableResult.getRecords(), storeMap,
                giftCancelableList, accountMap, giftMap, false);
        fetchRedemptionListDTO.setRecords(fetchRedemptionDTOList);
        return fetchRedemptionListDTO;
    }

    private static List<FetchRedemptionDTO> toFetchRedemptionDTOList(LoyaltyStructure structure,
                                                                     List<Redemption> redemptionList,
                                                                     Map<String, Store> storeMap, Map<String, Boolean> giftCancelableList,
                                                                     Map<String, Account> accountMap, Map<String, Gift> giftMap, Boolean redeemCodeVisible) {
        List<FetchRedemptionDTO> fetchRedemptionDTOList = new ArrayList<>();
        if (redemptionList != null && !redemptionList.isEmpty()) {
            for (Redemption redemption : redemptionList) {
                FetchRedemptionDTO fetchRedemptionDTO = toFetchRedemptionDTO(redemption, giftCancelableList, giftMap, redeemCodeVisible);
                if (!StringUtils.isEmpty(redemption.getStoreCode())) {
                    Store store = storeMap.get(redemption.getStoreCode());
                    if (store != null) {
                        fetchRedemptionDTO.setStoreAddress(store.getStoreAddress());
                        fetchRedemptionDTO.setStoreName(store.getStoreName());
                        fetchRedemptionDTO.setStoreCity(store.getCity());
                    }
                }
                if (accountMap != null) {
                    Account account = accountMap.get(redemption.getLoyaltyId());
                    if (account != null) {
                        Tier tier = account.tier(structure.name());
                        fetchRedemptionDTO.setTierLevel(structure.tierLevelSeries()
                                .getLevelByName(tier.getLevel()).getLevelAlias());
                    }
                }
                fetchRedemptionDTO.setEmail(redemption.email());
                fetchRedemptionDTO.valueType(redemption.valueType(structure).name());
                fetchRedemptionDTOList.add(fetchRedemptionDTO);
            }
        }
        return fetchRedemptionDTOList;
    }

    public static FetchRedemptionListDTO toFetchRedemptionListDTO(PageableResult<Redemption> pageableResult,
                                                                  Map<String, Boolean> giftCancelableList, Map<String, Gift> giftMap) {
        FetchRedemptionListDTO fetchRedemptionListDTO = new FetchRedemptionListDTO();
        fetchRedemptionListDTO.setTotalSize(pageableResult.getTotalSize());
        List<FetchRedemptionDTO> fetchRedemptionDTOList = new ArrayList<>();
        List<Redemption> redemptionList = pageableResult.getRecords();
        if (redemptionList != null && !redemptionList.isEmpty()) {
            for (Redemption redemption : redemptionList) {
                FetchRedemptionDTO fetchRedemptionDTO = toFetchRedemptionDTO(redemption, giftCancelableList, giftMap, true);
                fetchRedemptionDTOList.add(fetchRedemptionDTO);
            }
        }
        fetchRedemptionListDTO.setRecords(fetchRedemptionDTOList);
        return fetchRedemptionListDTO;
    }

    public static FetchRedemptionListForC2DTO toFetchRedemptionListForC2DTO(PageableResult<Redemption> pageableResult
            , Map<String, Gift> metaGiftMap) {
        FetchRedemptionListForC2DTO fetchGiftDeliveredRedemptionListDTO = new FetchRedemptionListForC2DTO();
        List<FetchRedemptionForC2DTO> fetchGiftDeliveredRedemptionList = pageableResult.getRecords().stream().map(
                item -> toFetchRedemptionForC2DTO(item, true, metaGiftMap)
        ).collect(Collectors.toList());
        fetchGiftDeliveredRedemptionListDTO.setTotalSize(pageableResult.getTotalSize());
        fetchGiftDeliveredRedemptionListDTO.setRecords(fetchGiftDeliveredRedemptionList);
        return fetchGiftDeliveredRedemptionListDTO;
    }


    /**
     * 把Re
     *
     * @param redemption
     * @return
     */
    private static FetchRedemptionDTO toFetchRedemptionDTO(Redemption redemption,
                                                           Map<String, Boolean> giftCancelableList,
                                                           Map<String, Gift> giftMap, Boolean redeemCodeVisible) {
        FetchRedemptionDTO fetchRedemptionDTO = new FetchRedemptionDTO();
        fetchRedemptionDTO.setActivityId(redemption.getActivityId());
        fetchRedemptionDTO.setAddress(redemption.getAddress());
        fetchRedemptionDTO.setBrand(redemption.brand());
        fetchRedemptionDTO.setChannel(redemption.getChannel());
        fetchRedemptionDTO.setCity(redemption.getCity());
        fetchRedemptionDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getCreatedTime()));
        fetchRedemptionDTO.setExpiredTimme(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getExpiredTime()));
        fetchRedemptionDTO.setDistrict(redemption.getDistrict());
        fetchRedemptionDTO.setLoyaltyId(redemption.getLoyaltyId());
        fetchRedemptionDTO.setPhone(redemption.getPhone());
        fetchRedemptionDTO.setPoint(redemption.getPoint());
        fetchRedemptionDTO.setProvince(redemption.getProvince());
        fetchRedemptionDTO.setReceiver(redemption.getReceiver());
        fetchRedemptionDTO.setStoreCode(redemption.getStoreCode());
        fetchRedemptionDTO.setFreight(redemption.getFreight());
        fetchRedemptionDTO.setPostalCode(redemption.getPostalCode());
        fetchRedemptionDTO.setDescription(redemption.getDescription());
        if (redemption.getValueType() != null) {
            fetchRedemptionDTO.setValueType(redemption.valueTypeDefault().name());
        }
        fetchRedemptionDTO.setReason(redemption.getReason());
        if (redemption.getRedemptionStatus() != null) {
            fetchRedemptionDTO.setRedemptionStatus(redemption.redemptionStatusIsReject() ?
                    RedemptionStatus.CANCELED.name() : redemption.getRedemptionStatus().name());
        }
        fetchRedemptionDTO.setMemberId(redemption.getMemberId());
        fetchRedemptionDTO.setTransactionId(redemption.getId());
        fetchRedemptionDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getUpdatedTime()));
        if (redeemCodeVisible || redemption.returnRedeemCode()) {
            fetchRedemptionDTO.setRedeemCode(redemption.getRedeemCode());
        }
        fetchRedemptionDTO.setDeliveryChannel(redemption.getDeliveryChannel().name());
        fetchRedemptionDTO.setDeliveryNumber(redemption.getDeliveryNumber());
        fetchRedemptionDTO.setDeliveryCompany(redemption.getDeliveryCompany());
        fetchRedemptionDTO.setPointItems(redemption.getPointItems().stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()));
        List<GiftItemDTO> giftItemDTOList = new ArrayList<>(4);
        int redemptionQuantity = 0;
        for (GiftItem giftItem : redemption.getGiftItemList()) {
            redemptionQuantity += giftItem.getQuantity();
            Gift gift = Optional.ofNullable(giftMap).map(map -> map.get(giftItem.getGiftId())).orElse(null);
            GiftItemDTO giftItemDTO = new GiftItemDTO();
            giftItemDTO.giftId(giftItem.getGiftId())
                    .giftName(giftItem.getGiftName())
                    .quantity(giftItem.getQuantity())
                    .giftStatus(GiftItemDTO.GiftStatusEnum.fromValue(giftItem.rejected() || giftItem.expired() ?
                            GiftItem.GiftStatus.CANCELED.name() : giftItem.getGiftStatus().name()))
                    .point(giftItem.getPoint())
                    .description(giftItem.getDescription())
                    .efficacies(Optional.ofNullable(gift).map(Gift::getEfficacies).orElse(null))
                    .imageUri(Optional.ofNullable(gift).map(Gift::getImageUri).orElse(null))
                    .products(GiftAssembler.toProductDTOs(gift));
            StringBuilder key = new StringBuilder(redemption.getId()).append("-").append(giftItem.getGiftId());
            boolean cancelable = giftCancelableList.get(key.toString()) != null && giftCancelableList.get(key.toString());
            giftItemDTO.cancelable(cancelable);
            giftItemDTOList.add(giftItemDTO);
        }
        fetchRedemptionDTO.setQuantity(redemptionQuantity);
        fetchRedemptionDTO.setTransactionStatus(FetchRedemptionDTO.TransactionStatusEnum.fromValue(redemption.getTransactionStatus().name()));
        fetchRedemptionDTO.setGiftItems(giftItemDTOList);
        return fetchRedemptionDTO;
    }

    private static FetchRedemptionForC2DTO toFetchRedemptionForC2DTO(Redemption redemption, Boolean isInvitation,
                                                                     Map<String, Gift> metaGiftMap) {
        FetchRedemptionForC2DTO fetchRedemptionForC2DTO = new FetchRedemptionForC2DTO();
        fetchRedemptionForC2DTO.setTransactionId(redemption.getId());
        fetchRedemptionForC2DTO.setLoyaltyId(redemption.getLoyaltyId());
        fetchRedemptionForC2DTO.setActivityId(redemption.getActivityId());
        fetchRedemptionForC2DTO.setBrand(redemption.brand());
        fetchRedemptionForC2DTO.setChannel(redemption.getChannel());
        fetchRedemptionForC2DTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getCreatedTime()));
        fetchRedemptionForC2DTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemption.getUpdatedTime()));
        fetchRedemptionForC2DTO.setMemberId(redemption.getMemberId());
        fetchRedemptionForC2DTO.setRedemptionStatus(redemption.getRedemptionStatus().name());
        fetchRedemptionForC2DTO.setTransactionStatus(redemption.getTransactionStatus().name());
        fetchRedemptionForC2DTO.setRedeemCode(redemption.getRedeemCode());
        fetchRedemptionForC2DTO.setDescription(redemption.getDescription());
        fetchRedemptionForC2DTO.setGiftItems(redemption.getGiftItemList().stream().map(item -> GiftAssembler.toGiftItemC2DTO(item, metaGiftMap)).collect(Collectors.toList()));
        fetchRedemptionForC2DTO.setStoreCode(redemption.getStoreCode());
        if (Boolean.TRUE.equals(isInvitation)) {
            fetchRedemptionForC2DTO.setReceiver(redemption.getReceiver());
            fetchRedemptionForC2DTO.setPhone(redemption.getPhone());
            fetchRedemptionForC2DTO.setDistrict(redemption.getDistrict());
        }
        return fetchRedemptionForC2DTO;
    }


    public static Map<String, GiftItem> toGiftItemMap(List<GiftIdQuantityCommand> list) {
        Map<String, GiftItem> map = new ConcurrentHashMap<>(4);
        for (GiftIdQuantityCommand dto : list) {
            GiftItem giftItem = new GiftItem();
            BeanUtils.copyProperties(dto, giftItem);
            map.put(dto.getGiftId(), giftItem);
        }
        return map;
    }

    public static FetchOrderListDTO toFetchOrderListDTO(PageableResult<Order> pageableResult) {
        FetchOrderListDTO fetchOrderListDTO = new FetchOrderListDTO();
        fetchOrderListDTO.setTotalSize(pageableResult.getTotalSize());
        List<Order> orderList = pageableResult.getRecords();
        if (!CollectionUtils.isEmpty(orderList)) {
            List<FetchOrderDTO> fetchOrderDTOList = orderList.stream().map(TransactionAssembler::toFetchOrderDTO).collect(Collectors.toList());
            fetchOrderListDTO.setRecords(fetchOrderDTOList);
        }
        return fetchOrderListDTO;
    }

    private static FetchOrderDTO toFetchOrderDTO(Order order) {
        FetchOrderDTO fetchOrderDTO = new FetchOrderDTO();
        fetchOrderDTO.transactionId(order.getId())
                .loyaltyId(order.getLoyaltyId())
                .brand(order.getBrand())
                .channel(order.getChannel())
                .point(order.getPoint())
                .createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(order.getCreatedTime()))
                .updatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(order.getUpdatedTime()))
                .expiredTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(order.getExpiredTime()))
                .availablePoint(order.getAvailablePoint())
                .transactionStatus(FetchOrderDTO.TransactionStatusEnum.valueOf(order.getTransactionStatus().name()))
                .description(order.getDescription())
                .pointType(order.getPointType())
                .orderId(order.getOrderId())
                .storeCode(order.getStoreCode())
                .orderDateTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(order.getOrderDateTime()))
                .groupPurchase(order.getGroupPurchase())
                .refundAmount(order.getRefundAmount())
                .refund(order.getRefund())
                .pointItems(order.getPointItems().stream().map(TransactionAssembler::toPointItemDTO).collect(Collectors.toList()))
                .orderItems(order.getOrderItems().stream().map(TransactionAssembler::toOrderItemDTO).collect(Collectors.toList()));
        return fetchOrderDTO;
    }

    private static OrderItemDTO toOrderItemDTO(OrderItem orderItem) {
        OrderItemDTO orderItemDTO = new OrderItemDTO();
        orderItemDTO.sku(orderItem.getSku())
                .purchaseQty(orderItem.getPurchaseQty())
                .realAmount(orderItem.getRealAmount())
                .retailAmount(orderItem.getRetailAmount());
        return orderItemDTO;
    }

    public static List<String> toGiftIdList(List<GiftIdList> giftIdLists) {
        return giftIdLists.stream().map(GiftIdList::getGiftId).collect(Collectors.toList());
    }

    public static Set<OrderItem> orderItemDtoToOrderItem(@Valid List<OrderItemDTO> orderItemDTOS) {
        Set<OrderItem> orderItems = new HashSet<>();
        for (OrderItemDTO o : orderItemDTOS) {
            OrderItem orderItem = new OrderItem();
            orderItem.setPurchaseQty(o.getPurchaseQty());
            orderItem.setSku(o.getSku());
            orderItem.setRealAmount(o.getRealAmount());
            orderItem.setRetailAmount(o.getRetailAmount());
            orderItems.add(orderItem);
        }
        return orderItems;
    }

    private TransactionAssembler() {
    }

    public static InteractionCountDTO listToInteractionCountDTO(int interactionTimes) {
        InteractionCountDTO interactionCountDTO = new InteractionCountDTO();
        interactionCountDTO.setTotal(interactionTimes);
        return interactionCountDTO;
    }

    private static String desensitizedName(String fullName) {
        if (StringUtils.isBlank(fullName)) {
            return fullName;
        }
        return fullName.substring(0, 1).concat(strToStart(fullName.substring(1)));
    }

    private static String desensitizedPhoneNumber(String phoneNumber) {
        if (StringUtils.isBlank(phoneNumber) || phoneNumber.length() < 4) {
            return phoneNumber;
        }
        if (phoneNumber.length() < 7) {
            return phoneNumber.substring(0, 3).concat(strToStart(phoneNumber.substring(3)));
        }
        return phoneNumber.substring(0, 3)
                .concat(strToStart(phoneNumber.substring(3, 7)))
                .concat(phoneNumber.substring(7));
    }

    private static String desensitizedAddress(Redemption redemption) {
        StringBuilder sb = new StringBuilder();
        concatStr(sb, redemption.getProvince());
        concatStr(sb, redemption.getCity());
        concatStr(sb, redemption.getDistrict());
        concatStr(sb, strToStart(redemption.getAddress()));
        return sb.toString();
    }

    private static String strToStart(String str) {
        return StringUtils.isBlank(str) ? "" :
                IntStream.range(0, str.length()).mapToObj(i -> "*").collect(Collectors.joining());
    }

    private static StringBuilder concatStr(StringBuilder sb, String str) {
        sb.append(StringUtils.isBlank(str) ? "" : str);
        return sb;
    }

    public static Interaction toInteraction(AddInteractionCommand body, Account account, LoyaltyStructure loyaltyStructure) {
        Interaction interaction = new Interaction(account.loyaltyId(), body.getBrand(), body.getChannel(), loyaltyStructure, body.getMemberId(), body.getExternalBusinessId());
        interaction.setImageUriList(body.getImageUriList());
        return interaction;
    }

    public static Interaction toInteraction(AddInteractionCommandV2 body, Account account, LoyaltyStructure loyaltyStructure) {
        Interaction interaction = new Interaction(account.loyaltyId(), body.getBrand(), body.getChannel(), loyaltyStructure, body.getMemberId(), body.getExternalBusinessId());
        Optional.ofNullable(body.getExtraParams()).ifPresent(extraParams ->
                interaction.setImageUriList(extraParams.getImageUriList())
        );
        return interaction;
    }

    public static InteractionExtraParams toInteractionExtraParams(AddInteractionCommand body) {
        InteractionExtraParams extraParams = new InteractionExtraParams();
        extraParams.setConvertPoint(false);
        extraParams.setValueType(InteractionExtraParams.ValueTypeEnum.DEFAULT);
        extraParams.setImageUriList(body.getImageUriList());
        extraParams.setNewMember(body.isNewMember());
        extraParams.setQrcode(body.getQrcode());
        extraParams.setSku(body.getSku());
        return extraParams;
    }

}
