package cn.com.pg.loyalty.infrastructure.rule.engine;

public enum RuleType {
    ORDER,
    INTERACTION,
    REDEMPTION,
    TIER,
    ALL
}
