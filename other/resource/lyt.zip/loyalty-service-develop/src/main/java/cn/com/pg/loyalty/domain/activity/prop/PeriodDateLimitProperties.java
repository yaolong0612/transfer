package cn.com.pg.loyalty.domain.activity.prop;

import lombok.*;

/**
 * @Author: Hayden
 * @CreateDate: 2021/4/14 17:20
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/4/14 17:20
 * @Version: 1.0
 * @Description:
 */
@Getter
@Setter
@NoArgsConstructor
public class PeriodDateLimitProperties extends RuleProperties {

    /**
     * 限定日期方式
     */
    private PeriodDateType type;
    /**
     * 限定日期间隔：如1天、2天
     */
    private int interval;
    /**
     * 限制业务数量
     */
    private int limitNum;
    /**
     * 是否是限制所有加积分
     */
    private boolean limitTotalAddPoint;
}
