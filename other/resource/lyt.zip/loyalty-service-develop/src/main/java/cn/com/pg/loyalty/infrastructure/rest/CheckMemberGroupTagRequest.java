package cn.com.pg.loyalty.infrastructure.rest;

import cn.com.pg.loyalty.domain.account.CheckMemberGroupTagGateway;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.paas.commons.utils.ApimSignUtils;
import cn.com.pg.paas.commons.utils.JsonUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * @author lvyanlin
 * @date 2022/6/17 11:12
 */
@Getter
@Setter
@Slf4j
@Component
public class CheckMemberGroupTagRequest implements CheckMemberGroupTagGateway {


    //apim peopleX配置
    @Value("${apim.peopleX.subscriptionKey}")
    private String apimSubscriptionKey;
    @Value("${apim.peopleX.api-url}")
    private String apiUrl;
    @Value("${apim.peopleX.api-key}")
    private String apiKey;
    @Value("${apim.peopleX.secret}")
    private String secret;

    @Autowired
    private RestTemplate template;

    /**
     * 判断品牌会员是否加入BC企业微信并且加入企微群
     *
     * @param memberId
     * @param brand
     * @return
     */
    @Override
    public boolean isWechatGroupFriend(String memberId, String brand) {
        JSONObject data = getGroupChatStatus(memberId, brand);
        //入企微群状态
        boolean inGroup = data.getBoolean("inGroup");
        //入BC企业微信状态
        boolean memberFriendship = data.getBoolean("memberFriendship");
        return inGroup && memberFriendship;
    }

    /**
     * 判断品牌会员是否加入BC企业微信
     *
     * @param memberId
     * @param brand
     * @return
     */
    @Override
    public boolean judgeJoinEnterpriseWechatForBC(String memberId, String brand) {
        JSONObject data = getGroupChatStatus(memberId, brand);
        //入BC企业微信状态
        boolean memberFriendship = data.getBoolean("memberFriendship");
        return memberFriendship;
    }


    /**
     * 发送邮件
     */
    private JSONObject getGroupChatStatus(String memberId, String brand) {
        Map<String, String> variables = buildUriVariables(brand, memberId);
        log.info("variables:{}", JsonUtils.obj2Json(variables));
        String url = apiUrl + changeJsonToArguments(variables);
        log.info("url:{}", url);
        ResponseEntity<String> exchange = template.getForEntity(url, String.class);
        JSONObject response = JSON.parseObject(exchange.getBody());
        log.info("exchange:{}", exchange);
        if (null == response) {
            throw new SystemException("peopleX response error", ResultCodeMapper.PEOPLEX_GROUP_MEMBER_STATUS);
        }
        JSONObject data = response.getJSONObject("data");
        if (null == data) {
            throw new SystemException("peopleX response error", ResultCodeMapper.PEOPLEX_GROUP_MEMBER_STATUS);
        }
        return data;
    }

    private String changeJsonToArguments(Map<String, String> apiCase) {
        Set<String> keys = apiCase.keySet();
        StringBuilder arg = new StringBuilder("?");
        for (String key : keys) {
            arg.append(key).append("=").append(apiCase.get(key)).append("&");
        }
        return arg.deleteCharAt(arg.length() - 1).toString();//此处为了兼容case内容为空
    }

    /**
     * 构建APIM相关参数
     */
    private Map<String, String> buildUriVariables(String brand, String memberId) {
        Map<String, String> params = new HashMap<>(4);
        params.put("brand", brand);
        params.put("memberId", memberId);
        params.put("api_key", apiKey);
        params.put("nonce_str", UUID.randomUUID().toString());
        params.put("timestamp", DateFormatUtils.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        params.put("subscription-key", apimSubscriptionKey);
        params.put("sign", ApimSignUtils.sign(params, null, secret));
        return params;
    }
}
