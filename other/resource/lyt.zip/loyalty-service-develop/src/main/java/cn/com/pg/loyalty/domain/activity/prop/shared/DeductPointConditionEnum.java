package cn.com.pg.loyalty.domain.activity.prop.shared;

/**
 * 兑换/交互减积分处理条件
 */
public enum DeductPointConditionEnum {
    /**
     * 只能扣减为0积分，比如账号上可用1000积分，请求扣1500积分，实际只能扣1000积分
     */
    DEDUCT_ZERO_POINT,
    /**
     * 允许扣减为负积分，只能一次
     */
    DEDUCT_NEGATIVE_POINT,
    /**
     * 不允许扣减为负积分（业务异常）
     */
    DEDUCT_NEGATIVE_POINT_ERR;
}
