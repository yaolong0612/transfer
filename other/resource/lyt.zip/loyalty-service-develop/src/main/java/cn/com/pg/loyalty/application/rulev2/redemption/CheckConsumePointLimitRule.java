package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.RedemptionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * 活动限制兑换积分规则
 *
 * @author linbj
 * @date 2020/6/16 14:47
 */

@Slf4j
@Rule(name = "兑换活动限制消费积分规则",
        description = "兑换活动限制消费积分规则",priority = 0)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
@Component
public class CheckConsumePointLimitRule {


    @Condition
    public boolean validateRule(@Fact(RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                                @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                                @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        if (redemption.valueType(structure).equals(ValueType.DEFAULT)) {
            return ruleProperties.getMaxConsumePoint() > 0;
        }
        return ruleProperties.getMaxConsumeTransitPoint() > 0;

    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties,
                            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords) {

        int point = redemption.point();
        ValueType valueType = redemption.valueType(structure);
        int maxConsumePoint = ruleProperties.getMaxConsumePoint();
        if (valueType == ValueType.TRANSIT) {
            maxConsumePoint = ruleProperties.getMaxConsumeTransitPoint();
        }

        int consumePoint = redemptionRecords.stream().filter(Redemption::redemptionIsEffective)
                .filter(redemption1 -> redemption1.valueType(structure) == valueType)
                .mapToInt(Redemption::getPoint).sum();

        int totalPoint = consumePoint + point;
        if (totalPoint > maxConsumePoint) {
            StringBuilder msg = new StringBuilder();
            msg.append("You have consumed ")
                    .append(consumePoint)
                    .append(" points in the current activity, and the maximum consumption is ")
                    .append(maxConsumePoint)
                    .append(" points .Exchange is failed. valueType :").append(valueType == null ? ValueType.DEFAULT.name() : valueType.name());
            log.info(msg.toString());
            throw new SystemException(msg.toString(), ResultCodeMapper.LIMIT_ERROR);
        }
        log.info("Accumulated consumption of {} points,value type :{}", totalPoint, valueType == null ? ValueType.DEFAULT.name() : valueType.name());
    }

}
