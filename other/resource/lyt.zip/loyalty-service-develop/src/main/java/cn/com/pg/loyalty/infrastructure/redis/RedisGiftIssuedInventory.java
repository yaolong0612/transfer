package cn.com.pg.loyalty.infrastructure.redis;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.GiftIssuedInventory;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class RedisGiftIssuedInventory implements GiftIssuedInventory {

    public static final String GIFT_ISSUED_NUM = "ACTIVITY-GIFT-STOCK";

    @Resource
    private RedisTemplate redisTemplate;

    @Override
    public Long issuedGifts(Redemption redemption, Map<String, RedemptionItem> redemptionItemMap) {
        DefaultRedisScript<Long> script = new DefaultRedisScript<>();
        script.setResultType(Long.class);
        script.setScriptText(getIssuedScript());
        List<String> keys = new ArrayList<>();
        List<Integer> issuedNextInventory = new ArrayList<>();

        redemption.getGiftItemList().forEach(giftItem -> {
            keys.add(generateCacheKey(redemption.activityId(), giftItem.getGiftId()));
            issuedNextInventory.add(giftItem.getQuantity());
            issuedNextInventory.add(redemptionItemMap.get(giftItem.getGiftId()).getStock());
        });
        return (Long) redisTemplate.execute(script, keys, issuedNextInventory.toArray());
    }

    @Override
    public void checkAndSyncIssuedInventory(Redemption redemption, Activity activity) {
        executeIssuedScript(redemption, getSyncScript(), activity.getGifts());
    }


    @Override
    public void refundIssuedInventory(Redemption redemption) {
        executeIssuedScript(redemption, getRefundScript(), null);
    }

    @Override
    public Map<String, Integer> fetchGiftsIssued(String activityId, Set<String> ids) {
        List<String> giftIds = new ArrayList<>(ids);
        List<String> giftKeys = giftIds.stream().map(giftId -> generateCacheKey(activityId, giftId)).collect(Collectors.toList());
        List<Integer> issuedNum = redisTemplate.opsForValue().multiGet(giftKeys);
        Map<String, Integer> issuedMap = new HashMap<>(giftKeys.size());
        for (int i = 0; i < ids.size(); i++) {
            assert issuedNum != null;
            issuedMap.put(giftIds.get(i), issuedNum.get(i));
        }
        return issuedMap;
    }

    private void executeIssuedScript(Redemption redemption, String execScript, Map<String, RedemptionItem> redemptionItemMap) {
        DefaultRedisScript<Void> script = new DefaultRedisScript<>();
        script.setResultType(Void.class);
        script.setScriptText(execScript);
        List<String> keys = new ArrayList<>();
        List<Integer> issued = new ArrayList<>();


        redemption.getGiftItemList().forEach(giftItem -> {
            keys.add(generateCacheKey(redemption.activityId(), giftItem.getGiftId()));
            if (CollectionUtils.isEmpty(redemptionItemMap)) {
                issued.add(giftItem.getQuantity());
                return;
            }
            issued.add(redemptionItemMap.get(giftItem.getGiftId()).getIssuedNum());
        });

        redisTemplate.execute(script, keys, issued.toArray());
    }

    private String getIssuedScript() {
        return "for num, key in pairs(KEYS) do\n" +
                "    if (redis.call('EXISTS', key) ~= 1) then\n" +
                "        return -1;\n" +
                "    end\n" +
                "    local issued = tonumber(ARGV[num * 2 - 1]);\n" +
                "    local inventory = tonumber(ARGV[num * 2]);\n" +
                "    local hasIssued = redis.call('GET', key)\n" +
                "    if ((tonumber(hasIssued) + issued) > inventory) then\n" +
                "        return 0;\n" +
                "    end\n" +
                "end\n" +
                "for num, key in pairs(KEYS) do\n" +
                "    local issued = tonumber(ARGV[num * 2 - 1]);\n" +
                "    redis.call('INCRBY', key, issued)\n" +
                "end\n" +
                "return 1";
    }

    private String getSyncScript() {
        return "for num, key in pairs(KEYS) do\n" +
                "    redis.call('SETNX', key, ARGV[num]);\n" +
                "end";
    }

    private String getRefundScript() {
        return "for num, key in pairs(KEYS) do\n" +
                "    if (redis.call('EXISTS', key) == 1) then\n" +
                "        redis.call('DECRBY', key, ARGV[num]);\n" +
                "    end\n" +
                "end";
    }

    private String generateCacheKey(String activityId, String giftId) {
        return GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
    }

}
