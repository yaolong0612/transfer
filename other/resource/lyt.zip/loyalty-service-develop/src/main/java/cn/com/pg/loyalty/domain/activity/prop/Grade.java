package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Min;
@Data
@NoArgsConstructor
public class Grade {
    public Grade(double baseAmount, int moreThenBaseMultiple) {
        this.baseAmount = baseAmount;
        this.moreThenBaseMultiple = moreThenBaseMultiple;
    }

    @Min(0)
    private double baseAmount;
    @Min(0)
    private int moreThenBaseMultiple;
}
