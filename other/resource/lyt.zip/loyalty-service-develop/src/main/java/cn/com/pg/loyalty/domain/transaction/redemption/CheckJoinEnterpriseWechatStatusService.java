package cn.com.pg.loyalty.domain.transaction.redemption;

import cn.com.pg.loyalty.domain.account.CheckMemberGroupTagGateway;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
/**
 * 核销礼品前检查是否加入BC企业微信
 */
public class CheckJoinEnterpriseWechatStatusService {

    @Autowired
    private CheckMemberGroupTagGateway gateway;
    @Autowired
    private CacheService cacheService;

    /**
     * 检查活动和礼品在核销时是否需要加入BC企业微信
     *
     * @param redemption
     * @return
     */
    private boolean checkActiviyConditionNeedJoinEnterpriseWechat(Redemption redemption, List<String> giftIdList) {
        Activity activity = cacheService.findActivityById(redemption.getActivityId());
        RedemptionProperties properties = (RedemptionProperties) activity.ruleProperties();
        //过滤得到要核销的礼品
        List<GiftItem> receiveGiftItemList = redemption.getGiftItemList().stream().filter(giftItem ->
                giftIdList.contains(giftItem.getGiftId())).collect(Collectors.toList());

        return doCheckActivityConditionNeedJoinEnterpriseWechatForGroup(properties.fetchNext(), activity.getGifts(), receiveGiftItemList);
    }

    /**
     * 分组检查
     *
     * @param properties
     * @param activityGifts
     * @param receiveGiftItemList
     * @return
     */
    private boolean doCheckActivityConditionNeedJoinEnterpriseWechatForGroup(CommonProperties properties, Map<String, RedemptionItem> activityGifts, List<GiftItem> receiveGiftItemList) {
        //没有分组 不检查需要加入BC企业微信
        if (properties == null) {
            return Boolean.FALSE;
        }

        if (receiveGiftItemList.stream().anyMatch(giftItem ->
                properties.checkJoinEnterpriseWechatForBC(activityGifts, giftItem))) {
            //有分组 且分组下为true ，默认该分组下所有档位需要检查，不需要检查分档
            return Boolean.TRUE;

        }
        // 有分组 但分组不检查， 需要检查分档是否需要检查
        return doCheckActivityConditionNeedJoinEnterpriseWechatForGrade(properties.fetchNext(), activityGifts, receiveGiftItemList);
    }

    /**
     * 分档检查
     *
     * @param properties
     * @param activityGifts
     * @param receiveGiftItemList
     * @return
     */
    private boolean doCheckActivityConditionNeedJoinEnterpriseWechatForGrade(CommonProperties properties, Map<String, RedemptionItem> activityGifts, List<GiftItem> receiveGiftItemList) {
        //没有分档 不检查
        if (properties == null) {
            //默认不检查是否需要加入BC企业微信
            return Boolean.FALSE;
        }
        return (receiveGiftItemList.stream().anyMatch(giftItem ->
                properties.checkJoinEnterpriseWechatForBC(activityGifts, giftItem)));
    }

    /**
     * 如果不满足活动条件(不需要确认是否加入BC企业微信)，直接默认返回true-不需要检查是否加入企业微信
     * 如果满足活动条件(需要确认是否加入BC企业微信)，请求BC企业微信接口，判断是否加入
     */
    public boolean checkJoinEnterpriseWechatForBC(Redemption redemption, List<String> giftIdList) {

        if (!checkActiviyConditionNeedJoinEnterpriseWechat(redemption, giftIdList)) {
            //活动配置不需要检查，直接返回true
            return Boolean.TRUE;
        }
        //活动配置需要检查会员是否加入BC企业微信
        boolean joinEnterpriseWechatForBC = gateway.judgeJoinEnterpriseWechatForBC(redemption.getMemberId(), redemption.brand());
        if (!joinEnterpriseWechatForBC) {
            //判断未加入BC企业微信，直接抛出异常
            throw new SystemException("会员没有绑定企业微信，无法提交订单；请会员绑定企业微信后，重新提交订单即可。", ResultCodeMapper.PEOPLEX_GROUP_MEMBER_STATUS);
        }
        return Boolean.TRUE;
    }
}
