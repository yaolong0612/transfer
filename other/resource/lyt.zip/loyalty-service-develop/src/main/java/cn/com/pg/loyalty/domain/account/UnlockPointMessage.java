package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class UnlockPointMessage {
    private String loyaltyId;
    private String brand;
    //如果没有值，默认是当天
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDate unlockTime=LocalDate.now();
}
