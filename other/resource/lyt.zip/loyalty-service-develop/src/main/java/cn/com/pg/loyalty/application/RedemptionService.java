package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountValidateService;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.GiftIssuedInventory;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.shared.CalculateService;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.lock.MutexLock;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;


/**
 * @author yanyongfu
 * Redemption Service
 */
@Service
@Slf4j
public class RedemptionService {

    @Autowired
    private TransactionForEsRepository transactionForEsRepository;
    @Autowired
    private AccountValidateService accountValidateService;
    @Autowired
    private ActivitiesService activitiesService;
    @Autowired
    private RedemptionRepositoryV2 redemptionRepositoryV2;
    @Autowired
    private CalculateService calculateServiceImpl;
    @Autowired
    private ActivityRepository activityRepository;
    @Autowired
    private GiftIssuedInventory giftIssuedInventory;


    public PageableResult<Redemption> fetchRedemptionListByStoreCode(LocalDateTime startAt, LocalDateTime endAt,
                                                                     String storeCode, String brand, Integer page,
                                                                     Integer perPage) {
        return transactionForEsRepository.fetchRedemptionListByStoreCode(
                startAt, endAt, storeCode, brand, page, perPage);
    }

    public PageableResult<Redemption> fetchRedemptionListByRedeemCode(LocalDateTime startAt, LocalDateTime endAt,
                                                                      String redeemCode, String brand,
                                                                      RedemptionStatus redemptionStatus, Integer page
            , Integer perPage) {
        return transactionForEsRepository.fetchRedemptionListByRedeemCode(
                startAt, endAt, redeemCode, brand, redemptionStatus, page, perPage);
    }

    public PageableResult<Redemption> fetchRedemptionList(String activityId, String brand,
                                                          LocalDateTime startTime, LocalDateTime endTime,
                                                          Integer perPage, Integer page, String memberId,
                                                          RedemptionStatus redemptionStatus,
                                                          DeliveryChannel deliveryChannel, String channel) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("redemptionStatus", redemptionStatus);
        queryParams.put("deliveryChannel", deliveryChannel);
        queryParams.put("brand", brand);
        queryParams.put("channel", channel);
        queryParams.put("memberId", memberId);
        queryParams.put("activityId", activityId);
        PageableResult<Redemption> redemptionPageableResult = transactionForEsRepository.fetchRedemptionList(startTime,
                endTime, queryParams, brand, page, perPage);
        List<Redemption> redemptions = redemptionPageableResult.getRecords().stream().filter(Redemption::visibleIsNot)
                .collect(Collectors.toList());
        return new PageableResult<>(redemptionPageableResult.getTotalSize(), redemptions);
    }


    @MutexLock(lockKeys = {"#redemption.brand", "#redemption.memberId"})
    public AccountTransactionResult createRedemption(Redemption redemption, LoyaltyStructure structure, Locale language) {
        Account account = accountValidateService.validate(structure, redemption.getMemberId());
        Activity activity = activitiesService.checkRedemptionActivity(redemption.activityId(), structure);
        redemption.bindAccount(structure, account);
        redemption.calculatePoint(activity);

        List<Redemption> redemptionRecords = redemptionRepositoryV2
                .findInActivityNotInRedemptionStatus(account, redemption.activityId(), Redemption.backStatus());
        return calculateServiceImpl.calculateRedemption(structure, redemption, account, activity,
                redemptionRecords, language);
    }

    @MutexLock(lockKeys = {"'SYNC-ISSUED'", "#activityId"}, maxTryTimes = 20)
    public void syncGiftIssued(String activityId, Set<String> giftIds) {
        if (CollectionUtils.isEmpty(giftIds)) {
            return;
        }
        List<Activity> activityList = activityRepository.findActivityById(activityId);
        if (activityList.isEmpty()) {
            return;
        }
        Activity activity = activityList.get(0);
        Map<String, Integer> issuedMap = giftIssuedInventory.fetchGiftsIssued(activityId, giftIds);
        AtomicBoolean change = new AtomicBoolean(false);
        issuedMap.forEach((giftId, issued) -> {
            if (issued == null) {
                return;
            }
            RedemptionItem item = activity.getGifts().get(giftId);
            if (item == null) {
                return;
            }
            if (item.getStock() < issued) {
                return;
            }
            if (issued.equals(item.getIssuedNum())) {
                return;
            }
            change.set(true);
            item.setIssuedNum(issued);

        });
        if (!change.get()) {
            return;
        }
        activityRepository.save(activity);

    }
}
