package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.infrastructure.cosmosdb.StructureJpaRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class StructureService {

    @Autowired
    private StructureJpaRepository structureJpaRepository;

    @Autowired
    private CacheService cacheServiceImpl;

    /**
     * 新增LoyaltyStructure
     */
    public LoyaltyStructure addLoyaltyStructure(LoyaltyStructure outerLoyaltyStructure) {
        LoyaltyStructure innerLoyaltyStructure = outerLoyaltyStructure;
        Optional<LoyaltyStructure> loyaltyStructureV2Optional = structureJpaRepository.findById(outerLoyaltyStructure.name());
        if (loyaltyStructureV2Optional.isPresent()) {
            innerLoyaltyStructure = loyaltyStructureV2Optional.get();
            innerLoyaltyStructure.updateMessage(outerLoyaltyStructure);
        }
        cacheServiceImpl.removeLoyaltyStructureCache();
        return structureJpaRepository.save(innerLoyaltyStructure);
    }

    /**
     * 查询LoyaltyStructure
     */
    public LoyaltyStructure findLoyaltyStructureById(String name) {
        return structureJpaRepository.findById(name).orElse(null);
    }

    public List<LoyaltyStructure> findLoyaltyStructures() {
        return structureJpaRepository.findLoyaltyStructures();
    }

    public LoyaltyStructure checkLoyaltyStructure(String region, String brand) {
        return cacheServiceImpl.findLoyaltyStructure(region, brand);
    }

}
