package cn.com.pg.loyalty.domain.structure;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ConfigRepository extends DocumentDbRepository<Config, String> {

    List<Config> findByTypeAndName(String type, String name);

    List<Config> findAllByType(String type);

    List<Config> findByPartitionKeyAndId(String partitionKey, String id);

    void deleteByPartitionKeyAndId(String partitionKey, String id);
}
