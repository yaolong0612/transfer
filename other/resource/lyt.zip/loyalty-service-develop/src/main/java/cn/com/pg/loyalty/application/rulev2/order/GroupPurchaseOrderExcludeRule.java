package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.GroupPurchaseOrderExcludePropertiesV2;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/22
 */
@Rule(name = "GROUP_PURCHASE_ORDER_EXCLUDE_RULE",
        description = "limit add the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.ORDER)
public class GroupPurchaseOrderExcludeRule {
    private RuleTemplate ruleTemplate = RuleTemplate.GROUP_PURCHASE_ORDER_EXCLUDE_RULE;


    /**
     * @param activityList
     * @param order
     * @param ruleResult
     * @return
     */
    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                             @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                             @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {

        List<Activity> limitActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        if (CollectionUtils.isEmpty(limitActivityList)) {
            //没有匹配到活动限制,可以进入下一流程
            log.info("orderId:{}匹配到的限制活动数:{}", order.getOrderId(), limitActivityList.size());
            return Boolean.TRUE;
        }
        //匹配到活动限制，进行条件判断
        Activity limitActivity = limitActivityList.get(0);
        GroupPurchaseOrderExcludePropertiesV2 ruleContent = JSON.parseObject(limitActivity.getRuleProperties(), GroupPurchaseOrderExcludePropertiesV2.class);
        // 订单金额>=团购金额,判断团购订单成立，结束加积分流程
        if (order.getRealTotalAmount() >= ruleContent.getRealGroupPurchaseAmount()) {
            log.info("orderId:{}订单金额: {} 配置限制团购金额:{} 满足团购条件，不参与加积分流程", order.getOrderId(), order.getRealTotalAmount(), ruleContent.getRealGroupPurchaseAmount());
            //给订单设置团购标志
            order.groupPurchase();
            ruleResult.end();
            return Boolean.FALSE;
        }
        //返回true 设置允许进入下一流程
        return Boolean.TRUE;
    }

    /**
     * @param ruleResult
     */
    @Action
    public void permitAddPoint(
            @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult
    ) {
        //设置success才能执行下一流程
        ruleResult.success();
    }
}
