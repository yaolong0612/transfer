package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @author LMR
 */
@Rule(name = "RedemptionMutex", description = "礼品互斥规则", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION,
        ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
public class CheckRedemptionMutexRule {

    @Condition
    public boolean matchRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                             @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                             @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        // 分组或挡位之间互斥设置为true进入规则
        return redemption.getGiftItemList().stream()
                .anyMatch(giftItem -> properties.fetchMutex(activity.getGifts(), giftItem));
    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_ACTIVITY) Activity activity,
                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords,
                            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties) {
        Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
        List<GiftItem> giftItemList = redemption.getGiftItemList();
        List<GiftItem> historyGiftItemList = redemptionRecords.stream()
                .flatMap(redemptionRecord -> redemptionRecord.effectiveGiftItems().stream())
                .filter(item -> properties.fetchMutex(redemptionItemMap, item))
                .collect(Collectors.toList());
        if (properties.checkMutex(redemptionItemMap, giftItemList, historyGiftItemList)) {
            throw new SystemException("兑换礼品互斥", ResultCodeMapper.REDEMPTION_GIFT_MUTEX);
        }
    }
}
