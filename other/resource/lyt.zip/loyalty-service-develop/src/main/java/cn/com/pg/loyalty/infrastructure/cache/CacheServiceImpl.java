package cn.com.pg.loyalty.infrastructure.cache;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.*;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.dmp.StoreRepository;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftRepository;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.cosmosdb.StructureJpaRepository;
import cn.com.pg.loyalty.infrastructure.lock.Lock;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.ehcache.Cache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.application.TransactionService.GIFT_ISSUED_NUM;
import static cn.com.pg.loyalty.application.TransactionService.GIFT_STOCK_TO_REDEEM_GIFT;
import static cn.com.pg.loyalty.infrastructure.lock.MutexLockPointCutAdvice.LOCK_DIR;

/**
 * @author Simon
 * @author cooltea
 */
@Slf4j
@Component
public class CacheServiceImpl implements CacheService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    @Qualifier("systemMemoryCache")
    public Cache<String, Object> memCacheTemplate;
    /**
     * 默认设置存redis 过期2小时
     */
    private static final long EXPIRED_TIME = 30 * 60 * 1_000L;

    private static final String TMP_REDIS_SET_VALUE = "tmp-set-val";

    /**
     * 缓存Member Id与Loyalty ID之间的关系Mid-Lid-memberid-programid
     */
    private static final String CACHE_MEMBER_ID_LOYALTY_ID_PREFIX = "MLP-";

    private static final long THREE_MONTH_SECOND = 90 * 24 * 3600 * 1000L;

    /**
     * 缓存烧过的qrcode进redis,过期时间90天
     */
    private static final String CACHE_QRCODE_PREFIX = "QRCODE:";

    private static final String STRUCTURE_PREFIX = "STRUCTURE:";

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private GiftRepository giftRepository;
    @Autowired
    private PointTypeRepository pointTypeRepository;

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private StructureJpaRepository structureJpaRepository;
    @Autowired
    private Lock redisLock;
    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public void setValue(String key, Object value, long millisExpireTime) {
        String valueStr = JSON.toJSONString(value);
        memCacheTemplate.put(key, value);
        if (millisExpireTime > 0) {
            stringRedisTemplate.opsForValue().set(key, valueStr, millisExpireTime, TimeUnit.MILLISECONDS);
        } else {
            stringRedisTemplate.opsForValue().set(key, valueStr);
        }
    }

    @Override
    public boolean lockedUpCompetition(String lockArea, long millisExpireTime) {
        Boolean setUp = stringRedisTemplate.opsForValue()
                .setIfAbsent(lockArea, "1", millisExpireTime, TimeUnit.MILLISECONDS);
        return setUp != null && setUp;
    }

    @Override
    public void setValueToMemory(String key, Object value) {
        memCacheTemplate.put(key, value);
    }

    @Override
    public <T> T getValue(String key, Class<T> clazz) {
        Object memCacheV = memCacheTemplate.get(key);
        return Optional.ofNullable(memCacheV).map(v -> (T) v).orElseGet(() -> {
            String result = getValueFromRedis(key);
            if (StringUtils.isNoneBlank(result)) {
                return Optional.of(JSON.parseObject(result, clazz)).map(objT -> {
                    setValueToMemory(key, objT);
                    return objT;
                }).get();
            }
            return null;
        });
    }

    @Override
    public <T> List<T> getValues(String key, Class<T> clazz) {
        Object obj = memCacheTemplate.get(key);
        return Optional.ofNullable(obj).map(o -> (List<T>) o).orElseGet(() -> {
            String result = getValueFromRedis(key);
            return Optional.ofNullable(result).map(valueStr -> {
                List<T> list = JSON.parseArray(valueStr, clazz);
                setValueToMemory(key, list);
                return list;
            }).orElse(new ArrayList<>());
        });
    }

    @Override
    public void deleteKey(String key) {
        stringRedisTemplate.delete(key);
    }

    @Override
    public void delActivityRedisKey(String activityId) {
        deleteKey(getKey(KeyEnum.ACTIVITY, activityId));
    }

    @Override
    public void delGiftRedisKey(String giftId) {
        deleteKey(getKey(KeyEnum.GIFT, giftId));
    }

    @Override
    public PointType validatePointType(String pointType, String structureName, TransactionType transactionType) {
        String key = getKey(KeyEnum.POINT_TYPE_LIST, structureName, pointType);
        List<PointType> pointTypes = getValues(key, PointType.class);
        if (pointTypes.isEmpty()) {
            pointTypes = pointTypeRepository.findByPointTypeAndLoyaltyStructure(pointType, structureName);
            if (!pointTypes.isEmpty()) {
                setValue(key, pointTypes, EXPIRED_TIME);
            }
        }
        Optional<PointType> isExists = pointTypes.parallelStream()
                .filter(PointType::availablePointType)
                .filter(pointType1 -> pointType1.thisTransactionType(transactionType)).findFirst();
        return isExists.orElseThrow(() -> new SystemException("There is no corresponding pointType", ResultCodeMapper.POINT_TYPE_NOT_FOUND));
    }

    @Override
    public void validatePointType(String pointType, String structureName) {
        String key = getKey(KeyEnum.POINT_TYPE_LIST, structureName, pointType);
        List<PointType> pointTypes = getValues(key, PointType.class);
        if (pointTypes.isEmpty()) {
            pointTypes = pointTypeRepository.findByPointTypeAndLoyaltyStructure(pointType, structureName);
            if (!pointTypes.isEmpty()) {
                setValue(key, pointTypes, EXPIRED_TIME);
            }
        }
        Optional<PointType> isExists = pointTypes.parallelStream()
                .filter(PointType::availablePointType).findFirst();
        if (!isExists.isPresent()) {
            throw new SystemException("There is no corresponding pointType", ResultCodeMapper.POINT_TYPE_NOT_FOUND);
        }
    }


    @Override
    public LoyaltyStructure findLoyaltyStructureById(String id) {
        return getLoyaltyStructures().stream()
                .filter(structure -> StringUtils.equals(id, structure.name()))
                .findFirst().orElseThrow(() -> new SystemException("Not find the structure", ResultCodeMapper.PARAM_ERROR));
    }

    @Override
    public LoyaltyStructure findLoyaltyStructure(Account account) {
        return getLoyaltyStructures().stream()
                .filter(structure -> StringUtils.equals(account.getMarketingProgramId(), structure.marketingProgramId()))
                .findFirst().orElseThrow(() -> new SystemException("Not find the structure", ResultCodeMapper.PARAM_ERROR));
    }

    @Override
    public LoyaltyStructure findLoyaltyStructure(String region, String brand) {
        List<LoyaltyStructure> structures = getLoyaltyStructures();
        return structures.stream().filter(structure1 -> structure1.contain(region, brand))
                .findFirst().orElseThrow(() -> new SystemException("The region and brand not config structure",
                        ResultCodeMapper.PARAM_ERROR));
    }

    @Override
    public void removeLoyaltyStructureCache() {
        String key = STRUCTURE_PREFIX.concat("ALL");
        memCacheTemplate.remove(key);
        memCacheTemplate.remove(key);
    }

    private List<LoyaltyStructure> getLoyaltyStructures() {
        String redisKey = STRUCTURE_PREFIX.concat("ALL");
        List<LoyaltyStructure> structures = getValues(redisKey, LoyaltyStructure.class);
        if (!CollectionUtils.isEmpty(structures)) {
            return structures;
        }
        structures = structureJpaRepository.findLoyaltyStructures();
        if (!CollectionUtils.isEmpty(structures)) {
            setValue(redisKey,structures,60*30*1000L);
        }
        return structures;
    }


    @Override
    public Optional<PointType> findByPointTypeAndLoyaltyStructureAndTransactionType(String pointType, String structureName, TransactionType transactionType) {
        String key = this.getKey(KeyEnum.POINT_TYPE_LIST, structureName, pointType);
        List<PointType> pointTypes = getValues(key, PointType.class);
        if (pointTypes.isEmpty()) {
            pointTypes = pointTypeRepository.findByPointTypeAndLoyaltyStructure(pointType, structureName);
            if (!pointTypes.isEmpty()) {
                setValue(key, pointTypes, EXPIRED_TIME);
            }
        }
        return pointTypes.parallelStream()
                .filter(PointType::availablePointType)
                .filter(pointType1 -> pointType1.thisTransactionType(transactionType)).findFirst();
    }

    @Override
    public List<Activity> getActivities(TransactionType transactionType) {
        String key = this.getKey(KeyEnum.ACTIVITY, transactionType.name());
        // 查缓存
        List<Activity> activities = this.getValues(key, Activity.class);
        if (activities.isEmpty()) {
            // 查数据库
            activities = activityRepository.findByTransactionType(transactionType);
            if (activities != null && !activities.isEmpty()) {
                this.setValue(key, activities, EXPIRED_TIME);
            }
        }
        return activities;
    }

    @Override
    public List<Activity> filterActivity(List<Activity> activities, String structureName, String brand, String name, ActivityStatus status, LocalDateTime startAt, LocalDateTime endAt, Comparator<Activity> comparator) {
        if (comparator != null) {
            activities.sort(comparator);
        }
        return activities.parallelStream()
                .filter(activity -> StringUtils.equals(activity.getLoyaltyStructure(), structureName))
                .filter(activity -> activity.getBrand().equals(brand))
                .filter(activity -> Optional.ofNullable(name).map(name1 -> activity.getActivityName().contains(name1)).orElse(true))
                .filter(activity -> Optional.ofNullable(status).map(status1 -> activity.getStatus().equals(status1)).orElse(true))
                .filter(activity -> Optional.ofNullable(startAt).map(startAt1 -> activity.getStartAt().isAfter(startAt1)).orElse(true))
                .filter(activity -> Optional.ofNullable(endAt).map(endAt1 -> activity.getEndAt().isBefore(endAt1)).orElse(true))
                .collect(Collectors.toList());
    }

    @Override
    public <T> PageableResult<T> generatePage(Integer page, Integer pageSize, List<T> totalElements, Comparator<T> comparator) {
        if (comparator != null) {
            totalElements.sort(comparator);
        }
        page = page == null ? 1 : page;
        pageSize = pageSize == null ? totalElements.size() : pageSize;
        int start = (page - 1) * pageSize;
        int end = page * pageSize;
        if (start >= totalElements.size()) {
            //左边已经超出范围
            return new PageableResult<>(totalElements.size(), new ArrayList<>());
        }
        //如果右边大于最大元素，则设置为最大元素的值，防止list报错
        end = end > totalElements.size() ? totalElements.size() : end;
        return new PageableResult<>(totalElements.size(), totalElements.subList(start, end));
    }

    @Override
    public List<Activity> filterAvailableActivity(List<Activity> activities, LocalDateTime compareTime, Comparator<Activity> comparator) {
        List<Activity> temps = activities.parallelStream().filter(activity -> activity.available(compareTime)).collect(Collectors.toList());
        if (comparator != null) {
            temps.sort(comparator);
        }
        return temps;
    }

    /**
     * 正常情况下，loyalty id应该都要从缓存中拿到
     *
     * @param marketingProgramId
     * @param memberId
     * @return
     */
    @Override
    public String fetchLoyaltyId(String marketingProgramId, String memberId) {
        String key = CACHE_MEMBER_ID_LOYALTY_ID_PREFIX.concat(marketingProgramId).concat(memberId);
        return getValue(key, String.class);
    }

    @Override
    public void cacheMemberIdLoyaltyIdMapping(String marketingProgramId, String memberId, String loyaltyId) {
        String key = CACHE_MEMBER_ID_LOYALTY_ID_PREFIX.concat(marketingProgramId).concat(memberId);
        setValue(key, loyaltyId, THREE_MONTH_SECOND);
    }

    private String getValueFromRedis(String key) {
        return stringRedisTemplate.opsForValue().get(key);
    }

    @Override
    public List<Activity> fetchAvailableActivitiesByRuleTemplateInOrder(RuleTemplate ruleTemplate) {
        String key = getKey(KeyEnum.ACTIVITY, ruleTemplate.name());
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByRuleTemplateAndStatus(ruleTemplate, ActivityStatus.ACTIVATE);
            if (!activities.isEmpty()) {
                setValue(key, activities, EXPIRED_TIME);
            }
        }
        Comparator<Activity> comparator = Comparator.comparing(Activity::getPriority).thenComparing(Activity::getUpdatedTime).reversed();
        activities = filterAvailableActivity(activities, LocalDateTime.now(), comparator);
        return activities;
    }

    @Override
    public List<Activity> fetchAvailableActivitiesByRuleTemplateAndBrandInOrder(RuleTemplate ruleTemplate, String brand) {
        String key = getKey(KeyEnum.ACTIVITY, ruleTemplate.name(), brand);
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByBrandAndRuleTemplateAndStatus(brand, ruleTemplate, ActivityStatus.ACTIVATE);
            if (!activities.isEmpty()) {
                setValue(key, activities, EXPIRED_TIME);
            }
        }
        Comparator<Activity> comparator = Comparator.comparing(Activity::getPriority)
                .thenComparing(Activity::getUpdatedTime).reversed();
        activities = filterAvailableActivity(activities, LocalDateTime.now(), comparator);
        return activities;
    }

    @Override
    public List<Activity> fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(String pointType, String structureName) {
        return fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(pointType, structureName, LocalDateTime.now());
    }

    @Override
    public List<Activity> fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(String pointType, String structureName, LocalDateTime compareActivityTime) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE, structureName, pointType);
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByLoyaltyStructureAndPointType(structureName, pointType);
            if (!activities.isEmpty()) {
                setValue(key, activities, EXPIRED_TIME);
            }
        }
        Comparator<Activity> comparator = Comparator.comparing(Activity::getPriority).thenComparing(Activity::getUpdatedTime).reversed();
        activities = filterAvailableActivity(activities, compareActivityTime, comparator);
        return activities;
    }

    @Override
    public List<Activity> fetchActivitiesByPointTypeAndLoyaltyStruct(String pointType, String structureName) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE, structureName, pointType);
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByLoyaltyStructureAndPointType(structureName, pointType);
            if (!activities.isEmpty()) {
                setValue(key, activities, EXPIRED_TIME);
            }
        }
        return activities;
    }

    @Override
    public Activity findActivityById(String activityId) {
        String key = getKey(KeyEnum.ACTIVITY, activityId);
        Activity activity = getValue(key, Activity.class);
        if (activity != null) {
            return activity;
        }
        List<Activity> activityList = activityRepository.findActivityById(activityId);
        if (!activityList.isEmpty()) {
            activity = activityList.get(0);
            setValue(key, activity, 10 * 60 * 1_000L);
            return activity;
        }
        return null;
    }

    @Override
    public Store getStoreByStoreCode(String storeCode) {
        if (Store.HOT_LINE_ARRIVED_HOME.equals(storeCode)) {
            Store store = new Store();
            store.setId(storeCode);
            store.setStoreType("estore");
            store.setOlayType("A");
            store.setCounterStatus("InUse");
            store.setStoreStatus("Active");
            store.setCreatedTime(LocalDateTime.of(2019, 7, 1, 1, 1));
            store.setBrand("OLAY");
            return store;
        }
        String key = getKey(KeyEnum.DMP_DAILY_COUNTER, storeCode);
        Store store = getValue(key, Store.class);
        if (store != null) {
            return store;
        }
        List<Store> stores = storeRepository.findStoreById(storeCode);
        if (!stores.isEmpty()) {
            store = stores.get(0);
            setValue(key, store, EXPIRED_TIME);
            return store;
        }
        return null;
    }

    @Override
    public void removeActivityPointType(String structureName, String pointType) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE, structureName, pointType);
        memCacheTemplate.remove(key);
        stringRedisTemplate.delete(key);
    }

    @Override
    public Gift getGiftById(String giftId) {
        String key = getKey(KeyEnum.GIFT, giftId);
        Gift gift = getValue(key, Gift.class);
        if (gift != null) {
            return gift;
        }
        List<Gift> giftList = giftRepository.findGiftById(giftId);
        if (!giftList.isEmpty()) {
            gift = giftList.get(0);
            setValue(key, gift, EXPIRED_TIME);
            return gift;
        }
        return null;
    }


    @Override
    public void removeActivityById(String activityId) {
        String key = getKey(KeyEnum.ACTIVITY, activityId);
        memCacheTemplate.remove(key);
        stringRedisTemplate.delete(key);
    }

    @Override
    public void removeGiftById(String giftId) {
        String key = getKey(KeyEnum.GIFT, giftId);
        memCacheTemplate.remove(key);
        stringRedisTemplate.delete(key);
    }

    @Override
    public Integer getIssuedNum(String activityId, String giftId) {
        String key = GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
        // 直接查redis
        String issuedNumStr = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(issuedNumStr)) {
            return Integer.valueOf(issuedNumStr);
        }
        // redis查不到，则查数据库,并将issuedNum回写到redis
        List<Activity> activityList = activityRepository.findActivityById(activityId);
        if (activityList.isEmpty()) {
            throw new SystemException("Can't find activity", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        Activity activity = activityList.get(0);
        Map<String, RedemptionItem> gifts = activity.getGifts();
        Integer issuedNum = null;
        for (String k : gifts.keySet()) {
            if (k.equals(giftId)) {
                RedemptionItem item = gifts.get(k);
                issuedNum = item.getIssuedNum();
                break;
            }
        }
        if (issuedNum == null) {
            throw new SystemException("Can't find related gifts", ResultCodeMapper.ACTIVITY_NOT_FOUND_GIFT);
        }
        stringRedisTemplate.opsForValue().set(key, String.valueOf(issuedNum));
        return issuedNum;
    }

    public Integer getIssuedNumV2(String activityId, String giftId) {
        String key = GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
        String lockKey = LOCK_DIR.concat("-").concat(activityId).concat("-").concat(giftId);
        // 直接查redis
        String issuedNumStr = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(issuedNumStr)) {
            return Integer.valueOf(issuedNumStr);
        }
        Integer issuedNum = null;
        //如果没有gift缓存，查数据库获取
        if (redisLock.tryLock(lockKey, 5, TimeUnit.SECONDS)) {
            // redis查不到，则查数据库,并将issuedNum回写到redis
            List<Activity> activityList = activityRepository.findActivityById(activityId);
            if (activityList.isEmpty()) {
                throw new SystemException("Can't find activity", ResultCodeMapper.ACTIVITY_NOT_FOUND);
            }
            Activity activity = activityList.get(0);
            Map<String, RedemptionItem> gifts = activity.getGifts();

            for (Map.Entry entry : gifts.entrySet()) {
                if (entry.getKey().equals(giftId)) {
                    RedemptionItem value = (RedemptionItem) entry.getValue();
                    issuedNum = value.getIssuedNum();
                    break;
                }
            }
            if (issuedNum == null) {
                throw new SystemException("Can't find related gifts", ResultCodeMapper.ACTIVITY_NOT_FOUND_GIFT);
            }
            stringRedisTemplate.opsForValue().set(key, String.valueOf(issuedNum));
            redisLock.deleteLock(lockKey);
        } else {
            getIssuedNumV2(activityId, giftId);
        }

        return issuedNum;
    }

    @Override
    public void initIssuedNum(String activityId, String giftId) {
        String key = GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
        stringRedisTemplate.opsForValue().set(key, "0");
    }

    @Override
    public void removeIssuedNum(String activityId, String giftId) {
        String key = GIFT_ISSUED_NUM.concat("-").concat(activityId).concat("-").concat(giftId);
        stringRedisTemplate.delete(key);
    }

    @Override
    public <T> PageableResult<T> fetchPageableResult(Integer page, Integer pageSize, String key, Class<T> clazz) {
        // 从redis中查询。获取总数，根据page和perPage获取score范围内得值。
        Long totalSize = stringRedisTemplate.boundZSetOps(key).size();
        if (totalSize != null && totalSize != 0) {
            //为了防止redis在set的时候超时，导致永久存在于内存中, 将零时的值删除
            if (stringRedisTemplate.boundZSetOps(key).remove(TMP_REDIS_SET_VALUE) != 0) {
                totalSize--;
            }
            double start = (double) pageSize * (page - 1);
            double end = (double) (page * pageSize) - 1;
            List<T> tList = new ArrayList<>();
            if (start < totalSize) {
                end = end > (totalSize - 1) ? (totalSize - 1) : end;
                Set<String> values = stringRedisTemplate.boundZSetOps(key).rangeByScore(start, end);
                if (values != null && !values.isEmpty()) {
                    for (String s : new ArrayList<>(values)) {
                        T object = JSON.parseObject(s, clazz);
                        tList.add(object);
                    }
                }
            }
            return new PageableResult<>(totalSize.intValue(), tList);
        }
        return null;
    }

    @Override
    public PageableResult<Transaction> fetchPageableTransactionResult(Integer page, Integer pageSize, String key) {
        // 从redis中查询。获取总数，根据page和perPage获取score范围内得值。
        Long totalSize = stringRedisTemplate.boundZSetOps(key).size();
        if (totalSize != null && totalSize != 0) {
            //为了防止redis在set的时候超时，导致永久存在于内存中, 将零时的值删除
            if (stringRedisTemplate.boundZSetOps(key).remove(TMP_REDIS_SET_VALUE) != 0) {
                totalSize--;
            }
            double start = (double) pageSize * (page - 1);
            double end = (double) (page * pageSize) - 1;
            List<Transaction> tList = new ArrayList<>();
            if (start < totalSize) {
                end = end > (totalSize - 1) ? (totalSize - 1) : end;
                Set<String> values = stringRedisTemplate.boundZSetOps(key).rangeByScore(start, end);
                if (values != null && !values.isEmpty()) {
                    Transaction transaction = null;
                    for (String s : new ArrayList<>(values)) {
                        JSONObject jsonObject = JSON.parseObject(s);
                        String transactionType = jsonObject.getString("transactionType");
                        if (transactionType.equals(TransactionType.REDEMPTION.name())) {
                            transaction = JSON.parseObject(s, Redemption.class);
                        } else if (transactionType.equals(TransactionType.ORDER.name())) {
                            transaction = JSON.parseObject(s, Order.class);
                        } else if (transactionType.equals(TransactionType.INTERACTION.name())) {
                            transaction = JSON.parseObject(s, Interaction.class);
                        }
                        tList.add(transaction);
                    }
                }
            }
            return new PageableResult<>(totalSize.intValue(), tList);
        }
        return null;
    }

    @Override
    public void setPageableValueToRedis(String key, int perPage, List list, Comparator comparator, int exipreSecond) {
        if (list == null || list.isEmpty()) {
            return;
        }
        if (list.size() <= perPage) {
            return;
        }
        if (comparator == null) {
            throw new SystemException("The rule of sort can't be null",
                    ResultCodeMapper.UNEXPECTED_ERROR);
        }
        list.sort(comparator);
        // 保存至redis,设置score，从0开始
        Set<ZSetOperations.TypedTuple<String>> tuples = new HashSet<>();
        double score = 0;
        for (Object object : list) {
            ZSetOperations.TypedTuple<String> objectTypedTuple = new DefaultTypedTuple<>(JSON.toJSONString(object), score);
            tuples.add(objectTypedTuple);
            score++;
        }
        if (!tuples.isEmpty()) {
            try {
                //由于批量插入时，所用时间比较长，会超过redis链接时间，导致key永久存在。所以先设置零时值，操作完成后再删除
                stringRedisTemplate.boundZSetOps(key).add(TMP_REDIS_SET_VALUE, 1000000);
                stringRedisTemplate.expire(key, exipreSecond, TimeUnit.SECONDS);
                stringRedisTemplate.boundZSetOps(key).add(tuples);
            } finally {
                stringRedisTemplate.boundZSetOps(key).remove(TMP_REDIS_SET_VALUE);
                log.info("删除分页的零时值：{}", key);
            }
        }

    }

    @Override
    public void setQrCodeToRedis(String structureName, String qrCode, ValueType valueType) {
        if (StringUtils.isBlank(structureName)) {
            throw new SystemException(ResultCodeMapper.PARAM_ERROR);
        }
        String key = String.format("%s%s:%s", CACHE_QRCODE_PREFIX, structureName, qrCode);
        if (ValueType.TRANSIT.equals(valueType)) {
            key = String.format("%s%s:%s:%s", CACHE_QRCODE_PREFIX, structureName, qrCode, valueType.name());
        }
        stringRedisTemplate.opsForValue().set(key, "true", 90, TimeUnit.DAYS);
    }

    @Override
    public void checkQrCode(String structureName, String qrCode) {
        if (StringUtils.isBlank(structureName)) {
            throw new SystemException(ResultCodeMapper.PARAM_ERROR);
        }
        String key = CACHE_QRCODE_PREFIX.concat(structureName).concat(":").concat(qrCode);
        String value = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(value)) {
            throw new SystemException("This code has been scanned before:" + qrCode,
                    ResultCodeMapper.SCAN_CODE_ERROR);
        }
    }

    @Override
    public void checkQrCode(String structureName, String qrCode, ValueType valueType) {
        if (StringUtils.isBlank(structureName)) {
            throw new SystemException(ResultCodeMapper.PARAM_ERROR);
        }
        String key = String.format("%s%s:%s", CACHE_QRCODE_PREFIX, structureName, qrCode);
        if (ValueType.TRANSIT.equals(valueType)) {
            key = String.format("%s%s:%s:%s", CACHE_QRCODE_PREFIX, structureName, qrCode, valueType);
        }
        String value = stringRedisTemplate.opsForValue().get(key);
        if (StringUtils.isNotEmpty(value)) {
            throw new SystemException("This code has been scanned before:" + qrCode,
                    ResultCodeMapper.SCAN_CODE_ERROR);
        }
    }

    @Override
    public List<Activity> fetchUniqueTemplateAvailableActivities(TransactionType transactionType,
                                                                 String structureName,
                                                                 LocalDateTime compareActivityTime) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE, structureName, transactionType.name());
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByLoyaltyStructureAndTransactionType(structureName, transactionType.name());
            if (CollectionUtils.isEmpty(activities)) {
                log.info("品牌{}没有配置对应的订单活动", structureName);
                return activities;
            }
            setValue(key, activities, EXPIRED_TIME);
        }
        return filterAvailableActivity(activities, compareActivityTime);
    }

    @Override
    public void clearActivities(TransactionType transactionType, String structureName) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE, structureName, transactionType.name());
        memCacheTemplate.remove(key);
        stringRedisTemplate.delete(key);
    }

    @Override
    public List<Activity> fetchUniquePointTypeAvailableActivities(TransactionType transactionType, String structureName,
                                                                  LocalDateTime compareActivityTime) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE_V2, structureName, transactionType.name());
        List<Activity> activities = getValues(key, Activity.class);
        if (activities.isEmpty()) {
            activities = activityRepository.findByLoyaltyStructureAndTransactionType(structureName, transactionType.name());
            if (CollectionUtils.isEmpty(activities)) {
                log.info("品牌{}没有配置对应的订单活动", structureName);
                return activities;
            }
            setValue(key, activities, EXPIRED_TIME);
        }
        return filterAvailableActivityV2(activities, compareActivityTime);
    }

    @Override
    public void clearActivitiesV2(TransactionType transactionType, String structureName) {
        String key = getKey(KeyEnum.ACTIVITY_POINT_TYPE_V2, structureName, transactionType.name());
        memCacheTemplate.remove(key);
        stringRedisTemplate.delete(key);
    }

    /**
     * 筛选每个pointType的有效活动，只取一个
     * 1、活动有效必须在有效期内
     * 2、取优先级最高的活动
     * 3、优先级一样时，取最新的活动
     */
    public List<Activity> filterAvailableActivityV2(List<Activity> activities, LocalDateTime compareTime) {
        List<Activity> filteredActivities = new ArrayList<>();
        if (CollectionUtils.isEmpty(activities)) {
            return filteredActivities;
        }
        Map<String, List<Activity>> filteredActivityMap = activities.stream()
                .filter(item -> item.available(compareTime))
                .sorted(Comparator.comparing(Activity::pointType)
                        .thenComparing(Activity::getPriority, Comparator.reverseOrder())
                        .thenComparing(Activity::getUpdatedTime, Comparator.reverseOrder()))
                .collect(Collectors.groupingBy(Activity::getPointType));
        filteredActivityMap.forEach((k, v) -> filteredActivities.add(v.get(0)));
        return filteredActivities;
    }

    /**
     * 筛选每个模板类型的有效活动，只取一个
     * 1、活动有效必须在有效期内
     * 2、取优先级最高的活动
     * 3、优先级一样时，取最新的活动
     */
    private List<Activity> filterAvailableActivity(List<Activity> activities, LocalDateTime compareTime) {
        Map<RuleTemplate, Activity> map = new EnumMap<>(RuleTemplate.class);
        for (Activity atv : activities) {
            if (!atv.available(compareTime)) {
                continue;
            }
            Activity tempActivity = map.get(atv.getRuleTemplate());
            if (tempActivity == null) {
                map.put(atv.getRuleTemplate(), atv);
                continue;
            }
            if (tempActivity.getPriority() < atv.getPriority()) {
                map.put(atv.getRuleTemplate(), atv);
                continue;
            }
            if (tempActivity.getPriority().equals(atv.getPriority())
                    && tempActivity.getUpdatedTime().isBefore(atv.getUpdatedTime())) {
                map.put(atv.getRuleTemplate(), atv);
            }
        }
        return map.entrySet().parallelStream().map(Map.Entry::getValue).collect(Collectors.toList());
    }


    @Override
    public Long incrementGift(String issuedNumRedisKey, int quantity, int stock) {
        DefaultRedisScript<Long> script = new DefaultRedisScript<>(getIssuedScript(), Long.class);
        List<String> keyList = new ArrayList<>();
        keyList.add(issuedNumRedisKey);
        Long result = (Long) redisTemplate.execute(script, keyList, quantity, stock);
        if (result == null || result < 0) {
            throw new SystemException(GIFT_STOCK_TO_REDEEM_GIFT, ResultCodeMapper.UNDER_STOCK);
        }
        return result;
    }


    /**
     * 返回：-1:key 值不存在
     * -2:库存不够，兑换失败
     * 正数:礼品兑换后库存值
     */
    private String getIssuedScript() {
        return "local quantity = tonumber(ARGV[1])\n" +
                "local stock = tonumber(ARGV[2])\n" +
                "if (not (redis.call('GET', KEYS[1]))) then\n" +
                "    return -1\n" +
                "end\n" +
                "local issuedNum=tonumber(redis.call(\"GET\", KEYS[1]))\n" +
                "if issuedNum > stock - quantity then\n" +
                "    return -2\n" +
                "else\n" +
                "    return redis.call(\"INCRBY\", KEYS[1],quantity)\n" +
                "end";
    }
}
