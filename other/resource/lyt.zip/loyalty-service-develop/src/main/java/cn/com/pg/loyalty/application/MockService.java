package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.interfaces.dto.UpdateMockAccountCommand;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class MockService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private ApplicationContext applicationContext;

    public void updateAccountById(String loyaltyId, UpdateMockAccountCommand updateMockAccountCommand) {
        checkEnvironment();
        String accountPartitionKey = PartitionKeyUtils.getAccountPartitionKey(loyaltyId);
        List<Account> accountList = accountRepository.findByPartitionKeyAndId(accountPartitionKey, loyaltyId);
        if(CollectionUtils.isEmpty(accountList)){
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        Integer pointAboutExpire = updateMockAccountCommand.getPointAboutExpire();
        String pointAboutExpiredDate = updateMockAccountCommand.getPointAboutExpiredDate();
        OffsetDateTime tierExpiredTime = updateMockAccountCommand.getTierExpiredTime();
        Account account = accountList.get(0);
        if(Objects.nonNull(pointAboutExpire)){
            account.pointAboutExpire(updateMockAccountCommand.getBrand(), pointAboutExpire);
        }
        if(StringUtils.isNotEmpty(pointAboutExpiredDate)){
            account.pointAboutExpiredDate(updateMockAccountCommand.getBrand(),
                    LoyaltyDateTimeUtils.stringToLocalDate(pointAboutExpiredDate));
        }
        if(Objects.nonNull(tierExpiredTime)){
            LoyaltyStructure loyaltyStructure =
                    cacheService.findLoyaltyStructure(updateMockAccountCommand.getRegion(),
                            updateMockAccountCommand.getBrand());
            account.updateTierExpiredTime(loyaltyStructure,
                    LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(tierExpiredTime));
        }
        accountRepository.save(account);

    }

    private void checkEnvironment() {
        String[] activeProfiles = applicationContext.getEnvironment().getActiveProfiles();
        if(CollectionUtils.containsAny(Arrays.asList(activeProfiles), "prd", "prod", "cne2_prod")) {
            throw new SystemException("error environment!", ResultCodeMapper.PARAM_ERROR);
        }
    }
}
