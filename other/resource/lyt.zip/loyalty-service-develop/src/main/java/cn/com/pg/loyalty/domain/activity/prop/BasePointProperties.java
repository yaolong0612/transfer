package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-06 12:00
 */

@Getter
@Setter
public class BasePointProperties extends RuleProperties {

    /**
     * 赠送积分倍数 1倍
     */
    @Min(0)
    private int bonusPointMultiple;
    /**
     * 是否参与竞争
     */
    private boolean competition;

}
