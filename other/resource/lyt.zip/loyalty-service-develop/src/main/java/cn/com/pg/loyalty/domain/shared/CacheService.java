package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityStatus;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * cache service
 */
public interface CacheService {

    PointType validatePointType(String pointType, String structureName, TransactionType interaction);

    void validatePointType(String pointType, String structureName);

    void removeLoyaltyStructureCache();

    LoyaltyStructure findLoyaltyStructureById(String name);

    LoyaltyStructure findLoyaltyStructure(Account account);

    LoyaltyStructure findLoyaltyStructure(String region, String brand);

    Long incrementGift(String issuedNumRedisKey, int quantity, int stock);


    enum KeyEnum {
        /**
         * 缓存Activity前缀
         */
        ACTIVITY,
        /**
         * C360 id 前缀
         */
        C360,
        /**
         * 缓存gift前缀
         */
        GIFT,
        /**
         *
         */
        ACTIVITY_POINT_TYPE,

        ACTIVITY_POINT_TYPE_V2,
        /**
         *
         */
        POINT_TYPE,
        POINT_TYPE_LIST,
        /**
         * 缓存前缀
         */
        REDEMPTION,
        /**
         * 缓存Counter前缀
         */
        DMP_DAILY_COUNTER,
        /**
         * 缓存正常订单加积分前缀
         */
        NORMAL_ORDER,
        /**
         * 缓存退单扣减积分前缀
         */
        REFUND_ORDER,
        /**
         * 缓存客户端调整订单加积分前缀
         */
        ADJUST_ORDER_POINT,
        /**
         * 缓存一般订单加积分前缀
         */
        COMMON_ORDER_POINT,

        FIND_POINT_HISTORY,
        /**
         * 数据聚合运算
         */
        PERSISTENT_AGGREGATION_REDEMPTION,
        /**
         * 事件
         */
        EVENT_HANDLE,

        /**
         * 幂等
         */
        IDEMPOTENT,
        /**
         * MEMBER LOCKED
         */
        ACCOUNT_LOCK,
        CONFIG,

        /**
         * 回滚订单前缀
         */
        ROLLBACK_ORDER,
        /**
         * accountGap前缀
         */
        ACCOUNT_GAP;
    }

    /**
     * @param keyEnum
     * @param key
     * @return
     */
    default String getKey(KeyEnum keyEnum, String... key) {
        StringBuilder sb = new StringBuilder(keyEnum.name());
        for (String keyStr : key) {
            sb.append(":").append(keyStr);
        }
        return sb.toString();
    }

    /**
     * 设置缓存值
     *
     * @param key
     * @param value
     * @param millisExpireTime 过期时间 TimeUnit.MILLISECONDS
     *                         负数则不过期
     */
    void setValue(String key, Object value, long millisExpireTime);

    boolean lockedUpCompetition(String lockArea, long millisExpireTime);

    void setValueToMemory(String key, Object value);

    void deleteKey(String key);

    void delActivityRedisKey(String activityId);

    void delGiftRedisKey(String giftId);

    /**
     * 获取缓存值
     *
     * @param key
     * @param clazz
     * @param <T>
     * @return
     */
    <T> T getValue(String key, Class<T> clazz);

    /**
     * 获取缓存值
     *
     * @param key
     * @param clazz
     * @param <T>
     * @return
     */
    <T> List<T> getValues(String key, Class<T> clazz);

    /**
     * 根据活动类型获取活动
     *
     * @param transactionType
     * @return
     */
    List<Activity> getActivities(TransactionType transactionType);

    Optional<PointType> findByPointTypeAndLoyaltyStructureAndTransactionType(String pointType, String structureName, TransactionType transactionType);

    /**
     * 根据条件过滤活动
     *
     * @param activities
     * @param structureName
     * @param brand
     * @param name
     * @param status           ACTIVATE INITIAL null; 如果传null
     * @param startAt
     * @param endAt
     * @param comparator
     * @return
     */
    List<Activity> filterActivity(List<Activity> activities, String structureName, String brand, String name, ActivityStatus status, LocalDateTime startAt, LocalDateTime endAt, Comparator<Activity> comparator);

    /**
     * @param page
     * @param pageSize
     * @param totalElements
     * @param comparator
     * @param <T>
     * @return
     */
    <T> PageableResult<T> generatePage(Integer page, Integer pageSize, List<T> totalElements, Comparator<T> comparator);

    List<Activity> filterAvailableActivity(List<Activity> activities, LocalDateTime compareTime, Comparator<Activity> comparator);

    String fetchLoyaltyId(String marketingProgramId, String memberId);

    void cacheMemberIdLoyaltyIdMapping(String marketingProgramId,
                                       String memberId, String loyaltyId);

    List<Activity> fetchAvailableActivitiesByRuleTemplateInOrder(RuleTemplate ruleTemplate);

    List<Activity> fetchAvailableActivitiesByRuleTemplateAndBrandInOrder(RuleTemplate ruleTemplate, String brand);

    /**
     * 根据多倍积分规则查找Activity
     *
     * @param pointType
     * @param structureName
     * @return
     */
    List<Activity> fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(String pointType, String structureName);

    List<Activity> fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(String pointType, String structureName, LocalDateTime compareActivityTime);

    /**
     * 根据ruleTemplate过滤
     * @param transactionType
     * @param structureName
     * @param compareActivityTime
     * @return
     */
    List<Activity> fetchUniqueTemplateAvailableActivities(TransactionType transactionType, String structureName, LocalDateTime compareActivityTime);

    void clearActivities(TransactionType transactionType,String structureName);


    /**
     * 根据pointType过滤
     * @param transactionType
     * @param structureName
     * @param compareActivityTime
     * @return
     */
    List<Activity> fetchUniquePointTypeAvailableActivities(TransactionType transactionType, String structureName,
                                                           LocalDateTime compareActivityTime);

    void clearActivitiesV2(TransactionType transactionType,String structureName);


    List<Activity> fetchActivitiesByPointTypeAndLoyaltyStruct(String pointType, String structureName);

    /**
     * 根据activityId查询活动
     *
     * @param activityId
     * @return
     */
    Activity findActivityById(String activityId);

    /**
     * 根据storeCode查询DmpDailyCounter信息
     *
     * @param storeCode
     * @return
     */
    Store getStoreByStoreCode(String storeCode);

    /**
     * 移除pointType
     *
     * @param pointType
     */
    void removeActivityPointType(String structureName, String pointType);

    /**
     * 根据id移除活动
     *
     * @param activityId
     */
    void removeActivityById(String activityId);

    /**
     * 根据id获取礼品
     *
     * @param giftId
     * @return
     */
    Gift getGiftById(String giftId);

    /**
     * 根据id移除礼品
     *
     * @param giftId
     */
    void removeGiftById(String giftId);

    /**
     * 根据活动id和礼品id获取已兑换礼品的数量
     *
     * @param activityId
     * @param giftId
     * @return
     */
    Integer getIssuedNum(String activityId, String giftId);
    /**
     * 根据活动id和礼品id获取已兑换礼品的数量
     * 增加互斥锁，避免缓存击穿
     * @param activityId
     * @param giftId
     * @return
     */
    Integer getIssuedNumV2(String activityId, String giftId);

    /**
     * 初始化issuedNum为0
     *
     * @param activityId
     * @param giftId
     */
    void initIssuedNum(String activityId, String giftId);

    /**
     * 礼品如果从活动中移除或活动被删除，则移除IssuedNum
     *
     * @param activityId
     * @param giftId
     */
    void removeIssuedNum(String activityId, String giftId);

    /**
     * 根据redis中的key获取对应的所有兑换历史记录，并根据 page和pageSize过滤记录
     *
     * @param page
     * @param pageSize
     * @param key
     * @return
     */
    <T> PageableResult<T> fetchPageableResult(Integer page, Integer pageSize, String key, Class<T> clazz);

    PageableResult<Transaction> fetchPageableTransactionResult(Integer page, Integer pageSize, String key);

    /**
     * 将兑换的历史记录缓存到redis
     *
     * @param key
     * @param
     * @param perPage
     * @param list
     * @param comparator
     * @param exipreSecond
     */
    void setPageableValueToRedis(String key, int perPage, List list, Comparator comparator, int exipreSecond);

    /**
     * 缓存qrcode进redis，缓存90天
     * redis存储key格式:  CACHE_QRCODE_PREFIX:structureName:pointType:qrcode:valueType

     */
    void setQrCodeToRedis(String structureName, String qrCode, ValueType valueType);

    /**
     * 检查qrcode是否已经扫过
     *
     * @param structureName
     * @param qrCode
     * @return
     */
    void checkQrCode(String structureName, String qrCode);

    void checkQrCode(String structureName, String qrCode, ValueType valueType);
}
