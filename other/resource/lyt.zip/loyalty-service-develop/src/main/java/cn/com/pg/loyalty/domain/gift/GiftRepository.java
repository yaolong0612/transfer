package cn.com.pg.loyalty.domain.gift;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author: Ysnow
 * @Date: 2019/4/29 15:16
 * @Description:
 */
@Repository
public interface GiftRepository extends DocumentDbRepository<Gift,String> {

    /**
     * * 查询礼品列表
     * @param name
     * @param loyaltyStructure
     * @return
     */
    List<Gift> findByNameIsStartingWithAndLoyaltyStructure(String name, String loyaltyStructure);

    /**
     * 根据积分体系获取
     * @param loyaltyStructure
     * @return
     */
    List<Gift> findByLoyaltyStructure(String loyaltyStructure);

    /**
     * 通过ID查找gift
     * @param id
     * @return
     */
    List<Gift> findGiftById(String id);

    List<Gift> findByBagSkuAndLoyaltyStructure(String bagSku, String loyaltyStructure);

    /**
     * 根据id半模糊查询。礼品id如201908查询201908_1500A，201908_1500B
     * @param giftId
     * @return
     */
    List<Gift> findByIdStartsWithAndLoyaltyStructure(String giftId, String loyaltyStructure);

    List<Gift> findByIdStartsWithAndNameStartsWithAndLoyaltyStructure(String giftId, String name, String loyaltyStructure);

    @Override
    Gift save(Gift gift);
}
