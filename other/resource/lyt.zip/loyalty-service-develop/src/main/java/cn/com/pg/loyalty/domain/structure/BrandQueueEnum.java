package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Optional;


@NoArgsConstructor
@AllArgsConstructor
@Getter
public enum BrandQueueEnum {

    SKII_NORMAL_ORDER(BrandV2.SKII, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_SKII_ORDER_QUEUE_NAME),
    SKII_REFUND_ORDER(BrandV2.SKII, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_SKII_ORDER_QUEUE_NAME),

    OLAY_NORMAL_ORDER(BrandV2.OLAY, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_OLAY_QUEUE_NAME),
    OLAY_REFUND_ORDER(BrandV2.OLAY, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_OLAY_REFUND_QUEUE_NAME),

    /**
     * 以下品牌都是用相同的queue
     */

    OPTE_NORMAL_ORDER(BrandV2.OPTE, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    OPTE_REFUND_ORDER(BrandV2.OPTE, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_REFUND_ORDER),

    BRAUN_NORMAL_ORDER(BrandV2.BRAUN, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    BRAUN_REFUND_ORDER(BrandV2.BRAUN, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_REFUND_ORDER),

    GILLETTE_NORMAL_ORDER(BrandV2.GILLETTE, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    GILLETTE_REFUND_ORDER(BrandV2.GILLETTE, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_REFUND_ORDER),

    ORALB_NORMAL_ORDER(BrandV2.ORALB, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    ORALB_REFUND_ORDER(BrandV2.ORALB, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_REFUND_ORDER),


    PAMPERS_NORMAL_ORDER(BrandV2.PAMPERS, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    PAMPERS_REFUND_ORDER(BrandV2.PAMPERS, OrderTypeEnum.REFUND_ORDER, ServiceBusBinder.Q_REFUND_ORDER),

    LA_NORMAL_ORDER(BrandV2.LA, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_NORMAL_ORDER),
    LA_REFUND_ORDER(BrandV2.LA, OrderTypeEnum.NORMAL_ORDER, ServiceBusBinder.Q_REFUND_ORDER);


    private String brand;
    private OrderTypeEnum orderTypeEnum;
    private ServiceBusBinder serviceBusBinder;

    public static ServiceBusBinder getQueue(String brand, OrderTypeEnum orderTypeEnum) {

        Optional<BrandQueueEnum> optional = Arrays.stream(BrandQueueEnum.values())
                .filter(brandQueue -> (brand.equals(brandQueue.getBrand()) && orderTypeEnum.equals(brandQueue.orderTypeEnum))).findFirst();
        if (!optional.isPresent()) {
            throw new SystemException("The brand not config queue binder", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return optional.get().serviceBusBinder;
    }


    public enum OrderTypeEnum {
        /**
         * 正常订单
         */
        NORMAL_ORDER("010"),

        REFUND_ORDER("020");

        private String value;

        OrderTypeEnum(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }
    }

}
