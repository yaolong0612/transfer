package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author LMR
 */
@Data
@NoArgsConstructor
public class RedemptionGroupsProperties implements CommonProperties {

    private Set<RedemptionGroupsProperties.GiftGroup> groups = new TreeSet<>();

    public void addGroup(GiftGroup group) {
        groups.add(group);
    }

    public boolean isEmpty() {
        return this.groups.isEmpty();
    }

    @Override
    public boolean checkMutex(Map<String, RedemptionItem> redemptionItemMap,
                              List<GiftItem> giftItemList,
                              List<GiftItem> historyGiftItemList) {
        ArrayList<GiftItem> giftItems = new ArrayList<>(giftItemList);
        giftItems.addAll(historyGiftItemList);
        // 组级别直接获取当前兑换的礼品和已兑换礼品的组名
        Set<String> nameSet = giftItems.stream()
                .map(giftItem -> this.fetchName(redemptionItemMap, giftItem))
                .filter(StringUtils::isNotEmpty).collect(Collectors.toSet());
        return nameSet.size() > 1;
    }

    @Override
    public boolean fetchMutex(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGroup giftGroup = fetchGiftGroup(redemptionItemMap, giftItem);
        if (giftGroup == null) {
            return false;
        }
        return giftGroup.isMutex();
    }

    @Override
    public boolean checkGroupStatus(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGroup giftGroup = fetchGiftGroup(redemptionItemMap, giftItem);
        if (giftGroup == null) {
            return false;
        }
        return giftGroup.isGroupMember();
    }


    @Override
    public boolean checkJoinEnterpriseWechatForBC(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGroup giftGroup = fetchGiftGroup(redemptionItemMap, giftItem);
        if (giftGroup == null) {
            return false;
        }
        return giftGroup.isJoinEnterpriseWechatForBC();
    }

    @Override
    public RuleLable fetchLable() {
        return RuleLable.GROUP;
    }

    @Override
    public CommonProperties fetchNext() {
        RedemptionGradesProperties redemptionGradesProperties = new RedemptionGradesProperties();
        this.groups.forEach(group -> group.getGrades().forEach(grade -> {
            grade.setGroupName(group.getName());
            redemptionGradesProperties.addGrade(grade);
        }));
        if (redemptionGradesProperties.isEmpty()) {
            return null;
        }
        return redemptionGradesProperties;
    }

    @Override
    public int fetchTotalLimitQuantity(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGroup giftGroup = fetchGiftGroup(redemptionItemMap, giftItem);
        if (giftGroup == null) {
            return 0;
        }
        return giftGroup.getTotalLimitQuantity();
    }

    @Override
    public PurchaseLimit fetchPurchaseLimit(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        GiftGroup giftGroup = fetchGiftGroup(redemptionItemMap, giftItem);
        if (giftGroup == null) {
            return null;
        }
        return giftGroup.getPurchaseLimit();
    }

    private GiftGroup fetchGiftGroup(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        String name = this.fetchName(redemptionItemMap, giftItem);
        if (StringUtils.isEmpty(name)) {
            return null;
        }
        return this.groups.stream()
                .filter(group -> group.getName().equals(name))
                .findFirst().orElse(null);
    }

    @Data
    @NoArgsConstructor
    public static class GiftGroup implements Comparable<GiftGroup> {
        // 组名
        private String name;
        // 组间互斥
        private boolean mutex;
        // 是否入群
        private boolean groupMember;
        // 是否加入BC企业微信
        private boolean joinEnterpriseWechatForBC;
        // 限制一个组的礼品允许兑换的数量
        private int totalLimitQuantity;
        // 购买次数限制
        private PurchaseLimit purchaseLimit;
        // 挡位配置
        private Set<RedemptionGradesProperties.GiftGrade> grades = new TreeSet<>();

        @Override
        public int compareTo(GiftGroup group) {
            return this.name.compareTo(group.name);
        }
    }
}
