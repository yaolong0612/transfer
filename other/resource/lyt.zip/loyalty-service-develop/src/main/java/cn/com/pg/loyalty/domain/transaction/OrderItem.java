package cn.com.pg.loyalty.domain.transaction;


import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.util.Optional;

/**
 * @author Young
 * @date 2019年4月11日上午11:00:56
 * @description 一笔Order中的具体商品信息
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class OrderItem implements ValueObject<OrderItem> {
    /**
     *
     */
    private static final long serialVersionUID = -3469577776626119132L;
    /**
     * 商品编号
     */
    private String sku;
    /**
     * 剩余购买数量，没有发生退单时那么就是消费购买时的数量
     */
    private Integer purchaseQty;
    /**
     * 退的数量
     */
    private Integer refundQty = 0;
    /**
     * 商品单价
     */
    private Double retailAmount;
    /**
     * 该商品实付金额
     */
    private Double realAmount;
    /**
     * 总的退款金额
     */
    private Double refundAmount = 0.0;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        OrderItem orderItem = (OrderItem) o;

        return new EqualsBuilder()
                .append(retailAmount, orderItem.retailAmount)
                .append(realAmount, orderItem.realAmount)
                .append(sku, orderItem.sku)
                .append(purchaseQty, orderItem.purchaseQty)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(sku)
                .append(purchaseQty)
                .append(retailAmount)
                .append(realAmount)
                .toHashCode();
    }

    @Override
    public boolean sameValueAs(final OrderItem other) {
        return other != null && this.equals(other);
    }

    /**
     * 返回单品的实付金额
     *
     * @return
     */
    public double realAmount() {
        //RealAmount是单品的实付金额，不需要再乘以数量
        return Optional.ofNullable(this.realAmount).orElse(0.0);
    }

    /**
     * 计算退单后的orderItem
     *
     * @param refundQty
     * @param realAmount
     */
    public void refund(int refundQty, double realAmount) {
        this.purchaseQty = this.purchaseQty - refundQty;
        this.realAmount = this.realAmount - realAmount;
        //realAmount是单品实付价格
        this.refundAmount = this.refundAmount + realAmount;
        this.refundQty = this.refundQty + refundQty;
    }

    public static OrderItem getNormalOrderItem(String sku, Integer purchaseQty, Double retailAmount, Double realAmount) {
        OrderItem orderItem = new OrderItem();
        orderItem.setSku(sku);
        orderItem.setPurchaseQty(purchaseQty);
        orderItem.setRetailAmount(retailAmount);
        orderItem.setRealAmount(realAmount);
        return orderItem;
    }
}
