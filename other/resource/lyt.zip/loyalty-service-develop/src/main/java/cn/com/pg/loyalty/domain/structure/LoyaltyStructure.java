package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics.SubAccountType;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@Document(collection = "Structure", ru = "400")
public class LoyaltyStructure {

    @Id
    @PartitionKey
    private String name;
    private List<String> brands;
    private String region;
    private String marketingProgramId;
    private String amTenantId;
    private PointExpire pointExpire;
    private boolean openExtraSubAccount;
    private ExtraSubAccountTactics extraSubAccountTactics;
    private ExchangeRate amountRate;
    private TierLevelSeries tierLevelSeries;
    private OrderImpact orderImpact;
    private String createdBy;
    /**
     * 订单积分锁定时长（天）
     */
    private int orderLockDuration;
    /**
     * 交互积分锁定时长（天）
     */
    private int interactLockDuration;

    /**
     * 积分体系为 核心规则，修改时要十分小心
     *
     * @param builder
     */
    private LoyaltyStructure(Builder builder) {
        this.name = builder.name;
        this.brands = builder.brands;
        this.region = builder.region;
        this.marketingProgramId = builder.marketingProgramId;
        this.amTenantId = builder.amTenantId;
        this.amountRate = builder.amountRate;
        this.pointExpire = builder.pointExpire;
        this.tierLevelSeries = builder.tierLevelSeries;
        this.orderImpact = builder.orderImpact;
        this.extraSubAccountTactics = builder.extraTactics;
        this.openExtraSubAccount = builder.openExtraSubAccount;
        this.createdBy = builder.createdBy;
        this.orderLockDuration = builder.orderLockDuration;
        this.interactLockDuration = builder.interactLockDuration;
    }

    /**
     * 获取积分过期配置: 默认账户配置
     */
    public PointExpire pointExpire() {
        return pointExpire(ValueType.DEFAULT);
    }

    /**
     * 获取积分过期配置：根据积分种类，子账户扩展策略返回
     */
    public PointExpire pointExpire(ValueType valueType) {
        if (subAccountType(valueType).callExtraSubAccount()) {
            return extraSubAccountTactics().getPointExpire();
        }
        return this.pointExpire;
    }

    /**
     * 获取积分过期配置：根据transaction 积分种类判定
     */
    public PointExpire pointExpire(Transaction transaction) {
        ValueType valueType = transaction.valueType(this);
        if (subAccountType(valueType).callExtraSubAccount()) {
            return extraSubAccountTactics().getPointExpire();
        }
        return this.pointExpire;
    }

    /**
     * 默认返回default 账户
     */
    public SubAccountType subAccountType(ValueType valueType) {
        return this.extraSubAccountTactics().getExtraTactics().subAccountType(valueType);
    }

    /**
     * 获取正 （非过渡）积分账户
     */
    public SubAccountType accountTypeOfDefault() {
        return this.extraSubAccountTactics().getExtraTactics().subAccountType(ValueType.DEFAULT);
    }

    public SubAccountType subAccountType(Transaction transaction) {
        return this.subAccountType(transaction.valueType(this));
    }

    private ExtraSubAccountTactics extraSubAccountTactics() {
        if (!openExtraSubAccount) {
            return ExtraSubAccountTactics.createDefault();
        }
        return this.extraSubAccountTactics;
    }

    public ExchangeRate amountRate() {
        return this.amountRate;
    }

    public TierLevelSeries tierLevelSeries() {
        return tierLevelSeries;
    }

    public List<String> brands() {
        return this.brands;
    }

    public String name() {
        return this.name;
    }

    public String marketingProgramId() {
        return this.marketingProgramId;
    }

    /**
     * 积分体系添加brand
     */
    public void addBrand(String brand) {
        this.brands.add(brand);
    }

    /**
     * 判断是否包含
     */
    public boolean contain(String region, String brand) {
        return this.region.equals(region) && this.brands.contains(brand);
    }

    public boolean checkMlBrand(String brand) {
        return contain("ML", brand);
    }

    public boolean checkTwBrand(String brand) {
        return contain("TW", brand);
    }

    public boolean checkHkBrand(String brand) {
        return contain("HK", brand);
    }


    public static Builder builder(String name, String region, List<String> brands,
                                  String marketingProgramId, String amTenantId) {
        return new Builder(name, region, brands, marketingProgramId, amTenantId);
    }

    public void updateMessage(LoyaltyStructure outerLoyaltyStructure) {
        this.brands = outerLoyaltyStructure.getBrands();
        this.pointExpire = outerLoyaltyStructure.getPointExpire();
        this.amountRate = outerLoyaltyStructure.amountRate();
        this.amTenantId = outerLoyaltyStructure.getAmTenantId();
    }

    public LocalDate getUnlockTime(Transaction transaction) {
        //目前过渡积分无锁定积分需求，后期如果有类似需求，可以在ExtraSubAccountTactics 中扩展
        if (ValueType.TRANSIT == transaction.valueType(this)) {
            return null;
        }

        if (TransactionType.ORDER == transaction.getTransactionType() && orderLockDuration > 0) {
            Order order = (Order) transaction;
            return order.getOrderDateTime().plusDays(this.orderLockDuration).toLocalDate();
        }

        if (TransactionType.INTERACTION == transaction.getTransactionType() && interactLockDuration > 0) {
            return transaction.getCreatedTime().plusDays(this.interactLockDuration).toLocalDate();
        }
        return null;
    }

    public boolean noLockTime() {
        return orderLockDuration == 0 && interactLockDuration == 0;
    }

    public static final class Builder {
        private String name;
        private List<String> brands;
        private String region;
        private String marketingProgramId;
        private String amTenantId;
        private PointExpire pointExpire;
        private boolean openExtraSubAccount;
        private ExtraSubAccountTactics extraTactics;
        private ExchangeRate amountRate;
        private TierLevelSeries tierLevelSeries;
        private OrderImpact orderImpact;
        private String createdBy;
        private int orderLockDuration;
        private int interactLockDuration;

        public Builder(String name, String region, List<String> brands,
                       String marketingProgramId, String amTenantId) {
            this.name = name;
            this.brands = brands;
            this.region = region;
            this.marketingProgramId = marketingProgramId;
            this.amTenantId = amTenantId;
        }

        public Builder pointExpire(PointExpire pointExpire) {
            this.pointExpire = pointExpire;
            return this;
        }

        public Builder extraTactics(boolean openExtraSubAccount, ExtraSubAccountTactics extraTactics) {
            this.openExtraSubAccount = openExtraSubAccount;
            if (openExtraSubAccount) {
                this.extraTactics = extraTactics;
            }
            return this;
        }

        public Builder amountRate(ExchangeRate amountRate) {
            this.amountRate = amountRate;
            return this;
        }

        public Builder tierLevelSeries(TierLevelSeries tierLevelSeries) {
            this.tierLevelSeries = tierLevelSeries;
            return this;
        }

        public Builder orderImpact(OrderImpact orderImpact) {
            this.orderImpact = orderImpact;
            return this;
        }

        public Builder createdBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }

        public Builder orderLockDuration(int orderLockDuration) {
            this.orderLockDuration = orderLockDuration;
            return this;
        }

        public Builder interactLockDuration(int interactLockDuration) {
            this.interactLockDuration = interactLockDuration;
            return this;
        }

        public LoyaltyStructure build() {
            return new LoyaltyStructure(this);
        }
    }

}
