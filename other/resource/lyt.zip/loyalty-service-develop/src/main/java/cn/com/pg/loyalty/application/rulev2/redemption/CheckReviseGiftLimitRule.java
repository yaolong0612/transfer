package cn.com.pg.loyalty.application.rulev2.redemption;


import cn.com.pg.loyalty.application.GiftService;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 开放礼品管理: 根据礼品兑换配置，折扣，重置兑换礼品信息，积分，再进行规则校验
 * 由于一些规则对兑换积分有依赖，需要保证其最优先计算:priority 越小越优先
 */
@Slf4j
@Rule(name = "礼品规则限制",
        description = "校验礼品限制:最高优先级,校验礼品设置以及可用积分", priority = Integer.MIN_VALUE+1)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
@Component
public class CheckReviseGiftLimitRule {

    @Autowired
    private GiftService giftService;


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        return ruleProperties.isReductionInventory();
    }

    @Action
    public void executeRule(
            @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
            @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITY) Activity activity,
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties,
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords) {

        checkGiftLimit(structure, account, redemption, activity, redemptionRecords);

        Map<String, Gift> giftMap = redemption.getGiftItemList().stream()
                .map(giftItem -> giftService.checkLoadGift(giftItem.getGiftId()))
                .collect(Collectors.toMap(Gift::getId, Function.identity()));
        //获取折扣
        double discount = getDiscount(structure, account, ruleProperties);
        //重新设置礼品，计算积分
        redemption.reviseGiftItemsAndPoint(giftMap, activity, discount);
        if (account.availablePoint(structure.subAccountType(redemption)) < redemption.point()) {
            throw new SystemException("Not enough points are available for conversion", ResultCodeMapper.NOT_ENOUGH_POINT_ERROR);
        }


    }

    private double getDiscount(LoyaltyStructure structure, Account account, RedemptionProperties ruleProperties) {
        double discount = 1.0;
        if (MapUtils.isNotEmpty(ruleProperties.getRedemptionTierDiscount())) {
            Tier tier = account.tier(structure.name());
            discount = ruleProperties.getRedemptionTierDiscount().getOrDefault(tier.getLevel(), 1.0);
        }
        return discount;
    }

    private void checkGiftLimit(LoyaltyStructure structure, Account account, Redemption redemption, Activity activity, List<Redemption> redemptionRecords) {
        Map<String, Integer> giftRedemptionNumMap = redemptionRecords.stream()
                .map(Redemption::getGiftItemList).flatMap(Collection::stream)
                .filter(GiftItem::effective)
                .collect(Collectors.groupingBy(GiftItem::getGiftId, Collectors.summingInt(GiftItem::getQuantity)));

        redemption.getGiftItemList().forEach(giftItem -> {
            RedemptionItem redemptionItem = getRedemptionItem(activity, giftItem);
            checkTier(activity, account, structure, redemptionItem);
            checkQuantityLimit(giftRedemptionNumMap, giftItem, redemptionItem);
        });
    }

    private void checkQuantityLimit(Map<String, Integer> giftRedemptionNumMap, GiftItem giftItem, RedemptionItem
            redemptionItem) {
        int hasRedemptionNum = giftRedemptionNumMap.getOrDefault(giftItem.getGiftId(), 0);
        int redemptionNum = giftItem.getQuantity();
        if (redemptionItem.getLimitQuantity() <= 0) {
            return;
        }
        if (hasRedemptionNum + redemptionNum > redemptionItem.getLimitQuantity()) {
            throw new SystemException("The gifts you redeem exceed the maximum limit of the event", ResultCodeMapper.LIMIT_ERROR);
        }
    }

    private void checkTier(Activity activity, Account account, LoyaltyStructure structure, RedemptionItem
            redemptionItem) {
        Tier tier = account.tier(activity.getLoyaltyStructure());
        String tierLevel = tier.getLevel();
        if (structure.tierLevelSeries().compare(tierLevel, redemptionItem.getTierLevel()) < 0) {
            throw new SystemException("You do not have enough tierLevel to redeem a premium gift", ResultCodeMapper.LOW_TIER_LEVEL_ERROR);
        }
    }

    private RedemptionItem getRedemptionItem(Activity activity, GiftItem giftItem) {
        return Optional.ofNullable(activity.getGifts().get(giftItem.getGiftId()))
                .orElseThrow(() -> {
                    String errorMsg = "Activity can not get giftId[" + giftItem.getGiftId() + "]corresponding gift";
                    return new SystemException(errorMsg, ResultCodeMapper.PARAM_ERROR);
                });
    }
}
