package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Objects;

/**
 * @author linbj
 * @date 2020/8/11 15:06
 */
@Slf4j
@Service
public class AccountValidateService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private CacheService cacheService;

    public Account validate(LoyaltyStructure loyaltyStructure, String memberId) {

        Account account = fetchAccountByMemberId(loyaltyStructure, memberId);
        if (Objects.isNull(account)) {
            throw new SystemException(ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        account.checkAccountAvailable(loyaltyStructure);
        return account;
    }

    private Account fetchAccountByMemberId(LoyaltyStructure loyaltyStructure, String memberId) {
        String loyaltyId = UUIDUtil.getLoyaltyId(memberId, loyaltyStructure);
        if (StringUtils.isEmpty(loyaltyId)) {
            log.info("从Redis中获取Loyalty Id，Loyalty Structure: {} memberId", loyaltyStructure, memberId);
            loyaltyId = cacheService.fetchLoyaltyId(loyaltyStructure.marketingProgramId(), memberId);
        }
        Account account;
        long startTime = System.currentTimeMillis();
        if (StringUtils.isEmpty(loyaltyId)) {
            log.warn("缓存中无法获取到Loyalty Id,memberId: {}, Loyalty structure: {}", memberId, loyaltyStructure);
            account = getAccountByMemberId(loyaltyStructure, memberId);
            if (!Objects.isNull(account)) {
                //把mapping缓存到redis
                cacheService.cacheMemberIdLoyaltyIdMapping(loyaltyStructure.marketingProgramId(), memberId,
                        account.loyaltyId());
            }
            log.info("findByMemberIdAndMarketingProgramId-costTime: {}ms", System.currentTimeMillis() - startTime);
            return account;
        }
        account = fetchAccountByLoyaltyId(loyaltyId);
        log.info("findByPartitionKeyAndId-costTime: {}ms", System.currentTimeMillis() - startTime);
        return account;
    }

    private Account getAccountByMemberId(LoyaltyStructure loyaltyStructure, String memberId) {
        return CollectionUtils.lastElement(accountRepository.findByMemberIdAndMarketingProgramId(memberId,
                loyaltyStructure.marketingProgramId()));
    }

    private Account fetchAccountByLoyaltyId(String loyaltyId) {
        String partitionKey = PartitionKeyUtils.getAccountPartitionKey(loyaltyId);
        List<Account> accounts = accountRepository.findByPartitionKeyAndId(partitionKey, loyaltyId);
        return CollectionUtils.lastElement(accounts);
    }
}
