package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;
import java.util.List;

@Document(collection = "Log", ru = "400")
@Getter
@Setter
@ToString
@Slf4j
@NoArgsConstructor
public class Log {
    @Id
    private String id;
    @PartitionKey
    private String loyaltyId;
    private String transactionId;
    private Account account;
    private Transaction transaction;
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;
    /**
     * 账户更新时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime registryTime;
    private String correlationId;
    private String targetMemberId;
    private String sourceMemberId;
    private List<String> reqParam;

    public Log(Transaction transaction, String correlationId,
               String targetMemberId, String sourceMemberId, List<String> reqParam, LocalDateTime registryTime) {
        this.transaction = transaction;
        this.transactionId = transaction.getId();
        this.id = UUIDUtil.generator();
        this.createdTime = LocalDateTime.now();
        this.loyaltyId = transaction.getLoyaltyId();
        this.updatedTime = LocalDateTime.now();
        this.correlationId = correlationId;
        this.targetMemberId = targetMemberId;
        this.sourceMemberId = sourceMemberId;
        this.reqParam = reqParam;
        this.registryTime = registryTime;
    }

    public Log(Account account, String correlationId, String targetMemberId,
               String sourceMemberId, List<String> reqParam, LocalDateTime registryTime) {
        this.account = account;
        this.id = UUIDUtil.generator();
        this.createdTime = LocalDateTime.now();
        this.loyaltyId = account.getId();
        this.updatedTime = LocalDateTime.now();
        this.correlationId = correlationId;
        this.targetMemberId = targetMemberId;
        this.sourceMemberId = sourceMemberId;
        this.reqParam = reqParam;
        this.registryTime = registryTime;
    }
}
