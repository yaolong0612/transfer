package cn.com.pg.loyalty.domain.gift;

import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.interfaces.dto.Language;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * @author Simon
 */
@Document(collection = "Gift", ru = "400")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Gift implements Entity<Gift> {
    /**
     * 礼品Package SKU，一份礼品的SKU唯一，一份礼品可以包含多个Item
     */
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.GIFT_PARTITIONKEY;
    /**
     * 礼品名称
     */
    private String name;

    /**
     * 礼品描述
     */
    private String description;

    /**
     * 功效说明，for olay
     */
    private String efficacies;

    /**
     * 礼品图片链接
     */
    private String imageUri;

    /**
     * 礼品的市场价格
     */
    private BigDecimal marketPrice;

    /**
     * 礼品需要的积分,PAMPERS对应成长值
     */
    private Integer point;
    /**
     * PAMPERS过渡积分
     */
    private Integer transitPoint;


    private List<GiftItem> items = new ArrayList<>(8);

    /**
     * 礼品被分配的积分体系
     */
    private String loyaltyStructure;

    /**
     * 用户添加礼品的时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    /**
     * 用户修改礼品的时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    /**
     * 礼品的备注信息
     */
    private String remark;

    /**
     * 谁创建这个礼品
     */
    private String createdBy;

    private String bagSku;

    private GiftType type = GiftType.NORMAL;

    private List<CouponUrlItem> couponUrls = new ArrayList<>(4);

    /**
     * 多语言支持
     */
    private List<GiftDisplayMsg> displayLanguages = new ArrayList<>();

    @Override
    public boolean sameIdentityAs(Gift other) {
        return other != null && id.equals(other.id);
    }


    @Default
    public Gift(String name, String imageUri, Integer point, String loyaltyStructure, GiftType type) {
        this.name = name;
        this.imageUri = imageUri;
        this.point = point;
        this.loyaltyStructure = loyaltyStructure;
        this.type = type;
        this.id = UUIDUtil.generator();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 添加礼品调用这个构造方法，被分配的数量默认值是0
     */
    public Gift(String name, String description, String imageUri, BigDecimal marketPrice, Integer point, Integer transitPoint, List<GiftItem> items,
                String loyaltyStructure, String remark, String createdBy,
                List<GiftDisplayMsg> displayLanguages, GiftType giftType, String bagSku, List<CouponUrlItem> urls) {
        this.id = UUIDUtil.generator();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.name = name;
        this.description = description;
        this.imageUri = imageUri;
        this.marketPrice = marketPrice;
        this.point = point;
        this.transitPoint = transitPoint;
        this.items = items;
        this.loyaltyStructure = loyaltyStructure;
        this.remark = remark;
        this.createdBy = createdBy;
        this.displayLanguages = displayLanguages;
        this.bagSku = bagSku;
        this.type = giftType;
        this.couponUrls = urls;
    }

    /**
     * 添加礼品调用这个构造方法，被分配的数量默认值是0
     * <p>
     * 2022-01-20 此方法在test中，没有被正式使用
     */
    @Deprecated
    public Gift(String name, String description, String imageUri, BigDecimal marketPrice, Integer point, List<GiftItem> items, String loyaltyStructure, String remark, String createdBy) {
        this.id = UUIDUtil.generator();
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.name = name;
        this.description = description;
        this.imageUri = imageUri;
        this.marketPrice = marketPrice;
        this.point = point;
        this.items = items;
        this.loyaltyStructure = loyaltyStructure;
        this.remark = remark;
        this.createdBy = createdBy;
    }

    public void updateGift(Gift newGift) {
        if (!StringUtils.equals(newGift.loyaltyStructure, this.loyaltyStructure)) {
            throw new SystemException("LoyaltyStructure not match", ResultCodeMapper.PARAM_ERROR);
        }
        this.name = newGift.name;
        this.description = newGift.description;
        this.imageUri = newGift.imageUri;
        this.marketPrice = newGift.marketPrice;
        this.point = newGift.point;
        this.transitPoint = newGift.transitPoint;
        this.items = newGift.items;
        this.updatedTime = LocalDateTime.now();
        this.remark = newGift.remark;
        this.displayLanguages = newGift.displayLanguages;
        this.efficacies = newGift.efficacies;
        this.couponUrls = newGift.couponUrls;
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 判断积分体系是否是同一个
     *
     * @param loyaltyStructure
     * @return boolean
     */
    public boolean checkLoyaltyStructure(String loyaltyStructure) {
        return StringUtils.equals(this.loyaltyStructure, loyaltyStructure);
    }

    /**
     * 解密加密了的图片链接：base64
     */
    public String getImageUri() {
        String imageRegex = "^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)$";
        if (StringUtils.isNotEmpty(imageUri) && imageUri.matches(imageRegex)) {
            return new String(Base64.getDecoder().decode(imageUri));
        }
        return imageUri;
    }

    public boolean couponGift() {
        return GiftType.COUPON == type;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class GiftDisplayMsg {
        private String language;
        private String description;
        private List<GiftItem> items;
        private String name;
        private String imageUri;


        @Default
        public GiftDisplayMsg(Language language, String description, List<GiftItem> items, String name, String imageUri) {
            this.language = language.toString();
            if (this.language == null) {
                throw new SystemException("Unsupported language:".concat(language.toString()), ResultCodeMapper.PARAM_ERROR);
            }
            this.description = description;
            this.items = items;
            this.name = name;
            this.imageUri = imageUri;
        }
    }


    public enum GiftType {
        NORMAL,
        COUPON
    }
}
