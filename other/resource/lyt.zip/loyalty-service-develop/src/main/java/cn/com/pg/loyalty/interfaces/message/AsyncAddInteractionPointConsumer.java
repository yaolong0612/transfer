package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountService;
import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Transaction.PointTypeEnum;
import cn.com.pg.loyalty.domain.transaction.TransactionRepository;
import cn.com.pg.loyalty.infrastructure.cache.CacheServiceImpl;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.dto.AddInteractionCommand;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;


/**
 * @description: 异步通知加交互积分队列
 * @author: Jevons Chen
 * @date: 2020-09-02 9:48
 */

@Component
@Slf4j
public class AsyncAddInteractionPointConsumer extends AbstractConsumerV2 {

    private static final String TOKEN = "AsyncAddInteractionPointConsumer";
    public static final String MEMBER_ID = "memberId";

    @Autowired
    private MessageService messageService;

    @Autowired
    private TransactionService transactionService;
    @Autowired
    private CacheServiceImpl cacheService;
    @Autowired
    private AccountService accountService;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;


    /**
     * {
     * "body": {
     * <p>
     * },
     * "ADD_INTERACTION_POINT": ""
     * }
     */
    @Override
    protected void doBusiness(JSONObject message) {
        log.info("AsyncAddInteractionPointConsumer receive msg: {}", message);
        JSONArray messageBody = message.getJSONArray("body");

        //香港tw加积分场景
        Boolean batchFlag = (Boolean) message.get("batch");
        String event= message.getString("event");

        if (batchFlag != null && batchFlag) {
            //TW/HK批量加积分
            batchAddInteractionPoint(message);
            return;
        }

        if ("CALCULATED".equals(event)) {
            addInteractionPoint(messageBody);
            return;
        }

        //加交互积分
        if (messageBody == null) {
            addInteractionPoint(message);
            return;
        }
        addInteractionPoint(messageBody.getJSONObject(0));
    }

    private void addInteractionPoint(JSONArray messageBody) {
        JSONObject body = messageBody.getJSONObject(0);
        InteractionMessage interactionMessage = JSON.toJavaObject(body, InteractionMessage.class);
        if (PointTypeEnum.TIER_REWARD_REFUND.name().equals(interactionMessage.getPointType())) {
            transactionService.refundOrderCauseTierDownReturnTierAwarePoint(interactionMessage);
            return;
        }
        transactionService.addInteractionPoint(interactionMessage);
    }


    private void batchAddInteractionPoint(JSONObject message) {
        JSONArray batchMessages = message.getJSONArray("body");
        Object plateForm = message.get("plateForm");
        JSONObject msg = new JSONObject();
        ArrayList<JSONObject> messages = new ArrayList<>();
        for (Object object : batchMessages) {
            msg.put("plateForm", plateForm);
            msg.put("type", "MAIL");
            msg.put("category", "BATCH_ADD_POINT");
            JSONObject batchMessage = (JSONObject) object;
            JSONObject outerMessage = new JSONObject();
            outerMessage.put(MEMBER_ID, batchMessage.get(MEMBER_ID));
            outerMessage.put("pointsAboutToExpire", batchMessage.get("point"));
            try {
                AccountTransactionResult accountTransactionResult = addInteractionPoint(batchMessage);
                outerMessage.put("expiryDate", accountTransactionResult.getTransaction().getExpiredTime().toLocalDate());
                outerMessage.put("loyaltyId", accountTransactionResult.getAccount().getId());
                outerMessage.put("partitionKey", accountTransactionResult.getAccount().getPartitionKey());
                outerMessage.put("isSecondReminder", false);
                outerMessage.put("code", 200);
                outerMessage.put("msg", "Success");
            } catch (SystemException e) {
                log.error(e.getMessage());
                outerMessage.put("code", e.resultCodeMapper().getCode());
                outerMessage.put("msg", e.resultCodeMapper().name());
                outerMessage.put("expiryDate", LocalDate.now());
                outerMessage.put("loyaltyId", "");
                outerMessage.put("partitionKey", "");
                outerMessage.put("isSecondReminder", false);
            } finally {
                messages.add(outerMessage);
            }
        }
        msg.put("body", messages);
        messageService.sendMessage4InfoConsumer(msg);
    }

    private AccountTransactionResult addInteractionPoint(JSONObject message) {
        AddInteractionCommand body = JSON.parseObject(JSON.toJSONString(message), AddInteractionCommand.class);
        verifyParams(body);
        AccountTransactionResult accountTransactionResult = transactionService.addInteractionPoint(
                body.getBrand(),
                body.getRegion(),
                body.getChannel(),
                body.getMemberId(),
                body.getPointType(), body.getQrcode(), body.getSku(), body.isNewMember(), body.getPoint(), body.getAdjustReason(), TOKEN, null);
        log.info("memberId:{} add interaction point by consumer successfully", body.getMemberId());
        return accountTransactionResult;
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_ASYNC_ADD_INTERACTION_POINT;
    }

    public void verifyParams(AddInteractionCommand body) {
        ParamValidator.stringParam("pointType", body.getPointType());
        ParamValidator.stringParam(MEMBER_ID, body.getMemberId());
    }
}
