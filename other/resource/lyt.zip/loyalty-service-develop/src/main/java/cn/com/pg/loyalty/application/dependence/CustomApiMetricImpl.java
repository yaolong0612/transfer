package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.paas.monitor.domain.entity.ApiLogExtend;
import cn.com.pg.paas.monitor.domain.services.ICustomApiMetric;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

/**
 * @author xingliangzhan
 * @date 2019/8/7
 * 定制ApiMetric:
 * 设置error_code,增加request_id,增加error message
 */
@Component
public class CustomApiMetricImpl implements ICustomApiMetric {

    @Override
    public ApiLogExtend getCustomMetric(String responseBody, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        ApiLogExtend apiLogExtend = new ApiLogExtend();
        HashMap<String, Object> dimension = new HashMap<>(3);
        dimension.put("correlation_id", RequestContext.getCurrentContext().getCorrelationId());
        dimension.put("api_method", RequestContext.getCurrentContext().getOperationName());
        ResultCodeMapper errorResult = RequestContext.getCurrentContext().errorResult();
        if (errorResult == null) {
            apiLogExtend.setError_code(ResultCodeMapper.SUCCESS.getCode());
            dimension.put("error_message", ResultCodeMapper.SUCCESS);
        } else {
            apiLogExtend.setError_code(errorResult.getCode());
            dimension.put("error_message", errorResult);
        }
        apiLogExtend.setDimension(dimension);
        return apiLogExtend;
    }
}
