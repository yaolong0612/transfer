package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.storage.StorageEntity;
import com.microsoft.azure.storage.table.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Simon
 * @date 2019/6/21 7:41
 * @description https://docs.microsoft.com/zh-cn/azure/cosmos-db/table-storage-how-to-use-java?toc=https%3A%2F%2Fdocs.microsoft.com%2Fzh-cn%2Fazure%2Fstorage%2Ftables%2FTOC.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fzh-cn%2Fazure%2Fbread%2Ftoc.json
 **/
@Component
@Slf4j
public class TableStorageTemplate {
    public final String PARTITION_KEY = "PartitionKey";
    public final String ROW_KEY = "RowKey";
    public final String TIMESTAMP = "Timestamp";
    @Autowired
    private CloudTableClient cloudTableClient;

    /**
     * 根据Filter String查询。FilterString的创建，参考链接中sample。
     * TableQuery.generateFilterCondition（）
     * TableQuery.combineFilters（）
     * 如果数据量大，不要直接将iterator转换为list，应该循环去读，Azure会自动封装每次读取100条
     *
     * @param entityClazz
     * @param filterString
     * @param <T>
     * @return
     */
    public <T extends TableEntity> Iterable<T> query(Class<T> entityClazz, String filterString) {
        long start = System.currentTimeMillis();
        String tableName = getTableName(entityClazz);
        log.info("Table Name: {}, Where: {}", tableName, filterString);
        try {
            CloudTable cloudTable = cloudTableClient.getTableReference(tableName);
            TableQuery<T> rangeQuery =
                    TableQuery.from(entityClazz)
                            .where(filterString);
            return cloudTable.execute(rangeQuery);
        } catch (Exception e) {
            log.error("Execute Query Error", e);
            throw new SystemException("执行TableStorage查询失败", ResultCodeMapper.TABLE_STORAGE_ERROR);
        } finally {
            log.info("Table Query Cost: {}", System.currentTimeMillis() - start);
        }
    }

    public <T extends TableEntity> T save(T entity) {
        long start = System.currentTimeMillis();
        String tableName = getTableName(entity.getClass());
        log.info("Save Table Name: {}", tableName);
        try {
            CloudTable cloudTable = cloudTableClient.getTableReference(tableName);
            TableOperation insertOperation = TableOperation.insertOrReplace(entity);
            TableResult tableResult = cloudTable.execute(insertOperation);
            return (T)tableResult.getResult();
        } catch (Exception e) {
            log.error("Execute Insert Error", e);
            throw new SystemException("执行TableStorage插入失败", ResultCodeMapper.TABLE_STORAGE_ERROR);
        } finally {
            log.info("Table Insert Cost: {}", System.currentTimeMillis() - start);
        }
    }

    public String getPartitionKeyFilter(String partitionKey) {
        return TableQuery.generateFilterCondition(
                PARTITION_KEY,
                TableQuery.QueryComparisons.EQUAL,
                partitionKey);
    }

    public String getRowKeyFilter(String rowKey) {
        return TableQuery.generateFilterCondition(
                ROW_KEY,
                TableQuery.QueryComparisons.EQUAL,
                rowKey);
    }

    private String getTableName(Class<?> entityClazz) {
        StorageEntity storageEntityAnnotation = entityClazz.getAnnotation(StorageEntity.class);
        return storageEntityAnnotation.name();
    }
}
