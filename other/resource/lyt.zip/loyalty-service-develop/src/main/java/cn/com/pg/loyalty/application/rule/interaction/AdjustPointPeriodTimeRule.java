package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.PeriodTimeAddPointProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: daming iYoYo添加积分  每天有上限
 */
@Rule(name = "read_a_period_time_add_point",
        description = "read a period time add point")
@Slf4j
public class AdjustPointPeriodTimeRule {

    @Condition
    public boolean isBirthMonthRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointPeriodTimeRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_PER_PERIOD;
    }
    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("point") Integer point,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("brand") String brand,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        log.info("根据阅读时间加积分:{}", point);
        activities = activities.stream().filter(activity -> LocalDateTime.now()
                .isBefore(activity.getEndAt()) && LocalDateTime.now().isAfter(activity.getStartAt()))
                .sorted(Comparator.comparing(Activity::getPriority).reversed()).collect(Collectors.toList());
        Activity activity = activities.get(0);
        PeriodTimeAddPointProperties birthMonthPointProperties = (PeriodTimeAddPointProperties)activity.ruleProperties();
        // 查看该用户是否已经加过该活动类型的积分
        List<Interaction> interactions = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(interaction.partitionKey(),
                activity.pointType(), interaction.getLoyaltyId(), brand, LoyaltyDateTimeUtils.getBeginTimeOfDate(LocalDateTime.now()).toString(), LoyaltyDateTimeUtils.getEndTimeOfDay(LocalDateTime.now()).toString());
        int sumExistedPoint = interactions.stream().mapToInt(Interaction::point).sum();
        Integer maxPoint = birthMonthPointProperties.maxPoint();
        Integer multiple = birthMonthPointProperties.multiple();
        int multipleMaxPoint = maxPoint * multiple;
        int multiplePoint = point * multiple;
        if (sumExistedPoint >= multipleMaxPoint) {
            ruleResult.addException(new SystemException("The amount of this type of bonus points that gained by this user exceeds the upper limit："+multipleMaxPoint + "，User："+interactions.size(), ResultCodeMapper.LIMIT_ERROR));
            return;
        }
        int sumPoint = multiplePoint + sumExistedPoint;
        if (sumPoint >= multipleMaxPoint) {
            multiplePoint = multipleMaxPoint - sumExistedPoint;
        }
        interaction.addPoint(activity, multiplePoint);
        log.info("阅读积分添加完成, 记录interaction: {}", JSON.toJSONString(interaction));
        ruleResult.success();
    }

}
