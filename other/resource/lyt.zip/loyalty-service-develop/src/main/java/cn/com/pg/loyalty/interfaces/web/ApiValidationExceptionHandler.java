package cn.com.pg.loyalty.interfaces.web;

import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.interfaces.dto.APIErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author xingliangzhan
 * @date 2019/5/10
 */
@ControllerAdvice
@Slf4j
public class ApiValidationExceptionHandler extends ResponseEntityExceptionHandler {

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid
            (MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        BindingResult bindingResult = ex.getBindingResult();
        List<String> errorDetails = bindingResult
                .getFieldErrors()
                .stream()
                .map(err -> err.getCode() + " error on '" + err.getField() + "': " + err.getDefaultMessage())
                .collect(Collectors.toList());
        RequestContext.getCurrentContext().error(ResultCodeMapper.PARAM_ERROR);
        APIErrorResponse apiErrorResponse = new APIErrorResponse().
                code(ResultCodeMapper.PARAM_ERROR.getCode()).
                message(String.join(" | ", errorDetails)).
                correlationId(RequestContext.getCurrentContext().getCorrelationId());
        log.info("Param Error: handleMethodArgumentNotValid, {}", apiErrorResponse.getMessage());
        return ResponseEntity.
                status(ResultCodeMapper.PARAM_ERROR.getStatus()).
                body(apiErrorResponse);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatus status, WebRequest request) {
        String message = null;
        if (ex instanceof HttpMessageNotReadableException) {
            if (StringUtils.isNotEmpty(ex.getMessage()) && ex.getMessage().contains("(")) {
                message = ex.getMessage().split("\\(")[0];
            }
        }
        if (message == null) {
            message = ex.getMessage();
        }
        APIErrorResponse apiErrorResponse = new APIErrorResponse().
                code(ResultCodeMapper.PARAM_ERROR.getCode()).message(message).
                correlationId(RequestContext.getCurrentContext().getCorrelationId());
        RequestContext.getCurrentContext().error(ResultCodeMapper.PARAM_ERROR);
        log.info("Param Error: handleExceptionInternal, {}", ex.getMessage());
        return ResponseEntity.
                status(ResultCodeMapper.PARAM_ERROR.getStatus()).
                body(apiErrorResponse);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    protected ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException e) {
        APIErrorResponse apiErrorResponse = new APIErrorResponse().
                code(ResultCodeMapper.PARAM_ERROR.getCode()).
                message(e.getMessage()).
                correlationId(RequestContext.getCurrentContext().getCorrelationId());
        RequestContext.getCurrentContext().error(ResultCodeMapper.PARAM_ERROR);
        log.info("Param Error: ConstraintViolationException, {}", e.getMessage());
        return ResponseEntity.
                status(ResultCodeMapper.PARAM_ERROR.getStatus()).
                body(apiErrorResponse);
    }

}
