package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/22
 */
@Getter
@Setter
public class GroupPurchaseOrderExcludePropertiesV2 extends RuleProperties {
    /**
     * 实际团购购买金额
     */
    @Min(0)
    private Double realGroupPurchaseAmount;
}
