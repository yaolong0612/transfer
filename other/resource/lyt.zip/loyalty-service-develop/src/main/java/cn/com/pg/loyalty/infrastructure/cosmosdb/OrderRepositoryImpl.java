package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.transaction.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.domain.transaction.TransactionType.ORDER;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2020-08-19 16:19
 */

@Service
public class OrderRepositoryImpl implements OrderRepositoryV2 {

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public List<Order> findMemberOrdersByOrderId(String loyaltyId, String brand, String orderId, String channel) {
        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndOrderIdAndChannel(transactionPartitionKey, loyaltyId, brand, orderId, channel);
    }

    @Override
    public List<Order> findMemberOrdersByLoyaltyId(Account account, String brand) {
        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(
                transactionPartitionKey, account.getId(), brand, ORDER);
    }

    @Override
    public List<Order> findMemberSinceLastNumYearOrdersByLoyaltyId(Account account, String brand, int lastYears) {
        LocalDateTime earliestTime = LoyaltyDateTimeUtils.getLastDayOfYear(
                LocalDateTime.now().minusYears(1).minusYears(lastYears));
        String earliestTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(earliestTime);
        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeGreaterThan(
                transactionPartitionKey, account.getId(), brand, ORDER, earliestTimeStr);
    }

    @Override
    public List<Order> findGivenDateIntervalMonthAgo2ItOrders(Account account, String brand, int intervalMonths, LocalDateTime givenDate) {
        LocalDateTime earliestTime = givenDate.minusMonths(intervalMonths);
        String givenTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(givenDate);
        String earliestTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(earliestTime);
        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                transactionPartitionKey, account.getId(), brand, ORDER, earliestTimeStr, givenTimeStr);
    }

    @Override
    public List<Order> findOrdersByOrderDateTimeBetween(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndOrderDateTimeBetweenAndTransactionType(partitionKey, loyaltyId, startTimeStr, endTimeStr, ORDER);
    }

    @Override
    public List<Order> findMemberOrdersInOrderIds(String loyaltyId, List<String> orderIds) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        return orderRepository.findByPartitionKeyAndLoyaltyIdAndOrderIdIn(partitionKey, loyaltyId, orderIds);
    }

    @Override
    public void deleteAll(List<Order> orders) {
        orderRepository.deleteAll(orders);
    }

    @Override
    public void saveAll(List<Order> orders) {
        orderRepository.saveAll(orders);
    }

    @Override
    public List<Order> fetchOrdersByCreatedTimeSorted(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        List<Order> orders = orderRepository.findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndCreatedTimeBetween(pk, loyaltyId, ORDER, startAt, endAt);
        return orders.stream()
                .sorted(Comparator.comparing(Transaction::getCreatedTime))
                .collect(Collectors.toList());
    }
}
