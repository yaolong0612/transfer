package cn.com.pg.loyalty.domain.transaction;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author: Ysnow
 * @Date: 2019/6/11 15:09
 * @Description:
 */
@Repository
public interface RedemptionRepository extends DocumentDbRepository<Redemption,String> {

    /**
     * 查询会员ID
     * @param id
     * @return
     */
    List<Redemption> findRedemptionById(String id);

    /**
     * 通过分区键和id查找
     * @param partitionKey
     * @param id
     * @return
     */
    List<Redemption> findByPartitionKeyAndId(String partitionKey,String id);

    /**
     * 通过分区键和redeemCode查找
     * @param partitionKey
     * @param redeemCode
     * @return
     */
    List<Redemption> findByPartitionKeyAndMemberIdAndTransactionTypeAndRedeemCode(String partitionKey,String memberId, TransactionType transactionType, String redeemCode);

    /**
     * 查询兑换订单
     * @param partitionKey
     * @param loyaltyId
     * @param transactionType
     * @param activityId
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndActivityIdAndRedemptionStatusNotIn(String partitionKey,String loyaltyId,TransactionType transactionType,String activityId,List<String> redemptionStatusList);


    /**
     * 查询兑换订单记录
     * @param activityId
     * @param brand
     * @param startTime
     * @param endTime
     * @param redemptionStatus
     * @param transactionType
     * @param channel
     * @param deliverChannel
     * @return
     */
    List<Redemption> findByActivityIdAndBrandAndCreatedTimeBetweenAndRedemptionStatusAndTransactionTypeAndChannelAndDeliveryChannel(String activityId, String  brand, String startTime, String endTime, RedemptionStatus redemptionStatus, TransactionType transactionType, String channel, DeliveryChannel deliverChannel);


    /**
     * 查询兑换订单
     * @param activityId
     * @param brand
     * @param startTime
     * @param endTime
     * @param transactionType
     * @param redemptionStatus
     * @param deliveryChannel
     * @return
     */
    List<Redemption> findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusAndDeliveryChannel(String activityId, String brand, String startTime, String endTime, TransactionType transactionType, RedemptionStatus redemptionStatus, DeliveryChannel deliveryChannel);


    /**
     * 查询兑换订单
     * @param partitionKey
     * @param loyaltyId
     * @param activityId
     * @param brand
     * @param startTime
     * @param endTime
     * @param redemptionStatus
     * @param transactionType
     * @param channel
     * @param deliverChannel
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndRedemptionStatusAndTransactionTypeAndChannelAndDeliveryChannel(String partitionKey, String loyaltyId, String activityId, String  brand, String startTime, String endTime, RedemptionStatus redemptionStatus, TransactionType transactionType, String channel, DeliveryChannel deliverChannel);

    List<Redemption> findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndChannelAndDeliveryChannel(String partitionKey, String loyaltyId, String activityId, String brand, String startTime, String endTime, TransactionType transactionType, String channel, DeliveryChannel deliverChannel);


    List<Redemption> findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndChannelAndDeliveryChannel(String activityId, String brand, String startTime, String endTime, TransactionType transactionType, String channel, DeliveryChannel deliverChannel);

    List<Redemption> findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndDeliveryChannel(String partitionKey,
                                                                                                                                            String loyaltyId,
                                                                                                                                            String activityId,
                                                                                                                                            String brand,
                                                                                                                                            String startTime,
                                                                                                                                            String endTime,
                                                                                                                                            TransactionType transactionType,
                                                                                                                                            DeliveryChannel deliverChannel);

    List<Redemption> findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndDeliveryChannel(String activityId, String brand, String startTime, String endTime, TransactionType transactionType, DeliveryChannel deliveryChannel);


    /**
     * 查询兑换订单
     * @param partitionKey
     * @param loyaltyId
     * @param activityId
     * @param brand
     * @param startTime
     * @param endTime
     * @param transactionType
     * @param redemptionStatus
     * @param deliverChannel
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusAndDeliveryChannel(String partitionKey, String loyaltyId, String activityId, String brand, String startTime, String endTime, TransactionType transactionType, RedemptionStatus redemptionStatus, DeliveryChannel deliverChannel);

    /**
     * 跨分区查兑换的transaction
     * @param transactionType
     * @param redemptionStatus
     * @param activityId
     * @param deliveryChannel
     * @param storeCode
     * @return
     */
    List<Redemption> findByTransactionTypeAndRedemptionStatusAndActivityIdAndDeliveryChannelAndStoreCode(TransactionType transactionType, RedemptionStatus redemptionStatus, String activityId, DeliveryChannel deliveryChannel, String storeCode);


    /**
     * 查询兑换记录
     * @param partitionKey
     * @param transactionType
     * @param redemptionStatus
     * @param loyaltyId
     * @param activityId
     * @return
     */
    List<Redemption> findByPartitionKeyAndTransactionTypeAndRedemptionStatusAndLoyaltyIdAndActivityId(String partitionKey,TransactionType transactionType,RedemptionStatus redemptionStatus,String loyaltyId,String activityId);


    /**
     * 根据领取柜台查询redemption
     * @param activityId
     * @param startTime
     * @param endTime
     * @param redemptionStatus
     * @param storeCode
     * @param transactionType
     * @return
     */
    List<Redemption> findByActivityIdAndCreatedTimeBetweenAndRedemptionStatusAndStoreCodeAndTransactionType(String activityId, String startTime, String  endTime, String  redemptionStatus, String storeCode, TransactionType transactionType);

    List<Redemption> findByCreatedTimeBetweenAndRedemptionStatusAndStoreCodeAndTransactionType(String startTime, String  endTime,RedemptionStatus  redemptionStatus, String storeCode, TransactionType transactionType);

    List<Redemption> findByCreatedTimeBetweenAndStoreCodeAndTransactionType(String startTime, String  endTime,String storeCode, TransactionType transactionType);



    /**
     * 根据领取柜台查询redemption
     * @param activityId
     * @param startTime
     * @param endTime
     * @param storeCode
     * @param transactionType
     * @return
     */
    List<Redemption> findByActivityIdAndCreatedTimeBetweenAndStoreCodeAndTransactionType(String activityId, String startTime, String  endTime,String storeCode, TransactionType transactionType);

    /**
     * 通过活动id和柜台查找redemption
     * @param activityId
     * @param storeCode
     * @param redemptionStatus
     * @param transactionType
     * @return
     */
    List<Redemption> findByActivityIdAndStoreCodeAndCreatedTimeBetweenAndRedemptionStatusAndTransactionType(String activityId, String storeCode, String startTime, String endTime, RedemptionStatus redemptionStatus, TransactionType transactionType);

    /**
     * 查询某个人的兑换记录
     * @param partitionKey
     * @param loyaltyId
     * @param startTime
     * @param endTime
     * @param transactionType
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(String partitionKey, String loyaltyId, String startTime, String endTime, TransactionType transactionType);

    /**
     * 查询某个人的兑换记录
     * @param partitionKey
     * @param loyaltyId
     * @param startTime
     * @param endTime
     * @param transactionType
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusIn(String partitionKey, String loyaltyId, String startTime, String endTime, TransactionType transactionType, List<String> redemptionStatus);

    /**
     * 查询某个人的兑换记录
     * @param partitionKey
     * @param loyaltyId
     * @param transactionType
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndTransactionType(String partitionKey, String loyaltyId, TransactionType transactionType);

    /**
     * 查询某个人的兑换记录
     * @param partitionKey
     * @param loyaltyId
     * @param transactionType
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndRedemptionStatusIn(String partitionKey, String loyaltyId, TransactionType transactionType, List<String> redemptionStatus);

    @Override
    Redemption save(Redemption redemption);

    /**
     *  查询用户某个活动的兑换记录
     * @param transactionPK
     * @param loyaltyId
     * @param id
     * @return
     */
    List<Redemption> findByPartitionKeyAndLoyaltyIdAndActivityId(String transactionPK, String loyaltyId, String id);
}
