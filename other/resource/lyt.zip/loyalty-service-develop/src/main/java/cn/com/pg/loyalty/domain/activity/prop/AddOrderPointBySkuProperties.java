package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

@Data
public class AddOrderPointBySkuProperties extends RuleProperties{
    /**
     * 指定sku加积分
     */
    private String sku;
    /**
     * 一个sku加多少积分
     */
    private int basePoint;

    private AddSkuTimesLimit addSkuTimesLimit;

    private OrdersTimesLimit ordersTimesLimit;

    @Data
    public static class OrdersTimesLimit{
        /**
         * 限制多长时间（单位：天）
         */
        private int limitOrderTimesInDays;
        /**
         * 限制必须有多少订单数量
         */
        private int limitOrderTimes;
    }

    @Data
    public static class AddSkuTimesLimit{
        /**
         * 一段时间内只能有多少个sku加积分
         */
        private int limitAddSkuNum;
        /**
         * 限制时间长度（单位：月）
         * 1 示当月；2表示当月加上一个月；3表示当月加上两个月；依此类推
         */
        private int limitAddSkuMonth;
    }
}
