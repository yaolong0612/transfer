package cn.com.pg.loyalty.infrastructure.lock;

import cn.com.pg.loyalty.domain.shared.SystemException;

import java.lang.annotation.*;
import java.util.concurrent.TimeUnit;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface MutexLock {

    /**
     * spel 语法表达:  变量 #argument，固定 'argument'
     */
    String[] lockKeys() default {};

    long expiredTime() default 10;

    TimeUnit timeUnit() default TimeUnit.SECONDS;

    Class<? extends RuntimeException>[] businessExceptions() default SystemException.class;

    String errorMessage() default "Frequent request";

    /**
     *最大重试次数
     */
    int maxTryTimes() default 10;

    /**
     * 获取不到锁时的睡眠时间
     */
    int tryLockSleepMsecs() default 50;

    /**
     *  释放锁之前的睡眠时间
     */
    int releaseLockSleepMsecs() default 50;
}
