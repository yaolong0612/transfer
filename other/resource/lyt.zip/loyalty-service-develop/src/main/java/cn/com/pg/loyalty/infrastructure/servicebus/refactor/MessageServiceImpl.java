package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import cn.com.pg.loyalty.application.RedemptionServiceBusProperties;
import cn.com.pg.loyalty.application.dependence.*;
import cn.com.pg.loyalty.application.dto.RefundDTO;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import cn.com.pg.loyalty.domain.structure.*;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.interfaces.dto.Event;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

@Slf4j
@Component
public class MessageServiceImpl implements MessageService {

    private static final String MEMBER_ID_TAG = "memberId";
    private static final String BRAND_TAG = "brand";
    private static final String REGION_TAG = "region";
    private static final String CHANNEL_TAG = "channel";
    private static final String TRANSACTIONS_TAG = "transactions";
    private static final String MEMBER_IDS_TAG = "memberIds";


    @Autowired
    private ServiceBusClient serviceBusClient;
    @Autowired
    private CacheService cacheService;
    @Autowired
    private ServiceBusTemplate serviceBusTemplate;


    @Override
    public void sendSaveTransactionAndAccountFailedMessage(Transaction transaction) {
        serviceBusClient.sendMessage(toJson(transaction), ServiceBusBinder.Q_DISASTER_RECOVERY);
    }

    @Override
    public void sendSaveAccountFailedMessage(Account account) {
        serviceBusClient.sendMessage(toJson(account), ServiceBusBinder.Q_DISASTER_RECOVERY);
    }

    @Override
    public void sendSaveTransactionFailedMessage(Transaction transaction) {
        serviceBusClient.sendMessage(toJson(transaction), ServiceBusBinder.Q_DISASTER_RECOVERY);
    }

    @Override
    public void send2RecalculateOrders(String memberId, String region, List<Order> originOrders) {
        if (CollectionUtils.isEmpty(originOrders)) {
            return;
        }
        String brand = originOrders.get(0).brand();
        Map<String, Object> messageBody = new HashMap<>();
        messageBody.put(MEMBER_ID_TAG, memberId);
        messageBody.put(TRANSACTIONS_TAG, originOrders);
        messageBody.put(REGION_TAG, region);
        messageBody.put(BRAND_TAG, brand);
        log.info("send 2 recalculate, account: {} ,order: {}", memberId,
                originOrders.stream().map(Order::getOrderId).collect(toList()));
        serviceBusClient.sendMessage(toJson(messageBody), ServiceBusBinder.getOrderConsumeBinder(brand));
    }

    @Override
    public void delayCalculateOrders(String memberId, String region, String brand, List<Order> originOrders,
                                     LocalDateTime calculateDate) {
        Map<String, Object> messageBody = new HashMap<>();
        messageBody.put(MEMBER_ID_TAG, memberId);
        messageBody.put(TRANSACTIONS_TAG, originOrders);
        messageBody.put(REGION_TAG, region);
        messageBody.put(BRAND_TAG, brand);
        serviceBusClient.sendScheduleMessage(toJson(messageBody),
                ServiceBusBinder.getOrderConsumeBinder(brand), calculateDate);
        log.info("delay order: {}", messageBody);

    }

    @Override
    public void delayRecalculateOrders(String memberId, String region, String brand, List<Order> originOrders,
                                       LocalDateTime calculateDate) {
        Map<String, Object> messageBody = new HashMap<>();
        messageBody.put(MEMBER_ID_TAG, memberId);
        messageBody.put(TRANSACTIONS_TAG, originOrders);
        messageBody.put(REGION_TAG, region);
        messageBody.put(BRAND_TAG, brand);
        serviceBusClient.sendScheduleMessage(toJson(messageBody),
                ServiceBusBinder.Q_ORDER_RECALCULATE, calculateDate);
        log.info("delay order: {}", messageBody);
    }

    @Override
    public void pushOrderAffectExpiredEvent(String memberId, String brand, String region) {
        Map<String, Object> messageBody = new HashMap<>(4);
        messageBody.put(MEMBER_ID_TAG, memberId);
        messageBody.put(REGION_TAG, region);
        messageBody.put(BRAND_TAG, brand);
        log.info("send or delay order year event: {}", messageBody);
        serviceBusClient.sendScheduleMessage(toJson(messageBody), ServiceBusBinder.Q_ORDER_EVENT,
                LocalDateTime.now().plusSeconds(5));

    }

    @Override
    public void send2DeleteMembersForSkii(JSONObject message) {
        serviceBusClient.sendMessage(message, ServiceBusBinder.Q_RETENTION_MEMBERIDS);
    }

    @Override
    public void sendMessageForDeleteMemberInfo(List<Account> originalAccounts, String brand) {
        if (originalAccounts.isEmpty()) {
            return;
        }
        Account account = originalAccounts.get(0);
        String region = account.region();
        List<String> memberIds = originalAccounts.stream().map(Account::memberId).collect(Collectors.toList());
        log.info("accounts {} been deleted ", memberIds);
        JSONObject message = new JSONObject();
        message.put(MEMBER_IDS_TAG, memberIds);
        message.put(REGION_TAG, region);
        message.put(BRAND_TAG, brand);
        serviceBusClient.sendMessage(message, ServiceBusBinder.Q_RETENTION_MEMBERIDS);
    }


    @Override
    public void sendMessageForBatchAddInteractionPoint(String region, String brand, String channel,
                                                       String pointType, Integer point, List<String> memberIds,
                                                       String adjustReason) {
        JSONObject message = new JSONObject();
        message.put("batch", true);
        ArrayList<Object> members = new ArrayList<>();
        message.put("body", members);
        if (RegionV2.isHkRegion(region) && BrandV2.PAMPERS.equals(brand)) {
            message.put("plateForm", "MT");
        }
        if (RegionV2.isHkRegion(region) && BrandV2.PAMPERS.equals(brand)) {
            message.put("plateForm", "SMP");
        }
        for (String memberId : memberIds) {
            getBody(region, brand, channel, pointType, point, memberId, members, adjustReason);
            if (members.size() % 10 == 0) {
                serviceBusClient.sendMessageAsyn(message, ServiceBusBinder.Q_ASYNC_ADD_INTERACTION_POINT);
                members.clear();
                message.remove("body");
            }
        }
        if (!members.isEmpty()) {
            serviceBusClient.sendMessageAsyn(message, ServiceBusBinder.Q_ASYNC_ADD_INTERACTION_POINT);
        }
    }

    @Override
    public void sendMessage4InfoConsumer(JSONObject outerMessage) {
        serviceBusClient.sendMessage(outerMessage, ServiceBusBinder.Q_MESSAGE_PROCESSOR);
    }

    @Override
    public void sendMessage4PointPool(PoolMessage poolMessage) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(poolMessage.getRegion(), poolMessage.brand());
        PointExpire pointExpire = structure.pointExpire(poolMessage.valueType());
        if (poolMessage.point() == 0) {
            return;
        }
        if (!pointExpire.useExternalPointPool()) {
            return;
        }
        serviceBusClient.sendMessage((JSONObject) JSON.toJSON(poolMessage), ServiceBusBinder.Q_SYNC_POINT_POOL);

    }

    private JSONObject toJson(Object messageBody) {
        return (JSONObject) JSON.toJSON(messageBody);
    }

    @Override
    public void sendMessageForAddInteractionPoint(InteractionMessage interactionMessage, int persistTimes) {
        JSONObject message = new JSONObject();
        message.put("batch", false);
        message.put("event", "CALCULATED");
        ArrayList<Object> members = new ArrayList<>();
        message.put("body", members);
        members.add(interactionMessage);
        serviceBusClient.sendScheduleMessage(message, ServiceBusBinder.Q_ASYNC_ADD_INTERACTION_POINT,
                LocalDateTime.now().plusSeconds(5L * persistTimes));
    }

    @Override
    public void sendToFindReceiverAndMobile(Redemption redemption, LoyaltyStructure loyaltyStructure) {
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("redemptionId", redemption.getId());
        jsonObject.put(MEMBER_ID_TAG, redemption.getMemberId());
        jsonObject.put("partitionKey", redemption.partitionKey());
        jsonObject.put(BRAND_TAG, redemption.brand());
        jsonObject.put("loyaltyStructure", loyaltyStructure.name());
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessageAsync(ServiceBusQueueTopicEnum.C2_FIND_NAME_AND_MOBILE_QUEUE, loyaltyMessage);
    }

    @Override
    public void sendToSyncInventoryToDB(Redemption redemption, Boolean isRefund) {
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        Map<String, Long> giftIssued = redemption.getGiftItemList().stream()
                .collect(Collectors.toMap(GiftItem::getGiftId, giftItem -> (long) giftItem.getQuantity()));
        RedemptionServiceBusProperties updateActivityStock = new RedemptionServiceBusProperties(redemption.getId(),
                redemption.activityId(), isRefund, giftIssued);
        String jsonString = JSON.toJSONString(updateActivityStock);
        JSONObject jsonObject = JSON.parseObject(jsonString);
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.SYNCHRONIZE_REDIS_INVENTORY_TO_DATABASE_QUEUE_NAME, loyaltyMessage);
    }

    private void getBody(String region, String brand, String channel, String pointType, Integer point, String memberId,
                         ArrayList<Object> members, String adjustReason) {
        JSONObject body = new JSONObject();
        body.put("uuid", UUIDUtil.generator());
        body.put(REGION_TAG, region);
        body.put(BRAND_TAG, brand);
        body.put(CHANNEL_TAG, channel);
        body.put("pointType", pointType);
        body.put("point", point);
        body.put(MEMBER_ID_TAG, memberId);
        body.put("adjustReason", adjustReason);
        members.add(body);
    }

    @Override
    public void sendNormalOrderMessageToQueue(String region, String brand, OrderMessage message) {
        serviceBusClient.sendMessage((JSONObject) JSON.toJSON(message), BrandQueueEnum.getQueue(brand, BrandQueueEnum.OrderTypeEnum.NORMAL_ORDER));
    }

    @Override
    public void sendRefundOrderMessageToQueue(String region, String brand, String memberId, RefundDTO refundDTO) {
        JSONObject message = new JSONObject();
        message.put(BRAND_TAG, brand);
        message.put(REGION_TAG, region);
        message.put(MEMBER_ID_TAG, memberId);
        message.put(TRANSACTIONS_TAG, Collections.singleton(refundDTO));
        serviceBusClient.sendMessage(message, BrandQueueEnum.getQueue(brand, BrandQueueEnum.OrderTypeEnum.REFUND_ORDER));
    }

    @Override
    public void delayOrdersRequest(RequestOrdersMessage message, LocalDateTime calculateDateTime) {
        ServiceBusBinder queue = ServiceBusBinder.Q_ORDER_RECALCULATE;
        if (message.allRefundOrders()) {
            queue = ServiceBusBinder.Q_REFUND_ORDER;
        }
        JSONObject jsonObject = (JSONObject) JSON.toJSON(message);
        serviceBusClient.sendScheduleMessage(jsonObject, queue, calculateDateTime);
    }

    @Override
    public void sendDelayEventMsg(Event event, LocalDateTime delayTime) {
        JSONObject message = new JSONObject();
        message.put("sourceId", event.getSourceId());
        message.put("sourcePartitionKey", event.getSourcePartitionKey());
        message.put("eventSourceType", event.getEventSourceType().name());
        message.put("sourceType", event.getSourceType());
        serviceBusClient.sendScheduleMessage(message, ServiceBusBinder.Q_TRANSACTION_EVENT, delayTime);
    }

    @Override
    public void sendMsgToTransactionEventTopic(JSONObject messageBody, Map<String, Object> propertiesMap) {
        serviceBusClient.publishTopicMessage(messageBody, propertiesMap, ServiceBusBinder.T_TRANSACTION_EVENT);
    }
}
