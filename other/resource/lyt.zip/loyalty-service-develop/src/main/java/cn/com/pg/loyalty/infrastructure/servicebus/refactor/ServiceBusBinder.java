package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.Optional;

/**
 * @author tangjia
 * @date 2019/6/6
 * ServiceBusBinder
 */
@NoArgsConstructor
public enum ServiceBusBinder {

    /**
     * q disaster recovery
     */
    Q_DISASTER_RECOVERY,
    /**
     * OLAY 订单
     */
    Q_OLAY_QUEUE_NAME(BrandV2.OLAY),
    /**
     * OLAY 退单队列
     */
    Q_OLAY_REFUND_QUEUE_NAME,

    Q_SKII_ORDER_QUEUE_NAME(BrandV2.SKII),

    Q_ORDER_EVENT,

    Q_ORDER_COMMON_QUEUE_NAME,

    Q_PAMPERS_NORMAL_ORDER,

    Q_ASYNC_ADD_INTERACTION_POINT,

    T_TRANSACTION_CHANGED,

    S_LOGISTICS_REDEMPTION_CONSUMER,
    /**
     * 删除用户队列
     */
    Q_RETENTION_MEMBERIDS,

    Q_MESSAGE_PROCESSOR,

    Q_COUPON_CODE,
    /**
     * pampers 及新品牌使用此订单队列
     */
    Q_NORMAL_ORDER,
    Q_REFUND_ORDER,

    /**
     * 同步积分池
     */
    Q_SYNC_POINT_POOL,

    /*
     * 锁定积分过期
     * */
    Q_POINT_UNLOCK,

    /**
     * 同步消息创建过期记录
     */
    QUEUE_SYNC_EXPIRED,

    QUEUE_PAMPERS_POINT_EXPIRED_CONSUMER,
    /**
     * 使用积分池过期的queue
     */
    QUEUE_EXPIRED_POINT_BY_POOL,


    /**
     * 订单重算队列
     */
    Q_ORDER_RECALCULATE,

    /**
     * olay兑换过期发短信
     */
    Q_OLAY_REDEMPTION_EXPIRED_SEND_MESSAGE,

    T_TRANSACTION_EVENT,

    Q_TRANSACTION_EVENT,
    /**
     * 新logistics发货订阅替代旧的logistics发货Q
     */
    S_DELIVER_GOODS;


    private String orderConsumeBrand;

    ServiceBusBinder(String orderConsumeBrand) {
        this.orderConsumeBrand = orderConsumeBrand;
    }

    public static ServiceBusBinder getOrderConsumeBinder(String brand) {
        Optional<ServiceBusBinder> optional = Arrays.stream(ServiceBusBinder.values())
                .filter(binder -> brand.equals(binder.orderConsumeBrand))
                .findFirst();
        if (!optional.isPresent()) {
            throw new SystemException("The brand not config queue binder", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return optional.get();
    }

    /**
     * 即使查不到也需要返回null
     *
     * @param name
     * @return
     */
    public static ServiceBusBinder fetchBinderByName(String name) {
        try {
            return ServiceBusBinder.valueOf(name);
        } catch (Exception e) {
            return null;
        }
    }

    public enum ServiceBusType {
        /**
         * 队列
         */
        QUEUE,
        /**
         * 主题
         */
        TOPIC,
        /**
         * 订阅
         */
        SUBSCRIBE
    }
}
