package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/6
 */
@Getter
@Setter
public class TireOrderPropertiesV2 extends RuleProperties {


    /**
     * 是否与其他加积分竞争：多个活动取值最高分
     * false: 不参与 直接作为相加中一项
     * true: 参与竞争
     */
    private boolean competition;

    private List<TireRewardRuleConfig> tireRewardRuleConfigs;

    /**
     * 默认赠送积分上限-在倍率积分时使用
     */
    @Min(0)
    private int maximumBonusPoints;

    @Getter
    @Setter
    public static class TireRewardRuleConfig {
        /**
         * 等级id
         */
        private String tierLimit;

        /**
         * 积分计算类型：固定，倍率
         */
        private PointCalculateType pointCalculateType;
        /**
         * 赠送积分倍率
         */
        @Min(0)
        private double bonusPointMultiple;


        /**
         * 固定积分
         */
        @Min(0)
        private int basePoint;
    }


}
