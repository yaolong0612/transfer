package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

/**
 * @author lmr
 */
@Data
public class TierCaculateForLevelChangeLimitProperties {
    /**
     * 是否限制一次升级的等级数
     */
    private boolean upgradeLimit;
    /**
     * 限制一次只能升多少级
     */
    private int upgradeLimitNum;
    /**
     * 是否限制一次降级的等级数
     */
    private boolean reduceLimit;
    /**
     * 限制一次只能降多少级
     */
    private int reduceLimitNum;
}
