package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2022/3/8
 */
@Getter
@Setter
public class AtSpecifiedOrderTimeMultiplePointProperties extends RuleProperties {
    /**
     * 基于第几单
     */
    private Integer baseOrderNum;
    /**
     * 天数限制
     */
    private Integer daysLimit;
    /**
     * 活动期间内与天数限制内的特殊加积分的订单数
     */
    private Integer aimOrderCount;
    /**
     * 加积分倍率
     */
    private Double multiple;

    /**
     *
     */
    private List<String> channels;

    /**
     * 是否参与竞争
     */
    private Boolean competition;
}
