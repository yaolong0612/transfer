package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.ServiceBusService;
import cn.com.pg.loyalty.interfaces.api.ServiceBusApiDelegate;
import cn.com.pg.loyalty.interfaces.dto.DistributeData2ServiceBusCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.validation.Valid;

/**
 * @author vincenzo
 * @description
 * @date 2021/11/25
 */
@Component("ServiceBusFacade")
public class ServiceBusFacade implements ServiceBusApiDelegate {

    @Autowired
    private ServiceBusService serviceBusService;

    @Override
    public ResponseEntity<Void> distributeDataToServiceBus_(@Valid DistributeData2ServiceBusCommand body) {
        serviceBusService.distributeDataToServiceBus(body.getData(), body.getName(), ServiceBusQueueTopicEnum.ServiceBusType.valueOf(body.getType().name()));
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
