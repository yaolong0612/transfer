package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AdjustPointTimesProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.List;
import java.util.Optional;

/**
 * @description: Quarter Interaction Rule
 * @author: Jevons Chen
 * @date: 2020-06-10 11:21
 */

@Rule(name = "Adjust point times per quarter rule template.",
        description = "Adjust point times per quarter rule template.")
@Slf4j
public class AdjustPointTimesPerQuarterRule {

    @Condition
    public boolean isAdjustPointTimesPerQuarterRule(@Fact("pointType") PointType pointType) {
        // 当该活动使用的RuleTemplate 为 AdjustPointTimesPerQuarterRule 才执行下面的@Action逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_TIMES_PER_QUARTER;
    }

    @Action
    public void addPoint(@Fact("loyaltyStructure") LoyaltyStructure structure,
                         @Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("account") Account account,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        Activity activity = activities.get(0);
        AdjustPointTimesProperties timesProperties = (AdjustPointTimesProperties) activity.ruleProperties();
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(LoyaltyDateTimeUtils.getStartDayOfThisQuarter());
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(LoyaltyDateTimeUtils.getEndDayOfThisQuarter());
        List<Interaction> list = interactionRepository.findByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeBetween(interaction.partitionKey(), account.loyaltyId(), activity.pointType(), startAt, endAt);
        Integer limit = Optional.ofNullable(timesProperties.getLimit()).orElse(0);
        if (list.size() >= limit) {
            ruleResult.addException(new SystemException("The times of participation have reached the upper limit of this quarter：" + limit + "，The times of participation are：" + list.size(), ResultCodeMapper.POINT_EXCEED_LIMIT_FREQUENCY));
            return;
        }
        Integer point = timesProperties.addPoint();
        if (Boolean.FALSE.equals(timesProperties.allowNegative()) && point < 0) {
            Integer accountAvailablePoint = account.availablePoint(structure.accountTypeOfDefault());
            if (point + accountAvailablePoint < 0) {
                ruleResult.addException(new SystemException("The requirement of adjusting user's account:" + point + "points，available points are not enough" + accountAvailablePoint, ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                return;
            }
        }
        interaction.addPoint(activity, timesProperties.addPoint());
        ruleResult.success();
    }
}
