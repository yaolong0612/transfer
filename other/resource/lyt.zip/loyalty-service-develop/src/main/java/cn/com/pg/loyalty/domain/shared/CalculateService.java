package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.application.AccountTransactionResult;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Redemption;

import java.util.List;
import java.util.Locale;

public interface CalculateService {

    AccountTransactionResult calculateOrderPoint(PointType pointType, Order order, Account account, LoyaltyStructure loyaltyStructure,
                             List<Activity> activityList, int point);
    AccountTransactionResult calculateRedemption(LoyaltyStructure structure, Redemption redemption, Account account, Activity activity, List<Redemption> redemptionRecords, Locale language);
}

