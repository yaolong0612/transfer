package cn.com.pg.loyalty.application.rulev2.tier;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.account.TierChangeScene.LevelCalculateResult;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.TierCaculateForLevelChangeLimitProperties;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author lmr
 */
@Slf4j
@Component
@Rule(name = "TierCalculateForOnlyChange2NextLevelRule",
        description = "限制用户一次性升降级数", priority = Integer.MIN_VALUE)
@Register(scope = RuleScope.AFTER_LIMIT_RULE, ruleType = RuleType.TIER)
public class TierCalculateForLevelChangeLimitRule {

    private static final RuleTemplate ruleTemplate = RuleTemplate.TIER_CALCULATE_FOR_LEVEL_CHANGE_LIMIT_RULE;


    @Condition
    public boolean validateRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                                @Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, LocalDateTime.now(), ruleTemplate);
        if (CollectionUtils.isEmpty(searchedActivityList)) {
            log.info("匹配到的限制用户只能升降一级活动数为:{}", searchedActivityList.size());
            return Boolean.FALSE;
        }
        TierCaculateForLevelChangeLimitProperties properties = JSON.parseObject(searchedActivityList.get(0).getRuleProperties(), TierCaculateForLevelChangeLimitProperties.class);
        tierChangeScene.initRuleLimitScene();
        return properties.isReduceLimit() || properties.isUpgradeLimit();
    }

    /**
     * 不允许跳级
     */
    @Action
    public void calculateTierForLevelChangeLimit(@Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene,
                                                 @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                                                 @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {

        Activity activity = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, LocalDateTime.now(), ruleTemplate).get(0);
        TierCaculateForLevelChangeLimitProperties properties = JSON.parseObject(activity.getRuleProperties(), TierCaculateForLevelChangeLimitProperties.class);

        LoyaltyStructure loyaltyStructure = tierChangeScene.getStructure();
        String currentLevel = tierChangeScene.getAccount().tier(loyaltyStructure.name()).getLevel();
        List<LevelCalculateResult> levels = tierChangeScene.getLevels();
        boolean doExpire= tierChangeScene.isHandleExpire() && !tierChangeScene.expireAtUnexpiredTime();
        //gapIndex > 0 升级，gapIndex < 0 降级
        for (int i = 0; i < levels.size(); i++) {
            LevelCalculateResult result = levels.get(i);
            int gapIndex = loyaltyStructure.tierLevelSeries().compare(result.level(), currentLevel);
            //升级超过限制
            if (properties.isUpgradeLimit() && gapIndex > properties.getUpgradeLimitNum()) {
                result.updateLevel(loyaltyStructure.tierLevelSeries().nextLevel(currentLevel).getLevelName());
            }
            //降级超过限制
            if (properties.isReduceLimit() && gapIndex < -properties.getReduceLimitNum() && doExpire) {
                result.updateLevel(loyaltyStructure.tierLevelSeries().lastLevel(currentLevel).getLevelName());
            }
        }
        ruleResult.success();
        log.info("限制用户一次性升降级数规则结束");
    }
}
