package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.desenitize.infrastructure.desensitized.filter.DesensitizedSerializeFilter;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-11 21:15
 */

@Component
@Slf4j
public class AmClientSupport {

    private static final String SUCCESS_0 = "0";
    private static final long SAVE_FOR_ONE_MONTH = 7 * 24 * 60 * 60L;
    private static final String REDIS_KEY_PREFIX = "AM:PROFILE:";
    private static final String BABY_ATTR_PROPERTY_BIRTHDAY = "113000001";
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private AmClient amClient;

    public AmClient.OptimizedProfileDTO queryProfile(String memberId, String tenantId) {
        String key = new StringBuilder(REDIS_KEY_PREFIX).append(memberId)
                .append(":").append(tenantId).toString();
        String keyValue = stringRedisTemplate.opsForValue().get(key);
        log.info("am_query_profile_cache_key: {}", key);
        AmClient.OptimizedProfileDTO optimizedProfileDTO;
        if (StringUtils.isNotEmpty(keyValue)) {
            optimizedProfileDTO = JSON.parseObject(keyValue, AmClient.OptimizedProfileDTO.class);
            log.info("am_query_profile_cache_value: {}", JSON.toJSONString(optimizedProfileDTO, new DesensitizedSerializeFilter()));
            return optimizedProfileDTO;
        }
        //调用AM获取用户生日
        long startTime = System.currentTimeMillis();
        AmClient.RequestEntity requestEntity = new AmClient.RequestEntity(memberId, tenantId);
        log.info("Call Am-Service requestBody: {}", JSON.toJSONString(requestEntity));
        AmClient.CallAmResponse response;
        try {
            response = amClient.queryProfile(requestEntity);
            if (!SUCCESS_0.equals(response.getResultCode())) {
                throw new SystemException(response.getErrorMsg(), ResultCodeMapper.CALL_AM_ERROR);
            }
        } catch (Exception ex) {
            log.error(ex.getMessage());
            throw new SystemException(ex.getMessage(), ResultCodeMapper.CALL_AM_ERROR);
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            log.info("Call Am-Service costTime: {}", costTime);
        }
        AmClient.ProfileDTO profileDTO = JSON.parseObject(response.getObject().toJSONString(), AmClient.ProfileDTO.class);
        String fullName = profileDTO.getAddresses().stream()
                .sorted()
                .findFirst().map(AmClient.AddressBean::getFullName).orElse(null);
        profileDTO.setFullName(fullName);
        Optional<String> optionalS = profileDTO.getAttrs().stream()
                .filter(attrBean -> BABY_ATTR_PROPERTY_BIRTHDAY.equals(attrBean.getAttrId()))
                .map(AmClient.AttrBean::getAttrVal).findFirst();
        if (optionalS.isPresent()) {
            List<AmClient.AttrBaby> babies = JSON.parseArray(optionalS.get(), AmClient.AttrBaby.class);
            profileDTO.setBabyBirthdays(babies);
        }
        AmClient.OptimizedProfileDTO newOptimizedProfileDTO = new AmClient.OptimizedProfileDTO();
        BeanUtils.copyProperties(profileDTO, newOptimizedProfileDTO);
        String amJsonString = JSON.toJSONString(newOptimizedProfileDTO);
        //缓存Redis 1天
        stringRedisTemplate.opsForValue().set(key, amJsonString, SAVE_FOR_ONE_MONTH, TimeUnit.SECONDS);
        return newOptimizedProfileDTO;
    }
}
