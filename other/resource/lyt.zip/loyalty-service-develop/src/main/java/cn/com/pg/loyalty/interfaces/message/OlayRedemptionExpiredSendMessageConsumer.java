package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.SmsService;
import cn.com.pg.loyalty.domain.transaction.RedemptionExpiredSendMessage;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author lmr
 */

@Slf4j
@Component
public class OlayRedemptionExpiredSendMessageConsumer extends AbstractConsumerV2 {

    @Autowired
    private SmsService smsService;

    @Override
    protected void doBusiness(JSONObject message) {
        RedemptionExpiredSendMessage redemptionExpiredSendMessage = JSON.toJavaObject(message, RedemptionExpiredSendMessage.class);
        smsService.sendRedemptionExpiredMessage(
                redemptionExpiredSendMessage.getMemberId(),
                redemptionExpiredSendMessage.getAmTenantId(),
                redemptionExpiredSendMessage.getBrand(),
                redemptionExpiredSendMessage.getMonth());
        log.info("OLAY兑换过期发短信完成！");
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_OLAY_REDEMPTION_EXPIRED_SEND_MESSAGE;
    }
}
