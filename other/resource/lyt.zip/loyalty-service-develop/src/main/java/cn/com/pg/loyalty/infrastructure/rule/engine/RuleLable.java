package cn.com.pg.loyalty.infrastructure.rule.engine;

public enum RuleLable {
    REDMPTION,
    GROUP,
    GRADE
}
