package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2020-03-31 16:04
 */
@Data
public class PurchaseRule {

    @NotNull
    @Valid
    private OrderChannel channelName;
    private List<String> storeCodes = new ArrayList<>();
    @Min(0)
    private double baseAmount;

    public enum OrderChannel {
        /**
         * 线下JD
         */
        JD,
        /**
         * 线下TMALL
         */
        TMALL,
        /**
         * 线下柜台
         */
        COUNTER,
        /**
         * 百货商店
         */
        DS,
        /**
         * 商业超市
         */
        ORC,
        /**
         * 临时柜
         */
        TEMPORARY,
        /**
         * 微信渠道
         */
        WECHAT,
        /**
         * 小程序
         */
        WECHAT_MINI_PROGRAM
    }
}
