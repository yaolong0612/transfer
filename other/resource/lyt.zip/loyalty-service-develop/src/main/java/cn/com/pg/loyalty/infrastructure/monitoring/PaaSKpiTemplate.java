package cn.com.pg.loyalty.infrastructure.monitoring;

import cn.com.pg.loyalty.LoyaltyApplication;
import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.paas.monitor.infrastructure.StreamingUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static cn.com.pg.loyalty.application.TransactionService.KPI_ADD_INTERACTION_POINT;
import static cn.com.pg.loyalty.application.TransactionService.KPI_ADD_ORDER_POINT;

/**
 * @author xingliangzhan
 * @date 2019/8/4
 */
@Slf4j
@Primary
@Component
@Conditional(PaasApiMetricConfig.PaasMetricCondition.class)
public class PaaSKpiTemplate implements KpiTemplate {

    private static final String APP_NAME = "app_name";
    private static final String KPI_NAME = "kpi_name";
    private static final String KPI_TYPE = "kpi_type";
    private static final String CORRELATION_ID = "correlation_id";

    @Autowired
    private StreamingUtil streamingUtil;

    @Override
    public void send(HashMap<String, Object> object) {
        streamingUtil.sendKpiEventhub(object);
    }

    @Override
    public void sendConsumingMessage(String messageId, String operationName, LocalDateTime consumingDateTime, long costTime, int errorCode, String errorMsg, String correlationId) {
        HashMap<String, Object> object = new HashMap<>(7);
        object.put(APP_NAME, LoyaltyApplication.APP_NAME);
        object.put(KPI_NAME, operationName);
        object.put(KPI_TYPE, KpiLog.KpiType.CONSUME_SERVICE_BUS);
        object.put("error_code", errorCode);
        object.put("error_message", errorMsg);
        object.put("response_time", costTime);
        object.put(CORRELATION_ID, correlationId);
        streamingUtil.sendKpiEventhub(object);
    }

    @Override
    public void sendDependency(String correlationId, String operationName, KpiLog.KpiType kpiType, LocalDateTime dateTime,
                               long costTime, String resultCode, String message, boolean isSuccess, Map<String, String> properties) {
        HashMap<String, Object> object = new HashMap<>(10);
        object.put(APP_NAME, LoyaltyApplication.APP_NAME);
        object.put(KPI_NAME, operationName);
        object.put(KPI_TYPE, kpiType);
        object.put("error_code", resultCode);
        object.put("error_message", message);
        object.put("response_time", costTime);
        object.put(CORRELATION_ID, correlationId);
        if (properties != null) {
            object.putAll(properties);
        }
        streamingUtil.sendKpiEventhub(object);
    }

    @Override
    public void sendKpi(String memberId, int point, String brand, String kpiName,
                        String channel, PointType pointType, Map<String, String> properties) {
        HashMap<String, Object> object = new HashMap<>(12);
        object.put(APP_NAME, LoyaltyApplication.APP_NAME);
        object.put(KPI_TYPE, KpiLog.KpiType.KPI);
        object.put(KPI_NAME, kpiName);
        if (KPI_ADD_INTERACTION_POINT.equals(kpiName) || KPI_ADD_ORDER_POINT.equals(kpiName)) {
            object.put("union_kpi_name", "EARN_POINT");
        }
        object.put(CORRELATION_ID, RequestContext.getCurrentContext().getCorrelationId());
        object.put("loyalty_send_time", LocalDateTime.now());
        object.put("loyalty_member_id", memberId);
        object.put("loyalty_point", point);
        object.put("loyalty_brand", brand);
        object.put("loyalty_channel", channel == null ? "DEFAULT-CHANNEL" : channel);
        if (pointType != null){
            object.put("loyalty_point_description", pointType.description());
            object.put("loyalty_point_type", pointType.pointType());
            object.put("loyalty_structure", pointType.getLoyaltyStructure());
        }
        if (properties != null) {
            object.putAll(properties);
        }
        streamingUtil.sendKpiEventhub(object);
    }

}
