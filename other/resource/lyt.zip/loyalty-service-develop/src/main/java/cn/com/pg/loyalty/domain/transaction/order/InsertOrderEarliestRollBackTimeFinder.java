package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.structure.OrderImpact;
import cn.com.pg.loyalty.domain.transaction.Order;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class InsertOrderEarliestRollBackTimeFinder implements OrderEarliestRollBackTimeFindAble {
    @Override
    public LocalDateTime findEarliestRollBackTime(OrderImpact orderImpact, List<Order> requestOrders, Map<String, Order> associatedOrdersMap) {
        if (!orderImpact.isInsertBackRoll()) {
            return LocalDateTime.MAX;
        }
        return requestOrders.stream().filter(order -> !associatedOrdersMap.containsKey(order.channelUnitOrderId()))
                .min(Comparator.comparing(Order::getOrderDateTime))
                .map(Order::getOrderDateTime)
                .orElse(LocalDateTime.MAX);
    }
}
