package cn.com.pg.loyalty.application.utils;

/**
 * @author cooltea on 2019/7/3 15:30.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@FunctionalInterface
public interface RetryFunction {
    void retry();
}
