package cn.com.pg.loyalty.infrastructure.monitoring;

import cn.com.pg.paas.monitor.EnableApiMetric;
import cn.com.pg.paas.monitor.EnableHealthPrometheusMvc;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @author tangjia
 * @date 2019/7/25
 * @description PaasApiMetricConfig
 */
@Conditional(PaasApiMetricConfig.PaasMetricCondition.class)
@Configuration
@EnableApiMetric
@EnableHealthPrometheusMvc
public class PaasApiMetricConfig {
    public static class PaasMetricCondition implements Condition {
        @Override
        public boolean matches(ConditionContext conditionContext, AnnotatedTypeMetadata annotatedTypeMetadata) {
            for (String activeProfile : conditionContext.getEnvironment().getActiveProfiles()) {
                if (activeProfile.equals("dev")) {
                    return false;
                }
                if (activeProfile.equals("tw")) {
                    return false;
                }
                if (activeProfile.equals("jp")) {
                    return false;
                }
            }
            return true;
        }
    }
}
