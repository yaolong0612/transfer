package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.structure.OrderImpact;
import cn.com.pg.loyalty.domain.transaction.Order;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@FunctionalInterface
public interface OrderEarliestRollBackTimeFindAble {

    /**
     * 获取最早回滚时间
     * @param orderImpact 订单影响配置
     * @param requestOrders 请求订单
     * @param associatedOrdersMap 请求关联数据库订单
     * @return 最早回滚时间
     */
    LocalDateTime findEarliestRollBackTime(OrderImpact orderImpact,
                                           List<Order> requestOrders,
                                           Map<String, Order> associatedOrdersMap);
}
