package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.activity.prop.PurchaseLimit;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * SKII兑换限制需要有渠道订单规则
 *
 * @author linbj
 * @date 2020/6/16 14:47
 */

@Slf4j
@Rule(name = "限制需要有渠道订单规则",
        description = "限制需要有渠道订单规则", priority = 2)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION, ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
@Component
public class CheckChannelOrderNumLimitRule {

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    @Condition
    public boolean validateRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                                @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                                @Fact(RULE_PARAM_ACTIVITY) Activity activity) {

        return redemption.getGiftItemList().stream()
                .anyMatch(giftItem -> {
                    PurchaseLimit purchaseLimit = properties.fetchPurchaseLimit(activity.getGifts(), giftItem);
                    return checkPurchaseLimit(redemption, purchaseLimit);
                });
    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                            @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        List<GiftItem> giftItemList = redemption.getGiftItemList();
        List<Order> historyOrders = orderRepositoryV2.findMemberOrdersByLoyaltyId(account, redemption.brand());
        for (GiftItem giftItem : giftItemList) {
            String redemptionChannel = redemption.channel();
            PurchaseLimit purchaseLimit = properties.fetchPurchaseLimit(activity.getGifts(), giftItem);
            if(!checkPurchaseLimit(redemption, purchaseLimit)){
                continue;
            }
            Integer purchaseRecords = purchaseLimit.getPurchaseRecords();
            // 统计和redemption的渠道相同的历史订单
            long channelOrderNum = historyOrders.stream()
                    .filter(order -> order.getRealTotalAmount() > 0 && redemptionChannel.equals(order.getChannel())).count();
            if (channelOrderNum < purchaseRecords) {
                StringBuilder msg = new StringBuilder();
                msg.append("you need to purchases ").append(purchaseRecords).append(" time order at ").append(redemptionChannel)
                        .append(", current ").append(channelOrderNum).append(",so that you can join this redemption.");
                log.info(msg.toString());
                throw new SystemException(msg.toString(), ResultCodeMapper.LIMIT_ERROR);
            }
        }
        log.info("兑换按渠道购买限制验证通过: {}, 当前Lable:{}", redemption, properties.fetchLable());
    }

    /**
     * 判断purchaseLimit中是否配置了该规则
     * @param redemption
     * @param purchaseLimit
     * @return
     */
    private boolean checkPurchaseLimit(Redemption redemption, PurchaseLimit purchaseLimit) {
        if(purchaseLimit == null || !PurchaseLimit.RedemptionQualificationType.CHANNEL_ORDER_NUM_LIMIT.equals(purchaseLimit.getRedemptionQualificationType())){
            return false;
        }
        // 渠道设置不为空且redemption的渠道不在限制的渠道内，返回false
        if(!CollectionUtils.isEmpty(purchaseLimit.getChannelsLimit())
                && !purchaseLimit.getChannelsLimit().contains(redemption.channel())){
            return false;
        }
        return true;
    }
}
