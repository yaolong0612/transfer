package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2020-03-05 17:27
 */

@Data
public class PurchaseLimit {

    @NotNull
    @Valid
    private RedemptionQualificationType redemptionQualificationType;
    /**
     * 按月查询
     */
    @Min(0)
    private int month;

    /**
     * 按关联activityId查询指定order
     */
    @NotNull
    private String activityId;

    @NotNull
    @Valid
    private List<PurchaseRule> purchaseRules = new ArrayList<>();
    /**
     * 精确查询开始时间
     */
    private String startAt;
    /**
     * 精确查询结束时间
     */
    private String endAt;
    /**
     * 购买记录数
     */
    @Min(0)
    private Integer purchaseRecords;
    /**
     * 兑换渠道
     */
    @Valid
    private List<String> channelsLimit = new ArrayList<>();

    private List<String> skus=new ArrayList<>();

    public LocalDateTime startAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.startAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.startAt);
        }
        return localDateTime;
    }

    public LocalDateTime endAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.endAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.endAt);
        }
        return localDateTime;
    }

    public Integer getPurchaseRecords() {
        return Optional.ofNullable(this.purchaseRecords).orElse(0);
    }

    /**
     * 查询方式
     */
    public enum RedemptionQualificationType {
        /**
         * 按月查询
         */
        MONTH,
        /**
         * 按精确查询,有起止时间
         */
        ABSOLUTE,
        /**
         * 按关联activityId查询指定order
         */
        ACTIVITY_ID,
        /**
         * 渠道订单数量限制
         */
        CHANNEL_ORDER_NUM_LIMIT
    }
}
