package cn.com.pg.loyalty.application.dependence;

import lombok.Getter;
import lombok.Setter;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@FeignClient(name = "mindTreeClient", url = "${mind-tree.url}")
public interface MindTreeMessageClient {

    /**
     * mindTree 邮件通知
     * @param requestEntity
     * @param mindTreeSubscriptionKey
     */
    @RequestMapping(value = "/api/points-expiration", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "MindTreeMessageClient-sendMessage", type= KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    void sendPointExpiredMessage(List<SendMessageRequestItem> requestEntity, @RequestHeader("Ocp-Apim-Subscription-Key") String mindTreeSubscriptionKey);

    @Getter
    @Setter
    class SendMessageRequestItem{
        String memberId;
        Integer pointsAboutToExpire;
        // yyyy-MM-dd
        String expiryDate;

        public SendMessageRequestItem(String memberId, Integer pointsAboutToExpire, String expiryDate){
            this.memberId = memberId;
            this.pointsAboutToExpire = pointsAboutToExpire;
            this.expiryDate = expiryDate;
        }
    }

}
