package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AdjustPointInComplexConditionProperties;
import cn.com.pg.loyalty.domain.activity.prop.PeriodDateType;
import cn.com.pg.loyalty.domain.activity.prop.shared.DeductPointConditionEnum;
import cn.com.pg.loyalty.domain.activity.prop.shared.PeriodTimesLimit;
import cn.com.pg.loyalty.domain.activity.prop.shared.TierDiscount;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author vincenzo
 * @description
 * @date 2022/1/19
 */
@Rule(name = "INTERACTION_ADJUST_POINT_IN_COMPLEX_CONDITION",
        description = "customer service add point")
@Slf4j
public class AdjustPointInComplexConditionRule {

    private static final String CHANNEL_ALL = "ALL";
    private static final RuleTemplate ruleTemplate = RuleTemplate.INTERACTION_ADJUST_POINT_IN_COMPLEX_CONDITION;
    /**
     * 无折扣率是1
     */
    private static final double NO_DISCOUNT_RATE = 1d;

    @Condition
    public boolean matchCondition(@Fact("pointType") PointType pointType) {
        return pointType.ruleTemplate() == ruleTemplate;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("point") Integer clientPoint,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("account") Account account,
                         @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure,
                         @Fact("pointType") PointType pointType,
                         @Fact("valueType") String valueType,
                         @Fact("reason") String reason,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        // 由于交互活动按积分类型指定，理论上同一个积分类型一个活动，如果多个活动，取最高优先级
        List<Activity> activityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activities, interaction.getCreatedTime(), ruleTemplate);

        Activity activity = activityList.get(0);
        AdjustPointInComplexConditionProperties ruleContent = (AdjustPointInComplexConditionProperties) activity.ruleProperties();
        //是客户端积分调整，且积分调整与预定条件不合法
        Boolean clientAdjust = ruleContent.getClientAdjust();
        if (Boolean.TRUE.equals(clientAdjust) &&
                Boolean.FALSE.equals(ruleContent.getClientAdjustType().doJudgeClientLegal(clientPoint))) {
            ruleResult.addException(new SystemException("adjusting point is illegal! ", ResultCodeMapper.PARAM_ERROR));
            return;
        }
        //匹配发生交互时间是否在在注册时间N天内
        if (!matchRegisterTimeInLimitDays(ruleContent.getRegisterTimeLimitDays(), account, interaction, ruleResult)) {
            return;
        }
        //判断是否满足渠道与次数限制
        if (!matchChannelAndTimes(pointType, account, interaction, ruleContent.getChannels(), ruleContent.getPeriodTimesLimitSet(), interactionRepository, ruleResult)) {
            //渠道或者次数条件不满足，需要给0积分
            return;
        }
        //设置等级并获取折扣值
        String tier = account.tier(loyaltyStructure.name()).getLevel();

        double discount = matchTireDiscount(tier, ruleContent.getTierDiscountConfig());
        //计算积分
        int discountPoint = caculateDiscountPoint(clientPoint, ruleContent.getFixedPoint(), ruleContent.getClientAdjust(), discount);
        int availablePoint = ruleContent.getTransactionValueType().fetchAvailablePoint(loyaltyStructure,account, interaction.getBrand(), valueType);

        Integer finalPoint = null;
        if (discountPoint >= 0) {
            finalPoint = discountPoint;
        } else {
            //扣积分需要校验账上可用积分,根据传参与规则模板设置判断加减过渡积分还是默认积分并获取
            //判断抵扣类型
            finalPoint = caculateFinalPointByDeductCondition(discountPoint, availablePoint, ruleContent.getDeductPointCondition(), ruleResult);
        }

        log.info("clientAdjust:{},valueType:{},会员id：{}，可用积分：{}，会员等级：{}，clientPoint ,point：{},finalPoint:{}",
                clientAdjust, valueType, interaction.getMemberId(),availablePoint , tier, clientPoint, discountPoint, finalPoint);
        //根据规则模板配置设置TransactionValueType
        //判断interaction的TransactionValueType
        // 如果规则模板指定哪种类型就使用哪种类型，
        //如果规则模板指定CLIENT_DECIDE 则需要根据具体入参设置
        ruleContent.getTransactionValueType().doDecideTransactionValueType(loyaltyStructure,valueType, interaction);
        //判断不为null 则赋值
        Optional.ofNullable(finalPoint).ifPresent(item -> {
                    if (Optional.ofNullable(reason).isPresent()) {
                        interaction.addPoint(activity, item.intValue(), reason);
                    } else {
                        interaction.addPoint(activity, item.intValue());
                    }
                    interaction.setCurrentLevel(tier);
                    ruleResult.success();
                }
        );
    }

    private boolean matchRegisterTimeInLimitDays(Integer registerTimeLimitDays, Account account,
                                                 Interaction interaction, RuleResult ruleResult) {
        //注册时间N天内参数为null，表示不限制，返回true
        if (registerTimeLimitDays == null || registerTimeLimitDays == 0) {
            return Boolean.TRUE;
        }
        //registerTimeLimitDays<=0表示非法配置
        if (registerTimeLimitDays < 0) {
            ruleResult.addException(new SystemException("Activity config err", ResultCodeMapper.PARAM_ERROR));
            return Boolean.FALSE;
        }
        LocalDateTime registerDate = LoyaltyDateTimeUtils.getBeginTimeOfDate(account.registryTime(interaction.brand()));
        //生成有效期开始日期-注册当天不算
        LocalDateTime startTime = registerDate.plusDays(1);
        //生成有效期结束日期
        LocalDateTime endTime = LoyaltyDateTimeUtils.getEndTimeOfDay(registerDate.plusDays(registerTimeLimitDays));
        //判断申请加积分时间是否在有效期内
        LocalDateTime currentTime = interaction.getCreatedTime();
        if (currentTime.isBefore(startTime) || currentTime.isAfter(endTime)) {
            log.info("会员: {} 注册时间{}  在当前时间{}由于不在有效期startTime:{}----endTime: {}，不进行加积分流程", account.getMemberId(), registerDate, currentTime, startTime, endTime);
            ruleResult.addException(new SystemException("Not in  effective period", ResultCodeMapper.LIMIT_ERROR));
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }

    /**
     * 匹配渠道与次数条件
     */
    private boolean matchChannelAndTimes(PointType pointType, Account account, Interaction interaction, List<String> limitChannels, List<PeriodTimesLimit> periodTimesLimitSet, InteractionRepository interactionRepository, RuleResult ruleResult) {

        if (!limitChannels.contains(interaction.getChannel()) && !limitChannels.contains(CHANNEL_ALL)) {
            log.info("interaction id: {} ，会员id: {}不满足规则渠道条件{}  ", interaction.getId(), interaction.getMemberId(), limitChannels.toString());
            ruleResult.addException(new SystemException("interaction  渠道:" + interaction.getChannel() + " 不满足渠道条件： " + limitChannels.toString(), ResultCodeMapper.PARAM_ERROR));
            return false;
        }
        if (CollectionUtils.isEmpty(periodTimesLimitSet)) {
            //没有配置表示不限次数
            return true;
        }
        //次数统计
        Map<String, Integer> timesCount = new LinkedHashMap<>();

        Boolean periodTimesStatus = true;
        //任意一个次数条件是false，则返回false
        for (PeriodTimesLimit periodTimesLimit : periodTimesLimitSet) {
            //任意条件满足 则返回true
            PeriodDateType periodDateType = periodTimesLimit.getType();
            String startTime = LoyaltyDateTimeUtils.localDateTimeToString(periodDateType.periodStartDate(interaction.getCreatedTime(), periodTimesLimit.getInterval()));
            String endTime = LoyaltyDateTimeUtils.localDateTimeToString(periodDateType.periodEndDate(interaction.getCreatedTime()));
            List<Interaction> sourceTransactions = interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(interaction.partitionKey(), pointType.getPointType(), account.loyaltyId(), interaction.getBrand(), startTime, endTime);
            //根据渠道过滤交互记录
            List<Transaction> filterTransactions = sourceTransactions.stream().filter(transaction -> limitChannels.contains(transaction.getChannel()) || limitChannels.contains(CHANNEL_ALL)).collect(Collectors.toList());
            timesCount.put(periodDateType.name() + "_Interval" + periodTimesLimit.getInterval() + "_TimesLimit" + periodTimesLimit.getTimes(), filterTransactions.size());
            if (filterTransactions.size() >= periodTimesLimit.getTimes()) {
                periodTimesStatus = false;
            }
        }
        String timesCountStr = JSON.toJSONString(timesCount);
        log.info("积分类型：{} memberid：{}，次数统计：", pointType.getPointType(), interaction.getMemberId(), timesCountStr);
        if (Boolean.FALSE.equals(periodTimesStatus)) {
            ruleResult.addException(new SystemException("adjust point exceed times limit: " + timesCountStr, ResultCodeMapper.ACTIVITY_EXCEED_TIMES));
        }
        return periodTimesStatus;

    }

    /**
     * 匹配等级折扣
     *
     * @return
     */
    private double matchTireDiscount(String currentTire, List<TierDiscount> tierDiscountConfig) {
        //未配置等级折扣，直接返回1
        if (CollectionUtils.isEmpty(tierDiscountConfig)) {
            return NO_DISCOUNT_RATE;
        }
        Optional<TierDiscount> tireDiscount = tierDiscountConfig.stream().filter(config -> currentTire.equals(config.getTierLimit())).findFirst();
        // 等级折扣存在取等级折扣，不存在则返回1
        return tireDiscount.isPresent() ? tireDiscount.get().getDiscount() : NO_DISCOUNT_RATE;
    }

    /**
     * 根据折扣计算积分
     *
     * @param clientPoint
     * @param fixedPoint
     * @param clientAdjust
     * @param discount
     * @return
     */
    private int caculateDiscountPoint(Integer clientPoint, Integer fixedPoint, boolean clientAdjust, double discount) {
        int basePoint = clientAdjust ? clientPoint : fixedPoint;
        return (int) Math.ceil(basePoint * discount);

    }

    /**
     * 根据抵扣条件获取最后积分
     */
    private Integer caculateFinalPointByDeductCondition(int decuctPoint, int availablePoint, DeductPointConditionEnum deductPointCondition, RuleResult ruleResult) {


        Integer finalPoint = null;
        int remainPoint = availablePoint + decuctPoint;
        switch (deductPointCondition) {
            //只允许扣到0
            case DEDUCT_ZERO_POINT:
                /**
                 * 账号上可用积分<=0,不能做扣减积分操作
                 */
                if (availablePoint <= 0) {
                    ruleResult.addException(new SystemException("member have no available point", ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                    return null;
                }
                finalPoint = remainPoint < 0 ? -availablePoint : decuctPoint;
                break;
             //允许扣负分-多次
            case DEDUCT_NEGATIVE_POINT:
                finalPoint = decuctPoint;
                break;
             //不允许扣负分
            case DEDUCT_NEGATIVE_POINT_ERR:
                if (remainPoint < 0) {
                    ruleResult.addException(new SystemException(" rule do not allow deduct point to  negative", ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                }
                finalPoint = decuctPoint;
                break;
        }
        return finalPoint;

    }

}
