package cn.com.pg.loyalty.domain.activity.prop;


import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BaseTierProperties extends RuleProperties {
    //等级配置
    private TierChangeSeries tierLevels;
    //计算方式
    private CalculateWay calculateWay;
    //统计范围
    private int calculateCountInterval;
    //最小开始统计时间
    private LocalDateTime minCountStartTime;

    public enum CalculateWay {
        /**
         * 按所有积分统计
         */
        BY_ALL_COUNT {
            @Override
            LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval, LocalDateTime tierChangeTime) {
                return LocalDateTime.MIN;
            }
        },

        /**
         * 按年统计计算
         */
        BY_YEAR_COUNT {
            @Override
            LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval, LocalDateTime tierChangeTime) {
                return endTime.minusYears(calculateCountInterval);
            }
        },

        /**
         * 按等级变更后获取的累加值
         */
        BY_ACCUMULATE_AFTER_TIER_CHANGE {
            @Override
            LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval, LocalDateTime tierChangeTime) {
                return tierChangeTime;
            }
        };

        abstract LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval, LocalDateTime tierChangeTime);
    }

    public LocalDateTime getCountStartTime(LocalDateTime endTime, LocalDateTime tierChangeTime) {
        return calculateWay.startAt(endTime, calculateCountInterval, tierChangeTime);
    }

    public static class TierChangeSeries extends ArrayList<TierScoreNode> {

        public String calculateTier(int tierScore, TierLevelSeries tierLevelSeries) {
            for (TierScoreNode tierScoreNode : this) {
                if (tierScoreNode.inScope(tierScore)) {
                    return tierScoreNode.getTierLevel();
                }
            }
            return tierLevelSeries.firstTierLevel();
        }

        public String getMaxChangeLevel(){
            return this.get(this.size()-1).tierLevel;
        }


    }

    @Data
    public static class TierScoreNode {
        public static final int BOUND_MIN = 0;
        /**
         * 等级名称
         */
        private String tierLevel;
        /**
         * 升级所需的金额或积分
         */
        private int upgradeScore;
        /**
         * 保级所需要的金额或积分
         */
        private int gradingScore;

        protected boolean inScope(int tierScore) {
            return tierScore >= gradingScore && (tierScore < upgradeScore || upgradeScore < gradingScore);
        }

    }

}
