package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AdjustPointTimesProperties;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;

import java.util.List;
import java.util.Optional;

/**
 * @author cooltea
 */
@Rule(name = "Adjust point times per day rule template.",
        description = "Adjust point times per day rule template.")
@Slf4j
public class AdjustPointTimesPerDayRule {

    @Condition
    public boolean isAdjustPointTimesPerDayRule(@Fact("pointType") PointType pointType) {
        // 校验是否为当前积分模板，true才执行下面逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_TIMES_PER_DAY;
    }

    @Action
    public void addPoint(@Fact("loyaltyStructure") LoyaltyStructure structure,
                         @Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("account") Account account,
                         @Fact("point") Integer point,
                         @Fact("interactionRepository") InteractionRepository interactionRepository) {
        Activity activity = activities.get(0);
        AdjustPointTimesProperties timesProperties = (AdjustPointTimesProperties) activity.ruleProperties();
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(LoyaltyDateTimeUtils.getBeginTimeOfToday());
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(LoyaltyDateTimeUtils.getEndTimeOfToday());
        List<Interaction> list = interactionRepository.findByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeBetween(interaction.partitionKey(), account.loyaltyId(), activity.pointType(), startAt, endAt);
        Integer limit = Optional.ofNullable(timesProperties.getLimit()).orElse(0);
        if (list.size() >= limit) {
            ruleResult.addException(new SystemException("The times of participation have reached the upper limit today：" + limit + "，The times of participation are：" + list.size(), ResultCodeMapper.POINT_EXCEED_LIMIT_FREQUENCY));
            return;
        }
        if (Boolean.FALSE.equals(timesProperties.allowNegative()) && point < 0) {
            Integer accountAvailablePoint = account.availablePoint(structure.accountTypeOfDefault());
            if (point + accountAvailablePoint < 0) {
                ruleResult.addException(new SystemException("The requirement of adjusting user's account :" + point + "points ，available points are not enough" + accountAvailablePoint, ResultCodeMapper.NOT_ENOUGH_POINT_ERROR));
                return;
            }
        }
        interaction.addPoint(activity, point);
        ruleResult.success();
    }
}
