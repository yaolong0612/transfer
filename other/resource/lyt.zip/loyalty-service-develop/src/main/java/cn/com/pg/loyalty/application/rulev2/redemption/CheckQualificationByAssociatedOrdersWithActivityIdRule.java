package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.CommonProperties;
import cn.com.pg.loyalty.domain.activity.prop.PurchaseLimit;
import cn.com.pg.loyalty.domain.activity.prop.PurchaseRule;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @description: (Olay)超级宠粉日兑换规则
 * @author: Jevons Chen
 * @date: 2020-03-30 16:54
 */

@Slf4j
@Rule(name = "Super Member Day Rule",
        description = "Calculate Redemption Qualification for finding Orders by Associated ActivityId",
        priority = 2)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION, ruleLables = {RuleLable.GROUP, RuleLable.GRADE})
@Component
public class CheckQualificationByAssociatedOrdersWithActivityIdRule {
    @Autowired
    private OrderRepositoryV2 orderRepository;
    @Autowired
    private CacheService cacheService;

    @Condition
    public boolean matchRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                             @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                             @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        return redemption.getGiftItemList().stream()
                .anyMatch(giftItem -> checkPurchaseLimit(properties.fetchPurchaseLimit(activity.getGifts(), giftItem)));
    }

    @Action
    public void executeRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RULE_PARAM_REDEMPTION_PROPERTIES) CommonProperties properties,
                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_ACTIVITY) Activity activity) {
        List<GiftItem> giftItemList = redemption.getGiftItemList();
        //一个redemption可以有多个礼品，可能分属不同组和挡位，有不同的限制规则，所以需要分别做比对
        for (GiftItem giftItem : giftItemList) {
            //获取每个礼品对应的 组/挡位 的限制规则
            PurchaseLimit purchaseLimit = properties.fetchPurchaseLimit(activity.getGifts(), giftItem);
            if (!checkPurchaseLimit(purchaseLimit)) {
                continue;
            }
            log.info("ByAssociatedOrdersWithActivityId规则：{}", JSON.toJSONString(purchaseLimit));
            // 根据限制的活动Id查询指定订单活动
            Activity orderActivity = cacheService.findActivityById(purchaseLimit.getActivityId());
            if (orderActivity == null) {
                log.info("关联activityId:{}不存在", purchaseLimit.getActivityId());
                throw new SystemException("related activityId not exists", ResultCodeMapper.PARAM_ERROR);
            }
            // 根据订单活动的开始结束时间查询用户的订单
            List<Order> orderRecords = orderRepository.findOrdersByOrderDateTimeBetween(account.loyaltyId(),
                    orderActivity.getStartAt(), orderActivity.getEndAt());
            //过滤团购及refund记录(point>0)
            orderRecords = orderRecords.stream().filter(order1 -> order1.getPoint() > 0).collect(Collectors.toList());
            //返回和activityId关联的orders
            List<Order> associatedOrders = filterOrdersByActivityId(orderRecords, orderActivity.getId());
            Order associatedOrder = associatedOrders.stream().min(Comparator.comparing(Order::getOrderDateTime))
                    .orElseThrow(() -> new SystemException("Can't find the related orders of festival days",
                            ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS));

            List<PurchaseRule> purchaseRules = purchaseLimit.getPurchaseRules();
            String orderChannel = associatedOrder.getChannel();
            if (ChannelV2.COUNTER.equals(associatedOrder.getChannel())) {
                //先筛选出规则中Counter选项里storeCode集合，若包含着关联订单中的storeCode则直接匹配相应counter规则内的金额
                Optional<String> isExists = purchaseRules.stream()
                        .flatMap(purchaseRule -> purchaseRule.getStoreCodes().stream()
                                .filter(storeCode -> storeCode.equalsIgnoreCase(associatedOrder.getStoreCode())))
                        .findAny();
                if (!isExists.isPresent()) {
                    //若不包含关联订单中的storeCode则匹配DS/ORC规则内的金额
                    orderChannel = mapToDSAndORCByStoreCode(cacheService, associatedOrder);
                    if (orderChannel == null) {
                        log.info("关联订单storeCode:{}匹配失败", associatedOrder.getStoreCode());
                        throw new SystemException("Unqualified to participate in redemption because StoreCode is not matched", ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS);
                    }
                }
            }
            PurchaseRule candidatePurchaseRule = null;
            for (PurchaseRule purchaseRule : purchaseRules) {
                if (null != purchaseRule.getChannelName()) {
                    if (!purchaseRule.getChannelName().name().equalsIgnoreCase(orderChannel)) {
                        continue;
                    }
                }
                List<String> storeCodes = purchaseRule.getStoreCodes();
                if (storeCodes.size() > 0) {
                    if (!storeCodes.contains(associatedOrder.getStoreCode())) {
                        continue;
                    }
                }
                candidatePurchaseRule = purchaseRule;
                break;
            }
            if (candidatePurchaseRule == null) {
                log.info("关联订单{}来自{}柜台编号{}购买规则未匹配成功", associatedOrder.getOrderId(), associatedOrder.channel(), associatedOrder.getStoreCode());
                throw new SystemException("Unqualified to participate in redemption because fails to match the rule of the limitation of pruchase with correspond orders", ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS);
            }
            //开始验证金额
            if (candidatePurchaseRule.getBaseAmount() > associatedOrder.getRealTotalAmount()) {
                log.info("关联订单{}金额{}未达到规定金额{}", associatedOrder.getOrderId(), associatedOrder.realTotalAmount(), candidatePurchaseRule.getBaseAmount());
                throw new SystemException("Unqualified to participate in redemption because the total amount of related orders is below the criteria", ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS);
            }
        }
        log.info("兑换按活动购买限制验证通过: {}, 当前Lable:{}", redemption, properties.fetchLable());
    }

    /**
     * 返回和activityId关联的orders
     *
     * @param historyOrders
     * @param activityId
     * @return
     */
    private List<Order> filterOrdersByActivityId(List<Order> historyOrders, String activityId) {
        List<Order> associatedOrders = new ArrayList<>();
        for (Order historyOrder : historyOrders) {
            List<PointItem> pointItems = historyOrder.getPointItems();
            for (PointItem pointItem : pointItems) {
                if (activityId.equalsIgnoreCase(pointItem.getActivityId())) {
                    associatedOrders.add(historyOrder);
                    break;
                }
            }
        }
        return associatedOrders;
    }

    private String mapToDSAndORCByStoreCode(CacheService cacheService, Order originalOrder) {
        //映射DS/ORC
        Store store = cacheService.getStoreByStoreCode(originalOrder.getStoreCode());
        if (null == store) {
            log.info("订单{}根据{}未找到对应的storeType", originalOrder.getOrderId(), originalOrder.getStoreCode());
            return null;
        }
        Store.LoyaltyStoreTypeEnum storeTypeEnum = store.storeType();
        String orderChannel = storeTypeEnum.name();
        log.info("订单{}来自{}柜台编号{}", originalOrder.getOrderId(), orderChannel, originalOrder.getStoreCode());
        return orderChannel;
    }

    /**
     * 判断purchaseLimit中是否配置了该规则
     * @param purchaseLimit
     * @return
     */
    private boolean checkPurchaseLimit(PurchaseLimit purchaseLimit) {
        return purchaseLimit != null &&
                PurchaseLimit.RedemptionQualificationType.ACTIVITY_ID.equals(purchaseLimit.getRedemptionQualificationType());
    }
}
