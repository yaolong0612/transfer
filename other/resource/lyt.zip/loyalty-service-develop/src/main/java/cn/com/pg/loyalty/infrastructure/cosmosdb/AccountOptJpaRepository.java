package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.account.AccountExtension.PartnerType;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * @Author: Hayden
 * @CreateDate: 2021/3/5 16:59
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/5 16:59
 * @Version: 1.0
 * @Description:
 */
@Repository
public interface AccountOptJpaRepository extends DocumentDbRepository<AccountOpt, String> {

    List<AccountOpt> findAccountOptByLoyaltyIdAndType(String id, PartnerType type);
}
