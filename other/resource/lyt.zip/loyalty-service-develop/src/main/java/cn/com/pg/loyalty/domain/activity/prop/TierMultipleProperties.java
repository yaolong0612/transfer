package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-05 21:22
 */

@Getter
@Setter
public class TierMultipleProperties extends RuleProperties {

    /**
     * 是否参与竞争
     */
    private boolean competition;
    /**
     * 默认赠送积分上限2000
     */
    @Min(0)
    private int maximumBonusPoints;
    /**
     * 默认铂金会员赠送积分0.2倍积分
     */
    @Min(0)
    private double platinumBonusPointMultiple;
    /**
     * 默认钻石会员赠送积分0.4倍积分
     */
    @Min(0)
    private double diamondBonusPointMultiple;

}
