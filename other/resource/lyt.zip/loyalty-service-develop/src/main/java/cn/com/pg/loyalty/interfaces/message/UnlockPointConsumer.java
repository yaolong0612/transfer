package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountService;
import cn.com.pg.loyalty.domain.account.UnlockPointMessage;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UnlockPointConsumer extends AbstractConsumerV2{
    @Autowired
    private AccountService accountService;

    @Override
    protected void doBusiness(JSONObject message) {
        log.info("接收到锁定积分过期消息");
        UnlockPointMessage unlockPointMessage = JSON.toJavaObject(message, UnlockPointMessage.class);
        accountService.unlockPointAndAddPointAvailable(
                unlockPointMessage.getLoyaltyId(),
                unlockPointMessage.getBrand(),
                unlockPointMessage.getUnlockTime());
        log.info("锁定积分过期完成");
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_POINT_UNLOCK;
    }
}
