package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@NoArgsConstructor
public class TierLevelSeries {
    public static final String MUST_MULTIPLE_LEVEL = "Must multiple level";
    private List<TierLevel> tierLevels;
    private TierChangeType tierChangeType;
    private int tierEffectiveYear;
    private TierExpiredWay tierExpiredWay;

    private CalculateWay calculateWay;

    private int calculateCountInterval;


    public TierLevelSeries(TierChangeType tierChangeType, TierExpiredWay tierExpiredWay,
                           int tierEffectiveYear, List<TierLevel> tierLevels,
                           CalculateWay calculateWay, int calculateCountInterval) {
        if (CollectionUtils.isEmpty(tierLevels)) {
            throw new SystemException("Not config tier levels", ResultCodeMapper.PARAM_ERROR);
        }
        this.tierLevels = tierLevels.stream().sorted(Comparator.comparing(TierLevel::getLevel))
                .collect(Collectors.toList());
        this.tierChangeType = tierChangeType;
        this.tierEffectiveYear = tierEffectiveYear;
        this.tierExpiredWay = tierExpiredWay;
        this.calculateWay = calculateWay;
        this.calculateCountInterval = calculateCountInterval;
        this.tierChangeType.validTierLevels(this.tierLevels);
    }

    public enum TierChangeType {
        /**
         * 等级不过期
         */
        NONE {
            @Override
            void validTierLevels(List<TierLevel> tierLevels) {
                if (tierLevels.size() == 1) {
                    return;
                }
                throw new SystemException("Tier not expire only need default tier", ResultCodeMapper.PARAM_ERROR);
            }
        },
        /**
         * 通过积分计算
         */
        BY_POINT {
            @Override
            void validTierLevels(List<TierLevel> tierLevels) {
                if (tierLevels.size() < 2) {
                    throw new SystemException(MUST_MULTIPLE_LEVEL, ResultCodeMapper.PARAM_ERROR);
                }
            }
        },
        /**
         * 通过订单金额计算
         */
        BY_ORDER_AMOUNT {
            @Override
            void validTierLevels(List<TierLevel> tierLevels) {
                if (tierLevels.size() < 2) {
                    throw new SystemException("Must multiple level ", ResultCodeMapper.PARAM_ERROR);
                }
            }
        },
        /**
         * 通过金额与积分竞争
         */
        BY_AMOUNT_POINT_MAX {
            @Override
            void validTierLevels(List<TierLevel> tierLevels) {
                if (tierLevels.size() < 2) {
                    throw new SystemException("Must multiple level ", ResultCodeMapper.PARAM_ERROR);
                }
            }
        };

        abstract void validTierLevels(List<TierLevel> tierLevels);
    }

    public enum TierExpiredWay {
        /**
         * 每天过期
         */
        BY_DAY() {
            @Override
            public LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getEndTimeOfDay(tierChangeTime.plusYears(pointEffectiveYear));
            }
        },
        /**
         * 每月过期
         */
        BY_MONTH() {
            @Override
            public LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getLastDayOfThisMonth(tierChangeTime.plusYears(pointEffectiveYear));
            }
        },
        /**
         * 每年过期
         */
        BY_YEAR() {
            @Override
            public LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getLastDayOfYear(tierChangeTime.plusYears(pointEffectiveYear));
            }
        },
        /**
         * 每年过期
         */
        BY_FISCAL_YEAR() {
            @Override
            public LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getEndDayOfFiscalYear(tierChangeTime).plusYears(pointEffectiveYear);
            }
        },
        /**
         * 不过期
         */
        NONE() {
            @Override
            public LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getLoyaltyInternalMaxDateTime();
            }
        };


        abstract LocalDateTime expiredDate(LocalDateTime tierChangeTime, int pointEffectiveYear);

    }

    public enum CalculateWay {
        /**
         * 按年统计计算
         */
        BY_YEAR_COUNT {
            @Override
            LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval) {
                return endTime.minusYears(calculateCountInterval);
            }
        },

        /**
         * 按等级变更后获取的累加值
         */
        BY_ACCUMULATE_AFTER_TIER_CHANGE {
            @Override
            LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval) {
                return null;
            }
        };

        abstract LocalDateTime startAt(LocalDateTime endTime, int calculateCountInterval);

    }

    public LocalDateTime getCountStartTime(LocalDateTime localDateTime) {
        return calculateWay.startAt(localDateTime, calculateCountInterval);
    }


    public int tierLevelNums() {
        return tierLevels.size();
    }

    /**
     * 获取第一个等级
     */
    public String firstTierLevel() {
        return this.tierLevels.get(0).getLevelName();
    }

    /**
     * 计算下一个等级:按金额
     */
    public TierLevel nextLevelByAmount(String curLevelName, int tierAmount) {
        int index = this.indexOfLevel(curLevelName);
        TierLevel tierLevel = this.tierLevels.get(index);

        if (TierChangeType.NONE.equals(this.tierChangeType)) {
            return tierLevel;
        }
        if (TierChangeType.BY_POINT.equals(this.tierChangeType)) {
            return tierLevel;
        }

        if (tierLevel.upgradeLevelByAmount(tierAmount)) {
            return getLevelByIndex(index + 1);
        }
        if (tierLevel.gradingLevelByAmount(tierAmount)) {
            return tierLevel;
        }
        return getLevelByIndex(index - 1);
    }

    /**
     * 计算下一个等级: 按积分
     */
    public TierLevel nextLevelByPoint(String curLevelName, int tierPoint) {
        int index = this.indexOfLevel(curLevelName);
        TierLevel tierLevel = this.tierLevels.get(index);

        if (TierChangeType.NONE.equals(this.tierChangeType)) {
            return tierLevel;
        }
        if (TierChangeType.BY_ORDER_AMOUNT.equals(this.tierChangeType)) {
            return tierLevel;
        }
        if (tierLevel.upgradeLevelByPoint(tierPoint)) {
            return getLevelByIndex(index + 1);
        }
        if (tierLevel.gradingLevelByPoint(tierPoint)) {
            return tierLevel;
        }
        return getLevelByIndex(index - 1);
    }

    public TierLevel nextLevel(TierChangeType tierChangeType, String curLevelName, int tierScore) {
        if (TierChangeType.BY_ORDER_AMOUNT.equals(tierChangeType)) {
            return nextLevelByAmount(curLevelName, tierScore);
        }
        if (TierChangeType.BY_POINT.equals(tierChangeType)) {
            return nextLevelByPoint(curLevelName, tierScore);
        }
        int index = this.indexOfLevel(curLevelName);
        return this.tierLevels.get(index);
    }


    public TierLevel lastLevel(String curLevelName) {
        int index = this.indexOfLevel(curLevelName);
        return getLevelByIndex(index - 1);
    }


    public TierLevel nextLevel(String curLevelName) {
        int index = this.indexOfLevel(curLevelName);
        return getLevelByIndex(index + 1);
    }

    public TierLevel currentLevel(String curLevelName) {
        int index = this.indexOfLevel(curLevelName);
        return getLevelByIndex(index);
    }

    /**
     * 等级比较
     */
    public int compare(String levelName1, String levelName2) {
        int index1 = this.indexOfLevel(levelName1);
        int index2 = this.indexOfLevel(levelName2);
        return index1 - index2;
    }


    public int calculateUpgradeAwardPoints(String preLevel, int levelGap) {
        int awardPoints = 0;
        TierLevel nextTierLevel = getLevelByName(preLevel);
        for (int i = 0; i < levelGap; i++) {
            if (nextTierLevel.getUpgradeAmount() <= 0) {
                break;
            }
            nextTierLevel = nextLevel(nextTierLevel.getLevelName());
            awardPoints += nextTierLevel.getUpgradeAward();
        }
        return awardPoints;
    }

    public int calculateRefundAwardPoints(String preLevel, int levelGap) {
        int refundPoints = 0;
        TierLevel lastTierLevel = getLevelByName(preLevel);
        for (int i = 0; i < levelGap; i++) {
            if (lastTierLevel.getGradingAmount() <= 0) {
                break;
            }
            refundPoints += lastTierLevel.getUpgradeAward();
            lastTierLevel = lastLevel(lastTierLevel.getLevelName());
        }
        return refundPoints;
    }

    public boolean hasTierLevel(String levelName) {
        return tierLevels.stream().anyMatch(tierLevel -> StringUtils.equals(levelName, tierLevel.getLevelName()));
    }


    /**
     * 获取还需要保级积分，如果已经保级了，返回0
     *
     * @return 保级积分
     */
    public int gradingPoint(String levelName, int tierPoint) {
        TierLevel tierLevel = getLevelByName(levelName);
        int gradingPoint = tierLevel.getGradingAmount();
        return Math.max(gradingPoint - tierPoint, 0);
    }

    /**
     * 获取需要升级的积分（还需要多少积分升级。如果是最高等级，返回0）
     *
     * @return 升级积分
     */
    public int upgradePoint(String levelName, int tierPoint) {
        TierLevel tierLevel = getLevelByName(levelName);
        int upgradePoint = tierLevel.getUpgradeAmount();
        return Math.max(upgradePoint - tierPoint, 0);
    }

    /**
     * 首个等级不过期
     */
    public LocalDateTime tierExpireDate(String curLevelName) {
        int index = this.indexOfLevel(curLevelName);
        if (index == 0) {
            return LoyaltyDateTimeUtils.getLoyaltyInternalMaxDateTime();
        }
        return this.tierExpiredWay.expiredDate(LocalDateTime.now(), tierEffectiveYear);
    }

    /**
     * 首个等级不过期
     */
    public LocalDateTime tierExpireDate(String curLevelName, LocalDateTime changeTime) {
        int index = this.indexOfLevel(curLevelName);
        if (index == 0) {
            return LoyaltyDateTimeUtils.getLoyaltyInternalMaxDateTime();
        }
        return this.tierExpiredWay.expiredDate(changeTime, tierEffectiveYear);
    }

    public TierLevel getLevelByName(String levelName) {
        return tierLevels.get(indexOfLevel(levelName));
    }

    public TierLevel getLevelByIndex(int index) {
        if (index < 0) {
            index = 0;
        } else if (index >= tierLevels.size()) {
            index = tierLevels.size() - 1;
        }
        return tierLevels.get(index);

    }

    private int indexOfLevel(String curLevelName) {
        for (int i = 0; i < this.tierLevels.size(); i++) {
            if (StringUtils.equals(tierLevels.get(i).getLevelName(), curLevelName)) {
                return i;
            }
        }
        throw new SystemException("not exist the level name:" + curLevelName, ResultCodeMapper.PARAM_ERROR);
    }


}
