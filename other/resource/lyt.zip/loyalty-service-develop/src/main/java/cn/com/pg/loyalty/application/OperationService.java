package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.utils.RetryTemplate;
import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.PointExpire;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.PointValueObject.PointValue;
import cn.com.pg.loyalty.interfaces.dto.AccountDeletedInBatchCommand;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-09-04 22:43
 */

@Service
@Slf4j
public class OperationService {

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private MessageService messageService;

    @Autowired
    private AccountRepository accountRepository;
    //skii的过期规则活动只有一个
    private AtomicReference<String> activityId = new AtomicReference<>();
    @Autowired
    private LogRepository logRepository;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private AccountOptRepository accountOptRepository;
    @Autowired
    private CacheService cacheService;

    private static final String REGISTRY = "REGISTER";
    private static final String SYSTEM_EXPIRED_POINT = "SYSTEM_EXPIRED_POINT";

    public void memberMerge(String originalMemberId, String targetMemberId, String region, String brand) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account originalAccount = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, originalMemberId);
        Account targetAccount = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, targetMemberId);

        String originalTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(originalAccount.loyaltyId());
        String targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        //查询源账号积分记录
        List<Transaction> originalTransactions = transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(originalTransactionPartitionKey, originalAccount.loyaltyId());
        if (CollectionUtils.isNotEmpty(originalTransactions)) {
            for (Transaction originalTransaction : originalTransactions) {
                log.info("开始删除源账号{}积分记录{}", originalTransaction.getMemberId(), originalTransaction.getId());
                originalTransaction.setPartitionKey(targetTransactionPartitionKey);
                originalTransaction.setLoyaltyId(targetAccount.loyaltyId());
                originalTransaction.setMemberId(targetAccount.getMemberId());
                //找到源账号的积分记录迁移到新账号中
                RetryTemplate.noResultRetry(() -> transactionRepository.save(originalTransaction), 1);
                //迁移到新账号记录后，从原账号记录中删除。防止save成功但delete失败，就准备retry1次
                RetryTemplate.noResultRetry(() -> transactionRepository.deleteById(originalTransaction.getId(), originalTransactionPartitionKey), 1);
                log.info("删除源账号成功");
            }
        }
        //源账号积分迁移新账号
        targetAccount.mergeAccount(originalAccount, brand);
        RetryTemplate.noResultRetry(() -> accountRepository.save(targetAccount), 1);
        RetryTemplate.noResultRetry(() -> accountRepository.delete(originalAccount), 1);
        log.info("会员合并处理完毕");
    }


    public Interaction findCodeUsedRecord(String qrCode, String brand) {
        List<Interaction> interactionList = interactionRepository.findByQrCodeAndBrand(qrCode, brand);
        if (CollectionUtils.isEmpty(interactionList)) {
            throw new SystemException(ResultCodeMapper.QRCODE_NOT_FOUND);
        }
        return interactionList.get(0);
    }

    public void sendAccounts2Bus(AccountDeletedInBatchCommand body) {
        JSONObject message = (JSONObject) JSON.toJSON(body);
        messageService.send2DeleteMembersForSkii(message);
    }

    private Account fetchAccountsByMemberIdAndLoyaltyStructure(LoyaltyStructure loyaltyStructure, String targetMemberId,
                                                               String region,
                                                               String brand, LocalDateTime registryTime,
                                                               String channel, String bindId) {
        Account account = accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId);
        if (account == null) {
            Account.RegistryEvent registryEvent = Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT;
            account = accountService.register(targetMemberId, brand, channel, bindId,
                    registryTime, region, null, registryEvent);
        }
        account.updateRegistryTime(registryTime, brand);
        return account;
    }

    private List<Account> fetchAccountsByMemberIdsAndLoyaltyStructure(LoyaltyStructure loyaltyStructure,
                                                                      List<String> originalMemberIds) {
        List<Account> accounts = new ArrayList<>();
        for (String memberId : originalMemberIds) {
            Account originalAccount = accountService.fetchAccountByMemberId(loyaltyStructure, memberId);
            if (originalAccount != null) {
                accounts.add(originalAccount);
            }
        }
        return accounts;
    }

    private List<Transaction> fetchTransactionsByMemberId(Account targetAccount) {
        String targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        //查询目标账号积分记录
        return transactionRepository
                .findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey, targetAccount.loyaltyId());
    }

    private List<Transaction> fetchTransactionsByMemberIds(List<Account> originalAccounts) {
        List<Transaction> originalTransactions = new ArrayList<>();
        for (Account account : originalAccounts) {
            String originalPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
            List<Transaction> transactions = transactionRepository
                    .findTransactionsByPartitionKeyAndLoyaltyId(originalPartitionKey, account.loyaltyId());
            originalTransactions.addAll(transactions);
        }
        return originalTransactions;
    }

    private void mergeTransactions(List<Transaction> targetTransactions, List<Transaction> originalTransactions,
                                   Account targetAccount) {
        for (Transaction originalTransaction : originalTransactions) {
            if (REGISTRY.equals(originalTransaction.getPointType())) {
                List<Transaction> existedRegistryRecord = targetTransactions.stream()
                        .filter(transaction -> REGISTRY.equals(transaction.getPointType())).collect(Collectors.toList());
                if (!existedRegistryRecord.isEmpty()) {
                    continue;
                }
            }
            originalTransaction.updateInfo(targetAccount.getId(),
                    targetAccount.getMemberId(), PartitionKeyUtils.getTransactionPartitionKey(targetAccount.getId()));
            targetTransactions.add(originalTransaction);
        }
    }

    private void saveTargetTransactions(List<Transaction> targetTransactions) {
        for (Transaction targetTransaction : targetTransactions) {
            if (SYSTEM_EXPIRED_POINT.equals(targetTransaction.getPointType())) {
                continue;
            }
            RetryTemplate.noResultRetry(() -> transactionRepository.save(targetTransaction), 1);
        }
    }

    private void saveTargetAccounts(Account targetAccount) {
        RetryTemplate.noResultRetry(() -> accountRepository.save(targetAccount), 1);
    }

    private void deleteOriginalAccountsInfos(List<Account> originalAccounts) {
        messageService.sendMessageForDeleteMemberInfo(originalAccounts, BrandV2.SKII);
    }

    public AccountOpt mergeAccountOpt(LoyaltyStructure loyaltyStructure, String memberId, String loyaltyId, AccountOpt.OptType optType,
                                      LocalDateTime optTime){
        AccountOpt.OptNode optNode = new AccountOpt.OptNode(optType, optTime);
        AccountOpt accountOpt = accountOptRepository.fetchAccountOptByLoyaltyId(loyaltyId);
        if(accountOpt == null) {
            if(AccountOpt.OptType.OPT_OUT.equals(optType)){
                accountOpt = new AccountOpt(memberId, loyaltyStructure.getMarketingProgramId(), loyaltyId);
                accountOpt.addOpt(optNode);
                accountOptRepository.save(accountOpt);
            }
        } else {
            if(!accountOpt.judgeOptType() && AccountOpt.OptType.OPT_IN.equals(optType)){
                accountOpt.addOpt(optNode);
            }
            if(accountOpt.judgeOptType() && AccountOpt.OptType.OPT_OUT.equals(optType)){
                accountOpt.addOpt(optNode);
            }
            accountOptRepository.save(accountOpt);
        }
        return accountOpt;
    }


    public Account mergeAccount4Skii(List<String> originalMemberIds, String targetMemberId, String region,
                                     String brand, LocalDateTime registryTime,
                                     String channel, String bindId, AccountOpt.OptType optType, LocalDateTime optTime) {
        //打印日志
        List<String> requestMemberIds = new ArrayList<>(originalMemberIds);
        requestMemberIds.add(targetMemberId);
        removeDuplicateIds(originalMemberIds);
        //合并过程所用到的源memberId
        originalMemberIds.remove(targetMemberId);
        log.info("merge account executing, the target memberId is {}, the original memberIds are {}, the registryTime is{}",
                targetMemberId, originalMemberIds, registryTime);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        //查询出目标账户
        Account targetAccount =
                fetchAccountsByMemberIdAndLoyaltyStructure(loyaltyStructure, targetMemberId,
                        region, brand, registryTime, channel, bindId);
        log.info("origin target account {}", targetAccount);
        //查询出源账户
        List<Account> originalAccounts = fetchAccountsByMemberIdsAndLoyaltyStructure(loyaltyStructure, originalMemberIds);
        log.info("origin source accounts {}", originalAccounts);
        //查询源账户的积分记录
        List<Transaction> originalTransactions = fetchTransactionsByMemberIds(originalAccounts);
        //查询出目标账户的所有积分记录
        List<Transaction> targetTransactions = fetchTransactionsByMemberId(targetAccount);
        //保存日志记录
        saveAccountAndTransactionAsLog(originalAccounts,
                targetAccount, targetTransactions, originalTransactions, requestMemberIds, registryTime);
        //合并所有的交易记录
        mergeTransactions(targetTransactions, originalTransactions, targetAccount);
        List<Order> orders = new ArrayList<>();
        //过滤记录 将订单数据筛选出来  targetTransactions剩余Interaction和Redemption记录
        filterTransactions(targetTransactions, registryTime, orders);
        //保存目标账户合并后的排除Order的所有交易记录,删除源账户所有的积分记录
        saveTargetTransactions(targetTransactions);
        //设置optType
        if(optType != null && optTime != null) {
            log.info("memberId:{},optType:{},optTime:{}", targetAccount.getMemberId(), optType, optTime);
            mergeAccountOpt(loyaltyStructure, targetMemberId, targetAccount.loyaltyId(),
                    optType, optTime);
        }
        //保存目标账户,删除所有的源账户
        saveTargetAccounts(targetAccount);
        log.info("final target account {}", targetAccount);
        //推队列进行重算
        messageService.send2RecalculateOrders(targetMemberId, targetAccount.region(), orders);
        //通过retention接口删除会员和transaction记录
        deleteOriginalAccountsInfos(originalAccounts);
        log.info("merge account execute successfully");
        return targetAccount;
    }

    private void removeDuplicateIds(List<String> originalMemberIds) {
        HashSet<String> memberIds = new HashSet<>(originalMemberIds);
        originalMemberIds.clear();
        originalMemberIds.addAll(memberIds);
    }

    private void filterTransactions(List<Transaction> targetTransactions, LocalDateTime registryTime,
                                    List<Order> orders) {
        for (Transaction transaction : targetTransactions) {
            if (REGISTRY.equals(transaction.getPointType())) {
                transaction.setCreatedTime(registryTime);
            }
            if (transaction.getCreatedTime().isBefore(registryTime) && transaction.point() != 0) {
                transaction.cleanPoint();
            }
            if (transaction instanceof Order) {
                orders.add((Order)transaction);
            }
        }
        targetTransactions.removeAll(orders);
    }

    private void saveAccountAndTransactionAsLog(List<Account> originalAccounts, Account targetAccount,
                                                List<Transaction> targetTransactions,
                                                List<Transaction> originalTransactions,
                                                List<String> memberIds, LocalDateTime registryTime) {
        String correlationId = RequestContext.getCurrentContext().getCorrelationId();
        String targetMemberId = targetAccount.memberId();
        originalAccounts.forEach(account ->
                RetryTemplate.noResultRetry(() -> saveLog(correlationId, targetMemberId, account, memberIds, registryTime), 1));
        RetryTemplate.noResultRetry(() -> saveLog(correlationId, targetMemberId, targetAccount, memberIds, registryTime), 1);
        targetTransactions.forEach(transaction ->
                RetryTemplate.noResultRetry(() -> logRepository.save(new Log(transaction,
                        correlationId, targetMemberId, transaction.getMemberId(), memberIds, registryTime)), 1));
        originalTransactions.forEach(transaction ->
                RetryTemplate.noResultRetry(() -> logRepository.save(new Log(transaction,
                        correlationId, targetMemberId, transaction.getMemberId(), memberIds, registryTime)), 1));
    }

    private void saveLog(String correlationId, String targetMemberId,
                         Account account, List<String> memberIds, LocalDateTime registryTime) {
        logRepository.save(new Log(account, correlationId, targetMemberId, account.memberId(), memberIds,registryTime));
    }

    protected void rollbackPoint(LoyaltyStructure structure,List<Transaction> transactions, Account account) {
        if (transactions.isEmpty()) {
            log.info("the member {} not exist transactions, please check it", account.memberId());
            throw new SystemException("there not exist transactions, please check it", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        //PointValueObject对象  将相应的正负极分都包装到相应的对象中
        PointValueObject pointValueObject = obtainPointValueObject(transactions,structure);
        //更新account的信息
        updateAccountInfo(structure,account, pointValueObject, transactions);
        //合并正积分记录
        mergePositivePoint(pointValueObject);
        //处理获取到有效积分记录
        obtainEffectiveRecords(pointValueObject);
        //计算积分
        calculatePoint(structure, account, pointValueObject);
        //保存新生成的过期记录
        createAndSaveExpiredRecord(account, pointValueObject);
    }

    private void updateAccountInfo(LoyaltyStructure structure,Account account, PointValueObject pointValueObject, List<Transaction> transactions) {
        String brand = transactions.get(0).getBrand();
        List<Order> orders = transactions.stream()
                .filter(transaction -> transaction instanceof Order)
                .filter(transaction -> transaction.point() > 0)
                .map(transaction -> (Order) transaction)
                .sorted(Comparator.comparing(Order::getOrderDateTime))
                .collect(Collectors.toList());
        int usedPoint = pointValueObject.getNegativePointObjects().values()
                .stream().mapToInt(transaction -> Math.abs(transaction.point())).sum();
        int totalPoint = pointValueObject.getPositivePointObjects().values()
                .stream().mapToInt(transaction -> Math.abs(transaction.point())).sum();
        if (!orders.isEmpty()) {
            account.updatePurchaseInfo(structure,orders.size(), orders.get(0));
        }
        account.updatePointInfo(brand, usedPoint, totalPoint);
    }

    private void createAndSaveExpiredRecord(Account account, PointValueObject pointValueObject) {
        Map<LocalDate, PointValue> processedTransactions = pointValueObject.getProcessedTransactions();
        List<Interaction> expiredRecords = new ArrayList<>(pointValueObject.getExpiredRecords().keySet());
        processedTransactions.keySet().forEach(key -> {
            PointValue pointValue = processedTransactions.get(key);
            Interaction expiredRecord;
            if (pointValue.expired() && pointValue.point() > 0) {
                expiredRecord = generateExpiredRecord(account, expiredRecords, key, pointValue);
                interactionRepository.save(expiredRecord);
            }
        });

        expiredRecords.forEach(expiredRecord -> {
            expiredRecord.cleanPoint();
            RetryTemplate.noResultRetry(() -> interactionRepository.save(expiredRecord), 1);
        });
    }

    private Interaction generateExpiredRecord(Account account, List<Interaction> expiredTransactions,
                                              LocalDate key, PointValue pointValue) {
        Interaction expiredRecord;
        Optional<Interaction> first = expiredTransactions.stream().
                filter(expiredTransaction -> expiredTransaction.getCreatedTime().toLocalDate().isEqual(key)).findFirst();
        if (first.isPresent()) {
            expiredRecord = first.get();
            expiredTransactions.remove(expiredRecord);
            int point = Math.abs(pointValue.point());
            if (Math.abs(expiredRecord.getPoint()) != point) {
                expiredRecord.setPoint(-1 * point);
            }
        } else {
            expiredRecord = createExpiredRecord(account, pointValue, key);
        }
        return expiredRecord;
    }

    private Interaction createExpiredRecord(Account account, PointValue pointValue, LocalDate createdDate) {
        String brand = pointValue.brand();
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(account.region(), brand);
        Interaction interaction = new Interaction(account.loyaltyId(),
                brand, ChannelV2.INTERNAL, loyaltyStructure, account.memberId());
        interaction.setActivityId(activityId.get());
        interaction.setPointType(SYSTEM_EXPIRED_POINT);
        interaction.setDescription("积分过期");
        interaction.setPartitionKey(pointValue.partitionKey());
        LocalDateTime createdTime = LocalDateTime.of(createdDate.getYear(), createdDate.getMonth(),
                createdDate.getDayOfMonth(), 0, 0, 0, 0).plusYears(1);
        interaction.setCreatedTime(createdTime);
        interaction.setExpiredTime(createdTime);
        interaction.setPoint(-1 * Math.abs(pointValue.point()));
        PointItem pointItem = new PointItem(interaction.point(),
                "积分过期(重算)", activityId.get());
        interaction.getPointItems().add(pointItem);
        return interaction;
    }

    private void calculatePoint(LoyaltyStructure structure, Account account, PointValueObject pointValueObject) {
        Map<LocalDate, PointValue> processedTransactions = pointValueObject.getProcessedTransactions();
        List<LocalDate> keys = processedTransactions.keySet()
                .stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        for (LocalDate createdTime : keys) {
            PointValue pointValue = processedTransactions.get(createdTime);
            LocalDate expiredDate = structure.pointExpire().pointExpiredDate(LocalDateTime.of(createdTime, LocalTime.MIN));
            account.calculatePoint(expiredDate, pointValue);
        }
    }

    private void obtainEffectiveRecords(PointValueObject pointValueObject) {
        Map<LocalDate, PointValue> negativePointObjects = pointValueObject.getNegativePointObjects();
        Map<LocalDate, PointValue> processedPointObjects = pointValueObject.getProcessedTransactions();
        List<LocalDate> negativeKeys = negativePointObjects.keySet()
                .stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        List<LocalDate> positiveKeys = processedPointObjects.keySet()
                .stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        for (LocalDate negativeKey: negativeKeys) {
            PointValue negativePointValue = negativePointObjects.get(negativeKey);
            int index = 0;
            if (positiveKeys.isEmpty()) {
                //如果有负积分记录，但是正积分记录为空，则有可能是退单导致，这种情况也需要支持
                PointValue pointValue = new PointValue(negativePointValue.partitionKey(), negativePointValue.brand());
                processedPointObjects.put(LocalDate.now(), pointValue);
            }
            for (LocalDate positiveKey: positiveKeys) {
                index++;
                if (positiveKey.isAfter(negativeKey.minusYears(1))) {
                    PointValue positivePointValue = processedPointObjects.get(positiveKey);
                    int positivePoint = positivePointValue.point();
                    positivePointValue.decreasePoint(negativePointValue.point());
                    negativePointValue.increasePoint(positivePoint);
                    if (negativePointValue.point() >= 0) {
                        break;
                    }
                    if (positivePointValue.point() < 0 && index != positiveKeys.size()) {
                        //如果PointValue积分小于零  且不是最后一个数据  则将积分置为零
                        positivePointValue.setPoint(0);
                    }
                }
            }
        }
    }

    private void mergePositivePoint(PointValueObject pointValueObject) {
        Map<LocalDate, PointValue> positivePointObjects = pointValueObject.getPositivePointObjects();
        Map<LocalDate, PointValue> processedTransactions = pointValueObject.getProcessedTransactions();
        Map<LocalDate, PointValue> surplusTransactions = new HashMap<>(positivePointObjects);
        List<LocalDate> orderedKeyList = positivePointObjects.keySet()
                .stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        for (LocalDate createdTime : orderedKeyList) {
            PointValue pointValue = positivePointObjects.get(createdTime);
            surplusTransactions.remove(createdTime);
            List<LocalDate> surplusKeys = surplusTransactions.keySet()
                    .stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());
            boolean notExistOrder = true;
            for (LocalDate nextCreatedTime: surplusKeys) {
                PointValue object = surplusTransactions.get(nextCreatedTime);
                if (object.existOrder() && !nextCreatedTime.isAfter(createdTime.plusYears(1))) {
                    object.increasePoint(pointValue.point());
                    processedTransactions.put(nextCreatedTime, object);
                    processedTransactions.remove(createdTime);
                    notExistOrder = false;
                    break;
                }
            }
            //notExistOrder为true则证明往后面找完了也没有找到订单
            if (notExistOrder) {
                //进来则证明往后面推一年没有订单记录,最后一个也进来
                if (!LocalDate.now().isBefore(createdTime.plusYears(1))) {
                    //若是晚于一年,则标记为过期状态
                    pointValue.expire();
                }
                processedTransactions.put(createdTime, pointValue);
            }
        }
    }

    private PointValueObject obtainPointValueObject(List<Transaction> transactions,LoyaltyStructure structure) {
        PointValueObject pointValueObject = new PointValueObject();
        for (Transaction transaction : transactions) {
            if (!SYSTEM_EXPIRED_POINT.equals(transaction.getPointType())) {
                if (transaction instanceof Redemption || transaction.point() < 0) {
                    groupNegativePointTransaction(transaction, pointValueObject);
                } else {
                    if (transaction instanceof Order &&
                            Boolean.TRUE.equals(((Order) transaction).getRefund()) && transaction.point() == 0) {
                        continue;
                    }
                    groupPositivePointTransaction(transaction, pointValueObject,structure);
                }
            } else {
                //若是有过期积分记录,则拿到activityId
                pointValueObject.addExpiredRecord((Interaction) transaction);
            }
        }
        return pointValueObject;
    }

    private void groupPositivePointTransaction(Transaction transaction, PointValueObject pointValueObject,LoyaltyStructure structure) {
        Map<LocalDate, PointValue> positiveTransactions = pointValueObject.getPositivePointObjects();
        PointValue pointValue;
        int point;
        LocalDate createdTime;
        if (transaction instanceof Order) {
            Order order = (Order) transaction;
            createdTime = order.getOrderDateTime().toLocalDate();
            if (PointExpire.ExpiredDateCalculateWay.BY_CREATED_TIME.equals(structure.pointExpire().getExpiredDateCalculateWay())) {
                createdTime = order.getCreatedTime().toLocalDate();
            }
            pointValue = positiveTransactions.get(createdTime);
            if (pointValue == null) {
                pointValue = new PointValue();
            }
            point = order.point();
            pointValue.addOrderType();
        } else {
            Interaction interaction = (Interaction) transaction;
            createdTime = interaction.getCreatedTime().toLocalDate();
            pointValue = positiveTransactions.get(createdTime);
            if (pointValue == null) {
                pointValue = new PointValue();
            }
            point = interaction.point();
        }
        pointValue.addPartitionKey(transaction.getPartitionKey());
        pointValue.addBrand(transaction.brand());
        pointValue.addDate(createdTime);
        pointValue.increasePoint(point);
        positiveTransactions.put(createdTime, pointValue);
    }

    private void groupNegativePointTransaction(Transaction transaction, PointValueObject pointValueObject) {
        Map<LocalDate, PointValue> negativeTransactionsMap = pointValueObject.getNegativePointObjects();
        LocalDate createdTime = transaction.getCreatedTime().toLocalDate();
        PointValue pointValue = negativeTransactionsMap.get(createdTime);
        if (pointValue == null) {
            pointValue = new PointValue();
        }
        pointValue.addPartitionKey(transaction.getPartitionKey());
        pointValue.addBrand(transaction.brand());
        pointValue.addDate(createdTime);
        pointValue.decreasePoint(transaction.point());
        negativeTransactionsMap.put(createdTime, pointValue);
    }

}
