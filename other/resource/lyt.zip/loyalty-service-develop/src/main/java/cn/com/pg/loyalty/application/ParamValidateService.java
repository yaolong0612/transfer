package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.structure.Config;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;
import java.util.*;
import java.util.function.Function;

@Component
@Slf4j
public class ParamValidateService {

    private ObjectMapper objectMapper;

    private static final List<String> VERIFIED_PARAMS = Arrays.asList("region", "brand", "channel");
    private static final Map<String, Function<String, Config>> VERIFIED_PARAM_APPLY = new HashMap<>();

    @Autowired
    public ParamValidateService(ObjectMapper objectMapper, ConfigService configService) {
        this.objectMapper = objectMapper;
        VERIFIED_PARAM_APPLY.put("region", configService::region);
        VERIFIED_PARAM_APPLY.put("brand", configService::brand);
        VERIFIED_PARAM_APPLY.put("channel", configService::channel);
    }

    public void validate(Map<String, String> paramsMap){
        paramsMap.forEach((k,v) -> {
            Function<String, Config> validateFunction = VERIFIED_PARAM_APPLY.get(k);
            if(Objects.nonNull(validateFunction)){
                validateFunction.apply(v);
            }
        });
    }


    public Map<String, String> exactVerifiedParam(Function<String, Object> rawParamMap){
        Map<String, String> paramsMap = new HashMap<>();
        VERIFIED_PARAMS.forEach(paramKey -> {
            Object paramValue = rawParamMap.apply(paramKey);
            if(Objects.nonNull(paramValue)){
                paramsMap.put(paramKey, String.valueOf(paramValue));
            }
        });
        return paramsMap;
    }

    public Map<String,String> exactVerifiedParam(Object... args) {
         Map<String, String> paramsMap = new HashMap<>();
        List<Object> objList = Arrays.asList(args);
        try {
            objList.stream()
                    .filter(Objects::nonNull)
                    .filter(clazz -> !BeanUtils.isSimpleValueType(clazz.getClass()))
                    .filter(clazz -> !OffsetDateTime.class.isAssignableFrom(clazz.getClass()))
                    .map(this::convertValue)
                    .forEach(item -> paramsMap.putAll(this.exactVerifiedParam(item::get)));
        } catch (Exception e) {
            log.error("ParamValidAspect exactVerifiedParam error:{}", e.getMessage(), e);
        }
        return paramsMap;
    }


    public Map<String,String> convertValue(Object item) {
        return objectMapper.convertValue(item, Map.class);
    }
}
