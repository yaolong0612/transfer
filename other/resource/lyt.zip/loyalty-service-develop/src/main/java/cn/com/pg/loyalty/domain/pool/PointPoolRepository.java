package cn.com.pg.loyalty.domain.pool;

import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PointPoolRepository extends DocumentDbRepository<PointPool, String> {

    Optional<PointPool> findById(String id);

}
