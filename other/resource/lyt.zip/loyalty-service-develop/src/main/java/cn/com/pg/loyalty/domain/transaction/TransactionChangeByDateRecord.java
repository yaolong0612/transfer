package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.shared.ValueObject;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.data.annotation.Id;

/**
 * @author Simon
 * @date 2019/6/6 15:36
 * @description
 **/
@Document(collection = "TransactionChangeByDateRecord", ru = "400")
@Getter
@Setter
@ToString
@NoArgsConstructor
public class TransactionChangeByDateRecord implements ValueObject<TransactionChangeByDateRecord> {
    /**
     * Loyalty Id
     */
    @Id
    private String loyaltyId;

    /**
     * 格式：yyyyMMdd
     * 分区键
     */
    @PartitionKey
    private String updatedDate;

    private String region;

    private String brand;

    private Integer point;

    private TransactionType transactionType;

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TransactionChangeByDateRecord that = (TransactionChangeByDateRecord) o;

        return new EqualsBuilder()
                .append(loyaltyId, that.loyaltyId)
                .append(updatedDate, that.updatedDate)
                .append(region, that.region)
                .append(brand, that.brand)
                .append(point, that.point)
                .append(transactionType, that.transactionType)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(loyaltyId)
                .append(updatedDate)
                .append(region)
                .append(brand)
                .append(point)
                .append(transactionType)
                .toHashCode();
    }

    @Override
    public boolean sameValueAs(TransactionChangeByDateRecord other) {
        return this.equals(other);
    }
}
