package cn.com.pg.loyalty.domain.gift;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.RegionV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.interfaces.dto.AddHKPampersStoreNameDisplayMsgCommand;
import cn.com.pg.loyalty.interfaces.dto.HKPampersStoreNameDisplayMsgDTO;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;

@Service
@Slf4j
public class GiftCouponService {

    @Autowired
    private CouponPool couponPool;
    @Autowired
    private GiftCouponRepository giftCouponRepository;

    public List<GiftCoupon> findByMemberId(String brand, String region, String memberId, Locale locale) {
        List<GiftCoupon> giftCouponList = giftCouponRepository.findByMemberIdAndBrandAndRegion(memberId, brand, region);
        //多语言转换
        if (RegionV2.isHkRegionOrTwRegion(region) && BrandV2.PAMPERS.equals(brand)) {
            giftCouponList.forEach(giftCoupon -> giftCoupon.translateByLanguage(locale));
        }
        return giftCouponList;
    }


    public void addHKPampersStoreNameDisplayMsg(AddHKPampersStoreNameDisplayMsgCommand body) {
        LocalDateTime start = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getStartAt());
        LocalDateTime end = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getEndAt());
        for (HKPampersStoreNameDisplayMsgDTO displayLanguage : body.getDisplayLanguages()) {
            List<GiftCoupon> giftCouponList;
            if (start != null && end != null && StringUtils.isNotEmpty(displayLanguage.getBagSku())) {
                giftCouponList = giftCouponRepository.findByRegionAndBrandAndStoreNameAndBagSkuAndCreatedTimeBetween(body.getRegion(), body.getBrand(), displayLanguage.getStoreName(), displayLanguage.getBagSku(), LoyaltyDateTimeUtils.localDateTimeToString(start), LoyaltyDateTimeUtils.localDateTimeToString(end));
            } else if (start != null && end != null && StringUtils.isEmpty(displayLanguage.getBagSku())) {
                giftCouponList = giftCouponRepository.findByRegionAndBrandAndStoreNameAndCreatedTimeBetween(body.getRegion(), body.getBrand(), displayLanguage.getStoreName(), LoyaltyDateTimeUtils.localDateTimeToString(start), LoyaltyDateTimeUtils.localDateTimeToString(end));
            }else if ((start==null||end==null)&& StringUtils.isNotEmpty(displayLanguage.getBagSku())){
                giftCouponList = giftCouponRepository.findByRegionAndBrandAndStoreNameAndBagSku(body.getRegion(),body.getBrand(),displayLanguage.getStoreName(),displayLanguage.getBagSku());
            } else {
                giftCouponList = giftCouponRepository.findByRegionAndBrandAndStoreName(body.getRegion(), body.getBrand(), displayLanguage.getStoreName());
            }
            GiftCoupon.GiftCouponDisplayMsg giftCouponDisplayMsg = new GiftCoupon.GiftCouponDisplayMsg(ParamValidator.validateLanguage(displayLanguage.getLanguage().name()), displayLanguage.getDescription());
            giftCouponList.forEach(giftCoupon -> {
                giftCoupon.addGiftCouponDisplayMsg(Collections.singletonList(giftCouponDisplayMsg));
                giftCoupon.updateValidityDate(giftCoupon.getStartAt(), giftCoupon.getEndAt());
                giftCouponRepository.save(giftCoupon);
            });
        }
    }

    public GiftCoupon findGiftCouponByBagSku(String bagSku,String brand,String region) {

        return giftCouponRepository.findTopByBagSku(bagSku,brand,region);
    }

    /**
     * 添加coupon
     */
    public void addCoupon(GiftCoupon giftCoupon) {
        Optional<GiftCoupon> optional = giftCouponRepository.findByCode(giftCoupon.getBagSku(),
                giftCoupon.getRegion(), giftCoupon.getBrand(), giftCoupon.getCouponCode());
        GiftCoupon addCoupon = giftCoupon;
        if (optional.isPresent()) {
            addCoupon = optional.get();
            addCoupon.updateValidityDate(giftCoupon.getStartAt(), giftCoupon.getEndAt());
        }
        giftCouponRepository.save(addCoupon);
    }


    /**
     * 分配coupon code ,支持分布式场景
     */
    public GiftCoupon allocateCoupon(Account account, Redemption redemption, String sku) {
        if (StringUtils.isBlank(sku)) {
            throw new SystemException("Gift sku is null,please config.", ResultCodeMapper.GIFT_NOT_FOUNT_SKU);
        }
        String region = account.region();
        couponPool.checkAndInit(sku, region, redemption.getBrand());
        GiftCoupon giftCoupon = couponPool.allotGiftCoupon(sku, region, redemption.getBrand());
        giftCoupon.usedBy(account.memberId(), redemption.getId());
        return giftCoupon;
    }

    public void rollbackCoupon(GiftCoupon giftCoupon) {
        couponPool.rollCouponCodeInPool(giftCoupon.getBagSku(), giftCoupon.getRegion(),
                giftCoupon.getBrand(), giftCoupon.getCouponCode());
    }

    public boolean expiredCoupon(Account account, Redemption redemption) {
        List<GiftCoupon> giftCoupons = giftCouponRepository
                .findMemberCouponByTransactionId(account.memberId(), redemption.brand(),
                        account.region(), redemption.getId());
        if (CollectionUtils.isEmpty(giftCoupons)) {
            return false;
        }
        log.info("expired redemption coupon:{}", redemption.getId());
        giftCoupons.forEach(giftCoupon -> {
            giftCoupon.expired();
            giftCouponRepository.save(giftCoupon);
            couponPool.rollCouponCodeInPool(giftCoupon.getBagSku(), account.region(),
                    redemption.brand(), giftCoupon.getCouponCode());
        });
        return true;

    }

    public GiftCoupon findByRegionAndBrandAndCouponCode(String region, String brand, String couponCode) {
        List<GiftCoupon> giftCouponList = giftCouponRepository.findByRegionAndBrandAndCouponCode(region, brand, couponCode);
        GiftCoupon giftCoupon = null;
        if (!CollectionUtils.isEmpty(giftCouponList)){
            giftCoupon = giftCouponList.get(0);
        }
        return giftCoupon;
    }
}
