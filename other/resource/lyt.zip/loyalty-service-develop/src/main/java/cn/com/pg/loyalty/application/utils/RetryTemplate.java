package cn.com.pg.loyalty.application.utils;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.extern.slf4j.Slf4j;

import java.util.function.Supplier;

/**
 * @author cooltea on 2019/7/3 15:29.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */

@Slf4j
public class RetryTemplate {

    // 休眠时长 重试
    private static final int SLEEP_TIME = 50;

    /**
     * 重试
     *
     * @param retry
     * @param retryLimit 重试次数
     */
    public static void noResultRetry(RetryFunction retry, Integer retryLimit) {
        try {
            retry.retry();
        } catch (Exception e) {
            if (retryLimit > 0) {
                log.info("retry.....");
                sleep();
                RetryTemplate.noResultRetry(retry, retryLimit - 1);
            }
            throw new SystemException(e.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    /**
     * @param retry
     * @param retryLimit 重试最大次数
     * @param <T>
     * @return
     */
    public static <T> T retry(Supplier<T> retry, Integer retryLimit) {
        try {
            return retry.get();
        } catch (Exception e) {
            if (retryLimit > 0) {
                log.info("retry.....");
                sleep();
                RetryTemplate.retry(retry, retryLimit - 1);
            }
            throw new SystemException(e.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    private static void sleep() {
        try {
            Thread.sleep(SLEEP_TIME);
        } catch (InterruptedException e1) {
            log.error("Retry errorMsg: {}", e1.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    private RetryTemplate() {
    }
}
