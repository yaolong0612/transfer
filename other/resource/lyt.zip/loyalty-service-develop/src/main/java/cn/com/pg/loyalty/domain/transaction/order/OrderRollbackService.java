package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderLog;
import cn.com.pg.loyalty.domain.transaction.OrderLogRepository;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Component
public class OrderRollbackService {

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;
    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;
    @Autowired
    private MessageService messageService;
    @Autowired
    private OrderLogRepository orderLogRepository;

    @Autowired
    private RollBackOrderSelfRecoveryAble rollBackOrderSelfRecoveryAble;

    public boolean doRollBackOrders(OrderAccountCalculator orderAccountCalculator) {
        LocalDateTime earliestRollBackTime = orderAccountCalculator.calculateEarliestRollBackTime(
                new AlterOrderEarliestRollBackTimeFinder(), new InsertOrderEarliestRollBackTimeFinder(),
                new RefundOrderEarliestRollBackTimeFinder());
        if (earliestRollBackTime.isEqual(LocalDateTime.MAX)) {
            return false;
        }
        Account account = orderAccountCalculator.getAccount();
        LoyaltyStructure structure = orderAccountCalculator.getStructure();

        List<Order> rollBackOrders = orderRepositoryV2.findOrdersByOrderDateTimeBetween(account.loyaltyId(),
                earliestRollBackTime, LocalDateTime.now()).stream()
                .filter(order -> order.realTotalAmount() > 0).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(rollBackOrders)) {
            return false;
        }
        List<OrderLog> orderLogs = rollBackOrders.stream().map(OrderLog::new).collect(Collectors.toList());
        orderLogRepository.saveAll(orderLogs);

        RollBackOrderRecoverScene rollBackOrderRecoverScene = new RollBackOrderRecoverScene(rollBackOrderSelfRecoveryAble, structure, account);
        //将订单存到redis
        rollBackOrderRecoverScene.backupRollBackOrders(rollBackOrders);
        //保存accountGap
        rollBackOrderRecoverScene.backupRollBackAccountGap();
        //回滚订单
        orderAccountCalculator.rollBackOrders(rollBackOrders);
        //删订单
        orderRepositoryV2.deleteAll(rollBackOrders);
        //保存account
        accountRepositoryV2.save(account);
        //加上本身请求的订单排序重新发送发送到队列
        String brand = orderAccountCalculator.getRecalculateOrders().get(0).brand();
        messageService.delayRecalculateOrders(account.memberId(), account.region(), brand, orderAccountCalculator.getRecalculateOrders(), LocalDateTime.now().plusSeconds(1));
        //删除redisKey
        rollBackOrderRecoverScene.deleteRollBackOrderKeyAndAccountGapKey();
        return true;
    }

    public void checkAndRecoverRollBackScene(LoyaltyStructure structure, Account account) {

        //获取redis中的订单
        RollBackOrderRecoverScene rollBackOrderRecoverScene = new RollBackOrderRecoverScene(rollBackOrderSelfRecoveryAble, structure, account);
        List<Order> recoveryOrders = rollBackOrderRecoverScene.getRecoveryOrders();
        if (CollectionUtils.isEmpty(recoveryOrders)) {
            return;
        }
        log.info("从redis获取的订单为：{}", recoveryOrders);
        orderRepositoryV2.saveAll(recoveryOrders);
        if (rollBackOrderRecoverScene.recoveryAccount(recoveryOrders)) {
            accountRepositoryV2.save(account);
        }
        //删除redisKey
        rollBackOrderRecoverScene.deleteRollBackOrderKeyAndAccountGapKey();
    }
}