package cn.com.pg.loyalty.application.rulev2.tier;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator.CountTierScoreAble;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator.FetchCountItemAble;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.TierCalculateByOrdersQuantityProperties;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Predicate;


/**
 * @author lmr
 */
@Slf4j
@Component
@Rule(name = "TierCalculateByAmountRule",
        description = "根据用户购买的有效订单数量计算等级", priority = 1)
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.TIER)
public class TierCalculateByOrdersQuantity {

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    private static final RuleTemplate ruleTemplate = RuleTemplate.TIER_CALCULATE_BY_ORDERS_QUANTITY_RULE;

    @Condition
    public boolean validateRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                                @Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, LocalDateTime.now(), ruleTemplate);
        if (CollectionUtils.isEmpty(searchedActivityList)) {
            //没有订单时间在活动期间内的活动返回false,不执行加积分
            log.info("匹配到的根据用户购买的有效订单数量计算等级活动数为:{}", searchedActivityList.size());
            return Boolean.FALSE;
        }
        TierCalculateByOrdersQuantityProperties properties = JSON.parseObject(searchedActivityList.get(0)
                .getRuleProperties(), TierCalculateByOrdersQuantityProperties.class);
        tierChangeScene.initRuleCalculatorScene(properties);
        return tierChangeScene.matchRuleCalculateScene(true);
    }

    @Action
    public void calculateTier(@Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene,
                              @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        Account account = tierChangeScene.getAccount();
        TierCalculateByOrdersQuantityProperties properties = (TierCalculateByOrdersQuantityProperties) tierChangeScene.getBaseTierProperties();
        FetchCountItemAble<Order> fetchCountItemAble = scope -> orderRepositoryV2.fetchOrdersByCreatedTimeSorted(
                account.loyaltyId(), scope.getStartAt(), scope.getEndAt());

        Predicate<Order> transactionFilterPredicate = order -> order.realTotalAmount() > 0 && !order.groupPurchaseIs()
                && order.getOrderItems().stream().anyMatch(orderItem -> orderItem.getRealAmount() >= properties.getMinSkuAmount());

        CountTierScoreAble<Order> countTierScoreAble = List::size;

        TierRuleCalculator<Order> calculator = tierChangeScene.tryBuildRuleCalculator(Order.class);
        if (calculator == null) {
            return;
        }
        String level = calculator.calculateLevel(fetchCountItemAble, countTierScoreAble, Order::getOrderDateTime, transactionFilterPredicate);
        tierChangeScene.addLevelCalculateResult(level, calculator.fetchUpgradeTime());

        ruleResult.success();
        log.info("根据用户购买的有效订单数量计算等级结束");
    }
}
