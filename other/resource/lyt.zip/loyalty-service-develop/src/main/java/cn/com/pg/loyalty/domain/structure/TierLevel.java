package cn.com.pg.loyalty.domain.structure;


import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
public class TierLevel {
    public static final int BOUND_MIN = 0;

    //等级:数字asc
    private int level;
    //等级名称
    private String levelName;
    //等级别名
    private String levelAlias;
    //当前等级升级积分/金额:为0时不升级
    private int upgradeAmount;
    //当前等级保级积分/金额:为0时保级
    private int gradingAmount;
    //升级积分
    private int upgradePoint;
    //保级积分
    private int gradingPoint;

    //升级奖励积分
    private int upgradeAward;
    //保级奖励积分
    private int gradingAward;

    protected TierLevel(int level, String levelName, String levelAlias) {
        this.level = level;
        this.levelName = levelName;
        this.levelAlias = levelAlias;
    }

    protected void levelAmountRange(int gradingAmount, int upgradeAmount) {
        if (upgradeAmount != 0 && gradingAmount >= upgradeAmount) {
            throw new SystemException("upgrade amount must gt grading amount if it not eq 0", ResultCodeMapper.PARAM_ERROR);
        }
        this.upgradeAmount = upgradeAmount;
        this.gradingAmount = gradingAmount;
    }

    protected void levelPointRange(int gradingPoint, int upgradePoint) {
        if (upgradePoint != 0 && gradingPoint >= upgradePoint) {
            throw new SystemException("upgrade point must gt grading point if it not eq 0", ResultCodeMapper.PARAM_ERROR);
        }
        this.upgradePoint = upgradePoint;
        this.gradingPoint = gradingPoint;
    }

    protected void awardPoint(int gradingAward, int upgradeAward) {
        this.gradingAward = gradingAward;
        this.upgradeAward = upgradeAward;
    }

    protected boolean upgradeLevelByAmount(int tierAmount) {
        return upgradeAmount > BOUND_MIN && tierAmount >= upgradeAmount;
    }

    protected boolean gradingLevelByAmount(int tierAmount) {
        return !upgradeLevelByAmount(tierAmount) && tierAmount >= gradingAmount;
    }

    protected boolean upgradeLevelByPoint(int tierPoint) {
        return upgradePoint > BOUND_MIN && tierPoint >= upgradePoint;
    }

    protected boolean gradingLevelByPoint(int tierPoint) {
        return !upgradeLevelByPoint(tierPoint) && tierPoint >= gradingPoint;
    }

}
