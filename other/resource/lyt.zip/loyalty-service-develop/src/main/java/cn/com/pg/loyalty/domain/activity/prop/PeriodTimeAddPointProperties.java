package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.Optional;

/**
 * @author daming on 2019/6/21 10:09.
 * @version 1.0
 */

@Getter
@Setter
public class PeriodTimeAddPointProperties extends RuleProperties {

    /**
     * 一天内iYoYo连续加积分阈值
     */
    private Integer maxPoint;

    /**
     *  加积分倍数,默认使用1倍积分
     */
    private Integer multiple;

    public Integer maxPoint() {
        return Optional.ofNullable(maxPoint).orElse(0);
    }

    public Integer multiple() {
        return Optional.ofNullable(multiple).orElse(1);
    }

}
