package cn.com.pg.loyalty.application;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class InteractionProperties {

    private String brand;
    private String region;
    private String channel;
    private String memberId;
    private String pointType;
    private String qrCode;
    private String sku;
    private Boolean newMember;
    private Integer point;
    private String reason;
    private String token;

    public String brand(){
        return this.brand;
    }

    public String region(){
        return this.region;
    }

    public String channel(){
        return this.channel;
    }

    public String memberId(){
        return this.memberId;
    }

    public String pointType(){
        return this.pointType;
    }

    public String qrCode(){
        return this.qrCode;
    }

    public String sku(){
        return this.sku;
    }

    public Boolean newMember(){
        return this.newMember;
    }

    public Integer point(){
        return this.point;
    }

    public String reason(){
        return this.reason;
    }

    public String token(){
        return this.token;
    }

}
