package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.activity.prop.BaseTierProperties;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.Getter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 提供等级规则计算场景能力
 * 规则中进行差异化组装，实现流程
 */
@Getter
public class TierChangeScene {
    private final LoyaltyStructure structure;
    private final Account account;
    private final Transaction transaction;

    private final List<LevelCalculateResult> levels = new ArrayList<>();

    private final boolean handleExpire;

    private BaseTierProperties baseTierProperties;


    public TierChangeScene(LoyaltyStructure structure, Account account, Transaction transaction) {
        this.structure = structure;
        this.account = account;
        this.transaction = transaction;
        this.handleExpire = account.tier(this.structure.name()).judgeTierExpired();
    }

    public TierChangeScene(LoyaltyStructure structure, Account account, boolean handleExpire) {
        this.structure = structure;
        this.account = account;
        this.handleExpire = handleExpire;
        this.transaction = null;
    }

    /**
     * 初始化场景：用于切换等级计算场景
     */
    public void initRuleCalculatorScene(BaseTierProperties baseTierProperties) {
        this.baseTierProperties = baseTierProperties;
    }

    public void initRuleLimitScene() {
        this.baseTierProperties = null;

    }

    /**
     *如果transaction 转泛型类型失败，返回null
     *请检查 matchScene 传参或者逻辑是否有误
     */
    public <T extends Transaction> TierRuleCalculator<T> tryBuildRuleCalculator(Class<T> clazz) {
        TierRuleCalculator<T> calculator = new TierRuleCalculator<>(account.tier(structure.name()), baseTierProperties, structure.tierLevelSeries());
        if (transaction == null) {
            return calculator;
        }
        if (!calculator.matchTransaction(transaction, clazz)) {
            return null;
        }
        return calculator;
    }


    public boolean matchRuleCalculateScene(boolean isOnlyOrderImpact) {
        if (expireAtUnexpiredTime()) {
            return false;
        }
        if (handleExpire) {
            return true;
        }
        if (isOnlyOrderImpact && transactionIsNotOrder()) {
            return false;
        }
        if (transactionIsNotOrder() && !transactionIsEarnInteraction()) {
            return false;
        }
        if (checkGroupOrder()) {
            return false;
        }
        if (checkRefundOrder()) {
            return true;
        }
        if (baseTierProperties == null) {
            return true;
        }
        String curLevel = account.tier(structure.name()).getLevel();
        String maxChangeLevel = baseTierProperties.getTierLevels().getMaxChangeLevel();
        //正单或者交互加积分并且当前等级大于等于活动所配置的等级，则不用计算
        return structure.tierLevelSeries().compare(maxChangeLevel, curLevel) > 0;
    }


    /**
     * 如果是等级过期，判断是否过期
     */
    public boolean expireAtUnexpiredTime() {
        if (!handleExpire) {
            return false;
        }
        Tier tier = account.tier(structure.name());
        return !LocalDate.now().isAfter(tier.getExpiredTime().toLocalDate());
    }


    public boolean checkRefundOrder() {
        if (transactionIsNotOrder()) return false;
        Order order = (Order) this.transaction;
        return order.refundOrder();
    }

    private boolean transactionIsNotOrder() {
        if (this.transaction == null) {
            return true;
        }
        return !TransactionType.ORDER.equals(this.transaction.getTransactionType());
    }

    private boolean transactionIsEarnInteraction() {
        if (this.transaction == null) {
            return false;
        }
        return TransactionType.INTERACTION.equals(this.transaction.getTransactionType()) && this.transaction.point() > 0;
    }

    private boolean checkGroupOrder() {
        if (transactionIsNotOrder()) return false;
        Order order = (Order) this.transaction;
        return order.groupPurchaseIs();
    }

    /**
     * 如果根据积分和金额竞争则可能存在多个等级，计算最高等级
     */
    public void calculateFinalTier() {
        TierLevelSeries tierLevelSeries = structure.tierLevelSeries();
        Tier currentTier = this.account.tier(this.structure.name());
        // 如果根据积分和金额竞争则可能存在多个等级，取最高等级

        Comparator<LevelCalculateResult> comparator = Comparator.comparing((LevelCalculateResult result) ->
                result.levelIndex(structure.tierLevelSeries()))
                .thenComparing(LevelCalculateResult::upgradeTime);
        LevelCalculateResult newLevelResult = this.levels.stream().max(comparator).orElse(null);
        if (newLevelResult == null) {
            return;
        }
        String newLevel = newLevelResult.level();
        int compareResult = tierLevelSeries.compare(currentTier.getLevel(), newLevel);

        // 等级没有变化
        if (compareResult == 0) {
            return;
        }

        //如果降级,且未到过期时间,并且不是退单
        if (compareResult > 0 && !currentTier.judgeTierExpired() && !checkRefundOrder()) {
            return;
        }

        // 如果是退单，退单后的等级不能小于原单等级
        if (checkRefundOrder() && tierLevelSeries.compare(transaction.getCurrentLevel(), newLevel) > 0) {
            newLevel = transaction.getCurrentLevel();
        }
        account.updateTier(this.structure, newLevel, newLevelResult.upgradeTime());
    }

    /**
     * 需要扣除或添加的等级奖励积分
     */
    public int calculateTierAwardPoint() {
        Tier currentTier = this.account.tier(this.structure.name());
        String backupLevel = currentTier.getBackupLevel();
        if (backupLevel == null) {
            return 0;
        }
        int compareResult = structure.tierLevelSeries().compare(backupLevel, currentTier.getLevel());
        // 升级加等级奖励积分
        if (compareResult < 0) {
            return structure.tierLevelSeries().calculateUpgradeAwardPoints(backupLevel, Math.abs(compareResult));
        }
        // 只要不是等级过期导致的降级，都需要扣除等级奖励积分
        if (compareResult > 0 && !isHandleExpire()) {
            // 退单导致降级扣除等级奖励积分
            return -structure.tierLevelSeries().calculateRefundAwardPoints(backupLevel, Math.abs(compareResult));
        }
        return 0;
    }

    public void addLevelCalculateResult(String level, LocalDateTime upgradeTime) {
        this.levels.add(new LevelCalculateResult(level, upgradeTime));
    }

    public static class LevelCalculateResult {
        private String level;
        private final LocalDateTime upgradeTime;

        public LevelCalculateResult(String level, LocalDateTime upgradeTime) {
            this.level = level;
            this.upgradeTime = upgradeTime;
        }

        public void updateLevel(String level) {
            this.level = level;
        }

        public String level() {
            return level;
        }

        public int levelIndex(TierLevelSeries series) {
            return series.getLevelByName(level).getLevel();
        }

        public LocalDateTime upgradeTime() {
            return upgradeTime;
        }

    }

    public int compareLevel(String level){
        TierLevelSeries tierLevelSeries = structure.tierLevelSeries();
        Tier currentTier = this.account.tier(this.structure.name());
        return tierLevelSeries.compare(currentTier.getLevel(),level);
    }

}
