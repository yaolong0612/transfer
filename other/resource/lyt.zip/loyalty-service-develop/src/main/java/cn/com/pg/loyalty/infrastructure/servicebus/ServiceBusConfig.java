package cn.com.pg.loyalty.infrastructure.servicebus;

import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.application.dependence.Subscribe;
import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.interfaces.message.AbstractConsumer;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.microsoft.azure.servicebus.*;
import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.lang.reflect.Method;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author tangjia
 * @date 2019/5/26
 * @description ServiceBusTopicConfig
 */
@Slf4j
@Component
@Getter
public class ServiceBusConfig {
    @Value("${serviceBus.connectionString}")
    private String connectionString;

    private final static Map<ServiceBusQueueTopicEnum, Object> CLIENT_MAP = new HashMap<>();

    public static final String QUEUE_IS_NOT_EXIST = "Queue is not Exist";
    public static final String CURRENT_THREAD_EXCEPTION = "current thread throw exception, message is: {}";

    private Map<ServiceBusQueueTopicEnum, Object> consumers = new HashMap<>(60);

    private Map<String, Integer> retryTimesMap = new HashMap<>(60);

    @Autowired
    private ApplicationContext context;

    /**
     * 若是需要新增Queue, 则需要注入
     * 相应的consumer,同时在init方法中添加进map中
     * 如果是没有consumer的queue,它仅仅只是用于发消息,
     * 为了保险起见,也需添加到consumers中进行预先注册
     */
    public void init() {
        List<String> currentActiveProfileList = Arrays.asList(context.getEnvironment().getActiveProfiles()).stream().map(String::toUpperCase).collect(Collectors.toList());
        Map<ServiceBusQueueTopicEnum, AbstractConsumer> consumerMap = context.getBeansOfType(AbstractConsumer.class)
                .entrySet().stream().collect(Collectors.toMap(item -> getServiceBusEnumByConsumer(item.getValue()), Map.Entry::getValue));
        Arrays.stream(ServiceBusQueueTopicEnum.values()).filter(queueOrTopic -> filterByActiveProfile(queueOrTopic, currentActiveProfileList))
                .forEach(queueOrTopic -> {
                    log.info("serviceBusEnumName:{}, type:{}, activeProfile:{}", queueOrTopic.name(), queueOrTopic.serviceBusType(), queueOrTopic.activeProfile());
                    if (queueOrTopic.serviceBusType().equals(ServiceBusQueueTopicEnum.ServiceBusType.QUEUE)) {
                        consumers.put(queueOrTopic, consumerMap.get(queueOrTopic));
                    } else if (queueOrTopic.serviceBusType().equals(ServiceBusQueueTopicEnum.ServiceBusType.TOPIC)) {
                        consumers.put(queueOrTopic, "this topic just for publish message ");
                    } else if (queueOrTopic.serviceBusType().equals(ServiceBusQueueTopicEnum.ServiceBusType.SUBSCRIBE)) {
                        ServiceBusQueueTopicEnum topicEnum = queueOrTopic.topicEnum();
                        consumers.put(queueOrTopic, new Subscribe(topicEnum, consumerMap.get(queueOrTopic)));
                    }
                });
    }

    public boolean filterByActiveProfile(ServiceBusQueueTopicEnum queueOrTopic, List<String> currentActiveProfileList) {
        ServiceBusQueueTopicEnum.ActiveProfile activeProfile = queueOrTopic.activeProfile();
        if (activeProfile.equals(ServiceBusQueueTopicEnum.ActiveProfile.ALL)) {
            return true;
        }
        if (currentActiveProfileList.contains(ServiceBusQueueTopicEnum.ActiveProfile.TW.name()) && activeProfile.equals(ServiceBusQueueTopicEnum.ActiveProfile.TW)) {
            return true;
        }
        if (!currentActiveProfileList.contains(ServiceBusQueueTopicEnum.ActiveProfile.TW.name()) && activeProfile.equals(ServiceBusQueueTopicEnum.ActiveProfile.ML)) {
            return true;
        }
        return false;
    }

    public ServiceBusQueueTopicEnum getServiceBusEnumByConsumer(AbstractConsumer consumer) {
        ServiceBusQueueTopicEnum serviceBusQueueTopicEnum;
        try {
            Class<? extends AbstractConsumer> consumerClazz = consumer.getClass();
            Method getQueueSubscribeEnumMethod = consumerClazz.getDeclaredMethod("getQueueSubscribeEnum");
            getQueueSubscribeEnumMethod.setAccessible(true);
            serviceBusQueueTopicEnum = (ServiceBusQueueTopicEnum) getQueueSubscribeEnumMethod.invoke(consumer);
        } catch (Exception e) {
            log.error("getServiceBusEnumByConsumer error : {}", ExceptionUtil.getStackTraceErrorMessage(e));
            throw new SystemException("getServiceBusEnumByConsumer error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return serviceBusQueueTopicEnum;
    }


    /**
     * 初始化
     * Exception
     */
    @PostConstruct
    public void creatClient() {
        init();
        consumers.keySet().forEach(serviceBusName -> {
            if (ServiceBusQueueTopicEnum.ServiceBusType.QUEUE.equals(serviceBusName.serviceBusType())) {
                createQueueClients(serviceBusName);
            } else if (ServiceBusQueueTopicEnum.ServiceBusType.TOPIC.equals(serviceBusName.serviceBusType())) {
                createTopicClient(serviceBusName);
            } else {
                Subscribe subscribe = (Subscribe) consumers.get(serviceBusName);
                ServiceBusQueueTopicEnum topicEnum = subscribe.getTopicEnum();
                createTopicSubscription(topicEnum, serviceBusName);
            }
        });
        registerMessage();
    }

    private void registerMessage() {
        log.info("init service bus... ");
        Set<ServiceBusQueueTopicEnum> set = consumers.keySet();
        try {
            for (ServiceBusQueueTopicEnum key : set) {
                if (consumers.get(key) instanceof IMessageHandler || consumers.get(key) instanceof Subscribe) {
                    if (ServiceBusQueueTopicEnum.ServiceBusType.SUBSCRIBE.equals(key.serviceBusType())) {
                        ((SubscriptionClient) CLIENT_MAP.get(key)).registerMessageHandler(
                                (IMessageHandler) ((Subscribe) consumers.get(key)).getObject(), createMessageHandlerOptions(), createExecutorService());
                    } else {
                        ((QueueClient) CLIENT_MAP.get(key)).registerMessageHandler(
                                (IMessageHandler) consumers.get(key), createMessageHandlerOptions(), createExecutorService());
                    }
                }
            }
            log.info("service bus is ok!");
        } catch (InterruptedException e) {
            log.error(CURRENT_THREAD_EXCEPTION, e.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("register message  handler failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (ServiceBusException e) {
            log.error(CURRENT_THREAD_EXCEPTION, e.getMessage());
            throw new SystemException("register message  handler failed", ResultCodeMapper.SERVICE_BUS_ERROR);
        }
    }

    /**
     * 卸载bean对象前关闭client
     * <p>
     * ServiceBusException
     */
    @PreDestroy
    public void closeTheClients() throws ServiceBusException {
        for (ServiceBusQueueTopicEnum key : CLIENT_MAP.keySet()) {
            if (ServiceBusQueueTopicEnum.ServiceBusType.SUBSCRIBE.equals(key.serviceBusType())) {
                ((SubscriptionClient) CLIENT_MAP.get(key)).close();
            } else if (ServiceBusQueueTopicEnum.ServiceBusType.TOPIC.equals(key.serviceBusType())) {
                ((TopicClient) CLIENT_MAP.get(key)).close();
            } else {
                ((QueueClient) CLIENT_MAP.get(key)).close();
            }
        }
    }

    /**
     * 创建QueueClient
     */
    private QueueClient createQueueClient(ServiceBusQueueTopicEnum queueName) throws Exception {
        ConnectionStringBuilder csb = new ConnectionStringBuilder(connectionString, queueName.queueOrTopicName());
        return new QueueClient(csb, ReceiveMode.PEEKLOCK);
    }

    /**
     * 创建多个client
     *
     * @param queueName queue名字
     */

    private void createQueueClients(ServiceBusQueueTopicEnum queueName) {
        String queueNameKey = "QUEUE:" + queueName.queueOrTopicName();
        try {
            QueueClient queueClient = createQueueClient(queueName);
            CLIENT_MAP.put(queueName, queueClient);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(queueNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建QueueClient {} 失败：{}", queueName, e.getMessage());
                throw new SystemException("create queue client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create queue client fail, retry more times");
            createQueueClients(queueName);
        }
    }


    private void sleepForRetry() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException exception) {
            log.error(CURRENT_THREAD_EXCEPTION, exception.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("thread sleep error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    public boolean canRetry(String queueNameKey) {
        if (retryTimesMap.get(queueNameKey) == null) {
            retryTimesMap.put(queueNameKey, 0);
        } else {
            retryTimesMap.put(queueNameKey, retryTimesMap.get(queueNameKey) + 1);
        }
        return (retryTimesMap.get(queueNameKey) == null ? 0 : retryTimesMap.get(queueNameKey)) < 2;
    }

    public ExecutorService createExecutorService() {
        return new ThreadPoolExecutor(0, 3, 5L,
                TimeUnit.MINUTES, new LinkedBlockingQueue<Runnable>(), new ThreadFactoryBuilder().setNameFormat("consumer-%d").build());
    }

    public MessageHandlerOptions createMessageHandlerOptions() {
        return new MessageHandlerOptions(3, false, Duration.ofMinutes(1));
    }

    public QueueClient getQueueClient(ServiceBusQueueTopicEnum queueName) {
        if (!CLIENT_MAP.containsKey(queueName)) {
            log.warn("Queue: {} is not exist", queueName);
            throw new SystemException(QUEUE_IS_NOT_EXIST, ResultCodeMapper.UNEXPECTED_ERROR);
        }
        if (!ServiceBusQueueTopicEnum.ServiceBusType.QUEUE.equals(queueName.serviceBusType())) {
            log.warn("Queue: {} is not a queue", queueName);
            throw new SystemException("this queue name is not a Queue", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return (QueueClient) CLIENT_MAP.get(queueName);
    }

    public Map<ServiceBusQueueTopicEnum, Object> getConsumers() {
        return consumers;
    }


    /**
     * 获取主题client
     *
     * @return 返回TopicClient
     */
    public TopicClient getTopicClient(ServiceBusQueueTopicEnum topicName) {
        if (!CLIENT_MAP.containsKey(topicName)) {
            log.error("Topic: {} is not exist", topicName);
            throw new SystemException(QUEUE_IS_NOT_EXIST, ResultCodeMapper.UNEXPECTED_ERROR);
        }
        if (!ServiceBusQueueTopicEnum.ServiceBusType.TOPIC.equals(topicName.serviceBusType())) {
            log.error("Topic: {} is not a topic", topicName);
            throw new SystemException("this queue name is not a Queue", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return (TopicClient) CLIENT_MAP.get(topicName);
    }

    /**
     * 获取订阅client
     *
     * @param subscribeName 订阅名称
     * @return 返回SubscriptionClient
     */
    public SubscriptionClient getSubscribeClient(ServiceBusQueueTopicEnum subscribeName) {
        if (!CLIENT_MAP.containsKey(subscribeName)) {
            log.error("Subscribe: {} is not exist", subscribeName);
            throw new SystemException("Subscribe is not Exist", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        if (!ServiceBusQueueTopicEnum.ServiceBusType.SUBSCRIBE.equals(subscribeName.serviceBusType())) {
            log.error("Subscribe: {} is not a Subscribe", subscribeName);
            throw new SystemException("this Subscribe name is not a Subscribe", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return (SubscriptionClient) CLIENT_MAP.get(subscribeName);
    }

    private void createTopicClient(ServiceBusQueueTopicEnum topicName) {
        String topicNameKey = "TOPIC:" + topicName.queueOrTopicName();
        try {
            TopicClient topicClient = new TopicClient(new ConnectionStringBuilder(connectionString, topicName.queueOrTopicName()));
            CLIENT_MAP.put(topicName, topicClient);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(topicNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建topicClient {} 失败：{}", topicName, e.getMessage());
                throw new SystemException("topic queue client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create topic client :{} fail, retry more times", topicName);
            createTopicClient(topicName);
        }
    }

    /**
     * 获取订阅主题
     *
     * @param topicEnum    订阅的主题
     * @param subscription 订阅的名称
     */
    public void createTopicSubscription(ServiceBusQueueTopicEnum topicEnum, ServiceBusQueueTopicEnum subscription) {
        String topicNameKey = "SUBSCRIPTION:" + subscription.queueOrTopicName();
        try {
            StringBuffer sb = new StringBuffer();
            sb.append(topicEnum.queueOrTopicName()).append("/subscriptions/").append(subscription.queueOrTopicName());
            SubscriptionClient subscriptionClient = new SubscriptionClient(new ConnectionStringBuilder(connectionString, sb.toString()), ReceiveMode.PEEKLOCK);
            CLIENT_MAP.put(subscription, subscriptionClient);
        } catch (InterruptedException interruptedException) {
            log.error(CURRENT_THREAD_EXCEPTION, interruptedException.getMessage());
            // Restore interrupted state...
            Thread.currentThread().interrupt();
            throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        } catch (Exception e) {
            sleepForRetry();
            if (!canRetry(topicNameKey)) {
                //超出重试次数 抛出异常 中断创建client
                log.error("创建subscriptionClient {} 失败：{}", subscription, e.getMessage());
                throw new SystemException("create subscription client failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.warn("create subscription consumer fail, retry more times");
            createTopicSubscription(topicEnum, subscription);
        }
    }

    /**
     * 获取queue或者topic客户端工具
     *
     * @param name
     * @return
     */
    static public Object fetchClient(String name, ServiceBusQueueTopicEnum.ServiceBusType serviceBusType) {
        return CLIENT_MAP.get(ServiceBusQueueTopicEnum.fetchServiceBusQueueTopicEnumByName(name, serviceBusType));
    }

}
