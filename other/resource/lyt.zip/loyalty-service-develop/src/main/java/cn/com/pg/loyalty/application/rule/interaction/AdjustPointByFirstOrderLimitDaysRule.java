package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AdjustPointByOrderLimitProperties;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * @author linbj
 * @date 2020/8/28 10:48
 */
@Rule(name = "Adjust point times limit of date template.",
        description = "Adjust point times limit of date template.")
@Slf4j
public class AdjustPointByFirstOrderLimitDaysRule {

    private static final String MEMBER_ID = "memberId";

    @Condition
    public boolean validateRule(@Fact("pointType") PointType pointType) {
        // 校验是否为当前积分模板，true才执行下面逻辑
        return pointType.ruleTemplate() == RuleTemplate.INTERACTION_ADJUST_POINT_BY_FIRST_ORDER_LIMIT_DAYS;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("account") Account account,
                         @Fact("brand") String brand,
                         @Fact("interaction") Interaction interaction,
                         @Fact("orderRepositoryV2") OrderRepositoryV2 orderRepositoryV2,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("ruleResult") RuleResult ruleResult) {

        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());

        List<Order> orderRecords = orderRepositoryV2.findMemberOrdersByLoyaltyId(account, brand);
        boolean pastedOrOptOutOrderWithEffect = orderRecords.stream()
                .filter(order1 -> BrandV2.SKII.equals(order1.brand()))
                .anyMatch(order1 -> order1.hasBeenOptOutOrder() || order1.hasBeenPastedOrder());
        if (pastedOrOptOutOrderWithEffect) {
            //若存在历史订单则不加肌肤测积分
            ruleResult.addException(new SystemException("Interaction Rule executions error because of existing history orders for memberId:" + account.getMemberId(),
                    ResultCodeMapper.PARAM_ERROR));
            return;
        }

        // 获取首单
        Optional<Order> firstOrder = getFirstOrder(account, orderRecords, ruleResult);
        if (!firstOrder.isPresent()) {
            return;
        }
        Activity activity = activities.get(0);

        AdjustPointByOrderLimitProperties properties = JSON.parseObject(activity.getRuleProperties(),
                AdjustPointByOrderLimitProperties.class);
        //检验订单是否在限期内
        if (validateNotEffectiveOrder(firstOrder.get(), properties)) {
            ruleResult.addException(new SystemException("Interaction Rule executions error because it is out of activity date for memberId:" + account.getMemberId(),
                    ResultCodeMapper.ACTIVITY_NOT_AVAILABLE_ERROR));
            return;
        }
        //校验加分次数是否超过限制
        if (adjustTimesOutOfLimit(account, brand, interactionRepository, ruleResult,
                transactionPartitionKey, activity, properties)) {
            return;
        }
        interaction.addPoint(activity, properties.getPoint());
        ruleResult.success();
    }

    /**
     * 是否存在加积分记录
     */
    private boolean adjustTimesOutOfLimit(Account account, String brand,
                                          InteractionRepository interactionRepository,
                                          RuleResult ruleResult,
                                          String transactionPK, Activity activity,
                                          AdjustPointByOrderLimitProperties properties) {

        List<Interaction> historyInteractions = interactionRepository
                .findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(
                        transactionPK, activity.getPointType(), account.loyaltyId(), brand);
        if (!CollectionUtils.isEmpty(historyInteractions) && historyInteractions.size() >= properties.getLimitTimes()) {
            ruleResult.addException(
                    new SystemException(MEMBER_ID + ":" + account.getMemberId() + ", " +
                            "participated in " + activity.getActivityName() + " activity " + historyInteractions.size() + " times, "
                            + "exceeding the limit",
                            ResultCodeMapper.LIMIT_ERROR));
            return true;
        }
        return false;
    }

    /**
     * 验证是否在限期内参加活动
     */
    private boolean validateNotEffectiveOrder(Order earliestOrder, AdjustPointByOrderLimitProperties properties) {
        LocalDateTime earliestOrderDateTime = earliestOrder.getOrderDateTime();
        return LocalDateTime.now().minusDays(properties.getLimitDays()).isAfter(earliestOrderDateTime);
    }


    /**
     * 获取首购
     */
    private Optional<Order> getFirstOrder(Account account, List<Order> historyOrders,
                                          RuleResult ruleResult) {
        Optional<Order> earliestOrder = historyOrders.stream().filter(order -> order.getRealTotalAmount() > 0).min(Comparator.comparing(Order::getOrderDateTime));
        if (!earliestOrder.isPresent()) {
            ruleResult.addException(new SystemException(MEMBER_ID + ":" + account.getMemberId() + ", has not purchased the product yet",
                    ResultCodeMapper.LESS_THAN_SPECIFIED_PURCHASE_RECORDS));
        }
        return earliestOrder;
    }
}
