package cn.com.pg.loyalty.domain.activity.prop;

import lombok.*;

@Data
public class TierCalculateByPointProperties extends BaseTierProperties{
}
