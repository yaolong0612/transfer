package cn.com.pg.loyalty.infrastructure.rule.engine;

public enum RuleScope {
    /**
     * 计算前限制规则
     */
    BEFORE_LIMIT_RULE,
    /**
     * 计算规则
     */
    CALCULATE_RULE,
    /**
     * 计算后限制规则
     */
    AFTER_LIMIT_RULE;

}
