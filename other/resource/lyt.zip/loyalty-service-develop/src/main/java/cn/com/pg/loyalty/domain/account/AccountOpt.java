package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;

/**
 * @Author: Hayden
 * @CreateDate: 2021/3/5 14:47
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/5 14:47
 * @Version: 1.0
 * @Description:
 */
@Getter
@Setter
@Slf4j
@NoArgsConstructor
public class AccountOpt extends AccountExtension {

    private List<OptNode> opts = new ArrayList<>();

    public AccountOpt(String memberId, String marketingProgramId, String loyaltyId) {
        super(memberId, marketingProgramId, loyaltyId, PartnerType.OPTION);
    }



    public enum OptType {
        /**
         * 可获取积分
         */
        OPT_IN,
        /**
         * 无获取积分
         */
        OPT_OUT
    }

    @Getter
    @Setter
    @NoArgsConstructor
    public static class OptNode {
        private OptType optType;
        @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
        private LocalDateTime optDate;

        public OptNode(OptType optType, LocalDateTime optDate) {
            this.optType = optType;
            this.optDate = optDate;
        }

        boolean conformEffectTimeInterval(LocalDateTime dateTime) {
            return !this.optDate.isAfter(dateTime);
        }

        boolean optOut() {
            return OptType.OPT_OUT == this.optType;
        }

        public OptType optType() {
            return this.optType;
        }
    }

    public void addOpt(OptNode optNode) {
        optNode.optDate = Optional.ofNullable(optNode.optDate).orElse(LocalDateTime.now());
        if (CollectionUtils.isEmpty(this.opts) && OptType.OPT_IN == optNode.optType) {
            throw new SystemException("The first opt node not be OPT_IN", ResultCodeMapper.PARAM_ERROR);
        }
        this.opts.stream().reduce((node1, node2) -> node2).ifPresent(lastNode -> {
            if (!lastNode.optDate.isBefore(optNode.optDate)) {
                throw new SystemException("The new node optDate must after old node.", ResultCodeMapper.PARAM_ERROR);
            }
            if (lastNode.optType == optNode.optType) {
                throw new SystemException("The new node optType must different from old node.", ResultCodeMapper.PARAM_ERROR);
            }
        });
        this.updatedTime = LocalDateTime.now();
        this.opts.add(optNode);
    }

    public boolean optOut(LocalDateTime dateTime) {
        return this.opts.stream().filter(optNode -> optNode.conformEffectTimeInterval(dateTime))
                .max(Comparator.comparing(OptNode::getOptDate)).filter(OptNode::optOut).isPresent();
    }

    public OptNode currentOptNode() {
        return this.opts.stream().max(Comparator.comparing(OptNode::getOptDate))
                .orElseThrow(() -> new SystemException(String.format("error opts, loyaltyId:%s", loyaltyId), ResultCodeMapper.PARAM_ERROR));
    }

    public boolean judgeOptType(){
        return currentOptNode().optType().equals(AccountOpt.OptType.OPT_IN);
    }
}
