package cn.com.pg.loyalty.domain.activity;

public interface CouponGateway {

    Coupon instanceCoupon(String memberId, String brand);

    boolean cancelCoupon(String memberId, String brand, String code);

    boolean redemptionCoupon(String memberId, String brand, String code);
}
