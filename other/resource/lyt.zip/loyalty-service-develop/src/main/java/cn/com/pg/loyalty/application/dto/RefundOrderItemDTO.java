package cn.com.pg.loyalty.application.dto;

import cn.com.pg.loyalty.domain.transaction.OrderItem;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-08-12 3:04
 */

@Getter
@Setter
@ToString
public class RefundOrderItemDTO {

    /**
     * 商品编号
     */
    private String sku;
    /**
     * 剩余购买数量
     */
    private Integer purchaseQty = 0;
    /**
     * 退的数量
     */
    private Integer refundQty = 0;
    /**
     * 商品单价
     */
    private Double retailAmount = 0.0;
    /**
     * 该商品实付金额
     */
    private Double realAmount = 0.0;
    /**
     * 退款金额
     */
    private Double refundAmount = 0.0;

    private String transactionSalePlace;

    private String skuQty;

    private String lineItemNo;

    public OrderItem orderItem() {
        OrderItem orderItems = new OrderItem();
        orderItems.setSku(sku);
        orderItems.setRealAmount(realAmount);
        orderItems.setRefundAmount(refundAmount);
        orderItems.setRefundQty(refundQty);
        return orderItems;
    }

    public static RefundOrderItemDTO getRefundOrderItemDTO(String sku,Integer refundQty,Double retailAmount,Double refundAmount){
        RefundOrderItemDTO orderItemDTO = new RefundOrderItemDTO();
        orderItemDTO.setSku(sku);
        orderItemDTO.setRefundQty(refundQty);
        orderItemDTO.setRetailAmount(retailAmount);
        orderItemDTO.setRefundAmount(refundAmount);
        return orderItemDTO;
    }

}
