package cn.com.pg.loyalty.domain.gift;

import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.builder.EqualsBuilder;

/**
 * @description:
 * @author: Artermus wang on 2021-09-06 13:40
 */
@Slf4j
@Getter
@Setter
@NoArgsConstructor
@ToString
public class CouponUrlItem implements ValueObject<CouponUrlItem> {

    private String size;

    private String url;

    public CouponUrlItem(String size, String url) {
        this.size = size;
        this.url = url;
    }

    @Override
    public boolean sameValueAs(CouponUrlItem o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return new EqualsBuilder()
                .append(size, o.size)
                .append(url, o.url)
                .isEquals();
    }
}
