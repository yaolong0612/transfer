package cn.com.pg.loyalty.infrastructure.elasticsearch;

import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class EsTemplate {

    @Autowired
    private RestHighLevelClient restHighLevelClient;

    public <T> List<T> search(SearchRequest searchRequest, RequestOptions requestOptions, Class<? extends T> clazz) {
        try {
            SearchResponse search = restHighLevelClient.search(searchRequest, requestOptions);
            return convertToObject(search, clazz);
        } catch (IOException e) {
            log.error("search es throw an exception, the message is: {}", e.getMessage(), e);
            throw new SystemException("search es throw an exception", ResultCodeMapper.ELASTIC_SEARCH_ERROR);
        }
    }

    public <T> PageableResult<T> pageQuery(String index, QueryBuilder queryBuilder, int page, int perPage, Class<T> clazz) {
        SearchRequest searchRequest = new SearchRequest(index);
        try {
            SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
            searchSourceBuilder.from((page - 1) * perPage);
            searchSourceBuilder.size(perPage);
            searchSourceBuilder.query(queryBuilder);
            searchRequest.source(searchSourceBuilder);
            SearchResponse pageQueryResult = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            log.info("result:{}", pageQueryResult);
            return new PageableResult<>((int) pageQueryResult.getHits().getTotalHits().value, convertToObject(pageQueryResult, clazz));
        } catch (IOException e) {
            log.error("search es throw an exception, the message is: {}", e.getMessage(), e);
            throw new SystemException("search es throw an exception", ResultCodeMapper.ELASTIC_SEARCH_ERROR);
        }
    }

    private <T> List<T> convertToObject(SearchResponse searchResponse, Class<? extends T> clazz) {
        SearchHit[] hits = searchResponse.getHits().getHits();
        return Arrays.stream(hits).map(hit -> {
            log.info("hit:{}", hit.getSourceAsString());
            return JSON.parseObject(hit.getSourceAsString(), clazz);
        }).collect(Collectors.toList());
    }

    public BoolQueryBuilder buildBoolQueryBuilder(Map<String, Object> queryParams) {
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        queryParams.forEach((k, v) -> {
            if (v != null) {
                boolQueryBuilder.filter(QueryBuilders.termQuery(k + ".keyword", v));
            }
        });
        return boolQueryBuilder;
    }

    public RangeQueryBuilder buildRangeQueryBuilder(String fieldName, Object from, Object to) {
        return QueryBuilders.rangeQuery(fieldName).gte(from).lte(to);
    }
}
