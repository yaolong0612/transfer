package cn.com.pg.loyalty.infrastructure.elasticsearch;

import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContexts;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PreDestroy;
import javax.net.ssl.SSLContext;
import java.io.IOException;
import java.util.ArrayList;

@Configuration
@Slf4j
@Setter
public class ESConfig{

    @Value("${elasticsearch.hostName}")
    private String hosts;

    @Value("${elasticsearch.port}")
    private Integer port;

    @Value("${elasticsearch.scheme}")
    private String scheme;

    @Value("${elasticsearch.connectTimeOut}")
    private Integer connectTimeOut; // 连接超时时间

    @Value("${elasticsearch.socketTimeOut}")
    private Integer socketTimeOut; // 连接超时时间

    @Value("${elasticsearch.connectionRequestTimeOut}")
    private Integer connectionRequestTimeOut; // 获取连接的超时时间

    @Value("${elasticsearch.maxConnectNum}")
    private Integer maxConnectNum; // 最大连接数

    @Value("${elasticsearch.maxConnectPerRoute}")
    private Integer maxConnectPerRoute; // 最大路由连接数

    @Value("${elasticsearch.userName}")
    private String userName;

    @Value("${elasticsearch.password}")
    private String password;

    private RestHighLevelClient restHighLevelClient;

    @Bean
    public RestHighLevelClient createRestHighLevelClient() {
        try{
            ArrayList<HttpHost> hostList = new ArrayList<>();
            String[] hostStrings = hosts.split(",");
            for (String host : hostStrings) {
                hostList.add(new HttpHost(host, port, scheme));
            }

            RestClientBuilder restClientBuilder = RestClient.builder(hostList.toArray(new HttpHost[0]));

            // 异步httpClient连接延时配置
            restClientBuilder.setRequestConfigCallback(builder -> {
                builder.setConnectTimeout(connectTimeOut);
                builder.setSocketTimeout(socketTimeOut);
                builder.setConnectionRequestTimeout(connectionRequestTimeOut);
                return builder;
            });
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(new TrustAllStrategy()).build();
            // 异步httpClient连接数配置
            restClientBuilder.setHttpClientConfigCallback(httpAsyncClientBuilder -> {
                httpAsyncClientBuilder.setMaxConnTotal(maxConnectNum);
                httpAsyncClientBuilder.setMaxConnPerRoute(maxConnectPerRoute);
                // prd环境需要用户名密码验证
                if(!userName.equals("") && !password.equals("")) {
                    final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
                    credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(userName, password));
                    httpAsyncClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
                }
                httpAsyncClientBuilder.setSSLContext(sslContext);
                httpAsyncClientBuilder.setSSLHostnameVerifier(new NoopHostnameVerifier());
                return httpAsyncClientBuilder;
            });
            restHighLevelClient = new RestHighLevelClient(restClientBuilder);
            log.info("create elasticsearch restHighLevelClient successfully");
            return restHighLevelClient;
        }catch (Exception e) {
            log.error("create elasticsearch restHighLevelClient failed, {}", ExceptionUtil.getStackTraceErrorMessage(e));
            throw new SystemException("create elasticsearch client failed", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    @Bean
    public RestClient createHealthClient(RestHighLevelClient restHighLevelClient) {
        return restHighLevelClient.getLowLevelClient();
    }

    @PreDestroy
    public void close() {
        if (restHighLevelClient != null) {
            try {
                restHighLevelClient.close();
            } catch (IOException e) {
                log.error("close elasticsearch restHighLevelClient failed, {}", ExceptionUtil.getStackTraceErrorMessage(e));
                throw new SystemException("close elasticsearch restHighLevelClient failed", ResultCodeMapper.UNEXPECTED_ERROR);
            }
        }
        log.info("close elasticsearch restHighLevelClient successfully");
    }
}
