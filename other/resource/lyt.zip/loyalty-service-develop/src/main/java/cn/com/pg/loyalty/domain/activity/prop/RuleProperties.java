package cn.com.pg.loyalty.domain.activity.prop;

/**
 * @author Simon
 * @date 2019/4/30 14:32
 * @description
 **/
public abstract class RuleProperties {
}
