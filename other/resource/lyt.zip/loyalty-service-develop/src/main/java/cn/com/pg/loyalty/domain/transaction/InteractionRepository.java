package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.pool.ValueType;
import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;
import sun.awt.SunHints;

import java.util.List;
import java.util.Set;

/**
 * @author: Ysnow
 * @Date: 2019/6/11 18:10
 * @Description:
 */
@Repository
public interface InteractionRepository extends DocumentDbRepository<Interaction, String> {
    /**
     * 查找某个人在某个品牌的某段时间的某个交互积分次数
     *
     * @param partitionKey
     * @param loyaltyId
     * @param brand
     * @param startTime
     * @param endTime
     * @return
     */
    int countByPartitionKeyAndLoyaltyIdAndBrandAndPointTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId, String brand, String pointType, String startTime, String endTime);


    List<Interaction> findByPartitionKeyAndLoyaltyIdAndBrandAndPointType(String partitionKey, String loyaltyId, String brand, String pointType);

    List<Interaction> findByPartitionKeyAndLoyaltyIdAndBrandAndPointTypeAndValueType(String partitionKey, String loyaltyId, String brand, String pointType, ValueType valueType);

    List<Interaction> findByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId, String pointType, String startAt, String endAt);

    List<Interaction> findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(String partitionKey, String pointType, String loyaltyId, String brand);

    List<Interaction> findByPartitionKeyAndLoyaltyIdAndTransactionStatusAndTransactionTypeAndBrand(String partitionKey, String loyaltyId, Transaction.TransactionStatus migration, TransactionType interaction, String brand);

    List<Interaction> findByPartitionKeyAndId(String partitionKey, String interactionId);

    @Override
    Interaction save(Interaction interaction);

    List<Interaction> findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrandAndCreatedTimeBetween(String partitionKey, String pointType, String loyaltyId, String brand, String startTime, String endTime);

    boolean existsByPartitionKeyAndLoyaltyIdAndTransactionStatusAndCreatedTimeBetweenAndBrandIn(String partitionKey, String loyaltyId, Transaction.TransactionStatus settlement, String startAt, String endAt, Set<String> brands);

    List<Interaction> findByQrCodeAndBrand(String qrCode, String brand);

    List<Transaction> findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId,TransactionType transactionType,String startAt, String endAt);

    List<Interaction> findByPartitionKeyAndLoyaltyIdAndExternalBusinessIdAndTransactionType(String pk, String loyaltyId, String externalBusinessId,TransactionType transactionType);

    List<Interaction> findByPartitionKeyAndLoyaltyIdAndPointTypeIn(String pk, String loyaltyId, List<String> pointTypes);

    boolean existsByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeAfterAndPointGreaterThan(String pk, String loyaltyId,String pointType,String createdTime,int point);
}
