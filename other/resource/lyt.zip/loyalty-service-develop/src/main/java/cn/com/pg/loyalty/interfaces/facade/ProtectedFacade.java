package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.interfaces.api.ProtectedApiDelegate;
import cn.com.pg.loyalty.interfaces.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;

@Component("ProtectedFacade")
@Slf4j
public class ProtectedFacade implements ProtectedApiDelegate {

    AccountsFacade accountsFacade;
    TransactionsFacade transactionsFacade;

    @Autowired
    public ProtectedFacade(AccountsFacade accountsFacade, TransactionsFacade transactionsFacade) {
        this.accountsFacade = accountsFacade;
        this.transactionsFacade = transactionsFacade;
    }

    @Override
    public ResponseEntity<AccountDTO> findAccountByMemberIdV2(String memberId, String brand, String region,
                                                              String channel, String bindId) {
        return accountsFacade.findAccountByMemberId(memberId, brand, region, channel, bindId);
    }

    @Override
    public ResponseEntity<PointHistoryWithPointCategoryDTO> findPointHistoryV2(String memberId, String brand,
                                                                               String region, String channel,
                                                                               String valueType, String bindId,
                                                                               OffsetDateTime startAt,
                                                                               OffsetDateTime endAt,
                                                                               Integer perPage, Integer page,
                                                                               String pointCategory) {
        return accountsFacade.findPointHistory(memberId, brand, region, channel, valueType,
                bindId, startAt, endAt, perPage, page, pointCategory, null);
    }

    @Override
    public ResponseEntity<PointHistoryDTO> findPointHistoryWithPointTypeV2(String memberId, String brand,
                                                                           String region, String channel, String pointType) {
        return accountsFacade.findPointHistoryWithPointType(memberId, brand, region, channel, pointType);
    }

    @Override
    public ResponseEntity<FetchOrderListDTO> findOrdersHistoryV2(String memberId, String brand, String region,
                                                                 String channel, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page) {
        return accountsFacade.findOrdersHistory(memberId, brand, region, channel, bindId, startAt, endAt, perPage, page);
    }

    @Override
    public ResponseEntity<RedemptionAggregationRecordDto> findRedemptionAggregationWithPointTypeV2(String memberId,
                                                                                                   String brand,
                                                                                                   String region,
                                                                                                   String channel,
                                                                                                   String pointType,
                                                                                                   OffsetDateTime startAt, OffsetDateTime endAt) {
        return accountsFacade.findRedemptionAggregationWithPointType(memberId, brand, region, channel, pointType,
                startAt, endAt);
    }


    @Override
    public ResponseEntity<FetchRedemptionListDTO> findRedemptionHistoryV2(String memberId, String brand, String region, String channel, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page, String activityId, String redemptionStatus, String valueType) {
        return accountsFacade.findRedemptionHistory(memberId, brand, region, channel, bindId, startAt, endAt, perPage
                , page, activityId, redemptionStatus, valueType);
    }


    @Override
    public ResponseEntity<Void> updateAccountProfileByMemberIdV2(String memberId, UpdateAccountProfileCommand updateAccountProfileCommand, String authorization) {
        return accountsFacade.updateAccountProfileByMemberId(memberId, updateAccountProfileCommand, authorization);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> findRedemptionHistoryForC2V2(String memberId, String brand,
                                                                               String region, String channel,
                                                                               Boolean isHotline, String bindId, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page) {
        return accountsFacade.findRedemptionHistoryForC2(memberId, brand, region, channel, isHotline, bindId, startAt
                , endAt, perPage, page);
    }

    @Override
    public ResponseEntity<AccountTierDTO> findTierV2(String memberId, String brand, String region) {
        return accountsFacade.findTier(memberId, brand, region);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> fetchRedemptionListV2(String authorization, String activityId,
                                                                        String brand, String region,
                                                                        OffsetDateTime startAt, OffsetDateTime endAt,
                                                                        Integer perPage, Integer page,
                                                                        String deliveryChannel,
                                                                        String redemptionStatus, String memberId,
                                                                        String channel, Boolean returnTierLevel) {
        return transactionsFacade.fetchRedemptionList(authorization, activityId, brand, region, startAt, endAt,
                perPage, page, deliveryChannel, redemptionStatus, memberId, channel, returnTierLevel, null);
    }

    @Override
    public ResponseEntity<TransactionDetailDTO> findTransactionByIdV2(String transactionId, String brand,
                                                                      String region, String loyaltyId) {
        return transactionsFacade.findTransactionById(transactionId, brand, region, loyaltyId);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> getRedemptionByStoreCodeV2(String authorization, String activityId,
                                                                             OffsetDateTime startAt,
                                                                             OffsetDateTime endAt, Integer perPage, Integer page, String storeCode, String redemptionStatus) {
        return transactionsFacade.getRedemptionByStoreCode(authorization, activityId, startAt, endAt, perPage, page, storeCode, redemptionStatus);
    }

    @Override
    public ResponseEntity<FetchRedemptionListDTO> getRedemptionByStoreCodeWithoutActivityIdV2(String authorization,
                                                                                              String storeCode, OffsetDateTime startAt, OffsetDateTime endAt, Integer perPage, Integer page, String redemptionStatus) {
        return transactionsFacade.getRedemptionByStoreCodeWithoutActivityId(authorization, storeCode, startAt, endAt, perPage, page, redemptionStatus);
    }

    @Override
    public ResponseEntity<Void> rejectByIdV2(String transactionId, RejectRedemptionCommand body) {
        return transactionsFacade.rejectById(transactionId, body);
    }

    @Override
    public ResponseEntity<TransferStoreCodeResultDTO> transferStoreCodeV2(String authorization,
                                                                          TransferConsumersToAnotherStoreCodeCommand body) {
        return transactionsFacade.transferStoreCode(authorization, body);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionDeliveryChannelV2(String authorization, UpdateRedemptionDeliveryChannelCommand body) {
        return transactionsFacade.updateRedemptionDeliveryChannel(authorization, body);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionGiftStatusToReceivedByIdV2(String transactionId, ReceiveRedemptionGiftsCommand receiveRedemptionGiftsCommand) {
        return transactionsFacade.updateRedemptionGiftStatusToReceivedById(transactionId, receiveRedemptionGiftsCommand);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionGiftsStatusByIdV2(String transactionId, UpdateRedemptionGiftStatusCommand updateRedemptionGiftStatusCommand) {
        return transactionsFacade.updateRedemptionGiftsStatusById(transactionId, updateRedemptionGiftStatusCommand);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionInfoByIdV2(String authorization, String transactionId, UpdateRedemptionCommand updateRedemptionCommand) {
        return transactionsFacade.updateRedemptionInfoById(authorization, transactionId, updateRedemptionCommand);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionLogisticsByIdV2(String transactionId, UpdateRedemptionLogisticsCommand updateRedemptionLogisticsCommand) {
        return transactionsFacade.updateRedemptionLogisticsById(transactionId, updateRedemptionLogisticsCommand);
    }

    @Override
    public ResponseEntity<Void> updateRedemptionStoreCodeByIdV2(String transactionId, UpdateRedemptionStoreCodeCommand updateRedemptionStoreCodeCommand) {
        return transactionsFacade.updateRedemptionStoreCodeById(transactionId, updateRedemptionStoreCodeCommand);
    }

    @Override
    public ResponseEntity<Void> updateStatusToDeliveredByStoreCodeV2(String authorization, String storeCode, UpdateRedemptionStatusToDeliveredCommand body) {
        return transactionsFacade.updateStatusToDeliveredByStoreCode(authorization, storeCode, body);
    }

    @Override
    public ResponseEntity<FetchRedemptionListForC2DTO> fetchRedemptionListByRedeemCodeV2(OffsetDateTime startAt,
                                                                                         OffsetDateTime endAt,
                                                                                         String redeemCode,
                                                                                         String brand,
                                                                                         Integer perPage,
                                                                                         Integer page) {
        return transactionsFacade.fetchRedemptionListByRedeemCode(startAt, endAt, redeemCode, brand, perPage, page);
    }

    @Override
    public ResponseEntity<RedemptionDTO> fetchRedemptionByIdV2(String transactionId, String brand, String region,
                                                               String memberId) {
        return transactionsFacade.fetchRedemptionById(transactionId, brand, region, memberId);
    }

    @Override
    public ResponseEntity<Void> expireRedemptionByIdV2(String transactionId, ExpireRedemptionCommand body) {
        return transactionsFacade.expireRedemptionById(transactionId, body);
    }

    @Override
    public ResponseEntity<Void> cancelRedemptionByIdV2(String transactionId, CancelRedemptionCommand body) {
        return transactionsFacade.cancelRedemptionById(transactionId, body);
    }

    @Override
    public ResponseEntity<CreateRedemptionDTO> createRedemptionV3(CreateRedemptionCommand body) {
        return transactionsFacade.createRedemption(body);
    }


    @Override
    public ResponseEntity<FetchRedemptionListDTO> fetchRedemptionListByStoreAndActivityForC2V2(OffsetDateTime startAt
            , OffsetDateTime endAt, String storeCode, String brand, Integer perPage, Integer page) {
        return transactionsFacade.fetchRedemptionListByStoreAndActivityForC2(startAt, endAt, storeCode, brand,
                perPage, page);
    }
}
