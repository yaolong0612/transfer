package cn.com.pg.loyalty.domain.structure;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BrandV2 extends Config {

    public static final String OLAY = "OLAY";
    public static final String SKII = "SKII";
    public static final String PAMPERS = "PAMPERS";
    public static final String OPTE = "OPTE";
    public static final String BRAUN = "BRAUN";
    public static final String GILLETTE = "GILLETTE";
    public static final String ORALB = "ORALB";
    public static final String LA = "LA";

    public BrandV2(String name, String description) {
        super("BRAND", name, description);
    }
}
