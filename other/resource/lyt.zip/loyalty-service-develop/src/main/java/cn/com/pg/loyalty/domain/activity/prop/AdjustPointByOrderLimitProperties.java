package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @author linbj
 * @date 2020/8/28 17:57
 */
@Getter
@Setter
public class AdjustPointByOrderLimitProperties extends RuleProperties {
    //加积分
    private int point;
    //日期限制
    private int limitDays;
    //次数限制
    private int limitTimes;
}
