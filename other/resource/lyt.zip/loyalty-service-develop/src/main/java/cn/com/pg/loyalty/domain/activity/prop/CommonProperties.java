package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;

import java.util.List;
import java.util.Map;

public interface CommonProperties {
    /**
     * 获取是否设置了互斥
     * @param redemptionItemMap
     * @param giftItem
     * @return
     */
    default boolean fetchMutex(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return false;
    }

    /**
     * 判断是否互斥
     * @param redemptionItemMap
     * @param giftItemList
     * @param historyGiftItemList
     * @return
     */
    default boolean checkMutex(Map<String, RedemptionItem> redemptionItemMap, List<GiftItem> giftItemList, List<GiftItem> historyGiftItemList){
        return false;
    }

    /**
     * 判断是否需要入群限制
     * @param redemptionItemMap
     * @param giftItem
     * @return
     */
    default boolean checkGroupStatus(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return false;
    }

    /**
     * 判断是否需要加入BC企业微信
     * @param redemptionItemMap
     * @param giftItem
     * @return
     */
    default boolean checkJoinEnterpriseWechatForBC(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return false;
    }

    /**
     * 获取当前ruleProperties的RuleLable
     *
     * @return
     */
    RuleLable fetchLable();

    /**
     * 获取下一层级rule的properties，
     *
     * @return
     */
    CommonProperties fetchNext();

    default String fetchName(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return redemptionItemMap.get(giftItem.getGiftId()).getNameWithLable(fetchLable());
    }

    /**
     * 返回限制的礼品兑换数量，不配置默认返回0表示不做限制
     * @param redemptionItemMap
     * @param giftItem
     * @return
     */
    default int fetchTotalLimitQuantity(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem){return 0;}


    /**
     * 返回购买次数限制
     * @param redemptionItemMap
     * @param giftItem
     * @return
     */
    default PurchaseLimit fetchPurchaseLimit(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem){return null;}
}
