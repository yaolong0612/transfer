package cn.com.pg.loyalty.interfaces.facade;


import cn.com.pg.loyalty.domain.shared.ExceptionUtil;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.json.DesensitizedSerializeByFieldNameFilter;
import cn.com.pg.loyalty.interfaces.dto.APIErrorResponse;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @author Ladd
 * FacadeAspect 统一处理Facade错误异常
 */

@Aspect
@Component
@Slf4j
@Order(1)
public class FacadeAspect {

    @Pointcut("execution(public * cn.com.pg.loyalty.interfaces.facade.*.*(..))")
    private void facadeProcess() {
        //DO NOTHING.
    }

    @Around(value = "facadeProcess()")
    public Object process(ProceedingJoinPoint pjp) {
        long startTime = System.currentTimeMillis();
        ResponseEntity response = null;
        //获取methodName
        String methodName = pjp.getSignature().getName();
        StringBuilder params = new StringBuilder();
        Object[] args = pjp.getArgs();
        for (int i = 0; i < args.length; i++) {
            Object arg = args[i];
            String p = arg == null ? null : arg.toString();
            if (i == 0) {
                params.append(p);
            } else {
                params.append(",").append(p);
            }
        }
        log.info("params: {}", params.toString().replace("\n", "").replace("    ", " "));
        RequestContext.getCurrentContext().operationName(methodName);
        SystemException systemException = null;
        try {
            response = (ResponseEntity) pjp.proceed();
        } catch (Throwable targetException) {
            APIErrorResponse apiErrorResponse;
            if (targetException instanceof SystemException) {
                systemException = (SystemException) targetException;
                apiErrorResponse = new APIErrorResponse()
                        .code(systemException.errorCode())
                        .message(systemException.getMessage())
                        .correlationId(RequestContext.getCurrentContext().getCorrelationId());
                //SystemErrorCode映射Httpstatus
                response = ResponseEntity.
                        status(systemException.resultCodeMapper().getStatus())
                        .body(apiErrorResponse);
            } else {
                log.error("API Catch a Unexpected Error, {}", targetException);
                apiErrorResponse = new APIErrorResponse().
                        code(HttpStatus.INTERNAL_SERVER_ERROR.value()).
                        message(targetException.getMessage()).
                        correlationId(RequestContext.getCurrentContext().getCorrelationId());
                response = ResponseEntity.
                        status(HttpStatus.INTERNAL_SERVER_ERROR).
                        body(apiErrorResponse);
                systemException = new SystemException(ResultCodeMapper.UNEXPECTED_ERROR);
            }
        } finally {
            RequestContext.getCurrentContext().error(systemException);
            long costTime = System.currentTimeMillis() - startTime;
            String responseString = Optional.ofNullable(response).map(item -> JSON.toJSONString(item,
                    new DesensitizedSerializeByFieldNameFilter())).orElse("");
            log.info("FacadeAspect-Response: {}, CostTime: {}", responseString, costTime);
        }
        return response;
    }
}
