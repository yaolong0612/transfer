package cn.com.pg.loyalty.infrastructure.servicebus.refactor;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Map;

@Setter
@Getter
@ToString
public class ServiceBusProperties {
    private String connectionString;
    private String generalLabel;
    private Map<String, Client> sender;
    private Map<String, Client> consumer;

    @Setter
    @Getter
    @ToString
    public static class Client {
        private ServiceBusBinder.ServiceBusType type;
        private String description;
        private String name;
        private ServiceBusBinder binging;
        private String topic;
        private int concurrency;
    }
}
