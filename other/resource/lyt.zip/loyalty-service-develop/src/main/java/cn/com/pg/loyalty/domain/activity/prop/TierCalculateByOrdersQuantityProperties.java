package cn.com.pg.loyalty.domain.activity.prop;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TierCalculateByOrdersQuantityProperties extends BaseTierProperties {

    /**
     * sku最小金额
     */
    private int minSkuAmount;
}
