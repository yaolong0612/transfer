package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.application.GiftService;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.interfaces.api.GiftsApiDelegate;
import cn.com.pg.loyalty.interfaces.assembler.GiftAssembler;
import cn.com.pg.loyalty.interfaces.assembler.GiftMapper;
import cn.com.pg.loyalty.interfaces.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

/**
 * @author Ladd
 */
@Component("GiftsFacade")
public class GiftsFacade implements GiftsApiDelegate {

    @Autowired
    private GiftService giftService;
    @Autowired
    CacheService cacheService;

    @Override
    public ResponseEntity<AddGiftDTO> addGift(String token, AddGiftCommand addGiftCommand) {
        String username = JwtUtils.getUsernameFromToken(token);
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(addGiftCommand.getRegion(), addGiftCommand.getBrand());

        Gift gift = GiftMapper.INSTANCE.addCmd2Gift(addGiftCommand, structure.name(), username);
        giftService.addGift(gift);
        //注意TODO,这个creator暂时是传token，确认好再修改
        AddGiftDTO addGiftDTO = GiftAssembler.toAddGiftDTO(gift);
        return ResponseEntity.ok(addGiftDTO);
    }

    @Override
    public ResponseEntity<Void> deleteGiftById(String token, String giftId) {
        giftService.deleteGiftById(giftId);
        return new ResponseEntity<>(HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> updateGiftInfoById(String token, String giftId, UpdateGiftCommand command) {

        LoyaltyStructure structure = cacheService.findLoyaltyStructure(command.getRegion(), command.getBrand());
        Gift gift = GiftMapper.INSTANCE.updateCmd2Gift(command, giftId, structure.name());
        giftService.updateGift(gift);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @Override
    public ResponseEntity<GiftListDTO> fetchGiftList(String authorization, String brand, String region, Integer perPage, Integer page, String name, String giftId) {
        PageableResult<Gift> pageableResult = giftService.fetchGiftList(brand, region, name, giftId, perPage, page);
        GiftListDTO giftListDTO = GiftAssembler.toGiftListDTO(pageableResult);
        return ResponseEntity.ok(giftListDTO);
    }

    @Override
    public ResponseEntity<GiftDTO> fetchGiftById(String authorization, String giftId) {
        Gift gift = giftService.findGiftById(giftId);
        GiftDTO giftDTO = GiftAssembler.giftTransformGiftDto(gift);
        return ResponseEntity.ok(giftDTO);
    }
}
