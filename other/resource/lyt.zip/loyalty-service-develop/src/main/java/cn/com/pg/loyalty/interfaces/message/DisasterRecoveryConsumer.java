package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @author cooltea on 2019/7/3 14:37.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Component
@Slf4j
public class DisasterRecoveryConsumer extends AbstractConsumer {

    private ServiceBusQueueTopicEnum queueEnum = ServiceBusQueueTopicEnum.DISASTER_RECOVERY_QUEUE;
    private static final String TRANSACTION_TYPE = "transactionType";

    @Autowired
    private TransactionRepositoryV2 transactionRepositoryV2;
    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        log.info("queue保存transaction开始：{}", jsonObject.toJSONString());
        String transactionTypeString = jsonObject.getString(TRANSACTION_TYPE);
        if (StringUtils.isEmpty(transactionTypeString)) {
            Account account = JSON.parseObject(jsonObject.toJSONString(), Account.class);
            if (account != null) {
                accountRepositoryV2.save(account);
                log.info("queue保存account成功结束");
            }
        } else {
            Transaction transaction = Optional.of(transactionTypeString).map(type -> {
                TransactionType transactionType = TransactionType.valueOf(type);
                if (transactionType == TransactionType.ORDER) {
                    return JSON.parseObject(jsonObject.toJSONString(), Order.class);
                }
                if (transactionType == TransactionType.INTERACTION) {
                    return JSON.parseObject(jsonObject.toJSONString(), Interaction.class);
                }
                return JSON.parseObject(jsonObject.toJSONString(), Redemption.class);
            }).orElse(null);
            if (transaction != null) {
                transactionRepositoryV2.save(transaction);
                log.info("queue保存transaction成功结束");
            }

        }
    }

    @Override
    protected String getLabel() {
        return queueEnum.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return queueEnum;
    }
}
