package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @description: 订单加固定分
 * @author: lin.bj
 * @date: 2020-02-10 14:02
 */

@Getter
@Setter
public class OrderAddFixedPointProperties extends RuleProperties {
    // 加积分
    private int point;
    // 是否参与竞争
    private boolean competition;
}
