package cn.com.pg.loyalty.application.dependence;

import lombok.Data;

import java.io.Serializable;

/**
 * @author cooltea on 2019/6/22 11:31.
 * @version 1.0
 * @email cooltea007@163.com
 */
@Data
public class ExpiredPointMessage implements Serializable {

    /**
     * 积分体系
     */
    private String loyaltyStructure;

    /**
     * 品牌
     */
    private String brand;
    /**
     * 用户loyalty
     */
    private String loyaltyId;
    /**
     * 预留字段
     */
    private String reserve;

}
