package cn.com.pg.loyalty.domain.account;

/**
 * @Author: Hayden
 * @CreateDate: 2021/3/5 16:53
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/3/5 16:53
 * @Version: 1.0
 * @Description:
 */
public interface AccountOptRepository {

     void save(AccountOpt accountOpt);

    AccountOpt fetchAccountOptByLoyaltyId(String loyaltyId);

}
