package cn.com.pg.loyalty.infrastructure.lock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.*;
import org.springframework.stereotype.*;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @Author: Hayden
 * @CreateDate: 2021/5/28 15:01
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/5/28 15:01
 * @Version: 1.0
 * @Description:
 */
@Component
public class RedisLock implements Lock {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Override
    public boolean tryLock(String key, long expireTime, TimeUnit timeUnit) {
        return Optional.ofNullable(redisTemplate.opsForValue().setIfAbsent(key, "1", expireTime, timeUnit))
                .orElse(Boolean.FALSE);
    }

    @Override
    public void deleteLock(String key) {
        redisTemplate.delete(key);
    }

    @Override
    public boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    @Override
    public void deleteLock(String key, long waitMills) {
        redisTemplate.expire(key, waitMills, TimeUnit.MILLISECONDS);
    }
}
