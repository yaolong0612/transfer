package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.*;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.account.TierRulesCalculateAble;
import cn.com.pg.loyalty.domain.activity.*;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.gift.GiftCouponService;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.Transaction.PointTypeEnum;
import cn.com.pg.loyalty.domain.transaction.redemption.CheckJoinEnterpriseWechatStatusService;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import cn.com.pg.loyalty.infrastructure.lock.IdempotentLock;
import cn.com.pg.loyalty.infrastructure.lock.MutexLock;
import cn.com.pg.loyalty.interfaces.dto.InteractionExtraParams;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * @author Ladd
 * Transaction Service
 */
@Service
@Slf4j
public class TransactionService {

    public static final String GIFT_ISSUED_NUM = "ACTIVITY-GIFT-STOCK";
    private static final String ISSUED_LOCK_KEY = "ISSUED:";
    private static final int SLEEP_TIME = 10;
    private static final String RULE_PARAM_NAME_ACCOUNT = "account";
    private static final String LOYALTY_STRUCTURE = "loyaltyStructure";
    private static final String TRANSACTION_REDEMPTION_STATUS_BY_MQ = "Update-Transaction-Redemption-Status-And-Modify-The-Point-By-Mq";
    private static final String DISTRIBUTED_LOCK_TRANSACTION_REDEMPTION_STATUS_BY_MQ_AND_LOYALTY_ID = "Distributed-Lock-Transaction-Redemption-Status-By-Mq-Loyalty-Id";
    private static final String SUCCESS_0 = "0";
    private static final long LOCK_ISSUED_ACTIVITY_TIME = 2 * 60L;
    public static final String KPI_ADD_INTERACTION_POINT = "ADD_INTERACTION_POINT";
    private static final String KPI_BURN_POINT = "BURN_POINT";
    public static final String KPI_ADD_ORDER_POINT = "ADD_ORDER_POINT";
    private static final String TRANSACTION_REPOSITORY = "transactionRepository";
    private static final String INTERACTION_REPOSITORY = "interactionRepository";
    private static final String BRAND_STR = "brand";
    public static final String GIFT_STOCK_TO_REDEEM_GIFT = "Insufficient gift stock to redeem gift";
    private static final String CACHE_SERVICE = "cacheService";
    private static final String POINT_TYPE = "pointType";
    private static final String POINT_STR = "point";
    private static final String ORDER_REPOSITORY_V2_STR = "orderRepositoryV2";
    public static final String ACTIVITIES = "activities";
    public static final String REPEAT_REQUEST = "Repeat_request!";
    public static final String INTERACTION = "interaction";
    public static final String MEMBER_ID = "memberId";


    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private InteractionRepository interactionRepository;

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    @Autowired
    private PointTypeRepository pointTypeRepository;

    @Autowired
    private AmClientSupport amClientSupport;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private AccountService accountService;

    @Autowired
    private ServiceBusTemplate serviceBusTemplate;

    @Autowired
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;

    @Autowired
    private CacheService cacheService;

    @Autowired
    private LogisticsAgentClientImpl logisticsAgentClient;

    @Autowired
    private InteractionRepositoryV2 interactionRepositoryV2;

    @Autowired
    private KpiTemplate kpiTemplate;

    @Autowired
    private GiftCouponService giftCouponService;

    @Autowired
    private Environment environment;

    @Autowired
    private CouponGateway couponGateway;

    @Autowired
    private TierRulesCalculateAble tierRulesCalculateEngine;
    @Autowired
    private CheckJoinEnterpriseWechatStatusService checkJoinEnterpriseWechatStatusService;


    @Autowired
    private AccountRepositoryV2 accountRepositoryV2;
    @Autowired
    private TransactionRepositoryV2 transactionRepositoryV2;
    @Autowired
    private MessageService messageService;

    @Autowired
    private CalculateService calculateServiceImpl;


    @MutexLock(lockKeys = {"#brand", "#memberId"})
    public AccountTransactionResult addInteractionPoint(String brand, String region, String channel,
                                                        String memberId, String pointType, String qrCode, String sku,
                                                        Boolean newMember, Integer point, String reason, String token,
                                                        String externalBusinessId) {
        log.info("交互积分pointType: {}, 调整积分分数：{}", pointType, point);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAndInitialInExistSubAccount(memberId, loyaltyStructure, brand, channel);
        account.checkAccountAvailable(loyaltyStructure);
        if (StringUtils.isNotEmpty(externalBusinessId)) {
            List<Interaction> interactions = interactionRepositoryV2
                    .fetchInteractionsByExternalBusinessId(account.loyaltyId(), externalBusinessId);
            if (!CollectionUtils.isEmpty(interactions)) {
                throw new SystemException(REPEAT_REQUEST, ResultCodeMapper.REQUEST_REPEAT);
            }
        }
        PointType pointTypeObject = cacheService.validatePointType(pointType, loyaltyStructure.name(), TransactionType.INTERACTION);
        if ("REGISTER".equals(pointTypeObject.pointType())) {
            throw new SystemException("The pointType is wrong.", ResultCodeMapper.PARAM_ERROR);
        }
        List<Activity> activityList = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(pointType, loyaltyStructure.name());
        if (activityList.isEmpty()) {
            throw new SystemException(pointTypeObject.pointType() + ": Can't find the configured activities or avtivities are overdue", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        //交互(签到，qrcode扫码，收藏店铺)加积分
        Interaction interaction = new Interaction(account.loyaltyId(), brand, channel, loyaltyStructure, memberId, externalBusinessId);
        //触发规则引擎
        RuleEngineSupport ruleEngineSupport = RuleEngineSupport.interactionRuleEngineSupportBuild();
        ruleEngineSupport.addFact(ACTIVITIES, activityList)
                .addFact(RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(INTERACTION, interaction)
                .addFact(POINT_TYPE, pointTypeObject)
                .addFact("qrCode", qrCode)
                .addFact(POINT_STR, point)
                .addFact("sku", sku)
                .addFact("newMember", Boolean.TRUE.equals(newMember))
                .addFact(BRAND_STR, brand)
                .addFact("reason", reason)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact("token", token)
                .addFact(MEMBER_ID, memberId)
                .addFact(CACHE_SERVICE, cacheService)
                .addFact(INTERACTION_REPOSITORY, interactionRepository)
                .addFact(ORDER_REPOSITORY_V2_STR, orderRepositoryV2)
                .addFact("stringRedisTemplate", stringRedisTemplate)
                .addFact(CACHE_SERVICE, cacheService)
                .fire();

        List<Activity> activities = cacheService
                .fetchUniqueTemplateAvailableActivities(TransactionType.INTERACTION, loyaltyStructure.name(), interaction.getCreatedTime());

        RuleEngineSupport.interactionLimitAfterCalculate()
                .addFact(RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(INTERACTION, interaction)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact(ACTIVITIES, activities)
                .addFact(TRANSACTION_REPOSITORY, transactionRepository)
                .fire();

        //重新计算等级
        tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, interaction));
        tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, false));

        if (interaction.point() != 0) {
            account.calculatePoint(interaction, loyaltyStructure);
        }
        batchUpdateDBComponentImpl.saveTransactionAndAccount(interaction, account);
        //所有扣减积分传的point都是负数则推KPI的时候分开推送
        kpiTemplate.sendKpi(account.memberId(), Math.abs(interaction.point()), brand,
                adjustPointLessThanZero(point, interaction) ? KPI_BURN_POINT : KPI_ADD_INTERACTION_POINT, channel, pointTypeObject, null);
        if ((Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType)
                || Transaction.PointTypeEnum.SCAN_CODE_TRANSIT.name().equals(pointType))
                && StringUtils.isNotEmpty(qrCode)) {
            // 保存qrCode进redis，时间90天
            cacheService.setQrCodeToRedis(loyaltyStructure.name(), qrCode, interaction.valueType(loyaltyStructure));
        }
        return new AccountTransactionResult(account, interaction);
    }


    @MutexLock(lockKeys = {"#interaction.brand", "#interaction.memberId"})
    public AccountTransactionResult addInteractionPointV2(Interaction interaction, Account account, LoyaltyStructure loyaltyStructure, String pointType, InteractionExtraParams extraParams, Integer point, String reason, String token,
                                                          String externalBusinessId) {
        log.info("memberId :{},交互积分pointType: {}, 调整积分分数：{},externalBusinessId:{}", account.getMemberId(), pointType, point, externalBusinessId);
        PointType pointTypeObject = cacheService.validatePointType(pointType, loyaltyStructure.name(), TransactionType.INTERACTION);
        if ("REGISTER".equals(pointTypeObject.pointType())) {
            throw new SystemException("The pointType is wrong.", ResultCodeMapper.PARAM_ERROR);
        }
        List<Activity> interactionActivityList = cacheService.fetchAvailableActivitiesByPointTypeAndLoyaltyStructOrderByPriorityAndUpdateTimeDesc(pointType, loyaltyStructure.name());
        if (interactionActivityList.isEmpty()) {
            throw new SystemException(pointTypeObject.pointType() + ": Can't find the configured activities or avtivities are overdue", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        //交互(签到，qrcode扫码，收藏店铺)加积分
        //触发规则引擎
        RuleEngineSupport ruleEngineSupport = RuleEngineSupport.interactionRuleEngineSupportBuild();
        Interaction transitPointInteraction = new Interaction(account.loyaltyId(), interaction.brand(),
                interaction.channel(), loyaltyStructure, account.memberId(), interaction.getExternalBusinessId());
        ruleEngineSupport.addFact(ACTIVITIES, interactionActivityList)
                .addFact(RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(INTERACTION, interaction)
                .addFact(POINT_TYPE, pointTypeObject)
                .addFact("qrCode", extraParams.getQrcode())
                .addFact(POINT_STR, point)
                .addFact("sku", extraParams.getSku())
                .addFact("newMember", Boolean.TRUE.equals(extraParams.isNewMember()))
                .addFact(BRAND_STR, interaction.getBrand())
                .addFact("reason", reason)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact("token", token)
                .addFact(MEMBER_ID, interaction.getMemberId())
                .addFact(CACHE_SERVICE, cacheService)
                .addFact(INTERACTION_REPOSITORY, interactionRepository)
                .addFact(ORDER_REPOSITORY_V2_STR, orderRepositoryV2)
                .addFact("stringRedisTemplate", stringRedisTemplate)
                .addFact("convertPoint", extraParams.isConvertPoint())
                .addFact("transitPointInteraction", transitPointInteraction)
                .addFact("valueType", extraParams.getValueType() != null ? extraParams.getValueType().name() : null)
                .fire();

        List<Activity> activities = cacheService
                .fetchUniqueTemplateAvailableActivities(TransactionType.INTERACTION, loyaltyStructure.name(), interaction.getCreatedTime());

        RuleEngineSupport.interactionLimitAfterCalculate()
                .addFact(RULE_PARAM_NAME_ACCOUNT, account)
                .addFact(INTERACTION, interaction)
                .addFact(LOYALTY_STRUCTURE, loyaltyStructure)
                .addFact(ACTIVITIES, activities)
                .addFact(TRANSACTION_REPOSITORY, transactionRepository)
                .fire();

        //重新计算等级
        tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, interaction));
        //计算等级奖励积分
        tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, false));

        if (interaction.point() != 0) {
            //积分扣减
            account.calculatePoint(interaction, loyaltyStructure);
        }
        //判断执行转换积分操作时需要扣减过渡积分
        if (transitPointInteraction.getPoint() == 0) {
            //普通交互只会生成一天记录
            batchUpdateDBComponentImpl.saveAccountAndTransactionV2(account, interaction);
            sendPointPoolMessage(loyaltyStructure, account, interaction);
        } else {
            //过渡积分转换为成长分会生成2条记录
            account.calculatePoint(transitPointInteraction, loyaltyStructure);
            batchUpdateDBComponentImpl.saveAccountAndTransactionV2(account, interaction, transitPointInteraction);
            sendPointPoolMessage(loyaltyStructure, account, interaction, transitPointInteraction);
        }
        //所有扣减积分传的point都是负数则推KPI的时候分开推送
        kpiTemplate.sendKpi(account.memberId(), Math.abs(interaction.point()), interaction.getBrand(),
                adjustPointLessThanZero(point, interaction) ? KPI_BURN_POINT : KPI_ADD_INTERACTION_POINT, interaction.getChannel(), pointTypeObject, null);
        if ((Transaction.PointTypeEnum.SCAN_CODE.name().equals(pointType)
                || Transaction.PointTypeEnum.SCAN_CODE_TRANSIT.name().equals(pointType))
                && StringUtils.isNotEmpty(extraParams.getQrcode())) {
            // 保存qrCode进redis，时间90天
            cacheService.setQrCodeToRedis(loyaltyStructure.name(), extraParams.getQrcode(), interaction.valueType(loyaltyStructure));
        }
        return new AccountTransactionResult(account, interaction);
    }

    /**
     * 发送积分池消息
     */
    private void sendPointPoolMessage(LoyaltyStructure structure, Account account, Transaction... transactionList) {
        for (Transaction transaction : transactionList) {
            PoolMessage poolMessage = new PoolMessage(structure, transaction, account);
            messageService.sendMessage4PointPool(poolMessage);
        }
    }

    private boolean adjustPointLessThanZero(Integer point, Interaction interaction) {
        return Optional.ofNullable(point).orElse(0) < 0 || (interaction.point() < 0);
    }


    public AccountTransactionResult addOrderPointV2(String brand, String region, String channel,
                                                    String memberId, String pointType, String orderId,
                                                    LocalDateTime orderDateTime, Set<OrderItem> orderItems,
                                                    String storeCode, int point) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAndInitialInExistSubAccount(memberId, loyaltyStructure, brand, channel);
        account.checkAccountAvailable(loyaltyStructure);
        //可以考虑聚合到order 实例化时计算，需评估
        Double realTotalAmount = orderItems.stream().mapToDouble(OrderItem::getRealAmount).sum();
        Order order = new Order(account.loyaltyId(), brand, channel, orderId, loyaltyStructure, orderDateTime,
                LocalDateTime.now(), orderItems, realTotalAmount, account.tier(loyaltyStructure.name()).getLevel(),
                memberId, storeCode);
        if (this.checkIsAddOrderRepeat(account, order)) {
            throw new SystemException("Order is repeat", ResultCodeMapper.ORDER_ID_EXISTS);
        }
        try {
            PointType originPointType = cacheService.validatePointType(pointType, loyaltyStructure.name(),
                    TransactionType.ORDER);

            List<Activity> availableActivities = cacheService.fetchUniquePointTypeAvailableActivities(
                    TransactionType.ORDER, loyaltyStructure.name(), order.getOrderDateTime());

            if (!PointTypeEnum.ORDER_ADD_POINT.name().equals(pointType)) {
                availableActivities = availableActivities.stream()
                        .filter(activity -> activity.pointType().equals(pointType))
                        .collect(Collectors.toList());
            }

            if (CollectionUtils.isEmpty(availableActivities)) {
                throw new SystemException("There is no activity that correspond to this pointType", ResultCodeMapper.ACTIVITY_NOT_FOUND);
            }
            //订单加积分
            calculateServiceImpl.calculateOrderPoint(originPointType, order, account, loyaltyStructure,
                    availableActivities, point);

            tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, order));
            tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, false));
            kpiTemplate.sendKpi(account.memberId(), order.point(),
                    brand, KPI_ADD_ORDER_POINT, channel, originPointType, null);
            account.setUpdatedTime(LocalDateTime.now());
            batchUpdateDBComponentImpl.saveTransactionAndAccount(order, account);
        } catch (Exception e) {
            String orderKey = cacheService.getKey(CacheService.KeyEnum.COMMON_ORDER_POINT, order.brand(), account.getMemberId(), order.getOrderId());
            stringRedisTemplate.delete(orderKey);
            throw e;
        }
        return new AccountTransactionResult(account, order);
    }

    public void migrateOrderRefund(String loyaltyId, String brand, Double refundAmount) {
        log.info("计算用户:{}，扣减其migration金额: {}开始", loyaltyId, refundAmount);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        List<Interaction> transactions = interactionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionStatusAndTransactionTypeAndBrand(partitionKey, loyaltyId, Transaction.TransactionStatus.MIGRATION, TransactionType.INTERACTION, brand);
        if (!transactions.isEmpty()) {
            Comparator<Interaction> comparator = (in1, in2) -> {
                if (in1.getCreatedTime().isAfter(in2.getCreatedTime())) {
                    return -1;
                }
                return 1;
            };
            Interaction interaction = transactions.stream().sorted(comparator).findFirst().orElseThrow(() -> {
                log.error("找不到这个用户的迁移记录{}", loyaltyId);
                return new SystemException("ACCOUNT_NOT_FOUND", ResultCodeMapper.ACCOUNT_NOT_FOUND);
            });
            log.info("计算用户:{}, 扣减其migration记录ID: {}", loyaltyId, interaction.getId());
            interaction.minusMigrationPoint(refundAmount.intValue());
            interactionRepository.save(interaction);
            log.info("计算用户:{}， 扣减其migration金额: {}完成", loyaltyId, refundAmount);
        }
    }

    public Transaction findByTransactionId(String transactionId, String brand, String loyaltyId) {
        List<Transaction> transactionList = transactionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        if (transactionList.isEmpty()) {
            throw new SystemException("The record you inquired does not exist. The Id is wrong", ResultCodeMapper.PARAM_ERROR);
        }
        Transaction transaction = transactionList.get(0);
        if (!brand.equals(transaction.brand())) {
            throw new SystemException("The brand :".concat(brand).concat(" is wrong,it doesn't map with the transactoinId"), ResultCodeMapper.PARAM_ERROR);
        }
        return transaction;
    }

    public Redemption findRedemptionById(String transactionId, LoyaltyStructure structure, String memberId) {
        Account account = accountService.fetchAccountByMemberIdAndCheck(structure, memberId);
        String pk = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        return redemptionRepository.findByPartitionKeyAndId(pk, transactionId).stream()
                .filter(r -> StringUtils.equals(r.getLoyaltyId(), account.loyaltyId()))
                .findFirst()
                .orElseThrow(() -> new SystemException("The redemption not exist", ResultCodeMapper.PARAM_ERROR));
    }


    /**
     * 返回issuedNum
     *
     * @param activity
     * @param reductionInventory
     * @param refundGiftMap
     * @return
     */
    private Map<String, Long> refundGiftIssuedNum(Activity activity, boolean reductionInventory, Map<String, Integer> refundGiftMap) {
        Map<String, Long> giftIdStockMap = new ConcurrentHashMap<>(4);
        if (reductionInventory) {
            Map<String, Integer> processedGiftMap = new HashMap<>(4);
            try {
                for (Map.Entry<String, Integer> entry : refundGiftMap.entrySet()) {
                    String giftId = entry.getKey();
                    int quantity = entry.getValue();
                    String issuedNumRedisKey = GIFT_ISSUED_NUM.concat("-").concat(activity.activityId()).concat("-").concat(giftId);
                    //如果redis找不到对应gift的issuedNum,查数据库，回传到redis，如果找不到，会抛出异常
                    cacheService.getIssuedNum(activity.activityId(), giftId);
                    // 修改redis的issuedNum
                    Long issuedNum = stringRedisTemplate.opsForValue().decrement(issuedNumRedisKey, quantity);
                    processedGiftMap.put(issuedNumRedisKey, quantity);
                    if (issuedNum != null) {
                        giftIdStockMap.put(giftId, issuedNum);
                    }
                }
            } catch (Exception e) {
                // 有异常回滚redis操作
                for (Map.Entry<String, Integer> entry : processedGiftMap.entrySet()) {
                    String redisKey = entry.getKey();
                    Integer quantity = entry.getValue();
                    stringRedisTemplate.opsForValue().increment(redisKey, quantity);
                }
                throw e;
            }
        }
        return giftIdStockMap;
    }

    public PageableResult<Redemption> fetchRedemptionList(String activityId, String brand,
                                                          String region, LocalDateTime startTime,
                                                          LocalDateTime endTime, Integer perPage,
                                                          Integer page, String memberId,
                                                          RedemptionStatus redemptionStatus,
                                                          DeliveryChannel deliveryChannel, String channel) {
        Account account = null;
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        String startTimeStampStr = String.valueOf(startTime.toEpochSecond(ZoneOffset.MAX));
        String endTimeStampStr = String.valueOf(endTime.toEpochSecond(ZoneOffset.MAX));
        String key;
        if (redemptionStatus != null && deliveryChannel != null) {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, activityId, region, redemptionStatus.name(), deliveryChannel.name(), memberId, channel, startTimeStampStr, endTimeStampStr, brand);
        } else if (redemptionStatus != null) {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, activityId, region, redemptionStatus.name(), memberId, channel, startTimeStampStr, endTimeStampStr, brand);
        } else if (deliveryChannel != null) {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, activityId, region, deliveryChannel.name(), memberId, channel, startTimeStampStr, endTimeStampStr, brand);
        } else {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, activityId, region, memberId, channel, startTimeStampStr, endTimeStampStr, brand);
        }
        // 从redis中查询。获取总数，根据page和perPage获取score范围内得值。
        PageableResult<Redemption> redemptionPageableResult = cacheService.fetchPageableResult(page, perPage, key, Redemption.class);
        if (redemptionPageableResult != null) {
            return redemptionPageableResult;
        }

        if (memberId != null) {
            account = accountService.fetchAccountByMemberIdAndCheck(structure, memberId);
        }
        List<Redemption> redemptionList;
        if (channel != null && memberId != null && redemptionStatus != null) {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndRedemptionStatusAndTransactionTypeAndChannelAndDeliveryChannel(
                    PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime), redemptionStatus, TransactionType.REDEMPTION, channel, deliveryChannel);
        } else if (channel != null && memberId != null) {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndChannelAndDeliveryChannel(
                    PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime), TransactionType.REDEMPTION, channel, deliveryChannel);
        } else if (channel != null && redemptionStatus != null) {
            redemptionList = redemptionRepository.findByActivityIdAndBrandAndCreatedTimeBetweenAndRedemptionStatusAndTransactionTypeAndChannelAndDeliveryChannel(
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime), redemptionStatus, TransactionType.REDEMPTION, channel, deliveryChannel);
        } else if (memberId != null && redemptionStatus != null) {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusAndDeliveryChannel(
                    PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime), TransactionType.REDEMPTION, redemptionStatus, deliveryChannel);
        } else if (channel != null) {
            redemptionList = redemptionRepository.findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndChannelAndDeliveryChannel(
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    TransactionType.REDEMPTION, channel, deliveryChannel);
        } else if (memberId != null) {
            redemptionList = redemptionRepository.findByPartitionKeyAndLoyaltyIdAndActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndDeliveryChannel(
                    PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), account.loyaltyId(),
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    TransactionType.REDEMPTION, deliveryChannel);
        } else if (redemptionStatus != null) {
            redemptionList = redemptionRepository.findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndRedemptionStatusAndDeliveryChannel(
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    TransactionType.REDEMPTION, redemptionStatus, deliveryChannel);
        } else {
            redemptionList = redemptionRepository.findByActivityIdAndBrandAndCreatedTimeBetweenAndTransactionTypeAndDeliveryChannel(
                    activityId, brand, LoyaltyDateTimeUtils.localDateTimeToString(startTime),
                    LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    TransactionType.REDEMPTION, deliveryChannel);
        }
        redemptionList = filterTransactionStatus(redemptionList);

        cacheService.setPageableValueToRedis(key, perPage, redemptionList, Redemption.comparatorByRedemptionCreatedTimeDesc(), 300);

        return cacheService.generatePage(page, perPage, redemptionList, Redemption.comparatorByRedemptionCreatedTimeDesc());
    }

    private List<Redemption> filterTransactionStatus(List<Redemption> redemptionList) {
        redemptionList = redemptionList.stream().filter(Redemption::visibleIsNot).collect(Collectors.toList());
        return redemptionList;
    }


    /**
     * Admin修改redemption状态，如果是物流微服务发货方式，就不让修改。
     *
     * @param transactionId
     * @param redemptionStatus
     * @param deliveryNumber
     * @param storeCode
     */
    public void updateRedemptionStatusByIdForAdmin(String transactionId, String redemptionStatus, String deliveryNumber, String storeCode, LocalDateTime updateTime) {
        List<Redemption> redemptionList = redemptionRepository.findRedemptionById(transactionId);
        if (redemptionList.isEmpty()) {
            throw new SystemException("The redemption is not found", ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }
        Redemption redemption = redemptionList.get(0);
        if (redemption.finished()) {
            throw new SystemException("The redemption has been canceled or accomplished, can not modify", ResultCodeMapper.PARAM_ERROR);
        }
        // 如果storeCode不为空，则检查
        if (storeCode != null) {
            Store store = cacheService.getStoreByStoreCode(storeCode);
            if (store == null) {
                throw new SystemException("Counter" + storeCode + "not exists", ResultCodeMapper.PARAM_ERROR);
            }
            store.checkAvailable();
        }
        //更新状态
        redemption.updateRedemptionStatus(RedemptionStatus.valueOf(redemptionStatus), storeCode, deliveryNumber, updateTime);
        //保存更新状态
        redemptionRepository.save(redemption);
    }

    public void updateRedemptionStoreCodeById(String transactionId, String memberId, String region, String brand, String storeCode) {
        LoyaltyStructure structure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberId(structure, memberId);
        if (account == null) {
            throw new SystemException("The Am member ID you entered is not correct, there is no such person in the system", ResultCodeMapper.PARAM_ERROR);
        }
        Redemption redemption = updateRedemptionCommonMethod(transactionId, account.loyaltyId());
        if (redemption.judgeCanceled()) {
            throw new SystemException("The redemption has been canceled, this is redemption id is".concat(transactionId), ResultCodeMapper.PARAM_ERROR);
        }
        Store store = cacheService.getStoreByStoreCode(storeCode);
        if (store == null) {
            throw new SystemException("Store" + storeCode + " not exist", ResultCodeMapper.PARAM_ERROR);
        }
        store.checkAvailable();
        Activity activity = cacheService.findActivityById(redemption.activityId());
        redemption.updateRedemptionStoreCode(storeCode, activity);
        //保存更新状态
        redemptionRepository.save(redemption);
    }

    /**
     * 修改redemption，公共的部分
     *
     * @param transactionId
     * @return
     */
    private Redemption updateRedemptionCommonMethod(String transactionId, String loyaltyId) {
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        if (redemptionList.isEmpty()) {
            throw new SystemException("The exchange order ID is incorrect. There is no exchange order", ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }
        return redemptionList.get(0);
    }


    /**
     * 把库存同步到redis
     *
     * @param activityId
     * @param stringLongMap
     */
    public void synchronizeRedisInventoryToDatabaseByMq(String redemptionId, String activityId, Boolean isRefund, Map<String, Long> stringLongMap) {
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        RedemptionServiceBusProperties updateActivityStock = new RedemptionServiceBusProperties(redemptionId, activityId, isRefund, stringLongMap);
        String jsonString = JSON.toJSONString(updateActivityStock);
        JSONObject jsonObject = JSON.parseObject(jsonString);
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.SYNCHRONIZE_REDIS_INVENTORY_TO_DATABASE_QUEUE_NAME, loyaltyMessage);
    }

    /**
     * 通过Service Bus把库存同步更新到Gift,这里不需要加分布式锁，在消费Service Bus消息那里加分布式锁，
     * 或者使用ack机制，消费完成才让其他线程消费继续消费MQ的消费，保证了库存同步性。
     */
    public Activity synchronizationGiftStock(String activityId, Boolean isRefund, Map<String, Long> stringIntegerMap) {
        Boolean isExists;
        String key = ISSUED_LOCK_KEY.concat(activityId);
        try {
            do {
                isExists = stringRedisTemplate.opsForValue().setIfAbsent(key, isRefund.toString(), LOCK_ISSUED_ACTIVITY_TIME, TimeUnit.SECONDS);
                if (isExists != null && !isExists) {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                        log.error("线程休眠时被中断: {}", e.getMessage());
                        Thread.currentThread().interrupt();
                    }
                }
            } while ((isExists != null && !isExists));
            List<Activity> activityList = activityRepository.findActivityById(activityId);
            if (activityList.isEmpty()) {
                return null;
            }
            Activity activity = activityList.get(0);
            Map<String, RedemptionItem> map = activity.getGifts();
            Integer stock;
            for (Map.Entry<String, Long> entry : stringIntegerMap.entrySet()) {
                RedemptionItem redemptionItem = map.get(entry.getKey());
                stock = Integer.valueOf(entry.getValue().toString());
                if (redemptionItem.getIssuedNum() < stock ||
                        (isRefund && redemptionItem.getIssuedNum() > stock)) {
                    redemptionItem.setIssuedNum(stock);
                    activity = activityRepository.save(activity);
                }
            }
            log.info("同步兑换订单中兑换数量到活动Id:{}成功", activityId);
            return activity;
        } finally {
            stringRedisTemplate.delete(key);
        }
    }


    /**
     * 检查需要发送给logistic
     * 代码从原来SettlementRedemptionRule类里挪过来
     * 并与TransactionService#deliversGoods原来的判断逻辑整合在一起
     *
     * @param activity
     * @param redemption
     * @return
     */
    private boolean checkNeedSendToLogistics(Activity activity, Redemption redemption) {
        String activityId = redemption.getActivityId();
        if (!redemption.isCreatedStatus()) {
            log.info("兑换id：{} 状态：{} 不发货", redemption.getId(), redemption.getRedemptionStatus());
            return Boolean.FALSE;
        }
        if (activity == null) {
            log.info("Activity deleted, system error，this activityId is {}", activityId);
            throw new SystemException("Activity deleted, system error，this activityId is " + activityId, ResultCodeMapper.PARAM_ERROR);
        }
        RedemptionProperties ruleProperties = (RedemptionProperties) activity.ruleProperties();
        boolean directDelivered = ruleProperties.isAllowDeliverDirectly();
        return redemption.getDeliveryChannel().sendLogisticsService() && directDelivered;
    }


    /**
     * 通过MQ方式解决兑换礼品后的发货
     *
     * @param redemptionId
     * @param activityId
     * @param memberId
     */
    public void deliversGoods(String redemptionId, String partitionKey, String activityId, String memberId) {
        Activity activity = cacheService.findActivityById(activityId);
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(partitionKey, redemptionId);
        if (redemptionList.isEmpty()) {
            throw new SystemException("The exchange order ID is incorrect. There is no exchange order", ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }
        Redemption redemption = redemptionList.get(0);
        if (!checkNeedSendToLogistics(activity, redemption)) {
            log.info("Redemption:{},not config logistics", redemptionId);
            return;
        }
        deliversGoodsToLogistics(redemption, activity, memberId, null);

        log.info("With serviceBus, the shipping process is success,this activityId is {},memberId is {}", activityId, memberId);

    }

    /**
     * 兑换订单后，通过MQ，这是真正的修改这个人的可用积分transaction记录
     *
     * @param redemptionId
     * @param partitionKey
     */
    public void modifyAvailableCreditsForRedemption(String redemptionId, String partitionKey) {
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(partitionKey, redemptionId);
        if (redemptionList.isEmpty()) {
            throw new SystemException("The exchange order was considered deleted and an error occurred in the system，this redemptionId is" + redemptionId, ResultCodeMapper.UNEXPECTED_ERROR);
        }

        Redemption redemption = redemptionList.get(0);
        //不能同时处理同一个人的订单。
        String distributedLockKey = DISTRIBUTED_LOCK_TRANSACTION_REDEMPTION_STATUS_BY_MQ_AND_LOYALTY_ID.concat("-").concat(redemption.getLoyaltyId());
        try {
            boolean flagLock = stringRedisTemplate.opsForValue().setIfAbsent(distributedLockKey, "TRUE", SLEEP_TIME, TimeUnit.SECONDS);
            if (!flagLock) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e1) {
                    log.error("线程休眠中断：{}", e1.getMessage());
                    Thread.currentThread().interrupt();
                }
                throw new SystemException("Failure to modify the integral record through MQ without obtaining a distributed lock", ResultCodeMapper.UNEXPECTED_ERROR);
            }

            //获取这个人的可用积分大于0的历史的订单积分和交互积分记录。
            List<Transaction> list = transactionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionTypeNotAndAvailablePointGreaterThanOrderByCreatedTime(
                    redemption.partitionKey(), redemption.getLoyaltyId(),
                    redemption.getTransactionType(), 0);
            if (redemption.brand().equals("PAMPERS")) {
                list = getCalculateList(redemption, list);
            }
            //如果查询不到记录，系统可能出现了问题。
            if (list.isEmpty()) {
                log.info("The system of integration is not working for this guy. This guy is:{}", redemption.getLoyaltyId());
                throw new SystemException("The system of integration is not working for this guy.", ResultCodeMapper.UNEXPECTED_ERROR);
            }

            //获取需要花费的积分,使用redis是防止保存的时候失败的操作。
            int pointCost = 0;
            String key = TRANSACTION_REDEMPTION_STATUS_BY_MQ.concat("-").concat(redemption.getId());
            if (Boolean.TRUE.equals(stringRedisTemplate.hasKey(key))) {
                pointCost = Integer.valueOf(stringRedisTemplate.opsForValue().get(key));
            } else {
                pointCost = redemption.getPoint();
            }
            log.info("Is deducting this person's score, this person is {}, the score is: {}", redemption.getLoyaltyId(), redemption.getPoint());
            //开始计算积分订单
            doDeductRecordPoint(list, pointCost, key, redemption);
        } finally {
            stringRedisTemplate.delete(distributedLockKey);
        }
    }

    private void doDeductRecordPoint(List<Transaction> list, int pointCost, String key, Transaction paramTransaction) {
        for (Transaction transaction : list) {
            if (Transaction.TransactionStatus.ACTIVATE.equals(transaction.getTransactionStatus()) ||
                    Transaction.TransactionStatus.USED.equals(transaction.getTransactionStatus()) ||
                    Transaction.TransactionStatus.MIGRATION.equals(transaction.getTransactionStatus())) {
                pointCost = transaction.reduceAvailablePoint(pointCost);
                log.info("After the exchange, someone's points are being deducted. This person is: {}. The points deducted for this cycle are {}.", transaction.getLoyaltyId(), pointCost);
                transactionRepository.save(transaction);
                stringRedisTemplate.opsForValue().set(key, String.valueOf(pointCost), 24L, TimeUnit.HOURS);
                log.info("The deduction succeeds. This person is: {}. The points deducted for this cycle are {}.", transaction.getLoyaltyId(), pointCost);
                if (pointCost <= 0) {
                    break;
                }
            }
        }
        // 如果所有积分记录都不足于扣除
        // 如果没有记录则新插入一条availablePoint负值为 -pointCost 的记录
        // 否则取最后一条记录 将其 availablePoint 扣减成负值-pointCost
        if (pointCost > 0) {
            Transaction transaction = getTransactionRecord(list, paramTransaction);
            log.info("扣除积分记录时不足与扣取所有，还少：{}分，将记录：{}的availablePoint扣成负数", -pointCost, transaction.getId());
            transaction.reduceAvailablePointNegative(pointCost);
            transactionRepository.save(transaction);
            stringRedisTemplate.opsForValue().set(key, String.valueOf(0), 24L, TimeUnit.HOURS);
        }
    }

    private Transaction getTransactionRecord(List<Transaction> list, Transaction transaction) {
        // 取最后一条记录
        if (!CollectionUtils.isEmpty(list)) {
            return list.get(list.size() - 1);
        }
        Account account = accountService.fetchAccountByLoyaltyId(transaction.getLoyaltyId());
        if (account == null) {
            log.info("积分不够扣取创建新的负值可用积分记录时获取不到用户:{}", transaction.getLoyaltyId());
            throw new SystemException("获取不到用户" + transaction.getLoyaltyId(), ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(account.getRegion(), transaction.brand());
        return new Interaction(transaction.getLoyaltyId(),
                transaction.brand(), transaction.channel(), loyaltyStructure, transaction.getMemberId(), Transaction.TransactionStatus.BORROW);
    }

    public void modifyAvailableCreditsForInteraction(String interactionId, String partitionKey) {
        List<Interaction> interactions = interactionRepository.findByPartitionKeyAndId(partitionKey, interactionId);
        if (interactions.isEmpty()) {
            log.info("The exchange order was considered deleted and an error occurred in the system，this interactionId is {}", interactionId);
            throw new SystemException("The exchange order was considered deleted and an error occurred in the system，this interactionId is" + interactionId, ResultCodeMapper.UNEXPECTED_ERROR);
        }
        Interaction interaction = interactions.get(0);
        //不能同时处理同一个人的订单。
        String distributedLockKey = DISTRIBUTED_LOCK_TRANSACTION_REDEMPTION_STATUS_BY_MQ_AND_LOYALTY_ID.concat("-").concat(interaction.getLoyaltyId());
        try {
            boolean flagLock = stringRedisTemplate.opsForValue().setIfAbsent(distributedLockKey, "TRUE", SLEEP_TIME, TimeUnit.SECONDS);
            if (!flagLock) {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException e1) {
                    log.error("线程休眠中断：{}", e1.getMessage());
                    Thread.currentThread().interrupt();
                }
                throw new SystemException("Failure to modify the integral record through MQ without obtaining a distributed lock", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            //获取这个人的可用积分大于0的历史的订单积分和交互积分记录。
            List<Transaction> list = transactionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionTypeNotAndAvailablePointGreaterThanOrderByCreatedTime(
                    interaction.partitionKey(), interaction.getLoyaltyId(),
                    TransactionType.REDEMPTION, 0);
            if (interaction.brand().equals("PAMPERS")) {
                list = getCalculateList(interaction, list);
            }

            //如果查询不到记录，系统可能出现了问题。
            if (list.isEmpty()) {
                log.info("The system of integration is not working for this guy. This guy is:{}", interaction.getLoyaltyId());
                throw new SystemException("The system of integration is not working for this guy.", ResultCodeMapper.UNEXPECTED_ERROR);
            }

            //获取需要花费的积分,使用redis是防止保存的时候失败的操作。
            int pointCost = 0;
            String key = TRANSACTION_REDEMPTION_STATUS_BY_MQ.concat("-").concat(interaction.getId());
            if (Boolean.TRUE.equals(stringRedisTemplate.hasKey(key))) {
                pointCost = Integer.valueOf(stringRedisTemplate.opsForValue().get(key));
            } else {
                pointCost = interaction.getPoint();
                if (pointCost >= 0) {
                    stringRedisTemplate.delete(distributedLockKey);
                    return;
                }
                pointCost = -pointCost;
            }
            log.info("Is deducting this person's score, this person is {}, the score is: {}", interaction.getLoyaltyId(), interaction.getPoint());
            //开始计算积分订单
            doDeductRecordPoint(list, pointCost, key, interaction);
        } finally {
            stringRedisTemplate.delete(distributedLockKey);
        }
    }

    private List<Transaction> getCalculateList(Transaction transaction, List<Transaction> list) {
        if (!Arrays.asList(environment.getActiveProfiles()).contains("ml")) {
            return list;
        }
        LoyaltyStructure structure = cacheService.findLoyaltyStructure("ML", transaction.brand());
        return list.stream().filter(transaction1 -> transaction1.valueType(structure) == transaction.valueType(structure))
                .collect(Collectors.toList());
    }

    /**
     * 批量转换兑换的A领取柜台到B柜台
     * 包括转柜（柜转实体柜），发运到家（柜转虚拟柜）逻辑
     */
    public TransferStoreCodeResult transferStoreCode(String activityId, String originalStoreCode,
                                                     String destinationStoreCode, List<String> acceptGiftIdList) {
        Store originalStore = cacheService.getStoreByStoreCode(originalStoreCode);
        Store destinationStore = cacheService.getStoreByStoreCode(destinationStoreCode);
        if (originalStore == null) {
            throw new SystemException("The originalStoreCode can not be found. ", ResultCodeMapper.PARAM_ERROR);
        }
        if (destinationStore == null) {
            throw new SystemException("The destinationStore can not be found. ", ResultCodeMapper.PARAM_ERROR);
        }
        destinationStore.checkAvailable();
        List<Redemption> redemptionList = redemptionRepository.findByTransactionTypeAndRedemptionStatusAndActivityIdAndDeliveryChannelAndStoreCode(TransactionType.REDEMPTION, RedemptionStatus.CREATED, activityId, DeliveryChannel.C2, originalStoreCode);
        Set<String> involvedConsumers = new HashSet<>();
        for (Redemption redemption : redemptionList) {
            if (!CollectionUtils.isEmpty(acceptGiftIdList)) {
                Optional<GiftItem> giftItem = redemption.getGiftItemList()
                        .stream().filter(item -> acceptGiftIdList.contains(item.getGiftId())).findFirst();
                if (!giftItem.isPresent()) {
                    continue;
                }
            }
            String loyaltyId = redemption.getLoyaltyId();
            involvedConsumers.add(loyaltyId);
            redemption.updateStoreCode(destinationStoreCode);
            redemptionRepository.save(redemption);
            if (Store.SHIPMENT_ARRIVED_HOME.equals(redemption.getStoreCode())) {
                sendTransferStoreMessageToMq(originalStoreCode, redemption, Redemption.MlOlayCounterTransferType.TRANSFER_TO_HOME);
            } else {
                sendTransferStoreMessageToMq(originalStoreCode, redemption, Redemption.MlOlayCounterTransferType.TRANSFER_TO_COUNTER);
            }
        }
        return new TransferStoreCodeResult(involvedConsumers.size(), redemptionList.size());
    }

    /**
     * 到柜/转换柜台，使用异步方式进行发短信
     */
    private void sendTransferStoreMessageToMq(String originalStoreCode, Redemption redemption, Redemption.MlOlayCounterTransferType type) {
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        Store counter = cacheService.getStoreByStoreCode(redemption.getStoreCode());
        String storeName = counter == null ? "快递到家" : counter.getStoreName();
        RedemptionServiceBusProperties redemptionServiceBusProperties = new RedemptionServiceBusProperties(redemption, storeName);
        redemptionServiceBusProperties.type(type.name());
        redemptionServiceBusProperties.setOriginalStoreCode(originalStoreCode);
        String jsonString = JSON.toJSONString(redemptionServiceBusProperties);
        JSONObject jsonObject = JSON.parseObject(jsonString);
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.SEND_MESSAGE_FOR_TRANSFERSTORE, loyaltyMessage);
    }


    /**
     * 修改发货渠道
     *
     * @param loyaltyId
     * @param activityId
     * @param storeCode
     * @param logisticsId
     * @param deliveryNumber
     * @param receiver
     * @param phone
     * @param address
     * @param province
     * @param city
     * @param district
     * @param deliveryChannel
     * @param ignoreGiftIdList
     */
    public void updateDeliveryChannel(String loyaltyId, String activityId, String storeCode, String logisticsId,
                                      String deliveryNumber, String receiver, String phone, String address,
                                      String province, String city, String district,
                                      DeliveryChannel deliveryChannel, List<String> ignoreGiftIdList) {
        Activity activity = cacheService.findActivityById(activityId);
        if (activity == null || TransactionType.REDEMPTION != activity.getTransactionType()) {
            throw new SystemException("Activity not found.", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndTransactionTypeAndRedemptionStatusAndLoyaltyIdAndActivityId(
                partitionKey, TransactionType.REDEMPTION, RedemptionStatus.CREATED, loyaltyId, activityId);
        for (Redemption redemption : redemptionList) {
            if (!CollectionUtils.isEmpty(ignoreGiftIdList)) {
                Optional<GiftItem> giftItem = redemption.getGiftItemList()
                        .stream().filter(item -> ignoreGiftIdList.contains(item.getGiftId())).findFirst();
                if (giftItem.isPresent()) {
                    continue; //豁免转柜
                }
            }
            String originalStoreCode = redemption.storeCode();
            redemption.updateDeliveryChannel(storeCode, logisticsId, deliveryNumber,
                    receiver, phone, address, province, city, district, deliveryChannel);
            redemptionRepository.save(redemption);
            sendTransferStoreMessageToMq(originalStoreCode, redemption, Redemption.MlOlayCounterTransferType.HOT_LINE);
        }
    }


    public void updateRedemptionLogisticsById(String memberId, LoyaltyStructure structure, String transactionId, LogisticsVO logisticsVO) {
        Account account = accountService.fetchAccountByMemberId(structure, memberId);
        if (account == null) {
            throw new SystemException(" found", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        String pk = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        Optional<Redemption> redemptionOptional = redemptionRepository
                .findByPartitionKeyAndId(pk, transactionId).stream().findFirst();
        if (!redemptionOptional.isPresent()) {
            throw new SystemException("Redemption not exist", ResultCodeMapper.PARAM_ERROR);
        }
        Redemption redemption = redemptionOptional.get();
        if (!StringUtils.equals(account.loyaltyId(), redemption.getLoyaltyId())) {
            throw new SystemException("Redemption not belong to the member", ResultCodeMapper.PARAM_ERROR);
        }
        if (!redemption.redemptionStatusIsCreated()) {
            log.info("transaction {} redemptionStatus :{},因为redemptionStatus 不是created，所以不予修改和发货", transactionId, redemption.getRedemptionStatus());
            throw new SystemException("redemptionStatus error,redemptionStatus is " + redemption.getRedemptionStatus(), ResultCodeMapper.UPDATE_REDEMPTION_ERROR);
        }
        Activity activity = cacheService.findActivityById(redemption.activityId());
        if (activity == null) {
            log.info("Activity is not found, system error，this activityId is {}", redemption.activityId());
            throw new SystemException("Activity is not found, system error，this activityId is " + redemption.activityId(), ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        if (!redemptionProperties.indirectDelivered() || !redemption.deliverChannelIsLogistics()) {
            log.info("transaction {} activityId {},DeliveryChannel: {},因为DeliveryChannel 不是LOGISTICS，所以不予修改和发货",
                    transactionId, redemption.activityId(), redemptionProperties.getDeliveryChannel());
            throw new SystemException("DeliveryChannel error", ResultCodeMapper.UPDATE_REDEMPTION_ERROR);
        }
        redemption.updateLogistics(logisticsVO);
        deliversGoodsToLogistics(redemption, activity, memberId, logisticsVO.getAddressCode());
    }

    /**
     * 根据领取柜台查询redemption
     *
     * @param activityId
     * @param startTime
     * @param endTime
     * @param redemptionStatus
     * @param perPage
     * @param page
     * @param storeCode
     * @return
     */
    public PageableResult<Redemption> getRedemptionByStoreCode(String activityId, LocalDateTime startTime, LocalDateTime endTime, String redemptionStatus, Integer perPage, Integer page, String storeCode) {
        List<Redemption> redemptionList = null;
        if (redemptionStatus != null) {
            redemptionList = redemptionRepository.findByActivityIdAndCreatedTimeBetweenAndRedemptionStatusAndStoreCodeAndTransactionType(
                    activityId, LoyaltyDateTimeUtils.localDateTimeToString(startTime), LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    redemptionStatus, storeCode, TransactionType.REDEMPTION);
        } else {
            redemptionList = redemptionRepository.findByActivityIdAndCreatedTimeBetweenAndStoreCodeAndTransactionType(
                    activityId, LoyaltyDateTimeUtils.localDateTimeToString(startTime), LoyaltyDateTimeUtils.localDateTimeToString(endTime),
                    storeCode, TransactionType.REDEMPTION);
        }
        redemptionList = filterTransactionStatus(redemptionList);
        return cacheService.generatePage(page, perPage, redemptionList, Redemption.comparatorByRedemptionCreatedTimeDesc());
    }

    /**
     * c2定制接口服务，查询兑换列表。并将列表拆分成transaction和gift一对一关系的列表。
     */
    public PageableResult<Redemption> getRedemptionByStoreCodeWithoutActivityId(LocalDateTime startTime,
                                                                                LocalDateTime endTime, String redemptionStatusStr,
                                                                                Integer perPage, Integer page, String storeCode) {
        RedemptionStatus redemptionStatus = StringUtils.isEmpty(redemptionStatusStr) ? null : RedemptionStatus.valueOf(redemptionStatusStr);
        String startTimeStampStr = String.valueOf(startTime.toEpochSecond(ZoneOffset.MAX));
        String endTimeStampStr = String.valueOf(endTime.toEpochSecond(ZoneOffset.MAX));
        String key;
        if (redemptionStatus == null) {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, storeCode, startTimeStampStr, endTimeStampStr);
        } else {
            key = cacheService.getKey(CacheService.KeyEnum.REDEMPTION, storeCode, redemptionStatus.name(), startTimeStampStr, endTimeStampStr);
        }
        // 从redis中查询。获取总数，根据page和perPage获取score范围内得值。
        Long totalSize = stringRedisTemplate.boundZSetOps(key).size();
        if (totalSize != null && totalSize != 0) {
            double start = (double) perPage * (page - 1);
            double end = (double) (page * perPage) - 1;
            List<Redemption> redemptionList = new ArrayList<>();
            if (start < totalSize) {
                end = end > totalSize ? (totalSize - 1) : end;
                Set<String> values = stringRedisTemplate.boundZSetOps(key).rangeByScore(start, end);
                if (values != null && !values.isEmpty()) {
                    for (String s : new ArrayList<>(values)) {
                        Redemption redemption = JSON.parseObject(s, Redemption.class);
                        redemptionList.add(redemption);
                    }
                }
            }
            return new PageableResult<>(totalSize.intValue(), redemptionList);
        }
        // redis查找不到则从数据库中查询
        List<Redemption> allRedemptionList;
        String startTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endTimeStr = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        if (redemptionStatusStr == null) {
            allRedemptionList = redemptionRepository.findByCreatedTimeBetweenAndStoreCodeAndTransactionType(
                    startTimeStr, endTimeStr, storeCode, TransactionType.REDEMPTION);
        } else {
            allRedemptionList = redemptionRepository.findByCreatedTimeBetweenAndRedemptionStatusAndStoreCodeAndTransactionType(
                    startTimeStr, endTimeStr, redemptionStatus, storeCode, TransactionType.REDEMPTION);
        }
        allRedemptionList = filterTransactionStatus(allRedemptionList);
        // 根据创建时间倒序排序
        Comparator<Redemption> comparator = Comparator.comparing(Redemption::getCreatedTime).reversed();
        allRedemptionList.sort(comparator);
        // 保存至redis,设置score，从0开始
        Set<ZSetOperations.TypedTuple<String>> tuples = new HashSet<>();
        double score = 0;
        List<Redemption> finalList = new ArrayList<>();
        for (Redemption redemption : allRedemptionList) {
            List<GiftItem> giftItemList = redemption.getGiftItemList();
            for (GiftItem giftItem : giftItemList) {
                // 拆分pointItem
                Redemption oneGiftRedemption = new Redemption();
                BeanUtils.copyProperties(redemption, oneGiftRedemption);
                List<GiftItem> oneGiftList = new ArrayList<>();
                oneGiftList.add(giftItem);
                oneGiftRedemption.setGiftItemList(oneGiftList);
                ZSetOperations.TypedTuple<String> objectTypedTuple = new DefaultTypedTuple<>(JSON.toJSONString(oneGiftRedemption), score);
                tuples.add(objectTypedTuple);
                finalList.add(oneGiftRedemption);
                score++;
            }
        }
        if (!tuples.isEmpty()) {
            stringRedisTemplate.boundZSetOps(key).add(tuples);
            stringRedisTemplate.expire(key, 15, TimeUnit.MINUTES);
        }
        return cacheService.generatePage(page, perPage, finalList, comparator);
    }

    /**
     * 获取redemptionlist中所有礼品是否可取消兑换的状态
     * 由于不同的兑换订单，可能包括相同的礼品，所以key是redemptionId-giftId
     *
     * @param redemptionList
     * @return
     */
    public Map<String, Boolean> fetchRedemptionCancelableStatus(List<Redemption> redemptionList) {
        Map<String, Boolean> cancelableList = new HashMap<>(redemptionList.size() * 2);
        redemptionList.forEach(redemption -> {
            Activity activity = cacheService.findActivityById(redemption.activityId());
            if (activity == null) {
                cancelableList.put(redemption.getId(), false);
                return;
            }
            redemption.getGiftItemList().forEach(giftItem -> {
                StringBuilder key = new StringBuilder(redemption.getId());
                key.append("-").append(giftItem.getGiftId());
                boolean cancelable = true;
                //如果是C2，活动期结束，不能取消兑换
                if (redemption.getDeliveryChannel() == DeliveryChannel.C2 && !activity.available()) {
                    cancelable = false;
                }
                //判断gift 时间范围
                if (!activity.giftAvailable(giftItem.getGiftId())) {
                    cancelable = false;
                }
                //兑换订单只有在created才能取消了
                if (!redemption.giftCancelable()) {
                    cancelable = false;
                }
                if (!((RedemptionProperties) activity.ruleProperties()).isAllowCancel()) {
                    cancelable = false;
                }
                //单个礼品是否可以取消判断
                if (!giftItem.cancelable()) {
                    cancelable = false;
                }
                cancelableList.put(key.toString(), cancelable);
            });
        });
        return cancelableList;
    }

    /**
     * 批量修改redemption状态（到柜）
     *
     * @param activityId
     * @param storeCode
     * @param ignoreGiftIdList
     */
    public void updateRedemptionStatusToDeliveredByStoreCode(String activityId, String storeCode,
                                                             LocalDateTime start, LocalDateTime end,
                                                             List<String> ignoreGiftIdList) {
        if (cacheService.getStoreByStoreCode(storeCode) == null) {
            throw new SystemException("Store is not found. ", ResultCodeMapper.PARAM_ERROR);
        }
        Activity activity = cacheService.findActivityById(activityId);
        if (activity == null || TransactionType.REDEMPTION != activity.getTransactionType()) {
            throw new SystemException("Activity not found", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        if (null == start) {
            start = activity.getStartAt();
        }
        if (null == end) {
            end = activity.getEndAt();
        }
        if (start.isAfter(end)) {
            throw new SystemException("Start time can not after end time", ResultCodeMapper.PARAM_ERROR);
        }
        //按时间来deliver查询出兑换记录
        List<Redemption> redemptionList = redemptionRepository.findByActivityIdAndStoreCodeAndCreatedTimeBetweenAndRedemptionStatusAndTransactionType(
                activityId, storeCode, LoyaltyDateTimeUtils.localDateTimeToString(start),
                LoyaltyDateTimeUtils.localDateTimeToString(end),
                RedemptionStatus.CREATED, TransactionType.REDEMPTION);
        for (Redemption redemption : redemptionList) {
            if (!CollectionUtils.isEmpty(ignoreGiftIdList)) {
                Optional<GiftItem> giftItem = redemption.getGiftItemList()
                        .stream().filter(item -> ignoreGiftIdList.contains(item.getGiftId())).findFirst();
                if (giftItem.isPresent()) {
                    continue; //豁免转柜
                }
            }
            redemption.updateStatusToDelivered();
            redemptionRepository.save(redemption);
            sendTransferStoreMessageToMq(redemption.storeCode(), redemption, Redemption.MlOlayCounterTransferType.NORMAL);
        }
    }

    /**
     * 取消兑换，返还库存，返还积分通过增加互动记录。
     */
    @MutexLock(lockKeys = {"#brand", "#memberId"})
    public void cancelRedemption(String region, String brand, String memberId, String transactionId, List<String> gifts) {
        String cancelReason = "cancel redemption";
        validateAndTerminationRedemption(region, brand, memberId, transactionId,
                gifts, GiftItem.GiftStatus.CANCELED, RedemptionStatus.CANCELED, cancelReason);
    }

    /**
     * 由于系统和内部原因，导致无法给消费者正常发送兑换礼品，拒绝兑换
     */
    @MutexLock(lockKeys = {"#brand", "#memberId"})
    public void rejectRedemption(String region, String brand, String memberId,
                                 String transactionId, List<String> gifts, String rejectReason) {
        validateAndTerminationRedemption(region, brand, memberId, transactionId,
                gifts, GiftItem.GiftStatus.REJECTED, RedemptionStatus.REJECTED, rejectReason);
    }

    /**
     * 过期兑换
     */
    @MutexLock(lockKeys = {"#brand", "#memberId"})
    public void expiredRedemption(String region, String brand, String memberId,
                                  String transactionId, List<String> gifts, String expiredReason) {
        validateAndTerminationRedemption(region, brand, memberId, transactionId,
                gifts, GiftItem.GiftStatus.EXPIRED, RedemptionStatus.EXPIRED, expiredReason);
    }

    /**
     * 校验请求，终止兑换，返还库存，返还积分通过增加互动记录。
     */
    private void validateAndTerminationRedemption(String region, String brand, String memberId, String transactionId,
                                                  List<String> gifts, GiftItem.GiftStatus giftStatus,
                                                  RedemptionStatus redemptionStatus, String refundReason) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberId(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException("Account not found", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(
                PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), transactionId);
        if (CollectionUtils.isEmpty(redemptionList)) {
            throw new SystemException("Redemption not found", ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }

        Redemption redemption = redemptionList.get(0);
        Activity activity = cacheService.findActivityById(redemption.getActivityId());
        if (activity == null) {
            throw new SystemException("Activity of the redemption not found", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }

        //校验本次兑换是否允许做：拒绝、取消、过期操作
        redemption.validateAllowChangeTo(redemptionStatus, activity);

        List<PointType> pointTypeList = pointTypeRepository.findByPointTypeAndLoyaltyStructure(
                Transaction.PointTypeEnum.REDEMPTION_CANCEL.name(), loyaltyStructure.name());
        if (CollectionUtils.isEmpty(pointTypeList)) {
            throw new SystemException("PointType REDEMPTION_CANCEL not found", ResultCodeMapper.POINT_TYPE_NOT_FOUND);
        }
        PointType pointType = pointTypeList.get(0);
        redemption.setReason(refundReason);
        terminationRedemption(gifts, pointType, account, redemption, activity, giftStatus, true);
    }

    /**
     * 根据redemptionCode取消过期兑换
     */
    @MutexLock(lockKeys = {"#brand", "#memberId"})
    public void cancelRedemptionByRedeemCode(String region, String brand, String memberId,
                                             String redeemCode, GiftItem.GiftStatus giftStatus,
                                             RedemptionStatus redemptionStatus) {
        cancelRedemptionByRedeemCodeValidateAndTerminationRedemption(region, brand, memberId, redeemCode, giftStatus, redemptionStatus);
    }

    /**
     * 根据redemptionCode取消过期兑换
     * 校验请求，终止兑换，返还库存，返还积分通过增加互动记录。
     */
    private void cancelRedemptionByRedeemCodeValidateAndTerminationRedemption(String region, String brand, String memberId, String redeemCode,
                                                                              GiftItem.GiftStatus giftStatus,
                                                                              RedemptionStatus redemptionStatus) {

        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        Account account = accountService.fetchAccountByMemberId(loyaltyStructure, memberId);
        if (account == null) {
            throw new SystemException("Account not found", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndMemberIdAndTransactionTypeAndRedeemCode(
                PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId()), memberId, TransactionType.REDEMPTION, redeemCode);
        if (CollectionUtils.isEmpty(redemptionList)) {
            throw new SystemException("Redemption not found", ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }

        Redemption redemption = redemptionList.get(0);
        Activity activity = cacheService.findActivityById(redemption.getActivityId());
        if (activity == null) {
            throw new SystemException("Activity of the redemption not found", ResultCodeMapper.ACTIVITY_NOT_FOUND);
        }
        //校验兑换订单是否已经过期
        if (redemption.redemptionStatusIsExpired() && redemptionStatus.equals(RedemptionStatus.EXPIRED)) {
            return;
        }
        //校验本次兑换是否允许做：拒绝、取消、过期操作
        redemption.validateAllowChangeTo(redemptionStatus, activity);

        List<PointType> pointTypeList = pointTypeRepository.findByPointTypeAndLoyaltyStructure(
                Transaction.PointTypeEnum.REDEMPTION_CANCEL.name(), loyaltyStructure.name());
        if (CollectionUtils.isEmpty(pointTypeList)) {
            throw new SystemException("PointType REDEMPTION_CANCEL not found", ResultCodeMapper.POINT_TYPE_NOT_FOUND);
        }
        PointType pointType = pointTypeList.get(0);
        List<GiftItem> giftItemList = redemption.getGiftItemList();

        List<String> gifts = giftItemList.stream().map(GiftItem::getGiftId).collect(Collectors.toList());

        terminationRedemption(gifts, pointType, account, redemption, activity, giftStatus, false);
    }


    /**
     * 终止兑换
     */
    private void terminationRedemption(List<String> gifts, PointType pointType, Account account,
                                       Redemption redemption, Activity activity, GiftItem.GiftStatus giftStatus, boolean normalCancel) {
        Map<String, Integer> refundGiftMap = redemption.refundGiftsMap(gifts, giftStatus);
        Integer refundPoint = redemption.terminationRedemption(gifts, giftStatus, normalCancel);
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(account.region(), redemption.brand());
        String brand = loyaltyStructure.brands().iterator().next();
        Interaction interaction = new Interaction(account.loyaltyId(), brand,
                ChannelV2.INTERNAL, loyaltyStructure, account.getMemberId());
        interaction.updateValueType(loyaltyStructure, redemption.valueType(loyaltyStructure));
        interaction.addPointForRedemptionCancel(redemption.activityId(), refundPoint, pointType);
        // 返还积分
        if (refundPoint > 0) {
            account.cancelRedemption(interaction, loyaltyStructure);
            accountRepositoryV2.saveRetrievable(account);
            transactionRepositoryV2.saveRetrievable(interaction);
            messageService.sendMessage4PointPool(new PoolMessage(loyaltyStructure, interaction, account));
            syncRedemptionPointForActivity(loyaltyStructure, redemption.activityId(), -refundPoint);
        }
        transactionRepositoryV2.saveRetrievable(redemption);
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        if (redemptionProperties.isBindCoupon() && normalCancel) {
            couponGateway.cancelCoupon(account.memberId(), redemption.brand(), redemption.getRedeemCode());
        }
        boolean reductionInventory = redemptionProperties.isReductionInventory();
        boolean expiredCoupon = giftCouponService.expiredCoupon(account, redemption);
        //coupon不返还库存
        if (expiredCoupon) {
            return;
        }
        //返还兑换issuedNum库存
        Map<String, Long> giftStockMap = refundGiftIssuedNum(activity, reductionInventory, refundGiftMap);
        // 调整兑换数量到db
        if (reductionInventory && giftStockMap.size() > 0) {
            synchronizeRedisInventoryToDatabaseByMq(redemption.getId(), activity.activityId(), true, giftStockMap);
        }
    }


    private void deliversGoodsToLogistics(Redemption redemption, Activity activity, String memberId, String addressCode) {
        LogisticsAgentClient.Response response = logisticsAgentClient.createOrder(redemption, activity, memberId, addressCode);
        if (!SUCCESS_0.equals(response.getResultCode())) {
            log.info("Failed to request logistics micro service，this error is {},this transactionId is {},this person is {}", response.getErrorMsg(), redemption.getId(), redemption.getReceiver());
            throw new SystemException(response.getErrorMsg(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
        //保存redemption发送物流微服务的状态
        redemption.updateLogisticsId(response.getObject().getDeliveryId(), "LogisticsSystem", true);
        redemptionRepository.save(redemption);
    }

    /**
     * 修改兑换订单状态，修改传入礼品的领取状态, 只有双月兑换会使用。需要使用兑换码兑换
     *
     * @param transactionId
     * @param loyaltyId
     * @param redeemCode
     * @param giftIdList
     */
    public void updateRedemptionGiftStatus2Pickup(String transactionId, String loyaltyId, String redeemCode, List<String> giftIdList) {
        if (giftIdList.isEmpty()) {
            log.info("Gift Id list is empty");
            throw new SystemException("Gifts is null", ResultCodeMapper.PARAM_ERROR);
        }
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        if (redemptionList.isEmpty()) {
            throw new SystemException("No redemption is found".concat(transactionId), ResultCodeMapper.REDEMPTION_NOT_FOUND);
        }
        Redemption redemption = redemptionList.get(0);
        if (redemption.finished()) {
            throw new SystemException("The redemption has been canceled or accomplished, can not modify", ResultCodeMapper.REQUEST_REPEAT_BUSINESS_COMPLETED);
        }
        if (!redemption.getRedeemCode().equals(redeemCode)) {
            throw new SystemException("The redeem code is not correct", ResultCodeMapper.PARAM_ERROR);
        }
        //根据活动配置 核销礼品前检查是否加入BC企业微信
        checkJoinEnterpriseWechatStatusService.checkJoinEnterpriseWechatForBC(redemption, giftIdList);
        redemption.changeGiftsStatus2Received(giftIdList);
        accomplishCoupon(redemption);
        transactionRepositoryV2.saveRetrievable(redemption);
    }

    /**
     * C2领取礼品
     *
     * @param transactionId
     * @param giftId
     * @param loyaltyId
     * @param redeemCode
     */
    public void modifyRedemptionSingleGiftStatus(String transactionId, String giftId, String loyaltyId, String redeemCode, String storeCode) {
        final String CRM = "CRM";
        List<Redemption> redemptionList;
        //如果loyaltyId为CRM，则只通过transactionID查询
        if (CRM.equals(loyaltyId)) {
            redemptionList = redemptionRepository.findRedemptionById(transactionId);
        } else {
            redemptionList = redemptionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(loyaltyId), transactionId);
        }
        if (redemptionList.isEmpty()) {
            throw new SystemException("Can't find conversion order because of the error of parameter, this redemption id is: ".concat(transactionId), ResultCodeMapper.PARAM_ERROR);
        }
        Redemption redemption = redemptionList.get(0);
        if (!redemption.pickupable()) {
            throw new SystemException("The redemption has been cancelled or finished", ResultCodeMapper.PARAM_ERROR);
        }
        if (!redemption.getRedeemCode().equals(redeemCode)) {
            throw new SystemException("The exchange code you want is not found. The exchange code is wrong", ResultCodeMapper.PARAM_ERROR);
        }
        //根据活动配置 核销礼品前检查是否加入BC企业微信
        List<String> giftIdList = new ArrayList<>(Collections.singletonList(giftId));
        checkJoinEnterpriseWechatStatusService.checkJoinEnterpriseWechatForBC(redemption, giftIdList);
        redemption.changeGiftReceivedStatus(giftId);
        redemption.setStoreCode(storeCode);
        accomplishCoupon(redemption);
        redemptionRepository.save(redemption);
    }

    private void accomplishCoupon(Redemption redemption) {
        if (redemption.pickupable()) {
            return;
        }
        Activity activity = cacheService.findActivityById(redemption.activityId());
        if (activity == null) {
            throw new SystemException("The redemption activity not exist", ResultCodeMapper.PARAM_ERROR);
        }
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        if (redemptionProperties.isBindCoupon()) {
            couponGateway.redemptionCoupon(redemption.getMemberId(), redemption.brand(), redemption.getRedeemCode());
        }
    }

    public List<Order> findByLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(String loyaltyId, String brand,
                                                                                        TransactionType transactionType, LocalDateTime startTime, LocalDateTime endTime) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);

        return orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(
                partitionKey, loyaltyId, brand, transactionType, startAt, endAt);
    }

    public void findNameAndMobileFromAm(String redemptionId, String memberId, String partitionKey, String loyaltyStructure) {
        LoyaltyStructure loyaltyStructure1 = cacheService.findLoyaltyStructureById(loyaltyStructure);
        List<Redemption> redemptions = redemptionRepository.findByPartitionKeyAndId(partitionKey, redemptionId);
        AmClient.OptimizedProfileDTO profileDTO = amClientSupport.queryProfile(memberId, loyaltyStructure1.getAmTenantId());
        Redemption redemption = redemptions.get(0);
        redemption.updateReceiverAndMobile(profileDTO.getFullName(), profileDTO.getCellphone());
        redemptionRepository.save(redemption);
    }

    public void redemptionPayedStatus(String brand, String memberId, String transactionId) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure("ML", brand);
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(partitionKey, transactionId);
        if (redemptionList.isEmpty()) {
            log.error("获取不到兑换订单：{}", transactionId);
            throw new SystemException("获取不到兑换订单", ResultCodeMapper.PARAM_ERROR);
        }
        Redemption redemption = redemptionList.get(0);
        redemption.updatePayedStatus(RedemptionStatus.PAYED);
        redemptionRepository.save(redemption);
    }

    /**
     * 检查订单是否重复
     *
     * @param account
     * @param order
     * @return
     */
    public boolean checkIsAddOrderRepeat(Account account, Order order) {
        //去重
        String orderKey = cacheService.getKey(CacheService.KeyEnum.COMMON_ORDER_POINT, order.brand(), account.getMemberId(), order.getOrderId());
        Boolean isStore = stringRedisTemplate.opsForValue().setIfAbsent(orderKey, order.getOrderId(), 1L, TimeUnit.DAYS);
        if (Boolean.FALSE.equals(isStore)) {
            log.warn("MemberId:{},订单:{}订单重复加积分", account.getMemberId(), order.getOrderId());
            return true;
        }
        String transactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        List<Order> existOrders = orderRepository.findByPartitionKeyAndLoyaltyIdAndBrandAndOrderIdAndChannel(transactionPartitionKey, account.loyaltyId(), order.brand(), order.getOrderId(), order.getChannel());
        if (!CollectionUtils.isEmpty(existOrders)) {
            //如果存在订单，说明就已经加过积分了，则继续下一个order执行
            log.warn("MemberId:{},OrderId:{}订单已经加过积分", account.memberId(), order.getOrderId());
            return true;
        }
        return false;
    }

    public int syncRedemptionPointForActivity(LoyaltyStructure loyaltyStructure, String activityId, int point) {
        String key = cacheService.getKey(CacheService.KeyEnum.PERSISTENT_AGGREGATION_REDEMPTION, loyaltyStructure.name());
        return stringRedisTemplate.opsForHash().increment(key, activityId, point).intValue();
    }

    public Map<String, Integer> getRedemptionPointAggregation(List<Activity> activities) {
        Map<String, Integer> activityPointMap = new HashMap<>();
        List<Object> ids = activities.parallelStream().filter(activity -> activity.getTransactionType() == TransactionType.REDEMPTION)
                .map(Activity::activityId).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(ids)) {
            return activityPointMap;
        }
        String structureName = activities.get(0).getLoyaltyStructure();
        String key = cacheService.getKey(CacheService.KeyEnum.PERSISTENT_AGGREGATION_REDEMPTION, structureName);
        List<Object> pointList = stringRedisTemplate.opsForHash().multiGet(key, ids);
        Stream.iterate(0, i -> i + 1).limit(ids.size()).forEach(index -> {
            Object pointStr = Optional.ofNullable(pointList.get(index)).orElse("0");
            int point = Integer.parseInt(String.valueOf(pointStr));
            activityPointMap.put((String) ids.get(index), point);
        });
        return activityPointMap;
    }


    /**
     * 因为OLAY的memberId不能直接计算，所以需要先查询账号并校验
     */
    public void updateRedemptionGiftStatusToReceivedById(String transactionId, String memberId,
                                                         LoyaltyStructure loyaltyStructure, String redeemCode,
                                                         List<String> giftIds) {
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        updateRedemptionGiftStatus2Pickup(transactionId, account.loyaltyId(), redeemCode, giftIds);
    }

    public void batchAddInteractionPoint(String region, String brand, String channel, String pointType,
                                         Integer point, List<String> memberIds, String adjustReason) {
        messageService.sendMessageForBatchAddInteractionPoint(region, brand,
                channel, pointType, point, memberIds, adjustReason);
    }

    @IdempotentLock(lockKeys = {"'interaction'", "#body.brand", "#body.memberId", "#body.uuid"},
            unlessWithEmpty = "#uuid")
    public void addInteractionPoint(InteractionMessage body) {
        ParamValidator.stringParam(POINT_TYPE, body.getPointType());
        ParamValidator.stringParam(MEMBER_ID, body.getMemberId());

        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(body.getRegion(), body.getBrand());
        Account account = accountService.fetchAndInitialInExistSubAccount(body.getMemberId(), loyaltyStructure, body.getBrand(), body.getChannel());
        account.checkAccountAvailable(loyaltyStructure);

        Interaction interaction = new Interaction(account.loyaltyId(), body.getBrand(), body.getChannel(), loyaltyStructure,
                body.getMemberId(), Transaction.TransactionStatus.ACTIVATE);
        interaction.addPoint(body.getPoint(), body.getAdjustReason(), body.getPointType(), body.getActivityId());
        interaction.setValueType(body.getValueType());
        //计算等级
        tierRulesCalculateEngine.calculateTiersRule(new TierChangeScene(loyaltyStructure, account, interaction));
        tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(loyaltyStructure, account, false));

        account.calculatePoint(interaction, loyaltyStructure);
        transactionRepository.save(interaction);
        log.info("add tier award point and save interaction successfully, the memberId is :{}", account.memberId());
        accountRepositoryV2.saveRetrievable(account);
        log.info("add tier award point and save account successfully, the memberId is :{}", account.memberId());
        messageService.sendMessage4PointPool(new PoolMessage(loyaltyStructure, interaction, account));
        log.info("add tier award point and send point pool successfully, the memberId is :{}", account.memberId());
    }

    @IdempotentLock(lockKeys = {"'interaction'", "#message.region", "#message.brand", "#message.memberId", "#message.uuid"},
            unlessWithEmpty = "#uuid")
    public void refundOrderCauseTierDownReturnTierAwarePoint(InteractionMessage message) {
        ParamValidator.stringParam(POINT_TYPE, message.getPointType());
        ParamValidator.stringParam(MEMBER_ID, message.getMemberId());

        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(message.getRegion(), message.getBrand());
        Account account = accountService.fetchAndInitialInExistSubAccount(message.getMemberId(), loyaltyStructure,
                message.getBrand(), message.getChannel());
        account.checkAccountAvailable(loyaltyStructure);
        List<Interaction> rewardTransactions = interactionRepositoryV2.fetchByPointTypes(account.loyaltyId(),
                PointTypeEnum.TIER_REWARD.name(), PointTypeEnum.TIER_REWARD_REFUND.name());
        int awardPoint = rewardTransactions.stream().mapToInt(Transaction::point).sum();
        if (awardPoint <= 0) {
            return;
        }
        int returnPoint = Math.min(awardPoint, Math.abs(message.getPoint()));
        Interaction interaction = new Interaction(account.loyaltyId(), message.getBrand(), message.getChannel(), loyaltyStructure,
                message.getMemberId(), Transaction.TransactionStatus.ACTIVATE);
        interaction.addPoint(-returnPoint, message.getAdjustReason(), message.getPointType(), message.getActivityId());

        account.calculatePoint(interaction, loyaltyStructure);
        transactionRepository.save(interaction);
        log.info("return tier award point and save interaction successfully, the memberId is :{}", account.memberId());
        accountRepositoryV2.saveRetrievable(account);
        log.info("return tier award point and save account successfully, the memberId is :{}", account.memberId());
        interaction.setPoint(message.getPoint());
        messageService.sendMessage4PointPool(new PoolMessage(loyaltyStructure, interaction, account, false));
        log.info("return tier award point and send point pool successfully, the memberId is :{}", account.memberId());
    }

    public Integer calculatePointAboutExpireInFuture3MonthsForSKII(Account account, String brand, LoyaltyStructure structure) {
        LocalDate pointAboutExpiredDate = account.pointAboutExpiredDate(brand, structure);
        int availablePoint = account.availablePoint(structure.accountTypeOfDefault());

        if (!BrandV2.SKII.equals(brand) || Objects.isNull(pointAboutExpiredDate) || pointAboutExpiredDate.isAfter(LocalDate.now().plusMonths(3))) {
            return 0;
        }
        //计算积分有效期大于当前时间+3个月的所有积分
        List<Transaction> transactionList = transactionRepositoryV2.fetchPositivePointTransactionByLoyaltyIdAndExpiredTimeGreaterThan(
                account.loyaltyId(), LoyaltyDateTimeUtils.getEndTimeOfDay(LocalDateTime.now().plusMonths(3)));
        int sumPoint = transactionList.stream().mapToInt(Transaction::point).sum();
        if (availablePoint < sumPoint) {
            return 0;
        }
        return availablePoint - sumPoint;
    }

    public Map<String, Object> calculatePointAboutExpireAndTheLastExpiredDateInFuture3MonthsForSKII(Account account, String brand, LoyaltyStructure structure) {
        String pointAboutExpireInFuture3Months = "pointAboutExpireInFuture3Months";
        String theLastPointAboutExpireDateInFuture3Months = "theLastPointAboutExpireDateInFuture3Months";
        Map<String, Object> pointAboutExpireMap = new HashMap<>();
        LocalDate pointAboutExpiredDate = account.pointAboutExpiredDate(brand, structure);
        int availablePoint = account.availablePoint(structure.accountTypeOfDefault());

        if (!BrandV2.SKII.equals(brand) || availablePoint <= 0 || Objects.isNull(pointAboutExpiredDate) || pointAboutExpiredDate.isAfter(LocalDate.now().plusMonths(3))) {
            pointAboutExpireMap.put(pointAboutExpireInFuture3Months, 0);
            pointAboutExpireMap.put(theLastPointAboutExpireDateInFuture3Months, "");
            return pointAboutExpireMap;
        }
        if (pointAboutExpiredDate.isEqual(LocalDate.now().plusMonths(3))) {
            pointAboutExpireMap.put(pointAboutExpireInFuture3Months, availablePoint);
            pointAboutExpireMap.put(theLastPointAboutExpireDateInFuture3Months, pointAboutExpiredDate.toString());
            return pointAboutExpireMap;
        }
        //计算积分有效期大于当前时间的记录
        List<Transaction> transactionList = transactionRepositoryV2.fetchPositivePointTransactionByLoyaltyIdAndExpiredTimeGreaterThan(
                account.loyaltyId(), LoyaltyDateTimeUtils.getBeginTimeOfDate(LocalDateTime.now()));
        //计算积分有效期大于等于当前时间+3个月的所有积分
        int sumPoint = transactionList.stream()
                .filter(transaction -> !transaction.getExpiredTime().isBefore(LoyaltyDateTimeUtils.getBeginTimeOfDate(LocalDateTime.now()).plusMonths(3)))
                .mapToInt(Transaction::point).sum();

        if (availablePoint <= sumPoint) {
            pointAboutExpireMap.put(pointAboutExpireInFuture3Months, 0);
            pointAboutExpireMap.put(theLastPointAboutExpireDateInFuture3Months, "");
            return pointAboutExpireMap;
        }

        //三个月内最大的即将过期日期
        Optional<LocalDateTime> localDateTime = transactionList.stream().filter(transaction -> transaction.getExpiredTime().isBefore(LoyaltyDateTimeUtils.getBeginTimeOfDate(LocalDateTime.now()).plusMonths(3)))
                .max(Comparator.comparing(Transaction::getExpiredTime)).map(Transaction::getExpiredTime);

        pointAboutExpireMap.put(theLastPointAboutExpireDateInFuture3Months, "");
        localDateTime.ifPresent(dateTime -> pointAboutExpireMap.put(theLastPointAboutExpireDateInFuture3Months, dateTime.toLocalDate().toString()));
        pointAboutExpireMap.put(pointAboutExpireInFuture3Months, availablePoint - sumPoint);

        return pointAboutExpireMap;
    }

}
