package cn.com.pg.loyalty.infrastructure.lock;

import java.util.concurrent.TimeUnit;

/**
 * @Author: Hayden
 * @CreateDate: 2021/5/28 14:59
 * @UpdateUser: Hayden
 * @UpdateDate: 2021/5/28 14:59
 * @Version: 1.0
 * @Description:
 */
public interface Lock {

    boolean tryLock(String key, long expireTime, TimeUnit timeUnit);

    void deleteLock(String key);

    boolean hasKey(String key);

    void deleteLock(String key,long waitMills);

}
