package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2022/3/11
 */
@Getter
@Setter
@NoArgsConstructor
public class AddPointBeforeRegisterTimeProperties extends RuleProperties {
    private int daysLimit;
    private List<String> channels;
}
