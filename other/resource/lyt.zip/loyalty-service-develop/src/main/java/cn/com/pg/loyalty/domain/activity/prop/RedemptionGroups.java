package cn.com.pg.loyalty.domain.activity.prop;

import lombok.*;

import java.util.Set;
import java.util.TreeSet;

@Data
@NoArgsConstructor
public class RedemptionGroups {

    /**
     * 是否互斥：只能兑换其中一个分组礼品
     */
    private boolean mutex;

    private Set<GiftGroup> groups = new TreeSet<>();


    public void addGroup(GiftGroup group) {
        groups.add(group);
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GiftGroup implements Comparable<GiftGroup> {
        private String name;

        @Override
        public int compareTo(GiftGroup group) {
            return this.name.compareTo(group.name);
        }
    }
}
