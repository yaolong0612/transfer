package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.gift.CouponUrlItem;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftItem;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.interfaces.dto.*;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author: Ysnow
 * @Date: 2019/4/30 14:18
 * @Description:
 */
public class GiftAssembler {

    private GiftAssembler() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * 创建添加礼品的DTO
     *
     * @param gift
     * @return AddGiftDTO
     */
    public static AddGiftDTO toAddGiftDTO(Gift gift) {
        return new AddGiftDTO().giftId(gift.getId());
    }


    /**
     * 把dto转为entity
     *
     * @param productDTO
     * @return GiftItem
     */
    public static GiftItem productDTOTransformGiftItem(ProductDTO productDTO) {
        return new GiftItem(productDTO.getSku(), productDTO.getName(), productDTO.getQuantity());
    }

    public static CouponUrlItem urlDTOTransformCouponUrlItem(CouponUrlDto urlDto) {
        return new CouponUrlItem(urlDto.getSize(), urlDto.getUrl());
    }

    /**
     * 把dto转为entity
     *
     * @return GiftItem
     */
    public static List<GiftDisplayMsgDTO> giftDisplayMsgTransformDisplayDTO(List<Gift.GiftDisplayMsg> giftDisplayMsgList) {
        if (CollectionUtils.isEmpty(giftDisplayMsgList)) {
            return new ArrayList<>();
        }
        List<GiftDisplayMsgDTO> displayMsgs = new ArrayList<>();
        giftDisplayMsgList.stream().forEach(giftDisplayMsg -> {
            List<ProductDTO> items = new ArrayList<>();
            if (!CollectionUtils.isEmpty(giftDisplayMsg.getItems())) {
                //把ProductDTO列表转为entity列表
                items = giftDisplayMsg.getItems().stream().map(GiftAssembler::giftItemTransformProductDTO).collect(Collectors.toList());
            }
            GiftDisplayMsgDTO giftDisplayMsgDTO = new GiftDisplayMsgDTO();
            giftDisplayMsgDTO.setDescription(giftDisplayMsg.getDescription());
            giftDisplayMsgDTO.setProducts(items);
            giftDisplayMsgDTO.setLanguage(Language.valueOf(giftDisplayMsg.getLanguage().toUpperCase()));
            giftDisplayMsgDTO.setGiftName(giftDisplayMsg.getName());
            giftDisplayMsgDTO.setImageUri(giftDisplayMsg.getImageUri());
            displayMsgs.add(giftDisplayMsgDTO);
        });
        return displayMsgs;
    }

    /**
     * 把实体转为dto
     *
     * @param giftItem
     * @return ProductDTO
     */
    public static ProductDTO giftItemTransformProductDTO(GiftItem giftItem) {
        ProductDTO productDTO = new ProductDTO();
        productDTO.setSku(giftItem.getSku());
        productDTO.setQuantity(giftItem.getQuantity());
        productDTO.setName(giftItem.getName());
        return productDTO;
    }

    public static CouponUrlDto urlItemTransformCouponUrlDTO(CouponUrlItem urlItem) {
        CouponUrlDto couponUrlDto = new CouponUrlDto();
        couponUrlDto.setUrl(urlItem.getUrl());
        couponUrlDto.setSize(urlItem.getSize());
        return couponUrlDto;
    }

    /**
     * 封装成GiftListDTO函数
     *
     * @param pageableResult
     * @return
     */

    public static GiftListDTO toGiftListDTO(PageableResult<Gift> pageableResult) {
        GiftListDTO giftListDTO = new GiftListDTO();
        giftListDTO.setTotalSize(pageableResult.getTotalSize());
        if (CollectionUtils.isNotEmpty(pageableResult.getRecords())) {
            giftListDTO.setRecords(pageableResult.getRecords().stream().map(GiftAssembler::giftTransformGiftDto).collect(Collectors.toList()));
        }
        return giftListDTO;
    }

    /**
     * 把gift转为giftDto
     *
     * @param gift
     * @return GiftDTO
     */
    public static GiftDTO giftTransformGiftDto(Gift gift) {
        GiftDTO giftDTO = new GiftDTO();
        giftDTO.setGiftId(gift.getId());
        giftDTO.setGiftName(gift.getName());
        giftDTO.setImage(gift.getImageUri());
        giftDTO.setPoint(gift.getPoint());
        giftDTO.setTransitPoint(gift.getTransitPoint());
        giftDTO.setPrice(gift.getMarketPrice().doubleValue());
        if (gift.getItems() != null) {
            giftDTO.setProducts(gift.getItems().stream().map(GiftAssembler::giftItemTransformProductDTO).collect(Collectors.toList()));
        }
        giftDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(gift.getCreatedTime()));
        giftDTO.setCreator(gift.getCreatedBy());
        giftDTO.setDescription(gift.getDescription());
        giftDTO.setEfficacies(gift.getEfficacies());
        giftDTO.setRemark(gift.getRemark());
        giftDTO.setGiftType(GiftDTO.GiftTypeEnum.valueOf(gift.getType().name()));
        giftDTO.setBagSku(gift.getBagSku());
        giftDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(gift.getUpdatedTime()));
        giftDTO.setLoyaltyStructure(gift.getLoyaltyStructure());
        List<GiftDisplayMsgDTO> giftDisplayMsgDTOS = giftDisplayMsgTransformDisplayDTO(gift.getDisplayLanguages());
        giftDTO.setDisplayLanguages(giftDisplayMsgDTOS);
        if (CollectionUtils.isNotEmpty(gift.getCouponUrls())) {
            giftDTO.setUrls(gift.getCouponUrls().stream().map(GiftAssembler::urlItemTransformCouponUrlDTO).collect(Collectors.toList()));
        }
        return giftDTO;
    }

    public static List<ProductDTO> toProductDTOs(Gift gift) {
        if (!Optional.ofNullable(gift).isPresent()) {
            return new ArrayList<>();
        }
        List<ProductDTO> productDTOS = new ArrayList<>();
        gift.getItems().forEach(giftItem -> {
            ProductDTO productDTO = new ProductDTO();
            BeanUtils.copyProperties(giftItem, productDTO);
            productDTOS.add(productDTO);
        });
        return productDTOS;
    }

    public static GiftItemForC2DTO toGiftItemC2DTO(cn.com.pg.loyalty.domain.transaction.GiftItem giftItem, Map<String, Gift> metaGiftMap) {
        GiftItemForC2DTO giftItemForC2DTO = new GiftItemForC2DTO();
        giftItemForC2DTO.setGiftId(giftItem.getGiftId());
        giftItemForC2DTO.setGiftName(giftItem.getGiftName());
        giftItemForC2DTO.setPoint(giftItem.getPoint());
        giftItemForC2DTO.setQuantity(giftItem.getQuantity());
        giftItemForC2DTO.setGiftStatus(giftItem.getGiftStatus().name());
        giftItemForC2DTO.setDescription(giftItem.getDescription());
        giftItemForC2DTO.setImageUri(Optional.ofNullable(metaGiftMap.get(giftItem.getGiftId())).map(Gift::getImageUri).orElse(""));
        giftItemForC2DTO.setProducts(GiftAssembler.toProductDTOs(metaGiftMap.get(giftItem.getGiftId())));
        return giftItemForC2DTO;
    }

    public static CouponDTO toCouponDto(GiftCoupon giftCoupon, Gift gift) {
        CouponDTO couponDTO = new CouponDTO();
        couponDTO.setCode(giftCoupon.getCouponCode());
        couponDTO.setExpiredTime(giftCoupon.getEndAt().toString());
        couponDTO.setPrice(giftCoupon.getPrice());
        couponDTO.setProduct(giftCoupon.getGiftName());
        couponDTO.setStartTime(giftCoupon.getStartAt().toString());
        couponDTO.setStoreName(giftCoupon.getStoreName());
        if (CollectionUtils.isNotEmpty(gift.getCouponUrls())) {
            couponDTO.setUrls(gift.getCouponUrls().stream().map(GiftAssembler::urlItemTransformCouponUrlDTO).collect(Collectors.toList()));
        }
        return couponDTO;
    }
}
