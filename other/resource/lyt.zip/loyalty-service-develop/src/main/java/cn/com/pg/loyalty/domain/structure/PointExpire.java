package cn.com.pg.loyalty.domain.structure;


import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class PointExpire {
    private PointExpiredWay pointExpiredWay;
    private ExpiredDateCalculateWay expiredDateCalculateWay;
    private int pointEffectiveYear;
    private boolean usePointPool;
    private boolean orderDelayExpired;

    public PointExpire(PointExpiredWay pointExpiredWay, int pointEffectiveYear,
                       boolean usePointPool, boolean orderDelayExpired, ExpiredDateCalculateWay expiredDateCalculateWay) {
        if (pointExpiredWay == null) {
            throw new SystemException("pointExpiredWay not null",
                    ResultCodeMapper.PARAM_ERROR);
        }
        if (pointExpiredWay != PointExpiredWay.NONE && pointEffectiveYear < 1) {
            throw new SystemException("The expired way, effective year must gt 0",
                    ResultCodeMapper.PARAM_ERROR);
        }
        if (pointExpiredWay.notMatchPointPoolDepend(usePointPool)) {
            throw new SystemException("The expired way not match the point pool config ",
                    ResultCodeMapper.PARAM_ERROR);
        }
        //按年过期,积分有效期大于1年必须使用积分池
        if (matchPointExpiredWay(PointExpiredWay.BY_YEAR) && !usePointPool && pointEffectiveYear > 1) {
            throw new SystemException("Expired by year with effective gt 1 year must use pointPool",
                    ResultCodeMapper.PARAM_ERROR);
        }

        this.pointExpiredWay = pointExpiredWay;
        this.usePointPool = usePointPool;
        this.pointEffectiveYear = pointEffectiveYear;
        this.orderDelayExpired = orderDelayExpired;
        this.expiredDateCalculateWay = expiredDateCalculateWay;
    }

    public LocalDateTime pointExpiredTime(LocalDateTime pointCreatedTime) {
        return pointExpiredWay.pointExpiredDate(pointCreatedTime, pointEffectiveYear);
    }

    public LocalDate pointExpiredDate(LocalDateTime pointCreatedTime) {
        return pointExpiredWay.pointExpiredDate(pointCreatedTime, pointEffectiveYear).toLocalDate();
    }

    public boolean matchPointExpiredWay(PointExpiredWay expiredWay) {
        return expiredWay == this.pointExpiredWay;
    }

    /**
     * 不使用积分池，按年过期，积分有效期1年，默认过期时间是今年年底
     * 功能：用于判断是否使用今年年底为过期时间
     * 后期如果olay要使用积分池，并继续使用默认时间，可将该方法修改，使用其去控制积分池重算即将过期积分逻辑
     */
    public boolean useDefaultExpireDate() {
        return !usePointPool && matchPointExpiredWay(PointExpiredWay.BY_YEAR) && pointEffectiveYear == 1;
    }

    public enum PointExpiredWay {
        /**
         * 每天过期
         */
        BY_DAY(PointPoolDepend.ABLE_USE) {
            @Override
            public LocalDateTime pointExpiredDate(LocalDateTime pointCreatedTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getEndTimeOfDay(pointCreatedTime.plusYears(pointEffectiveYear));
            }
        },
        /**
         * 每月过期
         */
        BY_MONTH(PointPoolDepend.MUST_USE) {
            @Override
            public LocalDateTime pointExpiredDate(LocalDateTime pointCreatedTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getLastDayOfThisMonth(pointCreatedTime.plusYears(pointEffectiveYear));
            }
        },
        /**
         * 每年过期
         */
        BY_YEAR(PointPoolDepend.ABLE_USE) {
            @Override
            public LocalDateTime pointExpiredDate(LocalDateTime pointCreatedTime, int pointEffectiveYear) {
                return LoyaltyDateTimeUtils.getLastDayOfYear(pointCreatedTime.plusYears(pointEffectiveYear));
            }
        },

        NONE(PointPoolDepend.UNABLE_USE) {
            @Override
            public LocalDateTime pointExpiredDate(LocalDateTime pointCreatedTime, int pointEffectiveYear) {
                return null;
            }
        };

        abstract LocalDateTime pointExpiredDate(LocalDateTime pointCreatedTime, int pointEffectiveYear);

        private final PointPoolDepend pointPoolDepend;

        PointExpiredWay(PointPoolDepend pointPoolDepend) {
            this.pointPoolDepend = pointPoolDepend;
        }

        public boolean notMatchPointPoolDepend(boolean usePointPool) {
            if (this.pointPoolDepend == PointPoolDepend.MUST_USE) {
                return !usePointPool;
            }
            if (this.pointPoolDepend == PointPoolDepend.UNABLE_USE) {
                return usePointPool;
            }
            return false;
        }

    }

    private enum PointPoolDepend {
        UNABLE_USE,
        MUST_USE,
        ABLE_USE
    }

    /**
     * 按天过期，积分池使用外置积分池
     */
    public boolean useExternalPointPool() {
        return PointExpiredWay.BY_DAY.equals(pointExpiredWay)
                && usePointPool;
    }

    public boolean useInternalPointPool() {
        return usePointPool && !matchPointExpiredWay(PointExpiredWay.BY_DAY);
    }

    public enum ExpiredDateCalculateWay {
        /**
         * 根据创建时间计算
         */
        BY_CREATED_TIME() {
            @Override
            LocalDateTime orderPointExpiredDate(LocalDateTime orderDateTime) {
                return LocalDateTime.now();
            }
        },

        /**
         * 根据订单时间计算
         */
        BY_ORDER_DATETIME() {
            @Override
            LocalDateTime orderPointExpiredDate(LocalDateTime orderDateTime) {
                return orderDateTime;
            }
        };

        abstract LocalDateTime orderPointExpiredDate(LocalDateTime orderDateTime);
    }

    public LocalDateTime orderPointExpiredTime(LocalDateTime orderDateTime) {
        return pointExpiredWay.pointExpiredDate(this.expiredDateCalculateWay.orderPointExpiredDate(orderDateTime), pointEffectiveYear);
    }

    public LocalDate orderPointExpiredDate(LocalDateTime orderDateTime) {
        return pointExpiredWay.pointExpiredDate(this.expiredDateCalculateWay.orderPointExpiredDate(orderDateTime), pointEffectiveYear).toLocalDate();
    }

}
