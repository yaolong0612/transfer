package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.shared.ValueObject;

/**
 * @author Young
 * @date 2019年4月11日上午11:25:48
 * @description Transaction类型
 */
public enum TransactionType implements ValueObject<TransactionType> {
    /**
     * INTERACTION
     */
    INTERACTION,
    /**
     * ORDER
     */
    ORDER,
    /**
     * REDEMPTION
     */
    REDEMPTION,

    TIER;

    @Override
    public boolean sameValueAs(TransactionType other) {
        return this.equals(other);
    }
}
