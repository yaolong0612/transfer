package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountOpt;
import cn.com.pg.loyalty.domain.account.AccountOpt.OptNode;
import cn.com.pg.loyalty.domain.account.AccountOpt.OptType;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.interfaces.dto.*;
import org.springframework.beans.BeanUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Simon
 */

public class AccountAssembler {

    public static AccountDTO toAccountDTO(Account account, LoyaltyStructure loyaltyStructure, Map<String,Object> pointAboutExpireMap) {
        Tier tier = account.tier(loyaltyStructure.name());
        String brand = null;
        Iterator<String> iterator = loyaltyStructure.getBrands().iterator();
        if (iterator.hasNext()) {
            brand = iterator.next();
        }
        return new AccountDTO().loyaltyId(account.loyaltyId())
                .gradingPoint(account.gradingPoint(loyaltyStructure))
                .pointAboutExpire(account.pointAboutExpire(loyaltyStructure.accountTypeOfDefault()))
                .pointAvailable(account.availablePoint(loyaltyStructure.accountTypeOfDefault()))
                .pointExpired(account.pointExpired(loyaltyStructure.accountTypeOfDefault()))
                .pointUsed(account.pointUsed(loyaltyStructure.accountTypeOfDefault()))
                .transitPoint(account.availablePoint(loyaltyStructure.subAccountType(ValueType.TRANSIT)))
                .transitPointAboutExpire(account.pointAboutExpire(loyaltyStructure.subAccountType(ValueType.TRANSIT)))
                .tier(loyaltyStructure.tierLevelSeries().getLevelByName(tier.getLevel()).getLevelAlias())
                .tierExpired(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(tier.getExpiredTime()))
                .createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(account.registryTime(brand)))
                .totalPoint(account.totalPoint(loyaltyStructure.accountTypeOfDefault()))
                .upgradePoint(account.upgradePoint(loyaltyStructure))
                .babyBirthYearAndMonth(account.babyBirthYearAndMonth())
                .pointLocked(account.pointLocked(loyaltyStructure.accountTypeOfDefault()))
                .pointAboutExpireInFuture3Months(account.calculatePointAboutExpireInFuture3Months(brand, pointAboutExpireMap))
                .theLastPointAboutExpiredDateInFuture3Months(account.getTheLastPointAboutExpireDateInFuture3Months(brand, pointAboutExpireMap))
                .pointAboutExpiredDate(LoyaltyDateTimeUtils
                        .localDateToDataString(account.pointAboutExpiredDate(brand, loyaltyStructure)));
    }

    public static AccountTierDTO toAccountTierDTO(Account account, LoyaltyStructure loyaltyStructure, Integer currentPoint,Map<String,Object> pointAboutExpireMap) {
        AccountDTO accountDTO = toAccountDTO(account, loyaltyStructure,pointAboutExpireMap);
        AccountTierDTO accountTierDTO = new AccountTierDTO();
        BeanUtils.copyProperties(accountDTO, accountTierDTO);
        if(currentPoint != null){
            accountTierDTO.gradingPoint(account.gradingPoint(loyaltyStructure, currentPoint));
            accountTierDTO.upgradePoint(account.upgradePoint(loyaltyStructure, currentPoint))
                    .nextTier(account.nextTierLevel(loyaltyStructure).getLevelAlias());
        }
        return accountTierDTO;
    }

    public static AccountOpt.OptNode toOptNode(AccountOptCommand command) {
        LocalDateTime time = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(command.getOptTime());
        return new OptNode(OptType.valueOf(command.getOptType().toString()), time);
    }

    public static AccountAttrDTO toAccountAttrDTO(LoyaltyStructure loyaltyStructure, Account account) {
        String brand = null;
        Iterator<String> iterator = loyaltyStructure.getBrands().iterator();
        if (iterator.hasNext()) {
            brand = iterator.next();
        }
        AccountAttrDTO accountAttrDTO = new AccountAttrDTO();
        accountAttrDTO.setMemberId(account.memberId());
        accountAttrDTO.setPointAboutExpire(account.pointAboutExpire(loyaltyStructure.accountTypeOfDefault()));
        accountAttrDTO.setPointAvailable(account.availablePoint(loyaltyStructure.accountTypeOfDefault()));
        accountAttrDTO.setTier(loyaltyStructure.getTierLevelSeries().getLevelByName(account.tier(loyaltyStructure.name()).getLevel()).getLevelAlias());
        accountAttrDTO.setPointAboutExpiredDate(LoyaltyDateTimeUtils
                .localDateToDataString(account.pointAboutExpiredDate(brand, loyaltyStructure)));
        return accountAttrDTO;
    }

    public static AccountAttrListDTO toAccountAttrListDTO(LoyaltyStructure loyaltyStructure,
                                                          List<Account> accountList) {
        AccountAttrListDTO accountAttrListDTO = new AccountAttrListDTO();
        List<AccountAttrDTO> accountAttrDTOList =
                accountList.stream().map(item -> toAccountAttrDTO(loyaltyStructure, item)).collect(Collectors.toList());
        accountAttrListDTO.records(accountAttrDTOList);
        return accountAttrListDTO;
    }

    private AccountAssembler() {
    }

    public static AvailablePointPoolDTO toAvailablePointPoolDTO(Account account) {
        TreeMap<LocalDate, Integer> availablePointPoolMap = account.getAvailablePointPool().statementPointPool();
        List<AvailablePointPoolItem> availablePointPool = new ArrayList<>(availablePointPoolMap.size());
        availablePointPoolMap.forEach((k, v) -> {
            AvailablePointPoolItem pointPoolItem = new AvailablePointPoolItem();
            pointPoolItem.setDate(LoyaltyDateTimeUtils.localDateToDataString(k));
            pointPoolItem.setPoint(v);
            availablePointPool.add(pointPoolItem);
        });
        return new AvailablePointPoolDTO().memberId(account.getMemberId()).availablePointPool(availablePointPool);
    }
}
