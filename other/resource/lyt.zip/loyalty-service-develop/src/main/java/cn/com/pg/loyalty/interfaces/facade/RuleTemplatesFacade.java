package cn.com.pg.loyalty.interfaces.facade;

import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.interfaces.api.RuleTemplatesApiDelegate;
import cn.com.pg.loyalty.interfaces.dto.RuleTemplateDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author Ladd
 */
@Component("RuleTemplatesFacade")
public class RuleTemplatesFacade implements RuleTemplatesApiDelegate {

    @Override
    public ResponseEntity<List<RuleTemplateDTO>> fetchTemplateRuleList(String brand, String ruleTemplateName) {
        List<RuleTemplateDTO> ruleTemplateDTOList = new ArrayList<>();
        List<RuleTemplate> ruleTemplates = new ArrayList<>();
        if (StringUtils.isEmpty(ruleTemplateName)){
            ruleTemplates.addAll(Arrays.asList(RuleTemplate.values()));
        }else {
            try {
                ruleTemplates.add(RuleTemplate.valueOf(ruleTemplateName));
            }catch (Exception e){
                throw new SystemException("The ruleTemplateName :".concat(ruleTemplateName).concat(" is not found !"),ResultCodeMapper.PARAM_ERROR);
            }

        }
        ObjectMapper objectMapper = new ObjectMapper();
        //设置对象属性有null也需要序列化出来
        objectMapper.setSerializationInclusion(JsonInclude.Include.ALWAYS);
        for (int i = 0; i < ruleTemplates.size(); i++) {
            RuleTemplate ruleTemplate = ruleTemplates.get(i);
            RuleTemplateDTO ruleTemplateDTO = new RuleTemplateDTO();
            try {
                log.info(ruleTemplate.getDescription());
                ruleTemplateDTO.setParams(objectMapper.writeValueAsString(ruleTemplate.getRulePropertiesClazz().newInstance()));
            } catch (Exception exception) {
                throw new SystemException("解析Json出错" + exception.getMessage(), ResultCodeMapper.RULE_TEMPLATE_CHANGE_ERROR);
            }
            ruleTemplateDTO.setRuleTemplateId(ruleTemplate.name());
            ruleTemplateDTO.setRuleTemplateName(ruleTemplate.name());
            ruleTemplateDTO.setDescription(ruleTemplate.getDescription());
            ruleTemplateDTOList.add(ruleTemplateDTO);
        }
        return ResponseEntity.ok(ruleTemplateDTOList);
    }


}
