package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class ConfigService {

    private final ConfigRepository configRepository;
    private final CacheService cacheService;

    private static final long CONFIG_EXPIRED_TIME = 15 * 60 * 1000L;

    private static final String REGION = "REGION";
    private static final String BRAND = "BRAND";
    private static final String CHANNEL = "CHANNEL";

    @Autowired
    public ConfigService(ConfigRepository configRepository, CacheService cacheService) {
        this.configRepository = configRepository;
        this.cacheService = cacheService;
    }

    public void createConfig(Config config) {
        if (CollectionUtils.isNotEmpty(configRepository.findByTypeAndName(config.type(), config.name()))) {
            throw new SystemException(String.format("config [%s] already exists!", config.name()),
                    ResultCodeMapper.PARAM_ERROR);
        }
        configRepository.save(config);
    }

    public List<Config> findByType(String type) {
        return configRepository.findAllByType(type);
    }

    public Config findByTypeAndName(String type, String name) {
        List<Config> configList = configRepository.findByTypeAndName(type, name);
        if (CollectionUtils.isEmpty(configList)) {
            throw new SystemException(String.format("Param: %s error", type), ResultCodeMapper.PARAM_ERROR);
        }

        return configList.get(0);
    }

    public Config fetchByTypeAndName(String type, String name) {
        if (StringUtils.isBlank(name)) {
            throw new SystemException(String.format("Param: %s is empty", type), ResultCodeMapper.PARAM_ERROR);
        }
        Config cacheConfig = cacheService.getValue(cacheService.getKey(CacheService.KeyEnum.CONFIG, type, name),
                Config.class);
        if (Objects.nonNull(cacheConfig)) {
            return cacheConfig;
        }
        Config config = this.findByTypeAndName(type, name);
        cacheService.setValue(cacheService.getKey(CacheService.KeyEnum.CONFIG, type, name), config,
                CONFIG_EXPIRED_TIME);
        return config;
    }

    public RegionV2 region(String value) {
        Config config = fetchByTypeAndName(REGION, value);
        RegionV2 region = new RegionV2();
        BeanUtils.copyProperties(config, region);
        return region;
    }

    public BrandV2 brand(String value) {
        Config config = fetchByTypeAndName(BRAND, value);
        BrandV2 brand = new BrandV2();
        BeanUtils.copyProperties(config, brand);
        return brand;
    }

    public ChannelV2 channel(String value) {
        Config config = fetchByTypeAndName(CHANNEL, value);
        ChannelV2 channel = new ChannelV2();
        BeanUtils.copyProperties(config, channel);
        return channel;
    }

    public void deleteConfigById(String id) {
        configRepository.deleteByPartitionKeyAndId(Config.PARTITION_KEY, id);
    }

    public Config fetchConfigById(String id) {
        List<Config> configList = configRepository.findByPartitionKeyAndId(Config.PARTITION_KEY, id);
        if (CollectionUtils.isEmpty(configList)) {
            throw new SystemException(String.format("Param: %s error, config not found.", id),
                    ResultCodeMapper.PARAM_ERROR);
        }
        return configList.get(0);
    }

    public Config checkConfig(String type, String name) {
        Config config = fetchByTypeAndName(type, name);
        if (Objects.isNull(config)) {
          throw new SystemException("channel not config",ResultCodeMapper.PARAM_ERROR);
        }
        return config;
    }
}
