package cn.com.pg.loyalty.domain.transaction;


import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.account.Tier;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.Coupon;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.GiftItem.GiftStatus;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Young
 * @date 2019年4月11日上午11:34:41
 * @description Transaction中的 兑换类型,
 */
@Getter
@Setter
@Slf4j
@NoArgsConstructor
public class Redemption extends Transaction {
    /**
     * 兑换礼品列表
     */
    List<GiftItem> giftItemList = new ArrayList<>(4);
    /**
     * 收货人
     */
    private String receiver;
    /**
     * 收货人电话
     */
    private String phone;
    /**
     * 省
     */
    private String province;
    /**
     * 市
     */
    private String city;
    /**
     * 区
     */
    private String district;
    /**
     * 收货地址
     */
    private String address;

    /**
     * 订单状态
     */
    private RedemptionStatus redemptionStatus;

    /**
     * 收货柜台
     */
    private String storeCode;

    /**
     * 收货柜台名称
     */
    private String storeName;

    /**
     * 物流微服务Id
     */
    private String logisticsId;

    /**
     * 物流单号
     */
    private String deliveryNumber;

    /**
     * 调用系统状态,key系统的属性
     */
    private Map<String, Boolean> dataStatus = new HashMap<>(4);

    /**
     * 兑换唯一的标识码,这个兑换码TODO
     */
    private String redeemCode;

    /**
     * 发货渠道
     */
    private DeliveryChannel deliveryChannel;

    /**
     * 邮政编码
     */
    private String postalCode;

    /**
     * 物流公司名称
     */
    private String deliveryCompany;

    /**
     * 取消订单整单的原因
     */
    private String reason;
    /**
     * 运费
     */
    private Double freight;

    /**
     * 邮箱地址
     */
    private String email;
    /**
     * 幂等id
     */
    private String externalBusinessId;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate pickUpDate;

    /**
     * 构造方法，Assembler组装调用这个方法
     *
     * @param brand
     * @param channel
     * @param receiver
     * @param phone
     * @param province
     * @param city
     * @param district
     * @param address
     * @param pickUpDate
     */
    public Redemption(String brand, String channel, String receiver, String phone, String province,
                      String city, String district, String address, String storeCode, String postalCode,
                      String memberId, Double freight, LocalDate pickUpDate, String externalBusinessId, ValueType valueType) {
        super(brand, channel, memberId);
        this.receiver = receiver;
        this.phone = phone;
        this.province = province;
        this.city = city;
        this.district = district;
        this.address = address;
        this.storeCode = storeCode;
        this.postalCode = postalCode;
        this.redemptionStatus = RedemptionStatus.CREATED;
        this.freight = freight;
        this.pickUpDate = pickUpDate;
        this.externalBusinessId = externalBusinessId;
        this.valueType = valueType;
        this.transactionType = TransactionType.REDEMPTION;

    }

    @Default
    public Redemption(String brand, String channel, String memberId) {
        super(brand, channel, memberId);
        this.transactionType = TransactionType.REDEMPTION;
        this.redemptionStatus = RedemptionStatus.CREATED;
    }

    public void email(String email) {
        this.email = email;
    }

    public String email() {
        return this.email;
    }

    public void updateLogistics(LogisticsVO logisticsVO) {
        this.receiver = logisticsVO.getReceiver();
        this.phone = logisticsVO.getPhone();
        this.province = logisticsVO.getProvince();
        this.city = logisticsVO.getCity();
        this.district = logisticsVO.getDistrict();
        this.address = logisticsVO.getAddress();
        this.email = logisticsVO.getEmail();
        this.postalCode = logisticsVO.getPostalCode();
    }

    public enum MlOlayCounterTransferType {
        /**
         * 热线到家
         */
        HOT_LINE,
        /**
         * 转柜发运到家
         */
        TRANSFER_TO_HOME,
        /**
         * 转柜到B柜
         */
        TRANSFER_TO_COUNTER,
        /**
         * 正常到柜
         */
        NORMAL
    }

    public boolean judgeCanceled() {
        return RedemptionStatus.CANCELED == this.redemptionStatus;
    }

    public boolean pickupable() {
        return !(RedemptionStatus.ACCOMPLISHED == this.redemptionStatus
                || RedemptionStatus.CANCELED == this.redemptionStatus
                || RedemptionStatus.EXPIRED == this.redemptionStatus
                || RedemptionStatus.REJECTED == this.redemptionStatus);
    }

    public boolean finished() {
        return RedemptionStatus.CANCELED == this.redemptionStatus
                || RedemptionStatus.REJECTED == this.redemptionStatus
                || RedemptionStatus.EXPIRED == this.redemptionStatus
                || RedemptionStatus.ACCOMPLISHED == this.redemptionStatus;
    }

    public boolean giftCancelable() {
        return RedemptionStatus.CREATED == this.redemptionStatus;
    }

    public void addStoreName(String storeName) {
        this.storeName = storeName;
    }

    /**
     * 创建兑换订单
     *
     * @param list
     * @param account
     * @param activity
     * @param deliveryChannel
     */
    public void createRedemption(List<Redemption> list, Account account, Activity activity, LoyaltyStructure structure,
                                 Map<String, GiftItem> paramGiftItemMap, Map<String, Gift> giftMap,
                                 DeliveryChannel deliveryChannel) {
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        this.loyaltyId = account.loyaltyId();
        this.partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        this.description = activity.description();
        //判断兑换是否在本次活动时间的范围之内,以及是否已经激活
        activity.checkAvailable(this.createdTime);
        //判断是否是同一个积分体系
        checkLoyaltyStructure(structure, activity);
        //检验兑换的礼品是否有等级限制或是否需要校验等级限制
        checkTierLevel(structure, activity, account, paramGiftItemMap.keySet(), redemptionProperties);
        //判断是否超过兑换件数限制，返回本次兑换礼品所需要花费的积分
        this.point = checkLimitQuantity(list, activity, paramGiftItemMap);
        //设置发货渠道
        this.deliveryChannel = Optional.ofNullable(deliveryChannel).orElse(redemptionProperties.getDeliveryChannel());
        if (this.storeCode == null && this.deliveryChannel == DeliveryChannel.C2) {
            SubAccount subAccount = account.subAccount(this.brand, structure.accountTypeOfDefault());
            //设置首单柜
            this.storeCode = subAccount.getFirstPurchaseStoreCode();
        }
        //设计兑换码，当有兑换码传入时使用传入兑换码，当正常运行后，只是用自动生成代码，没有传进来的redeemCode
        this.redeemCode = this.redeemCode == null ? RandomUtils.getRedeemCode(this.loyaltyId, activity.getId(), brand, this.id) : this.redeemCode;
        List<PointItem> pointItemList = new ArrayList<>(2);
        Map<String, RedemptionItem> stringRedemptionItemMap = activity.getGifts();
        // 设置积分兑换记录
        setupPointItemAndGiftItemList(structure, redemptionProperties, activity, pointItemList, paramGiftItemMap, stringRedemptionItemMap, giftMap);
        //设置积分明细
        this.setPointItems(pointItemList);
        this.pointType = activity.pointType();
        this.activityId = activity.activityId();
    }

    /**
     * 创建兑换订单
     *
     * @param account
     * @param activity
     * @param deliveryChannel
     */
    public void createRedemptionV2(LoyaltyStructure structure, Account account, Activity activity,
                                   Map<String, GiftItem> paramGiftItemMap, Map<String, Gift> giftMap,
                                   DeliveryChannel deliveryChannel) {
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        this.loyaltyId = account.loyaltyId();
        this.partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        this.description = activity.description();
        //设置发货渠道
        this.deliveryChannel = Optional.ofNullable(deliveryChannel).orElse(redemptionProperties.getDeliveryChannel());
        if (this.storeCode == null && this.deliveryChannel == DeliveryChannel.C2) {
            SubAccount subAccount = account.subAccount(brand, structure.subAccountType(this));
            //设置首单柜
            this.storeCode = subAccount.getFirstPurchaseStoreCode();
        }
        //设计兑换码，当有兑换码传入时使用传入兑换码，当正常运行后，只是用自动生成代码，没有传进来的redeemCode
        this.redeemCode = this.redeemCode == null ? RandomUtils.getRedeemCode(this.loyaltyId, activity.getId(), brand, this.id) : this.redeemCode;
        List<PointItem> pointItemList = new ArrayList<>(2);
        Map<String, RedemptionItem> stringRedemptionItemMap = activity.getGifts();
        // 设置积分兑换记录
        setupPointItemAndGiftItemList(structure, redemptionProperties, activity, pointItemList, paramGiftItemMap, stringRedemptionItemMap, giftMap);
        //设置积分明细
        this.setPointItems(pointItemList);
        this.pointType = activity.pointType();
        this.activityId = activity.activityId();
    }

    public void checkStoreAvailable(Store store) {
        if (store != null) {
            if (store.olayTypeIsE() || store.storeStatusIsClose() || store.storeAddressIsEmpty()) {
                String msg = store.olayTypeIsE() ? "beauty counter is not available" : "counter is not available";
                throw new SystemException(msg, ResultCodeMapper.PARAM_ERROR);
            }
        }
    }

    private void setupPointItemAndGiftItemList(LoyaltyStructure structure, RedemptionProperties redemptionProperties, Activity activity, List<PointItem> pointItemList, Map<String, GiftItem> paramGiftItemMap, Map<String, RedemptionItem> stringRedemptionItemMap, Map<String, Gift> giftMap) {
        for (Map.Entry<String, GiftItem> entry : paramGiftItemMap.entrySet()) {
            String giftId = entry.getKey();
            GiftItem paramGift = entry.getValue();
            RedemptionItem redemptionItem = stringRedemptionItemMap.get(entry.getKey());
            Integer quantity = paramGift.getQuantity();
            Integer point = Optional.ofNullable(paramGift).map(GiftItem::getPoint).orElse(0);
            Gift gift = giftMap.get(giftId);
            String giftName = Optional.ofNullable(paramGift.getGiftName()).orElse("");
            // 如果不扣除库存 那么这边不维护礼品等信息
            if (redemptionProperties.isReductionInventory()) {
                if (ValueType.TRANSIT.equals(this.valueType(structure))) {
                    point = Optional.ofNullable(redemptionItem).map(RedemptionItem::getTransitPoint).orElseThrow(() ->
                            new SystemException("Can't find the related gifts of giftId[" + giftId + "]", ResultCodeMapper.PARAM_ERROR));
                } else {
                    point = Optional.ofNullable(redemptionItem).map(RedemptionItem::getPoint).orElseThrow(() ->
                            new SystemException("Can't find the related gifts of giftId[" + giftId + "]", ResultCodeMapper.PARAM_ERROR));
                }
                giftName = Optional.ofNullable(gift).map(Gift::getName).orElseThrow(() ->
                        new SystemException("Can't find the related gifts of giftId[" + giftId + "]", ResultCodeMapper.PARAM_ERROR));
            }
            // 积分记录
            PointItem pointItem = new PointItem(point * quantity, activity.description(), activity.activityId());
            pointItemList.add(pointItem);
            // 礼品信息记录
            String descriptionS = Optional.ofNullable(gift).map(Gift::getDescription).orElse(paramGift.getGiftName());
            GiftItem giftItem = new GiftItem(giftId, giftName, point, quantity, GiftItem.GiftStatus.NOT_RECEIVED, descriptionS);
            this.giftItemList.add(giftItem);
        }
    }

    public void updateRedemptionStatus(RedemptionStatus redemptionStatus, String storeCode, String deliveryNumber, LocalDateTime updateTime) {
        //如果没有传，就不需要更新
        if (storeCode != null) {
            this.storeCode = storeCode;
        }

        if (deliveryNumber != null) {
            this.deliveryNumber = deliveryNumber;
        }

        this.redemptionStatus = redemptionStatus;
        this.updatedTime = updateTime;
    }

    /**
     * 检查兑换的礼品是否超过出了兑换的数量范围
     *
     * @param redemptionList
     * @param activity
     * @param paramGiftItemMap
     */
    private int checkLimitQuantity(List<Redemption> redemptionList, Activity activity, Map<String, GiftItem> paramGiftItemMap) {
        //获取兑换规则，and 得到最大的礼品兑换数量限制
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        int totalLimitQuantity = redemptionProperties.getTotalLimitQuantity();
        int totalPoint = 0;
        // 如果不扣除库存 那么这边不维护礼品等信息，只扣除积分
        if (!redemptionProperties.isReductionInventory()) {
            Collection<GiftItem> giftItems = paramGiftItemMap.values();
            int pointSum = 0;
            for (GiftItem giftItem : giftItems) {
                Integer point = Optional.ofNullable(giftItem.getPoint()).orElseThrow(
                        () -> new SystemException("The param of the points of gift redemption can not be null", ResultCodeMapper.PARAM_ERROR));
                pointSum += (giftItem.getQuantity() * point);
                if (StringUtils.isBlank(giftItem.getGiftName())) {
                    throw new SystemException("The giftName param of gift redemption can not be null", ResultCodeMapper.PARAM_ERROR);
                }
            }
            return pointSum;
        }
        //获取单个礼品的兑换数量限制
        Map<String, RedemptionItem> map = activity.getGifts();
        //单个礼品的兑换数量
        int singleParamQuantity;
        //本次兑换总数
        Collection<Integer> quantityList = paramGiftItemMap.values().stream().map(GiftItem::getQuantity).collect(Collectors.toList());
        int totalQuantity = quantityList.stream().reduce(0, Integer::sum);
        // 获取用户历史兑换总数 过滤掉取消订单的数量和单个礼品的数量
        int historyTotalQuantity = redemptionList.stream().filter(redemption -> !redemption.redemptionStatusIsCancel() && !redemption.redemptionStatusIsReject())
                .flatMap(redemption -> redemption.getGiftItemList().stream()
                        .filter(giftItem -> !giftItem.canceled()).map(GiftItem::getQuantity))
                .reduce(0, Integer::sum);
        // 判断本次活动的兑换总数量 + 历史兑换总数据量 是否大于 总限制数据量
        if (totalLimitQuantity != 0 && (historyTotalQuantity + totalQuantity) > totalLimitQuantity) {
            throw new SystemException("The gifts you redeem exceed the maximum(" + totalLimitQuantity + ") limit of the event:(history+this)=" + (historyTotalQuantity + totalQuantity), ResultCodeMapper.LIMIT_ERROR);
        }
        for (Map.Entry<String, GiftItem> entry : paramGiftItemMap.entrySet()) {
            final String giftIdKey = entry.getKey();
            singleParamQuantity = entry.getValue().getQuantity();
            RedemptionItem redemptionItem = Optional.ofNullable(map.get(giftIdKey)).orElseThrow(() ->
                    new SystemException("CheckLimitQuantity can not get giftId[" + giftIdKey + "]corresponding gift", ResultCodeMapper.PARAM_ERROR));
            if (!redemptionItem.availablePeriod()) {
                throw new SystemException("gifts[" + giftIdKey + "]are not in the time of redemption", ResultCodeMapper.PARAM_ERROR);
            }
            int singleLimitQuantity = redemptionItem.getLimitQuantity();
            // 历史单个礼品的兑换总数 // 过滤掉取消单个礼品的数量
            int singleHistoryQuantity = redemptionList.stream()
                    .filter(redemption -> !redemption.redemptionStatusIsCancel())
                    .filter(redemption -> !redemption.redemptionStatusIsReject())
                    .flatMap(redemption -> redemption.getGiftItemList().stream()
                            .filter(giftItem -> giftIdKey.equalsIgnoreCase(giftItem.getGiftId()))
                            .filter(giftItem -> !giftItem.canceled()).map(GiftItem::getQuantity))
                    .reduce(0, Integer::sum);
            // 历史单个礼品兑换的总数 + 本次兑换的单个礼品总数 是否大于 单个礼品限制数量
            if (singleLimitQuantity != 0 && (singleHistoryQuantity + singleParamQuantity) > singleLimitQuantity) {
                throw new SystemException("The gifts you redeem exceed the maximum limit of the event", ResultCodeMapper.LIMIT_ERROR);
            }
            totalPoint += redemptionItem.getPoint() * singleParamQuantity;
        }
        return totalPoint;
    }

    public boolean redemptionStatusIsCancel() {
        return this.redemptionStatus == RedemptionStatus.CANCELED;
    }

    public boolean redemptionAccomplished() {
        return this.redemptionStatus == RedemptionStatus.ACCOMPLISHED;
    }

    public boolean redemptionStatusIsReject() {
        return this.redemptionStatus == RedemptionStatus.REJECTED;
    }

    public boolean redemptionStatusIsExpired() {
        return this.redemptionStatus == RedemptionStatus.EXPIRED;
    }

    public boolean redemptionStatusIsCreated() {
        return this.redemptionStatus == RedemptionStatus.CREATED;
    }

    public boolean redemptionIsEffective() {
        return !redemptionStatusIsCancel() && !redemptionStatusIsReject() && this.redemptionStatus != RedemptionStatus.EXPIRED;
    }


    /**
     * 修改柜台，目前是开放给消费者使用
     *
     * @param storeCode
     * @param activity
     */
    public void updateRedemptionStoreCode(String storeCode, Activity activity) {
        //判断现在是否在活动的兑换期，以及是否激活
        activity.checkAvailable(LocalDateTime.now());
        this.storeCode = storeCode;
        this.updatedTime = LocalDateTime.now();
    }

    /**
     * 判断是否是同一个积分体系
     *
     * @param activity
     */
    private void checkLoyaltyStructure(LoyaltyStructure loyaltyStructure, Activity activity) {
        String currentLoyaltyStructure = activity.getLoyaltyStructure();
        if (!StringUtils.equals(loyaltyStructure.name(), currentLoyaltyStructure)) {
            throw new SystemException("The credit system input is different from the configuration of the activity, which cannot be redeemed for gifts",
                    ResultCodeMapper.NO_SAME_LOYALTY_STRUCTURE);
        }
    }

    private void checkTierLevel(LoyaltyStructure structure, Activity activity, Account account, Set<String> stringSet, RedemptionProperties redemptionProperties) {
        if (redemptionProperties.isReductionInventory()) {
            for (String giftId : stringSet) {
                Map<String, RedemptionItem> map = activity.getGifts();
                RedemptionItem redemptionItem = Optional.ofNullable(map.get(giftId)).orElseThrow(
                        () -> new SystemException("CheckTierLevel can not get giftId[" + giftId + "]corresponding gift", ResultCodeMapper.PARAM_ERROR));
                Tier tier = account.tier(activity.getLoyaltyStructure());
                String tierLevel = tier.getLevel();
                if (structure.tierLevelSeries().compare(tierLevel, redemptionItem.getTierLevel()) < 0) {
                    throw new SystemException("You do not have enough tierLevel to redeem a premium gift", ResultCodeMapper.LOW_TIER_LEVEL_ERROR);
                }
            }
        }
    }

    public void updateDeliveryChannel(String storeCode, String logisticsId,
                                      String deliveryNumber, String receiver, String phone, String address,
                                      String province, String city, String district,
                                      DeliveryChannel deliveryChannel) {
        if (redemptionStatus == RedemptionStatus.CREATED) {
            this.storeCode = storeCode;
            this.logisticsId = logisticsId;
            this.deliveryNumber = deliveryNumber;
            this.receiver = receiver;
            this.phone = phone;
            this.address = address;
            this.province = province;
            this.city = city;
            this.district = district;
            this.deliveryChannel = deliveryChannel;
            this.updatedTime = LocalDateTime.now();
        }

    }

    public void updateStoreCode(String storeCode) {
        if (redemptionStatus == RedemptionStatus.CREATED && deliveryChannel == DeliveryChannel.C2) {
            this.storeCode = storeCode;
            this.updatedTime = LocalDateTime.now();
        }
    }

    /**
     * 判断传进来的礼品是否都有效
     */
    public void validateContainGifts(List<String> giftIds) {
        if (CollectionUtils.isEmpty(giftIds)) {
            return;
        }
        List<String> ids = this.giftItemList.stream().map(GiftItem::getGiftId).collect(Collectors.toList());
        List<String> unContainGifts = giftIds.stream().filter(giftId -> !ids.contains(giftId)).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(unContainGifts)) {
            throw new SystemException("Gifts: " + unContainGifts.toString() + " not exist.", ResultCodeMapper.PARAM_ERROR);
        }
    }

    /**
     * 修改状态，完成时不再需要修改
     *
     * @param status
     */
    public boolean batchUpdateRedemptionStatus(RedemptionStatus status) {
        if (!RedemptionStatus.ACCOMPLISHED.equals(this.redemptionStatus) && !RedemptionStatus.CREATED.equals(status)) {
            this.redemptionStatus = status;
            return true;
        }
        return false;
    }

    public String activityId() {
        return this.activityId;
    }

    public String externalBusinessId() {
        return this.externalBusinessId;
    }

    /**
     * 终止兑换，并返还积分
     *
     * @param cancelGifts
     * @param normalCancel normalCancel or coupon expired
     * @return 返还的积分
     */
    public Integer terminationRedemption(List<String> cancelGifts, GiftStatus giftStatus, boolean normalCancel) {
        if (!TransactionType.REDEMPTION.sameValueAs(this.transactionType)) {
            throw new SystemException("The transaction is not a redemption", ResultCodeMapper.PARAM_ERROR);
        }
        if (CollectionUtils.isEmpty(cancelGifts)) {
            cancelGifts = giftItemList.stream().filter(giftItem -> giftItem.allowChangeTo(giftStatus))
                    .map(GiftItem::getGiftId).collect(Collectors.toList());
        }
        if (CollectionUtils.isEmpty(cancelGifts)) {
            throw new SystemException("There are no gifts to " + giftStatus.name().toLowerCase(), ResultCodeMapper.PARAM_ERROR);
        }
        // 验证giftId是否都有效
        validateContainGifts(cancelGifts);
        List<String> finalCancelGifts = cancelGifts;
        List<GiftItem> updateGiftItem = giftItemList.stream()
                .filter(giftItem -> finalCancelGifts.contains(giftItem.getGiftId())).collect(Collectors.toList());
        Integer refundPoint = 0;
        for (GiftItem giftItem : updateGiftItem) {
            //校验该礼品是否允许做：拒绝、取消、过期操作
            try {
                giftItem.validateAllowChangeTo(giftStatus);
            } catch (SystemException e) {
                log.error(e.getMessage());
                // coupon 兑换中直接略过
                if (normalCancel) {
                    throw e;
                }
                continue;
            }
            refundPoint += (giftItem.getPoint() * giftItem.getQuantity());
            giftItem.setGiftStatus(giftStatus);
        }
        updateRedemptionStatus();
        this.updatedTime = LocalDateTime.now();
        return refundPoint;
    }

    /**
     * 更新兑换状态
     */
    private void updateRedemptionStatus() {

        Map<GiftItem.GiftStatus, Long> giftStatusCount = giftItemList.stream()
                .collect(Collectors.groupingBy(GiftItem::getGiftStatus, Collectors.counting()));

        if (giftStatusCount.containsKey(GiftItem.GiftStatus.NOT_RECEIVED)) {
            return;
        }
        if (giftStatusCount.containsKey(GiftStatus.EXPIRED)) {
            this.redemptionStatus = RedemptionStatus.EXPIRED;
            return;
        }
        if (giftStatusCount.size() == 1) {
            GiftItem.GiftStatus giftStatus = giftStatusCount.entrySet().iterator().next().getKey();
            if (RedemptionStatus.valueOf(giftStatus.name()) != null) {
                this.redemptionStatus = RedemptionStatus.valueOf(giftStatus.name());
            }
        } else {
            this.redemptionStatus = RedemptionStatus.ACCOMPLISHED;
        }
    }

    public void updateLogisticsId(String logisticsId, String key, boolean flag) {
        this.logisticsId = logisticsId;
        dataStatus.put(key, flag);
    }

    /**
     * 核销礼品的状态
     *
     * @param giftIdList 参数是传入多个礼品。
     */
    public void changeGiftsStatus2Received(List<String> giftIdList) {
        for (String giftId : giftIdList) {
            GiftItem giftItem = giftItem(giftId);
            giftItem.receiveGift();
        }
        this.updatedTime = LocalDateTime.now();
        checkRedemptionStatusByeGiftsStatus();
    }

    public GiftItem giftItem(String giftId) {
        for (GiftItem giftItem : this.giftItemList) {
            if (giftItem.getGiftId().equals(giftId)) {
                return giftItem;
            }
        }
        throw new SystemException("Gift is not found", ResultCodeMapper.REDEMPTION_ITEM_NOT_FOUND);
    }

    /**
     * 当核销礼品的状态时候,全部礼品核销完，就修改整个兑换订单的状态为完成。
     */
    public void checkRedemptionStatusByeGiftsStatus() {
        boolean flagReceived = true;
        for (GiftItem giftItem : this.giftItemList) {
            if (!giftItem.received() && !giftItem.canceled()) {
                flagReceived = false;
                break;
            }
        }
        if (flagReceived) {
            this.redemptionStatus = RedemptionStatus.ACCOMPLISHED;
        }
    }

    public static Comparator<Redemption> comparatorByRedemptionCreatedTimeDesc() {
        return (o1, o2) -> o2.createdTime.compareTo(o1.createdTime);
    }

    public void changeGiftReceivedStatus(String giftId) {
        int giftItemSize = this.giftItemList.size();
        int sum = 0;
        for (GiftItem giftItem : this.giftItemList) {
            if (giftItem.getGiftId().equals(giftId)) {
                if (giftItem.getGiftStatus().equals(GiftItem.GiftStatus.NOT_RECEIVED)) {
                    giftItem.setGiftStatus(GiftItem.GiftStatus.RECEIVED);
                } else {
                    throw new SystemException("The gift ID has RECEIVED. The gift ID is ".concat(giftItem.getGiftId()), ResultCodeMapper.PARAM_ERROR);
                }
                break;
            }
            sum++;
        }
        if (sum == giftItemSize) {
            throw new SystemException("The gift ID is not in this transaction. The input parameter is incorrect".concat(giftId), ResultCodeMapper.PARAM_ERROR);
        }
        this.updatedTime = LocalDateTime.now();
        checkRedemptionStatusByeGiftsStatus();
    }

    public String storeCode() {
        return this.storeCode;
    }

    public void storeCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public void updateReceiverAndMobile(String receiver, String phone) {
        this.receiver = receiver;
        this.phone = phone;
        this.updatedTime = LocalDateTime.now();
    }


    public boolean isCreatedStatus() {
        return this.redemptionStatus == RedemptionStatus.CREATED;
    }

    public void updateStatusToDelivered() {
        if (redemptionStatus == RedemptionStatus.CREATED) {
            redemptionStatus = RedemptionStatus.DELIVERED;
            updatedTime = LocalDateTime.now();
        }
    }

    public void deliveryCompany(String deliverCompany) {
        this.deliveryCompany = deliverCompany;
    }

    public void reason(String reason) {
        this.reason = reason;
    }

    public void redemptionStatus(RedemptionStatus status) {
        this.redemptionStatus = status;
    }

    public void updateLogisticsCallBack(String deliverCompany, String reason, RedemptionStatus status, String deliveryNumber) {
        if (this.redemptionStatus == RedemptionStatus.CANCELED ||
                this.redemptionStatus == RedemptionStatus.ACCOMPLISHED) {
            return;
        }
        this.redemptionStatus = status;
        this.deliveryCompany = deliverCompany;
        this.deliveryNumber = deliveryNumber;
        this.reason = reason;
        this.updatedTime = LocalDateTime.now();
    }

    public void checkLogisticUserInfo(RedemptionProperties redemptionProperties) {
        if (StringUtils.isBlank(receiver) || StringUtils.isBlank(phone) ||
                StringUtils.isBlank(address)) {
            String msg = "Receiver hasn't provided all information that is required" + "receiver:" +
                    receiver + "phone:" + phone +
                    "address：\n" + address;
            throw new SystemException(msg, ResultCodeMapper.PARAM_ERROR);
        }
    }

    public void checkLogisticUserInfo() {
        if (StringUtils.isBlank(receiver) || StringUtils.isBlank(phone) ||
                StringUtils.isBlank(address)) {
            String msg = "Receiver hasn't provided all information that is required" + "receiver:" +
                    receiver + "phone:" + phone +
                    "address：\n" + address;
            throw new SystemException(msg, ResultCodeMapper.PARAM_ERROR);
        }
    }

    public void validateAllowChangeTo(RedemptionStatus newRedemptionStatus, Activity activity) {
        RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
        if (newRedemptionStatus == RedemptionStatus.CANCELED && !redemptionProperties.isAllowCancel()) {
            throw new SystemException("The redemption is not allowed to cancel ", ResultCodeMapper.REDEMPTION_CONFIG_NOT_CANCEL);
        }
        if (newRedemptionStatus == RedemptionStatus.CANCELED && activity.activityIsEnd()) {
            throw new SystemException("The redemption Activity is end,can't cancel", ResultCodeMapper.ACTIVITY_NOT_AVAILABLE_ERROR);
        }
        if (newRedemptionStatus == RedemptionStatus.CANCELED && activity.judgeInLimitCancelPeriod(this.createdTime)) {
            throw new SystemException("The redemption is not allowed to cancel  in a special period when is prohibiting cancellation ", ResultCodeMapper.REDEMPTION_CONFIG_NOT_CANCEL);
        }
        if (!allowChangeTo(newRedemptionStatus)) {
            throw new SystemException("The redemption was " + this.redemptionStatus.name().toLowerCase()
                    + ",could not " + newRedemptionStatus.name().toLowerCase(), ResultCodeMapper.REDEMPTION_THIS_STATUS_NOT_ALLOW_CHANGED);
        }
    }

    private boolean allowChangeTo(RedemptionStatus newRedemptionStatus) {
        if (newRedemptionStatus == RedemptionStatus.CANCELED) {
            return this.redemptionStatus.isAllowCancel();
        }
        if (newRedemptionStatus == RedemptionStatus.REJECTED) {
            return this.redemptionStatus.isAllowReject();
        }
        if (newRedemptionStatus == RedemptionStatus.EXPIRED) {
            return this.redemptionStatus.isAllowExpire();
        }
        return false;
    }

    public Map<String, Integer> refundGiftsMap(List<String> gifts, GiftItem.GiftStatus giftStatus) {
        Map<String, Integer> refundGiftMap = new HashMap<>(12);
        List<GiftItem> giftItemsTemp;
        if (!CollectionUtils.isEmpty(gifts)) {
            giftItemsTemp = this.giftItemList.stream()
                    .filter(giftItem -> gifts.contains(giftItem.getGiftId()))
                    .collect(Collectors.toList());
        } else {
            giftItemsTemp = this.giftItemList;
        }
        giftItemsTemp.forEach(giftItem -> {
            if (giftItem.allowChangeTo(giftStatus)) {
                refundGiftMap.put(giftItem.getGiftId(), giftItem.getQuantity());
            }
        });
        return refundGiftMap;
    }

    /**
     * 非有效兑换的历史记录
     *
     * @return
     */
    public static List<String> backStatus() {
        List<String> redemptionStatusList = new ArrayList<>(4);
        redemptionStatusList.add(RedemptionStatus.CANCELED.name());
        redemptionStatusList.add(RedemptionStatus.REJECTED.name());
        redemptionStatusList.add(RedemptionStatus.EXPIRED.name());
        return redemptionStatusList;
    }

    public void updatePayedStatus(RedemptionStatus status) {
        if (this.redemptionStatus == RedemptionStatus.CANCELED ||
                this.redemptionStatus == RedemptionStatus.REJECTED) {
            throw new SystemException("该订单已被取消或拒绝，无法更新为支付状态", ResultCodeMapper.REDEMPTION_CANCELED_OR_REJECTED);
        }
        this.redemptionStatus = status;
        this.updatedTime = LocalDateTime.now();
    }

    public boolean returnRedeemCode() {
        if (DeliveryChannel.C2 != this.deliveryChannel) {
            return true;
        }
        return RedemptionStatus.CREATED != this.redemptionStatus &&
                RedemptionStatus.REJECTED != this.redemptionStatus &&
                RedemptionStatus.CANCELED != this.redemptionStatus;
    }

    public Map<String, String> kipElementMap() {
        if (StringUtils.isNotEmpty(this.phone)) {
            Map<String, String> map = new HashMap<>();
            map.put("loyalty_redemption_mobile", this.phone);
            return map;
        }
        return new HashMap<>();
    }

    public boolean filterByActivityId(String paramsActivityId) {
        return StringUtils.isNotEmpty(paramsActivityId) && this.activityId.equals(paramsActivityId);
    }

    public boolean deliverChannelIsLogistics() {
        return this.deliveryChannel.sameValueAs(DeliveryChannel.LOGISTICS);
    }

    public boolean matchExternalBusinessId(String externalBusinessId) {
        return StringUtils.equals(this.externalBusinessId, externalBusinessId);
    }

    public void reviseGiftItemsAndPoint(Map<String, Gift> giftMap, Activity activity, double discount) {
        Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
        this.giftItemList.forEach(giftItem -> {
            giftItem.setGiftStatus(GiftStatus.NOT_RECEIVED);
            Gift gift = giftMap.get(giftItem.getGiftId());
            giftItem.updateByGift(gift);
            RedemptionItem item = redemptionItemMap.get(giftItem.getGiftId());
            if (!item.availablePeriod()) {
                throw new SystemException("gifts[" + giftItem.getGiftId() + "]are not in the time of redemption", ResultCodeMapper.PARAM_ERROR);
            }
            giftItem.updatePoint((int) Math.floor(item.getPoint() * discount));
            if (ValueType.TRANSIT.equals(this.getValueType())) {
                giftItem.updatePoint(item.getTransitPoint());
            }
        });
        this.calculatePoint(activity);
    }

    public void calculatePoint(Activity activity) {
        pointItems.clear();
        description = activity.getDescription();
        this.pointType = activity.pointType();
        this.giftItemList.forEach(giftItem -> {
            if (giftItem.getPoint() != null) {
                PointItem pointItem = new PointItem(giftItem.getQuantity() * giftItem.getPoint(), description, activityId);
                pointItems.add(pointItem);
            }
        });
        this.point = pointItems.stream().mapToInt(PointItem::getPoint).sum();
    }

    public void updateByGiftCoupon(GiftCoupon coupon, Locale language) {
        coupon.translateByLanguage(language);
        redeemCode = coupon.getCouponCode();
        storeName = coupon.getStoreName();
    }

    public List<GiftItem> effectiveGiftItems() {
        return giftItemList.stream().filter(GiftItem::effective).collect(Collectors.toList());
    }

    public void bindDelivery(DeliveryChannel deliveryChannel) {
        this.deliveryChannel = Optional.ofNullable(this.deliveryChannel)
                .orElse(deliveryChannel);
        //设计兑换码，当有兑换码传入时使用传入兑换码，当正常运行后，只是用自动生成代码，没有传进来的redeemCode
        this.redeemCode = Optional.ofNullable(this.redeemCode)
                .orElse(RandomUtils.getRedeemCode(this.loyaltyId, activityId, brand, this.id));
    }

    public void bindCouponCode(Coupon coupon) {
        this.redeemCode = coupon.getCode();
        this.expiredTime = coupon.getEndAt();
    }

}
