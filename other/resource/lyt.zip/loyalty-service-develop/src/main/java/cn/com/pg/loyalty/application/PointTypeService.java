package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.PointTypeRepository;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @description:
 * @author: Artemus wang on 2019-06-27 14:52
 */
@Service
@Slf4j
public class PointTypeService {

    @Autowired
    private PointTypeRepository pointTypeRepository;

    @Autowired
    private ActivityRepository activityRepository;

    @Autowired
    private CacheService cacheService;

    public List<PointType> fetchPointTypeList(String brand, String region, PointType.PointTypeStatus status) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        return pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(), status);
    }

    public List<PointType> fetchPointTypeList(String brand, String region, PointType.PointTypeStatus status, TransactionType transactionType) {
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(region, brand);
        if (transactionType == null) {
            return pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(), status);
        } else {
            return pointTypeRepository.findByLoyaltyStructureAndStatusAndTransactionType(loyaltyStructure.name(), status, transactionType);
        }
    }

    public PointType addPointType(PointType pointType) {
        List<PointType> pointTypeList = pointTypeRepository.findByPointTypeAndLoyaltyStructure(pointType.getPointType(), pointType.getLoyaltyStructure());
        if (!pointTypeList.isEmpty()) {
            throw new SystemException("该pointType已经存在", ResultCodeMapper.POINT_TYPE_ALREADY_EXISTED);
        }
        return pointTypeRepository.save(pointType);
    }


    public void deleteById(String id, String userName) {
        List<PointType> pointTypeList = pointTypeRepository.findPointTypeById(id);
        if (pointTypeList.isEmpty()) {
            throw new SystemException("pointType未找到", ResultCodeMapper.POINT_TYPE_NOT_FOUND);
        }

        PointType pointType = pointTypeList.get(0);
        List<Activity> activityList = activityRepository.findByLoyaltyStructureAndPointType(
                pointType.getLoyaltyStructure(),
                pointType.pointType());
        if (!activityList.isEmpty()) {
            throw new SystemException("该pointType已有活动在使用，不能删除", ResultCodeMapper.POINT_TYPE_IN_USE);
        }
        pointType.delete(userName);
        pointTypeRepository.save(pointType);
    }

    public PointType findById(String pointTypeId) {
        List<PointType> pointTypeList = pointTypeRepository.findPointTypeById(pointTypeId);
        if (pointTypeList.isEmpty()) {
            throw new SystemException("pointType未找到", ResultCodeMapper.POINT_TYPE_NOT_FOUND);
        }
        return pointTypeList.get(0);
    }

    /**
     * 对已创建积分类型添加多语言
     *
     * @param pointTypeId
     * @param displayLanguages
     */
    public void addDisplayLanguages(String pointTypeId, List<PointType.PointTypeDisplayMsg> displayLanguages) {
        PointType pointType = findById(pointTypeId);
        pointType.addDisplayLanguages(displayLanguages);
        pointTypeRepository.save(pointType);
    }

}

