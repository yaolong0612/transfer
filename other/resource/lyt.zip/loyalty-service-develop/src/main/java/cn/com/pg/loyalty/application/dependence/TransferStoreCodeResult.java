package cn.com.pg.loyalty.application.dependence;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransferStoreCodeResult {

    private Integer involvedConsumerNum = null;

    private Integer involvedTransactionNum = null;

    public TransferStoreCodeResult(Integer involvedConsumerNum, Integer involvedTransactionNum) {
        this.involvedConsumerNum = involvedConsumerNum;
        this.involvedTransactionNum = involvedTransactionNum;
    }
}
