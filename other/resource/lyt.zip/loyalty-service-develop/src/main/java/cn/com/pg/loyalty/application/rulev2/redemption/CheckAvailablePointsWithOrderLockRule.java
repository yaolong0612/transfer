package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.*;

/**
 * @author lvyanlin
 * @date 2022/6/8 17:22
 */
@Slf4j
@Rule(name = "兑换活动可用积分规则",
        description = "兑换活动可用积分规则",priority = 1)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
@Component
public class CheckAvailablePointsWithOrderLockRule {

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    @Condition
    public boolean validateRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        //锁定天数大于0
        return ruleProperties.getOrderLockDay() > 0;

    }

    @Action
    public void executeRule(@Fact(RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties,
                            @Fact(RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
                            @Fact(RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                            @Fact(RULE_PARAM_NAME_ACCOUNT) Account account) {

        //兑换所需积分 <= 可用积分（account积分-锁定期积分）
        int point = redemption.point();

        int accountPoint = account.availablePoint(structure.accountTypeOfDefault());

        String loyaltyId = Optional.ofNullable(redemption.getLoyaltyId()).orElseThrow(
                () -> new SystemException("The param of the loyaltyId of redemption can not be null", ResultCodeMapper.PARAM_ERROR));

        List<Order> listOrder = orderRepositoryV2.findOrdersByOrderDateTimeBetween(loyaltyId,
                LocalDateTime.now().minusDays(ruleProperties.getOrderLockDay()),
                LocalDateTime.now());
        List<Order> orders = Optional.ofNullable(listOrder).orElse(new ArrayList<>());
        int lockPoint = orders.stream().mapToInt(Order::point).sum();

        // 可用积分小于兑换所需积分
        if ((accountPoint - lockPoint) < point ) {
            throw new SystemException("Insufficient points required", ResultCodeMapper.NOT_ENOUGH_POINT_ERROR);
        }
    }

}
