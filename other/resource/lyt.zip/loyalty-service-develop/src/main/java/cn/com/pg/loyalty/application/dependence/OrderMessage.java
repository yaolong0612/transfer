package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.domain.transaction.Order;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Ladd
 * @date 2019年6月15日下午2:02:17
 * @description one message that holds all orders from other trade platform
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderMessage {
    /**
     * 大陆为MemberId
     */
    private String memberId;
    /**
     * 该用户当天指定品牌的下的全渠道所有订单
     */
    private List<Order> transactions;
    /**
     * 品牌
     */
    private String brand;

    /**
     * 区域
     */
    private String region;
}
