package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.Account;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @description: 抽象出来访问仓储的接口以隔离仓储和业务
 * @author: Jevons Chen
 * @date: 2020-08-19 17:28
 */
public interface OrderRepositoryV2 {

    List<Order> findMemberOrdersByOrderId(String loyaltyId, String brand, String orderId, String channel);

    List<Order> findMemberOrdersByLoyaltyId(Account account, String brand);

    List<Order> findMemberSinceLastNumYearOrdersByLoyaltyId(Account account, String brand, int lastYears);

    List<Order> findGivenDateIntervalMonthAgo2ItOrders(Account account, String brand, int intervalMonths, LocalDateTime givenDate);

    List<Order> findOrdersByOrderDateTimeBetween(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime);

    List<Order> findMemberOrdersInOrderIds(String loyaltyId,List<String> ids);

    void deleteAll(List<Order> order);

    void saveAll(List<Order> orders);

    List<Order> fetchOrdersByCreatedTimeSorted(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime);

}

