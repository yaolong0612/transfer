package cn.com.pg.loyalty.application.dependence;

import lombok.Data;

import java.io.Serializable;

/**
 * @author: Dong
 * @date: 2019-11-29
 * @description: 帮宝适支付商城的传递给loyalty service的消息参数
 **/
@Data
public class UpdateRedemptionStatusMessage implements Serializable {

    private String brand;
    private String memberId;
    private String channel;
    private String transactionId;
}
