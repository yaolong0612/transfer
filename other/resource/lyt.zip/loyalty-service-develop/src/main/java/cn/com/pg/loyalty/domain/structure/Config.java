package cn.com.pg.loyalty.domain.structure;

import cn.com.pg.loyalty.domain.shared.Entity;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@Document(collection = "Config", ru = "400")
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type", include = JsonTypeInfo.As.EXISTING_PROPERTY,
        visible = true)
@JsonSubTypes({
        @JsonSubTypes.Type(value = RegionV2.class, name = "REGION"),
        @JsonSubTypes.Type(value = BrandV2.class, name = "BRAND"),
        @JsonSubTypes.Type(value = ChannelV2.class, name = "CHANNEL")
})
public class Config implements Entity<Config> {
    public static final String PARTITION_KEY = "CF";
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PARTITION_KEY;
    private String type;
    private String name;
    private String description;
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    @Override
    public boolean sameIdentityAs(Config other) {
        return this.id.equals(other.getId());
    }

    public Config(String type, String name, String description) {
        this.id = UUIDUtil.generator();
        this.partitionKey = PARTITION_KEY;
        this.type = type;
        this.name = name;
        this.description = description;
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
    }

    public String name() {
        return this.name;
    }

    public String type() {
        return this.type;
    }

    public String description() {
        return this.description;
    }

    public String id() {
        return this.id;
    }

    public enum Type{
        BRAND,
        REGION,
        CHANNEL;
    }

}
