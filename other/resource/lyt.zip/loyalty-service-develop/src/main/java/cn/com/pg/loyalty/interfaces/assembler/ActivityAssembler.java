package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.dto.*;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import com.alibaba.fastjson.JSON;
import org.apache.commons.collections4.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/***
 *@author simonMeng
 *@version 1.0
 *@Date 2019/4/29 15:37
 */
public class ActivityAssembler {

    private ActivityAssembler() {
    }

    public static ActivityDTO toActivityDTO(Activity activity) {
        return new ActivityDTO().activityId(activity.getId());
    }

    public static PointTypeActivityListDTO toPointTypeActivityListDTO(List<Activity> activityList, LoyaltyStructure structure,
                                                                      Map<String, Gift> giftMap, Map<String, Integer> activityPointMap) {
        PointTypeActivityListDTO pointTypeActivityListDTO = new PointTypeActivityListDTO();
        List<ActivityDetailDTO> records = new ArrayList<>();
        for (Activity activity : activityList) {
            ActivityDetailDTO detailDTO = new ActivityDetailDTO();
            if (activity.activityIsEnd()) {
                detailDTO.setStatus(ActivityDetailDTO.StatusEnum.END);
            } else if (activity.activityIsNotStart()) {
                detailDTO.setStatus(ActivityDetailDTO.StatusEnum.NOT_START);
            } else {
                detailDTO.setStatus(ActivityDetailDTO.StatusEnum.fromValue(activity.getStatus().name()));
            }
            detailDTO.setActivityId(activity.activityId());
            detailDTO.setExternalCode(activity.getExternalId());
            detailDTO.setActivityName(activity.getActivityName());
            detailDTO.setPointType(activity.getPointType());
            detailDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
            detailDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
            detailDTO.setBrand(activity.getBrand());
            detailDTO.setUpdatedBy(activity.getUpdatedBy());
            detailDTO.setPriority(activity.getPriority());
            detailDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
            detailDTO.setRegion(structure.getRegion());
            detailDTO.setRemark(activity.getRemark());
            if (TransactionType.REDEMPTION.sameValueAs(activity.getTransactionType())) {
                RedemptionProperties redemptionProperties = (RedemptionProperties) activity.ruleProperties();
                detailDTO.setTotalLimitQuantity(redemptionProperties.getTotalLimitQuantity());
                detailDTO.setReduceInventory(redemptionProperties.isReductionInventory());
                detailDTO.setDeliveryChannel(ActivityDetailDTO.DeliveryChannelEnum.valueOf(redemptionProperties.getDeliveryChannel().name()));
                detailDTO.setAllowCancel(redemptionProperties.isAllowCancel());
                detailDTO.setAllowDelivery(redemptionProperties.isAllowDeliverDirectly());
                detailDTO.setLimitProperty(JSON.toJSONString(redemptionProperties.limitTime()));
                detailDTO.setPurchaseLimitProperty(redemptionProperties.purchaseLimitProperties());
                detailDTO.setRedemptionTimesCalculationType(
                        redemptionProperties.redemptionTimesCalculationTypeProperties());
                detailDTO.setRedemptionLimitType(redemptionProperties.limitTypeProperties());
                List<RedemptionGiftDTO> gifts = toRedemptionGiftDTOList(activity.getGifts(), giftMap.values(), null);
                detailDTO.setGifts(gifts);
                detailDTO.setTotalPoint(activityPointMap.get(activity.activityId()));
            } else {
                detailDTO.setRuleTemplateId(activity.ruleTemplate().name());
                detailDTO.setProperties(activity.getRuleProperties());
            }
            records.add(detailDTO);
        }
        pointTypeActivityListDTO.setTotalSize(records.size());
        pointTypeActivityListDTO.setRecords(records);
        return pointTypeActivityListDTO;
    }

    public static InteractionActivityListDTO toInteractionActivityListDTO(PageableResult<Activity> result) {
        InteractionActivityListDTO interactionActivityListDTO = new InteractionActivityListDTO();
        List<Activity> activities = result.getRecords();
        List<InteractionActivityDTO> interactionActivityDTOS = new ArrayList<>();
        if (null != activities && !activities.isEmpty()) {
            interactionActivityDTOS = activities.parallelStream().map(activity -> {
                InteractionActivityDTO interactionActivityDTO = new InteractionActivityDTO();
                if (activity.activityIsEnd()) {
                    interactionActivityDTO.setStatus(InteractionActivityDTO.StatusEnum.END);
                } else if (activity.activityIsNotStart()) {
                    interactionActivityDTO.setStatus(InteractionActivityDTO.StatusEnum.NOT_START);
                } else {
                    interactionActivityDTO.setStatus(InteractionActivityDTO.StatusEnum.valueOf(activity.getStatus().name()));
                }
                interactionActivityDTO.pointType(activity.getPointType())
                        .activityId(activity.getId())
                        .activityName(activity.getActivityName())
                        .createdBy(activity.getCreatedBy())
                        .description(activity.getDescription())
                        .externalCode(activity.getExternalId())
                        .updatedBy(activity.getUpdatedBy())
                        .ruleTemplateId(activity.getRuleTemplate().name())
                        .startAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()))
                        .endAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()))
                        .createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()))
                        .updatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()))
                        .remark(activity.getRemark()).priority(activity.getPriority());
                return interactionActivityDTO;
            }).collect(Collectors.toList());
        }
        interactionActivityListDTO.setRecords(interactionActivityDTOS);
        interactionActivityListDTO.setTotalSize(result.getTotalSize());
        return interactionActivityListDTO;
    }

    public static RedemptionActivityListDTO toRedemptionActivityListDTO(PageableResult<Activity> result, Map<String, Gift> giftMap) {
        RedemptionActivityListDTO redemptionActivityListDTO = new RedemptionActivityListDTO();
        List<Activity> activities = result.getRecords();
        List<RedemptionActivityDTO> redemptionActivityDTOS = new ArrayList<>();
        for (Activity activity : activities) {
            RedemptionActivityDTO rActivityDTO = new RedemptionActivityDTO();

            if (activity.activityIsEnd()) {
                rActivityDTO.setStatus(RedemptionActivityDTO.StatusEnum.END);
            } else if (activity.activityIsNotStart()) {
                rActivityDTO.setStatus(RedemptionActivityDTO.StatusEnum.NOT_START);
            } else {
                rActivityDTO.setStatus(RedemptionActivityDTO.StatusEnum.valueOf(activity.getStatus().name()));
            }
            List<RedemptionGiftDTO> gifts = toRedemptionGiftDTOList(activity.getGifts(), giftMap.values(), null);
            rActivityDTO.activityId(activity.getId())
                    .activityName(activity.getActivityName())
                    .pointType(activity.getPointType())
                    .createdBy(activity.getCreatedBy())
                    .startAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()))
                    .endAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()))
                    .createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()))
                    .updatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()))
                    .description(activity.getDescription())
                    .externalCode(activity.getExternalId())
                    .remark(activity.getRemark())
                    .gifts(gifts)
                    .logisticsActivityId(activity.logisticsActivityId())
                    .priority(activity.getPriority());

            redemptionActivityDTOS.add(rActivityDTO);
        }
        redemptionActivityListDTO.setRecords(redemptionActivityDTOS);
        redemptionActivityListDTO.setTotalSize(result.getTotalSize());
        return redemptionActivityListDTO;
    }


    public static ActivityGiftListDTO toActivityGiftListDTO(Activity activity,
                                                            List<RedemptionGiftDTO> redemptionGiftDTOS, int totalSize) {
        ActivityGiftListDTO activityGiftListDTO = new ActivityGiftListDTO();

        activityGiftListDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
        activityGiftListDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
        activityGiftListDTO.setRecords(redemptionGiftDTOS);
        activityGiftListDTO.setTotalSize(totalSize);
        return activityGiftListDTO;
    }

    public static RedemptionActivityDetailsDTO toRedemptionActivityDetailsDTO(Activity activity, LoyaltyStructure structure,
                                                                              Map<String, RedemptionItem> redemptionItemMap,
                                                                              List<Gift> gifts, Map<String, Integer> activityPointMap) {
        RedemptionActivityDetailsDTO redemptionActivityDetailsDTO = new RedemptionActivityDetailsDTO();
        if (activity.activityIsEnd()) {
            redemptionActivityDetailsDTO.setStatus(RedemptionActivityDetailsDTO.StatusEnum.END);
        } else if (activity.activityIsNotStart()) {
            redemptionActivityDetailsDTO.setStatus(RedemptionActivityDetailsDTO.StatusEnum.NOT_START);
        } else {
            redemptionActivityDetailsDTO.setStatus(RedemptionActivityDetailsDTO.StatusEnum.valueOf(activity.getStatus().name()));
        }
        redemptionActivityDetailsDTO.setExternalCode(activity.getExternalId());
        redemptionActivityDetailsDTO.setActivityName(activity.getActivityName());
        redemptionActivityDetailsDTO.setPointType(activity.getPointType());
        redemptionActivityDetailsDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
        redemptionActivityDetailsDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
        redemptionActivityDetailsDTO.setBrand(activity.getBrand());
        redemptionActivityDetailsDTO.setUpdatedBy(activity.getUpdatedBy());
        redemptionActivityDetailsDTO.setPriority(activity.getPriority());
        redemptionActivityDetailsDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
        redemptionActivityDetailsDTO.setRegion(structure.getRegion());
        redemptionActivityDetailsDTO.setRemark(activity.getRemark());
        redemptionActivityDetailsDTO.logisticsActivityId(activity.logisticsActivityId());
        redemptionActivityDetailsDTO.setDescription(activity.getDescription());
        redemptionActivityDetailsDTO.setLoyaltyStructure(activity.getLoyaltyStructure());
        redemptionActivityDetailsDTO.setProperties(activity.getRuleProperties());
        List<RedemptionGiftDTO> redemptionGiftDTOS = toRedemptionGiftDTOList(redemptionItemMap, gifts, null);
        redemptionActivityDetailsDTO.setRecords(redemptionGiftDTOS);
        redemptionActivityDetailsDTO.setTotalPoint(activityPointMap.get(activity.activityId()));
        redemptionActivityDetailsDTO.setMsgTemplate(activity.getMsgTemplate());
        redemptionActivityDetailsDTO.setDisplayLanguages(toDisplayMsgDTO(activity.getDisplayLanguages()));
        return redemptionActivityDetailsDTO;
    }


    public static OrderActivityListDTO toOrderActivityListDTO(PageableResult<Activity> result) {
        OrderActivityListDTO orderActivityListDTO = new OrderActivityListDTO();
        List<Activity> activities = result.getRecords();
        List<OrderActivityDTO> orderActivityDTOS = new ArrayList<>();
        if (null != activities && !activities.isEmpty()) {
            for (Activity activity : activities) {
                OrderActivityDTO orderActivityDTO = new OrderActivityDTO();
                if (activity.activityIsEnd()) {
                    orderActivityDTO.setStatus(OrderActivityDTO.StatusEnum.END);
                } else if (activity.activityIsNotStart()) {
                    orderActivityDTO.setStatus(OrderActivityDTO.StatusEnum.NOT_START);
                } else {
                    orderActivityDTO.setStatus(OrderActivityDTO.StatusEnum.valueOf(activity.getStatus().name()));
                }
                orderActivityDTO.setActivityId(activity.getId());
                orderActivityDTO.setPointType(activity.getPointType());
                orderActivityDTO.setActivityName(activity.getActivityName());
                orderActivityDTO.setPointType(activity.getPointType());
                orderActivityDTO.setCreatedBy(activity.getCreatedBy());
                orderActivityDTO.setDescription(activity.getDescription());
                orderActivityDTO.setRuleTemplateId(activity.getRuleTemplate().name());
                orderActivityDTO.setRemark(activity.getRemark());
                orderActivityDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
                orderActivityDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
                orderActivityDTO.setExternalCode(activity.getExternalId());
                orderActivityDTO.setUpdatedBy(activity.getUpdatedBy());
                orderActivityDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
                orderActivityDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()));
                orderActivityDTO.setPriority(activity.getPriority());
                orderActivityDTOS.add(orderActivityDTO);
            }
        }
        orderActivityListDTO.setRecords(orderActivityDTOS);
        orderActivityListDTO.setTotalSize(result.getTotalSize());
        return orderActivityListDTO;
    }

    public static TierActivityListDTO toTierActivityListDTO(PageableResult<Activity> result) {
        TierActivityListDTO tierActivityListDTO = new TierActivityListDTO();
        List<Activity> activities = result.getRecords();
        List<TierActivityDTO> tierActivityDTOS = new ArrayList<>();
        if (null != activities && !activities.isEmpty()) {
            for (Activity activity : activities) {
                TierActivityDTO tierActivityDTO = new TierActivityDTO();
                if (activity.activityIsEnd()) {
                    tierActivityDTO.setStatus(TierActivityDTO.StatusEnum.END);
                } else if (activity.activityIsNotStart()) {
                    tierActivityDTO.setStatus(TierActivityDTO.StatusEnum.NOT_START);
                } else {
                    tierActivityDTO.setStatus(TierActivityDTO.StatusEnum.valueOf(activity.getStatus().name()));
                }
                tierActivityDTO.setActivityId(activity.getId());
                tierActivityDTO.setPointType(activity.getPointType());
                tierActivityDTO.setActivityName(activity.getActivityName());
                tierActivityDTO.setPointType(activity.getPointType());
                tierActivityDTO.setCreatedBy(activity.getCreatedBy());
                tierActivityDTO.setDescription(activity.getDescription());
                tierActivityDTO.setRuleTemplateId(activity.getRuleTemplate().name());
                tierActivityDTO.setRemark(activity.getRemark());
                tierActivityDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
                tierActivityDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
                tierActivityDTO.setExternalCode(activity.getExternalId());
                tierActivityDTO.setUpdatedBy(activity.getUpdatedBy());
                tierActivityDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
                tierActivityDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()));
                tierActivityDTO.setPriority(activity.getPriority());
                tierActivityDTOS.add(tierActivityDTO);
            }
        }
        tierActivityListDTO.setRecords(tierActivityDTOS);
        tierActivityListDTO.setTotalSize(result.getTotalSize());
        return tierActivityListDTO;
    }


    public static OrderActivityDetailsDTO toOrderActivityDetailsDTO(Activity activity) {
        OrderActivityDetailsDTO activityDetailsDTO = new OrderActivityDetailsDTO();
        if (activity.activityIsEnd()) {
            activityDetailsDTO.setStatus(OrderActivityDetailsDTO.StatusEnum.END);
        } else if (activity.activityIsNotStart()) {
            activityDetailsDTO.setStatus(OrderActivityDetailsDTO.StatusEnum.NOT_START);
        } else {
            activityDetailsDTO.setStatus(OrderActivityDetailsDTO.StatusEnum.valueOf(activity.getStatus().name()));
        }
        activityDetailsDTO.setActivityId(activity.getId());
        activityDetailsDTO.setPointType(activity.getPointType());
        activityDetailsDTO.setActivityName(activity.getActivityName());
        activityDetailsDTO.setProperties(activity.getRuleProperties());
        activityDetailsDTO.setCreatedBy(activity.getCreatedBy());
        activityDetailsDTO.setDescription(activity.getDescription());
        activityDetailsDTO.setRuleTemplateId(activity.getRuleTemplate().name());
        activityDetailsDTO.setRemark(activity.getRemark());
        activityDetailsDTO.setPriority(activity.getPriority());
        activityDetailsDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
        activityDetailsDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
        activityDetailsDTO.setExternalCode(activity.getExternalId());
        activityDetailsDTO.setUpdatedBy(activity.getUpdatedBy());
        activityDetailsDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
        activityDetailsDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()));
        activityDetailsDTO.setLoyaltyStructure(activity.getLoyaltyStructure());
        activityDetailsDTO.setDisplayLanguages(toDisplayMsgDTO(activity.getDisplayLanguages()));
        return activityDetailsDTO;
    }

    public static InteractionActivityDetailsDTO toInteractionActivityDetailsDTO(Activity activity) {
        InteractionActivityDetailsDTO activityDetailsDTO = new InteractionActivityDetailsDTO();
        if (activity.activityIsEnd()) {
            activityDetailsDTO.setStatus(InteractionActivityDetailsDTO.StatusEnum.END);
        } else if (activity.activityIsNotStart()) {
            activityDetailsDTO.setStatus(InteractionActivityDetailsDTO.StatusEnum.NOT_START);
        } else {
            activityDetailsDTO.setStatus(InteractionActivityDetailsDTO.StatusEnum.valueOf(activity.getStatus().name()));
        }
        activityDetailsDTO.setActivityId(activity.getId());
        activityDetailsDTO.setActivityName(activity.getActivityName());
        activityDetailsDTO.setPointType(activity.getPointType());
        activityDetailsDTO.setProperties(activity.getRuleProperties());
        activityDetailsDTO.setCreatedBy(activity.getCreatedBy());
        activityDetailsDTO.setDescription(activity.getDescription());
        activityDetailsDTO.setRuleTemplateId(activity.getRuleTemplate().name());
        activityDetailsDTO.setRemark(activity.getRemark());
        activityDetailsDTO.setPriority(activity.getPriority());
        activityDetailsDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
        activityDetailsDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
        activityDetailsDTO.setExternalCode(activity.getExternalId());
        activityDetailsDTO.setUpdatedBy(activity.getUpdatedBy());
        activityDetailsDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
        activityDetailsDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()));
        activityDetailsDTO.setLoyaltyStructure(activity.getLoyaltyStructure());
        activityDetailsDTO.setMsgTemplate(activity.getMsgTemplate());
        activityDetailsDTO.setDisplayLanguages(toDisplayMsgDTO(activity.getDisplayLanguages()));
        return activityDetailsDTO;
    }


    public static List<RedemptionGiftDTO> toRedemptionGiftDTOList(Map<String, RedemptionItem> redemptionItemMap, Collection<Gift> metaGifts, String language) {
        return toRedemptionGiftDTOList(redemptionItemMap, metaGifts, new HashMap<>(), language);
    }

    public static List<RedemptionGiftDTO> toRedemptionGiftDTOList(Map<String, RedemptionItem> redemptionItemMap,
                                                                  Collection<Gift> metaGifts, Map<String, GiftCoupon> couponMap, String language) {
        if (redemptionItemMap == null || metaGifts == null) {
            return new ArrayList<>();
        }
        List<RedemptionGiftDTO> redemptionGiftDTOList = new ArrayList<>();
        for (Map.Entry<String, RedemptionItem> entry : redemptionItemMap.entrySet()) {
            String giftId = entry.getKey();
            RedemptionItem redemptionItem = entry.getValue();
            RedemptionGiftDTO redemptionGiftDTO = new RedemptionGiftDTO();
            Optional<Gift> metaGiftOption = metaGifts.stream().filter(item -> giftId.equals(item.getId())).findFirst();
            redemptionGiftDTO.setGroupName(redemptionItem.getGroupName());
            redemptionGiftDTO.setGradeName(redemptionItem.getGradeName());
            metaGiftOption.ifPresent(metaGift -> {
                List<GiftDisplayMsgDTO> giftMultilingual = GiftAssembler.giftDisplayMsgTransformDisplayDTO(metaGift.getDisplayLanguages());
                //使用默认值
                redemptionGiftDTO.setDescription(metaGift.getDescription());
                redemptionGiftDTO.setEfficacies(metaGift.getEfficacies());
                redemptionGiftDTO.setProducts(GiftAssembler.toProductDTOs(metaGift));
                redemptionGiftDTO.setGiftName(metaGift.getName());
                redemptionGiftDTO.setImage(metaGift.getImageUri());
                //当language参数有值并找到目标语言，设置目标语言
                if (Optional.ofNullable(language).isPresent()) {
                    Optional<GiftDisplayMsgDTO> giftDisplayMsgDTO = giftMultilingual.stream().filter(item -> item.getLanguage().toString().equals(language)).findFirst();
                    giftDisplayMsgDTO.ifPresent(item -> {
                        redemptionGiftDTO.setDescription(item.getDescription());
                        redemptionGiftDTO.setProducts(item.getProducts());
                        redemptionGiftDTO.setGiftName(item.getGiftName());
                        //由于不是一开始就上了图片，可能为null，如果不存在则使用默认的图片
                        Optional.ofNullable(item.getImageUri()).ifPresent(redemptionGiftDTO::setImage);
                    });
                }
                GiftCoupon coupon = couponMap.get(metaGift.getBagSku());
                redemptionGiftDTO.setPrice(metaGift.getMarketPrice().doubleValue());
                redemptionGiftDTO.setGiftMultilingual(giftMultilingual);
                redemptionGiftDTO.setGiftType(RedemptionGiftDTO.GiftTypeEnum.valueOf(metaGift.getType().name()));
                if (couponGift(metaGift) && coupon != null) {
                    redemptionGiftDTO.setUrls(metaGift.getCouponUrls().stream().map(GiftAssembler::urlItemTransformCouponUrlDTO).collect(Collectors.toList()));
                    redemptionGiftDTO.setCouponEndAt(coupon.getEndAt().toString());
                    redemptionGiftDTO.setCouponStartAt(coupon.getStartAt().toString());
                    redemptionGiftDTO.setStoreName(coupon.getStoreName());
                }

            });
            redemptionGiftDTO.setGiftId(redemptionItem.getGiftId());
            redemptionGiftDTO.setTierLevel(redemptionItem.getTierLevel());
            redemptionGiftDTO.setLogisticsGiftId(redemptionItem.getLogisticsGiftId());
            redemptionGiftDTO.setFreight(redemptionItem.getFreight());
            redemptionGiftDTO.setStock(redemptionItem.getStock());
            redemptionGiftDTO.setPoint(redemptionItem.getPoint());
            redemptionGiftDTO.setTransitPoint(redemptionItem.getTransitPoint());
            redemptionGiftDTO.setIssuedNum(redemptionItem.getIssuedNum());
            redemptionGiftDTO.setLimit(redemptionItem.getLimitQuantity());
            redemptionGiftDTO.setAvailableStock(redemptionItem.availableStock());
            redemptionGiftDTO.setPriority(Optional.ofNullable(redemptionItem.getPriority()).orElse(0));
            redemptionGiftDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemptionItem.getStartAt()));
            redemptionGiftDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(redemptionItem.getEndAt()));
            redemptionGiftDTOList.add(redemptionGiftDTO);
        }
        //按排序值降序排序
        redemptionGiftDTOList.sort(Comparator.comparing(RedemptionGiftDTO::getPriority).thenComparing(RedemptionGiftDTO::getStartAt).reversed());
        return redemptionGiftDTOList;
    }

    public static TierActivityDetailsDTO toTierActivityDetailsDTO(Activity activity) {
        TierActivityDetailsDTO activityDetailsDTO = new TierActivityDetailsDTO();
        if (activity.activityIsEnd()) {
            activityDetailsDTO.setStatus(TierActivityDetailsDTO.StatusEnum.END);
        } else if (activity.activityIsNotStart()) {
            activityDetailsDTO.setStatus(TierActivityDetailsDTO.StatusEnum.NOT_START);
        } else {
            activityDetailsDTO.setStatus(TierActivityDetailsDTO.StatusEnum.valueOf(activity.getStatus().name()));
        }
        activityDetailsDTO.setActivityId(activity.getId());
        activityDetailsDTO.setPointType(activity.getPointType());
        activityDetailsDTO.setActivityName(activity.getActivityName());
        activityDetailsDTO.setProperties(activity.getRuleProperties());
        activityDetailsDTO.setCreatedBy(activity.getCreatedBy());
        activityDetailsDTO.setDescription(activity.getDescription());
        activityDetailsDTO.setRuleTemplateId(activity.getRuleTemplate().name());
        activityDetailsDTO.setRemark(activity.getRemark());
        activityDetailsDTO.setPriority(activity.getPriority());
        activityDetailsDTO.setStartAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()));
        activityDetailsDTO.setEndAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()));
        activityDetailsDTO.setExternalCode(activity.getExternalId());
        activityDetailsDTO.setUpdatedBy(activity.getUpdatedBy());
        activityDetailsDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getUpdatedTime()));
        activityDetailsDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()));
        activityDetailsDTO.setLoyaltyStructure(activity.getLoyaltyStructure());
        return activityDetailsDTO;
    }

    private static boolean couponGift(Gift metaGift) {
        return metaGift.getCouponUrls() != null && metaGift.couponGift();
    }

    public static QrcodeActivitySkuListDTO toActivitySkuListDTO(List<QrcodeItem> qrcodeItems, int totalSize) {
        List<QrcodeActivitySkuDTO> scanCodeSkuDTOS = new ArrayList<>();
        qrcodeItems.forEach(baseScanCodeSku -> {
            QrcodeActivitySkuDTO qrcodeActivitySkuDTO = new QrcodeActivitySkuDTO();
            qrcodeActivitySkuDTO.setBasePoint(baseScanCodeSku.getBasePoint());
            qrcodeActivitySkuDTO.setDescription(baseScanCodeSku.getDescription());
            qrcodeActivitySkuDTO.setExtraPoint(baseScanCodeSku.getExtraPoint());
            qrcodeActivitySkuDTO.setMultiple(baseScanCodeSku.getMultiple());
            qrcodeActivitySkuDTO.setSku(baseScanCodeSku.getSku());
            qrcodeActivitySkuDTO.setProductType(baseScanCodeSku.getProductType().toString());
            scanCodeSkuDTOS.add(qrcodeActivitySkuDTO);
        });
        QrcodeActivitySkuListDTO activitySkuListDTO = new QrcodeActivitySkuListDTO();
        activitySkuListDTO.setTotalSize(totalSize);
        activitySkuListDTO.setRecords(scanCodeSkuDTOS);
        return activitySkuListDTO;
    }

    public static RedemptionActivityForC2ListDTO toRedemptionActivityListForC2DTO(List<Activity> activities) {
        RedemptionActivityForC2ListDTO redemptionActivityForC2ListDTO = new RedemptionActivityForC2ListDTO();
        ArrayList<RedemptionActivityForC2DTO> redemptionActivityForC2List = new ArrayList<>();
        redemptionActivityForC2ListDTO.setTotalSize(activities.size());
        for (Activity activity : activities) {
            RedemptionActivityForC2DTO redemptionActivityForC2DTO = new RedemptionActivityForC2DTO();
            redemptionActivityForC2DTO
                    .activityId(activity.getId())
                    .activityName(activity.getActivityName())
                    .logisticsActivityId(activity.logisticsActivityId())
                    .createdTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getCreatedTime()))
                    .startAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getStartAt()))
                    .endAt(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(activity.getEndAt()))
                    .status(activity.getStatus().name());
            redemptionActivityForC2List.add(redemptionActivityForC2DTO);
        }
        redemptionActivityForC2ListDTO.setRecords(redemptionActivityForC2List);
        return redemptionActivityForC2ListDTO;
    }

    public static List<Activity.ActivityDisplayMsg> toActivityDisplayMsg(List<ActivityDisplayMsgDTO> activityDisplayMsgDTOList) {
        if (CollectionUtils.isEmpty(activityDisplayMsgDTOList)) {
            return Collections.emptyList();
        }
        ParamValidator.validateDuplicateLanguage(activityDisplayMsgDTOList.stream().map(ActivityDisplayMsgDTO::getLanguage).collect(Collectors.toList()));
        return activityDisplayMsgDTOList.stream().map(
                item -> new Activity.ActivityDisplayMsg((ParamValidator.validateLanguage(item.getLanguage().name())), item.getDescription())
        ).collect(Collectors.toList());

    }

    public static List<ActivityDisplayMsgDTO> toDisplayMsgDTO(List<Activity.ActivityDisplayMsg> activityDisplayMsgList) {
        if (CollectionUtils.isEmpty(activityDisplayMsgList)) {
            return Collections.emptyList();
        }
        return activityDisplayMsgList.stream().map(
                item -> {
                    ActivityDisplayMsgDTO displayMsgDTO = new ActivityDisplayMsgDTO();
                    displayMsgDTO.setLanguage(Language.valueOf(item.getLanguage().toString().toUpperCase()));
                    displayMsgDTO.setDescription(item.getDescription());
                    return displayMsgDTO;
                }
        ).collect(Collectors.toList());
    }

}
