package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @description: OralB产品扫码模板，目前没有特殊规则
 * @author: Jevons Chen
 * @date: 2020-06-22 17:35
 */

@Getter
@Setter
public class MlOralbScanCodePlusPointProperties extends RuleProperties {

    private String description = "No Need Properties";

}
