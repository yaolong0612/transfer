package cn.com.pg.loyalty.application.rulev2.redemption;

import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Rule(name = "CheckPointDeductionRule",
        description = "兑换前积分扣除校验", priority = 0)
@Slf4j
@Component
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
public class CheckPointDeductionRule {

    @Autowired
    private InteractionRepositoryV2 interactionRepositoryV2;


    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_PROPERTIES) RedemptionProperties ruleProperties) {
        return ruleProperties.isCheckPointDeducted();
    }


    @Action
    public void executeRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT) Account account,
                            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption) {
        String externalBusinessId = redemption.getExternalBusinessId();
        if (StringUtils.isBlank(externalBusinessId)) {
            throw new SystemException("externalBusinessId not found", ResultCodeMapper.REDEMPTION_NOT_FOUND_RELY_BUSINESS_ID);
        }
        List<Interaction> interactions = interactionRepositoryV2.fetchInteractionsByExternalBusinessId(account.loyaltyId(), externalBusinessId);
        if (CollectionUtils.isEmpty(interactions)) {
            throw new SystemException("没有找到相关抽奖活动记录！", ResultCodeMapper.REDEMPTION_NOT_FOUND_RELY_INTERACTION);
        }
    }

}
