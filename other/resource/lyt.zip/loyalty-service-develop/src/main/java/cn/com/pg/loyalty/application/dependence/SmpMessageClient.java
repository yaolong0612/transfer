package cn.com.pg.loyalty.application.dependence;


import lombok.Getter;
import lombok.Setter;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@FeignClient(name = "smpClient", url = "${smp.url}")
public interface SmpMessageClient {

    /**
     * 获取token接口
     *
     * @param requestEntity
     * @return
     */
    @RequestMapping(value = "/api/authenticate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "SmpMessageClient-generateToken", type = KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    CallSmpResponse generateToken(SmpMessageClient.TokenRequestEntity requestEntity);

    /**
     * smp line通知接口
     *
     * @param requestEntity
     * @return
     */
    @RequestMapping(value = "/smpmessagemicro/api/pmps/sendMessage", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    @KpiLog(name = "SmpMessageClient-sendMessage", type = KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    CallSmpResponse sendMessage(SmpMessageClient.SendMessageRequestEntity requestEntity, @RequestHeader("Authorization") String token);


    @Getter
    @Setter
    class CallSmpResponse {
        private String id_token;
        private String code;
        private String errorMessage;
    }

    @Getter
    @Setter
    class TokenRequestEntity {
        private boolean rememberMe;
        private String username;
        private String password;
    }

    @Getter
    @Setter
    class SendMessageRequestEntity {
        private String companyCode;
        private List<String> contents;
        private String lineId;
    }
}
