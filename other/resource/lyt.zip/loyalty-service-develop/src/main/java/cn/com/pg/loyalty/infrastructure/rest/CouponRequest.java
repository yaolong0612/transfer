package cn.com.pg.loyalty.infrastructure.rest;

import cn.com.pg.loyalty.domain.activity.Coupon;
import cn.com.pg.loyalty.domain.activity.CouponGateway;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.infrastructure.rest.CouponConfig.CouponTemplate;
import cn.com.pg.loyalty.infrastructure.rest.CouponRequestClient.CancelEntity;
import cn.com.pg.loyalty.infrastructure.rest.CouponRequestClient.InstanceEntity;
import cn.com.pg.loyalty.infrastructure.rest.CouponRequestClient.RedemptionEntity;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * @author lvyanlin
 * @date 2022/6/7 13:31
 */
@Slf4j
@Service
public class CouponRequest implements CouponGateway {

    @Autowired
    private CouponRequestClient couponRequestClient;
    @Autowired
    private CouponConfig couponConfig;

    @Override
    public Coupon instanceCoupon(String memberId, String brand) {
        CouponTemplate template = getCouponTemplate(brand);

        InstanceEntity entity = new InstanceEntity(memberId, template.getCouponTemplateId(), template.getPlatformName());
        try {
            CouponRequestClient.ResultDTO instance = couponRequestClient.instanceCoupon(entity);
            return new Coupon(instance.getCode(), instance.getStartTime(), instance.getEndTime());

        } catch (FeignException e) {
            log.info("call instance coupon error：{},\n content:{},", e.getMessage(), new String(e.content() == null ? "没有内容".getBytes(StandardCharsets.UTF_8) : e.content(), StandardCharsets.UTF_8));
            throw new SystemException("生成券码失败", ResultCodeMapper.CALL_COUPON_ERROR);
        }
    }

    @Override
    public boolean cancelCoupon(String memberId, String brand, String code) {
        CouponTemplate template = getCouponTemplate(brand);
        CancelEntity entity = new CancelEntity(template.getCouponTemplateId(), code,
                template.getPlatformName(), false, memberId);
        try {
            CouponRequestClient.ResultDTO cancel = couponRequestClient.cancelCoupon(entity);
            return StringUtils.isEmpty(cancel.getErrorCode()) && !StringUtils.isEmpty(cancel.getCode());
        } catch (Exception e) {
            log.warn("call instance coupon error", e);
            throw new SystemException("取消券码失败", ResultCodeMapper.CALL_COUPON_ERROR);
        }
    }

    @Override
    public boolean redemptionCoupon(String memberId, String brand, String code) {
        CouponTemplate template = getCouponTemplate(brand);
        String verificationTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        RedemptionEntity entity = new RedemptionEntity(template.getCouponTemplateId(), code,
                template.getPlatformName(), verificationTime, memberId);
        try {
            CouponRequestClient.ResultDTO cancel = couponRequestClient.redemptionCoupon(entity);
            return StringUtils.isEmpty(cancel.getErrorCode()) && !StringUtils.isEmpty(cancel.getCode());
        } catch (Exception e) {
            log.info("redemption error:{}", e.getMessage());
            throw new SystemException("核销券码失败", ResultCodeMapper.CALL_COUPON_ERROR);
        }
    }

    private CouponTemplate getCouponTemplate(String brand) {
        CouponTemplate template = couponConfig.getBrandTemplate().get(brand);
        if (Objects.isNull(template)) {
            throw new SystemException("activity config error", ResultCodeMapper.UNEXPECTED_ERROR);
        }
        return template;
    }

}
