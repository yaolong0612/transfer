package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.transaction.Transaction;

/**
 * @author: Ysnow
 * @Date: 2019/5/15 10:24
 * @Description:
 */
public class AccountTransactionResult {
    private Account account;
    private Transaction transaction;
    private GiftCoupon giftCoupon;

    public AccountTransactionResult() {
    }

    public AccountTransactionResult(Account account, Transaction transaction) {
        this.account = account;
        this.transaction = transaction;
    }

    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
    }


    public GiftCoupon getGiftCoupon() {
        return giftCoupon;
    }

    public void setGiftCoupon(GiftCoupon giftCoupon) {
        this.giftCoupon = giftCoupon;
    }

}
