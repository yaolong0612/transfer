package cn.com.pg.loyalty.application.dependence;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author xingliangzhan
 * @date 2019/8/5
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface KpiLog {
    /**
     * logger name
     * @return String
     */
    String name() default "";

    /**
     * kpi type
     * @return KpiType
     */
    KpiType type() default KpiType.KPI;

    /**
     * 超过超时时间才会发送，否则不会发送，默认-1，全部发送
     * 单位 毫秒
     * @return
     */
    long timeout() default -1L;

    /**
     * 只有失败的数据才会log，默认false，所有的数据都会log
     * @return
     */
    boolean onlyFailure() default false;


    enum KpiType {
        /**
         * Azure service bus send
         */
        SEND_SERVICE_BUS,
        /**
         * Azure service bus consume
         */
        CONSUME_SERVICE_BUS,
        /**
         * Azure storage
         */
        STORAGE,
        /**
         * KPI
         */
        KPI,
        /**
         * 调用第三方接口
         */
        API_CALL,
        /**
         * 数据库
         */
        SQL,
        /**
         * redis
         */
        REDIS,
        /**
         * 系统处理API请求
         */
        API_REQUEST,
        /**
         * elasticsearch
         */
        ES
    }
}
