package cn.com.pg.loyalty.interfaces.web;

import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.web.*;
import org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.stereotype.Controller;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * @author Simon
 * <p>
 * 自定义错误数据响应渲染
 */
@Controller
@Slf4j
public class SystemErrorController extends BasicErrorController {

    /**
     * 并非从浏览器请求API，eg：Postman
     */
    private static final String ERROR_METHOD = "error";

    /**
     * 从浏览器中请求API
     */
    private static final String ERROR_HTML_METHOD = "errorHtml";

    public SystemErrorController(ServerProperties serverProperties) {
      super(new DefaultErrorAttributes(), serverProperties.getError());
    }

    @Override
    protected Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
        Map<String, Object> errorAttributes = super.getErrorAttributes(request, includeStackTrace);
        refineErrorAttribute(errorAttributes);
        return errorAttributes;
    }

    public static void refineErrorAttribute(Map<String, Object> errorAttributes){
        Object path = errorAttributes.get("path");
        Object exception = errorAttributes.get("exception");
        Object message = errorAttributes.get("message");
        StringBuilder sb = new StringBuilder();
        RequestContext currentContext = RequestContext.getCurrentContext();
        sb.append(path).append(", ").append(exception).append(", ").append(message);
        log.error("Error Controller: {}", sb);
        errorAttributes.clear();
        String newMessage = "Micro Service: Unexpected Error";
        if (message != null) {
            newMessage = "Micro Service Error: " + message;
        }
        errorAttributes.put("code", ResultCodeMapper.UNEXPECTED_ERROR.getCode());
        errorAttributes.put("message", newMessage);
        errorAttributes.put("correlationId", currentContext != null ? currentContext.getCorrelationId() : "");
    }

}
