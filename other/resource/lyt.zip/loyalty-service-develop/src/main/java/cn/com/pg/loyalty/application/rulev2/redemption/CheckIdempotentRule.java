package cn.com.pg.loyalty.application.rulev2.redemption;


import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Slf4j
@Rule(name = "幂等规则",
        description = "幂等校验", priority = 0)
@Register(scope = RuleScope.BEFORE_LIMIT_RULE, ruleType = RuleType.REDEMPTION)
@Component
public class CheckIdempotentRule {

    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption) {
        return !StringUtils.isBlank(redemption.externalBusinessId());
    }

    @Action
    public void executeRule(
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_REDEMPTION) Redemption redemption,
            @Fact(RuleParamNameConfig.RULE_PARAM_REDEMPTION_RECORDS) List<Redemption> redemptionRecords) {
        boolean existRedemption = redemptionRecords.stream()
                .map(Redemption::externalBusinessId)
                .filter(Objects::nonNull)
                .anyMatch(redemption::matchExternalBusinessId);
        if (existRedemption) {
            throw new SystemException("Repeat request!", ResultCodeMapper.REQUEST_REPEAT);
        }
    }
}
