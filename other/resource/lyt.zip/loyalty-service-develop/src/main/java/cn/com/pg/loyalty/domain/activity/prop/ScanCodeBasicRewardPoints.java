package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @author: Ysnow
 * @Date: 2019/5/30 14:08
 * @Description:扫码加积分的基础奖励积分
 */
@Getter
@Setter
public class ScanCodeBasicRewardPoints {
    /**
     * 扫码物品类的sku
     */
    @NotNull
    private String sku;

    /**
     * 这个物品类的扫码的基本分数
     */
    @Min(0)
    private int point;

    /**
     * 扫码加积分的倍数
     */
    @Min(0)
    private int mulriple;

    /**
     * 描述
     */
    private String description;

    public ScanCodeBasicRewardPoints() {
        sku = "";
    }

    public ScanCodeBasicRewardPoints(String sku, int point, int mulriple, String description) {
        this.sku = sku;
        this.point = point;
        this.mulriple = mulriple;
        this.description = description;
    }
}
