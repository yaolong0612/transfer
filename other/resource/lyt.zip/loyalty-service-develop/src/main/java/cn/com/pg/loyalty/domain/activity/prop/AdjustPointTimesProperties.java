package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.ObjectUtils;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

/**
 * @author cooltea on 2019/6/21 10:09.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Getter
@Setter
public class AdjustPointTimesProperties extends RuleProperties {

    /**
     * 添加积分限制次数
     * -1没有次数不限制
     */
    @NotNull
    @Min(-1)
    private Integer limit;
    /**
     * 每次添加积分
     */
    @NotNull
    private Integer addPoint = 0;

    /**
     * 是否允许将用户的可用积分字段扣减成负数
     */
    @NotNull
    private Boolean allowNegative;

    /**
     * 积分有效期类型，按月，按天，默认按月
     */
    private PeriodDateType effectiveDateType;

    /**
     *之后版本废弃，当前只做兼容。    
     */
    private int effectiveMonth = 0;

    private int effectiveTime = 0;

    public LocalDateTime expiredTime(LocalDateTime createTime) {
        if (Objects.isNull(effectiveDateType) && this.effectiveMonth <= 0) {
            return null;
        }

        if (Objects.isNull(effectiveDateType)) {
            effectiveDateType = Optional.ofNullable(effectiveDateType).orElse(PeriodDateType.BY_NATURAL_MONTH);
            return effectiveDateType.periodEndDate(createTime, effectiveMonth);
        }

        if (effectiveTime <= 0) {
            return null;
        }

        return effectiveDateType.periodEndDate(createTime, effectiveTime);

    }

    public boolean allowNegative() {
        return Optional.ofNullable(this.allowNegative).orElse(false);
    }

    public Integer addPoint() {
        return Optional.ofNullable(addPoint).orElse(0);
    }
}
