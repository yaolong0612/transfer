package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.application.EventAppService;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.Transaction.PointTypeEnum;
import cn.com.pg.loyalty.interfaces.dto.Event;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

@Service
@Slf4j
public class TransactionRepositoryImplV2 implements TransactionRepositoryV2 {

    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private RedemptionRepository redemptionRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private MessageService messageService;
    @Autowired
    private TransactionJpaRepositoryV2 transactionJpaRepositoryV2;

    @Autowired
    private EventAppService eventAppService;

    @Override
    public void saveRetrievable(Transaction transaction) {
        try {
            eventAppService.publishEvent(transaction.getId(), Event.EventSourceTypeEnum.TRANSACTION, transaction.getTransactionType().name(), transaction.getPartitionKey());
            save(transaction);
        } catch (Exception e) {
            log.info("save transaction error, msg: {}, it will send to service bus", e.getMessage());
            messageService.sendSaveTransactionFailedMessage(transaction);
        }
    }

    @Override
    public void save(Transaction transaction) {
        TransactionType transactionType = Optional.ofNullable(transaction)
                .map(entity -> Optional.ofNullable(entity.getTransactionType())
                        .orElseThrow(() -> new SystemException("Field transactionType is null", ResultCodeMapper.PARAM_ERROR)))
                .orElseThrow(() -> new SystemException("The entities which are going to be saved can not be null", ResultCodeMapper.PARAM_ERROR));
        if (transactionType == TransactionType.ORDER) {
            orderRepository.save((Order) transaction);
        } else if (transactionType == TransactionType.INTERACTION) {
            interactionRepository.save((Interaction) transaction);
        } else {
            redemptionRepository.save((Redemption) transaction);
        }
    }

    @Override
    public List<Transaction> fetchInteractions(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        List<Transaction> transactions = interactionRepository
                .findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndCreatedTimeBetween(pk,
                        loyaltyId, TransactionType.INTERACTION, startAt, endAt);
        return transactions.stream()
                .filter(transaction -> !StringUtils.equalsAny(transaction.getPointType(),
                        Transaction.PointTypeEnum.DATA_MIGRATION.name(),
                        Transaction.PointTypeEnum.SYSTEM_OPERATIONS_POINT.name()))
                .collect(toList());
    }

    @Override
    public List<Transaction> fetchByUnlockTimeAfter(String loyaltyId, LocalDate startAt) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String start = LoyaltyDateTimeUtils.localDateToDataString(startAt);
        return transactionJpaRepositoryV2.findByPartitionKeyAndLoyaltyIdAndUnlockTimeGreaterThan(pk, loyaltyId, start);
    }

    @Override
    public List<Transaction> fetchEarnTransactionsByCreatedTimeSorted(String loyaltyId, LocalDateTime startTime, LocalDateTime endTime) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        String endAt = LoyaltyDateTimeUtils.localDateTimeToString(endTime);
        List<Transaction> transactions = transactionJpaRepositoryV2.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween(pk, loyaltyId, startAt, endAt);
        return transactions.stream()
                .filter(transaction -> StringUtils.equalsAny(transaction.getTransactionType().name(),
                        TransactionType.ORDER.name(), TransactionType.INTERACTION.name()))
                .filter(transaction -> !StringUtils.equals(PointTypeEnum.REDEMPTION_CANCEL.name(), transaction.getPointType()))
                .sorted(Comparator.comparing(Transaction::getCreatedTime))
                .collect(Collectors.toList());
    }

    @Override
    public List<Transaction> fetchPositivePointTransactionByLoyaltyIdAndExpiredTimeGreaterThan(String loyaltyId, LocalDateTime startTime) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        String startAt = LoyaltyDateTimeUtils.localDateTimeToString(startTime);
        List<Transaction> transactions = transactionJpaRepositoryV2.findByPartitionKeyAndLoyaltyIdAndExpiredTimeGreaterThan(pk, loyaltyId, startAt);
        return transactions.stream()
                .filter(transaction -> transaction.point() > 0)
                .filter(transaction -> !StringUtils.equals(TransactionType.REDEMPTION.name(), transaction.getTransactionType().name()))
                .filter(transaction -> !StringUtils.equalsAny(transaction.getPointType(),
                        Transaction.PointTypeEnum.DATA_MIGRATION.name(),
                        Transaction.PointTypeEnum.SYSTEM_OPERATIONS_POINT.name(),
                        "MIGRATION_ORDER"))
                .collect(Collectors.toList());
    }
}
