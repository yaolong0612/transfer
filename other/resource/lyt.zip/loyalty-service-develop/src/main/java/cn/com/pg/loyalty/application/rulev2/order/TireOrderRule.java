package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.TireOrderPropertiesV2;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/7
 */
@Rule(name = "TIRE_ORDER_RULE_V2",
        description = "calculate the point by each purchase")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class TireOrderRule {

    private RuleTemplate ruleTemplate = RuleTemplate.TIRE_ORDER_RULE_V2;

    /**
     * 等级奖励积分规则执行条件：
     * 1、必须查到积分模板是等级奖励的且有订单时间在活动期间内活动数大于0
     * 2、订单实付金额大于0
     *
     * @param activityList
     * @param order
     * @return
     */
    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList, @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order) {
        if (order.getRealTotalAmount() <= 0 || order.getCurrentLevel() == null) {
            //订单金额是0,或者等级不存在，不执行加积分
            log.info("orderId:{}金额是:{} 当前等级信息 {}，不参与积分计算", order.getOrderId(), order.getRealTotalAmount(), JSON.toJSONString(order.getCurrentLevel()));
            return Boolean.FALSE;
        }

        List<Activity> tireRewardActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        if (CollectionUtils.isEmpty(tireRewardActivityList)) {
            //没有订单时间在活动期间内的活动返回false,不执行加积分
            log.info("orderId:{}匹配到的等级奖励积分活动数:{}", order.getOrderId(), tireRewardActivityList.size());
            return Boolean.FALSE;
        }

        //返回true 进行加积分操作
        return Boolean.TRUE;
    }

    /**
     * 按规则内容进行加积分
     *
     * @param order
     * @param activityList
     */
    @Action
    public void addPoint(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                         @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                         @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure structure,
                         @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult
    ) {
        List<Activity> tireRewardActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        Activity tireRewardActivity = tireRewardActivityList.get(0);
        TireOrderPropertiesV2 ruleContent = JSON.parseObject(tireRewardActivity.getRuleProperties(), TireOrderPropertiesV2.class);
        //根据订单产生时会员等级id匹配对应的等级积分奖励配置
        String currentLevel = order.getCurrentLevel();
        Optional<TireOrderPropertiesV2.TireRewardRuleConfig> tireRewardRuleConfigOption = ruleContent.getTireRewardRuleConfigs().stream().filter(item -> item.getTierLimit().equals(currentLevel)).findFirst();

        log.info("orderId:{} 金额是:{},订单发生时会员等级id是{}", order.getOrderId(), order.getRealTotalAmount(), currentLevel);
        if (!tireRewardRuleConfigOption.isPresent()) {
            log.info("orderId:{} 未匹配到相应等级的积分奖励配置  当前会员tire:{}", order.getOrderId(), currentLevel);
            return;
        }
        log.info("orderId:{} 匹配到相应等级的积分奖励配置  当前会员tire:{}", order.getOrderId(), currentLevel);
        //根据等级匹配到配置进行积分计算类型，进而进行计算积分
        TireOrderPropertiesV2.TireRewardRuleConfig config = tireRewardRuleConfigOption.get();
        int maxPoint = ruleContent.getMaximumBonusPoints();

        int point = config.getPointCalculateType()
                .calculatePoint(order.exchangeBaseAmount(structure),config.getBasePoint(),
                        maxPoint,config.getBonusPointMultiple());
        PointItem pointItem = new PointItem(point, tireRewardActivity.description(), tireRewardActivity.activityId());
        competePointItems.put(pointItem, ruleContent.isCompetition());
        ruleResult.success();
    }
}
