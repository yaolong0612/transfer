package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Objects;

@Slf4j
public class RollBackOrderRecoverScene {

    private RollBackOrderSelfRecoveryAble selfRecoveryAble;

    private Account account;

    private LoyaltyStructure structure;

    private List<Order> rollbackOrders;

    public RollBackOrderRecoverScene(RollBackOrderSelfRecoveryAble selfRecoveryAble, LoyaltyStructure structure, Account account) {
        this.selfRecoveryAble = selfRecoveryAble;
        this.account = account;
        this.structure = structure;
    }

    public List<Order> getRecoveryOrders() {
        log.info("begin get recoveryOrders loyaltyId:{}",account.loyaltyId());
        return selfRecoveryAble.getBackupRollBackOrders(account.loyaltyId());
    }

    public void backupRollBackOrders(List<Order> orders) {
        this.rollbackOrders = orders;
        selfRecoveryAble.backupRollBackOrders(account.loyaltyId(), rollbackOrders);
    }

    public void backupRollBackAccountGap() {
        int point = rollbackOrders.stream().mapToInt(Order::getPoint).sum();
        String level = account.tier(structure.name()).getLevel();
        int totalPurchaseTimes = account.subAccount(rollbackOrders.get(0).brand()).getTotalPurchaseTimes();
        AccountRollBackGap gap = new AccountRollBackGap(point, level, totalPurchaseTimes);
        selfRecoveryAble.backupRollBackAccountGap(account.loyaltyId(), gap);
    }

    public boolean recoveryAccount(List<Order> recoveryOrders) {
        AccountRollBackGap gap = selfRecoveryAble.getBackupRollBackAccountGap(account.loyaltyId());
        if (Objects.isNull(gap)) {
            return false;
        }
        int accountPurchaseTimes = account.subAccount(recoveryOrders.get(0).brand()).getTotalPurchaseTimes();
        //订单数相同，回滚过程保存Account失败
        if (gap.getTotalPurchaseTimes() == accountPurchaseTimes) {
            return false;
        }
        recoveryOrders.forEach(order -> account.calculatePoint(order, structure));
        account.tier(structure.name()).setLevel(gap.tierLevel);
        return true;
    }


    public void deleteRollBackOrderKeyAndAccountGapKey() {
        log.info("delete rollBackOrderKey And accountGapKey success");
        selfRecoveryAble.removeBackUps(account.loyaltyId());
    }


    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    public static class AccountRollBackGap {
        private int point;
        private String tierLevel;
        private int totalPurchaseTimes;
    }


}
