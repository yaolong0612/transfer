package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.shared.PageableResult;

import java.time.LocalDateTime;
import java.util.Map;

public interface TransactionForEsRepository {

    PageableResult<Redemption> fetchRedemptionListByStoreCode(LocalDateTime startAt, LocalDateTime endAt,
                                                              String storeCode, String brand, Integer page,
                                                              Integer perPage);

    PageableResult<Redemption> fetchRedemptionListByRedeemCode(LocalDateTime startAt, LocalDateTime endAt,
                                                               String redeemCode, String brand,
                                                               RedemptionStatus redemptionStatus,
                                                               Integer page, Integer perPage);
    PageableResult<Redemption> fetchRedemptionList(LocalDateTime startAt, LocalDateTime endAt,
                                                   Map<String, Object> queryParams ,String brand,
                                                   Integer page, Integer perPage);
}
