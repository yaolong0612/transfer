package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.structure.OrderImpact;
import cn.com.pg.loyalty.domain.transaction.Order;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AlterOrderEarliestRollBackTimeFinder implements OrderEarliestRollBackTimeFindAble {
    @Override
    public LocalDateTime findEarliestRollBackTime(OrderImpact orderImpact, List<Order> requestOrders,
                                                  Map<String, Order> associatedOrdersMap) {
        if (!orderImpact.isAlertBackRoll()) {
            return LocalDateTime.MAX;
        }
        List<Order> mapOrders = requestOrders.stream()
                .filter(order -> associatedOrdersMap.containsKey(order.channelUnitOrderId()))
                .filter(order -> order.realTotalAmount()>0)
                .collect(Collectors.toList());
        mapOrders.addAll(associatedOrdersMap.values());
        return mapOrders.stream().min(Comparator.comparing(Order::getOrderDateTime))
                .map(Order::getOrderDateTime).orElse(LocalDateTime.MAX);
    }
}
