package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/8
 */
@Setter
@Getter
public class BasicOrderRulePropertiesV2 extends RuleProperties {
    /**
     * 积分数
     */
    @Min(0)
    protected int basePoint;
    /**
     * 是否固定积分模式
     * 固定积分模式：到账积分=basePoint
     * 非固定模式-倍率模式：到账积分=订单实付金额*bonusPointMultiple<=maximumBonusPoints
     */

    /**
     * 积分计算类型：固定，倍率
     */
    protected PointCalculateType pointCalculateType;


    /**
     * 默认赠送积分上限-与倍率计算模式一起使用
     */
    @Min(0)
    protected int maximumBonusPoints;
    /**
     * 赠送积分倍率
     */
    @Min(0)
    protected double bonusPointMultiple;

    /**
     * 是否与其他加积分竞争：多个活动取值最高分
     * false: 不参与 直接作为相加中一项
     * true: 参与竞争
     */
    protected boolean competition;

    public int calculatePoint(LoyaltyStructure structure, Order order) {
        return pointCalculateType.calculatePoint(order.exchangeBaseAmount(structure), basePoint,
                maximumBonusPoints, bonusPointMultiple);
    }

}
