package cn.com.pg.loyalty.domain.transaction;


import com.microsoft.azure.spring.data.cosmosdb.repository.DocumentDbRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-06-25 10:20
 */

@Repository
public interface OrderRepository extends DocumentDbRepository<Order, String> {

    /**
     * 查询指定用户的历史订单
     * @param partitionKey
     * @param loyaltyId
     * @param brand
     * @param transactionType
     * @param earliestTime
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeGreaterThan(String partitionKey, String loyaltyId, String brand, TransactionType transactionType, String earliestTime);

    /**
     * 根据orderId查找交易记录
     * @param partitionKey
     * @param loyaltyId
     * @param brand
     * @param orderId
     * @param channel
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndBrandAndOrderIdAndChannel(String partitionKey, String loyaltyId, String brand, String orderId, String channel);

    /**
     * 查询某个人的订单记录
     * @param partitionKey
     * @param loyaltyId
     * @param startTime
     * @param endTime
     * @param transactionType
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(String partitionKey, String loyaltyId, String startTime, String endTime, TransactionType transactionType);

    /**
     * 查询某个人在某个时间段的订单记录
     * @param partitionKey
     * @param loyaltyId
     * @param startTime
     * @param endTime
     * @param transactionType
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndOrderDateTimeBetweenAndTransactionType(String partitionKey, String loyaltyId, String startTime, String endTime, TransactionType transactionType);

    /**
     * 查找指定时间某个人的订单记录
     * @param partitionKey
     * @param loyaltyId
     * @param brand
     * @param transactionType
     * @param startTime
     * @param endTime
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(String partitionKey, String loyaltyId, String brand, TransactionType transactionType, String startTime, String endTime);

    /**
     * 查询某个人的兑换记录
     * @param partitionKey
     * @param loyaltyId
     * @param transactionType
     * @return
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndTransactionType(String partitionKey, String loyaltyId, TransactionType transactionType);

    /**
     *查询订单
     */
    List<Order> findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionTypeAndCreatedTimeGreaterThan(String partitionKey, String loyaltyId, String brand, TransactionType transactionType, String startTime);

    @Override
    Order save(Order order);

    boolean existsByPartitionKeyAndChannelAndBrandAndOrderId(String partitionKey, String channel, String brand, String orderId);

    List<Order> findByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(String partitionKey, String loyaltyId, String brand, TransactionType transactionType);


    List<Order> findByPartitionKeyAndLoyaltyIdAndOrderIdIn(String partitionKey, String loyaltyId,List<String> orderIds);

    List<Order> findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId, TransactionType transactionType, String startAt, String endAt);
}
