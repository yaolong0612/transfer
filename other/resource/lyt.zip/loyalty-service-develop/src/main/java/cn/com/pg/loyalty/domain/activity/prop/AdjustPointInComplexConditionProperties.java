package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.prop.shared.DeductPointConditionEnum;
import cn.com.pg.loyalty.domain.activity.prop.shared.PeriodTimesLimit;
import cn.com.pg.loyalty.domain.activity.prop.shared.TierDiscount;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vincenzo
 * @description
 * @date 2022/1/19
 */
@Getter
@Setter
public class AdjustPointInComplexConditionProperties extends RuleProperties {

    /**
     * 是否允许客户端调整
     */

    private Boolean clientAdjust;

    /*
     *客戶端调整类型
     */
    private ClientAdjustType clientAdjustType;

    /**
     * 固定加减积分
     */
    private Integer fixedPoint;

    /**
     * 适配渠道
     */
    private List<String> channels = new ArrayList<>();
    /**
     * 指定积分类型：积分、过渡积分
     */
    private TransactionValueType transactionValueType;
    /**
     * 日期限制注册时间N天内
     */
    private Integer registerTimeLimitDays;

    /**
     * 时间段内次数限制
     */
    private List<PeriodTimesLimit> periodTimesLimitSet;

    /**
     * 扣减类型
     */
    private DeductPointConditionEnum deductPointCondition;


    /**
     * 等级折扣-针对扣减积分情况，如积分抵现
     */
    private List<TierDiscount> tierDiscountConfig;

    public enum TransactionValueType {
        /**
         * 默认情况下的值，pampers代表的是成长值、其他品牌代表的是积分
         */
        DEFAULT {
            @Override
            public void doDecideTransactionValueType(LoyaltyStructure structure,String valueType, Interaction interaction) {
                interaction.updateValueType(structure,ValueType.DEFAULT);
            }

            @Override
            public int fetchAvailablePoint(LoyaltyStructure structure,Account account, String brand, String valueType) {
                return account.subAccount(brand, structure.subAccountType(ValueType.DEFAULT)).getPointAvailable();
            }
        },
        /**
         * pampers品牌代表的是积分
         */
        TRANSIT {
            @Override
            public void doDecideTransactionValueType(LoyaltyStructure structure,String valueType, Interaction interaction) {
                interaction.updateValueType(structure,ValueType.TRANSIT);
            }

            @Override
            public int fetchAvailablePoint(LoyaltyStructure structure,Account account, String brand, String valueType) {
                return account.subAccount(brand, structure.subAccountType(ValueType.TRANSIT)).getPointAvailable();
            }
        },
        /**
         * 客户端传参决定
         */
        CLIENT_DECIDE {
            @Override
            public void doDecideTransactionValueType(LoyaltyStructure structure,String valueType, Interaction interaction) {
                interaction.updateValueType(structure,ValueType.valueOf(valueType));
            }

            @Override
            public int fetchAvailablePoint(LoyaltyStructure structure,Account account, String brand, String valueType) {
                ValueType type = ValueType.valueOf(valueType);
                return account.subAccount(brand, structure.subAccountType(type)).getPointAvailable();
            }
        };

        public abstract void doDecideTransactionValueType(LoyaltyStructure structure,String valueType, Interaction interaction);

        public abstract int fetchAvailablePoint(LoyaltyStructure structure,Account account, String brand, String valueType);
    }

    public enum ClientAdjustType {
        /**
         * 只能扣积分
         */
        DEDUCT {
            @Override
            public Boolean doJudgeClientLegal(Integer clientPoint) {
                if (clientPoint >= 0) {
                    return Boolean.FALSE;
                }
                return Boolean.TRUE;
            }

        },
        /**
         * 只能加积分
         */
        ADD {
            @Override
            public Boolean doJudgeClientLegal(Integer clientPoint) {
                if (clientPoint <= 0) {
                    return Boolean.FALSE;
                }
                return Boolean.TRUE;
            }

        },
        /**
         * 客户端决定加减积分
         */
        CLIENT_DECIDE {
            @Override
            public Boolean doJudgeClientLegal(Integer clientPoint) {
                return Boolean.TRUE;
            }

        };

        public abstract Boolean doJudgeClientLegal(Integer clientPoint);
    }


}
