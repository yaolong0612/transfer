package cn.com.pg.loyalty.application.dto;


import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.OrderItem;
import lombok.*;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-08-11 23:13
 */

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class RefundDTO {
    /**
     * 退单号
     */
    private String orderId;
    /**
     * 渠道
     */
    private String channel;
    /**
     * 品牌
     */
    private String brand;
    /**
     * 退单时间
     */
    private String orderDateTime;
    /**
     * 该笔订单中的详细商品列表
     */
    private List<RefundOrderItemDTO> orderItems = new ArrayList<>();
    /**
     * 退款金额，是推掉的金额，为正数
     */
    private Double refundAmount = 0.0;

    private Double realTotalAmount = 0.0;
    /**
     * 原单orderId
     */
    private String associateTransactionId;
    /**
     * 柜台编号
     */
    private String storeCode;

    public Set<OrderItem> getRefundOrderItems(){
        Set<OrderItem> orderItemSet = new HashSet<>();
        for (RefundOrderItemDTO refundOrderItemDTO : orderItems){
            orderItemSet.add(refundOrderItemDTO.orderItem());
        }
        return orderItemSet;
    }

    public String refundId(){
        return orderId;
    }

    public double refundAmount(){
        return refundAmount;
    }

    public String originalOrderId(){
        return associateTransactionId;
    }

    public LocalDateTime refundDateTime(){
        if (StringUtils.isEmpty(orderDateTime)){
            throw new SystemException("退单队列中的orderDateTime为空", ResultCodeMapper.PARAM_ERROR);
        }
        orderDateTime = orderDateTime.replace(" ", "T");
        if (orderDateTime.contains(".")){
            String[] orderDateTimeStr = orderDateTime.split("\\.");
            orderDateTime = orderDateTimeStr[0];
        }
        if (orderDateTime.length() == 10){
            orderDateTime = orderDateTime.concat("T00:00:00");
        }
        return LoyaltyDateTimeUtils.stringToLocalDateTime(orderDateTime, LoyaltyDateTimeUtils.COMMON_DATE_FORMATER);
    }

    public String channelUnitOrderId() {
        return channel.concat("_").concat(associateTransactionId);
    }
}
