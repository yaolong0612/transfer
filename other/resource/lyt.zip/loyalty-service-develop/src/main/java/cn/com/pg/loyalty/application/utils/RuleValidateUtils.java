package cn.com.pg.loyalty.application.utils;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.transaction.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @description:
 * @author: Artermus wang on 2020-10-10 14:15
 */
@Slf4j
public class RuleValidateUtils {
    public static boolean validateAmountAndTemplate(Order order, List<Activity> activityList, RuleTemplate ruleTemplate) {
        boolean validate = order.realTotalAmount() != 0;
        return validate && validateTemplate(activityList, ruleTemplate);
    }
    public static boolean validateTemplate( List<Activity> activityList, RuleTemplate ruleTemplate) {
        Optional<Activity> first = activityList.stream().filter(atv -> ruleTemplate == atv.ruleTemplate()).findFirst();
        return first.isPresent();
    }

    private RuleValidateUtils() {
    }

}
