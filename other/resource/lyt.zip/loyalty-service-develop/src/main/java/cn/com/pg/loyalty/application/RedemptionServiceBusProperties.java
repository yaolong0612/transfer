package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

/**
 * @author: Ysnow
 * @Date: 2019/6/28 14:36
 * @Description:
 */
@Setter
@Getter
public class RedemptionServiceBusProperties {
    /**
     *  活动Id是公用的
     */
    private String activityId;
    private Boolean isRefund;
    private String redemptionId;
    private String partitionKey;
    private String memberId;
    private String brand;
    private String loyaltyStructure;
    private String type;
    private String storeCode;
    /**
     * 拼接giftNames
     */
    private String giftNames;
    private String redeemCode;
    private String address;
    private String loyaltyId;
    private String storeName;
    private String receiver;
    private String originalStoreCode;
    private String transactionType;
    /**
     * 发送转柜消息
     * @param redemption
     */
    public RedemptionServiceBusProperties(Redemption redemption, String storeName) {

        StringBuilder giftNameBuilder = new StringBuilder();
        this.activityId = redemption.getActivityId();
        this.redemptionId = redemption.getId();
        this.memberId = redemption.getMemberId();
        this.storeCode = redemption.storeCode();
        this.storeName = storeName;
        if (!redemption.getGiftItemList().isEmpty()) {
            redemption.getGiftItemList().stream().forEach(giftItem -> {
                if (GiftItem.GiftStatus.NOT_RECEIVED == giftItem.getGiftStatus()) {
                    giftNameBuilder.append(giftItem.getGiftName().concat("、 "));
                }
            });
        }
        this.giftNames = giftNameBuilder.length() == 0 ? null : giftNameBuilder.substring(0, giftNameBuilder.lastIndexOf("、"));
        this.address = redemption.getAddress();
        this.redeemCode = redemption.getRedeemCode();
        this.loyaltyId = redemption.getLoyaltyId();
        this.receiver = redemption.getReceiver();
    }

    /**
     * 更新库存的属性
     */
    private Map<String,Long> giftIdStockMap;

    public RedemptionServiceBusProperties() {
    }

    /**
     * 这个构造方法是更新库存用的
     * @param activityId
     * @param giftIdStockMap
     */
    public RedemptionServiceBusProperties(String redemptionId, String activityId, Boolean isRefund, Map<String, Long> giftIdStockMap) {
        this.redemptionId = redemptionId;
        this.activityId = activityId;
        this.isRefund = isRefund;
        this.giftIdStockMap = giftIdStockMap;
    }

    /**
     * 这个构造方法是创建兑换订单后，修改这个的历史交互或者订单状态使用
     * @param redemptionId
     * @param partitionKey
     */
    public RedemptionServiceBusProperties(String redemptionId, String partitionKey, String transactionType) {
        this.redemptionId = redemptionId;
        this.partitionKey = partitionKey;
        this.transactionType = transactionType;
    }

    /**
     * 这个构造方法是发货用的
     * @param redemptionId
     * @param partitionKey
     * @param activityId
     * @param memberId
     */
    public RedemptionServiceBusProperties(String redemptionId, String partitionKey, String activityId, String memberId) {
        this.redemptionId = redemptionId;
        this.partitionKey = partitionKey;
        this.activityId = activityId;
        this.memberId = memberId;
    }
    public RedemptionServiceBusProperties type(String status){
        this.type = status;
        return this;
    }

}
