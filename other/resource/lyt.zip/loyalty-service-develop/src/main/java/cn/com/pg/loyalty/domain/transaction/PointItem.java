package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * @author Simon
 * @date 2019/5/27 17:59
 * @description
 **/
@Getter
@Setter
@ToString
@NoArgsConstructor
public class PointItem implements ValueObject<PointItem> {

    /**
     * 积分明细
     */
    private Integer point;

    /**
     * 积分余额
     */
    private String description;

    /**
     * 活动ID
     */
    private String activityId;


    public PointItem(int point, String description, String activityId) {
        this.point = point;
        this.description = description;
        this.activityId = activityId;
    }

    @Override
    public boolean sameValueAs(PointItem other) {
        return this.equals(other);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PointItem pointItem = (PointItem) o;

        return new EqualsBuilder()
                .append(point, pointItem.point)
                .append(description, pointItem.description)
                .append(activityId, pointItem.activityId)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(point)
                .append(description)
                .append(activityId)
                .toHashCode();
    }
}
