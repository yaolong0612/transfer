package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.transaction.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RedemptionRepositoryImplV2 implements RedemptionRepositoryV2 {

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Override
    public List<Redemption> findInActivityNotInRedemptionStatus(Account account, String activityId, List<String> statuses) {
        String pk = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());

        return redemptionRepository.findByPartitionKeyAndLoyaltyIdAndTransactionTypeAndActivityIdAndRedemptionStatusNotIn(
                pk,account.loyaltyId(), TransactionType.REDEMPTION,activityId,statuses
        );
    }
}
