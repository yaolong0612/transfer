package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.interfaces.dto.EnrollAccountCommand;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone;

/**
 * @description: 创建账户
 * @author: linbj
 * @date: 2020-4-16 14:12:23
 */

@Component
@Slf4j
public class AsyncEnrollAccountConsumer extends AbstractConsumer{

    @Autowired
    private AccountService accountService;

    @Override
    public void doBusiness(JSONObject jsonObject) {
        EnrollAccountCommand body = JSON.parseObject(JSON.toJSONString(jsonObject), EnrollAccountCommand.class);
        Account.RegistryEvent registryEvent = Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT;
        if (body.getRegisterType() == EnrollAccountCommand.RegisterTypeEnum.BINDING) {
            registryEvent = Account.RegistryEvent.BINDING_EVENT;
        }
        accountService.register(body.getMemberId(),
                body.getBrand(),
                body.getChannel(),
                body.getBindId(),toLocalDateTimeAtDefaultZone(body.getRegistryTime()),
                body.getRegion(),
                body.getBabyBirthYearAndMonth(), registryEvent);
    }

    @Override
    protected String getLabel() {
        return ServiceBusQueueTopicEnum.ASYNC_ENROLL_ACCOUNT_QUEUE.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return ServiceBusQueueTopicEnum.ASYNC_ENROLL_ACCOUNT_QUEUE;
    }
}
