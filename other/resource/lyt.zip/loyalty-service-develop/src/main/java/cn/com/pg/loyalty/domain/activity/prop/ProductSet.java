package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:57
 */

@Data
public class ProductSet {

    @NotNull
    private String sku;

    @NotNull
    private String productName;
}
