package cn.com.pg.loyalty.application.rule.interaction;

import cn.com.pg.loyalty.application.utils.LimitTimeUtils;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.QrcodeItem;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.MLPampersScanCodeProperties;
import cn.com.pg.loyalty.domain.activity.prop.NumMappingPoint;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.data.redis.core.StringRedisTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author cooltea on 2019/8/16 16:57.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 * 第一次输入产品积分	150
 * 首次拉拉裤积分奖励	150
 * 连续输入产品积分第二个月	150
 * 连续输入产品积分第三个月	200
 * 连续输入产品积分第四个月	250
 * 连续输入产品积分第五个月	300
 * 限制（时间扫码时间往前推）：
 * 每个会员每天最多扫码3次
 * 每个会员每三个月最多扫码10次
 * 每个会员每六个月最多扫码20次
 */
@Rule(name = "Interaction rule: PampersScanCode Rule",
        description = "add point for account scan code")
@Slf4j
public class MlPampersScanCodeRule {
    /**
     * 主要用来防止重复点击签到
     */
    private static String REDIS_KEY_PREFIX = "PAMPERS:SCANCODE:";
    private static long EXPIRE_TIME_SECONDS = 20L;
    private static final DateTimeFormatter fmMonth = DateTimeFormatter.ofPattern("yyyy-MM");

    @Condition
    public boolean isPampersScanCodeRule(@Fact("pointType") PointType pointType) {
        return pointType.ruleTemplate() == RuleTemplate.ML_PAMPERS_INTERACTION_SCAN_CODE;
    }

    @Action
    public void addPoint(@Fact("activities") List<Activity> activities,
                         @Fact("interaction") Interaction interaction,
                         @Fact("ruleResult") RuleResult ruleResult,
                         @Fact("qrCode") String qrCode,
                         @Fact("account") Account account,
                         @Fact("sku") String sku,
                         @Fact("pointType") PointType pointType,
                         @Fact("brand") String brand,
                         @Fact("cacheService") CacheService cacheService,
                         @Fact("stringRedisTemplate") StringRedisTemplate stringRedisTemplate,
                         @Fact("interactionRepository") InteractionRepository interactionRepository,
                         @Fact("loyaltyStructure") LoyaltyStructure loyaltyStructure) {
        Activity activity = activities.get(0);
        try {
            MLPampersScanCodeProperties scanCodeProperties = (MLPampersScanCodeProperties) activity.ruleProperties();
            //如果存在，则设置交互积分的valueType
            Optional.ofNullable(scanCodeProperties.getValueType()).ifPresent(val ->
                    interaction.updateValueType(loyaltyStructure,ValueType.valueOf(val))
            );
            checkParam(activity, qrCode, sku, stringRedisTemplate, brand, cacheService, interaction.valueType(loyaltyStructure));
            Integer fixedPoint = scanCodeProperties.getFixedPoint();
            List<PointItem> pointItems = new ArrayList<>();
            String loyaltyId = account.loyaltyId();
            String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
            List<Interaction> historyInteractions =
                    interactionRepository.findByPartitionKeyAndPointTypeAndLoyaltyIdAndBrand(partitionKey, pointType.pointType(), loyaltyId, BrandV2.PAMPERS);
            log.info("获取到历史记录数：{}", historyInteractions.size());
            //判断扫码次数是否在限制范围内 一日3次 3个月10次 6个月20次,校验扫码限制
            doCheckScanCodeLimit(historyInteractions, qrCode, loyaltyStructure);
            if (fixedPoint != null && fixedPoint > 0) {
                //查询到固定积分参数，直接获取并设置
                pointItems.add(new PointItem(fixedPoint, activity.getDescription(), activity.getId()));
                interaction.scanCode(activity, qrCode, sku, pointType, pointItems);
                ruleResult.success();
                return;
            }
            List<QrcodeItem> qrcodeItems = activity.qrcodeItems();
            Optional<QrcodeItem> isExistsSku = qrcodeItems.stream()
                    .filter(qrcodeItem -> qrcodeItem.equalsThisSku(sku)).findFirst();
            QrcodeItem qrcodeItem = isExistsSku.orElse(null);
            if (qrcodeItem == null) {
                throw new SystemException("Can't find sku of scanning code in the scanning code sku list of activity configuration[" + sku + "]", ResultCodeMapper.ACTIVITY_NOT_FOUND_SCANCODE_SKU);
            }

            LocalDate localDate = LocalDate.now();


            Map<String, Long> historyInteractionsCountByMonthMap = historyInteractions.stream()
                    .filter(interaction1 -> StringUtils.isNotBlank(interaction1.qrCode()))
                    .collect(Collectors.groupingBy(interaction1 -> interaction1.getCreatedTime().toLocalDate().format(fmMonth), Collectors.counting()));
            //本次扫基础积分为(basePoint * multiple)
            int basePoint = (int) Math.ceil(qrcodeItem.getBasePoint() * qrcodeItem.getMultiple());
            pointItems.add(new PointItem(basePoint, activity.getDescription(), activity.getId()));
            //判断是否第一次扫码
            addScanFirstTimePoint(historyInteractions, pointItems, activity, scanCodeProperties);
            //如果是拉拉裤类型判断是否首次扫码拉拉库其pointType独有一个
            addPantsPoint(loyaltyStructure, qrcodeItem, cacheService, historyInteractions, pointItems);
            //连续月扫码赠送积分
            addSeriesMonthPoint(activity, historyInteractionsCountByMonthMap, localDate, scanCodeProperties, pointItems);
            interaction.scanCode(activity, qrCode, sku, pointType, pointItems);
        } catch (SystemException se) {
            ruleResult.addException(se);
            return;
        } catch (Exception e) {
            log.error("未知异常：{}: {}", e.getMessage(), e);
            ruleResult.addException(new SystemException("unknown exception", ResultCodeMapper.UNEXPECTED_ERROR));
            return;
        }
        log.info("完成帮宝适扫码加积分流程：{}", JSON.toJSONString(interaction));
        ruleResult.success();
    }

    private void addScanFirstTimePoint(List<Interaction> historyInteractions, List<PointItem> pointItems, Activity activity, MLPampersScanCodeProperties scanCodeProperties) {
        if (CollectionUtils.isEmpty(historyInteractions)) {
            // 连续月扫码赠送积分
            int extraPoint = scanCodeProperties.seriesMonthPoints().stream()
                    .filter(monthPoint -> monthPoint.thisNumIs(1))
                    .map(NumMappingPoint::pointOrSize)
                    .findAny().orElse(0);
            log.info("首次扫码赠送额外积分: {}", extraPoint);
            pointItems.add(new PointItem(extraPoint, "extra bonus points of the first scanning", activity.getId()));
        }
    }

    private void addSeriesMonthPoint(Activity activity, Map<String, Long> historyInteractionsCountByMonthMap, LocalDate localDate, MLPampersScanCodeProperties scanCodeProperties, List<PointItem> pointItems) {
        // 连续扫码后达到最高分
        int maxPoint = scanCodeProperties.maxPoint();
        // 连续扫码月数
        int seriesMonth = 1;
        // 标记当前月扫码是否已经处理过
        boolean thisMonthExists = false;
        // 当前月
        LocalDate temp = localDate;
        List<String> seriesMonths = historyInteractionsCountByMonthMap.keySet().stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        String strMonth;
        for (int i = 0, count = seriesMonths.size(); i < count; i++) {
            strMonth = seriesMonths.get(i);
            // 当前月是否扫码过
            if (strMonth.equalsIgnoreCase(localDate.format(fmMonth))) {
                thisMonthExists = true;
                break;
            }
            temp = temp.minusMonths(1);
            // 计算连续扫码月数
            if (strMonth.equalsIgnoreCase(temp.format(fmMonth))) {
                seriesMonth++;
                continue;
            }
            break;

        }
        log.info("是否计算过当月:{}, 当前连续扫码月(包含本次扫码): {}", thisMonthExists, seriesMonth);
        final int finalSeriesMonth = seriesMonth;
        if (!thisMonthExists && finalSeriesMonth > 1) {
            // 连续月扫码赠送积分
            int seriesExtraPoint = scanCodeProperties.seriesMonthPoints().stream()
                    .filter(monthPoint -> monthPoint.thisNumIs(finalSeriesMonth))
                    .map(NumMappingPoint::pointOrSize)
                    .findAny().orElse(maxPoint);
            log.info("连续扫码月: {}, 额外加积分: {}", seriesMonth, seriesExtraPoint);
            pointItems.add(new PointItem(seriesExtraPoint, "Scanning code continuously,extra bonus points of" + seriesMonth, activity.getId()));
        }
    }

    private void checkParam(Activity activity, String qrCode, String sku, StringRedisTemplate stringRedisTemplate, String brand, CacheService cacheService, ValueType valueType) {
        if (StringUtils.isBlank(qrCode) || StringUtils.isBlank(sku)) {
            throw new SystemException("Params of scanning code,qrCode:" + qrCode + ",SKU:" + sku, ResultCodeMapper.PARAM_ERROR);
        }
        String key = new StringBuilder(REDIS_KEY_PREFIX).append(brand)
                .append(":").append(qrCode).toString();
        Boolean isExists = stringRedisTemplate.opsForValue().setIfAbsent(key, activity.pointType(), EXPIRE_TIME_SECONDS, TimeUnit.SECONDS);
        if (!isExists) {
            throw new SystemException("Scanning too frequently:" + qrCode + "，retry later please", ResultCodeMapper.SCAN_CODE_TOO_FAST);
        }
        cacheService.checkQrCode(activity.getLoyaltyStructure(), qrCode, valueType);
    }

    private void addPantsPoint(LoyaltyStructure structure, QrcodeItem codeSkus, CacheService cacheService, List<Interaction> interactions, List<PointItem> pointItems) {
        if (codeSkus.productTypeIsThisType(QrcodeItem.ProductTypeEnum.PANTS)) {
            log.info("扫码为拉拉裤(PANTS)类型的qrCode");
            LocalDateTime compareTime = LocalDateTime.now();
            Comparator<Activity> comparator = Comparator.comparing(Activity::getPriority).thenComparing(Activity::getUpdatedTime).reversed();
            List<Activity> allTapeActivities = cacheService.fetchActivitiesByPointTypeAndLoyaltyStruct(Transaction.PointTypeEnum.FIRST_TIME_PANTS_SCANS.name(), structure.name());
            List<Activity> availableTapeActivity = allTapeActivities.stream()
                    .filter(activity -> activity.available(compareTime))
                    .sorted(comparator)
                    .collect(Collectors.toList());
            List<String> activityIds = allTapeActivities.stream().map(Activity::activityId).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(availableTapeActivity)) {
                log.warn("帮宝适扫码加积分活动中pointType: {}, 没有可用的的活动", Transaction.PointTypeEnum.FIRST_TIME_PANTS_SCANS.name());
            }
            // 判断是否包含活动id 是：表示已经加过拉拉库积分
            List<String> historyInteractionIds = interactions.stream().map(Transaction::getPointItems)
                    .flatMap(Collection::stream)
                    .map(PointItem::getActivityId)
                    .collect(Collectors.toList());
            boolean isExists = activityIds.stream().anyMatch(historyInteractionIds::contains);
            log.info("是否第一次扫拉拉库码: {}", !isExists);
            if (!isExists && !CollectionUtils.isEmpty(availableTapeActivity)) {
                int tapePoint = codeSkus.getExtraPoint();
                log.info("第一次扫拉拉裤送额外积分: {}", tapePoint);
                Activity tapeAct = availableTapeActivity.get(0);
                pointItems.add(new PointItem(tapePoint, tapeAct.getDescription(), tapeAct.getId()));
            }
        }
    }

    private void doCheckScanCodeLimit(List<Interaction> historyInteractions, String qrCode,
                                      LoyaltyStructure loyaltyStructure) {
        boolean qrCodeIsUsed =
                historyInteractions.stream().anyMatch(interaction -> qrCode.equalsIgnoreCase(interaction.getQrCode()));
        if (qrCodeIsUsed) {
            throw new SystemException("This QR code" + qrCode + "has already been scanned,scanning repeatedly is not allowed", ResultCodeMapper.SCAN_CODE_SKU_LIMIT_MAX);
        }
        try {
            // 过滤空的qrCode
            historyInteractions = historyInteractions.stream()
                    .filter(interaction -> StringUtils.isNotBlank(interaction.qrCode()))
                    .collect(Collectors.toList());
            List<NumMappingPoint> numMappingPoints = LimitTimeUtils.fetchMlPampersScanLimit();
            Map<Integer, Long> limitSizeMap = LimitTimeUtils.checkLimit(historyInteractions, numMappingPoints);
            Map<Integer, Long> checkVisitMap = numMappingPoints.stream().collect(Collectors.toMap(NumMappingPoint::num, numMappingPoint -> limitSizeMap.get(numMappingPoint.getNum())));
            log.info("历史扫码次数：{}", JSON.toJSONString(checkVisitMap));
        } catch (SystemException e) {
            throw new SystemException("The times of scanning code exceed upper limit", ResultCodeMapper.SCAN_CODE_SKU_LIMIT_MAX);
        }
    }
}
