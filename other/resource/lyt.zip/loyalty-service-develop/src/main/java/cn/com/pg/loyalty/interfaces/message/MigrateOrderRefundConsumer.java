package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * @author cooltea on 2019/7/8 15:23.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Component
@Slf4j
public class MigrateOrderRefundConsumer extends AbstractConsumer {

    private ServiceBusQueueTopicEnum queueTopicEnum = ServiceBusQueueTopicEnum.MIGRATE_ORDER_REFUND_QUEUE_NAME;

    @Autowired
    private TransactionService transactionService;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        String brand = Optional.ofNullable(jsonObject.getString("brand"))
                .orElseThrow(() -> new SystemException("处理迁移订单退单时brand为空", ResultCodeMapper.PARAM_ERROR));
        String loyaltyId = jsonObject.getString("loyaltyId");
        Double refundAmount = jsonObject.getDoubleValue("refundAmount");
        transactionService.migrateOrderRefund(loyaltyId, brand, refundAmount);
        log.info("任务【迁移订单退单队列】处理完成.........");
    }

    @Override
    protected String getLabel() {
        return queueTopicEnum.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return queueTopicEnum;
    }
}
