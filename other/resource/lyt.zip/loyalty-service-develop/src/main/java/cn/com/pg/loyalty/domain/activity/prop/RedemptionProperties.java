package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleLable;
import com.alibaba.fastjson.JSON;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author: Ysnow
 * @Date: 2019/5/10 10:55
 * @Description:
 */
@Data
@NoArgsConstructor
@Slf4j
public class RedemptionProperties extends RuleProperties implements CommonProperties {
    /**
     * 这个活动每个人可以兑换的最大数量
     */
    @Min(0)
    private int totalLimitQuantity;

    /**
     * 是否校验兑换资格
     */
    private boolean checkConvertibility;
    /**
     * 是否直接发货
     */
    private boolean allowDeliverDirectly = true;

    /**
     * 是否检验扣减积分
     */
    private boolean checkPointDeducted = false;

    /**
     * 是否需要扣减礼品库存
     */
    private boolean reductionInventory;

    /**
     * 每个客户单个活动捐赠最高积分数
     */
    @Min(0)
    private int maxConsumePoint;

    /**
     * 每个客户单个活动捐赠最高积分数
     */
    @Min(0)
    private int maxConsumeTransitPoint;

    private boolean allowCancel;

    private int orderLockDay;
    /**
     * 当选择了N号，整个活动的兑换礼品在发生兑换后的下月N号(包括N号)后禁止取消兑换
     * 但允许业务做reject
     */
    private Integer limitCancelDay;


    private List<NumMappingPoint> limitTime = new ArrayList<>();

    /**
     * 增加满足n月m次购买记录的条件才可参加兑换的规则
     */
    private PurchaseLimit purchaseLimit;

    @Valid
    private RedemptionTimesCalculationType redemptionTimesCalculationType;

    private RedemptionLimitType limitType;

    private Map<String, Double> redemptionTierDiscount;

    @NotNull
    private DeliveryChannel deliveryChannel = DeliveryChannel.NONE;

    /**
     * 兑换分组
     */
    @Valid
    private RedemptionGroups redemptionGroups;

    @Valid
    private RedemptionGroupsProperties redemptionGroupsProperties;
    /**
     * 绑定coupon 劵码
     */
    private boolean bindCoupon;
    /**
     * 宝宝生日月控制
     */
    @Valid
    private Scope babyBirthMonthScope;


    /**
     * 按月刷新兑换数量限制
     */
    private boolean refreshReduction = false;


    public List<NumMappingPoint> limitTime() {
        return Optional.ofNullable(this.limitTime).orElse(new ArrayList<>());
    }

    public boolean indirectDelivered() {
        return this.deliveryChannel.sameValueAs(DeliveryChannel.LOGISTICS) && !this.isAllowDeliverDirectly();
    }

    public String purchaseLimitProperties() {
        return Optional.ofNullable(this.purchaseLimit).map(JSON::toJSONString).orElse(null);
    }

    @Override
    public PurchaseLimit fetchPurchaseLimit(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return this.purchaseLimit;
    }

    public String redemptionTimesCalculationTypeProperties() {
        return Optional.ofNullable(this.redemptionTimesCalculationType).map(RedemptionTimesCalculationType::name).orElse(null);
    }

    public String limitTypeProperties() {
        return Optional.ofNullable(this.limitType).map(Enum::name).orElse(null);
    }

    @Override
    public RuleLable fetchLable() {
        return RuleLable.REDMPTION;
    }

    @Override
    public CommonProperties fetchNext() {
        if (this.redemptionGroupsProperties == null) {
            return null;
        }
        if (this.redemptionGroupsProperties.isEmpty()) {
            return null;
        }
        return this.redemptionGroupsProperties;
    }

    @Override
    public boolean fetchMutex(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        if (this.redemptionGroups != null) {
            return this.redemptionGroups.isMutex();
        }
        return false;
    }

    @Override
    public String fetchName(Map<String, RedemptionItem> redemptionItemMap, GiftItem giftItem) {
        return redemptionItemMap.get(giftItem.getGiftId()).getGroupName();
    }

    /**
     * 兑换次数计算方式
     */
    public enum RedemptionTimesCalculationType {
        /**
         * 天数范围差
         */
        BY_DAY {
            @Override
            public LocalDateTime searchStartTime(int interval) {
                return PeriodDateType.BY_DAY.periodStartDate(LocalDateTime.now(), interval);
            }
        },

        BY_NATURE_DAY {
            @Override
            public LocalDateTime searchStartTime(int interval) {
                return PeriodDateType.BY_NATURE_DAY.periodStartDate(LocalDateTime.now(), interval);
            }
        },
        /**
         * 按季度计算
         */
        BY_QUARTER {
            @Override
            public LocalDateTime searchStartTime(int interval) {
                return PeriodDateType.BY_NATURE_QUARTER.periodStartDate(LocalDateTime.now(), interval);
            }
        },
        /**
         * 自然月
         */
        BY_NATURAL_MONTH {
            @Override
            public LocalDateTime searchStartTime(int interval) {
                return PeriodDateType.BY_NATURAL_MONTH.periodStartDate(LocalDateTime.now(), interval);
            }
        },

        /**
         * 自然年
         */
        BY_NATURAL_YEAR {
            @Override
            public LocalDateTime searchStartTime(int interval) {
                return PeriodDateType.BY_NATURAL_YEAR.periodStartDate(LocalDateTime.now(), interval);
            }
        };

        public abstract LocalDateTime searchStartTime(int interval);
    }

    public enum RedemptionLimitType {
        LIMIT_RECORDS_TIMES() {
            @Override
            public void validLimit(List<Redemption> redemptionRecords, LocalDateTime startTime, List<GiftItem> redemptionGifts, int limitRedemptionNum) {
                long hasRedemptionNum = redemptionRecords.stream()
                        .filter(redemption -> redemption.getCreatedTime().isAfter(startTime))
                        .count();
                if (hasRedemptionNum >= limitRedemptionNum) {
                    log.warn("超过次数限制: 限制范围 {} 内，可以兑换{} 次，已兑换 {} 次", startTime, limitRedemptionNum, hasRedemptionNum);
                    throw new SystemException("exceeds the limitation of times", ResultCodeMapper.LIMIT_ERROR);
                }
            }
        },
        LIMIT_GIFT_TIMES() {
            @Override
            public void validLimit(List<Redemption> redemptionRecords, LocalDateTime startTime, List<GiftItem> redemptionGifts, int limitRedemptionNum) {
                Map<String, Integer> giftRecordMap = redemptionRecords.stream()
                        .filter(redemption -> redemption.getCreatedTime().isAfter(startTime))
                        .map(Redemption::getGiftItemList).flatMap(Collection::stream)
                        .filter(GiftItem::effective)
                        .collect(Collectors.groupingBy(GiftItem::getGiftId, Collectors.summingInt(GiftItem::getQuantity)));
                for (GiftItem redemptionGift : redemptionGifts) {
                    int hasRedemptionNum = giftRecordMap.getOrDefault(redemptionGift.getGiftId(), 0);
                    if (hasRedemptionNum + redemptionGift.getQuantity() > limitRedemptionNum) {
                        log.warn("礼包超过次数限制: 限制范围 {} 内，可以兑换{} 个，已兑换 {} 个,本次兑换{}个 ",
                                startTime, limitRedemptionNum, hasRedemptionNum, redemptionGift.getQuantity());
                        throw new SystemException("exceeds the limitation of times", ResultCodeMapper.LIMIT_ERROR);
                    }
                }
            }
        };

        public abstract void validLimit(List<Redemption> redemptionRecords, LocalDateTime startTime,
                                        List<GiftItem> redemptionGifts, int limitRedemptionNum);
    }
}
