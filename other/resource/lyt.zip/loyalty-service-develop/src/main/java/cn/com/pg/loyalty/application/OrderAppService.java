package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.application.dependence.OrderMessage;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.application.dto.RefundDTO;
import cn.com.pg.loyalty.application.dto.RefundOrderItemDTO;
import cn.com.pg.loyalty.application.dto.RequestOrderCommand;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.account.TierRulesCalculateAble;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.domain.transaction.order.OrderAccountCalculator;
import cn.com.pg.loyalty.domain.transaction.order.OrderRollbackService;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import cn.com.pg.loyalty.infrastructure.lock.IdempotentLock;
import cn.com.pg.loyalty.infrastructure.lock.MutexLock;
import cn.com.pg.loyalty.interfaces.assembler.OrderMapper;
import cn.com.pg.loyalty.interfaces.dto.AddOrderCmd;
import cn.com.pg.loyalty.interfaces.dto.OrderItemCmd;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author linbj
 * @date 2020/6/16 14:47
 */
@Service
@Slf4j
public class OrderAppService {

    private static final String KPI_ADD_ORDER_POINT = "ADD_ORDER_POINT";
    private static final String BASE_ORDER_ADD_POINT = Transaction.PointTypeEnum.ORDER_ADD_POINT.name();

    @Autowired
    private MessageService messageService;
    @Autowired
    private AccountService accountService;
    @Autowired
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;
    @Autowired
    private CacheService cacheService;

    @Autowired
    private KpiTemplate kpiTemplate;
    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;
    @Autowired
    private CalculateService calculateServiceImpl;

    @Autowired
    private OrderRecalculateAboutExpiredPointService orderRecalculateAboutExpiredPointService;

    @Autowired
    private TaskService taskService;

    @Autowired
    private TierRulesCalculateAble tierRulesCalculateEngine;

    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private OrderRollbackService orderRollbackService;


    @IdempotentLock(lockKeys = {"'order'", "#body.brand", "#body.memberId", "#body.orderId", "#body.orderType"},
            unlessWithEmpty = "#body.orderId")
    public void sendOrderToServiceBus(AddOrderCmd body) {
        String region = body.getRegion();
        String brand = body.getBrand();
        String memberId = body.getMemberId();
        String channel = body.getChannel();
        String storeCode = body.getStoreCode();
        LocalDateTime orderDateTime = LoyaltyDateTimeUtils.toLocalDateTimeAtDefaultZone(body.getOrderDateTime());
        //正常订单
        if (AddOrderCmd.OrderTypeEnum._010.equals(body.getOrderType())) {
            sendNormalOrderToQueue(body, region, brand, memberId, channel, storeCode, orderDateTime);
            return;
        }
        //退单
        sendRefundOrderToQueue(body, region, brand, memberId, channel, orderDateTime);
    }


    /**
     * 正常订单处理
     */
    @MutexLock(lockKeys = {"#message.brand", "#message.memberId"}, expiredTime = 20)
    public void calculateOrders(RequestOrdersMessage message) {
        message.valid();
        List<RequestOrderCommand> orderCommands = message.getTransactions();
        LoyaltyStructure loyaltyStructure = cacheService.findLoyaltyStructure(message.getRegion(), message.getBrand());
        //校验订单格式
        validRequestOrders(message.getRegion(), message.getBrand(), orderCommands, loyaltyStructure);
        if (message.noRefundOrders()) {
            calculateNormalOrders(loyaltyStructure, message.getMemberId(), OrderMapper.INSTANCE.request2Orders(orderCommands));
            return;
        }
        if (message.allRefundOrders()) {
            calculateRefundOrder(loyaltyStructure, message.getMemberId(), orderCommands);
            return;
        }
        messageService.delayOrdersRequest(message.findNonRefundOrderMessage(), LocalDateTime.now());
        messageService.delayOrdersRequest(message.findRefundOrderMessage(), LocalDateTime.now().minusSeconds(5));
    }


    private void validRequestOrders(String region, String brand, List<RequestOrderCommand> requestCommands, LoyaltyStructure loyaltyStructure) {
        requestCommands.forEach(cmd -> {
            if (StringUtils.isBlank(cmd.getBrand())) {
                cmd.setBrand(brand);
                return;
            }
            if (loyaltyStructure.contain(region, cmd.getBrand())) {
                return;
            }
            throw new SystemException("Order brand error", ResultCodeMapper.PARAM_ERROR);
        });
    }


    /**
     * 退单处理
     */
    private void calculateRefundOrder(LoyaltyStructure loyaltyStructure, String memberId, List<RequestOrderCommand> refundDTOS) {
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);

        //查询获取redis的订单并恢复
        orderRollbackService.checkAndRecoverRollBackScene(loyaltyStructure, account);
        //查找数据库关联订单
        List<String> refundOrderIds = refundDTOS.stream().map(RequestOrderCommand::originalOrderId).distinct().collect(Collectors.toList());
        List<Order> associatedOrders = orderRepositoryV2.findMemberOrdersInOrderIds(account.loyaltyId(), refundOrderIds);
        Map<String, Order> associatedOrderMap = associatedOrders.stream()
                .collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));
        List<Order> refundOrders = doRefundOrders(memberId, refundDTOS, associatedOrderMap);
        addPointV2(loyaltyStructure, account, refundOrders, new ArrayList<>(associatedOrderMap.values()));
    }

    private void calculateNormalOrders(LoyaltyStructure loyaltyStructure, String memberId, List<Order> requestOrders) {
        Account account = accountService.fetchAccountByMemberIdAndCheck(loyaltyStructure, memberId);
        //查询获取redis的订单并恢复
        orderRollbackService.checkAndRecoverRollBackScene(loyaltyStructure, account);
        //获取数据库关联订单
        List<String> requestOrderIds = requestOrders.stream().map(Order::getOrderId).collect(Collectors.toList());
        List<Order> associatedOrders = orderRepositoryV2.findMemberOrdersInOrderIds(account.loyaltyId(), requestOrderIds);
        addPointV2(loyaltyStructure, account, requestOrders, associatedOrders);
    }

    private List<Order> doRefundOrders(String memberId, List<RequestOrderCommand> refundDTOS, Map<String, Order> associatedOrderMap) {
        //排序
        refundDTOS.sort(Comparator.comparing(RequestOrderCommand::getOrderDateTime));
        Map<String, Order> refundOrdersMap = new HashMap<>();
        for (RequestOrderCommand refundDTO : refundDTOS) {
            //校验退单是否合理
            Order mapOrder = associatedOrderMap.get(refundDTO.channelUnitOriginOrderId());
            if (Objects.isNull(mapOrder)) {
                retryRefundOrder(refundDTO.getBrand(), memberId, refundDTO);
            }
            mapOrder = refundOrdersMap.getOrDefault(refundDTO.channelUnitOriginOrderId(), mapOrder);
            if (!mapOrder.canRefund(refundDTO.refundAmount(), refundDTO.adapterRefundOrderDateTime())) {
                log.info("退单号:{}退款金额{}不能大于原订单:{} 剩余实付金额{}", refundDTO.refundId(),
                        refundDTO.refundAmount(), mapOrder.getOrderId(), mapOrder.getRealTotalAmount());
                throw new SystemException("退单错误",ResultCodeMapper.PARAM_ERROR);
            }
            //积分不用在这里退，在计算订单的时候回滚关联订单,要深拷贝，防止把关联订单给退了
            Order refundOrder = OrderMapper.INSTANCE.copyOrder(mapOrder);
            Set<OrderItem> orderItems = OrderMapper.INSTANCE.dto2OrderItems(refundDTO.getOrderItems());

            refundOrder.refund(refundDTO.refundId(), orderItems, refundDTO.refundAmount(),
                    refundDTO.adapterRefundOrderDateTime());
            refundOrdersMap.put(refundOrder.channelUnitOrderId(), refundOrder);
        }
        return new ArrayList<>(refundOrdersMap.values());
    }

    private void retryRefundOrder(String brand, String memberId, RequestOrderCommand refundOrder) {
        String retryKey = cacheService.getKey(CacheService.KeyEnum.REFUND_ORDER, memberId, brand,
                refundOrder.getChannel(), refundOrder.refundId(), "retry");

        Boolean setUp = stringRedisTemplate.opsForValue().setIfAbsent(retryKey, "10", 1L, TimeUnit.DAYS);
        if (Boolean.TRUE.equals(setUp)) {
            throw new SystemException("找不到原始订单", ResultCodeMapper.OPERATION_TOO_FAST);
        }
        Long remainTimes = stringRedisTemplate.opsForValue().increment(retryKey, -1L);
        if (remainTimes != null && remainTimes > 0) {
            throw new SystemException("找不到原始订单", ResultCodeMapper.OPERATION_TOO_FAST);
        }
        log.warn("Refund order not find original:{}", refundOrder.getOrderId());
        throw new SystemException(ResultCodeMapper.ORIGIN_ORDER_NOT_FIND);
    }

    /**
     * 正常订单处理
     */
    private void addPointV2(LoyaltyStructure structure, Account account, List<Order> requestOrders,
                            List<Order> associatedOrders) {
        List<Order> calculateOrders = doAbnormalOrders(structure, account, requestOrders, associatedOrders);

        if (CollectionUtils.isEmpty(calculateOrders)) {
            return;
        }
        Order firstOrder = calculateOrders.get(0);
        String brand = firstOrder.brand();

        //处理olay首单柜
        taskService.handleFirstCounter(account, structure, firstOrder, brand);
        PointType pointType = cacheService.validatePointType(BASE_ORDER_ADD_POINT, structure.name(),
                TransactionType.ORDER);
        calculateOrders.forEach(order -> calculateOrder(structure, account, order, pointType, associatedOrders));

        //计算等级奖励积分
        tierRulesCalculateEngine.calculateAwardPoint(new TierChangeScene(structure, account, false));

        //触发重算即将过期积分重算：订单延迟过期
        orderRecalculateAboutExpiredPointService.triggerRecalculateAboutExpiredPoint(structure, account, requestOrders);

    }

    private List<Order> doAbnormalOrders(LoyaltyStructure structure, Account account, List<Order> requestOrders, List<Order> associatedOrders) {
        OrderAccountCalculator orderAccountCalculator = OrderAccountCalculator.init(structure, account,
                requestOrders, associatedOrders);

        //判断过滤之后是否还有请求订单
        if (CollectionUtils.isEmpty(orderAccountCalculator.getRequestOrders())) {
            return Collections.emptyList();
        }
        //回滚订单
        boolean doRollBack = orderRollbackService.doRollBackOrders(orderAccountCalculator);
        if (doRollBack) {
            return Collections.emptyList();
        }
        //如果不支持改单,回滚关联订单，继承关联订单重算
        orderAccountCalculator.rollBackAssociatedOrdersPoint();
        return orderAccountCalculator.getCalculateOrders();
    }

    private void calculateOrder(LoyaltyStructure structure, Account account, Order order, PointType pointType, List<Order> associatedOrders) {
        //查询有效订单活动
        List<Activity> activityList = cacheService.fetchUniquePointTypeAvailableActivities(TransactionType.ORDER,
                structure.name(), order.getOrderDateTime());
        //重新给订单设置当前等级
        resetOrderCurrentLevel(structure, account, order, associatedOrders);
        //订单加积分
        calculateServiceImpl.calculateOrderPoint(pointType, order, account, structure,
                activityList, 0);

        TierChangeScene tierChangeScene = new TierChangeScene(structure, account, order);
        tierRulesCalculateEngine.calculateTiersRule(tierChangeScene);
        batchUpdateDBComponentImpl.saveTransactionAndAccount(order, account);
        messageService.sendMessage4PointPool(new PoolMessage(structure, order, account));

        log.info("MemberId:{},OrderId:{}订单积分流程结束", account.getMemberId(), order.getOrderId());
        kpiTemplate.sendKpi(account.memberId(), order.point(), order.brand(), KPI_ADD_ORDER_POINT, order.channel(), pointType, null);

    }

    private void resetOrderCurrentLevel(LoyaltyStructure structure, Account account, Order order, List<Order> associatedOrders) {
        if (CollectionUtils.isEmpty(associatedOrders)) {
            order.setCurrentLevel(account.tier(structure.name()).getLevel());
            return;
        }
        //退单的时候，订单的当前等级跟关联订单保持一致
        Map<String, Order> associatedOrdersMap = associatedOrders.stream().collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));
        order.setCurrentLevel(associatedOrdersMap.get(order.channelUnitOrderId()).getCurrentLevel());
    }

    private void sendNormalOrderToQueue(AddOrderCmd body, String region, String brand, String memberId, String channel, String storeCode, LocalDateTime orderDateTime) {
        Set<OrderItem> orderItems = new HashSet<>();
        for (OrderItemCmd orderItemCmd : body.getOrderItems()) {
            OrderItem orderItem = OrderItem.getNormalOrderItem(orderItemCmd.getSku(), orderItemCmd.getPurchaseQty(), orderItemCmd.getRetailAmount(), orderItemCmd.getRealAmount());
            orderItems.add(orderItem);
        }
        Double realTotalAmount = orderItems.stream().mapToDouble(OrderItem::getRealAmount).sum();
        Order order = new Order(brand, channel, body.getOrderId(), orderDateTime, realTotalAmount, orderItems, storeCode);
        OrderMessage orderMessage = new OrderMessage(memberId, Collections.singletonList(order), brand, region);
        messageService.sendNormalOrderMessageToQueue(region, brand, orderMessage);
    }

    private void sendRefundOrderToQueue(AddOrderCmd body, String region, String brand, String memberId, String channel, LocalDateTime orderDateTime) {
        if (StringUtils.isEmpty(body.getOriginOrderId())) {
            throw new SystemException("originOrderId is empty", ResultCodeMapper.PARAM_ERROR);
        }
        List<RefundOrderItemDTO> refundOrderItemDTOS = new ArrayList<>();
        for (OrderItemCmd orderItemCmd : body.getOrderItems()) {
            RefundOrderItemDTO orderItemDTO = RefundOrderItemDTO.getRefundOrderItemDTO(orderItemCmd.getSku(), orderItemCmd.getPurchaseQty(), orderItemCmd.getRetailAmount(), orderItemCmd.getRealAmount());
            refundOrderItemDTOS.add(orderItemDTO);
        }
        Double realTotalAmount = refundOrderItemDTOS.stream().mapToDouble(RefundOrderItemDTO::getRefundAmount).sum();
        RefundDTO refundDTO = new RefundDTO(body.getOrderId(), channel, brand, orderDateTime.toString(), refundOrderItemDTOS, realTotalAmount, realTotalAmount, body.getOriginOrderId(), body.getStoreCode());
        messageService.sendRefundOrderMessageToQueue(region, brand, memberId, refundDTO);
    }

}
