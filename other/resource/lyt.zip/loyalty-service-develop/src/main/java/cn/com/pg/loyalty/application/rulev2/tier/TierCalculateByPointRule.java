package cn.com.pg.loyalty.application.rulev2.tier;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator.CountTierScoreAble;
import cn.com.pg.loyalty.domain.account.TierRuleCalculator.FetchCountItemAble;
import cn.com.pg.loyalty.domain.account.TierChangeScene;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.TierCalculateByPointProperties;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionRepositoryV2;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Predicate;


/**
 * @author lmr
 */
@Slf4j
@Component
@Rule(name = "TierCalculateByPointRule",
        description = "根据用户的有效积分计算等级", priority = Integer.MIN_VALUE + 1)
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.TIER)
public class TierCalculateByPointRule {

    private static final RuleTemplate ruleTemplate = RuleTemplate.TIER_CALCULATE_BY_POINT_RULE;

    @Autowired
    private TransactionRepositoryV2 transactionRepository;


    @Condition
    public boolean validateRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                                @Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, LocalDateTime.now(), ruleTemplate);
        if (CollectionUtils.isEmpty(searchedActivityList)) {
            log.info("匹配到的根据积分计算等级活动数为:{}", searchedActivityList.size());
            return Boolean.FALSE;
        }
        TierCalculateByPointProperties tierCalculateByPointProperties = JSON.parseObject(searchedActivityList.get(0).getRuleProperties(), TierCalculateByPointProperties.class);
        tierChangeScene.initRuleCalculatorScene(tierCalculateByPointProperties);
        return tierChangeScene.matchRuleCalculateScene(false);
    }

    @Action
    public void calculateTier(@Fact(RuleParamNameConfig.RULE_PARAM_TIER_CHANGE_SCENE) TierChangeScene tierChangeScene,
                              @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult) {
        Account account = tierChangeScene.getAccount();

        FetchCountItemAble<Transaction> fetchCountItemAble = scope -> transactionRepository.fetchEarnTransactionsByCreatedTimeSorted(
                account.loyaltyId(), scope.getStartAt(), scope.getEndAt());

        Predicate<Transaction> transactionFilterPredicate = transaction -> transaction.point() > 0
                || StringUtils.equals(Transaction.PointTypeEnum.TIER_REWARD_REFUND.name(), transaction.getPointType());

        CountTierScoreAble<Transaction> countTierScoreAble = countItems ->
                countItems.stream().mapToInt(Transaction::point).sum();

        TierRuleCalculator<Transaction> calculator = tierChangeScene.tryBuildRuleCalculator(Transaction.class);
        String level = calculator.calculateLevel(fetchCountItemAble, countTierScoreAble, Transaction::getCreatedTime, transactionFilterPredicate);
        tierChangeScene.addLevelCalculateResult(level, calculator.fetchUpgradeTime());
        ruleResult.success();
        log.info("根据有效积分计算等级结束");
    }
}
