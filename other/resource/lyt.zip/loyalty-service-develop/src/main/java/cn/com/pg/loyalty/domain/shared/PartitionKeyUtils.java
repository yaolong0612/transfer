package cn.com.pg.loyalty.domain.shared;


import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.Map.Entry;

/**
 * @author Young
 * @author cooltea
 * @date 2019年5月8日下午5:23:34
 * @description 一致性Hash，用来计算分散均匀的PartitionKey
 */
public class PartitionKeyUtils {

    public static final String ACTIVITY_PARTITIONKEY = "AP";
    public static final String ACTIVITY_LOG_PARTITIONKEY = "AL";
    public static final String POINT_TYPE_PARTITIONKEY = "PT";
    public static final String GIFT_PARTITIONKEY = "GP";
    public static final String STORE_PARTITIONKEY = "SP";

    /**
     * PartitionKey列表 项目启动时从数据库拉取,需要改成Map形式，标记那个PartitionKey不可用
     */
    private static Map<String, Boolean> ACCOUNT_NODES = new HashMap<>(2000);
    private static Map<String, Boolean> TRANSACTION_NODES = new HashMap<>(2000);

    /**
     * Circle环 -> Key为PartitionKey子节点的Hash值，Value为其子节点的名称，利用java中的红黑树实现TreeMap 实现环
     */
    private static TreeMap<Integer, String> ACCOUNT_HASH_CIRCLE = new TreeMap<>();
    private static TreeMap<Integer, String> TRANSACTION_HASH_CIRCLE = new TreeMap<>();

    private static char[] CHAR_NUM;
    /**
     * 存储partitionKey值 AA AB AC ....zz
     */
    private static String[] ARRAY_KEY = new String[2704];


    static {
        CHAR_NUM = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();
        int index = 0;
        for (int i = 0; i < CHAR_NUM.length; i++) {
            for (int j = 0; j < CHAR_NUM.length; j++) {
                ARRAY_KEY[index++] = CHAR_NUM[i] + "" + CHAR_NUM[j];
            }
        }
    }

    private static int getHash(String str) {
        final int p = 16777619;
        int hash = (int) 2166136261L;
        for (int i = 0; i < str.length(); i++) {
            hash = (hash ^ str.charAt(i)) * p;
        }
        hash += hash << 13;
        hash ^= hash >> 7;
        hash += hash << 3;
        hash ^= hash >> 17;
        hash += hash << 5;
        // 如果值为负数则取其绝对值
        if (hash < 0) {
            hash = Math.abs(hash);
        }
        return hash;
    }

    /**
     * 寻址换上的节点
     *
     * @param loyaltyId
     * @return
     */
    public static String getTransactionPartitionKey(String loyaltyId) {
        if (TRANSACTION_HASH_CIRCLE.isEmpty()) {
            //先初始化为了单元测试
            initTransaction(8, 4);
        }
        // 得到带路由的结点的Hash值
        int hash = getHash(loyaltyId);
        if (!TRANSACTION_HASH_CIRCLE.containsKey(hash)) {
            // 得到大于该Hash值的所有Map
            SortedMap<Integer, String> subMap = TRANSACTION_HASH_CIRCLE.tailMap(hash);
            hash = subMap.isEmpty() ? TRANSACTION_HASH_CIRCLE.firstKey() : subMap.firstKey();
        }
        // 返回对应的PartitionKey
        return TRANSACTION_HASH_CIRCLE.get(hash).split("-")[0];
    }

    /**
     * 寻址换上的节点
     *
     * @param loyaltyId
     * @return
     */
    public static String getAccountPartitionKey(String loyaltyId) {
        if (ACCOUNT_HASH_CIRCLE.isEmpty()) {
            //为了单元测试
            initAccount(8, 4);
        }
        // 得到带路由的结点的Hash值
        int hash = getHash(loyaltyId);
        if (!ACCOUNT_HASH_CIRCLE.containsKey(hash)) {
            // 得到大于该Hash值的所有Map
            SortedMap<Integer, String> subMap = ACCOUNT_HASH_CIRCLE.tailMap(hash);
            hash = subMap.isEmpty() ? ACCOUNT_HASH_CIRCLE.firstKey() : subMap.firstKey();
        }
        // 返回对应的PartitionKey
        return ACCOUNT_HASH_CIRCLE.get(hash).split("-")[0];
    }

    public static void initTransaction(int partitionNum, int virtualNodes) {
        if (partitionNum >= ARRAY_KEY.length) {
            throw new SystemException("init azure cosmosDb partitionKey numbers error max: 2074...", ResultCodeMapper.PARAM_ERROR);
        }
        for (int i = 0; i < partitionNum; i++) {
            TRANSACTION_NODES.put(ARRAY_KEY[i], true);
        }
        Set<Entry<String, Boolean>> entrySet = TRANSACTION_NODES.entrySet();
        for (Entry<String, Boolean> entry : entrySet) {
            for (int i = 1; i <= virtualNodes; i++) {
                generateVirtualNodes(TRANSACTION_HASH_CIRCLE, entry.getKey() + "-" + i);
            }
        }
    }

    public static void initAccount(int partitionNum, int virtualNodes) {
        if (partitionNum >= ARRAY_KEY.length) {
            throw new SystemException("init azure cosmosDb partitionKey numbers error max: 2074...", ResultCodeMapper.PARAM_ERROR);
        }
        for (int i = 0; i < partitionNum; i++) {
            ACCOUNT_NODES.put(ARRAY_KEY[i], true);
        }
        Set<Entry<String, Boolean>> entrySet = ACCOUNT_NODES.entrySet();
        for (Entry<String, Boolean> entry : entrySet) {
            for (int i = 1; i <= virtualNodes; i++) {
                generateVirtualNodes(ACCOUNT_HASH_CIRCLE, entry.getKey() + "-" + i);
            }
        }
    }

    private static void generateVirtualNodes(TreeMap<Integer, String> hashCircle, String nodeName) {
        generateVirtualNodes(hashCircle, nodeName, null);
    }

    private static void generateVirtualNodes(TreeMap<Integer, String> hashCircle, String nodeName, Integer hash) {
        hash = hash != null ? getHash(hash.toString()) : getHash(nodeName);
        if (StringUtils.isBlank(hashCircle.get(hash))) {
            hashCircle.put(hash, nodeName);
        } else {
            // hash碰撞,重hash
            generateVirtualNodes(hashCircle, nodeName, hash);
        }
    }

    private PartitionKeyUtils() {
    }
}

