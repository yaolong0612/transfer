package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;

import java.util.List;

public interface AccountRepositoryV2 {

    void saveRetrievable(Account account);

    void save(Account account);

    List<Account> findAccounts(LoyaltyStructure structure, List<String> memberIds);

}
