package cn.com.pg.loyalty.domain.transaction;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
public class PointValueObject {
    /**
     * 存放负积分信息
     */
    private Map<LocalDate, PointValue> negativePointObjects = new HashMap<>();
    /**
     * 存放正积分信息
     */
    private Map<LocalDate, PointValue> positivePointObjects = new HashMap<>();
    /**
     * 存放过期记录与活动ID映射
     */
    private Map<Interaction, String> expiredRecords = new HashMap<>();
    /**
     * 用于存储处理完成的积分记录
     */
    HashMap<LocalDate, PointValue> processedTransactions = new HashMap<>();

    public void addExpiredRecord(@NotNull Interaction interaction){
        this.expiredRecords.put(interaction, interaction.activityId);
    }

    public void addExpiredRecords(@NotNull List<Interaction> expiredRecords){
        expiredRecords.forEach(this::addExpiredRecord);
    }

    @Data
    public static class PointValue {
        /**
         * 当天的积分
         */
        private int point;
        /**
         * 是否存在订单
         */
        private boolean existOrder;
        /**
         * 是否已经过期
         */
        private boolean expired;
        /**
         * 活动id
         */
        private String activityId;
        /**
         * 品牌
         */
        private String brand;
        /**
         * 分区键
         */
        private String partitionKey;
        /**
         * 积分的日期
         */
        private LocalDate date;

        public PointValue(){
            this.point = 0;
            this.existOrder = false;
            this.expired = false;
        }

        public PointValue(String partitionKey, String brand){
            this.point = 0;
            this.existOrder = false;
            this.expired = false;
            this.partitionKey = partitionKey;
            this.brand = brand;
        }

        public void increasePoint(int point){
            this.point += Math.abs(point);
        }

        public void addOrderType(){
            this.existOrder = true;
        }

        public void decreasePoint(Integer availablePoint) {
            this.point -= Math.abs(availablePoint);
        }

        public boolean existOrder() {
            return this.existOrder;
        }

        public int point() {
            return this.point;
        }

        public void expire(){
            this.expired = true;
        }

        public boolean expired(){
            return this.expired;
        }

        public void addActivityId(String activityId){
            this.activityId = activityId;
        }

        public String activityId(){
            return this.activityId;
        }

        public void addBrand(String brand){
            this.brand = brand;
        }

        public String brand(){
            return this.brand;
        }

        public void addPartitionKey(String partitionKey){
            this.partitionKey = partitionKey;
        }

        public String partitionKey(){
            return this.partitionKey;
        }

        public void addDate(LocalDate date){
            this.date = date;
        }

        public LocalDate date(){
            return this.date;
        }
    }
}
