package cn.com.pg.loyalty.infrastructure.elasticsearch;

import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.RedemptionStatus;
import cn.com.pg.loyalty.domain.transaction.TransactionForEsRepository;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Repository
public class TransactionForEsRepositoryImpl implements TransactionForEsRepository {

    private static final String INDEX_SUFFIX = "transaction-query";
    public static final String TRANSACTION_TYPE = "transactionType";
    public static final String CREATED_TIME = "createdTime";

    @Autowired
    private EsTemplate esTemplate;

    private String buildTransactionIndex(String brand) {
        return brand.toLowerCase()+ "-" + INDEX_SUFFIX;
    }

    @Override
    @KpiLog(name = "ESClient-fetchRedemptionListByRedeemCode", type = KpiLog.KpiType.ES, onlyFailure = true, timeout
            = 50)
    public PageableResult<Redemption> fetchRedemptionListByRedeemCode(LocalDateTime startAt, LocalDateTime endAt,
                                                                      String redeemCode, String brand,
                                                                      RedemptionStatus redemptionStatus, Integer page
            , Integer perPage) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("redeemCode", redeemCode);
        queryParams.put(TRANSACTION_TYPE, TransactionType.REDEMPTION);
        queryParams.put("redemptionStatus", redemptionStatus);
        BoolQueryBuilder boolQueryBuilder = esTemplate.buildBoolQueryBuilder(queryParams);
        boolQueryBuilder.must(esTemplate.buildRangeQueryBuilder(CREATED_TIME, startAt, endAt));
        return esTemplate.pageQuery(buildTransactionIndex(brand), boolQueryBuilder, page,
                perPage,
                Redemption.class);
    }


    @Override
    @KpiLog(name = "ESClient-fetchRedemptionList", type = KpiLog.KpiType.ES, onlyFailure = true, timeout =
            50)
    public PageableResult<Redemption> fetchRedemptionList(LocalDateTime startAt, LocalDateTime endAt,
                                                          Map<String, Object> queryParams,String brand,
                                                          Integer page, Integer perPage) {

        queryParams.put(TRANSACTION_TYPE, TransactionType.REDEMPTION);
        BoolQueryBuilder boolQueryBuilder = esTemplate.buildBoolQueryBuilder(queryParams);
        boolQueryBuilder.must(esTemplate.buildRangeQueryBuilder(CREATED_TIME, startAt, endAt));
        return esTemplate.pageQuery(buildTransactionIndex(brand), boolQueryBuilder, page, perPage,
                Redemption.class);
    }


    @Override
    @KpiLog(name = "ESClient-fetchRedemptionListByStoreCode", type = KpiLog.KpiType.ES, onlyFailure = true, timeout =
            50)
    public PageableResult<Redemption> fetchRedemptionListByStoreCode(LocalDateTime startAt, LocalDateTime endAt,
                                                                     String storeCode, String brand, Integer page,
                                                                     Integer perPage) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("storeCode", storeCode);
        queryParams.put(TRANSACTION_TYPE, TransactionType.REDEMPTION);
        BoolQueryBuilder boolQueryBuilder = esTemplate.buildBoolQueryBuilder(queryParams);
        boolQueryBuilder.must(esTemplate.buildRangeQueryBuilder(CREATED_TIME, startAt, endAt));
        return esTemplate.pageQuery(buildTransactionIndex(brand), boolQueryBuilder, page, perPage,
                Redemption.class);
    }
}
