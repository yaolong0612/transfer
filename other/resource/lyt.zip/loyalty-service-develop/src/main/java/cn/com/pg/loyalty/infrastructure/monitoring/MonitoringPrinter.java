package cn.com.pg.loyalty.infrastructure.monitoring;

import cn.com.pg.loyalty.LoyaltyApplication;
import cn.com.pg.loyalty.application.dependence.KpiLog;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import com.alibaba.fastjson.JSON;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @author Simon
 */
@Getter
@Setter
@Component
@Slf4j
public class MonitoringPrinter {
    /**
     * 如果Azure KPI Template为空，则只打印日志。证明是大陆环境
     */
    private static AzureKpiTemplate azureKpiTemplate;

    @Autowired(required = false)
    public void setAzureKpiTemplate(AzureKpiTemplate azureKpiTemplate) {
        MonitoringPrinter.azureKpiTemplate = azureKpiTemplate;
    }

    /**
     * 监控API请求，是从外部请求进来的监控
     *
     * @param errorCode
     * @param errorMsg
     */
    public static void printAPIRequest(int errorCode, String errorMsg) {
        MonitoringMetric monitoringMetric = new MonitoringMetric(errorCode, errorMsg,
                KpiLog.KpiType.API_REQUEST);
        print(monitoringMetric);
        if (azureKpiTemplate == null) {
            //Pass 环境的，会自己拦截, 不用监控
            return;
        }
        azureKpiTemplate.sendRequest(RequestContext.getCurrentContext().getPath(),
                RequestContext.getCurrentContext().getRequestMethod(),
                monitoringMetric.operationName, monitoringMetric.startDateTime, monitoringMetric.responseTime,
                monitoringMetric.errorCode, monitoringMetric.errorMsg, monitoringMetric.correlationId);
    }

    private static void print(MonitoringMetric monitoringMetric) {
        String json = JSON.toJSONString(monitoringMetric);
        log.info(json);
    }

    @Getter
    @Setter
    private static class MonitoringMetric {
        private String appName = LoyaltyApplication.APP_NAME;
        private String operationName;
        private LocalDateTime startDateTime;
        private int errorCode;
        private long responseTime;
        private String errorMsg;
        private String correlationId;
        private KpiLog.KpiType kpiType;
        private String messageId;

        public MonitoringMetric(int errorCode, String errorMsg, KpiLog.KpiType kpiType) {
            this.operationName = RequestContext.getCurrentContext().getOperationName();
            if (this.operationName == null) {
                this.operationName = RequestContext.getCurrentContext().getPath();
            }
            this.startDateTime = RequestContext.getCurrentContext().getStartDateTime();
            this.errorCode = errorCode;
            this.responseTime = RequestContext.getCurrentContext().costTime();
            this.errorMsg = errorMsg;
            this.correlationId = RequestContext.getCurrentContext().getCorrelationId();
            this.kpiType = kpiType;
            this.messageId = RequestContext.getCurrentContext().getMessageId();
        }
    }

}
