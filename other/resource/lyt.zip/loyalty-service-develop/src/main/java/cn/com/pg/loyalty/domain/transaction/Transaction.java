package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.Id;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


/**
 * @author Young
 * @date 2019年4月11日上午11:14:45
 * @description Loyalty中的Transaction
 */
@Getter
@Setter
@ToString
@Document(collection = "Transaction", ru = "400")
@NoArgsConstructor
public class Transaction implements Entity<Transaction> {

    private static final String SYSTEM_OPERATIONS_DESCRIPTION = "内部系统结算积分";
    private static final String SYSTEM_OPERATIONS_ACTIVITY_ID = "SYSTEM_OPERATIONS_ACTIVITY_ID";
    /**
     * 全局唯一
     */
    @Id
    protected String id;
    /**
     * 积分id
     */
    protected String loyaltyId;
    /**
     * 会员系统用户ID：AM，Janrain
     */
    private String memberId;
    /**
     * 通过构造方法或Set方法将Brand转为String,该字段也可用来筛选
     * 指定品牌下的订单
     */
    protected String brand;

    /**
     * PartitionKey
     */
    @PartitionKey
    protected String partitionKey;
    /**
     * Transaction渠道
     */
    protected String channel;
    /**
     * Transaction类型，该字段会配合 brandName进行数据筛选
     */
    protected TransactionType transactionType;
    /**
     * 该笔Transaction对应的积分变动可为负
     */
    protected Integer point;
    /**
     * 该Transaction在积分系统中的生成时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime createdTime;
    /**
     * 更新时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime updatedTime;
    /**
     * 可用积分，如果时积分过期了，不标志为0
     */
    protected Integer availablePoint;

    /**
     * 交易状态
     */
    private TransactionStatus transactionStatus;
    /**
     * 积分到期日
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    protected LocalDateTime expiredTime;

    /**
     * 积分描述，是给消费者查看的，从Activity description 中得到
     */
    protected String description;

    /**
     * 与积分描述一一对应
     */
    protected String pointType;

    /**
     * 活动ID, 如果有多个activity，就以point item为准，本字段可以为空。只有Redemption会用到
     */
    protected String activityId;

    /**
     * 交互积分解锁的日期
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    protected LocalDate unlockTime;

    public ValueType valueType(LoyaltyStructure structure) {
        if (valueType != null) {
            return valueType;
        }
        if (structure.isOpenExtraSubAccount()) {
            return ValueType.TRANSIT;
        }
        return ValueType.DEFAULT;
    }


    public ValueType valueTypeDefault() {
        return this.valueType;
    }

    /**
     * 区别是积分还是成长值,不给默认值，为了避免获取pampers历史数据时赋给默认default
     */
    protected ValueType valueType;

    /**
     * 该笔订单计算之前的Level
     */
    private String currentLevel;

    protected List<PointItem> pointItems = new ArrayList<>();

    public String brand() {
        return this.brand;
    }

    public Integer availablePoint() {
        return this.availablePoint;
    }

    public int point() {
        return point;
    }

    public String channel() {
        return channel;
    }


    @Override
    public boolean sameIdentityAs(Transaction other) {
        return this.id.equals(other.getId());
    }


    public Transaction(String loyaltyId, String brand, String channel, TransactionType transactionType,
                       LoyaltyStructure loyaltyStructure, String memberId) {
        this.loyaltyId = loyaltyId;
        this.point = 0;
        this.availablePoint = 0;
        this.partitionKey = PartitionKeyUtils.getTransactionPartitionKey(this.loyaltyId);
        this.brand = brand;
        this.channel = channel;
        this.id = UUIDUtil.generator();
        this.transactionType = transactionType;
        this.transactionStatus = TransactionStatus.ACTIVATE;
        this.memberId = memberId;
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        if (loyaltyStructure.isOpenExtraSubAccount()) {
            this.valueType = ValueType.DEFAULT;
        }

    }

    public void bindAccount(LoyaltyStructure structure, Account account) {
        if (!StringUtils.equals(account.memberId(), getMemberId())) {
            throw new SystemException(ResultCodeMapper.UNEXPECTED_ERROR);
        }
        if (!structure.contain(account.region(), brand)) {
            throw new SystemException(ResultCodeMapper.UNEXPECTED_ERROR);
        }
        this.loyaltyId = account.loyaltyId();
        this.partitionKey = PartitionKeyUtils.getTransactionPartitionKey(this.loyaltyId);
        this.id = UUIDUtil.generator();
        this.transactionStatus = TransactionStatus.ACTIVATE;
        if (structure.isOpenExtraSubAccount()) {
            this.valueType = ValueType.DEFAULT;
        }
        this.unlockTime = structure.getUnlockTime(this);


    }

    /**
     * 该构造函数只能给系统结算积分使用
     *
     * @param loyaltyId
     * @param brand
     * @param channel
     * @param transactionType
     * @param loyaltyStructure
     * @param memberId
     * @param transactionStatus
     * @param createTime
     * @param availablePoint
     */
    public Transaction(String loyaltyId, String brand, String channel, TransactionType transactionType,
                       LoyaltyStructure loyaltyStructure, String memberId, TransactionStatus transactionStatus, LocalDateTime createTime, Integer availablePoint) {
        this(loyaltyId, brand, channel, transactionType, loyaltyStructure, memberId);
        this.transactionStatus = transactionStatus;
        this.createdTime = createTime;
        this.availablePoint = availablePoint;
        this.description = SYSTEM_OPERATIONS_DESCRIPTION;
        this.pointType = PointTypeEnum.SYSTEM_OPERATIONS_POINT.name();
        this.activityId = SYSTEM_OPERATIONS_ACTIVITY_ID;
    }


    /**
     * 该构造函数只能给用户借取积分使用
     *
     * @param loyaltyId
     * @param brand
     * @param channel
     * @param transactionType
     * @param loyaltyStructure
     * @param memberId
     * @param transactionStatus
     */
    public Transaction(String loyaltyId, String brand, String channel, TransactionType transactionType,
                       LoyaltyStructure loyaltyStructure, String memberId, TransactionStatus transactionStatus) {
        this(loyaltyId, brand, channel, transactionType, loyaltyStructure, memberId);
        this.transactionStatus = transactionStatus;
        this.description = SYSTEM_OPERATIONS_DESCRIPTION;
        this.pointType = PointTypeEnum.SYSTEM_OPERATIONS_POINT.name();
        this.activityId = SYSTEM_OPERATIONS_ACTIVITY_ID;
    }

    /**
     * 创建兑换订单使用, 其它类型不要使用
     *
     * @param brand
     * @param channel
     */
    public Transaction(String brand, String channel, String memberId) {
        this.id = UUIDUtil.generator();
        this.brand = brand;
        this.channel = channel;
        this.createdTime = LocalDateTime.now();
        this.updatedTime = LocalDateTime.now();
        this.availablePoint = 0;
        this.point = 0;
        this.transactionStatus = TransactionStatus.ACTIVATE;
        this.memberId = memberId;
    }


    /**
     * 计算扣去可用积分，大于0表示不够扣，返回还剩下不够扣积分
     *
     * @param costPoint
     * @return int
     */
    public int reduceAvailablePoint(int costPoint) {
        int point = this.availablePoint;
        if (this.availablePoint < costPoint) {
            this.availablePoint = 0;
        } else {
            this.availablePoint = this.availablePoint - costPoint;
        }
        this.updatedTime = LocalDateTime.now();
        this.transactionStatus = TransactionStatus.USED;
        return costPoint - point;
    }

    public void reduceAvailablePointNegative(int pointCost) {
        this.availablePoint = this.availablePoint - pointCost;
        this.updatedTime = LocalDateTime.now();
        this.transactionStatus = TransactionStatus.USED;
    }

    public void addPoint(PointItem pointItem) {
        this.updatedTime = LocalDateTime.now();
        this.point += pointItem.getPoint();
        this.availablePoint += pointItem.getPoint();
        this.pointItems.add(pointItem);
    }

    /**
     * 积分是否过期
     *
     * @return
     */
    public boolean judgeExpired() {
        if (transactionType != TransactionType.INTERACTION && transactionType != TransactionType.ORDER) {
            return false;
        }
        if (transactionStatus == TransactionStatus.EXPIRED) {
            return true;
        }

        return availablePoint > 0 && LocalDateTime.now().isAfter(expiredTime);
    }

    public LocalDate expiredDate(){
        return this.expiredTime.toLocalDate();
    }

    /**
     * 设置积分过期
     */
    public int expire() {
        transactionStatus = TransactionStatus.EXPIRED;
        updatedTime = LocalDateTime.now();
        return availablePoint;
    }

    public String description() {
        return description;
    }

    public boolean redemptionType() {
        return this.transactionType == TransactionType.REDEMPTION;
    }

    public boolean statusActivateOrUsed() {
        return (this.transactionStatus == TransactionStatus.USED ||
                this.transactionStatus == TransactionStatus.ACTIVATE ||
                this.transactionStatus == TransactionStatus.MIGRATION ||
                this.transactionStatus == TransactionStatus.BORROW ||
                this.transactionStatus == TransactionStatus.SETTLEMENT);
    }

    public boolean statusAvailableOrExpire() {
        return (this.transactionStatus != TransactionStatus.LOCK &&
                this.transactionStatus != TransactionStatus.DELAY);
    }

    public void updateInfo(String loyaltyId, String memberId, String partitionKey) {
        this.loyaltyId = loyaltyId;
        this.memberId = memberId;
        this.partitionKey = partitionKey;
    }

    public void cleanPoint() {
        this.point = 0;
        this.availablePoint = 0;
    }


    /**
     * 固定的积分类型，由于代码中有些积分类型需要特殊处理，所以需要定义常量。但是实际的point type应该都要存在于数据库中
     * 描述，id以数据库配置为准
     */
    public enum PointTypeEnum {
        INTERACTION("交互积分", TransactionType.INTERACTION),
        PURCHASE("购物积分", TransactionType.ORDER),
        REDEMPTION("积分兑换", TransactionType.REDEMPTION),
        SCAN_CODE("扫码积分", TransactionType.INTERACTION),
        SCAN_CODE_TRANSIT("扫码加过渡积分", TransactionType.INTERACTION),
        REGISTER("注册积分", TransactionType.INTERACTION),
        BIND("绑定积分", TransactionType.INTERACTION),
        SIGN_IN("签到积分", TransactionType.INTERACTION),
        SIGN_IN_TMALL("天猫签到积分", TransactionType.INTERACTION),
        SHOPPING("购物积分", TransactionType.INTERACTION),
        BOOKMARK("收藏店铺积分", TransactionType.INTERACTION),
        BABY_BIRTHDAY_MONTH_12("1岁宝宝生日月积分", TransactionType.INTERACTION),
        BABY_BIRTHDAY_MONTH_24("2岁宝宝生日月积分", TransactionType.INTERACTION),
        BABY_BIRTHDAY_MONTH_3("3个月宝宝生日月积分", TransactionType.INTERACTION),
        ORDER_ADD_POINT("订单加积分", TransactionType.ORDER),
        BASE_POINT_ORDER_ADD_POINT("基础订单加积分", TransactionType.ORDER),
        MEMBERS_DAY_ORDER_ADD_POINT("会员日订单加积分", TransactionType.ORDER),
        BIRTHMONTH_ORDER_ADD_POINT("生日月订单加积分", TransactionType.ORDER),
        ONLINE_HOLIDAY_ORDER_ADD_POINT("线上节假日订单加积分", TransactionType.ORDER),
        MULTIPLE_GRADE_POINT("多档多倍积分", TransactionType.ORDER),
        NEW_PRODUCT_ORDER_ADD_POINT("新品订单加积分", TransactionType.ORDER),
        SINGLE_PRODUCT_ORDER_ADD_POINT("单品订单加积分", TransactionType.ORDER),
        SECOND_PURCHASE_ORDER_ADD_POINT("二次购买订单加积分", TransactionType.ORDER),
        TIER_ORDER_ADD_POINT("等级规则订单加积分", TransactionType.ORDER),
        BIRTHDAY_MONTH_ORDER_ADD_POINT("生日月双倍订单加积分", TransactionType.ORDER),
        EXTRA_ORDER_POINT("特定情况额外订单积分", TransactionType.ORDER),
        /**
         * 只用作内部扣减记录时,不需要展示给消费者
         */
        SYSTEM_OPERATIONS_POINT("系统积分计算", TransactionType.INTERACTION),
        /**
         * 取消兑换返还积分
         */
        REDEMPTION_CANCEL("取消兑换返还积分", TransactionType.INTERACTION),
        HOTLINE_REDEMPTION("热线兑换", TransactionType.REDEMPTION),
        FIRST_TIME_PANTS_SCANS("首次拉拉裤扫码奖励", TransactionType.INTERACTION),
        /**
         * 数据迁移使用，这个类型的积分用来数据迁移标记，不需要展示给消费者
         */
        DATA_MIGRATION("数据迁移积分", TransactionType.INTERACTION),
        /**
         * 历史迁移积分
         */
        ORDER_POINT_MIGRATION("The bonus points of purchase", TransactionType.ORDER),
        SYSTEM_EXPIRED_POINT("过期积分", TransactionType.INTERACTION),
        ORDER_OPT_OUT("OPT OUT ORDER", TransactionType.ORDER),
        ORDER_ADD_POINT_WITH_LIMIT("订单限制加积分", TransactionType.ORDER),
        ORDER_PASTED("PASTED ORDER", TransactionType.ORDER),
        TIER_REWARD("等级奖励积分", "00abe86c4cbf4dd78e412d54e0969abe",TransactionType.ORDER),
        TIER_REWARD_REFUND("等级奖励积分回退", "00abe86c4cbf4dd78e412d54e0969abd",TransactionType.ORDER);


        private TransactionType transactionType;
        private String activityId;
        private String remark;

        PointTypeEnum(String remark, TransactionType transactionType) {
            this.remark = remark;
            this.transactionType = transactionType;
        }

        PointTypeEnum(String remark,String activityId,TransactionType transactionType) {
            this.transactionType = transactionType;
            this.remark = remark;
            this.activityId = activityId;
        }

        public String remark() {
            return this.remark;
        }

        public String activityId() {
            return this.activityId;
        }

    }

    public String partitionKey() {
        if (StringUtils.isNotBlank(this.partitionKey)) {
            return this.partitionKey;
        }
        if (StringUtils.isBlank(this.loyaltyId)) {
            throw new SystemException("loyaltyId is Null", ResultCodeMapper.ACCOUNT_NOT_FOUND);
        }
        return PartitionKeyUtils.getTransactionPartitionKey(this.loyaltyId);
    }

    public void updateValueType(LoyaltyStructure structure, ValueType valueType) {
        this.valueType = valueType;
        this.unlockTime = structure.getUnlockTime(this);
    }

    /**
     * 积分交易的状态
     */
    public enum TransactionStatus {
        /**
         * 锁定
         */
        LOCK,
        /**
         * 激活
         */
        ACTIVATE,
        /**
         * 使用
         */
        USED,
        /**
         * 过期,这个状态今后不用，用过期的时间判断，若当前时间晚于过期时间则属于过期
         */
        @Deprecated
        EXPIRED,
        /**
         * 积分延期
         */
        DELAY,
        /**
         * 用户借用，判断是否展示给消费者时，用POINT TYPE：SYSTEM_OPERATIONS_POINT
         */
        BORROW,
        /**
         * 系统结算，判断是否展示给消费者时，用Point TYPE: SYSTEM_OPERATIONS_POINT
         */
        SETTLEMENT,
        /**
         * 数据迁移状态，不展示给前端，不应该使用这个来判断，应该使用POINT TYPE：DATA_MIGRATION 来判断是否给消费者显示
         */
        MIGRATION;
    }

    public boolean visibleIsNot() {
        if (TransactionStatus.MIGRATION == this.transactionStatus ||
                TransactionStatus.BORROW == this.transactionStatus ||
                TransactionStatus.SETTLEMENT == this.transactionStatus) {
            return false;
        }
        if (PointTypeEnum.DATA_MIGRATION.name().equals(this.pointType) ||
                PointTypeEnum.SYSTEM_OPERATIONS_POINT.name().equals(this.pointType)) {
            return false;
        }
        return true;
    }

    public static Comparator<Transaction> comparatorByTransactionCreatedTimeDesc() {
        return (o1, o2) -> o2.createdTime.compareTo(o1.createdTime);
    }
}
