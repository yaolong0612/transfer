package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

/**
 * @author cooltea on 2019/6/21 10:15.
 * @version 1.0
 * @email cooltea007@163.com
 * 这个类是一个默认的参数配置类，里面不需要任何的属性。为了转换JSON不报错，必须要这个类
 */

@Getter
@Setter
public class DefaultProperties extends RuleProperties {
    private String description = "No Need Properties";

}
