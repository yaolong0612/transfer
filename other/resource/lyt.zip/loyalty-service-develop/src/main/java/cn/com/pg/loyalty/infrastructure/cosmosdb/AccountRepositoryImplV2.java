package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.application.utils.RetryTemplate;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepositoryV2;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class AccountRepositoryImplV2 implements AccountRepositoryV2 {
    @Autowired
    AccountJpaRepositoryV2 accountJpaRepositoryV2;
    @Autowired
    private MessageService messageService;

    @Override
    public void saveRetrievable(Account entity) {
        try {
            RetryTemplate.retry(() -> accountJpaRepositoryV2.save(entity), 3);
            log.info("保存Transaction数据成功");
        } catch (Exception e) {
            log.info("save transaction error, msg: {}, it will send to service bus", e.getMessage());
            messageService.sendSaveAccountFailedMessage(entity);
        }
    }

    @Override
    public void save(Account account) {
        accountJpaRepositoryV2.save(account);
    }

    @Override
    public List<Account> findAccounts(LoyaltyStructure structure, List<String> memberIds) {
        return accountJpaRepositoryV2.findByMarketingProgramIdAndMemberIdIn(structure.marketingProgramId(),memberIds);
    }
}
