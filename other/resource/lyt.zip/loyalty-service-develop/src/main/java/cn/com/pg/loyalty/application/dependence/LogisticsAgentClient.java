package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.LoyaltyApplication;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * @author Simon
 * @date 2019/6/6
 * @description Feign Client For Logistics
 */
// url = "https://qa-zuul-b2c.cn-xnp-cloud-pg.com.cn/api/cms-logistic-agent"
@FeignClient(name = "cms-logistic-agent")
public interface LogisticsAgentClient {

    /**
     * 创建物流订单
     * @param command
     * @return
     */

    @KpiLog(name = "LogisticsAgentClient-createOrder", type= KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    @RequestMapping(path = "/order/create", method = RequestMethod.POST)
    Response create(@RequestBody CreateOrderCommand command);

    @KpiLog(name = "LogisticsAgentClient-createDingtaiOrder", type= KpiLog.KpiType.API_CALL, onlyFailure = true, timeout = 50)
    @RequestMapping(path = "/order/generate", method = RequestMethod.POST)
    Response generate(@RequestBody CreateOrderCommand command);

    @Getter
    @Setter
    @ToString
    class Response {
        private String resultCode;
        private String errorMsg;
        private CreateOrderDTO object;
    }

    @Getter
    @Setter
    @ToString
    class CreateOrderDTO {
        private String apiName;
        private String deliveryId;
    }

    @Getter
    @Setter
    @ToString
    class CreateOrderCommand {
        //经销商 DINGTAI/ other
        private String distributor;
        private String source;
        private String transactionId;
        private boolean ignoreDuplicate;
        private String brand;
        private String memberId;
        private String activityCode;
        private List<Product> products;
        private String addressCode;
        private TenantId tenantId;
        private String name;
        private String mobile;
        private String province;
        private String city;
        private String district;
        private String address;
        private String postcode;
        private String remark;

        public void createOrder(String transactionId, boolean ignoreDuplicate, String brand, String memberId, String activityCode, List<Product> products, String name, String mobile, String province, String city, String district, String address) {
            this.source = LoyaltyApplication.APP_NAME;
            this.transactionId = transactionId;
            this.ignoreDuplicate = ignoreDuplicate;
            this.brand = brand;
            this.memberId = memberId;
            this.activityCode = activityCode;
            this.products = products;
            this.name = name;
            this.mobile = mobile;
            this.province = province;
            this.city = city;
            this.district = district;
            this.address = address;
        }
    }

    @Getter
    @Setter
    @ToString
    class Product {
        private String productId;
        private Integer num;
        //定泰需要，暂未确认是否必要
        private String imageUrl;

        public void createProduct(String productId, Integer num) {
            this.productId = productId;
            this.num = num;
        }
    }
    @AllArgsConstructor
    @Getter
    @ToString
    class TenantId {
        private final String id;
    }
}
