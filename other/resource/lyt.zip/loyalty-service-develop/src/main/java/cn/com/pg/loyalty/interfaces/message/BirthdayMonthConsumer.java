package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.InteractionProperties;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BirthdayMonthConsumer extends AbstractConsumer {

    @Autowired
    private TransactionService transactionService;

    private static final ServiceBusQueueTopicEnum QUEUE_NAME = ServiceBusQueueTopicEnum.BIRTHDAY_POINT;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        JSONArray messages = (JSONArray) jsonObject.get("body");
        for (Object object : messages) {
            JSONObject message = (JSONObject) JSON.toJSON(object);
            InteractionProperties interactionProperties = JSON.toJavaObject(message, InteractionProperties.class);
            verifyParams(interactionProperties);
            transactionService.addInteractionPoint(interactionProperties.brand(), interactionProperties.region(),
                    interactionProperties.channel(), interactionProperties.memberId(), interactionProperties.pointType(),
                    interactionProperties.qrCode(), interactionProperties.sku(), interactionProperties.newMember(),
                    interactionProperties.point(), interactionProperties.reason(), interactionProperties.token(), null);
        }
    }

    public void verifyParams(InteractionProperties interactionProperties) {
        if (interactionProperties.brand() == null) {
            throw new SystemException("brand is required", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
        if (interactionProperties.region() == null) {
            throw new SystemException("region is required", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
        if (interactionProperties.channel() == null) {
            throw new SystemException("channel is required", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
        if (StringUtils.isEmpty(interactionProperties.memberId())) {
            throw new SystemException("memberId is required", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
        if (StringUtils.isEmpty(interactionProperties.pointType())) {
            throw new SystemException("pointType is required", ResultCodeMapper.MESSAGE_PARAM_ERROR);
        }
    }

    @Override
    protected String getLabel() {
        return QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return QUEUE_NAME;
    }
}
