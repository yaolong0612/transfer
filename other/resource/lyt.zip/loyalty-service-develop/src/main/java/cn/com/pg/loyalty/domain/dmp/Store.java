package cn.com.pg.loyalty.domain.dmp;

import cn.com.pg.loyalty.domain.shared.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import com.microsoft.azure.spring.data.cosmosdb.core.mapping.PartitionKey;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-07-27 16:54
 */
@Getter
@Setter
@Document(collection = "Store", ru = "400")
@NoArgsConstructor
@ToString
public class Store implements Entity<Store> {

    public final static String TMALL_OLAY = "E-PG-OLAY-TB-CT001";
    public final static String JD_OLAY = "E-PG-OLAY-JD-CT001";
    /**
     * 发运到家,柜转虚拟柜
     */
    public final static String SHIPMENT_ARRIVED_HOME = "V-PG-OLAY-DI-CT002";

    /**
     * 热线到家虚拟柜
     */
    public final static String HOT_LINE_ARRIVED_HOME = "V-PG-OLAY-DI-HL888";
    /**
     * olay 美丽柜 表示E
     */
    private static String OLAY_TYPE_E = "E";
    /**
     * 关柜
     */
    private static String STORE_STATUS_CLOSE = "Close";
    /**
     * storeAddress=""
     */
    private static String STORE_ADDRESS_EMPTY = "";

    /**
     * 唯一Store Code
     */
    @Id
    private String id;
    @PartitionKey
    private String partitionKey = PartitionKeyUtils.STORE_PARTITIONKEY;
    private String storeName;
    private String storeAddress;
    private String storeStatus;
    private String storeType;
    /**
     * OLAY柜台的类型
     */
    private String olayType;
    private String province;
    private String city;
    /**
     * 柜台的状态：InUse
     */
    private String counterStatus;
    private String brand;
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    @Override
    public boolean sameIdentityAs(Store other) {
        return other != null && this.id.equals(other.id);
    }

    /**
     * 匹配线下DS/ORC/TMALL/JD/虚拟柜（不含发运到家）
     * @return
     */
    public LoyaltyStoreTypeEnum storeType() {
        if (null == this.storeType){
            return LoyaltyStoreTypeEnum.TEMPORARY;
        }
        if (this.storeType.equalsIgnoreCase(LoyaltyStoreTypeEnum.DS.name())){
            return LoyaltyStoreTypeEnum.DS;
        } else if (this.storeType.equalsIgnoreCase(LoyaltyStoreTypeEnum.ESTORE.name())){
            if (TMALL_OLAY.equalsIgnoreCase(this.id)){
                return LoyaltyStoreTypeEnum.TMALL;
            } else if (JD_OLAY.equalsIgnoreCase(this.id)){
                return LoyaltyStoreTypeEnum.JD;
            } else if (SHIPMENT_ARRIVED_HOME.equalsIgnoreCase(this.id)){
                return LoyaltyStoreTypeEnum.OTHERS;
            } else {
                //排除非TMALL/JD/发运到家
                return LoyaltyStoreTypeEnum.VIRTUAL;
            }
        } else {
            //排除DS/ESTORE
            return LoyaltyStoreTypeEnum.ORC;
        }
    }

    public boolean olayTypeIsE() {
        return OLAY_TYPE_E.equalsIgnoreCase(this.olayType);
    }

    public boolean storeStatusIsClose() {
        return STORE_STATUS_CLOSE.equalsIgnoreCase(this.storeStatus);
    }

    public boolean storeAddressIsEmpty() {
        return STORE_ADDRESS_EMPTY.equals(this.storeAddress);
    }

    public void checkAvailable() {
        if (olayTypeIsE()) {
            throw new SystemException("Beauty counter is unavailable", ResultCodeMapper.PARAM_ERROR);
        }
        if (storeStatusIsClose()) {
            throw new SystemException("Counter" + id + "is closed", ResultCodeMapper.PARAM_ERROR);
        }
    }

    public enum LoyaltyStoreTypeEnum {
        /**
         * 线下JD
         */
        JD,
        /**
         * 线下TMALL
         */
        TMALL,
        /**
         * 百货商店
         */
        DS,
        /**
         * 商业超市
         */
        ORC,
        /**
         * 临时柜
         */
        TEMPORARY,
        /**
         * 虚拟柜
         */
        VIRTUAL,
        /**
         *
         */
        ESTORE,
        /**
         * 其他
         */
        OTHERS;
    }

    public enum StoreCodeEnum{
        /**
         * 天猫生活家官方旗舰店
         */
        LA_OFFICIAL("2"),
        /**
         * 天猫aussie旗舰店
         */
        TMALL_AUSSIE("2017019"),
        /**
         * 天猫 HAIRRECIPE官方旗舰店
         */
        TMALL_HAIR_RECIPE("2017021"),
        /**
         * 天猫佳洁士官方旗舰店
         */
        TMALL_CREST("2017022"),
        /**
         * 天猫舒隐官方旗舰店
         */
        TMALL_ALWAYS_DISCREET("2017024"),
        /**
         * 天猫生活家海外旗舰店
         */
        LA_ABROAD("29999999021"),
        /**
         * 天猫吉列官方旗舰店
         */
        GILLETTE("29999999008"),
        /**
         * 天猫沙宣官方旗舰店
         */
        LA_VS("29999999010"),
        /**
         * 天猫博朗官方旗舰店
         */
        BRAUN("30000000249"),
        /**
         * 天猫欧乐B官方旗舰店
         */
        ORALB("30000016463"),
        /**
         * HERBAL_ESSENCES Tmall He店铺
         */
        FS_STORE("2017026"),
        /**
         * LA Tmall Snowberry店铺
         */
        FS_STORE_SNOW_BERRY("2017027"),
        /**
         * fab店铺
         */
        FAB_STORE("2017031");

        StoreCodeEnum(String storeCode){
            this.storeCode = storeCode;
        }

        private String storeCode;

        public static StoreCodeEnum getInstanceByStoreCode(String storeCode){
            for (StoreCodeEnum instance : StoreCodeEnum.values()){
                if (instance.storeCode.equals(storeCode)){
                    return instance;
                }
            }
            return null;
        }
    }
}
