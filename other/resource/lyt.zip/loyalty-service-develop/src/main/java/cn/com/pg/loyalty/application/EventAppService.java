package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dto.GiftItemDto;
import cn.com.pg.loyalty.application.dto.GiftPackageDto;
import cn.com.pg.loyalty.application.dto.RedemptionDto;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftItem;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.interfaces.dto.Event;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/9
 */

/**
 * 用于处理兑换等实体在保存前发消息
 * 监听数据库是否正常保存
 * 推送监听的事件消息到相应的topic
 */
@Service
@Slf4j
public class EventAppService {

    @Autowired
    private RedemptionRepository redemptionRepository;

    @Autowired
    private MessageService messageService;

    @Autowired
    private CacheService cacheService;

    private static final String BRAND_SKII = "SKII";
    /**
     * 延时秒数
     */
    private static final int DELAY_SECONDS = 5;


    public void publishEvent(String sourceId, Event.EventSourceTypeEnum eventSourceType, String sourceType, String sourcePartitionKey) {
        Event event = generateEvent(sourceId, eventSourceType, sourceType, sourcePartitionKey);
        //设置消息延迟处理 延迟10s
        LocalDateTime delayTime = LocalDateTime.now().plusSeconds(DELAY_SECONDS);
        messageService.sendDelayEventMsg(event, delayTime);


    }

    private Event generateEvent(String sourceId, Event.EventSourceTypeEnum eventSourceType, String sourceType, String sourcePartitionKey) {
        Event event = new Event();
        event.setSourceId(sourceId);
        event.setSourceType(sourceType);
        event.setEventSourceType(eventSourceType);
        event.setSourcePartitionKey(sourcePartitionKey);
        return event;
    }

    /**
     * 接收event消息
     * 后续可能需要改造 可以兼容account 等的逻辑
     *
     * @param event
     */
    public void processEvent(Event event) {
        log.info("处理event消息：{}", JSON.toJSONString(event));
        Map<String, Object> propertiesMap = new HashMap<>(5);
        JSONObject messageBody = null;
        //目前理论上只有兑换的transaction在用
        if (event.getEventSourceType() == Event.EventSourceTypeEnum.TRANSACTION) {
            messageBody = resolveTransactionEvent(event, propertiesMap);
        }
        //发送消息给topic
        Optional.ofNullable(messageBody).ifPresent(message ->
                messageService.sendMsgToTransactionEventTopic(message, propertiesMap));

    }

    /**
     * 转换成发送消息需要的JSONObject
     *
     * @param source
     * @return
     */
    private JSONObject generateMessageBody(Object source) {
        String jsonStr = JSON.toJSONString(source);
        return JSON.parseObject(jsonStr);
    }

    /**
     * 处理transaction event ：填充消息属性和生成消息体
     *
     * @param event
     * @param propertiesMap
     */

    private JSONObject resolveTransactionEvent(Event event, Map<String, Object> propertiesMap) {
        if (TransactionType.REDEMPTION.name().equals(event.getSourceType())) {

            //获取兑换类型transaction 数据
            List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(event.getSourcePartitionKey(), event.getSourceId());
            if (redemptionList.isEmpty()) {
                log.info("事件消息异常REDEMPTION_NOT_FOUND：{}", JSON.toJSONString(event));
                // 由于收到的事件消息 无法在对应数据库找到 需要抛异常 使消息进行重试 重试三次失败进入死信
                throw new SystemException(ResultCodeMapper.REDEMPTION_NOT_FOUND);
            }
            Redemption redemption = redemptionList.get(0);
            //生成dto 初始化信息
            RedemptionDto dto = RedemptionDto.build(redemption);
            //填充消息属性 以让订阅做过滤
            fillMessagePropertiesForRedemption(redemption, propertiesMap);
            //给dto附加sdc需要的额外信息
            attachAttributeforSdc(redemption, dto);
            return generateMessageBody(dto);
        }
        //其他类型 根据需要写在下面
        return null;
    }


    /**
     * 为sdc 附加额外信息
     *
     * @param redemption
     * @param dto
     */
    private void attachAttributeforSdc(Redemption redemption, RedemptionDto dto) {
        if (DeliveryChannel.C2 != redemption.getDeliveryChannel() || !BRAND_SKII.equals(redemption.brand())) {
            return;
        }
        if (RedemptionStatus.CREATED != redemption.getRedemptionStatus()) {
            //从function：RedemptionRecord4SKII代码看 只需要推送CREATED状态的兑换
            return;
        }
        //brand=SKII & 发运=C2 时生成消息
        List<GiftPackageDto> giftPackageDtoList = new ArrayList<>();
        redemption.getGiftItemList().stream().forEach(giftPackage -> {
            String giftId = giftPackage.getGiftId();
            Gift localGiftPackage = cacheService.getGiftById(giftId);
            List<GiftItem> giftItemList = localGiftPackage.getItems();
            List<GiftItemDto> giftItemDtoList = new ArrayList<>();
            if (!giftItemList.isEmpty()) {
                //补充礼包下的礼品明细
                giftItemList.stream().forEach(item -> {
                    GiftItemDto giftItemDto = GiftItemDto.builder()
                            .name(item.getName()).quantity(item.getQuantity())
                            .sku(item.getSku()).build();
                    giftItemDtoList.add(giftItemDto);
                });

            }
            GiftPackageDto giftPackageDto = GiftPackageDto.builder()
                    .giftId(giftId).giftName(giftPackage.getGiftName()).quantity(giftPackage.getQuantity())
                    //补充每个礼包的图片
                    .imageUri(localGiftPackage.getImageUri()).giftItem(giftItemDtoList).build();
            giftPackageDtoList.add(giftPackageDto);


        });
        dto.setGiftPackageList(giftPackageDtoList);
    }


    /**
     * 填充消息属性
     * <p>
     * 填充属性的详解(以后有变动 需要记录下来)：
     * 目前分发 sdc (订阅名称s_sdc_redemption)需要满足内容：brand=SKII，deliveryChannel=C2，transactionType=REDEMPTION
     * 分发s_deliver_goods_queue(回自动转发消息到deliver_goods_queue) 需要满足deliveryChannel	LOGISTICS，transactionType=REDEMPTION
     * 订阅接收到从topic来的消息 不满足以上的消息属性的消息将被对应的订阅直接舍弃
     * <p>
     * 关于订阅配置消息过滤规则的资料见下面的链接
     * https://learn.microsoft.com/en-us/azure/service-bus-messaging/topic-filters?WT.mc_id=Portal-Microsoft_Azure_ServiceBus
     *
     * @param redemption
     * @param propertiesMap
     */
    private void fillMessagePropertiesForRedemption(Redemption redemption, Map<String, Object> propertiesMap) {
        propertiesMap.put("brand", redemption.getBrand());
        propertiesMap.put("deliveryChannel", redemption.getDeliveryChannel().name());
        propertiesMap.put("transactionType", redemption.getTransactionType().name());
    }


}
