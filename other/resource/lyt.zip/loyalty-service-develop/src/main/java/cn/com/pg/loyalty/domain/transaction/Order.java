package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountOpt;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @author Young
 * @date 2019年4月11日上午10:59:31
 * @description Transaction中的Order类型
 */
@Getter
@Setter
@NoArgsConstructor
public class Order extends Transaction {

    public Order(String loyaltyId, String brand, String channel, LoyaltyStructure loyaltyStructure, String memberId) {
        super(loyaltyId, brand, channel, TransactionType.ORDER, loyaltyStructure, memberId);
    }

    /**
     * C2,Tmall,Jd订单中的TRANSACTION_ID(原始订单号)
     */
    private String orderId;
    /**
     * 退单号
     */
    private String refundOrderId;
    /**
     * 店铺编号
     */
    private String storeCode;
    /**
     * 用户该笔订单总实付金额,
     */
    private Double originalTotalAmount;
    /**
     * 用户该笔订单订单实付金额，正常时 realTotalAmount = originalTotalAmount。
     * 如果发生退单时，那么realTotalAmount = originalTotalAmount - refundAmount。
     */
    private Double realTotalAmount;
    /**
     * 该笔订单的生成时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime orderDateTime;
    /**
     * 该笔订单的更新时间（仅SKII订单使用）
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime orderUpdateTime;
    /**
     * 退单时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime refundOrderDateTime;
    /**
     * 该笔订单中的详细商品列表
     */
    private Set<OrderItem> orderItems = new HashSet<>();
    /**
     * 该笔订单是否为团购
     */
    private Boolean groupPurchase;
    /**
     * 退款金额，是推掉的金额，为正数
     */
    private Double refundAmount;
    /**
     * 当该订单发生退单行为时设置为true
     */
    private Boolean refund;

    /**
     * 如果有退货，此为原始积分
     */
    private Integer originalPoint;


    public void groupPurchase() {
        this.groupPurchase = true;
    }

    public Order addPoint(List<PointItem> pointItems, cn.com.pg.loyalty.domain.activity.PointType pointType) {
        int point = 0;
        if (!CollectionUtils.isEmpty(pointItems)) {
            for (PointItem pointItem : pointItems) {
                point = point + pointItem.getPoint();
            }
        }
        this.point = point;
        this.availablePoint = point;
        this.pointItems = pointItems;
        this.pointType = pointType.pointType();
        this.description = pointType.description();
        this.updatedTime = LocalDateTime.now();
        return this;
    }

    public void inheritanceOriginalInfo(String transactionId, LocalDateTime createTime,LocalDateTime expiredTime) {
        this.id = transactionId;
        this.createdTime = createTime;
        this.expiredTime = expiredTime;
    }

    public void inheritanceOriginalOrder(Order originalOrder) {
        this.id = originalOrder.getId();
        this.createdTime = originalOrder.createdTime;
        this.expiredTime = originalOrder.expiredTime;
        if (!originalOrder.refundOrder()) {
            return;
        }
        this.refund = true;
        this.refundOrderId = originalOrder.refundOrderId;
        this.refundOrderDateTime = originalOrder.refundOrderDateTime;
        this.originalPoint = originalOrder.originalPoint;
        this.originalTotalAmount = originalOrder.originalTotalAmount;
        this.refundAmount = originalOrder.refundAmount;

    }

    /**
     * 添加一条新积分记录
     *
     * @param loyaltyId
     * @param brand
     * @param channel
     * @param loyaltyStructure
     * @param orderDateTime
     * @param orderUpdateTime
     * @param orderItems
     * @param realTotalAmount
     * @return
     */
    public Order(String loyaltyId, String brand, String channel, String orderId, LoyaltyStructure loyaltyStructure,
                 LocalDateTime orderDateTime, LocalDateTime orderUpdateTime, Set<OrderItem> orderItems,
                 double realTotalAmount, String tierLevel, String memberId, String storeCode) {
        super(loyaltyId, brand, channel, TransactionType.ORDER, loyaltyStructure, memberId);
        super.setCurrentLevel(tierLevel);
        this.orderId = orderId;
        this.originalTotalAmount = realTotalAmount;
        this.realTotalAmount = realTotalAmount;
        this.orderDateTime = orderDateTime;
        this.orderItems = orderItems;
        this.refundAmount = 0.0;
        this.refund = false;
        this.storeCode = storeCode;
        this.groupPurchase = false;
        this.originalPoint = 0;
        this.orderUpdateTime = orderUpdateTime;
        this.expiredTime = loyaltyStructure.pointExpire().orderPointExpiredTime(orderDateTime);
        //Transaction 构造中还无orderDateTime,需要重新给值
        this.setUnlockTime(loyaltyStructure.getUnlockTime(this));
    }

    public Order(String loyaltyId, String brand, String channel, String orderId, LoyaltyStructure loyaltyStructure,
                 LocalDateTime orderDateTime, Set<OrderItem> orderItems, String memberId, String storeCode) {
        super(loyaltyId, brand, channel, TransactionType.ORDER, loyaltyStructure, memberId);
        this.orderId = orderId;
        this.realTotalAmount = 0.0;
        this.originalTotalAmount = this.realTotalAmount;
        this.orderDateTime = orderDateTime;
        this.orderItems = orderItems;
        this.refundAmount = 0.0;
        this.refund = false;
        this.storeCode = storeCode;
        this.groupPurchase = false;
        this.originalPoint = 0;
        this.expiredTime = loyaltyStructure.pointExpire().orderPointExpiredTime(orderDateTime);
        //Transaction 构造中还无orderDateTime,需要重新给值
        this.setUnlockTime(loyaltyStructure.getUnlockTime(this));
    }

    public Order(String brand, String channel, String orderId, LocalDateTime orderDateTime, Double realTotalAmount, Set<OrderItem> orderItems, String storeCode) {
        this.brand = brand;
        this.channel = channel;
        this.orderId = orderId;
        this.realTotalAmount = realTotalAmount;
        this.orderDateTime = orderDateTime;
        this.orderItems = orderItems;
        this.storeCode = storeCode;
    }

    public void refund(String refundOrderId, Set<OrderItem> refundOrderItems, double refundAmount, LocalDateTime refundDateTime) {
        updateOrderItemAfterRefund(refundOrderItems);
        this.realTotalAmount = this.realTotalAmount - refundAmount;
        //更新退单的原始记录
        this.refundOrderId = refundOrderId;
        this.refundOrderDateTime = refundDateTime;
        this.refundAmount += refundAmount;
        this.refund = true;
        this.orderUpdateTime=refundOrderDateTime;
        this.updatedTime = LocalDateTime.now();
        this.originalPoint = this.point;
    }


    private void updateOrderItemAfterRefund(Set<OrderItem> refundOrderItems) {
        Iterator<OrderItem> originalOrderItems = this.getOrderItems().iterator();
        while (originalOrderItems.hasNext()) {
            OrderItem originalOrderItem = originalOrderItems.next();
            for (OrderItem refundOrderItem : refundOrderItems) {
                if (originalOrderItem.getSku().equalsIgnoreCase(refundOrderItem.getSku())) {
                    originalOrderItem.refund(refundOrderItem.getRefundQty(), refundOrderItem.getRefundAmount());
                }
            }
        }
    }

    public boolean refundOrder() {
        return Optional.ofNullable(refund).orElse(false);
    }

    public boolean refundAllOrder() {
        return refundOrder() && this.realTotalAmount == 0;
    }

    public static Comparator<Order> comparatorByOrderCreatedTimeDesc() {
        return (o1, o2) -> o2.createdTime.compareTo(o1.createdTime);
    }

    public static Comparator<Order> comparatorByOrderCreatedTimeAsc() {
        return (o1, o2) -> {
            if (o1.getCreatedTime() != null && o2.getCreatedTime() != null) {
                return o1.getCreatedTime().compareTo(o2.getCreatedTime());
            }
            if (o1.getCreatedTime() != null && o2.getCreatedTime() == null) {
                return 1;
            }
            if (o1.getCreatedTime() == null && o2.getCreatedTime() != null) {
                return -1;
            }
            return 0;
        };
    }

    /**
     * 退了多少积分
     *
     * @return
     */
    public int refundPoint() {
        return this.getOriginalPoint() - this.getPoint();
    }

    public boolean groupPurchaseIs() {
        return Optional.ofNullable(this.groupPurchase).orElse(false);
    }

    public double realTotalAmount() {
        double amount = Optional.ofNullable(this.realTotalAmount).orElse(0.0);
        if (Math.abs(amount) < 1 && Boolean.TRUE.equals(this.refund)) {
            amount = 0.0;
        }
        return amount;
    }

    public LocalDateTime adapterOrderUpdateTime() {
        if (orderUpdateTime == null) {
            return orderDateTime;
        }
        return orderUpdateTime;
    }

    public Set<OrderItem> orderItems() {
        return Optional.ofNullable(this.orderItems).orElse(new HashSet<>());
    }

    /**
     * 检查订单和新的订单是否有重复：订单id相同，金额相同，order items相同，则认为是重复的订单
     *
     * @param other
     * @return
     */
    public boolean duplicateWith(Order other) {
        if (!this.orderId.equals(other.orderId)) {
            return false;
        }
        if (!this.realTotalAmount.equals(other.realTotalAmount)) {
            return false;
        }
        return sameOrderItems(this.orderItems, other.orderItems);
    }

    private boolean sameOrderItems(Set<OrderItem> items1, Set<OrderItem> items2) {
        if (items1.size() != items2.size()) {
            return false;
        }
        Map<String, Integer> items1Map =
                items1.stream().collect(Collectors.toMap(OrderItem::getSku, OrderItem::getPurchaseQty));
        Map<String, Integer> items2Map =
                items2.stream().collect(Collectors.toMap(OrderItem::getSku, OrderItem::getPurchaseQty));
        return items1Map.equals(items2Map);
    }

    /**
     * 竞争逻辑
     *
     * @param competePointItems 竞争PointItems
     * @return List<PointItem>
     */
    public void calculateCompetePoint(Map<PointItem, Boolean> competePointItems, PointType pointType) {

        List<PointItem> competePointItemsList = new ArrayList<>();
        ArrayList<PointItem> pointItemList = new ArrayList<>();
        List<PointItem> competedPointItems = new ArrayList<>();

        competePointItems.forEach((pointItem, isCompete) -> {
            if (Boolean.FALSE.equals(isCompete)) {
                pointItemList.add(pointItem);
            } else {
                competePointItemsList.add(pointItem);
            }
        });
        //竞争逻辑
        if (!competePointItemsList.isEmpty()) {
            Map<String, Integer> collect = competePointItemsList.stream()
                    .collect(Collectors.groupingBy(PointItem::getActivityId, Collectors.summingInt(PointItem::getPoint)));
            AtomicReference<String> competedActivityId = new AtomicReference<>();
            AtomicInteger maxPoint = new AtomicInteger(0);
            collect.forEach((activityId, point) -> {
                if (point > maxPoint.get()) {
                    maxPoint.set(point);
                    competedActivityId.set(activityId);
                }
            });
            competedPointItems = competePointItems.keySet().stream()
                    .filter(pointItem -> pointItem.getActivityId().equals(competedActivityId.get()))
                    .collect(Collectors.toList());
        }
        if (!competedPointItems.isEmpty()) {
            pointItemList.addAll(competedPointItems);
        }
        addPoint(pointItemList, pointType);


    }

    public String channelUnitOrderId() {
        return channel.concat("_").concat(orderId);
    }

    /**
     * @param account
     * @return
     */
    public boolean anJpSkiiPastedOrder(Account account) {
        if (!BrandV2.SKII.equals(this.brand) || !"JP".equals(account.region())) {
            return false;
        }
        return this.orderDateTime.isBefore(account.registryTime(this.brand));
    }

    public boolean hasBeenPastedOrder() {
        return StringUtils.equals(PointTypeEnum.ORDER_PASTED.name(), this.pointType);
    }

    public Order pastedOrder() {
        this.pointType = PointTypeEnum.ORDER_PASTED.name();
        this.description = "历史订单";
        return this;
    }


    public boolean catchOptOut(AccountOpt opt) {
        return opt != null && opt.optOut(this.orderDateTime);
    }

    public void optOutOrder() {
        this.pointType = PointTypeEnum.ORDER_OPT_OUT.name();
        this.description = "opt out 订单";
    }

    public boolean hasBeenOptOutOrder() {
        return StringUtils.equals(PointTypeEnum.ORDER_OPT_OUT.name(), this.pointType);
    }

    public boolean availableCalculate() {
        return null == pointType;
    }

    /**
     * 防止迁移数据为null,不要删除
     *
     * @param orderItems
     */
    public void setOrderItems(Set<OrderItem> orderItems) {
        if (orderItems == null) {
            return;
        }
        this.orderItems = orderItems;
    }

    public boolean canRefund(double refundAmount, LocalDateTime refundOrderDateTime) {
        return this.realTotalAmount >= refundAmount
                && !this.orderDateTime.isAfter(refundOrderDateTime);
    }

    public boolean containsSkuAll(List<String> skuStr) {
        return this.orderItems.stream().allMatch(orderItem -> skuStr.contains(orderItem.getSku()));
    }

    public boolean containsSkuAny(List<String> skuS) {
        return this.orderItems.stream().anyMatch(orderItem -> skuS.contains(orderItem.getSku()));
    }

    public boolean notContainsSkuAny(List<String> skuS) {
        return this.orderItems.stream().anyMatch(orderItem -> !skuS.contains(orderItem.getSku()));
    }

    /**
     * 竞争逻辑
     *
     * @param competePointItems 竞争PointItems
     * @return List<PointItem>
     */
    public void calculateCompetePointForOlay(Map<PointItem, Boolean> competePointItems, PointType pointType, List<String> sbdActivityIds) {

        List<PointItem> competePointItemsList = new ArrayList<>();
        ArrayList<PointItem> pointItemList = new ArrayList<>();
        List<PointItem> competedPointItems = new ArrayList<>();

        competePointItems.forEach((pointItem, isCompete) -> {
            if (Boolean.FALSE.equals(isCompete)) {
                pointItemList.add(pointItem);
            } else {
                competePointItemsList.add(pointItem);
            }
        });
        //竞争逻辑
        if (!competePointItemsList.isEmpty()) {
            Map<String, Integer> collect = competePointItemsList.stream()
                    .collect(Collectors.groupingBy(PointItem::getActivityId, Collectors.summingInt(PointItem::getPoint)));
            AtomicReference<String> competedActivityId = new AtomicReference<>();
            AtomicInteger maxPoint = new AtomicInteger(0);
            collect.forEach((activityId, point) -> {
                //olay sbd 活动竞争规则：当最大积分与sbd积分相等时，优先选择sbd活动
                if (point > maxPoint.get() || (point.equals(maxPoint.get()) && sbdActivityIds.contains(activityId))) {
                    maxPoint.set(point);
                    competedActivityId.set(activityId);
                }
            });
            competedPointItems = competePointItems.keySet().stream()
                    .filter(pointItem -> pointItem.getActivityId().equals(competedActivityId.get()))
                    .collect(Collectors.toList());
        }
        if (!competedPointItems.isEmpty()) {
            pointItemList.addAll(competedPointItems);
        }
        addPoint(pointItemList, pointType);


    }

    public double exchangeBaseAmount(LoyaltyStructure structure) {
        return structure.amountRate().exchange2BaseAmount(this.realTotalAmount);
    }
}
