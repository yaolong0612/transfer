package cn.com.pg.loyalty.domain.account;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.ValueObject;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointValueObject.PointValue;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Young
 * @date 2019年4月2日下午3:27:08
 * @description 子品牌
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
public class SubAccount implements ValueObject<SubAccount> {

    /**
     *
     */
    private static final long serialVersionUID = -3970275652956150759L;
    /**
     * 绑定渠道ID: JD PIN，Tmall ID，WeChat Open ID, (Website也包含在内，bindid == null, 为了判断绑定事件，尽管没有绑定ID)
     */
    private Map<String, String> bindList = new HashMap<>();
    /**
     * 剩余可用积分
     */
    private Integer pointAvailable;
    /**
     * 即将过期积分
     */
    private Integer pointAboutExpire;
    /**
     * 该用户购买次数
     */
    private Integer totalPurchaseTimes;
    /**
     * 历史总积分
     */
    private Integer totalPoint;

    /**
     * 消费者使用掉的积分,是正数
     */
    private Integer pointUsed;

    /**
     * 过期积分是正数
     */
    private Integer pointExpired;

    /**
     * 锁定积分
     */
    private int pointLocked;

    /**
     * 最后解锁积分的日期，已解锁早于该日期的锁定积分
     * 如：2022-02-22，则transaction中unlockTime为2022-02-22之前的积分已被解锁
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate unlockTime;

    private String firstPurchaseStoreCode;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime firstPurchaseTime;

    /**
     * 子账户创建时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime;

    /**
     * 子账户更新时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime updatedTime;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_PATTERN)
    private LocalDate pointAboutExpiredDate;

    public SubAccount(String channel, String bindId, LocalDateTime registerTime) {
        pointAvailable = 0;
        pointExpired = 0;
        pointUsed = 0;
        totalPoint = 0;
        totalPurchaseTimes = 0;
        pointAboutExpire = 0;
        createdTime = registerTime != null ? registerTime : LocalDateTime.now();
        updatedTime = LocalDateTime.now();
        bindList.put(channel, bindId);
    }

    public Map<String, String> bindList() {
        return bindList;
    }

    public void bind(String channel, String bindId) {
        updatedTime = LocalDateTime.now();
        bindList.put(channel, bindId);
    }

    public void addPoint(int point, LocalDate expiredDate, LocalDate unlockedTime) {
        if (point <= 0) {
            return;
        }
        if (Objects.isNull(expiredDate)) {
            return;
        }
        if (expiredDate.isBefore(LocalDate.now())) {
            return;
        }
        this.totalPoint += point;
        this.updatedTime = LocalDateTime.now();
        calculateIfLocked(point, unlockedTime);
        calculateAboutExpireForAdd(point, expiredDate);
    }

    private void calculateIfLocked(int point, LocalDate unlockedTime) {
        if (unlockedTime == null || !unlockedTime.isAfter(LocalDate.now())) {
            this.pointAvailable += point;
            return;
        }
        this.pointLocked += point;
        if (this.pointLocked < 0) {
            this.pointLocked = 0;
            this.pointAvailable += pointLocked;
        }
    }

    private void calculateAboutExpireForAdd(int point, LocalDate expiredDate) {
        if (point <= 0 || expiredDate == null) {
            return;
        }
        if (ownPoint() <= 0) {
            this.pointAboutExpire = 0;
            this.pointAboutExpiredDate = null;
            return;
        }
        if (pointAboutExpiredDate == null) {
            this.pointAboutExpire = ownPoint();
            this.pointAboutExpiredDate = expiredDate;
            return;
        }
        if (expiredDate.isEqual(pointAboutExpiredDate)) {
            this.pointAboutExpire += point;
            return;
        }
        if (expiredDate.isBefore(pointAboutExpiredDate)) {
            this.pointAboutExpiredDate = expiredDate;
            this.pointAboutExpire = point;
        }
    }

    public LocalDate pointAboutExpiredDateWithDefault() {
        return Optional.ofNullable(pointAboutExpiredDate).orElse(LocalDate.MAX);
    }


    public void consumePoint(int point) {
        this.pointAvailable -= point;
        this.pointUsed += point;
        calculateAboutExpireForReduce(point);
        this.updatedTime = LocalDateTime.now();
    }


    public void cancelRedemption(int point, LocalDate expiredDate) {
        this.pointAvailable += point;
        this.pointUsed -= point;
        this.updatedTime = LocalDateTime.now();
        calculateAboutExpireForAdd(point, expiredDate);
    }

    public void calculateOrder(Order order) {
        addPoint(order.getPoint(), order.getExpiredTime().toLocalDate(), order.getUnlockTime());
        if (order.realTotalAmount() > 0) {
            this.totalPurchaseTimes += 1;
        }
        if (firstPurchaseTime == null || order.getOrderDateTime().compareTo(this.firstPurchaseTime) < 0) {
            this.firstPurchaseTime = order.getOrderDateTime();
            this.firstPurchaseStoreCode = order.getStoreCode();
        }
    }


    public void rollBack(Order order) {
        this.totalPoint -= order.point();
        this.totalPurchaseTimes -= 1;
        this.updatedTime = LocalDateTime.now();
        calculateIfLocked(-order.getPoint(), order.getUnlockTime());
        calculateAboutExpireForReduce(order.point(), order.getExpiredTime().toLocalDate());
    }

    public void refundAwardPoint(Interaction interaction) {
        this.updatedTime = LocalDateTime.now();
        this.totalPoint -= Math.abs(interaction.point());
        calculateIfLocked(-interaction.getPoint(), interaction.getUnlockTime());
        calculateAboutExpireForReduce(interaction.availablePoint(), interaction.getExpiredTime().toLocalDate());

    }


    public void mergeAccount(int totalPoint, int pointAvailable, int pointAboutExpire, int pointUsed,
                             int totalPurchaseTimes, int pointExpired) {
        this.totalPoint += totalPoint;
        this.pointAvailable += pointAvailable;
        this.pointUsed += pointUsed;
        this.pointAboutExpire += pointAboutExpire;
        this.totalPurchaseTimes += totalPurchaseTimes;
        this.pointExpired += pointExpired;
        this.updatedTime = LocalDateTime.now();
    }

    public int expiredPoint(int point) {
        int expirePoint = Math.min(point, this.pointAvailable);
        this.pointAvailable -= expirePoint;
        this.pointExpired += expirePoint;
        this.updatedTime = LocalDateTime.now();
        return expirePoint;
    }

    public void pointAboutExpire(int pointAboutExpire) {
        this.updatedTime = LocalDateTime.now();
        this.pointAboutExpire = pointAboutExpire;
    }

    private void calculateAboutExpireForReduce(int point) {
        this.pointAboutExpire = Optional.ofNullable(this.pointAboutExpire).orElse(0) - point;
        if (this.pointAboutExpire <= 0) {
            this.pointAboutExpire = 0;
            this.pointAboutExpiredDate = null;
        }
    }

    private void calculateAboutExpireForReduce(int point, LocalDate expiredDate) {
        if (expiredDate == null) {
            calculateAboutExpireForReduce(point);
            return;
        }
        if (pointAboutExpiredDate == null) {
            calculateAboutExpireForReduce(point);
            return;
        }
        if (!expiredDate.isAfter(pointAboutExpiredDate)) {
            calculateAboutExpireForReduce(point);
        }
    }


    public void delayExpired(int point, LocalDate createdDate, LocalDate expiredDate) {
        if (this.pointAboutExpiredDate == null && point > 0) {
            this.updateAboutExpired(point, expiredDate);
            return;
        }
        if (this.pointAboutExpiredDate == null) {
            return;
        }
        //如果与订单过期时间相同，不做计算，因为计算订单的时候已经计算
        if (expiredDate.isEqual(this.pointAboutExpiredDate)) {
            return;
        }
        if (createdDate.isAfter(this.pointAboutExpiredDate)) {
            return;
        }
        if (expiredDate.isBefore(this.pointAboutExpiredDate)) {
            return;
        }
        this.updateAboutExpired(pointAboutExpire + point, expiredDate);
    }

    public void updateAboutExpired(int pointAboutExpire, LocalDate pointAboutExpiredDate) {
        this.updatedTime = LocalDateTime.now();
        if (ownPoint() <= 0) {
            this.pointAboutExpiredDate = null;
            this.pointAboutExpire = 0;
        }
        this.pointAboutExpiredDate = pointAboutExpiredDate;
        this.pointAboutExpire = pointAboutExpire;
    }

    protected int ownPoint() {
        return this.pointAvailable + this.pointLocked;
    }

    public void updatePurchaseInfo(LocalDateTime createdTime, String storeCode, int totalPurchaseTimes) {
        if (this.firstPurchaseTime == null) {
            this.firstPurchaseTime = createdTime;
        }
        if (this.firstPurchaseStoreCode == null) {
            this.firstPurchaseStoreCode = storeCode;
        }
        this.totalPurchaseTimes += totalPurchaseTimes;
        this.updatedTime = LocalDateTime.now();
    }

    public void calculatePoint(PointValue pointValue, LocalDate pointAboutExpiredDate) {
        if (pointValue.expired()) {
            this.pointExpired += pointValue.point();
        } else {
            if (this.pointAboutExpiredDate == null) {
                this.pointAboutExpire += pointValue.point();
                this.pointAboutExpiredDate = pointAboutExpiredDate;
                if (this.pointAboutExpire < 0) {
                    this.pointAboutExpire = 0;
                    this.pointAboutExpiredDate = null;
                }
            }
            this.pointAvailable += pointValue.point();
        }
        this.updatedTime = LocalDateTime.now();
    }

    public void resetInfo() {
        this.pointAboutExpiredDate = null;
        this.pointAboutExpire = 0;
        this.totalPoint = 0;
        this.pointUsed = 0;
        this.pointExpired = 0;
        this.pointAvailable = 0;
        this.firstPurchaseTime = null;
        this.firstPurchaseStoreCode = null;
        this.totalPurchaseTimes = 0;
        this.updatedTime = LocalDateTime.now();
    }

    public void initPoint() {
        this.pointAboutExpiredDate = null;
        this.pointAboutExpire = 0;
        this.totalPoint = 0;
        this.pointUsed = 0;
        this.pointExpired = 0;
        this.pointAvailable = 0;
        this.pointLocked = 0;
        this.unlockTime = null;
        this.updatedTime = LocalDateTime.now();
    }

    public void updatePointInfo(int usedPoint, int totalPoint) {
        this.pointUsed += usedPoint;
        this.totalPoint += totalPoint;
        this.updatedTime = LocalDateTime.now();
    }

    public void updateRegistryTime(LocalDateTime registryTime) {
        this.createdTime = registryTime;
        this.updatedTime = LocalDateTime.now();
    }


    public void firstPurchaseStoreCode(String firstPurchaseStoreCode, LocalDateTime firstPurchaseTime) {
        this.firstPurchaseStoreCode = firstPurchaseStoreCode;
        this.firstPurchaseTime = firstPurchaseTime;
        this.updatedTime = LocalDateTime.now();
    }

    public String firstPurchaseTimeToIgnoreMillisecond() {
        return this.firstPurchaseTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.000"));
    }

    public void updateUnlockPoint(int notUnlockedPoint, LocalDate unlockTime) {
        //先计算应该解锁积分
        int doUnlockPoint = this.pointLocked - notUnlockedPoint;
        this.pointAvailable += doUnlockPoint;
        this.pointLocked = notUnlockedPoint;
        this.unlockTime = unlockTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubAccount that = (SubAccount) o;

        return new EqualsBuilder()
                .append(pointAvailable, that.pointAvailable)
                .append(pointAboutExpire, that.pointAboutExpire)
                .append(totalPurchaseTimes, that.totalPurchaseTimes)
                .append(totalPoint, that.totalPoint)
                .append(pointUsed, that.pointUsed)
                .append(pointExpired, that.pointExpired)
                .append(bindList, that.bindList)
                .append(firstPurchaseStoreCode, that.firstPurchaseStoreCode)
                .append(firstPurchaseTime, that.firstPurchaseTime)
                .append(createdTime, that.createdTime)
                .append(updatedTime, that.updatedTime)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(bindList)
                .append(pointAvailable)
                .append(pointAboutExpire)
                .append(totalPurchaseTimes)
                .append(totalPoint)
                .append(pointUsed)
                .append(pointExpired)
                .append(firstPurchaseStoreCode)
                .append(firstPurchaseTime)
                .append(createdTime)
                .append(updatedTime)
                .toHashCode();
    }

    @Override
    public boolean sameValueAs(SubAccount other) {
        return this.equals(other);
    }

    public void updateAboutExpiredDate(LocalDate pointAboutExpiredDate) {
        this.pointAboutExpiredDate = pointAboutExpiredDate;
        this.updatedTime = LocalDateTime.now();
    }

    public boolean needRecalculatePointAboutExpire() {
        return this.getPointAboutExpire() == null || this.getPointAboutExpire() <= 0 || ownPoint() <= 0;
    }

}
