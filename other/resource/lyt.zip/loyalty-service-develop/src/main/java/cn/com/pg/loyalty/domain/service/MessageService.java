package cn.com.pg.loyalty.domain.service;

import cn.com.pg.loyalty.application.dependence.OrderMessage;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.application.dto.RefundDTO;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.pool.PoolMessage;
import cn.com.pg.loyalty.domain.shared.InteractionMessage;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.interfaces.dto.Event;
import com.alibaba.fastjson.JSONObject;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface MessageService {

    /**
     * 保存Transaction或者Account失败后的message
     *
     * @param transaction
     */
    void sendSaveTransactionAndAccountFailedMessage(Transaction transaction);

    /**
     * 保存account失败后发送消息
     *
     * @param account
     */
    void sendSaveAccountFailedMessage(Account account);

    /**
     * 保存transaction失败后发送消息
     *
     * @param transaction
     */
    void sendSaveTransactionFailedMessage(Transaction transaction);

    void send2RecalculateOrders(String memberId, String region, List<Order> originOrders);

    void delayCalculateOrders(String memberId, String region, String brand, List<Order> originOrders, LocalDateTime calculateDate);

    void delayRecalculateOrders(String memberId, String region, String brand, List<Order> originOrders, LocalDateTime calculateDate);

    void pushOrderAffectExpiredEvent(String memberId, String brand, String region);

    void send2DeleteMembersForSkii(JSONObject message);

    void sendMessageForDeleteMemberInfo(List<Account> originalAccounts, String brand);

    void sendMessageForBatchAddInteractionPoint(String region, String brand, String channel,
                                                String pointType, Integer point, List<String> memberIds,
                                                String adjustReason);

    void sendMessage4InfoConsumer(JSONObject outerMessage);

    void sendMessage4PointPool(PoolMessage poolMessage);

    void sendMessageForAddInteractionPoint(InteractionMessage message, int persistTimes);

    void sendToFindReceiverAndMobile(Redemption redemption, LoyaltyStructure loyaltyStructure);

    void sendToSyncInventoryToDB(Redemption redemption, Boolean isRefund);


    void sendNormalOrderMessageToQueue(String region, String brand, OrderMessage message);

    void sendRefundOrderMessageToQueue(String region, String brand, String memberId, RefundDTO refundDTO);

    void delayOrdersRequest(RequestOrdersMessage message, LocalDateTime calculateDateTime);

    void sendDelayEventMsg(Event event, LocalDateTime delayTime);

    void sendMsgToTransactionEventTopic(JSONObject messageBody, Map<String, Object> propertiesMap);


}
