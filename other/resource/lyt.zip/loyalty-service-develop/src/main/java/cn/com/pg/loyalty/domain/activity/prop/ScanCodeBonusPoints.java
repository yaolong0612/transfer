package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Min;

/**
 * @author: Ysnow
 * @Date: 2019/5/30 14:16
 * @Description:扫码加积分的额外奖励积分
 */
@Getter
@Setter
public class ScanCodeBonusPoints {
    /**
     * 从第几次可以加额外积分
     */
    private int startTimes;

    /**
     * 总共可以加多少积分
     */
    private int totalPoint;

    /**
     *每次加多少积分
     */
    @Min(0)
    private int perPoint;



    public ScanCodeBonusPoints() {
    }

    public ScanCodeBonusPoints(int startTimes, int totalPoint, int perPoint) {
        this.startTimes = startTimes;
        this.totalPoint = totalPoint;
        this.perPoint = perPoint;
    }
}
