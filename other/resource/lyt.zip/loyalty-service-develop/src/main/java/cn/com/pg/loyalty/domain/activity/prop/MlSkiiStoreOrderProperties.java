package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @description:
 * @author: Artermus wang on 2022-05-26 13:46
 */
@Getter
@Setter
public class MlSkiiStoreOrderProperties extends RuleProperties {
    String channel;
    /**
     * 参与竞争
     */
    private boolean competition;
    /**
     * 倍数的类型  包含固定和浮动
     */
    private Type multipleType;

    /**
     * 固定倍率下才有值
     */
    private Double multipleTimes = 1.0;
    /**
     * 额外积分下存在
     */
    private Integer extraPoint;

    public enum Type {
        REGULAR,
//        FLOAT,
        EXTRA
    }


    /**
     * 指定柜台多倍积分
     * 包含或者排出
     */
    private List<ChannelSet3.StoreCode> storeCodeConfig;
}
