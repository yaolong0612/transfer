package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.structure.ExtraSubAccountTactics;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevel;
import cn.com.pg.loyalty.domain.structure.TierLevelBuilder;
import cn.com.pg.loyalty.interfaces.dto.AddStructureCommand;
import cn.com.pg.loyalty.interfaces.dto.FetchStructureListDto;
import cn.com.pg.loyalty.interfaces.dto.StructureDto;
import cn.com.pg.loyalty.interfaces.dto.StructureDto.ExtraTacticsEnum;
import cn.com.pg.loyalty.interfaces.dto.TierLevelDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class LoyaltyStructureAssembler {

    public static StructureDto toStructureDto(LoyaltyStructure loyaltyStructure) {
        StructureDto structureDto = new StructureDto();
        ExtraSubAccountTactics extraSubAccountTactics = loyaltyStructure.getExtraSubAccountTactics();
        structureDto.name(loyaltyStructure.getName())
                .amTenantId(loyaltyStructure.getAmTenantId())
                .amountRate(loyaltyStructure.getAmountRate().getRate())
                .brands(loyaltyStructure.getBrands())
                .marketingProgramId(loyaltyStructure.getMarketingProgramId())
                .pointEffectiveYear(loyaltyStructure.getPointExpire().getPointEffectiveYear())
                .pointExpiredWay(loyaltyStructure.getPointExpire().getPointExpiredWay().name())
                .pointExpiredDateCalculateWay(loyaltyStructure.getPointExpire().getExpiredDateCalculateWay().name())
                .usePointPool(loyaltyStructure.getPointExpire().isUsePointPool())
                .orderDelayExpired(loyaltyStructure.getPointExpire().isOrderDelayExpired())
                .region(loyaltyStructure.getRegion())
                .tierLevels(loyaltyStructure.getTierLevelSeries().getTierLevels().stream()
                        .map(LoyaltyStructureAssembler::toTierLevelDto).collect(Collectors.toList()))
                .tierChangeType(loyaltyStructure.getTierLevelSeries().getTierChangeType().name())
                .tierEffectiveYear(loyaltyStructure.getTierLevelSeries().getTierEffectiveYear())
                .tierExpiredWay(loyaltyStructure.tierLevelSeries().getTierExpiredWay().name())
                .insertOrderBackRoll(loyaltyStructure.getOrderImpact().isInsertBackRoll())
                .refundOrderBackRoll(loyaltyStructure.getOrderImpact().isRefundBackRoll())
                .alertOrderBackRoll(loyaltyStructure.getOrderImpact().isAlertBackRoll())
                .openExtraSubAccount(loyaltyStructure.isOpenExtraSubAccount())
                .calculateWay(loyaltyStructure.tierLevelSeries().getCalculateWay().name())
                .calculateCountInterval(loyaltyStructure.tierLevelSeries().getCalculateCountInterval());
        if (extraSubAccountTactics != null && loyaltyStructure.isOpenExtraSubAccount()) {
            structureDto.extraTactics(ExtraTacticsEnum.fromValue(extraSubAccountTactics.getExtraTactics().name()))
                    .extraOrderDelayExpired(extraSubAccountTactics.getPointExpire().isOrderDelayExpired())
                    .extraPointEffectiveYear(extraSubAccountTactics.getPointExpire().getPointEffectiveYear())
                    .extraPointExpiredWay(extraSubAccountTactics.getPointExpire().getPointExpiredWay().name())
                    .extraUsePointPool(extraSubAccountTactics.getPointExpire().isUsePointPool());
        }
        return structureDto;
    }

    private static TierLevelDTO toTierLevelDto(TierLevel tierLevel) {
        TierLevelDTO tierLevelDto = new TierLevelDTO();
        return tierLevelDto.level(tierLevel.getLevel())
                .levelAlias(tierLevel.getLevelAlias())
                .levelName(tierLevel.getLevelName())
                .gradingAmount(tierLevel.getGradingAmount())
                .upgradeAmount(tierLevel.getUpgradeAmount())
                .gradingPoint(tierLevel.getGradingPoint())
                .upgradePoint(tierLevel.getUpgradePoint())
                .gradingAward(tierLevel.getGradingAward())
                .upgradeAward(tierLevel.getUpgradeAward());
    }

    public static StructureDto toStructureDto(AddStructureCommand body) {
        StructureDto structureDto = new StructureDto();
        structureDto.tierEffectiveYear(body.getTierEffectiveYear())
                .tierChangeType(body.getTierChangeType())
                .tierLevels(body.getTierLevels())
                .region(body.getRegion())
                .brands(body.getBrands())
                .usePointPool(body.isUsePointPool())
                .name(body.getName())
                .marketingProgramId(body.getMarketingProgramId())
                .amTenantId(body.getAmTenantId())
                .pointEffectiveYear(body.getPointEffectiveYear())
                .pointExpiredWay(body.getPointExpiredWay())
                .orderDelayExpired(body.isOrderDelayExpired())
                .amountRate(body.getAmountRate())
                .pointExpiredDateCalculateWay(body.getPointExpiredDateCalculateWay());
        return structureDto;
    }

    public static TierLevel toTierLevelV2(TierLevelDTO tierLevelDto) {
        return new TierLevelBuilder().level(tierLevelDto.getLevel())
                .levelName(tierLevelDto.getLevelName())
                .levelAlias(tierLevelDto.getLevelAlias())
                .gradingAmount(Optional.ofNullable(tierLevelDto.getGradingAmount()).orElse(0))
                .upgradeAmount(Optional.ofNullable(tierLevelDto.getUpgradeAmount()).orElse(0))
                .gradingAward(tierLevelDto.getGradingAward())
                .upgradeAward(tierLevelDto.getUpgradeAward())
                .gradingPoint(Optional.ofNullable(tierLevelDto.getGradingPoint()).orElse(0))
                .upgradePoint(Optional.ofNullable(tierLevelDto.getUpgradePoint()).orElse(0))
                .createTierLevel();
    }

    public static FetchStructureListDto toStructureListDto(List<LoyaltyStructure> structures) {
        List<StructureDto> structureDtos = new ArrayList<>();
        structures.forEach(structureV2 -> structureDtos.add(toStructureDto(structureV2)));
        FetchStructureListDto fetchStructureListDto = new FetchStructureListDto();
        fetchStructureListDto.setTotalSize(structureDtos.size());
        fetchStructureListDto.setRecords(structureDtos);
        return fetchStructureListDto;
    }

    private LoyaltyStructureAssembler() {
    }
}
