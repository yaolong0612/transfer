package cn.com.pg.loyalty.domain.account;

/**
 * 订单规则计算
 */
public interface TierRulesCalculateAble {

    /**
     * 根据规则计算规则等级
     *
     * @param tierChangeScene
     */
    void calculateTiersRule(TierChangeScene tierChangeScene);

    /**
     * 根据规则计算规则等级
     */
     void calculateAwardPoint(TierChangeScene tierChangeScene);
}
