package cn.com.pg.loyalty.domain.transaction;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Young
 * @date 2019年4月11日上午11:46:42
 * @description Transaction中的交互类型
 */
@Getter
@Setter
@NoArgsConstructor
public class Interaction extends Transaction {

    /**
     * 扫码的
     */
    private String qrCode;

    /**
     * sku
     */
    private String sku;

    /**
     * 操作描述/调整原因
     */
    private String adjustReason;

    /**
     * 操作人
     */
    private String createBy;

    /**
     * 外部业务ID
     */
    private String externalBusinessId;


    /**
     * 审批加积分的截图链接
     */
    private List<String> imageUriList = new ArrayList<>();


    /**
     * 交互类型
     */
    public Interaction(String loyaltyId, String brand, String channel, LoyaltyStructure loyaltyStructure, String memberId) {
        super(loyaltyId, brand, channel, TransactionType.INTERACTION, loyaltyStructure, memberId);
        this.unlockTime = loyaltyStructure.getUnlockTime(this);
        this.expiredTime = loyaltyStructure.pointExpire().pointExpiredTime(createdTime);
    }

    /**
     * 交互类型
     */
    public Interaction(String loyaltyId, String brand, String channel, LoyaltyStructure loyaltyStructure, String memberId, String externalBusinessId) {
        super(loyaltyId, brand, channel, TransactionType.INTERACTION, loyaltyStructure, memberId);
        //默认是default类型
        this.externalBusinessId = externalBusinessId;
        this.unlockTime = loyaltyStructure.getUnlockTime(this);
        this.expiredTime = loyaltyStructure.pointExpire().pointExpiredTime(createdTime);
    }

    /**
     * 该构造函数只能给用户借用积分使用
     */
    public Interaction(String loyaltyId, String brand, String channel, LoyaltyStructure loyaltyStructure, String memberId, TransactionStatus transactionStatus) {
        super(loyaltyId, brand, channel, TransactionType.INTERACTION, loyaltyStructure, memberId, transactionStatus);
        this.unlockTime = loyaltyStructure.getUnlockTime(this);
        this.expiredTime = loyaltyStructure.pointExpire().pointExpiredTime(createdTime);
    }

    /**
     * 该构造函数只能给系统结算积分使用
     */
    public Interaction(String loyaltyId, String brand, String channel, LoyaltyStructure loyaltyStructure, String memberId, TransactionStatus transactionStatus, LocalDateTime createTime, Integer availablePoint) {
        super(loyaltyId, brand, channel, TransactionType.INTERACTION, loyaltyStructure, memberId, transactionStatus, createTime, availablePoint);
        this.unlockTime = loyaltyStructure.getUnlockTime(this);
        this.expiredTime = loyaltyStructure.pointExpire().pointExpiredTime(createdTime);
    }

    /**
     * 处理积分
     *
     * @param activity
     * @param point
     */
    public void addPoint(Activity activity, int point) {
        this.point = point;
        if (point > 0) {
            this.availablePoint = point;
        } else {
            this.availablePoint = 0;
        }
        this.description = activity.description();
        this.pointType = activity.pointType();
        PointItem pointItem = new PointItem(point, description, activity.activityId());
        this.pointItems.add(pointItem);
        this.updatedTime = LocalDateTime.now();
    }

    public void addPoint(int point, String description, String pointType, String activityId) {
        this.point = point;
        if (point > 0) {
            this.availablePoint = point;
        } else {
            this.availablePoint = 0;
        }
        this.description = description;
        this.pointType = pointType;
        PointItem pointItem = new PointItem(point, description, activityId);
        this.pointItems.add(pointItem);
        this.updatedTime = LocalDateTime.now();
        this.activityId = activityId;

    }

    public void returnPoint(int point, String description, String pointType, String activityId) {
        int absPoint = Math.abs(point);
        this.point -= absPoint;
        this.availablePoint -= absPoint;
        this.description = description;
        this.pointType = pointType;
        PointItem pointItem = new PointItem(-absPoint, description, activityId);
        this.pointItems.add(pointItem);
        this.updatedTime = LocalDateTime.now();
    }


    /**
     * 客服处理积分
     *
     * @param activity
     * @param point
     * @param adjustReason
     * @param createBy
     */
    public void addPoint(Activity activity, int point, String adjustReason, String createBy) {
        addPoint(activity, point);
        this.adjustReason = adjustReason;
        this.createBy = createBy;

    }

    /**
     * 前端处理积分
     *
     * @param activity
     * @param point
     * @param adjustReason
     */
    public void addPoint(Activity activity, int point, String adjustReason) {
        addPoint(activity, point);
        this.description = adjustReason;
    }

    /**
     * 注册增加积分
     *
     * @param activity
     * @param pointType
     * @param addPoint
     */
    public void addPoint(Activity activity, PointType pointType, Integer addPoint) {
        this.point = addPoint;
        this.availablePoint = addPoint;
        this.description = pointType.description();
        this.pointType = pointType.pointType();
        PointItem pointItem = new PointItem(point, description, activity.activityId());
        this.updatedTime = LocalDateTime.now();
        this.pointItems.add(pointItem);
    }

    public void addPointForRedemptionCancel(String activityId, Integer refundPoint, PointType pointType) {
        this.pointType = PointTypeEnum.REDEMPTION_CANCEL.name();
        this.point = refundPoint;
        this.availablePoint = refundPoint;
        this.description = pointType.getDescription();
        PointItem pointItem = new PointItem(refundPoint, pointType.getDescription(), activityId);
        this.pointItems.add(pointItem);
        this.updatedTime = LocalDateTime.now();
        this.unlockTime = null;
    }

    public void scanCode(Activity activity, int point, String qrCode, String sku, PointType pointTypeObject) {
        this.pointType = pointTypeObject.pointType();
        this.qrCode = qrCode;
        this.sku = sku;
        PointItem pointItem = new PointItem(point, activity.description(), activity.activityId());
        this.pointItems.add(pointItem);
        this.description = pointTypeObject.description();
        this.point = point;
        this.availablePoint = point;
        this.updatedTime = LocalDateTime.now();
        this.activityId = activity.activityId();
    }

    public void scanCode(Activity activity, String qrCode, String sku, PointType pointTypeObject, List<PointItem> pointItems) {
        this.pointType = pointTypeObject.pointType();
        this.qrCode = qrCode;
        this.sku = sku;
        this.pointItems = pointItems;
        this.description = pointTypeObject.description();
        pointItems.forEach(pointItem -> this.point += pointItem.getPoint());
        this.availablePoint = point;
        this.updatedTime = LocalDateTime.now();
        this.activityId = activity.activityId();
    }

    public void minusMigrationPoint(Integer refundAmount) {
        this.availablePoint -= refundAmount;
        this.point -= refundAmount;
        this.updatedTime = LocalDateTime.now();
    }

    public String qrCode() {
        return this.qrCode;
    }

    public String sku() {
        return this.sku;
    }

    public void updateExpireTime(LocalDateTime expiredTime) {
        this.expiredTime = expiredTime;
    }
}
