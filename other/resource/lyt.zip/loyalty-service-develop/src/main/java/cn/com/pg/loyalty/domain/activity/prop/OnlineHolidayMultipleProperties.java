package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-05-16 18:40
 */

@Getter
@Setter
public class OnlineHolidayMultipleProperties extends RuleProperties {

    @Min(0)
    private int givenLimitPoint;
    private boolean competition;
    private String exemptionPeriodStartAt;
    private String exemptionPeriodEndAt;
    @Valid
    private List<ChannelSet> channels = new ArrayList<>();

    public LocalDateTime exemptionPeriodStartAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodStartAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodStartAt);
        }
        return localDateTime;
    }

    public LocalDateTime exemptionPeriodEndAt(){
        LocalDateTime localDateTime = null;
        if (StringUtils.isNotEmpty(this.exemptionPeriodEndAt)){
            localDateTime = LoyaltyDateTimeUtils.stringToLocalDateTime(this.exemptionPeriodEndAt);
        }
        return localDateTime;
    }
}
