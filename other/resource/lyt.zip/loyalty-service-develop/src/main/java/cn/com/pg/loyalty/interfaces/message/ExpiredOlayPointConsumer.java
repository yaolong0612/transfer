package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.ExpiredPointService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import cn.com.pg.loyalty.domain.shared.RequestContext;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import cn.com.pg.loyalty.application.dependence.ExpiredPointMessage;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * @author cooltea on 2019/6/22 10:35.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Component
@Slf4j
public class ExpiredOlayPointConsumer extends AbstractConsumer {

    private ServiceBusQueueTopicEnum EXPIRED_POINT_QUEUE_NAME = ServiceBusQueueTopicEnum.EXPIRED_POINT_USER_QUEUE_NAME;

    @Autowired
    private ExpiredPointService pointService;

    @Override
    protected void doBusiness(JSONObject message) {
        ExpiredPointMessage pointMessage = JSON.toJavaObject(message, ExpiredPointMessage.class);
        Integer expiredYear = LocalDateTime.now().plusDays(1).getYear();
        // 处理过期积分
        pointService.expiredPointByYear(pointMessage.getBrand(), pointMessage.getLoyaltyId(), (expiredYear - 2));
        // 计算即将过期积分 过期和即将过期计算顺序不能颠倒
        pointService.willExpiredPointsByYear(pointMessage.getBrand(), pointMessage.getLoyaltyId(), (expiredYear - 1));
        log.info("任务【积分过期队列】处理完成.........");
    }

    @Override
    protected String getLabel() {
        return EXPIRED_POINT_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return EXPIRED_POINT_QUEUE_NAME;
    }
}
