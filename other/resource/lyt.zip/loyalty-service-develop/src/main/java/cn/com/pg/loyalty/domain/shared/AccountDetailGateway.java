package cn.com.pg.loyalty.domain.shared;

public interface AccountDetailGateway {

    String birthday(String memberId);
}
