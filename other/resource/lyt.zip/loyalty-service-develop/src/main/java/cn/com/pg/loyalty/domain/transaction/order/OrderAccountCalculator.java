package cn.com.pg.loyalty.domain.transaction.order;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
@Getter
public class OrderAccountCalculator {
    private final LoyaltyStructure structure;
    private final Account account;
    private final List<Order> requestOrders;
    private final List<Order> associatedOrders;
    private List<Order> rollbackOrders;
    private final Map<String, Order> associatedOrderMap;

    private OrderAccountCalculator(LoyaltyStructure structure, Account account,
                                   List<Order> requestOrders, List<Order> associatedOrders) {
        this.structure = structure;
        this.account = account;
        this.requestOrders = validOrders(structure, requestOrders, associatedOrders);

        Map<String, Order> requestOrderMap = this.requestOrders.stream().collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));
        //过滤校验失败订单的关联订单
        this.associatedOrders = associatedOrders.stream()
                .filter(order -> requestOrderMap.containsKey(order.channelUnitOrderId())).collect(Collectors.toList());

        //过滤校验失败订单的关联订单
        this.associatedOrderMap = this.associatedOrders.stream().collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));
        this.inheritanceAssociateOrder(this.requestOrders, associatedOrderMap);
    }

    private void inheritanceAssociateOrder(List<Order> requestOrders, Map<String, Order> associatedOrderMap) {
        requestOrders.forEach(order -> {
            Order associatedOrder = associatedOrderMap.get(order.channelUnitOrderId());
            if (associatedOrder != null) {
                order.inheritanceOriginalInfo(associatedOrder.getId(), associatedOrder.getCreatedTime(), associatedOrder.getExpiredTime());
            }
        });
    }

    public static OrderAccountCalculator init(LoyaltyStructure structure, Account account,
                                              List<Order> requestOrders, List<Order> associatedOrders) {
        return new OrderAccountCalculator(structure, account, requestOrders, associatedOrders);
    }

    public LocalDateTime calculateEarliestRollBackTime(OrderEarliestRollBackTimeFindAble... finders) {
        return Arrays.stream(finders)
                .map(findAble -> findAble.findEarliestRollBackTime(structure.getOrderImpact(),
                        requestOrders, associatedOrderMap))
                .min(Comparator.comparing(Function.identity())).orElse(LocalDateTime.MAX);
    }

    public void rollBackAssociatedOrdersPoint() {
        rollbackOrders = associatedOrders;
        //订单时间倒序退单
        associatedOrders.sort(Comparator.comparing(Order::getOrderDateTime)
                .thenComparing(Order::getCreatedTime).reversed());
        //退积分，不退等级，等级会重新计算，退了等级会有问题(当前订单的等级会不正确，计算的时候判断升降级会有问题)
        associatedOrders.forEach(order -> account.rollBackPoint(order, structure));
    }

    public void rollBackOrders(List<Order> rollbackOrders) {
        this.rollbackOrders = rollbackOrders;
        //订单时间倒序退单
        this.rollbackOrders.sort(Comparator.comparing(Order::getOrderDateTime)
                .thenComparing(Order::getCreatedTime).reversed());
        this.rollbackOrders.forEach(order -> {
            account.rollBackPoint(order, structure);
            account.rollBackTier(order, structure);
        });
    }

    public List<Order> getCalculateOrders() {
        if (CollectionUtils.isEmpty(requestOrders)) {
            return Collections.emptyList();
        }
        return reBuildRequestOrders();
    }

    /**
     * 获取重算订单
     */
    public List<Order> getRecalculateOrders() {
        Map<String, Order> requestOrderMap = requestOrders.stream()
                .collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));

        List<Order> recalculateOrders = rollbackOrders.stream()
                .filter(order -> !requestOrderMap.containsKey(order.channelUnitOrderId())).collect(Collectors.toList());
        recalculateOrders.addAll(getRequestOrders());
        return recalculateOrders.stream().sorted(Comparator.comparing(Order::getOrderDateTime)).collect(Collectors.toList());
    }

    private List<Order> reBuildRequestOrders() {
        return requestOrders.stream().map(this::buildOrder)
                .sorted(Comparator.comparing(Order::getOrderDateTime)
                        .thenComparing(Order::getCreatedTime)).collect(Collectors.toList());
    }

    private Order buildOrder(Order order) {
        //构建订单的时候需要延迟一毫秒，否则相同订单时间的订单，createTime可能会相同，回滚订单排序会有问题
        try {
            Thread.sleep(1L);
        } catch (InterruptedException e) {
            log.error("构建订单延迟时被中断: {}", e.getMessage());
            Thread.currentThread().interrupt();
        }
        // 当没有开启退单重算时，订单有等级，继承原订单的等级
        String level = account.tier(structure.name()).getLevel();
        if (StringUtils.isNotEmpty(order.getCurrentLevel())) {
            level = order.getCurrentLevel();
        }
        Order newOrder = new Order(account.loyaltyId(), order.brand(), order.getChannel(), order.getOrderId(), structure,
                order.getOrderDateTime(), order.adapterOrderUpdateTime(), order.getOrderItems(),
                order.getRealTotalAmount(), level, account.memberId(),
                order.getStoreCode());
        if (StringUtils.isNotBlank(order.getId())) {
            newOrder.inheritanceOriginalOrder(order);
        }
        return newOrder;
    }

    private List<Order> validOrders(LoyaltyStructure structure, List<Order> requestOrders, List<Order> requestAssociatedOrders) {
        //没有orderUpdateTime的默认给orderDateTime
        Map<String, Order> orderMap = requestAssociatedOrders.stream().collect(Collectors.toMap(Order::channelUnitOrderId, Function.identity()));

        return requestOrders.stream().sorted(Comparator.comparing(Order::adapterOrderUpdateTime))
                //请求订单去重
                .filter(distinctByKey(Order::channelUnitOrderId))
                //不接受积分有效期外的订单
                .filter(order -> withinValidityPeriod(structure, order))
                //不接受订单更新时间在关联订单之前的订单
                .filter(order -> this.updatedAfterAssociatedOrder(order, orderMap))
                .collect(Collectors.toList());
    }

    private boolean withinValidityPeriod(LoyaltyStructure structure, Order order) {
        boolean within = order.getOrderDateTime().isAfter(LocalDateTime.now()
                .minusYears(structure.pointExpire().getPointEffectiveYear()).minusDays(1));
        if (within) {
            return true;
        }
        log.warn("Order within validity period:{}", order.getOrderId());
        return false;
    }

    private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    private boolean updatedAfterAssociatedOrder(Order requestOrder, Map<String, Order> associatedOrderMap) {
        Order associatedOrder = associatedOrderMap.get(requestOrder.channelUnitOrderId());
        if (Objects.isNull(associatedOrder)) {
            return true;
        }
        LocalDateTime associatedOrderUpdateTime = associatedOrder.getOrderDateTime();
        LocalDateTime requestOrderUpdateTime = requestOrder.getOrderDateTime();

        if (requestOrderUpdateTime.isBefore(associatedOrderUpdateTime)) {
            log.warn("Order update before associated:{}", requestOrder.getOrderId());
            throw new SystemException("订单时间异常", ResultCodeMapper.PARAM_ERROR);
        }
        if (associatedOrder.refundOrder() && !requestOrder.refundOrder()) {
            log.warn("Order associated is refund:{}", requestOrder.getOrderId());
            return false;
        }
        return true;
    }
}
