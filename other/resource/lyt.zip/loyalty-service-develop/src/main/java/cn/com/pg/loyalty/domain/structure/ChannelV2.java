package cn.com.pg.loyalty.domain.structure;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ChannelV2 extends Config {

    public ChannelV2(String name, String description) {
        super("CHANNEL", name, description);
    }

    public static final String INTERNAL = "INTERNAL";
    public static final String LINE = "LINE";
    public static final String COUNTER = "COUNTER";
    public static final String TMALL = "TMALL";
}
