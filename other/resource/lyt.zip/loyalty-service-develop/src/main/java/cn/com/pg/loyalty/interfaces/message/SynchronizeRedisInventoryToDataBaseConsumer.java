package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.RedemptionService;
import cn.com.pg.loyalty.application.RedemptionServiceBusProperties;
import cn.com.pg.loyalty.application.TransactionService;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.microsoft.azure.servicebus.ExceptionPhase;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author: Ysnow
 * @Date: 2019/6/13 18:31
 * @Description:
 */
@Component
@Slf4j
public class SynchronizeRedisInventoryToDataBaseConsumer extends AbstractConsumer {


    @Autowired
    private RedemptionService redemptionService;

    private final static ServiceBusQueueTopicEnum QUEUE_NAME = ServiceBusQueueTopicEnum.SYNCHRONIZE_REDIS_INVENTORY_TO_DATABASE_QUEUE_NAME;

    @Override
    protected void doBusiness(JSONObject jsonObject) {
        RedemptionServiceBusProperties updateActivityStock = JSON.toJavaObject(jsonObject, RedemptionServiceBusProperties.class);
        redemptionService.syncGiftIssued(updateActivityStock.getActivityId(), updateActivityStock.getGiftIdStockMap().keySet());
    }

    @Override
    protected String getLabel() {
        return QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return QUEUE_NAME;
    }

    @Override
    public void notifyException(Throwable throwable, ExceptionPhase exceptionPhase) {
          //Do nothing.
    }
}
