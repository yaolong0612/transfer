package cn.com.pg.loyalty.infrastructure.rule.engine;

import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class RuleContext {
    protected static final Map<RuleScope, ArrayList<RuleContext.RuleParam>> RULES = new EnumMap<>(RuleScope.class);
    protected static final Map<RuleLable, ArrayList<RuleContext.RuleParam>> LABEL_RULES = new EnumMap<>(RuleLable.class);

    public void calculateOrderPoint(RuleEngineSupportV2 ruleEngineSupportV2) {
        calculate(RuleType.ORDER, ruleEngineSupportV2);
    }

    public void calculateInteractionPoint(RuleEngineSupportV2 ruleEngineSupportV2) {
        calculate(RuleType.INTERACTION, ruleEngineSupportV2);
    }

    public void calculateRedemptionPoint(RuleEngineSupportV2 ruleEngineSupportV2) {
        ruleEngineSupportV2.skipOnFirstFailedRule(true);
        ruleEngineSupportV2.throwExceptionAfterFail();
        calculate(RuleType.REDEMPTION, ruleEngineSupportV2);
    }

    public void calculateTier(RuleEngineSupportV2 ruleEngineSupportV2) {
        calculate(RuleType.TIER, ruleEngineSupportV2);
    }

    private void calculate(RuleType type, RuleEngineSupportV2 ruleEngineSupportV2) {
        //计算前执行前置操作
        registryRulesAndFire(RuleScope.BEFORE_LIMIT_RULE, type, ruleEngineSupportV2);
        if (ruleEngineSupportV2.getRuleResult().isEndTag()) {
            return;
        }
        //计算
        registryRulesAndFire(RuleScope.CALCULATE_RULE, type, ruleEngineSupportV2);
        if (ruleEngineSupportV2.getRuleResult().isEndTag()) {
            return;
        }
        //后置操作
        registryRulesAndFire(RuleScope.AFTER_LIMIT_RULE, type, ruleEngineSupportV2);
    }

    public void calculateLabelRule(RuleLable ruleLable, RuleType ruleType, RuleEngineSupportV2 ruleEngineSupportV2) {
        //根据RuleLabel执行规则
        ruleEngineSupportV2.skipOnFirstFailedRule(true);
        ruleEngineSupportV2.throwExceptionAfterFail();
        registryRulesAndFireWithRuleLabel(ruleLable, ruleType, ruleEngineSupportV2);
    }

    private void registryRulesAndFire(RuleScope calculateRule, RuleType ruleType, RuleEngineSupportV2 ruleEngineSupportV2) {
        List<Object> rules = RULES.get(calculateRule).stream()
                .filter(ruleParam -> ruleType.equals(ruleParam.ruleType) || RuleType.ALL.equals(ruleParam.ruleType))
                .map(ruleParam -> ruleParam.rule)
                .collect(Collectors.toList());
        ruleEngineSupportV2.buildRulesEngineSupport(rules);
        ruleEngineSupportV2.fire();
    }

    private void registryRulesAndFireWithRuleLabel(RuleLable ruleLable, RuleType ruleType, RuleEngineSupportV2 ruleEngineSupportV2) {
        List<Object> rules = LABEL_RULES.get(ruleLable).stream()
                .filter(ruleParam -> ruleType.equals(ruleParam.ruleType) || RuleType.ALL.equals(ruleParam.ruleType))
                .map(ruleParam -> ruleParam.rule)
                .collect(Collectors.toList());
        ruleEngineSupportV2.buildRulesEngineSupport(rules);
        ruleEngineSupportV2.fire();
    }

    protected static void initContext() {
        RULES.clear();
        RULES.put(RuleScope.BEFORE_LIMIT_RULE, new ArrayList<>());
        RULES.put(RuleScope.CALCULATE_RULE, new ArrayList<>());
        RULES.put(RuleScope.AFTER_LIMIT_RULE, new ArrayList<>());
    }

    protected static void initContextWithLabel(){
        LABEL_RULES.clear();
        LABEL_RULES.put(RuleLable.REDMPTION, new ArrayList<>());
        LABEL_RULES.put(RuleLable.GROUP, new ArrayList<>());
        LABEL_RULES.put(RuleLable.GRADE, new ArrayList<>());
    }

    protected static class RuleParam {
        private RuleScope ruleScope;
        private RuleType ruleType;
        private RuleLable[] ruleLables;
        private Object rule;

        public RuleParam(RuleScope ruleScope, RuleType ruleType, RuleLable[] ruleLables, Object rule) {
            this.ruleScope = ruleScope;
            this.ruleType = ruleType;
            this.ruleLables = ruleLables;
            this.rule = rule;
        }

    }
}
