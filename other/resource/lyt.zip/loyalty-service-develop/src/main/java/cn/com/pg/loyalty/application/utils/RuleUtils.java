package cn.com.pg.loyalty.application.utils;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/7
 */
@Slf4j
public class RuleUtils {

    /**
     * 获取指定积分模板且目标时间时间在活动期内的活动，按优先级从大到小排序返回
     *
     * @param activityList    活动列表
     * @param aimDateTime     目标时间
     * @param aimRuleTemplate 指定积分模板
     * @return
     */
    public static List<Activity> fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(List<Activity> activityList, LocalDateTime aimDateTime, RuleTemplate aimRuleTemplate) {
        return activityList.stream().filter(activity ->
                activity.getRuleTemplate() == aimRuleTemplate && isInPeriod(activity.getStartAt(), activity.getEndAt(), aimDateTime)
        )
                .sorted(Comparator.comparing(Activity::getPriority).reversed())
                .collect(Collectors.toList());
    }


    /**
     * 判断目标时间是否在开始结束期间内
     *
     * @param startTime
     * @param endTime
     * @param aimTime
     * @return
     */
    public static boolean isInPeriod(LocalDateTime startTime, LocalDateTime endTime, LocalDateTime aimTime) {
        //下面的表达式等价于(aimTime.isAfter(startTime)||aimTime.equals(startTime)) && (aimTime.isBefore(endTime)||aimTime.equals(endTime))
        return !aimTime.isBefore(startTime) && !aimTime.isAfter(endTime);
    }

    private RuleUtils() {
    }
}
