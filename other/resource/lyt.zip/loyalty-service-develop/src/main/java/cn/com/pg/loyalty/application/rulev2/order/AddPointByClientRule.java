package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author vincenzo
 * @description
 * @date 2021/12/22
 */
@Rule(name = "ORDER_ADJUST_POINT_BY_CLIENT_V2",
        description = "calculate the point by each purchase order")
@Slf4j
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class AddPointByClientRule {
    private RuleTemplate ruleTemplate = RuleTemplate.ORDER_ADJUST_POINT_BY_CLIENT_V2;


    /**
     * 匹配到动态调整积分模板，并且传入积分大于0
     *
     * @param activityList
     * @param order
     * @param point
     * @return
     */
    @Condition
    public boolean matchRule(@Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                             @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                             @Fact(RuleParamNameConfig.RULE_PARAM_POINT_STR) Integer point) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        if (CollectionUtils.isNotEmpty(searchedActivityList) && point > 0) {
            log.info("满足Order动态调整 orderId:{}积分 传入point:{}", order.getOrderId(), point);
            //匹配到活动且传入point大于0，返回true执行加积分
            return Boolean.TRUE;
        }
        log.info("不满足Order动态调整 orderId:{} 传入point:{}，活动数:{}", order.getOrderId(), point, searchedActivityList.size());
        return Boolean.FALSE;
    }

    /**
     * @param ruleResult
     */
    @Action
    public void addPoint(
            @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
            @Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
            @Fact(RuleParamNameConfig.RULE_PARAM_POINT_STR) Integer point,
            @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
            @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult
    ) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        Activity activity = searchedActivityList.get(0);
        PointItem pointItem = new PointItem(point, activity.description(), activity.activityId());
        //动态调整积分一定不做竞争
        competePointItems.put(pointItem, Boolean.FALSE);
        //设置success才能执行下一流程
        ruleResult.success();
    }
}
