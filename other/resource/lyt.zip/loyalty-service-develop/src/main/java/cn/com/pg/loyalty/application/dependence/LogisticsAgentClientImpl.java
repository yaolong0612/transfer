package cn.com.pg.loyalty.application.dependence;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RedemptionItem;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.GiftItem;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @description:
 * @author: Artermus wang on 2022-09-19 16:18
 */
@Slf4j
@Component
public class LogisticsAgentClientImpl{
    @Autowired
    private LogisticsAgentClient client;
    @Autowired
    private CacheService cacheService;
    public static final String FIXED_LOGISTICS_GIFT_ID = "10086";
    public static final String DINGTAI_CHANNEL = "DINGTAI";

    public LogisticsAgentClient.Response createOrder(Redemption redemption, Activity activity, String memberId,
                                                     String addressCode){
        RedemptionProperties properties = (RedemptionProperties) activity.ruleProperties();
        if (DeliveryChannel.LOGISTICS == properties.getDeliveryChannel()) {
            return ylytOrder(redemption, activity, memberId, addressCode);
        }
        if (DeliveryChannel.LOGISTICS_DINGTAI == properties.getDeliveryChannel()) {
            return dingTaiOrder(redemption, activity, memberId, addressCode);
        }
        return new LogisticsAgentClient.Response();
    }

    private LogisticsAgentClient.Response dingTaiOrder(Redemption redemption, Activity activity, String memberId, String addressCode) {
        String tenantId = cacheService.findLoyaltyStructureById(activity.getLoyaltyStructure()).getAmTenantId();
        LogisticsAgentClient.TenantId tenantId1 = new LogisticsAgentClient.TenantId(tenantId);
        LogisticsAgentClient.CreateOrderCommand createOrderCommand = getCreateOrderCommand(redemption, activity, memberId, addressCode);
        createOrderCommand.setTenantId(tenantId1);
        createOrderCommand.setDistributor(DINGTAI_CHANNEL);
        return client.generate(createOrderCommand);
    }

    private LogisticsAgentClient.Response ylytOrder(Redemption redemption, Activity activity, String memberId, String addressCode) {
        LogisticsAgentClient.CreateOrderCommand createOrderCommand = getCreateOrderCommand(redemption, activity, memberId, addressCode);
        return client.create(createOrderCommand);
    }

    private LogisticsAgentClient.CreateOrderCommand getCreateOrderCommand(Redemption redemption, Activity activity, String memberId, String addressCode) {
        //创建物流订单中的product
        List<LogisticsAgentClient.Product> productList = new ArrayList<>(4);
        Map<String, RedemptionItem> redemptionItemMap = activity.getGifts();
        List<GiftItem> giftItemList = redemption.getGiftItemList();
        for (GiftItem giftItem : giftItemList) {
            LogisticsAgentClient.Product product = new LogisticsAgentClient.Product();
            RedemptionItem redemptionItem = redemptionItemMap.get(giftItem.getGiftId());
            //logisticsGiftId为一个特定值时不调用物流微服务
            if (FIXED_LOGISTICS_GIFT_ID.equals(redemptionItem.logisticsGiftId())) {
                continue;
            }
            product.createProduct(redemptionItem.logisticsGiftId(), giftItem.getQuantity());
            Gift gift = cacheService.getGiftById(giftItem.getGiftId());
            if(gift != null) {
                product.setImageUrl(gift.getImageUri());
            }
            productList.add(product);
        }

        //创建物流订单
        LogisticsAgentClient.CreateOrderCommand createOrderCommand = new LogisticsAgentClient.CreateOrderCommand();
        createOrderCommand.createOrder(redemption.getId(), false, redemption.getBrand(), memberId, activity.logisticsActivityId(), productList, redemption.getReceiver(), redemption.getPhone(), redemption.getProvince(), redemption.getCity(), redemption.getDistrict(), redemption.getAddress());
        if (StringUtils.isNotBlank(addressCode)) {
            createOrderCommand.setAddressCode(addressCode);
        }
        return createOrderCommand;
    }
}
