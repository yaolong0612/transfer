package cn.com.pg.loyalty.application.rulev2.order;

import cn.com.pg.loyalty.application.utils.RuleUtils;
import cn.com.pg.loyalty.constant.RuleParamNameConfig;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.activity.prop.AddOrderPointBySkuProperties;
import cn.com.pg.loyalty.domain.activity.prop.AddOrderPointBySkuProperties.AddSkuTimesLimit;
import cn.com.pg.loyalty.domain.activity.prop.AddOrderPointBySkuProperties.OrdersTimesLimit;
import cn.com.pg.loyalty.domain.shared.RuleResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderItem;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.PointItem;
import cn.com.pg.loyalty.infrastructure.rule.engine.Register;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleScope;
import cn.com.pg.loyalty.infrastructure.rule.engine.RuleType;
import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.jeasy.rules.annotation.Action;
import org.jeasy.rules.annotation.Condition;
import org.jeasy.rules.annotation.Fact;
import org.jeasy.rules.annotation.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static cn.com.pg.loyalty.constant.RuleParamNameConfig.RULE_PARAM_NAME_ACCOUNT;
import static cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils.getFirstDayOfThisMonth;
import static cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils.getLastDayOfThisMonth;

/**
 * @description: skii  CCSD-10157 空瓶回收
 * @author: Artermus wang on 2022-06-27 09:47
 */
@Slf4j
@Rule(name = "AddOrderPointBySkuRule",
        description = "calculate the point by sku")
@Component
@Register(scope = RuleScope.CALCULATE_RULE, ruleType = RuleType.ORDER)
public class AddOrderPointBySkuRule {

    @Autowired
    private OrderRepositoryV2 orderRepositoryV2;

    private static final RuleTemplate ruleTemplate = RuleTemplate.ORDER_ADD_POINT_BY_SKU_RULE;
    private AddOrderPointBySkuProperties properties;
    private Activity activity;

    @Condition
    public boolean validateRule(@Fact("order") Order order,
                                @Fact(RuleParamNameConfig.RULE_PARAM_ACTIVITIES) List<Activity> activityList,
                                @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure loyaltyStructure) {
        List<Activity> searchedActivityList = RuleUtils.fetchActivitiesByRuleTemplateAndAimTimeSortByPriorityDesc(activityList, order.getOrderDateTime(), ruleTemplate);
        if (CollectionUtils.isEmpty(searchedActivityList)) {
            log.info("匹配到根据sku计算积分活动数：{}", searchedActivityList.size());
            return Boolean.FALSE;
        }
        activity = searchedActivityList.get(0);
        properties = JSON.parseObject(activity.getRuleProperties(), AddOrderPointBySkuProperties.class);
        return specifySkuCount(order, loyaltyStructure) > 0;
    }

    @Action
    public void calculate(@Fact(RuleParamNameConfig.RULE_PARAM_NAME_ORDER) Order order,
                          @Fact(RULE_PARAM_NAME_ACCOUNT) Account account,
                          @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_POINT_ITEMS) Map<PointItem, Boolean> competePointItems,
                          @Fact(RuleParamNameConfig.RULE_PARAM_COMPETE_RULE_RESULT) RuleResult ruleResult,
                          @Fact(RuleParamNameConfig.RULE_PARAM_LOYALTY_STRUCTURE) LoyaltyStructure loyaltyStructure) {
        // 当前订单有多少个sku需要加积分
        int orderContainSkuQty = specifySkuCount(order, loyaltyStructure);
        // 有多少个sku可以加积分
        int count = calculateLimitAddSkuTimes(account, order, orderContainSkuQty, loyaltyStructure);
        PointItem pointItem = new PointItem(properties.getBasePoint() * count, activity.getDescription(), activity.activityId());
        competePointItems.put(pointItem, Boolean.FALSE);
        ruleResult.success();
    }

    /**
     * 判断是否符合订单限制规则，如180天内至少有1个订单
     */
    private boolean matchLimitOrders(Account account, Order currentOrder) {
        OrdersTimesLimit ordersTimesLimit = properties.getOrdersTimesLimit();
        if (ordersTimesLimit == null) {
            return true;
        }
        LocalDateTime endAt = currentOrder.getOrderDateTime();
        LocalDateTime startAt = endAt.minusDays(ordersTimesLimit.getLimitOrderTimesInDays());
        List<Order> orders = orderRepositoryV2.findOrdersByOrderDateTimeBetween(account.loyaltyId(), startAt, endAt);
        int count = (int) orders.stream().filter(order -> !order.groupPurchaseIs())
                .filter(order -> order.realTotalAmount() > 0).count();
        return count >= ordersTimesLimit.getLimitOrderTimes();
    }

    /**
     * 计算在限制时间内已经有多少个sku加了积分
     *
     * @return 还可以加积分的sku个数
     */
    private int calculateLimitAddSkuTimes(Account account, Order currentOrder, int orderContainSkuQty, LoyaltyStructure loyaltyStructure) {
        if (!matchLimitOrders(account, currentOrder)) {
            return 0;
        }
        AddSkuTimesLimit addSkuTimesLimit = properties.getAddSkuTimesLimit();
        // 没有限制多少个sku加积分，所有订单中的sku都加
        if (addSkuTimesLimit == null) {
            return orderContainSkuQty;
        }
        LocalDateTime startAt = currentOrder.getOrderDateTime().minusMonths(addSkuTimesLimit.getLimitAddSkuMonth() - 1L);
        List<Order> orders = orderRepositoryV2.findOrdersByOrderDateTimeBetween(account.loyaltyId(),
                getFirstDayOfThisMonth(startAt), getLastDayOfThisMonth(currentOrder.getOrderDateTime()));
        List<Order> effectiveOrders = orders.stream().filter(order -> order.point() > 0).collect(Collectors.toList());
        // 限制时间内内已经有多少个sku加了积分
        int count = effectiveOrders.stream().mapToInt(order -> specifySkuCount(order, loyaltyStructure)).sum();
        // 取当前订单添加的sku个数 和 还剩余的可以添加的个数中小的那个
        int min = Math.min(addSkuTimesLimit.getLimitAddSkuNum() - count, orderContainSkuQty);
        return Math.max(min, 0);
    }

    /**
     * 计算订单内包含的指定的sku的个数
     */
    private int specifySkuCount(Order order, LoyaltyStructure loyaltyStructure) {
        Set<OrderItem> orderItems = order.getOrderItems();
        if (loyaltyStructure.checkMlBrand(order.getBrand()) && order.realTotalAmount() == 0) {
            return orderItems.stream().mapToInt(orderItem -> {
                if (orderItem.getSku().equals(properties.getSku())) {
                    return orderItem.getPurchaseQty();
                }
                return 0;
            }).sum();
        }
        return 0;
    }
}
