package cn.com.pg.loyalty.domain.activity;

import cn.com.pg.loyalty.domain.shared.ValueObject;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Objects;
import java.util.Optional;

/**
 * @author cooltea on 2019/8/20 11:02.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明： 扫码sku
 * 扫码这个sku 可获得积分 = basePoint * multiple + extraPoint
 */
@Getter
@Setter
@NoArgsConstructor
@Slf4j
public class QrcodeItem implements ValueObject<QrcodeItem> {

    /**
     * sku
     */
    private String sku;
    /**
     * sku类型
     */
    private ProductTypeEnum productType;

    /**
     * 扫码这个sku可获得的基础积分
     */
    private Integer basePoint;
    /**
     * 扫码这个sku额外可加积分
     */
    private Integer extraPoint;
    /**
     * 基础积分倍数
     */
    private Float multiple;
    /**
     * 描述
     */
    private String description;

    public QrcodeItem(String sku, ProductTypeEnum typeEnum, Integer basePoint, String description) {
        this.sku = sku;
        this.productType = typeEnum;
        this.basePoint = basePoint;
        this.description = description;
        this.multiple = 0.0f;
        this.extraPoint = 0;
    }

    @Override
    public boolean sameValueAs(QrcodeItem other) {
        return this.equals(other);
    }

    public QrcodeItem(String sku, ProductTypeEnum peoductType, Integer basePoint, Integer extraPoint, Float multiple, String description) {
        this.sku = sku;
        this.productType = peoductType;
        this.basePoint = basePoint;
        this.extraPoint = extraPoint;
        this.multiple = multiple;
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o){
            return true;
        }
        if (o == null || getClass() != o.getClass()){
            return false;
        }
        QrcodeItem qrcodeItem = (QrcodeItem) o;

        return new EqualsBuilder()
                .append(sku,         qrcodeItem.sku)
                .append(productType, qrcodeItem.productType)
                .append(basePoint,   qrcodeItem.basePoint)
                .append(extraPoint,  qrcodeItem.extraPoint)
                .append(multiple,    qrcodeItem.multiple)
                .append(description, qrcodeItem.description)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(sku)
                .append(productType)
                .append(basePoint)
                .append(extraPoint)
                .append(multiple)
                .append(description)
                .toHashCode();
    }

    public boolean equalsThisSku(String sku) {
        return this.sku.equalsIgnoreCase(sku);
    }

    public boolean productTypeIsThisType(ProductTypeEnum typeEnum) {
        return this.productType == typeEnum;
    }
    public Integer basePoint() {
        return Optional.ofNullable(this.basePoint).orElse(0);
    }
    public enum ProductTypeEnum {
        /**
         * OLAY 使用基础默认
         */
        BASIC,
        /**
         * OLAY 使用 额外，
         */
        WHIPS,
        /**
         * 帮宝适使用拉拉裤
         * 譬如帮宝适大陆首次拉拉裤扫码额外可加250积分
         */
        TAPE,
        /**
         * 帮宝适使用
         */
        PANTS,
        /**
         * OralB使用
         */
        NORMAL

    }
}
