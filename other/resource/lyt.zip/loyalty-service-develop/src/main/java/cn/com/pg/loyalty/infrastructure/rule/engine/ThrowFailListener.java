package cn.com.pg.loyalty.infrastructure.rule.engine;

import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import lombok.extern.slf4j.Slf4j;
import org.jeasy.rules.api.Facts;
import org.jeasy.rules.api.Rule;
import org.jeasy.rules.api.RuleListener;

import java.lang.reflect.InvocationTargetException;

@Slf4j
public class ThrowFailListener implements RuleListener {
    ThrowFailListener() {
    }

    @Override
    public boolean beforeEvaluate(Rule rule, Facts facts) {
        return true;
    }

    @Override
    public void afterEvaluate(Rule rule, Facts facts, boolean evaluationResult) {
        String ruleName = rule.getName();
        if (evaluationResult) {
            log.info("Rule '{}' triggered", ruleName);
        } else {
            log.info("Rule '{}' has been evaluated to false, it has not been executed", ruleName);
        }

    }

    @Override
    public void beforeExecute(Rule rule, Facts facts) {
    }

    @Override
    public void onSuccess(Rule rule, Facts facts) {
        log.info("Rule '{}' performed successfully", rule.getName());
    }

    @Override
    public void onFailure(Rule rule, Facts facts, Exception exception) {
        log.warn("Rule '" + rule.getName() + "' performed with error", exception);
        Throwable targetException = exception;

        if (exception instanceof InvocationTargetException) {
            targetException = ((InvocationTargetException) exception).getTargetException();
        }
        if (targetException instanceof SystemException) {
            throw (SystemException) targetException;
        }
        throw new SystemException(exception.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
    }
}
