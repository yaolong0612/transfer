package cn.com.pg.loyalty.application.utils;

import cn.com.pg.loyalty.domain.activity.prop.NumMappingPoint;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author cooltea on 2019/9/6 11:28.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Slf4j
public class LimitTimeUtils {

    /**
     * 天数
     */
    private static final int ONE_DAY = 1;
    private static final int THREE_MONTH_DAYS = 3 * 30;
    private static final int SIX_MONTH_DAYS = 6 * 30;
    /**
     * ml扫码限制次数
     */
    private static final int ML_PAMPERS_ONE_DAY_LIMIT_TIMES = 3;
    private static final int ML_PAMPERS_THREE_MONTH_LIMIT_TIMES = 10;
    private static final int ML_PAMPERS_SIX_MONTH_LIMIT_TIMES = 20;

    /**
     * hktw扫码限制次数
     */
    private static final int HKTW_PAMPERS_ONE_DAY_LIMIT_TIMES = 5;
    private static final int HKTW_PAMPERS_THREE_MONTH_LIMIT_TIMES = 36;
    private static final int HKTW_PAMPERS_SIX_MONTH_LIMIT_TIMES = 72;

    public static Map<Integer, Long> checkLimit(List<? extends Transaction> historyTransactions, List<NumMappingPoint> numMappingPoints) {
        Optional<NumMappingPoint> optionalMaxNum = numMappingPoints.stream().max(Comparator.comparing(NumMappingPoint::num));
        int maxNum = optionalMaxNum.isPresent() ? optionalMaxNum.get().num() : 0;
        Map<Integer, Long> numSizeMap = new HashMap<>();
        Long sumTimes = 0L;
        LocalDate localDate = LocalDate.now();
        Map<String, Long> dayCount = historyTransactions.stream()
                .collect(Collectors.groupingBy(redemption -> redemption.getCreatedTime().toLocalDate().toString(), Collectors.counting()));
        for (int i = 0; i < maxNum; i++) {
            sumTimes += Optional.ofNullable(dayCount.get(localDate.toString())).orElse(0L);
            localDate = localDate.minusDays(1);
            numSizeMap.put(i+1, sumTimes);
        }
        if (numSizeMap.size() > 0) {
            for (NumMappingPoint numMappingPoint: numMappingPoints) {
                if (Optional.ofNullable(numSizeMap.get(numMappingPoint.num())).orElse(-1L) >= numMappingPoint.pointOrSize()) {
                    log.info("超过次数限制, {}天内{}次, 不包含本次之前共: {}次", numMappingPoint.num(), numMappingPoint.getPointOrSize(), numSizeMap.get(numMappingPoint.num()));
                    throw new SystemException("The upper limit of scanning times is exceeded", ResultCodeMapper.LIMIT_ERROR);
                }
            }
        }
        return numSizeMap;
    }

    public static List<NumMappingPoint> fetchMlPampersScanLimit() {
        return Arrays.asList(
                new NumMappingPoint(ONE_DAY, ML_PAMPERS_ONE_DAY_LIMIT_TIMES),
                new NumMappingPoint(THREE_MONTH_DAYS, ML_PAMPERS_THREE_MONTH_LIMIT_TIMES),
                new NumMappingPoint(SIX_MONTH_DAYS, ML_PAMPERS_SIX_MONTH_LIMIT_TIMES));
    }

    public static List<NumMappingPoint> fetchHktwPampersScanLimit() {
        return Arrays.asList(
                new NumMappingPoint(ONE_DAY, HKTW_PAMPERS_ONE_DAY_LIMIT_TIMES),
                new NumMappingPoint(THREE_MONTH_DAYS, HKTW_PAMPERS_THREE_MONTH_LIMIT_TIMES),
                new NumMappingPoint(SIX_MONTH_DAYS, HKTW_PAMPERS_SIX_MONTH_LIMIT_TIMES));
    }
}
