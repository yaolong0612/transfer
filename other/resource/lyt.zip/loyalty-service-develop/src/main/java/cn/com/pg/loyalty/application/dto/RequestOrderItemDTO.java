package cn.com.pg.loyalty.application.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;

/**
 * @description:
 * @author: Jevons Chen
 * @date: 2019-08-12 3:04
 */

@Getter
@Setter
@ToString
public class RequestOrderItemDTO {

    /**
     * 商品编号
     */
    @NotNull
    private String sku;
    /**
     * 剩余购买数量
     */
    private Integer purchaseQty = 0;
    /**
     * 退的数量
     */
    private Integer refundQty = 0;
    /**
     * 商品单价
     */
    private Double retailAmount = 0.0;
    /**
     * 该商品实付金额
     */
    private Double realAmount = 0.0;
    /**
     * 退款金额
     */
    private Double refundAmount = 0.0;

    private String skuQty;

    private String lineItemNo;

    private String transactionType;
}
