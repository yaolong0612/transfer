package cn.com.pg.loyalty.interfaces.message;


/**
 * @Author tangjia
 */
public interface Task {

    /**
     * 监听service bus中来自调度中心的方法,有需要从service bus中获取相关消息的需求,需要实现此接口
     *使用 message.getMessageBody().getValueData() 获取到消息体内容
     *实现类若是有异常情况,则直接抛出
     * @param brand   品牌
     * @param message 消息体
     * @param region  地区
     */
    void excute(String brand, String region, String message);

}
