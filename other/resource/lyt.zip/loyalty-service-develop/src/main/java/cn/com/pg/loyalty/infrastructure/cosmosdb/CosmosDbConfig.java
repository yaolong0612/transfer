package cn.com.pg.loyalty.infrastructure.cosmosdb;

import com.microsoft.azure.spring.data.cosmosdb.core.mapping.Document;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * @author 		Young
 * @date   		2019年4月9日上午11:21:04
 * @description 助力封装
 */
@Component
@Slf4j
public class CosmosDbConfig {
	/**
	 * 集合链接地址模板
	 */
	private static final String  COLLECTION_LINK_TEMPLATE="/dbs/%s/colls/%s";
	/**
	 * 文档链接地址模板
	 */
	private static final String  DOCUMENT_LINK_TEMPLATE="/dbs/%s/colls/%s/docs/%s";
	/**
	 * 数据库名称
	 */
	@Value("${azure.cosmosdb.database:LoyaltyService}")
	private String configDbName;

	@PostConstruct
	public void init() {
		log.info("CosmosDbUtils初始化数据库名称: {}", configDbName);
		if (StringUtils.isBlank(configDbName)) {
			configDbName = "LoyaltyService";
		}
	}

	/**
	 * @param   clz
	 * @return  返回该类对应的Collection在CosmosDb中的链接地址
	 */
	public String getCollectionLink(Class<?> clz) {
		Document annotation = clz.getAnnotation(Document.class);
		String collectionName = annotation.collection();
		return String.format(COLLECTION_LINK_TEMPLATE, configDbName, collectionName);
	}

	public String getDocumentLink(Class<?> clz, String id) {
		Document annotation = clz.getAnnotation(Document.class);
		String collectionName = annotation.collection();
		return String.format(DOCUMENT_LINK_TEMPLATE, configDbName, collectionName, id);
	}
}