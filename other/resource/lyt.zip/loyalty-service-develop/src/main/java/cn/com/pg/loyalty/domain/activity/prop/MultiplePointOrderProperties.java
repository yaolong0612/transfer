package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class MultiplePointOrderProperties extends RuleProperties {
    /**
     * 参与竞争
     */
    private boolean competition;
    /**
     * 奖励积分上限
     */
    private Integer upperLimitPoint;
    /**
     * 参与渠道
     */
    private List<ChannelSet3> channels = new ArrayList<>();
}
