package cn.com.pg.loyalty.domain.activity.prop;

import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderItem;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Data
public class ChannelSet3 {

    /**
     *
     */
    String channel;
    /**
     * 第几单可以参与奖励
     * 包含-1表示全部可参与
     */
    private List<Integer> partakeOrders = new ArrayList<>();

    /**
     * 距首次购买的时间限制
     */
    private ChannelSet3.TIME_PERIOD_TYPE timePeriodType;

    /**
     * 如配置timePeriodType：MONTH, timePeriod: 4，即表示距首次购买4个月内
     */
    private Integer timePeriod;


    /**
     * 参与条件
     * 若是没配置，则表示无等级限制
     */
    private List<String> tierLimit = new ArrayList<>();
    /**
     * 等级和积分条件是否共存关系，默认值为并存
     */
    private Relation pointTierRelation = Relation.OR;
    /**
     * 账户积分限制，需要满足多少积分才能参与活动
     * 不配置则表示无此限制
     */
    private Integer pointLimit;
    /**
     * 倍数的类型  包含固定和浮动
     */
    private Type multipleType;

    /**
     * 固定倍率下才有值
     */
    private Double multipleTimes = 1.0;
    /**
     * 金额上限
     * 只有浮动倍数的时候才会有
     */
    private Integer upperLimitMoney;
    /**
     * 金额上限对应的倍数
     * 只有浮动倍数的时候才会有值
     */
    private Integer moreLimitMoneyMultiple;
    /**
     * 满足金额后的积分倍数
     * multipleType若是浮动  则可以有多个倍数
     * key表示满足多少金额
     */
    private List<ChannelSet3.LimitMoneyAndMultiple> multiple;
    /**
     * 首单限制时间
     */
    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime inspectionTime;

    public enum Type {
        REGULAR,
        FLOAT
    }

    public enum TIME_PERIOD_TYPE {
        MONTH,
        DAY
    }

    @Setter
    @Getter
    public static class LimitMoneyAndMultiple {
        private Double money;
        private Double multiple;

    }


    /**
     * 指定柜台多倍积分
     * 包含或者排出
     */
    private List<StoreCode> storeCodeConfig;

    /**
     * CONDITION_ALL_MATCH 表示作为条件需要全部匹配
     * CALCULATE 作为算分的条件参与计算
     */
    private SkuEnum skuParticipateType;

    private List<SkuCode> skuConfig;


    @Setter
    @Getter
    public static class StoreCode {
        private Scope scope;
        private String storeCodes;
        private List<String> storeType;
    }


    @Setter
    @Getter
    public static class SkuCode {
        private Scope scope;
        private String skus;
        private int purchaseQty;
    }

    public enum Relation {
        AND,
        OR
    }

    public enum Scope {
        INCLUDE {
            @Override
            public Boolean matchSkuCondition(Order order, ChannelSet3 channelSet3) {
                List<String> skuList = extractSkuList(channelSet3, INCLUDE);
                List<Boolean> skuConditionResult = new ArrayList<>();
                if (SkuEnum.CONDITION_ALL_MATCH.equals(channelSet3.getSkuParticipateType()) && order.containsSkuAll(skuList)) {
                    //如果key是INCLUDE且需要全部匹配，则订单的sku全部需要包含在配置的字符串中方可满足条件
                    skuConditionResult.add(Boolean.TRUE);
                }
                //如果key是INCLUDE且只需要部分匹配，则sku只需要包含在配置的字符串中方可满足条件
                skuConditionResult.add(order.containsSkuAny(skuList));
                int skuPurchaseQtyConfig = channelSet3.getSkuConfig().stream().mapToInt(SkuCode::getPurchaseQty).sum();
                int purchaseQty = order.getOrderItems().stream().filter(item -> skuList.contains(item.getSku()))
                        .mapToInt(OrderItem::getPurchaseQty).sum();
                // 购买件数超过配置的件数，满足加积分的条件
                skuConditionResult.add(purchaseQty >= skuPurchaseQtyConfig);
                return !skuConditionResult.contains(Boolean.FALSE);
            }
        },
        EXCLUDE {
            @Override
            public Boolean matchSkuCondition(Order order, ChannelSet3 channelSet3) {
                List<String> skuList = extractSkuList(channelSet3, EXCLUDE);
                List<Boolean> skuConditionResult = new ArrayList<>();
                //如果key是EXCLUDE,则柜台编号必须不再配置的字符串中方可
                if (ChannelSet3.SkuEnum.CONDITION_ALL_MATCH.equals(channelSet3.getSkuParticipateType()) && !order.containsSkuAll(skuList)) {
                    //如果key是EXCLUDE且需要全部匹配，则订单的sku需要全部不在指定的sku中才返回true
                    skuConditionResult.add(Boolean.TRUE);
                }
                //如果key是EXCLUDE且需要部分匹配，则订单的sku全部需要包含在配置的字符串中方可满足条件
                skuConditionResult.add(order.notContainsSkuAny(skuList));
                return !skuConditionResult.contains(Boolean.FALSE);
            }
        };

        public List<String> extractSkuList(ChannelSet3 channelSet3, Scope scope){
            return channelSet3.getSkuConfig().stream()
                    .filter(item -> scope.equals(item.getScope()))
                    .map(this::extractSkuList)
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        }

        public List<String> extractSkuList(SkuCode skuCode){
            if(Objects.isNull(skuCode) || StringUtils.isEmpty(skuCode.getSkus())) {
                return new ArrayList<>();
            }
            return Arrays.asList(StringUtils.split(skuCode.getSkus(), ","));
        }

        public abstract Boolean matchSkuCondition(Order order, ChannelSet3 channelSet3);
    }

    public enum SkuEnum {
        CONDITION_ALL_MATCH,
        CALCULATE
    }
}
