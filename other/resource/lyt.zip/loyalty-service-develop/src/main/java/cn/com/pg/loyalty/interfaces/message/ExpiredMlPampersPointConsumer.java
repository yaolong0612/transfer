package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.ExpiredPointService;
import cn.com.pg.loyalty.application.dependence.ExpiredPointMessage;
import cn.com.pg.loyalty.application.dependence.ServiceBusQueueTopicEnum;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/**
 * @author cooltea on 2019/6/22 10:35.
 * @version 1.0
 * @email cooltea007@163.com
 */

@Component
@Slf4j
public class ExpiredMlPampersPointConsumer extends AbstractConsumer {

    private ServiceBusQueueTopicEnum EXPIRED_POINT_QUEUE_NAME = ServiceBusQueueTopicEnum.EXPIRED_PAMPERS_POINT_USER_QUEUE_NAME;

    private final static LocalDateTime ML_PAMPERS_EXPIRED_START_DATE = LocalDate.of(2019, 10, 1).atTime(LocalTime.MIN);

    @Autowired
    private ExpiredPointService pointService;

    @Override
    protected void doBusiness(JSONObject message) {
        ExpiredPointMessage pointMessage = JSON.toJavaObject(message, ExpiredPointMessage.class);
        if (LocalDateTime.now().isBefore(ML_PAMPERS_EXPIRED_START_DATE)) {
            //因为系统需要在10月1日前全量算一次即将过期积分，但是9月1日前的过期积分是aimia计算的，loyalty不应该重复计算，所以才加这个判断
            log.info("积分系统从2019年10月1日开始算积分过期");
            return;
        }
        // 处理过期积分
        LocalDate expiredMonth = LocalDateTime.now().toLocalDate().minusMonths(1);
        pointService.expiredPointByMonth(pointMessage.getBrand(), pointMessage.getLoyaltyId(), expiredMonth.getYear(), expiredMonth.getMonthValue());
        // 处理即将过期积分
        expiredMonth = LocalDateTime.now().toLocalDate();
        pointService.willExpiredPointsByMonth(pointMessage.getBrand(), pointMessage.getLoyaltyId(), expiredMonth.getYear(), expiredMonth.getMonthValue());
        log.info("任务【积分帮宝适过期队列】处理完成.........");
    }

    @Override
    protected String getLabel() {
        return EXPIRED_POINT_QUEUE_NAME.queueOrTopicName();
    }

    @Override
    protected ServiceBusQueueTopicEnum getQueueSubscribeEnum() {
        return EXPIRED_POINT_QUEUE_NAME;
    }
}
