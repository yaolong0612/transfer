package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.Transaction.PointTypeEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@NoArgsConstructor
public class InteractionMessage {

    private String memberId;

    private String brand;

    private String channel;

    private String region;

    private String pointType;

    private Integer point;

    private String adjustReason;

    private ValueType valueType;

    private String uuid;

    private String activityId;

    @JsonFormat(pattern = LoyaltyDateTimeUtils.UNIFORM_DATE_TIME_PATTERN)
    private LocalDateTime createdTime=LocalDateTime.now();


    public static InteractionMessage createDefault(LoyaltyStructure structure,
                                                   String memberId, String pointType, Integer point,
                                                   String adjustReason) {
        InteractionMessage message = new InteractionMessage();
        message.memberId = memberId;
        message.brand = structure.brands().get(0);
        message.channel = "INTERNAL";
        message.region = structure.getRegion();
        message.pointType = pointType;
        message.point = point;
        message.adjustReason = adjustReason;
        message.valueType = ValueType.DEFAULT;
        message.uuid = UUIDUtil.generator();
        message.createdTime=LocalDateTime.now();
        return message;
    }

    public static InteractionMessage createTierAwardMessage(LoyaltyStructure structure,
                                                   String memberId, int awardPoint, LocalDateTime createdTime) {
        InteractionMessage message = new InteractionMessage();
        message.memberId = memberId;
        message.brand = structure.brands().get(0);
        message.channel = "INTERNAL";
        message.region = structure.getRegion();
        message.point = awardPoint;
        message.valueType = ValueType.DEFAULT;

        message.uuid = UUIDUtil.generator();
        message.createdTime=createdTime;
        message.pointType= PointTypeEnum.TIER_REWARD.name();
        message.adjustReason = PointTypeEnum.TIER_REWARD.remark();
        message.activityId=PointTypeEnum.TIER_REWARD.activityId();
        if(awardPoint<0){
            message.pointType= PointTypeEnum.TIER_REWARD_REFUND.name();
            message.adjustReason = PointTypeEnum.TIER_REWARD_REFUND.remark();
            message.activityId = PointTypeEnum.TIER_REWARD_REFUND.activityId();

        }

        return message;
    }
}
