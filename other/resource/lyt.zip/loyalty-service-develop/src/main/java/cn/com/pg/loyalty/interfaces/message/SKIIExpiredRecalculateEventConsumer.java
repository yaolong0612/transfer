package cn.com.pg.loyalty.interfaces.message;

import cn.com.pg.loyalty.application.AccountAppService;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusBinder;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class SKIIExpiredRecalculateEventConsumer extends AbstractConsumerV2 {

    @Autowired
    private AccountAppService accountAppService;

    @Override
    protected void doBusiness(JSONObject message) {
        log.info("expired rollback get msg:{}", message);
        OrderEventMsg orderEventMsg = JSON.toJavaObject(message, OrderEventMsg.class);
//        ParamValidator.brand(orderEventMsg.brand == null ? null : orderEventMsg.brand);
        ParamValidator.stringParam("memberId", orderEventMsg.memberId);
        accountAppService.recalculateAccount(orderEventMsg.memberId, orderEventMsg.brand, orderEventMsg.region);
    }

    @Override
    protected ServiceBusBinder getServiceBusBinder() {
        return ServiceBusBinder.Q_ORDER_EVENT;
    }

    @Data
    private static class OrderEventMsg {
        private String memberId;
        private String brand;
        private String region;
    }
}
