package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author vincenzo
 * @description
 * @date 2021/10/20
 */
@Getter
@Setter
@NoArgsConstructor
public class AddPointInLimitDaysByRegisterTimeProperties extends RuleProperties  {
    //加积分
    private int point;
    //日期限制
    private int limitDays;
    //次数限制
    private int limitTimes;
}
