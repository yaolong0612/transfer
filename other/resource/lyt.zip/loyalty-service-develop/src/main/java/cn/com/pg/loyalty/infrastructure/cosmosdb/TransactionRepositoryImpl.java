package cn.com.pg.loyalty.infrastructure.cosmosdb;

import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import com.microsoft.azure.documentdb.*;
import com.microsoft.azure.spring.data.cosmosdb.DocumentDbFactory;
import com.microsoft.azure.spring.data.cosmosdb.common.CosmosdbUtils;
import com.microsoft.azure.spring.data.cosmosdb.core.convert.MappingDocumentDbConverter;
import com.microsoft.azure.spring.data.cosmosdb.exception.DocumentDBAccessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author cooltea
 * <p>
 * 说明：应为在查询用户交易类型时有 order、interraction、redemption 三种类型
 * 而有时需要将这三种类型一并查出，在现有的repository 里都不能实现，所以这个类主要用于将查询出
 * 的doucument聚合,如果是enum类型，需要用.name()方法。不支持枚举类型，是enum类型就要转换为String
 */
@Repository
@Slf4j
public class TransactionRepositoryImpl implements TransactionRepository {

    private static final String PARTITION_KEY = "@partitionKey";
    private static final String LOYALTY_ID = "@loyaltyId";
    private static final String POINT_TYPE_1 = "@pointType1";
    private static final String POINT_TYPE_2 = "@pointType2";
    private static final String TRANSACTION_TYPE = "@transactionType";
    private static final String START_TIME = "@start";
    private static final String END_TIME = "@end";
    private static final String LOG_INFO = "{}查询，消耗{}RU";
    private static final String REDEMPTION = "REDEMPTION";
    private static final String BRAND = "brand";

    private static String fetchByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween = "SELECT r.id, r.loyaltyId, r.channel, r.transactionType, r.point,r.expiredTime, r.createdTime, r.transactionStatus, r.storeCode, r.description, r.pointType, r.pointItems, r.redeemCode, r.deliveryChannel, r.redemptionStatus, r.adjustReason, r.createBy, r.valueType FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND (r.pointType != @pointType1 AND r.pointType != @pointType2) AND (r.createdTime BETWEEN @start AND @end)";
    private static String fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween = "SELECT r.id, r.loyaltyId, r.channel, r.transactionType, r.point, r.createdTime, r.transactionStatus, r.storeCode, r.description, r.pointType, r.pointItems, r.redeemCode, r.deliveryChannel, r.redemptionStatus, r.adjustReason, r.createBy, r.valueType FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.transactionType != @transactionType AND r.point >= @point AND (r.pointType != @pointType1 AND r.pointType != @pointType2) AND (r.createdTime BETWEEN @start AND @end)";
    private static String fetchBurnByPartitionKeyAndLoyaltyIdAndTransactionTypeOrPointLessThanAndCreatedTimeBetween = "SELECT r.id, r.loyaltyId, r.channel, r.transactionType, r.point, r.createdTime, r.transactionStatus, r.storeCode, r.description, r.pointType, r.pointItems, r.redeemCode, r.deliveryChannel, r.redemptionStatus,r.adjustReason, r.createBy, r.valueType FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND (r.transactionType = @transactionType OR r.point < @point) AND (r.pointType != @pointType1 AND r.pointType != @pointType2) AND (r.createdTime BETWEEN @start AND @end)";

    private static String queryByPAndId = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.id = @id";
    private static String queryByPartitionKeyAndId = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId order by r.createdTime DESC";
    private String queryByPAndLoIdAndType = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.transactionType != @transactionType AND r.availablePoint > @availablePoint and r.expiredTime > @end and r.transactionStatus IN (%s) ORDER BY r.createdTime";
    private String queryByPAndLoIdAndExpiredTimeBtw = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND (r.expiredTime BETWEEN @start AND @end) AND r.brand IN (%s) AND r.availablePoint != 0";
    private String queryByPAndLoIdAndExpiredTimeLt = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.expiredTime <= @end AND r.transactionStatus != @transactionStatus AND r.brand IN (%s)";
    private static String queryByPAndLoIdAndPt = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.pointType = @pointType And r.transactionStatus != @transactionStatus order by r.createdTime";
    private static String queryByPkAndLoIdAndVtAndCt = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId And r.valueType = @valueType and r.createdTime >= @startTime and r.createdTime <= @endTime order by r.createdTime";
    private static String queryMaxTByPAndLoIdAndTType = "SELECT MAX(r.orderDateTime) FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.brand = @brand And r.transactionType = @transactionType";
    private static String queryMaxTByPAndLoId = "SELECT MAX(r.createdTime) FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId  AND r.valueType= @valueType AND r.point>0 AND r.transactionType!='REDEMPTION'";

    private static String fetchByPartitionKeyAndLoyaltyIdAndPointTypeAndUnlockedTimeBetween = "SELECT * FROM ROOT r WHERE r.partitionKey = @partitionKey AND r.loyaltyId = @loyaltyId AND r.pointType NOT IN ('REDEMPTION', 'SYSTEM_OPERATIONS_POINT', 'REDEMPTION_CANCEL', 'DATA_MIGRATION', 'SYSTEM_EXPIRED_POINT') AND (r.unlockTime BETWEEN @start AND @end) AND r.point > 0";

    @Autowired
    private DocumentClient documentClient;
    @Autowired
    private MappingDocumentDbConverter mappingDocumentDbConverter;
    @Autowired
    private InteractionRepository interactionRepository;
    @Autowired
    private RedemptionRepository redemptionRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private CosmosDbConfig cosmosDbConfig;

    @Autowired
    private DocumentDbFactory documentDbFactory;

    @Override
    public Transaction save(Transaction transaction) {
        TransactionType transactionType = Optional.ofNullable(transaction)
                .map(entity -> Optional.ofNullable(entity.getTransactionType())
                        .orElseThrow(() -> new SystemException("Field transactionType is null", ResultCodeMapper.PARAM_ERROR)))
                .orElseThrow(() -> new SystemException("The entities which are going to be saved can not be null", ResultCodeMapper.PARAM_ERROR));
        if (transactionType == TransactionType.ORDER) {
            return orderRepository.save((Order) transaction);
        }
        if (transactionType == TransactionType.INTERACTION) {
            return interactionRepository.save((Interaction) transaction);
        }
        return redemptionRepository.save((Redemption) transaction);
    }

    @Override
    public List<Transaction> findByPartitionKeyAndId(String partitionKey, String transactionId) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter("@id", transactionId));
        return executeQueryFindList(queryByPAndId, spc);
    }

    @Override
    public void deleteById(String id, String partitionKey) {
        try {
            RequestOptions options = CosmosdbUtils.getCopyFrom(this.documentDbFactory.getConfig().getRequestOptions());
            if (partitionKey != null) {
                options.setPartitionKey(new PartitionKey(partitionKey));
            }
            this.documentClient.deleteDocument(cosmosDbConfig.getDocumentLink(Transaction.class, id), options);
        } catch (DocumentClientException var5) {
            throw new DocumentDBAccessException("deleteById exception", var5);
        }
    }

    @Override
    public List<Transaction> findTransactionsByPartitionKeyAndLoyaltyId(String partitionKey, String loyaltyId) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId));
        return executeQueryFindList(queryByPartitionKeyAndId, spc);
    }

    @Override
    public List<Transaction> fetchBurnByPartitionKeyAndLoyaltyIdAndTransactionTypeOrPointLessThanAndCreatedTimeBetween(String partitionKey, String loyaltyId, String transactionType, int point, String startAt, String endAt) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(POINT_TYPE_1, Transaction.PointTypeEnum.DATA_MIGRATION.name()),
                new SqlParameter(POINT_TYPE_2, Transaction.PointTypeEnum.SYSTEM_OPERATIONS_POINT.name()),
                new SqlParameter(TRANSACTION_TYPE, transactionType),
                new SqlParameter("@point", point),
                new SqlParameter(START_TIME, startAt),
                new SqlParameter("@end", endAt));
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(partitionKey));
        return executeQueryFindList(fetchBurnByPartitionKeyAndLoyaltyIdAndTransactionTypeOrPointLessThanAndCreatedTimeBetween, spc, feedOptions);
    }

    @Override
    public List<Transaction> fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween(String partitionKey, String loyaltyId, String transactionType, int point, String startAt, String endAt) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(POINT_TYPE_1, Transaction.PointTypeEnum.DATA_MIGRATION.name()),
                new SqlParameter(POINT_TYPE_2, Transaction.PointTypeEnum.SYSTEM_OPERATIONS_POINT.name()),
                new SqlParameter(TRANSACTION_TYPE, TransactionType.REDEMPTION.name()),
                new SqlParameter("@point", point),
                new SqlParameter(START_TIME, startAt),
                new SqlParameter("@end", endAt));
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(partitionKey));
        return executeQueryFindList(fetchEarnByPartitionKeyAndLoyaltyIdAndTransactionTypeAndPointMoreThanAndCreatedTimeBetween, spc, feedOptions);
    }

    @Override
    public List<Transaction> fetchByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween(String partitionKey, String loyaltyId, String startAt, String endAt) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(POINT_TYPE_1, Transaction.PointTypeEnum.DATA_MIGRATION.name()),
                new SqlParameter(POINT_TYPE_2, Transaction.PointTypeEnum.SYSTEM_OPERATIONS_POINT.name()),
                new SqlParameter(START_TIME, startAt),
                new SqlParameter("@end", endAt));
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(partitionKey));
        return executeQueryFindList(fetchByPartitionKeyAndLoyaltyIdAndCreatedTimeBetween, spc, feedOptions);
    }

    @Override
    public List<Transaction> findByPartitionKeyAndLoyaltyIdAndTransactionTypeNotAndAvailablePointGreaterThanOrderByCreatedTime(String partitionKey, String loyaltyId, TransactionType transactionType, int availablePoint) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(TRANSACTION_TYPE, transactionType.name()),
                new SqlParameter("@availablePoint", availablePoint),
                new SqlParameter("@end", LoyaltyDateTimeUtils.localDateTimeToString(LocalDateTime.now())));
        List<Transaction.TransactionStatus> tempStatus = Arrays.asList(Transaction.TransactionStatus.values());
        List<String> statuses = tempStatus.stream()
                .filter(tStatus -> tStatus != Transaction.TransactionStatus.LOCK)
                .filter(tStatus -> tStatus != Transaction.TransactionStatus.EXPIRED)
                .map(Enum::toString)
                .collect(Collectors.toList());
        queryByPAndLoIdAndType = String.format(queryByPAndLoIdAndType,
                statuses.stream().map(status -> "'" + status + "'").collect(Collectors.joining(",")));
        return executeQueryFindList(queryByPAndLoIdAndType, spc);
    }

    /**
     * 获取某个用户某事件段过期交易记录
     *
     * @param partitionKey
     * @param loyaltyId
     * @param startAt
     * @param endAt
     * @param brands
     * @return
     */
    @Override
    public List<Transaction> findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(String partitionKey, String loyaltyId, String startAt, String endAt, Set<String> brands) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(START_TIME, startAt),
                new SqlParameter("@end", endAt));
        queryByPAndLoIdAndExpiredTimeBtw = String.format(queryByPAndLoIdAndExpiredTimeBtw, brands.stream().map(brand -> "'" + brand + "'").collect(Collectors.joining(",")));
        return executeQueryFindList(queryByPAndLoIdAndExpiredTimeBtw, spc);
    }

    @Override
    public List<Transaction> findByPartitionKeyAndLoyaltyIdAndExpiredTimeLessThanAndBrandInAndTransactionStatusNotExpire(String partitionKey, String loyaltyId, String endAt, Set<String> brands) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter("@transactionStatus", "EXPIRED"),
                new SqlParameter("@end", endAt));
        queryByPAndLoIdAndExpiredTimeLt = String.format(queryByPAndLoIdAndExpiredTimeLt, brands.stream().map(brand -> "'" + brand + "'").collect(Collectors.joining(",")));
        return executeQueryFindList(queryByPAndLoIdAndExpiredTimeLt, spc);
    }

    @Override
    public List<Transaction> findByPartitionKeyAndLoyaltyIdAndPointType(String partitionKey, String loyaltyId, String pointType) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter("@pointType", pointType),
                new SqlParameter("@transactionStatus", Transaction.TransactionStatus.MIGRATION.name()));
        return executeQueryFindList(queryByPAndLoIdAndPt, spc);
    }

    @Override
    public Optional<String> findMaxOrderTimeByPartitionKeyAndLoyaltyIdAndBrandAndTransactionType(String partitionKey, String loyaltyId, String brand, TransactionType transactionType) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter("@brand", brand),
                new SqlParameter(TRANSACTION_TYPE, transactionType.name()));
        return getString(queryMaxTByPAndLoIdAndTType, spc);
    }

    @Override
    public Optional<String> findMaxCreatedTimeOfAddTransaction(String loyaltyId, ValueType valueType) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter("@valueType", valueType.name()));
        return getString(queryMaxTByPAndLoId, spc);
    }

    @Override
    public List<Transaction> findTransactionsWitTypeAndCreateTimeBetween(String loyaltyId, ValueType valueType,
                                                                         LocalDateTime startTime, LocalDateTime endTime) {
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(loyaltyId);
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter("@valueType", valueType.name()),
                new SqlParameter("@startTime", LoyaltyDateTimeUtils.localDateTimeToString(startTime)),
                new SqlParameter("@endTime", LoyaltyDateTimeUtils.localDateTimeToString(endTime)));
        return executeQueryFindList(queryByPkAndLoIdAndVtAndCt, spc);
    }

    private Optional<String> getString(String sql, SqlParameterCollection spc) {
        SqlQuerySpec sqs = new SqlQuerySpec(sql, spc);
        FeedOptions feedOptions = new FeedOptions();
        FeedResponse<Document> response = documentClient.queryDocuments(cosmosDbConfig.getCollectionLink(Transaction.class), sqs, feedOptions);
        double requestCharge = response.getRequestCharge();
        log.info(LOG_INFO, sqs.getQueryText(), requestCharge);
        Iterator<Document> it = response.getQueryIterator();
        while (it.hasNext()) {
            return Optional.ofNullable((String) (it.next().get("$1")));
        }
        return Optional.empty();
    }



    private List<Transaction> executeQueryFindList(String querySql, SqlParameterCollection spc) {
        FeedOptions feedOptions = new FeedOptions();
        return executeQueryFindList(querySql, spc, feedOptions);
    }

    private List<Transaction> executeQueryFindList(String querySql, SqlParameterCollection spc, FeedOptions feedOptions) {
        SqlQuerySpec sqs = new SqlQuerySpec(querySql, spc);
        FeedResponse<Document> response = documentClient.queryDocuments(cosmosDbConfig.getCollectionLink(Transaction.class), sqs, feedOptions);
        double requestCharge = response.getRequestCharge();
        log.info(LOG_INFO, sqs.getQueryText(), requestCharge);
        Iterator<Document> it = response.getQueryIterator();
        List<Transaction> result = new ArrayList<>();
        while (it.hasNext()) {
            Document document = it.next();
            if (document != null) {
                result.add(mappingDocumentToTransaction(document));
            }
        }
        return result;
    }


    private Transaction mappingDocumentToTransaction(Document next) {
        TransactionType transactionType = Optional.ofNullable((String) next.get("transactionType"))
                .map(TransactionType::valueOf)
                .orElseThrow(() -> new SystemException("transactionType is null when mapping the entity of transaction", ResultCodeMapper.PARAM_ERROR));
        if (transactionType == TransactionType.ORDER) {
            return mappingDocumentDbConverter.read(Order.class, next);
        }
        if (transactionType == TransactionType.INTERACTION) {
            return mappingDocumentDbConverter.read(Interaction.class, next);
        }
        return mappingDocumentDbConverter.read(Redemption.class, next);
    }

    @Override
    public List<Transaction> fetchByPartitionKeyAndLoyaltyIdAndPointTypeAndCreatedTimeBetween(String partitionKey, String loyaltyId, String startAt, String endAt) {
        SqlParameterCollection spc = new SqlParameterCollection(
                new SqlParameter(PARTITION_KEY, partitionKey),
                new SqlParameter(LOYALTY_ID, loyaltyId),
                new SqlParameter(START_TIME, startAt),
                new SqlParameter(END_TIME, endAt));
        FeedOptions feedOptions = new FeedOptions();
        feedOptions.setPartitionKey(new PartitionKey(partitionKey));
        return executeQueryFindList(fetchByPartitionKeyAndLoyaltyIdAndPointTypeAndUnlockedTimeBetween, spc, feedOptions);
    }
}
