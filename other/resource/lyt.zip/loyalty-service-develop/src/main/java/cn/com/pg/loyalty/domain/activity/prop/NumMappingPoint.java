package cn.com.pg.loyalty.domain.activity.prop;

import lombok.Getter;
import lombok.Setter;

import java.util.Optional;

/**
 * @author cooltea on 2019/9/4 17:34.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */

@Getter
@Setter
public class NumMappingPoint {

    /**
     * 天数
     */
    private Integer num;
    /**
     * 对应积分/次数
     */
    private Integer pointOrSize;

    public Integer num() {
        return Optional.ofNullable(this.num).orElse(0);
    }

    public boolean thisNumIs(Integer num) {
        return this.num.equals(num);
    }

    public int pointOrSize() {
        return Optional.ofNullable(this.pointOrSize).orElse(0);
    }

    public NumMappingPoint(Integer num, Integer pointOrSize) {
        this.num = num;
        this.pointOrSize = pointOrSize;
    }

    public NumMappingPoint() {
    }
}
