package cn.com.pg.loyalty.domain.shared;

import org.springframework.http.HttpStatus;

/**
 * @author Ladd
 * <p>
 * SystemErrorCode与HttpStatus映射
 */
public enum ResultCodeMapper {
    /**
     * 成功
     */
    SUCCESS(1, HttpStatus.OK),
    /**
     * 未识别错误
     */
    UNEXPECTED_ERROR(2, HttpStatus.INTERNAL_SERVER_ERROR),

    /**
     * 未发现
     */
    ACCOUNT_NOT_FOUND(3, HttpStatus.NOT_FOUND),
    QRCODE_NOT_FOUND(3, HttpStatus.NOT_FOUND),
    STRUCTURE_NOT_FOUND(3, HttpStatus.NOT_FOUND),
    /**
     * 注册重复/频繁
     */
    ACCOUNT_REGISTER_FREQUENTLY(4, HttpStatus.BAD_REQUEST),

    /**
     * 参数错误
     */
    RULE_TEMPLATE_NOT_FOUND(4, HttpStatus.BAD_REQUEST),

    /**
     * 不在兑换期内
     */
    NOT_IN_REDEMPTION_PERIOD(5, HttpStatus.BAD_REQUEST),

    /**
     * GIFT未发现
     */
    GIFT_NOT_FOUND(7, HttpStatus.NOT_FOUND),

    /**
     * Activity未发现
     */
    ACTIVITY_NOT_FOUND(6, HttpStatus.EXPECTATION_FAILED),
    /**
     * Activity不能删除
     */
    ACTIVITY_NOT_DELETE(12, HttpStatus.NOT_FOUND),
    /**
     * Activity中没有找到对应的Gift
     */
    ACTIVITY_SCANCODE_SKUS_EMPTY(102, HttpStatus.NOT_FOUND),
    /**
     * Activity中没有找到对应的SKU
     */
    ACTIVITY_NOT_FOUND_SCANCODE_SKU(101, HttpStatus.NOT_FOUND),
    /**
     * 礼品已经配分配，不能删除错误
     */
    GIFT_DISTRIBUTED_NOT_DELETE_ERROR(8, HttpStatus.BAD_REQUEST),
    /**
     * PointType下没有可用的活动
     */
    POINT_TYPE_NO_ACTIVITY(15, HttpStatus.NOT_FOUND),
    /**
     * 扫码次数超过限制
     */
    SCAN_CODE_SKU_LIMIT_MAX(10183, HttpStatus.BAD_REQUEST),
    /**
     * 不是同一个积分系统错误
     */
    NO_SAME_LOYALTY_STRUCTURE(9, HttpStatus.BAD_REQUEST),

    /**
     * 库存不足，无法分配
     */
    UNDER_STOCK(10, HttpStatus.BAD_REQUEST),

    /**
     * 参数错误
     */
    PARAM_ERROR(11, HttpStatus.BAD_REQUEST),

    /**
     * PointType已存在
     */
    POINT_TYPE_ALREADY_EXISTED(12, HttpStatus.BAD_REQUEST),

    /**
     * PointType未找到
     */
    POINT_TYPE_NOT_FOUND(13, HttpStatus.NOT_FOUND),

    /**
     * PointType使用中
     */
    POINT_TYPE_IN_USE(14, HttpStatus.BAD_REQUEST),

    /**
     * 消息参数错误,放入dead queue中
     */
    MESSAGE_PARAM_ERROR(15, HttpStatus.BAD_REQUEST),
    /**
     * service bus error
     */
    SERVICE_BUS_ERROR(59, HttpStatus.BAD_REQUEST),
    /**
     * elastic search error
     */
    ELASTIC_SEARCH_ERROR(60, HttpStatus.BAD_REQUEST),
    /**
     * Activity不能更新
     */
    ACTIVITY_NOT_UPDATE_STATUS(80, HttpStatus.BAD_REQUEST),
    /**
     * 礼品库存修改不能，让占用库存大于总库存
     */
    GIFT_UPDATE_STOCK_ERROR(90, HttpStatus.BAD_REQUEST),
    /**
     * Activity中没有找到对应的Gift
     */
    ACTIVITY_NOT_FOUND_GIFT(100, HttpStatus.NOT_FOUND),
    /**
     * Activity中没有找到对应的Gift
     */
    ACTIVITY_GIFT_LOYALSTRUCTRE_ERROR(110, HttpStatus.NOT_FOUND),
    /**
     * 兑换订单没有依赖的业务Id
     */
    REDEMPTION_NOT_FOUND_RELY_BUSINESS_ID(111, HttpStatus.NOT_FOUND),
    /**
     * 兑换订单没有依赖的业务Id（interaction）
     */
    REDEMPTION_NOT_FOUND_RELY_INTERACTION(112, HttpStatus.NOT_FOUND),
    /**
     * RuleTemplate转换错误
     */
    RULE_TEMPLATE_CHANGE_ERROR(120, HttpStatus.NOT_FOUND),
    /***
     * EXTERNALID已经存在的状态码
     */
    ACTIVITY_EXTERNALID_EXITS(130, HttpStatus.BAD_REQUEST),

    /**
     * 超过限制范围的错误
     */
    LIMIT_ERROR(140, HttpStatus.BAD_REQUEST),

    /**
     * 兑换未找到
     */
    REDEMPTION_NOT_FOUND(141, HttpStatus.NOT_FOUND),

    /**
     * 兑换项未找到
     */
    REDEMPTION_ITEM_NOT_FOUND(142, HttpStatus.NOT_FOUND),

    /**
     * 积分等级太低，无法兑换高等级礼品错误
     */
    LOW_TIER_LEVEL_ERROR(150, HttpStatus.BAD_REQUEST),

    /**
     * 积分不足，无法兑换礼品的错误
     */
    NOT_ENOUGH_POINT_ERROR(160, HttpStatus.BAD_REQUEST),

    /**
     * 更新Redemption的错误
     */
    UPDATE_REDEMPTION_ERROR(170, HttpStatus.BAD_REQUEST),

    /**
     * 等级重算错误
     */
    TIER_RECALCULATE_ERROR(180, HttpStatus.BAD_REQUEST),

    /**
     * 码重复错误
     */
    SCAN_CODE_ERROR(181, HttpStatus.BAD_REQUEST),

    /**
     * 扫码过于频繁
     */
    SCAN_CODE_TOO_FAST(10182, HttpStatus.TOO_MANY_REQUESTS),

    /**
     * 兑换过于频繁
     */
    REDEMPTION_TOO_FAST(10188, HttpStatus.TOO_MANY_REQUESTS),

    /**
     * 操作过于频繁
     */
    OPERATION_TOO_FAST(10189, HttpStatus.TOO_MANY_REQUESTS),

    /**
     * SKU 不存在，未配置
     */
    SCAN_CODE_SKU_INEXIST(20182, HttpStatus.BAD_REQUEST),

    /**
     * 不在活动期内
     */
    ACTIVITY_NOT_AVAILABLE_ERROR(190, HttpStatus.BAD_REQUEST),
    /**
     * 没有可用的活动
     */
    NOT_AVAILABLE_ACTIVITY(191, HttpStatus.BAD_REQUEST),
    /**
     * 超出活动参与次数限制
     */
    ACTIVITY_EXCEED_TIMES(193, HttpStatus.BAD_REQUEST),
    /**
     * 发送消息失败
     */
    SEND_MESSAGE_ERROR(182, HttpStatus.BAD_REQUEST),
    /**
     * 数据库执行错误
     */
    DB_ERROR(183, HttpStatus.INTERNAL_SERVER_ERROR),
    /**
     * OrderId不存在
     */
    ORDER_ID_NOT_FOUND(184, HttpStatus.NOT_FOUND),
    /**
     * 执行Table Storage 失败
     */
    TABLE_STORAGE_ERROR(185, HttpStatus.INTERNAL_SERVER_ERROR),
    /**
     * 调用AM异常
     */
    CALL_AM_ERROR(186, HttpStatus.BAD_REQUEST),
    /**
     * account的状态已经关闭
     */
    ACCOUNT_STATUS_CLOSED(187, HttpStatus.BAD_REQUEST),
    /**
     * account相同的状态无需更改
     */
    ACCOUNT_NOT_UPDATE_STATUS(188, HttpStatus.BAD_REQUEST),
    /**
     * account的状态未激活或已被锁定，关闭
     */
    ACCOUNT_STATUS_NOT_ACTIVATED(189, HttpStatus.BAD_REQUEST),
    /**
     * SKU已经存在
     */
    QRCODE_ACTIVITY_SKU_EXIST(190, HttpStatus.BAD_REQUEST),
    /**
     * 调用SMP异常
     */
    CALL_SMP_ERROR(191, HttpStatus.BAD_REQUEST),
    /**
     * 调用mineTree异常
     */
    CALL_MINDTREE_ERROR(192, HttpStatus.BAD_REQUEST),

    CALL_COUPON_ERROR(193, HttpStatus.BAD_REQUEST),

    POINT_EXCEED_LIMIT_FREQUENCY(600, HttpStatus.BAD_REQUEST),
    /**
     * 签到频繁
     */
    ATTENDANCE_FREQUENTLY(700, HttpStatus.BAD_REQUEST),
    /**
     * 订单金额为0
     */
    ORDER_AMOUNT_ZERO(800, HttpStatus.BAD_REQUEST),
    /**
     * 订单重复
     */
    ORDER_ID_EXISTS(900, HttpStatus.BAD_REQUEST),
    /**
     * 消息推送重复
     */
    MESSAGE_DUPLICATED(121, HttpStatus.BAD_REQUEST),
    /**
     * 消息为空
     */
    MESSAGE_EMPTY(122, HttpStatus.BAD_REQUEST),
    /**
     * 兑换已取消或拒绝
     */
    REDEMPTION_CANCELED_OR_REJECTED(123, HttpStatus.BAD_REQUEST),
    /**
     * 未达到指定购买记录数，不能参加兑换活动
     */
    LESS_THAN_SPECIFIED_PURCHASE_RECORDS(124, HttpStatus.BAD_REQUEST),

    /**
     * 兑换不应许取消
     */
    REDEMPTION_CONFIG_NOT_CANCEL(125, HttpStatus.BAD_REQUEST),
    /**
     * 兑换
     */
    REDEMPTION_THIS_STATUS_NOT_ALLOW_CHANGED(126, HttpStatus.BAD_REQUEST),

    /**
     * 业务已完成，不需要重复请求
     */
    REQUEST_REPEAT_BUSINESS_COMPLETED(128, HttpStatus.BAD_REQUEST),
    /**
     * 请求重复
     */
    REQUEST_REPEAT(127, HttpStatus.BAD_REQUEST),
    /**
     * 客户群成员状态校验不通过
     */
    PEOPLEX_GROUP_MEMBER_STATUS(301, HttpStatus.OK),

    GIFT_NOT_FOUNT_SKU(129, HttpStatus.BAD_REQUEST),

    REDEMPTION_GIFT_MUTEX(130,HttpStatus.BAD_REQUEST),

    BABY_BIRTH_LIMIT(130,HttpStatus.BAD_REQUEST),

    ORIGIN_ORDER_NOT_FIND(131, HttpStatus.BAD_REQUEST);



    public static ResultCodeMapper getInstanceByCode(int code) {
        for (ResultCodeMapper instance : ResultCodeMapper.values()) {
            if (instance.getCode() == code) {
                return instance;
            }
        }
        return null;
    }

    ResultCodeMapper(int code, HttpStatus status) {
        this.code = code;
        this.status = status;
    }

    private int code;

    private HttpStatus status;

    public int getCode() {
        return code;
    }


    public HttpStatus getStatus() {
        return status;
    }

}
