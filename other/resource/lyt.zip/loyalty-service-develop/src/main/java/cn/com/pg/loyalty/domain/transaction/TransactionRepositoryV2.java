package cn.com.pg.loyalty.domain.transaction;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepositoryV2 {

    void save(Transaction entity);

    void saveRetrievable(Transaction transaction);

    List<Transaction> fetchInteractions(String loyaltyId, LocalDateTime startAt, LocalDateTime endAt);

    List<Transaction> fetchByUnlockTimeAfter(String loyaltyId, LocalDate startAt);

    List<Transaction> fetchEarnTransactionsByCreatedTimeSorted(String loyaltyId, LocalDateTime startAt, LocalDateTime endAt);

    List<Transaction> fetchPositivePointTransactionByLoyaltyIdAndExpiredTimeGreaterThan(String loyaltyId, LocalDateTime startTime);
}
