package cn.com.pg.loyalty.infrastructure.lock;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.LocalVariableTableParameterNameDiscoverer;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.lang.reflect.Method;

@Slf4j
@Order(2)
@Component
@Aspect
public class MutexLockAspect {
    public static final Class<MutexLock> MUTEX_LOCK_CLASS = MutexLock.class;


    @Resource
    Lock lock;


    @Pointcut("@annotation(cn.com.pg.loyalty.infrastructure.lock.MutexLock)")
    public void mutexPointCut() {
        // Do nothing because of point cut.
    }


    @Around("mutexPointCut()")
    public Object doMutexPointCutAround(ProceedingJoinPoint point) throws Throwable {
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        Method method = methodSignature.getMethod();
        Object[] arguments = point.getArgs();
        LocalVariableTableParameterNameDiscoverer discoverer = new LocalVariableTableParameterNameDiscoverer();
        String[] parameterNames = discoverer.getParameterNames(method);
        MutexLock mutexLock = method.getAnnotation(MUTEX_LOCK_CLASS);
        return MutexLockPointCutAdvice.pointAdviceWithLock(point, mutexLock, lock, parameterNames, arguments);
    }
}
