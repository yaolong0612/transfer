package cn.com.pg.loyalty.application;

import cn.com.pg.desenitize.infrastructure.desensitized.DesensitizedUtils;
import cn.com.pg.loyalty.application.dependence.*;
import cn.com.pg.loyalty.domain.dmp.Store;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.TierLevelSeries;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.Redemption;
import cn.com.pg.loyalty.domain.transaction.RedemptionRepository;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author cooltea on 2019/7/15 17:18.
 * @version 1.0
 * @email cooltea007@163.com
 * 说明：
 */
@Service
@Slf4j
public class SmsService {

    private static final String FULL_NAME = "fullname";
    /**
     * 升级到铂金
     */
    @Value("${sms.olayTierUpPlatinum}")
    private String OLAY_TIER_UP_PLATINUM;
    /**
     * 升级到砖石
     */
    @Value("${sms.olayTierUpDiamond}")
    private String OLAY_TIER_UP_DIAMOND;
    /**
     * 降级级到普通
     */
    @Value("${sms.olayTierDownNormal}")
    private String OLAY_TIER_DOWN_NORMAL;
    /**
     * 升级到铂金
     */
    @Value("${sms.olayTierWownPlatinum}")
    private String OLAY_TIER_WOWN_PLATINUM;
    /**
     * 正常到柜领取
     */
    @Value("${sms.c2NornalRecive}")
    private String C2_NORNAL_RECIVE;
    /**
     * C2转柜
     */
    @Value("${sms.c2TransferCounter}")
    private String C2_TRANSFER_COUNTER;
    /**
     * 发运到家
     */
    @Value("${sms.c2DeliverHome}")
    private String C2_DELIVER_HOME;
    /**
     * 发送热线
     */
    @Value("${sms.c2HotLine}")
    private String C2_HOT_LINE;

    /**
     * olay兑换过期发短信
     */
    @Value("${sms.olayRedemptionExpired}")
    private String OLAY_REDEMPTION_EXPIRED;

    private static String SMS_REDIS_KEY_PREFIX = "SMS:PREFIX:";
    private static String SMS_DOWN_GRADING_REDIS_KEY_PREFIX = "SMS:DOWN:GRADING:PREFIX:";
    private static int SMS_EXPIRE_TIME = 1 * 24 * 3600;
    private static int SMS_DOWN_GRADING_EXPIRE_TIME = 180 * 24 * 3600;
    private static int SMS_FREQUNTLTY_TIME = 3 * 60;
    private final static String RESULT_CODE = "resultCode";
    private static String DEFAULT_MEMBER_NAME = "会员";
    private final static String SUCCESS = "0";
    private final static String FREQUENTLY_CODE = "300403";
    public final static String REDEMPTION_TRANSFER_TYPE = "REDEMPTION_TRANSFER_TYPE";
    public final static String TIER_CHANGE_TYPE = "tierChanged";
    public static final String SMS_TYPE = "smsType";
    private static String PHONE_WHITE_LIST_KEY = "PHONE:WHITE:LIST";
    private static String PROFILE_PROD_ACTIVE = "prod";
    private static String OLAY_REDEMPTION_EXPIRED_SEND_MESSAGE_PREFIX = "OLAY:MESSAGE:";
    private static int SMS_REDEMPTION_EXPIRED_EXPIRE_TIME = 20 * 24 * 3600;


    @Autowired
    private CmsMessageGatewayClient cmsMessageGatewayClient;
    @Autowired
    private AmClientSupport amClientSupport;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private RedemptionRepository redemptionRepository;
    @Autowired
    private ApplicationContext context;
    @Autowired
    private CacheService cacheService;
    @Autowired
    private ServiceBusTemplate serviceBusTemplate;

    @Value("${enable.send.sms:false}")
    private Boolean isEnableSendSms;

    /**
     * 等级过期发送短信通知，目前只有olay品牌
     *
     * @param memberId
     * @param brand
     * @param originalTier
     * @param currentTier
     */
    public void sendTierChangeSMS(String memberId, String loyaltyId, String brand, String originalTier,
                                  String currentTier, LoyaltyStructure loyaltyStructure) {
        String originLevel = originalTier;
        String currentLevel = currentTier;
        TierLevelSeries series = loyaltyStructure.tierLevelSeries();
        int tierChange = series.compare(currentLevel, originLevel);
        if (tierChange == 0) {
            return;
        }
        boolean isSuccess = true;
        String key = null;
        if (tierChange > 0) {
            key = new StringBuilder(SMS_REDIS_KEY_PREFIX).append(loyaltyStructure.name()).append(":").append(brand).append(":").append(loyaltyId).toString();
            isSuccess = stringRedisTemplate.opsForValue().setIfAbsent(key, memberId, SMS_EXPIRE_TIME, TimeUnit.SECONDS);
        } else {
            key = new StringBuilder(SMS_DOWN_GRADING_REDIS_KEY_PREFIX).append(loyaltyStructure.name()).append(":").append(brand).append(":").append(loyaltyId).toString();
            isSuccess = stringRedisTemplate.opsForValue().setIfAbsent(key, memberId, SMS_DOWN_GRADING_EXPIRE_TIME, TimeUnit.SECONDS);
        }
        if (!isSuccess) {
            log.warn("{}天内只可以发送1次升降级短信", tierChange > 0 ? 1 : 180);
            return;
        }
        try {
            AmClient.OptimizedProfileDTO profileDTO = amClientSupport.queryProfile(memberId, loyaltyStructure.getAmTenantId());
            String fullName = Optional.of(profileDTO).map(profileDTO1 -> Optional.ofNullable(profileDTO1.getFullName()).orElse(DEFAULT_MEMBER_NAME)).orElse(DEFAULT_MEMBER_NAME);
            String mobile = Optional.of(profileDTO).map(AmClient.OptimizedProfileDTO::getCellphone).orElseThrow(
                    () -> new SystemException("没有找到该用户", ResultCodeMapper.ACCOUNT_NOT_FOUND));
            if (!enableSendMsgQaProfile(mobile)) {
                log.warn("qa环境中该手机号不在白名单：{}", mobile);
                return;
            }
            if (!isEnableSendSms) {
                log.warn("启动配置[enable.send.sms]是否允许发送短信：否{}", isEnableSendSms);
                return;
            }
            double currentPoint = getCurrentOrderAmount(loyaltyId, brand);
            // 升级
            if (tierChange > 0) {
                int upgradeAmount = series.getLevelByName(originLevel).getUpgradeAmount();
                if (upgradeAmount > currentPoint) {
                    log.warn("当前本期金额:{}小于于升降金额:{}则不发升级短信", currentPoint, upgradeAmount);
                    stringRedisTemplate.delete(key);
                    return;
                }
                String smsTemplateCode = series.getLevelByName(currentLevel).getLevel() == 3 ? OLAY_TIER_UP_DIAMOND : OLAY_TIER_UP_PLATINUM;
                CmsMessageGatewayClient.MessageEntity messageEntity = CmsMessageGatewayClient.MessageEntity
                        .create(smsTemplateCode, mobile)
                        .brand(brand)
                        .putParam(FULL_NAME, fullName);
                log.info("send-upgrade-sms-msg-is: mobile:{}, templateCode:{}",
                        DesensitizedUtils.mobilePhone(mobile),
                        Optional.ofNullable(messageEntity).map(CmsMessageGatewayClient.MessageEntity::getTemplateCode)
                                .orElse(""));
                String resultCode = callSMSResult(messageEntity);
                if (!SUCCESS.equals(resultCode)) {
                    throw new SystemException("Failed to send message to SMS", ResultCodeMapper.UNEXPECTED_ERROR);
                }
                return;
            }
            // 降级
            if (tierChange < 0) {
                //判断当实际金额和升降级金额出现冲突时不发送短信
                int gradingAmount = series.getLevelByName(originLevel).getGradingAmount();
                if (gradingAmount <= currentPoint) {
                    log.warn("当前本期金额:{}大于升降级金额:{}则不发降级短信", currentPoint, gradingAmount);
                    stringRedisTemplate.delete(key);
                    return;
                }
                String smsTemplateCode = series.getLevelByName(currentLevel).getLevel() == 2 ? OLAY_TIER_WOWN_PLATINUM : OLAY_TIER_DOWN_NORMAL;
                CmsMessageGatewayClient.MessageEntity messageEntity = CmsMessageGatewayClient.MessageEntity
                        .create(smsTemplateCode, mobile)
                        .brand(brand)
                        .putParam("amount", String.valueOf(currentPoint))
                        .putParam(FULL_NAME, fullName);
                log.info("send-downgrade-sms-msg: mobile:{}, templateCode:{}",
                        DesensitizedUtils.mobilePhone(mobile),
                        Optional.ofNullable(messageEntity).map(CmsMessageGatewayClient.MessageEntity::getTemplateCode)
                                .orElse(""));
                String resultCode = callSMSResult(messageEntity);
                if (!SUCCESS.equals(resultCode)) {
                    throw new SystemException("Failed to send message to SMS", ResultCodeMapper.UNEXPECTED_ERROR);
                }
            }
        } catch (SystemException e) {
            stringRedisTemplate.delete(key);
            throw e;
        } catch (Exception e) {
            stringRedisTemplate.delete(key);
            throw new SystemException("发送短信异常：" + e.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    private double getCurrentOrderAmount(String loyaltyId, String brand) {
        List<Order> orders = transactionService.findByLoyaltyIdAndBrandAndTransactionTypeAndOrderDateTimeBetween(loyaltyId, brand,
                TransactionType.ORDER, LocalDateTime.now().minusYears(1).plusDays(1), LocalDateTime.now());
        orders = orders.parallelStream().filter(order -> !order.groupPurchaseIs()).collect(Collectors.toList());
        return orders.stream().mapToDouble(Order::getRealTotalAmount).sum();
    }

    private String callSMSResult(CmsMessageGatewayClient.MessageEntity messageEntity) {
        String response = cmsMessageGatewayClient.sendMessage(messageEntity);
        log.info("send-sms-result: {}", response);
        JSONObject responseJson = JSON.parseObject(response);
        return responseJson.getString(RESULT_CODE);
    }

    private boolean enableSendMsgQaProfile(String phone) {
        List<String> profiles = Arrays.asList(context.getEnvironment().getActiveProfiles());
        if (profiles.contains(PROFILE_PROD_ACTIVE)) {
            return true;
        }
        try {
            String strPhone = stringRedisTemplate.opsForValue().get(PHONE_WHITE_LIST_KEY);
            List<String> phones = Arrays.asList(strPhone.split(","));
            return phones.contains(phone);
        } catch (Exception e) {
            log.error("qa环境链接redis获取手机号白名单异常：{}", e.getMessage());
        }
        return false;
    }

    public void sendCounterTransferSMS(RedemptionServiceBusProperties properties, JSONObject jsonObject) {
        log.info("sendCounterTransferSMS-RedemptionServiceBusProperties is: {}", JSON.toJSONString(properties));
        LoyaltyStructure structure = cacheService.findLoyaltyStructureById(properties.getLoyaltyStructure());
        List<Redemption> redemptionList = redemptionRepository.findByPartitionKeyAndId(PartitionKeyUtils.getTransactionPartitionKey(properties.getLoyaltyId()), properties.getRedemptionId());
        Redemption redemption = redemptionList.get(0);
        String phone;
        String name;
        if (StringUtils.isNotBlank(redemption.getPhone())) {
            phone = redemption.getPhone();
            name = redemption.getReceiver();
        } else {
            AmClient.OptimizedProfileDTO profileDTO = amClientSupport.queryProfile(properties.getMemberId(), structure.getAmTenantId());
            phone = profileDTO.getCellphone();
            name = profileDTO.getFullName();
        }
        name = StringUtils.isBlank(name) ? DEFAULT_MEMBER_NAME : name;
        String brand = redemption.brand();
        CmsMessageGatewayClient.MessageEntity messageEntity = null;
        Store store = cacheService.getStoreByStoreCode(properties.getStoreCode());
        properties.setAddress(Optional.ofNullable(store).map(Store::getStoreAddress).orElse(""));
        if (Redemption.MlOlayCounterTransferType.NORMAL.name().equals(properties.getType())) {
            messageEntity = getNormalMessageEntity(properties, name, phone, brand);
        } else if (Redemption.MlOlayCounterTransferType.TRANSFER_TO_COUNTER.name().equals(properties.getType())) {
            messageEntity = getTransferToCounterMessageEntity(properties, name, phone, brand);
        } else if (Redemption.MlOlayCounterTransferType.TRANSFER_TO_HOME.name().equals(properties.getType())) {
            messageEntity = getTransferToHomeMessageEntity(properties, name, phone, brand);
        } else if (Redemption.MlOlayCounterTransferType.HOT_LINE.name().equals(properties.getType())) {
            messageEntity = getTransferToHotLineEntity(properties, name, phone, brand);
        }
        if (!enableSendMsgQaProfile(phone)) {
            log.warn("qa环境中该手机号不在白名单：{}", phone);
            return;
        }
        if (!isEnableSendSms) {
            log.warn("启动配置[enable.send.sms]是否允许发送短信：否{}", isEnableSendSms);
            return;
        }
        log.info("send-sms-msg: mobile:{}, counterTransferType:{} ,templateCode:{}",
                DesensitizedUtils.mobilePhone(phone), properties.getType(),
                Optional.ofNullable(messageEntity).map(CmsMessageGatewayClient.MessageEntity::getTemplateCode)
                        .orElse(""));
        String response = cmsMessageGatewayClient.sendMessage(messageEntity);
        log.info("send-sms-result: {}", response);
        JSONObject responseJson = JSON.parseObject(response);
        String resultCode = responseJson.getString(RESULT_CODE);
        if (FREQUENTLY_CODE.equalsIgnoreCase(resultCode)) {
            log.warn("发送太频繁, 消息放入到计划消息，3分钟后再消费");
            sendMessageToScheduleMQ(jsonObject);
            return;
        }
        if (!SUCCESS.equals(resultCode)) {
            throw new SystemException("Failed to send message", ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    private void sendMessageToScheduleMQ(JSONObject jsonObject) {
        LocalDateTime messageConsumedTime = LocalDateTime.now().plusMinutes(3);
        LoyaltyMessage loyaltyMessage = new LoyaltyMessage();
        loyaltyMessage.setJsonObject(jsonObject);
        serviceBusTemplate.sendMessage(ServiceBusQueueTopicEnum.SEND_MESSAGE_TO_CONSUMER_BY_SMS, loyaltyMessage, messageConsumedTime);
    }

    public void sendRedemptionExpiredMessage(String memberId, String amTenantId, String brand, String month) {
        String key = new StringBuilder(OLAY_REDEMPTION_EXPIRED_SEND_MESSAGE_PREFIX).append(memberId).toString();
        boolean isSuccess = stringRedisTemplate.opsForValue().setIfAbsent(key, "1", SMS_REDEMPTION_EXPIRED_EXPIRE_TIME, TimeUnit.SECONDS);
        if (!isSuccess) {
            log.warn("不允许重复发送兑换过期短信：{}", memberId);
            return;
        }
        try {
            // 调用AM接口查询用户的信息
            AmClient.OptimizedProfileDTO profileDTO = amClientSupport.queryProfile(memberId, amTenantId);
            String phone = Optional.of(profileDTO).map(AmClient.OptimizedProfileDTO::getCellphone).orElseThrow(
                    () -> new SystemException("没有找到该用户", ResultCodeMapper.ACCOUNT_NOT_FOUND));
            if (!enableSendMsgQaProfile(phone)) {
                log.warn("qa环境中该手机号不在白名单：{}", phone);
                return;
            }
            if (!isEnableSendSms) {
                log.warn("启动配置[enable.send.sms]是否允许发送短信：否{}", isEnableSendSms);
                return;
            }
            // 调用SMS发送短信
            CmsMessageGatewayClient.MessageEntity messageEntity = CmsMessageGatewayClient.MessageEntity
                    .create(OLAY_REDEMPTION_EXPIRED, phone)
                    .brand(brand)
                    .putParam("month", month);
            String resultCode = callSMSResult(messageEntity);
            if (!SUCCESS.equals(resultCode)) {
                throw new SystemException("Failed to send message to SMS", ResultCodeMapper.UNEXPECTED_ERROR);
            }
            log.info("send-olay-redemption-expired-sms-msg-is: mobile:{}, templateCode:{}",
                    DesensitizedUtils.mobilePhone(phone),
                    Optional.ofNullable(messageEntity).map(CmsMessageGatewayClient.MessageEntity::getTemplateCode)
                            .orElse(""));
        } catch (SystemException e) {
            stringRedisTemplate.delete(key);
            throw e;
        } catch (Exception e) {
            stringRedisTemplate.delete(key);
            throw new SystemException("发送短信异常：" + e.getMessage(), ResultCodeMapper.UNEXPECTED_ERROR);
        }
    }

    private CmsMessageGatewayClient.MessageEntity getNormalMessageEntity(RedemptionServiceBusProperties properties, String name, String phone, String brand) {
        return CmsMessageGatewayClient.MessageEntity.create(C2_NORNAL_RECIVE, phone)
                .brand(brand)
                .putParam(FULL_NAME, name)
                .putParam("gift", properties.getGiftNames())
                .putParam("counter", properties.getStoreName())
                .putParam("password", properties.getRedeemCode())
                .putParam("address", properties.getAddress());
    }

    private CmsMessageGatewayClient.MessageEntity getTransferToCounterMessageEntity(RedemptionServiceBusProperties properties, String name, String phone, String brand) {
        return CmsMessageGatewayClient.MessageEntity.create(C2_TRANSFER_COUNTER, phone)
                .brand(brand)
                .putParam(FULL_NAME, name)
                .putParam("counter", properties.getStoreName())
                .putParam("password", properties.getRedeemCode())
                .putParam("address", properties.getAddress());
    }

    private CmsMessageGatewayClient.MessageEntity getTransferToHomeMessageEntity(RedemptionServiceBusProperties properties, String name, String phone, String brand) {
        return CmsMessageGatewayClient.MessageEntity.create(C2_DELIVER_HOME, phone)
                .brand(brand)
                .putParam(FULL_NAME, name);
    }

    private CmsMessageGatewayClient.MessageEntity getTransferToHotLineEntity(RedemptionServiceBusProperties properties, String name, String phone, String brand) {
        return CmsMessageGatewayClient.MessageEntity.create(C2_HOT_LINE, phone)
                .brand(brand)
                .putParam(FULL_NAME, name);
    }
}
