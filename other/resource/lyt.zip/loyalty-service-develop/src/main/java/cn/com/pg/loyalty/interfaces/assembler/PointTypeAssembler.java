package cn.com.pg.loyalty.interfaces.assembler;

import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.dto.*;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import org.apache.commons.collections.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author: Artermus wang on 2019-06-27 16:23
 */
public class PointTypeAssembler {

    private PointTypeAssembler() {
    }

    /**
     * 实体list转换为ListDTO
     */
    public static PointTypeListDTO toPointTypeListDTO(List<PointType> list) {
        PointTypeListDTO pointTypeListDTO = new PointTypeListDTO();
        pointTypeListDTO.setTotalSize(list.size());

        if (!list.isEmpty()) {
            pointTypeListDTO.setRecords(list.stream().map(PointTypeAssembler::toPointTypeDTO).collect(Collectors.toList()));
        }
        return pointTypeListDTO;
    }

    /**
     * 实体PointType 转换为DTO
     */
    public static PointTypeDTO toPointTypeDTO(PointType pointType) {
        PointTypeDTO pointTypeDTO = new PointTypeDTO();
        pointTypeDTO.setCreatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(pointType.getCreatedTime()));
        pointTypeDTO.setCreator(pointType.getCreatedBy());
        pointTypeDTO.setDescription(pointType.getDescription());
        pointTypeDTO.setModifier(pointType.getUpdatedBy());
        pointTypeDTO.setPointType(pointType.getPointType());
        pointTypeDTO.setPointTypeId(pointType.getId());
        pointTypeDTO.setRemark(pointType.getRemark());
        pointTypeDTO.setStatus(PointTypeDTO.StatusEnum.valueOf(pointType.getStatus().name()));
        pointTypeDTO.setUpdatedTime(LoyaltyDateTimeUtils.toOffsetDateTimeAtDefaultZone(pointType.getUpdatedTime()));
        pointTypeDTO.setLoyaltyStructure(pointType.getLoyaltyStructure());
        pointTypeDTO.setTransactionType(PointTypeDTO.TransactionTypeEnum.fromValue(pointType.getTransactionType().name()));
        pointTypeDTO.setRuleTemplateId(pointType.getRuleTemplate().name());
        pointTypeDTO.setMappingPointType(pointType.getMappingPointType());
        pointTypeDTO.setTypeAlias(pointType.getTypeAlias());
        pointTypeDTO.setSubAlias(pointType.getSubAlias());


        if (CollectionUtils.isNotEmpty(pointType.getDisplayLanguages())) {
            List<PointTypeDisplayMsgDTO> pointTypeDisplayMsgDTOS = pointType.getDisplayLanguages().stream().map(
                    item -> {
                        PointTypeDisplayMsgDTO pointTypeDisplayMsgDTO = new PointTypeDisplayMsgDTO();
                        pointTypeDisplayMsgDTO.setLanguage(Language.valueOf(item.getLanguage().toString().toUpperCase()));
                        pointTypeDisplayMsgDTO.setDescription(item.getDescription());
                        return pointTypeDisplayMsgDTO;
                    }
            ).collect(Collectors.toList());
            pointTypeDTO.setDisplayLanguages(pointTypeDisplayMsgDTOS);
        } else {
            pointTypeDTO.setDisplayLanguages(Collections.emptyList());
        }
        return pointTypeDTO;
    }


    public static PointType toPointType(AddPointTypeCommand command, LoyaltyStructure loyaltyStructure, String createdBy) {
        TransactionType transactionType = TransactionType.valueOf(command.getTransactionType().name());
        RuleTemplate ruleTemplate = RuleTemplate.getRuleTemplateById(command.getRuleTemplateId());
        PointType pointType = new PointType(command.getPointType(), command.getDescription(), command.getRemark(), loyaltyStructure.name(), createdBy, transactionType, ruleTemplate);
        pointType.setDisplayLanguages(toPointTypeDisplayMsgList(command.getDisplayLanguages()));
        pointType.configAlias(command.getTypeAlias(), command.getSubAlias());
        return pointType;
    }


    public static List<PointType.PointTypeDisplayMsg> toPointTypeDisplayMsgList(List<PointTypeDisplayMsgDTO> displayLanguages) {
        if (CollectionUtils.isEmpty(displayLanguages)) {
            return Collections.emptyList();
        }
        ParamValidator.validateDuplicateLanguage(displayLanguages.stream().map(PointTypeDisplayMsgDTO::getLanguage).collect(Collectors.toList()));
        return displayLanguages.stream().map(
                item -> new PointType.PointTypeDisplayMsg((ParamValidator.validateLanguage(item.getLanguage().name())), item.getDescription())
        ).collect(Collectors.toList());
    }
}
