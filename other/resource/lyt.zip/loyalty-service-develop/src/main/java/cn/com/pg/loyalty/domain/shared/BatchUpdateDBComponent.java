package cn.com.pg.loyalty.domain.shared;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.transaction.Transaction;

public interface BatchUpdateDBComponent {
    void saveTransactionAndAccount(Transaction transaction, Account account);

    void saveAccountAndTransactionV2(Account account, Transaction... transactionList);
}
