package cn.com.pg.loyalty;

import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.net.JarURLConnection;
import java.net.URL;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import static org.hamcrest.Matchers.notNullValue;

/**
 * @author tangjia
 * @date 2019/6/14
 * @description 这个类是用来测试Swagger自动生成的DTO，完成单元测试覆盖率的
 */
public class DTOUnitTest {
    private static final String CLASS_SUFFIX = ".class";
    private static final String CLASS_FILE_PREFIX = File.separator + "classes"  + File.separator;
    private static final String PACKAGE_SEPARATOR = ".";
    private static final String PACKAGE_PATH_DTO = "cn.com.pg.loyalty.interfaces.dto";

    public final static String TYPE_STRING = "class java.lang.String";
    public final static String TYPE_INTEGER = "class java.lang.Integer";
    public final static String TYPE_SHORT = "class java.lang.Short";
    public final static String TYPE_DOUBLE = "class java.lang.Double";
    public final static String TYPE_BOOLEAN = "class java.lang.Boolean";
    public final static String TYPE_DATE = "class java.util.Date";


    @Test
    public void testDto() throws IOException, ClassNotFoundException {
        List<String> list = getClazzName(PACKAGE_PATH_DTO, true);
        for (String pathString : list) {
            Class<?> aClass = Class.forName(pathString);
            mockInvokeMethod(aClass);
        }
        Assert.assertNotNull(list);
    }

    private static void mockInvokeMethod(Class aClass) {
        if (aClass.isInterface()) {
            return;
        }
        if (aClass.getClasses().length != 0) {
            for (Class childCls : aClass.getClasses()) {
                mockInvokeMethod(childCls);
            }
        }
        Method[] methods = aClass.getMethods();
        methods = excludeSomeMethod(methods);
        for (Method method : methods) {
            Object[] args = new Object[method.getParameterCount()];
            Parameter[] parameters = method.getParameters();
            for (int i = 0; i < method.getParameterCount(); i++) {
                Parameter parameter = parameters[i];
                args[i] = getInstance(parameter.getType());
            }
            try {
                if (!aClass.isEnum()) {
                    Object obj = getInstance(aClass);
                    method.invoke(obj, args);
                } else {
                    Object[] enumConstants = aClass.getEnumConstants();
                    if (enumConstants.length != 0) {
                        method.invoke(enumConstants[0], args);
                    }
                }
            } catch (Exception e) {
                System.out.println(aClass.getName() + "-" + method.getName() + ". error :" + e.getMessage());
            }
        }
    }

    private static Method[] excludeSomeMethod(Method[] methods) {
        Method[] objectMethods = Object.class.getMethods();
        List<Method> excludedMethodList = new ArrayList<>();
        for (Method method : methods) {
            if (method.getName().equals("valueOf")
                    || method.getName().equals("compareTo")) {
                continue;
            }
            if (method.getName().equals("toString")
                    || method.getName().equals("equals")
                    || method.getName().equals("hashCode")) {
                excludedMethodList.add(method);
                continue;
            }
            boolean isSame = false;
            for (Method objectMethod : objectMethods) {
                if (method.getName().equals(objectMethod.getName())) {
                    isSame = true;
                    break;
                }
            }
            if (!isSame) {
                excludedMethodList.add(method);
            }
        }
        Method[] excludedMethods = new Method[excludedMethodList.size()];
        return excludedMethodList.toArray(excludedMethods);
    }

    private static Object getInstance(Class cls) {
        String type = cls.toString();
        if (type.equals(TYPE_STRING)) {
            return UUID.randomUUID().toString();
        }
        if (type.equals(TYPE_INTEGER)) {
            return Math.toIntExact(Math.round(Math.random()));
        }
        if (type.equals(TYPE_SHORT)) {
            return 23;
        }
        if (type.equals(TYPE_DOUBLE)) {
            return Math.random();
        }
        if (type.equals(TYPE_BOOLEAN)) {
            return true;
        }
        if (type.equals(TYPE_DATE)) {
            return new Date();
        }

        Constructor[] declaredConstructors = cls.getDeclaredConstructors();
        for (Constructor constructor : declaredConstructors) {
                Object[] args = new Object[constructor.getParameterCount()];
                Parameter[] parameters = constructor.getParameters();
                for (int i = 0; i < constructor.getParameterCount(); i++) {
                    Parameter parameter = parameters[i];
                    args[i] = getInstance(parameter.getType());
                }
                try {
                    return constructor.newInstance(args);
                } catch (Exception e) {

                }

        }
        return null;
    }


    public static List<String> getClazzName(String packageName, boolean showChildPackageFlag ) throws IOException {
        List<String> result = new ArrayList<>();
        String suffixPath = packageName.replaceAll("\\.", "/");
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        try {
            Enumeration<URL> urls = loader.getResources(suffixPath);
            while(urls.hasMoreElements()) {
                URL url = urls.nextElement();
                if(url != null) {
                    String protocol = url.getProtocol();
                    if("file".equals(protocol)) {
                        String path = url.getPath();
                        System.out.println(path);
                        result.addAll(getAllClassNameByFile(new File(path), showChildPackageFlag));
                    } else if("jar".equals(protocol)) {
                        JarFile jarFile = null;
                        try{
                            jarFile = ((JarURLConnection) url.openConnection()).getJarFile();
                        } catch(Exception e){
                            e.printStackTrace();
                        }
                        if(jarFile != null) {
                            result.addAll(getAllClassNameByJar(jarFile, packageName, showChildPackageFlag));
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;

    }

    private static List<String> getAllClassNameByFile(File file, boolean flag) {
        List<String> result =  new ArrayList<>();
        if(!file.exists()) {
            return result;
        }
        if(file.isFile()) {
            String path = file.getPath();
            // 注意：这里替换文件分割符要用replace。因为replaceAll里面的参数是正则表达式,而windows环境中File.separator="\\"的,因此会有问题
            if(path.endsWith(CLASS_SUFFIX)) {
                path = path.replace(CLASS_SUFFIX, "");
                // 从"/classes/"后面开始截取
                String clazzName = path.substring(path.indexOf(CLASS_FILE_PREFIX) + CLASS_FILE_PREFIX.length())
                        .replace(File.separator, PACKAGE_SEPARATOR);
                if(-1 == clazzName.indexOf("$")) {
                    result.add(clazzName);
                }
            }
            return result;

        } else {
            File[] listFiles = file.listFiles();
            if(listFiles != null && listFiles.length > 0) {
                for (File f : listFiles) {
                    if(flag) {
                        result.addAll(getAllClassNameByFile(f, flag));
                    } else {
                        if(f.isFile()){
                            String path = f.getPath();
                            if(path.endsWith(CLASS_SUFFIX)) {
                                path = path.replace(CLASS_SUFFIX, "");
                                // 从"/classes/"后面开始截取
                                String clazzName = path.substring(path.indexOf(CLASS_FILE_PREFIX) + CLASS_FILE_PREFIX.length())
                                        .replace(File.separator, PACKAGE_SEPARATOR);
                                if(-1 == clazzName.indexOf("$")) {
                                    result.add(clazzName);
                                }
                            }
                        }
                    }
                }
            }
            return result;
        }
    }

    /**
     * 递归获取jar所有class文件的名字
     * @param jarFile
     * @param packageName 包名
     * @param flag  是否需要迭代遍历
     * @return List
     */
    private static List<String> getAllClassNameByJar(JarFile jarFile, String packageName, boolean flag) {
        List<String> result =  new ArrayList<>();
        Enumeration<JarEntry> entries = jarFile.entries();
        while(entries.hasMoreElements()) {
            JarEntry jarEntry = entries.nextElement();
            String name = jarEntry.getName();
            // 判断是不是class文件
            if(name.endsWith(CLASS_SUFFIX)) {
                name = name.replace(CLASS_SUFFIX, "").replace("/", ".");
                if(flag) {
                    // 如果要子包的文件,那么就只要开头相同且不是内部类就ok
                    if(name.startsWith(packageName) && -1 == name.indexOf("$")) {
                        result.add(name);
                    }
                } else {
                    // 如果不要子包的文件,那么就必须保证最后一个"."之前的字符串和包名一样且不是内部类
                    if(packageName.equals(name.substring(0, name.lastIndexOf("."))) && -1 == name.indexOf("$")) {
                        result.add(name);
                    }
                }
            }
        }
        return result;
    }
}
