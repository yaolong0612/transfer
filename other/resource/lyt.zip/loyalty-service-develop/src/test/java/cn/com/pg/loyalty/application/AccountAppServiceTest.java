package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PartitionKeyUtils;
import cn.com.pg.loyalty.domain.shared.UUIDUtil;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.*;
import lombok.Data;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_OLAY;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * @Author: Hayden
 * @CreateDate: 2020/8/20 16:11
 * @UpdateUser: Hayden
 * @UpdateDate: 2020/8/20 16:11
 * @Version: 1.0
 * @Description:
 */
@RunWith(MockitoJUnitRunner.class)
public class AccountAppServiceTest {

    @InjectMocks
    AccountAppService accountAppService;
    @Mock
    AccountValidateService accountValidateService;
    @Mock
    AccountRepository accountRepository;
    @Mock
    private TransactionRepository transactionRepository;
    @Mock
    private OperationService operationService;
    @Mock
    private OrderRecalculateForOptDelay orderRecalculateForOptDelay;
    @Mock
    private CacheService cacheService;

    private static final String MEMBER_ID = "1234567";
    private static final String EXPIRE_ACTIVITY_ID = "expireActivityId";
    private static final String BRAND_SKII = StructureConfig.BRAND_SKII;
    private static final String REGION_JP = "JP";
    private static final LoyaltyStructure JP_STRUCTURE = StructureConfig.getJPStructure();
    private static final LoyaltyStructure ML_STRUCTURE = StructureConfig.getMLOlayStructure();

    private static final String CHANNEL_SPA = "SPA";


    @Before
    public void setUp() {
        Mockito.when(cacheService.findLoyaltyStructure("ML",BRAND_OLAY))
                .thenReturn(ML_STRUCTURE);
        Mockito.when(cacheService.findLoyaltyStructure("JP",BRAND_SKII))
                .thenReturn(JP_STRUCTURE);
    }

    /**
     * 品牌限制
     */
    @Test
    public void when_brand_is_not_SKII_then_ignore() {
        accountAppService.recalculateAccount(MEMBER_ID, BRAND_OLAY, "ML");
        Mockito.verify(accountValidateService, never()).validate(any(), anyString());

    }


    @Test
    public void validateRecalculateAccount() {
        Account account = setupAccount();
        List<Transaction> transactionList = setUpHistoryTransactions(setUpPointInfo(), account.loyaltyId());
        setupAccountPointWithHistoryOrder(transactionList, account);
        commonMock(account, transactionList);
        accountAppService.recalculateAccount(MEMBER_ID, BRAND_SKII, REGION_JP);
        Mockito.verify(accountRepository, times(1)).save(any(Account.class));
    }

    public void commonMock(Account account, List<Transaction> transactionList) {
        when(accountValidateService.validate(JP_STRUCTURE, MEMBER_ID)).thenReturn(account);
        String partitionKey = PartitionKeyUtils.getTransactionPartitionKey(account.loyaltyId());
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(partitionKey, account.loyaltyId())).thenReturn(transactionList);
    }


    /**
     * 根据历史订单计算积分
     */
    private void setupAccountPointWithHistoryOrder(List<Transaction> transactionList, Account account) {
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(1400);
        subAccount.setPointAvailable(900);
        subAccount.setTotalPurchaseTimes(3);
        subAccount.setPointUsed(200);
        subAccount.setPointAboutExpire(900);
        subAccount.setPointExpired(300);
        Optional<Transaction> last = transactionList.stream().max(Comparator.comparing(Transaction::getCreatedTime));
        LocalDate localDate = last.isPresent() ? last.get().getCreatedTime().toLocalDate() : LocalDateTime.now().toLocalDate();
        subAccount.setPointAboutExpiredDate(localDate);
    }

    private Account setupAccount() {
        Account account = new Account(MEMBER_ID, JP_STRUCTURE);
        SubAccount subAccount = new SubAccount();
        subAccount.setTotalPoint(0);
        subAccount.setPointAvailable(0);
        subAccount.setPointUsed(0);
        subAccount.setPointExpired(0);
        subAccount.setPointAboutExpire(0);
        subAccount.setTotalPurchaseTimes(0);
        subAccount.setUpdatedTime(LocalDateTime.now());
        SubAccounts subAccountList = new SubAccounts();
        subAccountList.put(BRAND_SKII, subAccount);
        account.setSubAccountList(subAccountList);
        return account;
    }

    /**
     * 初始化积分时间流水
     */
    private List<PointInfo> setUpPointInfo() {
        List<PointInfo> pointInfoList = new ArrayList<>();
        LocalDateTime now = LocalDateTime.now();
        //3-2年前的记录
        PointInfo i202 = new PointInfo(now.minusYears(3).plusMonths(1), 100, TransactionType.INTERACTION);
        PointInfo o203 = new PointInfo(now.minusYears(3).plusMonths(2), 200, TransactionType.ORDER);
        PointInfo i204 = new PointInfo(now.minusYears(3).plusMonths(3), 300, TransactionType.INTERACTION);
        pointInfoList.add(i202);
        pointInfoList.add(o203);
        pointInfoList.add(i204);
        //2-1年前的记录
        PointInfo i102 = new PointInfo(now.minusYears(2).plusMonths(1), 100, TransactionType.INTERACTION);
        //第二天过期，过期积分300分
        PointInfo e10302 = new PointInfo(now.minusYears(2).plusMonths(2).plusDays(1), -300, TransactionType.INTERACTION, true);
        PointInfo o104 = new PointInfo(now.minusYears(2).plusMonths(3), 300, TransactionType.ORDER);
        pointInfoList.add(i102);
        pointInfoList.add(e10302);
        pointInfoList.add(o104);
        //近1年前的记录
        PointInfo i002 = new PointInfo(now.minusYears(1).plusMonths(1), 100, TransactionType.INTERACTION);
        PointInfo r003 = new PointInfo(now.minusYears(1).plusMonths(2), 200, TransactionType.REDEMPTION);
        PointInfo o004 = new PointInfo(now.minusYears(1).plusMonths(3).minusDays(1), 300, TransactionType.ORDER);
        pointInfoList.add(i002);
        pointInfoList.add(r003);
        pointInfoList.add(o004);

        return pointInfoList;
    }


    /**
     * 初始化积分流水
     */
    private List<Transaction> setUpHistoryTransactions(List<PointInfo> pointInfoList, String loyaltyId) {
        List<Transaction> transactionList = new ArrayList<>();
        pointInfoList.forEach(pointInfo -> transactionList.add(setUpHistoryTransaction(pointInfo, loyaltyId)));
        return transactionList;
    }

    private Transaction setUpHistoryTransaction(PointInfo pointInfo, String loyaltyId) {
        if (pointInfo.getTransactionType() == TransactionType.ORDER) {
            Order order = new Order(loyaltyId, BRAND_SKII, CHANNEL_SPA, UUIDUtil.generator(), JP_STRUCTURE,
                    pointInfo.getCreatedTime(), new HashSet<>(), MEMBER_ID, UUIDUtil.generator());
            order.setCreatedTime(pointInfo.createdTime);
            order.setPoint(pointInfo.point);
            return order;
        }
        if (pointInfo.getTransactionType() == TransactionType.INTERACTION) {
            Interaction interaction = new Interaction(loyaltyId, BRAND_SKII, CHANNEL_SPA, JP_STRUCTURE, MEMBER_ID);
            interaction.setCreatedTime(pointInfo.createdTime);
            interaction.setPoint(pointInfo.point);
            if (pointInfo.isExpiredRecord()) {
                interaction.setActivityId(EXPIRE_ACTIVITY_ID);
            }
            return interaction;
        }
        Redemption redemption = new Redemption(BRAND_SKII, CHANNEL_SPA, "张三",
                "13424000000", "广东",
                "广州", "天河区", "", "body.getReceivingStoreCode()",
                " body.getPostalCode()", MEMBER_ID, 10D, null, null, ValueType.DEFAULT);
        redemption.setCreatedTime(pointInfo.createdTime);
        redemption.setPoint(pointInfo.point);
        return redemption;

    }


    @Data
    public static class PointInfo {
        private LocalDateTime createdTime;
        private int point;
        private TransactionType transactionType;
        private boolean expiredRecord;

        public PointInfo(LocalDateTime createdTime, int point, TransactionType transactionType) {
            this.createdTime = createdTime;
            this.point = point;
            this.transactionType = transactionType;
            this.expiredRecord = false;
        }

        public PointInfo(LocalDateTime createdTime, int point, TransactionType transactionType, boolean expiredRecord) {
            this.createdTime = createdTime;
            this.point = point;
            this.transactionType = transactionType;
            this.expiredRecord = expiredRecord;
        }
    }
}
