package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountValidateService;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.GiftIssuedInventory;
import cn.com.pg.loyalty.domain.shared.CalculateService;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.*;

import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
public class RedemptionServiceTest {
    @InjectMocks
    private RedemptionService redemptionService;
    @Mock
    private TransactionForEsRepository repository;
    @Mock
    private CalculateService calculateServiceImpl;
    @Mock
    private AccountValidateService accountValidateService;
    @Mock
    private ActivitiesService activitiesService;
    @Mock
    private RedemptionRepositoryV2 redemptionRepositoryV2;
    @Mock
    private ActivityRepository activityRepository;
    @Mock
    private GiftIssuedInventory giftIssuedInventory;

    private PageableResult<Redemption> pageableResult;

    private LoyaltyStructure loyaltyStructure = StructureConfig.getMLPampersStructure();

    @Before
    public void setUp() throws Exception {
        //组装数据
        ArrayList<Redemption> redemptionArrayList = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            redemptionArrayList.add(createdRedemption());
        }
        pageableResult = new PageableResult<>(16, redemptionArrayList);
    }
    Redemption createdRedemption(){
        return new Redemption();
    }

    @Test
    public void fetchRedemptionList() {
        when(repository.fetchRedemptionList(any(LocalDateTime.class), any(LocalDateTime.class),anyMap(),any(String.class),
                any(Integer.class), any(Integer.class))).thenReturn(pageableResult);
        PageableResult<Redemption> redemptionPageableResult = redemptionService.fetchRedemptionList("activity",
                "OLAY",
                OffsetDateTime.now().toLocalDateTime(), OffsetDateTime.now().toLocalDateTime(), 10, 9,
                "C2", RedemptionStatus.CREATED, DeliveryChannel.C2, "TMALL");
        Assert.assertThat(pageableResult.getRecords(), is(redemptionPageableResult.getRecords()));
        Assert.assertThat(pageableResult.getTotalSize(), is(redemptionPageableResult.getTotalSize()));
    }

    @Test
    public void createRedemptionTest() {
        Redemption redemption = new Redemption();
        redemption.setMemberId("123456");
        redemption.setActivityId("456789");
        redemption.setBrand("PAMPERS");
        Account account = new Account();
        account.setMemberId("123456");
        account.setRegion("ML");
        account.setId("654321");
        Activity activity = new Activity();
        activity.setDescription("test");
        AccountTransactionResult accountTransactionResult = new AccountTransactionResult();
        when(activitiesService.checkRedemptionActivity(anyString(), any())).thenReturn(activity);
        when(accountValidateService.validate(any(), anyString())).thenReturn(account);
        when(calculateServiceImpl.calculateRedemption(any(), any(), any(), any(),any(), any())).thenReturn(accountTransactionResult);
        when(redemptionRepositoryV2.findInActivityNotInRedemptionStatus(any(), any(), any())).thenReturn(null);
        AccountTransactionResult redemption1 = redemptionService.createRedemption(redemption, loyaltyStructure, Locale.CHINESE);
        Assert.assertNotNull(redemption1);
    }

    @Test
    public void syncGiftIssuedTest() {
        Activity activity = new Activity();
        activity.setDescription("test");
        activity.setId("102030");
        Set<String> giftIds = new HashSet<>();
        giftIds.add("123");
        giftIds.add("456");
        giftIds.add("789");
        AccountTransactionResult accountTransactionResult = new AccountTransactionResult();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(anyString())).thenReturn(activityList);
        Exception exception = null;
        try {
            redemptionService.syncGiftIssued(activity.getId(), giftIds);
        } catch (Exception e) {
            exception = e;
            e.printStackTrace();
        }
        Assert.assertNull(exception);
    }
}
