package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dependence.KpiTemplate;
import cn.com.pg.loyalty.application.dependence.RequestOrdersMessage;
import cn.com.pg.loyalty.application.dto.RequestOrderCommand;
import cn.com.pg.loyalty.application.dto.RequestOrderItemDTO;
import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.TierRulesCalculateAble;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.CalculateService;
import cn.com.pg.loyalty.domain.shared.ResultCodeMapper;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.Order;
import cn.com.pg.loyalty.domain.transaction.OrderItem;
import cn.com.pg.loyalty.domain.transaction.OrderRecalculateAboutExpiredPointService;
import cn.com.pg.loyalty.domain.transaction.OrderRepositoryV2;
import cn.com.pg.loyalty.domain.transaction.order.OrderRollbackService;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_SKII;
import static cn.com.pg.loyalty.domain.structure.StructureConfig.CHANNEL_JD;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class OrderAppServiceTest {
    @Mock
    MessageService messageService;
    @Mock
    AccountService accountService;
    @Mock
    BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;
    @Mock
    CacheService cacheService;
    @Mock
    KpiTemplate kpiTemplate;
    @Mock
    OrderRepositoryV2 orderRepositoryV2;
    @Mock
    CalculateService calculateServiceImpl;
    @Mock
    OrderRecalculateAboutExpiredPointService orderRecalculateAboutExpiredPointService;
    @Mock
    TaskService taskService;
    @Mock
    TierRulesCalculateAble tierRulesCalculateEngine;
    @Mock
    StringRedisTemplate stringRedisTemplate;
    @Mock
    ValueOperations<String, String> valueOperations;
    @Mock
    OrderRollbackService orderRollbackService;
    @Mock
    Logger log;
    @InjectMocks
    OrderAppService orderAppService;

    private LoyaltyStructure structure = StructureConfig.getMLOlayStructure();

    @Before
    public void setUp() {
        Account account = new Account("01", structure);
        account.register(structure, "OLAY", "TMALL", "21", LocalDateTime.now());
        Mockito.when(accountService.fetchAccountByMemberIdAndCheck(any(), anyString()))
                .thenReturn(account);
        Mockito.when(cacheService.findLoyaltyStructure(anyString(), anyString()))
                .thenReturn(structure);
        Mockito.when(stringRedisTemplate.opsForValue()).thenReturn(valueOperations);
        Mockito.when(cacheService.getKey(any(), any())).thenReturn("key");
    }

    private RequestOrderCommand getRequestOrderCommand(String orderId, String refundId, Double realTotalAmount, Double refundAmount) {
        RequestOrderCommand order = new RequestOrderCommand();
        order.setOrderId(orderId);
        order.setRealTotalAmount(realTotalAmount);
        order.setRefundAmount(refundAmount);
        order.setOrderDateTime(LocalDateTime.now());
        order.setOrderUpdateTime(LocalDateTime.now());
        order.setStoreCode("1001");
        order.setChannel("JD");
        order.setAssociateTransactionId(refundId);
        RequestOrderItemDTO dto = new RequestOrderItemDTO();
        dto.setSku("01");
        dto.setRealAmount(realTotalAmount);
        dto.setRefundAmount(refundAmount);
        dto.setPurchaseQty(1);
        Set<RequestOrderItemDTO> orderItems = new HashSet<>();
        orderItems.add(dto);
        order.setOrderItems(orderItems);
        return order;
    }

    private Order getOrder(String orderId, double realTotalAmount, LocalDateTime orderDateTime) {
        Order order = new Order("1", "OLAY", "JD", structure, "01");
        order.setOrderDateTime(orderDateTime);
        order.setOrderId(orderId);
        order.setChannel("JD");
        order.setRealTotalAmount(realTotalAmount);
        order.setPoint(100);
        order.setRefundAmount(0.0);
        order.setExpiredTime(LocalDateTime.now().plusDays(100));
        OrderItem dto = new OrderItem();
        dto.setSku("01");
        dto.setRealAmount(realTotalAmount);
        dto.setRefundAmount(0.0);
        dto.setPurchaseQty(1);
        Set<OrderItem> orderItems = new HashSet<>();
        orderItems.add(dto);
        order.setOrderItems(orderItems);
        return order;
    }

    private RequestOrderCommand getRequestOrderCommand() {
        RequestOrderCommand order1 = new RequestOrderCommand();
        order1.setBrand(BRAND_SKII);
        order1.setOrderDateTime(LocalDateTime.of(2019, 07, 11, 9, 0, 0));
        order1.setOrderUpdateTime(LocalDateTime.of(2019, 07, 11, 9, 0, 0));
        order1.setRealTotalAmount(100.0);
        order1.setStoreCode("1001");
        order1.setChannel("JD");
        order1.setOrderId("01");
        RequestOrderItemDTO dto = new RequestOrderItemDTO();
        dto.setSku("01");
        dto.setRealAmount(1000.0);
        dto.setPurchaseQty(1);
        Set<RequestOrderItemDTO> orderItems = new HashSet<>();
        orderItems.add(dto);
        order1.setOrderItems(orderItems);
        return order1;
    }

    @Test(expected = SystemException.class)
    public void when_brand_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", null, "JP", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_region_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", null, transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_channel_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setChannel(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_orderId_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setOrderId(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_amount_is_min_0_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setRealTotalAmount(-100.0);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_amount_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setRealTotalAmount(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_order_date_time_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setOrderDateTime(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_order_item_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.setOrderItems(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_sku_is_null_then_return_exception() {
        RequestOrderCommand order1 = getRequestOrderCommand();
        order1.setChannel(CHANNEL_JD);
        List<RequestOrderCommand> transactions = new ArrayList<>();
        transactions.add(order1);
        order1.getOrderItems().iterator().next().setSku(null);
        RequestOrdersMessage message = new RequestOrdersMessage("122000005031", "OLAY", "ML", transactions);
        orderAppService.calculateOrders(message);
    }

    @Test(expected = SystemException.class)
    public void when_order_with_not_structure_then_exception() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("01", null, 1000.0, 0.0));
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        commands.get(0).setBrand("SKII");
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        orderAppService.calculateOrders(message);

    }

    @Test
    public void when_order_with_refund_and_non_refund_order_then_send_to_queue() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("01", null, 1000.0, 0.0));
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        orderAppService.calculateOrders(message);
        Mockito.verify(messageService, Mockito.times(2))
                .delayOrdersRequest(any(), any());
        Assert.assertEquals("02", message.findRefundOrderMessage().getTransactions().get(0).getOrderId());
        Assert.assertEquals("01", message.findNonRefundOrderMessage().getTransactions().get(0).getOrderId());
    }

    @Test
    public void when_refund_order_no_mapping_order_then_exception() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        Mockito.when(valueOperations.setIfAbsent(anyString(), anyString(), anyLong(), any())).thenReturn(Boolean.TRUE);
        Mockito.when(orderRepositoryV2.findMemberOrdersInOrderIds(anyString(), anyList()))
                .thenReturn(new ArrayList<>());
        ResultCodeMapper resultCodeMapper = null;
        try {
            orderAppService.calculateOrders(message);
        } catch (SystemException e) {
            resultCodeMapper = e.resultCodeMapper();
        }
        Assert.assertEquals(ResultCodeMapper.OPERATION_TOO_FAST, resultCodeMapper);
    }

    @Test
    public void when_refund_order_no_mapping_order_remain_try_times_0_then_not_find_exception() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        Mockito.when(orderRepositoryV2.findMemberOrdersInOrderIds(anyString(), anyList()))
                .thenReturn(new ArrayList<>());
        ResultCodeMapper resultCodeMapper = null;
        try {
            orderAppService.calculateOrders(message);
        } catch (SystemException e) {
            resultCodeMapper = e.resultCodeMapper();
        }
        Assert.assertEquals(ResultCodeMapper.ORIGIN_ORDER_NOT_FIND, resultCodeMapper);
    }

    @Test
    public void when_refund_order_no_mapping_order_remain_try_times_1_then_not_find_exception() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        Mockito.when(orderRepositoryV2.findMemberOrdersInOrderIds(anyString(), anyList()))
                .thenReturn(new ArrayList<>());
        Mockito.when(valueOperations.increment(anyString(), anyLong())).thenReturn(1L);
        ResultCodeMapper resultCodeMapper = null;
        try {
            orderAppService.calculateOrders(message);
        } catch (SystemException e) {
            resultCodeMapper = e.resultCodeMapper();
        }
        Assert.assertEquals(ResultCodeMapper.OPERATION_TOO_FAST, resultCodeMapper);
    }

    @Test
    public void when_refund_order_mapping_order_then_calculate() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 0.0, 100.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        List<Order> mapOrder = new ArrayList<>();
        mapOrder.add(getOrder("01", 2000, LocalDateTime.now().minusDays(10)));
        Mockito.when(orderRepositoryV2.findMemberOrdersInOrderIds(anyString(), anyList()))
                .thenReturn(mapOrder);
        orderAppService.calculateOrders(message);
        Mockito.verify(calculateServiceImpl, Mockito.times(1))
                .calculateOrderPoint(any(), any(), any(), any(), anyList(), anyInt());
    }

    @Test(expected = SystemException.class)
    public void when_refund_order_mapping_order_but_amount_not_match_then_no_calculate() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 0.0, 3000.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        List<Order> mapOrder = new ArrayList<>();
        mapOrder.add(getOrder("01", 2000, LocalDateTime.now()));
        Mockito.when(orderRepositoryV2.findMemberOrdersInOrderIds(anyString(), anyList()))
                .thenReturn(mapOrder);
        orderAppService.calculateOrders(message);
    }

    @Test
    public void when_non_refund_order_not_mapping_order_then_calculate() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 3000.0, 0.0));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        List<Order> mapOrder = new ArrayList<>();
        mapOrder.add(getOrder("01", 2000, LocalDateTime.now()));
        orderAppService.calculateOrders(message);
        Mockito.verify(calculateServiceImpl, Mockito.times(1))
                .calculateOrderPoint(any(), any(), any(), any(), anyList(), anyInt());
    }

    @Test
    public void when_non_refund_order_not_mapping_order_then_no_calculate() {
        List<RequestOrderCommand> commands = new ArrayList<>();
        commands.add(getRequestOrderCommand("02", "01", 3000.0, 0.0));
        commands.get(0).setOrderDateTime(LocalDateTime.now().minusYears(3));
        RequestOrdersMessage message = new RequestOrdersMessage("01", "OLAY", "ML", commands);
        List<Order> mapOrder = new ArrayList<>();
        mapOrder.add(getOrder("01", 2000, LocalDateTime.now()));
        orderAppService.calculateOrders(message);
        Mockito.verify(calculateServiceImpl, Mockito.never())
                .calculateOrderPoint(any(), any(), any(), any(), anyList(), anyInt());
    }
}

