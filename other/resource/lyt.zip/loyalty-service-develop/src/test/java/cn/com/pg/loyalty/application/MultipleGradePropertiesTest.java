package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.prop.MultipleGradePointProperties;
import org.junit.Assert;
import org.junit.Test;

import java.time.LocalDateTime;
import java.util.HashMap;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;

public class MultipleGradePropertiesTest {

    @Test
    public void setGetMethodTest(){
        MultipleGradePointProperties properties = new MultipleGradePointProperties();
        LocalDateTime localDateTime = properties.exemptionPeriodStartAt();
        Assert.assertThat(localDateTime, not(LocalDateTime.now()));
    }

    @Test
    public void setGetMethodTest2(){
        MultipleGradePointProperties properties = new MultipleGradePointProperties();
        LocalDateTime localDateTime = properties.exemptionPeriodEndAt();
        Assert.assertThat(localDateTime, not(LocalDateTime.now()));
    }
}
