package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.prop.RedemptionProperties;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.interfaces.dto.Event;
import com.alibaba.fastjson.JSON;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * @author vincenzo
 * @description
 * @date 2023/1/10
 */
@RunWith(MockitoJUnitRunner.class)
public class EventAppServiceTest {

    @InjectMocks
    private EventAppService eventAppService;


    @Mock
    private RedemptionRepository redemptionRepository;

    @Mock
    private MessageService messageService;

    @Mock
    private CacheService cacheService;

    @Test
    public void publish_event() {
        eventAppService.publishEvent("sourceId", Event.EventSourceTypeEnum.TRANSACTION, "sourceType", "sourcePartitionKey");
        Mockito.verify(messageService).sendDelayEventMsg(any(), any());
    }

    @Test
    public void process_event_when_redemption_can_not_be_found() {
        Event event = new Event();
        event.setSourceType(TransactionType.REDEMPTION.name());
        event.setSourcePartitionKey("sourcePartitionKey");
        event.setEventSourceType(Event.EventSourceTypeEnum.TRANSACTION);
        event.setSourceId("sourceId");

        when(redemptionRepository.findByPartitionKeyAndId(any(), any())).thenReturn(new ArrayList<Redemption>());
        SystemException catchSystemException = null;
        try {
            eventAppService.processEvent(event);
        } catch (SystemException e) {
            catchSystemException = e;
        }
        Assert.assertNotNull(catchSystemException);
    }

    private Redemption generateRedemptionForSdc(DeliveryChannel deliveryChannel, String brand) {

        List<GiftItem> giftItemList = new ArrayList<>();
        GiftItem giftItem = new GiftItem();
        giftItem.setGiftId("GiftId" + 1);
        giftItem.setQuantity(1);
        giftItem.setGiftName("GiftName" + 1);
        giftItemList.add(giftItem);
        Redemption redemption = new Redemption();
        redemption.setId("id");
        redemption.setActivityId("test_activity_id");
        redemption.setBrand(brand);
        redemption.setDeliveryChannel(deliveryChannel);
        redemption.setTransactionType(TransactionType.REDEMPTION);
        redemption.setStoreCode("StoreCode");
        redemption.setMemberId("MemberId");
        redemption.setPickUpDate(LocalDate.now());
        redemption.setCreatedTime(LocalDateTime.now());
        redemption.setChannel("WECHAT");
        redemption.setRedemptionStatus(RedemptionStatus.CREATED);
        redemption.setGiftItemList(giftItemList);

        return redemption;
    }


    private Gift generateGift() {
        Gift gift = new Gift();
        gift.setId("GiftId1");
        return gift;
    }

    public Activity generateActivity(DeliveryChannel deliveryChannel) {
        RedemptionProperties ruleProperties = new RedemptionProperties();
        ruleProperties.setDeliveryChannel(deliveryChannel);

        Activity activity = new Activity();
        activity.setId("test_activity_id");
        activity.setRuleProperties(JSON.toJSONString(ruleProperties));
        return activity;
    }


    @Test
    public void process_event_when_redemption_is_for_sdc() {

        Event event = new Event();
        event.setSourceType(TransactionType.REDEMPTION.name());
        event.setSourcePartitionKey("sourcePartitionKey");
        event.setEventSourceType(Event.EventSourceTypeEnum.TRANSACTION);
        event.setSourceId("sourceId");


        List<Redemption> redemptionList = new ArrayList();
        redemptionList.add(generateRedemptionForSdc(DeliveryChannel.C2, "SKII"));
        when(redemptionRepository.findByPartitionKeyAndId(any(), any())).thenReturn(redemptionList);
        when(cacheService.getGiftById(any())).thenReturn(generateGift());
        eventAppService.processEvent(event);

        Mockito.verify(messageService).sendMsgToTransactionEventTopic(any(), any());
    }

    @Test
    public void process_event_when_redemption_is_for_logistics() {

        Event event = new Event();
        event.setSourceType(TransactionType.REDEMPTION.name());
        event.setSourcePartitionKey("sourcePartitionKey");
        event.setEventSourceType(Event.EventSourceTypeEnum.TRANSACTION);
        event.setSourceId("sourceId");

        List<Redemption> redemptionList = new ArrayList();
        redemptionList.add(generateRedemptionForSdc(DeliveryChannel.LOGISTICS, "SKII"));
        when(redemptionRepository.findByPartitionKeyAndId(any(), any())).thenReturn(redemptionList);
        eventAppService.processEvent(event);
        Mockito.verify(messageService).sendMsgToTransactionEventTopic(any(), any());
    }

}
