package cn.com.pg.loyalty;

import lombok.extern.slf4j.Slf4j;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author Simon
 * @date 2019/6/23 16:48
 * @description 用来生成加密密码
 **/
@Slf4j
public class PasswordEncryptUtil {
    /**
     * 用来加密的密码
     * 需要和Bootstrap.yml中jasypt.encryptor.password: 配置相同
     */
    private final String password = "together";


    @Test
    public void generate() {
        //待加密字符串
        final String data = "";
        String encryptedData = encrypt(data);
        String result = "ENC(" + encryptedData + ")";
        System.out.println("Use this: " + result);
        Assert.assertNotNull(result);
    }

    @Test
    public void decrypt() {
        //待解密字符串
        String data = "yMT/U97VfHfo/vn+N69p+gT6KjLNFZO8o2xUjpMYSkdKK1Nq5z5b1/zkPY0YAixmxCfgtqkDd84r+CzZ1bFlSvGQJ5dja6Rth3ssc44EOBGXqjHAHE/1iTzrN0/TzPmeQaYsIvoLDcA=";
        String result = decrypt(data);
        log.info("result:{}", result);
        Assert.assertNotNull(result);
    }

    private PooledPBEStringEncryptor getEncryptor() {
        PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
        SimpleStringPBEConfig config = new SimpleStringPBEConfig();
        config.setPassword(password);
        config.setAlgorithm("PBEWithMD5AndDES");
        config.setKeyObtentionIterations("1000");
        config.setPoolSize("1");
        config.setProviderName(null);
        config.setProviderClassName(null);
        config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
        config.setIvGeneratorClassName("org.jasypt.salt.NoOpIVGenerator");
        config.setStringOutputType("base64");
        encryptor.setConfig(config);
        return encryptor;
    }

    public String encrypt(String data) {
        PooledPBEStringEncryptor encryptor = getEncryptor();
        return encryptor.encrypt(data);
    }

    public String decrypt(String data) {
        PooledPBEStringEncryptor encryptor = getEncryptor();
        return encryptor.decrypt(data);
    }
}
