package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.*;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.LoyaltyDateTimeUtils;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.DeliveryChannel;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import cn.com.pg.loyalty.interfaces.dto.AddRedemptionActivityCommand;
import cn.com.pg.loyalty.interfaces.dto.AddRedemptionGiftCommand;
import cn.com.pg.loyalty.interfaces.dto.UpdateRedemptionActivityCommand;
import cn.com.pg.loyalty.interfaces.dto.UpdateRedemptionActivityCommand.StatusEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import javax.validation.Validator;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_OLAY;
import static cn.com.pg.loyalty.domain.structure.StructureConfig.REGION_ML;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)

public class ActivitiesServiceTest {

    @InjectMocks
    private ActivitiesService activitiesService;

    @Mock
    private ActivityRepository activityRepository;

    @Mock
    private ActivityLogRepository activityLogRepository;

    @Mock
    private PointTypeRepository pointTypeRepository;

    @Mock
    private CacheService cacheService;

    @Mock
    private Validator validator;

    private static final String ruleTemplateId = "INTERACTION_BIND_POINT";
    private String userName = "huang.dh.3";
    private String activityId = null;
    private String activityName = "VIP OLAY Birthday";
    private String interactionPointType = "interaction_pointType";
    private String redemptionPointType = "redemption_pointType";
    private String orderPointType = "order_pointType";
    private OffsetDateTime startAt = null;
    private OffsetDateTime endAt = null;
    private ActivityStatus activityStatus = null;
    private String description = null;
    private RuleTemplate ruleTemplate = null;
    private String brand = null;
    private LoyaltyStructure loyaltyStructure = null;
    private String externalId = null;
    private String ruleProperties = null;
    private String remark = null;
    private int priority = 0;
    private int perPage = 10;
    private int page = 1;
    private String giftId = "1243522";
    private Map<String, RedemptionItem> redemptionItemMap = null;
    private Gift gift = null;
    private int totalLimitQuantity = 100;
    private boolean reduceInventory = true;
    private boolean checkConvertibilit = true;
    private DeliveryChannel deliveryChannel = DeliveryChannel.C2;
    private boolean allowCancel = false;
    private List<PointType> pointTypeList = new ArrayList<>();
    private TransactionType transactionType = null;
    private QrcodeItem qrderItem = null;
    private ArrayList<Activity> activities = null;
    private String limitProperty = "[{\"num\":4,\"pointOrSize\":3},{\"num\":6,\"pointOrSize\":4},{\"num\":8,\"pointOrSize\":5}]";
    private String purchaselimitProperty = "";
    private String redemptionTimesCalculationType = "";

    @Before
    public void setUp() {
        userName = "huang.dh.3";
        activityName = "VIP OLAY Birthday";
        activityId = "86232040382";
        startAt = OffsetDateTime.now().minusDays(10);
        endAt = OffsetDateTime.now();
        activityStatus = ActivityStatus.ACTIVATE;
        description = "description";
        ruleTemplate = RuleTemplate.valueOf(ruleTemplateId);
        brand = BRAND_OLAY;
        loyaltyStructure = StructureConfig.getMLOlayStructure();
        externalId = "123456";
        ruleProperties = "{\"point\":10}";
        perPage = 10;
        page = 1;
        redemptionItemMap = new HashMap<>();
        RedemptionItem item = new RedemptionItem();
        item.setIssuedNum(0);
        item.setTierLevel("ML_OLAY_2");
        item.setLimitQuantity(100);
        item.setPoint(100);
        item.setGiftId(giftId);
        item.setStock(200);
        item.setLogisticsGiftId("21321");
        transactionType = TransactionType.ORDER;
        gift = new Gift();
        gift.setId(giftId);
        gift.setItems(new ArrayList<>());
        gift.setMarketPrice(BigDecimal.ONE);
        gift.setImageUri("/img/2");
        gift.setLoyaltyStructure(loyaltyStructure.name());
        gift.setName("giftName");
        gift.setPoint(100);
        gift.setDescription("desc");
        redemptionItemMap.put(gift.getId(), item);
        totalLimitQuantity = 100;
        reduceInventory = true;
        checkConvertibilit = true;
        deliveryChannel = DeliveryChannel.C2;

        PointType pt = new PointType(interactionPointType, "", "", loyaltyStructure.name(), userName, TransactionType.INTERACTION, RuleTemplate.INTERACTION_ADJUST_POINT_BY_CLIENT);
        PointType pt2 = new PointType(orderPointType, "", "", loyaltyStructure.name(), userName, TransactionType.ORDER, RuleTemplate.INTERACTION_BIND_POINT);
        PointType pt3 = new PointType(redemptionPointType, "", "", loyaltyStructure.name(), userName, TransactionType.REDEMPTION, RuleTemplate.INTERACTION_ADJUST_POINT_TIMES);
        pointTypeList.add(pt);
        pointTypeList.add(pt2);
        pointTypeList.add(pt3);

        qrderItem = new QrcodeItem("M110", QrcodeItem.ProductTypeEnum.BASIC, 100, 20, 1.0f, "this is a test data");
        ArrayList<QrcodeItem> qrcodeItems = new ArrayList<>();
        qrcodeItems.add(qrderItem);
        Activity activity = new Activity();
        activity.setTransactionType(TransactionType.INTERACTION);
        activity.setPointType(Transaction.PointTypeEnum.SCAN_CODE.toString());
        activity.setQrcodeItems(qrcodeItems);
        activities = new ArrayList<>();
        activities.add(activity);

        Mockito.when(cacheService.findLoyaltyStructure("ML", BRAND_OLAY))
                .thenReturn(loyaltyStructure);

        Mockito.when(cacheService.findLoyaltyStructureById(loyaltyStructure.name()))
                .thenReturn(loyaltyStructure);
    }

    @Test
    public void addInteractionActivity() {
        Activity activity = Activity.Builder
                .interactionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        when(activityRepository.existsByExternalId(externalId)).thenReturn(false);
        when(activityRepository.save(ArgumentMatchers.any(Activity.class))).thenReturn(activity);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        Activity result = activitiesService.addInteractionActivity(userName, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), activityStatus, description, brand, loyaltyStructure.getRegion(),
                externalId, ruleProperties, remark, priority, null, new ArrayList<>());
        Assert.assertEquals(result, activity);
    }

    @Test
    public void addOrderActivity() {
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        when(activityRepository.existsByExternalId(externalId)).thenReturn(false);
        when(activityRepository.save(ArgumentMatchers.any(Activity.class))).thenReturn(activity);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        Activity result = activitiesService.addOrderActivity(userName, activityName, orderPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), activityStatus, description, brand, loyaltyStructure.getRegion(),
                externalId, ruleProperties, remark, priority, new ArrayList<>());
        Assert.assertEquals(result, activity);
    }

    @Test
    public void addRedemptionActivity() {
        List<AddRedemptionGiftCommand> giftDTOList = new ArrayList<>();
        AddRedemptionGiftCommand giftCommand = new AddRedemptionGiftCommand();
        giftCommand.setGiftId(giftId);
        giftCommand.setLimit(100);
        giftCommand.setPoint(100);
        giftCommand.setStock(200);
        giftCommand.setTierLevel("ML_OLAY_2");
        giftCommand.setStartAt(startAt);
        giftCommand.setEndAt(endAt);
        giftCommand.setLogisticsGiftId("logisticsGiftId");
        giftCommand.setFreight(510.0);
        giftCommand.setPriority(0);
        giftDTOList.add(giftCommand);
        AddRedemptionActivityCommand activityCommand = new AddRedemptionActivityCommand();
        activityCommand.setBrand(brand);
        activityCommand.setActivityName(activityName);
        activityCommand.setPointType(redemptionPointType);
        activityCommand.setDescription(description);
        activityCommand.setStartAt(startAt);
        activityCommand.setEndAt(endAt);
        activityCommand.setStatus(AddRedemptionActivityCommand.StatusEnum.ACTIVATE);
        activityCommand.setRegion(REGION_ML);
        activityCommand.setExternalCode(externalId);
        activityCommand.setPriority(0);
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now())
                .build();
        when(activityRepository.existsByExternalId(externalId)).thenReturn(false);
        when(activityRepository.save(ArgumentMatchers.any(Activity.class))).thenReturn(activity);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        Activity result = activitiesService.addRedemptionActivity(userName, activityCommand, new ArrayList<>());
        Assert.assertEquals(result, activity);
    }

    @Test(expected = SystemException.class)
    public void addRedemptionActivityWithGiftNotFound() {
        List<AddRedemptionGiftCommand> giftDTOList = new ArrayList<>();
        AddRedemptionGiftCommand giftCommand = new AddRedemptionGiftCommand();
        giftCommand.setGiftId(giftId);
        giftCommand.setLimit(100);
        giftCommand.setPoint(100);
        giftCommand.setStock(200);
        giftCommand.setTierLevel("ML_OLAY_2");
        giftCommand.setStartAt(startAt);
        giftCommand.setEndAt(endAt);
        giftCommand.setLogisticsGiftId("logisticsGiftId");
        giftCommand.setFreight(51.0);
        giftDTOList.add(giftCommand);
        AddRedemptionActivityCommand activityCommand = new AddRedemptionActivityCommand();
        activityCommand.setBrand(brand);
        activityCommand.setActivityName(activityName);
        activityCommand.setPointType("pointTypeStr");
        activityCommand.setDescription(description);
        activityCommand.setStartAt(startAt);
        activityCommand.setEndAt(endAt);
        activityCommand.setStatus(AddRedemptionActivityCommand.StatusEnum.ACTIVATE);
        activityCommand.setRegion(REGION_ML);
        activityCommand.setExternalCode(externalId);
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now())
                .build();
        Activity result = activitiesService.addRedemptionActivity(userName, activityCommand, new ArrayList<>());
        Assert.assertEquals(result, activity);
    }

    @Test
    public void addRedemptionGiftItem() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now())
                .build();
        when(cacheService.getGiftById(giftId)).thenReturn(gift);
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        when(activityRepository.save(activity)).thenReturn(activity);
        RedemptionItem redemptionItem = redemptionItemMap.get(gift.getId());
        Activity activity1 = activitiesService.addSingleRedemptionGift(userName, activityId, redemptionItem);
        Assert.assertNotNull(activity1);
    }

    @Test(expected = SystemException.class)
    public void addRedemptionGiftItemWithGiftNotFound() {
        Map<String, Gift> giftMap = new HashMap<>();
        giftMap.put(giftId, gift);
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        activity.setGifts(redemptionItemMap);
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        RedemptionItem redemptionItem = activity.getGifts().get(gift.getId());
        activitiesService.addSingleRedemptionGift(userName, activityId, redemptionItem);
    }

    @Test
    public void deleteActivityById() {
        Map<String, Gift> giftMap = new HashMap<>();
        giftMap.put(giftId, gift);
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.deleteActivityById(userName, activityId, TransactionType.REDEMPTION);
        Assert.assertNotNull(activity);
    }

    @Test
    public void deleteSingleGiftByGiftId() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        activity.setGifts(redemptionItemMap);
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        when(cacheService.getIssuedNum(activityId, giftId)).thenReturn(0);
        activitiesService.deleteSingleGiftByGiftId(userName, activityId, giftId);
        Assert.assertNotNull(activity);
    }

    @Test(expected = SystemException.class)
    public void deleteSingleGiftByGiftIdWithActivityNotFound() {
        when(activityRepository.findActivityById(activityId)).thenReturn(new ArrayList<>());
        activitiesService.deleteSingleGiftByGiftId(userName, activityId, giftId);
    }

    @Test(expected = SystemException.class)
    public void deleteSingleGiftByGiftIdWithTransactionTypeNotMatch() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.deleteSingleGiftByGiftId(userName, activityId, giftId);
    }


    @Test
    public void updateActivityStatus() {
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(1), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.ORDER, activityStatus);
        Assert.assertNotNull(activityList);
    }

    @Test(expected = SystemException.class)
    public void updateActivityStatusWithActivityNotFound() {
        List<Activity> activityList = new ArrayList<>();
        when(activityRepository.findActivityById(activityId)).thenReturn(new ArrayList<>());
        activitiesService.updateActivityStatus(userName, activityId, TransactionType.INTERACTION, activityStatus);
    }

    @Test
    public void updateInteractionActivityInfo() {
        Activity activity = Activity.Builder
                .interactionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        activitiesService.updateInteractionActivityInfo(userName, activityId, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, null, new ArrayList<>());
        Assert.assertNotNull(activityList);
    }

    @Test(expected = SystemException.class)
    public void updateInteractionActivityInfoWithActivityNotFound() {
        when(activityRepository.findActivityById(activityId)).thenReturn(new ArrayList<>());
        activitiesService.updateInteractionActivityInfo(userName, activityId, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, null, new ArrayList<>());
    }

    @Test(expected = SystemException.class)
    public void updateInteractionActivityInfoWithTransactionTypeNotMatch() {
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(1), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.updateInteractionActivityInfo(userName, activityId, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, null, new ArrayList<>());
    }

    @Test
    public void updateOrderActivityInfo() {
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(1), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        activitiesService.updateOrderActivityInfo(userName, activityId, activityName, orderPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, new ArrayList<>());
        Assert.assertNotNull(activityList);
    }

    @Test(expected = SystemException.class)
    public void updateOrderActivityInfoWithActivityNotFound() {
        when(activityRepository.findActivityById(activityId)).thenReturn(new ArrayList<>());
        activitiesService.updateOrderActivityInfo(userName, activityId, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, new ArrayList<>());
    }

    @Test(expected = SystemException.class)
    public void updateOrderActivityInfoWithTransactionTypeNotMatch() {
        Activity activity = Activity.Builder
                .interactionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.updateOrderActivityInfo(userName, activityId, activityName, interactionPointType, startAt.toLocalDateTime(),
                endAt.toLocalDateTime(), description, activityStatus, ruleProperties, remark,
                priority, new ArrayList<>());
    }

    @Test
    public void updateRedemptionActivityInfo() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(),
                PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypeList);
        UpdateRedemptionActivityCommand command = new UpdateRedemptionActivityCommand();
        command.setActivityName(activityName);
        command.setDescription(description);
        command.setPointType(redemptionPointType);
        command.setRecords(new ArrayList<>());
        command.setPriority(0);
        command.setStartAt(startAt);
        command.setEndAt(endAt);
        command.setStatus(StatusEnum.INITIAL);
        activitiesService.updateRedemptionActivityInfo(userName, activityId, command, new ArrayList<>());
        Assert.assertNotNull(activityList);
    }

    @Test(expected = SystemException.class)
    public void updateRedemptionActivityInfoWithGiftNotFound() {
        Map<String, Gift> giftMap = new HashMap<>();
        giftMap.put(giftId, gift);
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        UpdateRedemptionActivityCommand command = new UpdateRedemptionActivityCommand();
        command.setActivityName(activityName);
        activitiesService.updateRedemptionActivityInfo(userName, activityId, command, new ArrayList<>());
    }

    @Test
    public void modifyGiftInventory() {
        Integer amount = 98;
        Map<String, Gift> giftMap = new HashMap<>();
        giftMap.put(giftId, gift);
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        activity.setGifts(redemptionItemMap);
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        activitiesService.modifyGiftInventory(userName, activityId, giftId, amount);
        Assert.assertNotNull(activityList);
    }

    @Test
    public void queryInteractionActivities() {
        Activity activity = Activity.Builder
                .interactionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(0), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> list = new ArrayList<>();
        list.add(activity);
        when(activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.INTERACTION, loyaltyStructure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt.toLocalDateTime()),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt.toLocalDateTime())))
                .thenReturn(list);
        when(cacheService.filterActivity(anyList(), anyString(), anyString(), anyString(),
                isNull(), isNull(), isNull(), any())).thenReturn(list);
        PageableResult pageableResult = new PageableResult(1, list);
        when(cacheService.generatePage(page, perPage, list, null)).thenReturn(pageableResult);
        PageableResult result = activitiesService.queryInteractionActivities(loyaltyStructure.getRegion(), brand, activityName, perPage, page,
                startAt.toLocalDateTime(), endAt.toLocalDateTime());
        Assert.assertEquals(result.getRecords(), list);
    }

    @Test
    public void queryRedemptionActivities() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> list = new ArrayList<>();
        list.add(activity);
        when(activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.REDEMPTION, loyaltyStructure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt.toLocalDateTime()),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt.toLocalDateTime())))
                .thenReturn(list);
        when(cacheService.filterActivity(anyList(), anyString(), anyString(), anyString(),
                isNull(), isNull(), isNull(), any())).thenReturn(list);
        PageableResult pageableResult = new PageableResult(1, list);
        when(cacheService.generatePage(page, perPage, list, null)).thenReturn(pageableResult);
        PageableResult result = activitiesService.queryRedemptionActivities(loyaltyStructure.getRegion(), brand, interactionPointType, activityName, perPage, page,
                startAt.toLocalDateTime(), endAt.toLocalDateTime());
        Assert.assertEquals(result.getRecords(), list);
    }

    @Test
    public void queryOrderActivities() {
        Activity activity = Activity.Builder
                .orderBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(1), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> list = new ArrayList<>();
        list.add(activity);
        when(activityRepository.findByTransactionTypeAndLoyaltyStructureAndBrandAndUpdatedTimeBetween(
                TransactionType.ORDER, loyaltyStructure.name(), brand,
                LoyaltyDateTimeUtils.localDateTimeToString(startAt.toLocalDateTime()),
                LoyaltyDateTimeUtils.localDateTimeToString(endAt.toLocalDateTime())))
                .thenReturn(list);
        when(cacheService.filterActivity(anyList(), anyString(), anyString(), anyString(),
                isNull(), isNull(), isNull(), any())).thenReturn(list);
        PageableResult pageableResult = new PageableResult(1, list);
        when(cacheService.generatePage(page, perPage, list, null)).thenReturn(pageableResult);
        PageableResult result = activitiesService.queryOrderActivities(loyaltyStructure.getRegion(), brand, activityName, perPage, page,
                startAt.toLocalDateTime(), endAt.toLocalDateTime());
        Assert.assertEquals(result.getRecords(), list);
    }

    @Test
    public void queryRedemptionActivityById() {
        Activity activity = Activity.Builder
                .redemptionBuilder(activityName, loyaltyStructure, brand, description, remark)
                .buildRule(pointTypeList.get(2), ruleProperties, priority)
                .validityTime(startAt.toLocalDateTime(), endAt.toLocalDateTime())
                .createBy(userName, LocalDateTime.now()).build();
        List<Activity> activityList = new ArrayList<>();
        activityList.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activityList);
        Activity result = activitiesService.queryRedemptionActivityById(activityId);
        Assert.assertEquals(result, activity);
    }

    @Test
    public void addQrcodeSkuForActivity() {
        qrderItem = new QrcodeItem("M110", QrcodeItem.ProductTypeEnum.BASIC, 100, 20, 1.0f, "this is a test data");
        Activity activity = new Activity();
        activity.setTransactionType(TransactionType.INTERACTION);
        activity.setPointType(Transaction.PointTypeEnum.SCAN_CODE.toString());
        activities = new ArrayList<>();
        activities.add(activity);
        when(activityRepository.findActivityById(activityId)).thenReturn(activities);
        activitiesService.addQrcodeSkuForActivity("tom", activityId, qrderItem);
        Assert.assertNotNull(activities);
    }

    @Test
    public void updateQrcodeActivitySku() {
        when(activityRepository.findActivityById(activityId)).thenReturn(activities);
        activitiesService.updateQrcodeActivitySku("tom", activityId, qrderItem);
        Assert.assertNotNull(activities);
    }

    @Test
    public void deleteQrcodeActivitySkuByActivityIdAndSku() {
        when(activityRepository.findActivityById(activityId)).thenReturn(activities);
        activitiesService.deleteQrcodeActivitySkuByActivityIdAndSku("Tim", activityId, "M110");
        Assert.assertNotNull(activities);
    }
}
