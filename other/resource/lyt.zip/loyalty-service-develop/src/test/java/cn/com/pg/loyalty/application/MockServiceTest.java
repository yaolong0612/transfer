package cn.com.pg.loyalty.application;


import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.interfaces.dto.UpdateMockAccountCommand;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.mock.env.MockEnvironment;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Slf4j
public class MockServiceTest {

    @InjectMocks
    MockService mockService;

    @Mock
    AccountRepository accountRepository;

    @Mock
    ApplicationContext applicationContext;

    @Mock
    CacheService cacheService;

    private UpdateMockAccountCommand updateMockAccountCommand;
    private List<Account> mockAccountList;


    @Before
    public void before(){
        updateMockAccountCommand = new UpdateMockAccountCommand();
        updateMockAccountCommand.setRegion(StructureConfig.REGION_ML);
        updateMockAccountCommand.setBrand(StructureConfig.BRAND_OLAY);
        updateMockAccountCommand.setPointAboutExpire(100);
        updateMockAccountCommand.setPointAboutExpiredDate("2021-12-17");
        updateMockAccountCommand.setTierExpiredTime(OffsetDateTime.of(LocalDateTime.now(), ZoneOffset.UTC));

        mockAccountList = new ArrayList<>();
        Account mockAccount = new Account();
        mockAccount.register(StructureConfig.getMLOlayStructure(), StructureConfig.BRAND_OLAY, StructureConfig.CHANNEL_JD
                , "bindId", LocalDateTime.now());
        mockAccountList.add(mockAccount);
    }

    @Test
    public void should_success_when_update_mock_account_in_test_env(){
        MockEnvironment env = new MockEnvironment();
        env.addActiveProfile("test");
        when(applicationContext.getEnvironment()).thenReturn(env);
        when(accountRepository.findByPartitionKeyAndId(anyString(), anyString())).thenReturn(mockAccountList);
        when(cacheService.findLoyaltyStructure(anyString(), anyString())).thenReturn(StructureConfig.getMLOlayStructure());
        mockService.updateAccountById("loyaltyId", updateMockAccountCommand);
        Mockito.verify(accountRepository, Mockito.times(1)).save(any());
    }

    @Test
    public void should_throw_exception_when_update_mock_account_in_test_env(){
        MockEnvironment env = new MockEnvironment();
        env.addActiveProfile("prod");
        when(applicationContext.getEnvironment()).thenReturn(env);
        Assertions.assertThatThrownBy(() -> mockService.updateAccountById("loyaltyId", updateMockAccountCommand)).isInstanceOf(SystemException.class).hasMessage("error environment!");
    }
}
