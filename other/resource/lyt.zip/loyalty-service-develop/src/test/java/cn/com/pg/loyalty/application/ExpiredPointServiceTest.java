package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.cosmosdb.BatchUpdateDBComponentImpl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_OLAY;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExpiredPointServiceTest {

    @InjectMocks
    private ExpiredPointService expiredPointService;

    @Mock
    private AccountService accountService;
    @Mock
    private AccountRepository accountRepository;
    @Mock
    private TransactionRepository transactionRepository;
    @Mock
    private InteractionRepository interactionRepository;
    @Mock
    private BatchUpdateDBComponentImpl batchUpdateDBComponentImpl;
    @Mock
    private StringRedisTemplate stringRedisTemplate;
    @Mock
    ValueOperations<String, String> valueOperations;
    @Mock
    CacheService cacheService;

    private static final LoyaltyStructure loyaltyStructure= StructureConfig.getMLOlayStructure();
    public static final String JD_CHANNEL = "JD";

    @Before
    public void setUp() throws Exception {
        Mockito.when(cacheService.findLoyaltyStructure("ML",BRAND_OLAY))
                .thenReturn(loyaltyStructure);
    }

    private Account getAccount() {
        String memberId = "123456";
        String brand = BRAND_OLAY;
        Account account = new Account(memberId, loyaltyStructure);
        //另外一个渠道注册
        String anotherChannel = JD_CHANNEL;
        account.register(loyaltyStructure,brand, JD_CHANNEL, "ob-001",null);
        Map<String, SubAccount> subAccountMap = account.getSubAccountList();
        subAccountMap.forEach((brand1, subAccount) -> subAccount.addPoint(200,null,null));
        return account;
    }

    private static List<Transaction> getTransactions() {
        List<Transaction> list = new ArrayList<>();
        Interaction interaction = new Interaction("123456", BRAND_OLAY, JD_CHANNEL, loyaltyStructure,"123");
        interaction.setAvailablePoint(90);
        Redemption redemption = new Redemption(
                BRAND_OLAY, JD_CHANNEL, "receiver", "String phone", "String province",
                "String city", "String district", "String address", "String receivingCounter","123876","123",null,
                null, null, ValueType.DEFAULT);
        Order order = new Order("123456", BRAND_OLAY, JD_CHANNEL, "12334"
        , loyaltyStructure, LocalDateTime.now(), null, new HashSet<>(), 20, "ML_OLAY_1","123", "123");
        list.add(interaction);
        list.add(redemption);
        list.add(order);
        return list;
    }

    @Test
    public void expiredPointByYear() {
        Interaction interaction = new Interaction("123456", BRAND_OLAY, JD_CHANNEL, loyaltyStructure,"123");
        interaction.setAvailablePoint(-90);
        when(accountService.fetchAccountByLoyaltyId("123456")).thenReturn(getAccount());
        when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(anyString(),
                anyString(), anyString(), anyString(), anySet())).thenReturn(new ArrayList<Transaction>(){{add(interaction);}});
        when(interactionRepository.existsByPartitionKeyAndLoyaltyIdAndTransactionStatusAndCreatedTimeBetweenAndBrandIn(anyString(), anyString(),
                any(), anyString(), anyString(), anySet()))
                .thenReturn(false);
        Account account = expiredPointService.expiredPointByYear(BRAND_OLAY, "123456", 2018);
        Assert.assertNotNull(account);
    }
    @Test
    public void expiredPointByMonth() {
        Interaction interaction = new Interaction("123456", BRAND_OLAY, JD_CHANNEL, loyaltyStructure,"123");
        interaction.setAvailablePoint(-90);
        when(accountService.fetchAccountByLoyaltyId("123456")).thenReturn(getAccount());
        when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(anyString(),
                anyString(), anyString(), anyString(), anySet())).thenReturn(new ArrayList<Transaction>(){{add(interaction);}});
        when(interactionRepository.existsByPartitionKeyAndLoyaltyIdAndTransactionStatusAndCreatedTimeBetweenAndBrandIn(anyString(), anyString(),
                any(), anyString(), anyString(), anySet()))
                .thenReturn(false);
        Account account = expiredPointService.expiredPointByMonth(BRAND_OLAY, "123456", 2018, 6);
        Assert.assertNotNull(account);
    }
    @Test
    public void expiredPointByDay() {
        String memberId = "1234567";
        String brand = BRAND_OLAY;
        String anotherChannel = JD_CHANNEL;
        Account account = new Account(memberId, loyaltyStructure);
        //另外一个渠道注册
        account.register(loyaltyStructure,brand, anotherChannel, "ob-0017",null);
        Map<String, SubAccount> subAccountMap = account.getSubAccountList();
        subAccountMap.forEach((brand1, subAccount) -> subAccount.addPoint(200,null,null));

        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountService.fetchAccountByLoyaltyId(anyString())).thenReturn(account);
        when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndExpiredTimeLessThanAndBrandInAndTransactionStatusNotExpire(
                anyString(), anyString(), anyString(),
                anySet()
        )).thenReturn(getTransactions());
        Account account1 = expiredPointService.expiredPointByDay(BRAND_OLAY, anyString(), LocalDate.now());
        Assert.assertNotNull(account1);

    }

    @Test
    public void willExpiredPointsByYear() {
        when(accountService.fetchAccountByLoyaltyId("123456")).thenReturn(getAccount());
        when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(
                anyString(), anyString(), anyString(), anyString(),
                anySet()
        )).thenReturn(getTransactions());
        Account account = expiredPointService.willExpiredPointsByYear(BRAND_OLAY, "123456", 2021);
        Assert.assertNotNull(account);

    }

    @Test
    public void willExpiredPointsByMonth() {
        when(accountService.fetchAccountByLoyaltyId("123456")).thenReturn(getAccount());
        when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndAvailablePointNotEqualsZeroAndExpiredTimeBetweenAndBrandIn(
                anyString(), anyString(), anyString(), anyString(),
                anySet()
        )).thenReturn(getTransactions());
//        when(stringRedisTemplate.opsForValue()).thenReturn(valueOperations);
//        when(stringRedisTemplate.opsForValue().get(anyString())).thenReturn(null);
        Account account = expiredPointService.willExpiredPointsByMonth(BRAND_OLAY, "123456", 2021, 9);
        Assert.assertNotNull(account);

    }
    @Test
    public void calculateWillExpiredPoint() {
        expiredPointService.calculateWillExpiredPoint(getTransactions(), getAccount(), loyaltyStructure);
        Assert.assertNotNull(getAccount());
    }

}
