package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.BrandV2;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.Config;
import cn.com.pg.loyalty.domain.structure.ConfigRepository;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ConfigServiceTest {

    @Mock
    private ConfigRepository configRepository;

    @InjectMocks
    private ConfigService configService;

    private static List<Config> EXPECT_CONFIG_LIST = Collections.singletonList(new BrandV2("BRAND",
            "帮宝适"));

    @Test
    public void should_create_config_success(){
        configService.createConfig(new ChannelV2("WECHAT", "微信"));
        verify(configRepository, times(1)).save(any(Config.class));
    }

    @Test
    public void should_throw_exception_when_input_config_exists(){
        List<Config> mockConfigList = new ArrayList<>();
        ChannelV2 wechat = new ChannelV2("WECHAT", "微信");
        mockConfigList.add(wechat);
        when(configRepository.findByTypeAndName(eq("CHANNEL"), eq("WECHAT"))).thenReturn(mockConfigList);
        Assertions.assertThatThrownBy(() -> configService.createConfig(wechat))
                .isInstanceOf(SystemException.class).hasMessage("config [WECHAT] already exists!");
    }

    @Test
    public void should_fetch_config_success_when_input_config_type(){
        when(configRepository.findAllByType(anyString())).thenReturn(EXPECT_CONFIG_LIST);
        List<Config> configList = configService.findByType("BRAND");
        Assertions.assertThat(configList).isEqualTo(EXPECT_CONFIG_LIST);
    }

    @Test
    public void should_fetch_config_success_when_input_config_type_and_name(){
        when(configRepository.findByTypeAndName(anyString(), anyString())).thenReturn(EXPECT_CONFIG_LIST);
        Config config = configService.findByTypeAndName("BRAND", "PAMPERS");
        Assertions.assertThat(config).isEqualTo(EXPECT_CONFIG_LIST.get(0));
    }

    @Test
    public void should_fetch_config_success_when_input_config_id(){
        when(configRepository.findByPartitionKeyAndId(anyString(), anyString())).thenReturn(EXPECT_CONFIG_LIST);
        Config config = configService.fetchConfigById("configId");
        Assertions.assertThat(config).isEqualTo(EXPECT_CONFIG_LIST.get(0));
    }

    @Test
    public void should_delete_config_success_when_input_config_id(){
        configService.deleteConfigById("configId");
        verify(configRepository, times(1)).deleteByPartitionKeyAndId(anyString(), anyString());
    }
}
