package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.ChannelV2;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.infrastructure.servicebus.refactor.ServiceBusClient;
import lombok.Data;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.LocalDateTime;
import java.util.*;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_OLAY;
import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_SKII;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class OperationServiceTest {
    @InjectMocks
    private OperationService operationService;
    @Mock
    private InteractionRepository interactionRepository;
    @Mock
    private AccountService accountService;
    @Mock
    private TransactionRepository transactionRepository;
    @Mock
    private ServiceBusClient serviceBusClient;
    @Mock
    private AccountRepository accountRepository;
    @Mock
    private MessageService messageService;
    @Mock
    private TransactionService transactionService;
    @Mock
    private StringRedisTemplate stringRedisTemplate;
    @Mock
    ValueOperations<String, String> valueOperations;
    @Mock
    CacheService cacheService;

    private Interaction interaction = new Interaction();
    private String qrCode = "qrCode";

    private Account sourceAccount;
    private Account targetAccount;

    private static final LoyaltyStructure loyaltyStructure= StructureConfig.getJPStructure();
    private static final String REGISTRY = "REGISTER";
    private String targetTransactionPartitionKey;
    private String sourceTransactionPartitionKey;
    private Interaction sourceRegistryRecord;
    private Interaction targetRegistryRecord;
    @Mock
    private LogRepository logRepository;

    @Mock
    private AccountOptRepository accountOptRepository;

    private static final String REGION_JP = "JP";
    @Before
    public void setUp() {
        RequestContext.createContext("123456");
        sourceAccount = new Account("vip-source001", loyaltyStructure);
        sourceAccount.register(loyaltyStructure,BRAND_SKII,
                ChannelV2.LINE, "vip001", LocalDateTime.now());
        targetAccount = new Account("vip-target002", loyaltyStructure);
        targetAccount.register(loyaltyStructure,BRAND_SKII,
                ChannelV2.LINE, "vip002", LocalDateTime.now().minusMonths(3));
        sourceRegistryRecord = new Interaction(targetAccount.loyaltyId(),
                BRAND_SKII, ChannelV2.INTERNAL, loyaltyStructure, targetAccount.memberId());
        sourceRegistryRecord.setPointType(REGISTRY);
        sourceRegistryRecord.setPoint(300);
        targetRegistryRecord = new Interaction(targetAccount.loyaltyId(),
                BRAND_SKII, ChannelV2.INTERNAL, loyaltyStructure, targetAccount.memberId());
        targetRegistryRecord.setPointType(REGISTRY);
        targetRegistryRecord.setPoint(300);
        targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        sourceTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(sourceAccount.loyaltyId());
        Mockito.when(cacheService.findLoyaltyStructure(REGION_JP, BRAND_SKII))
                .thenReturn(loyaltyStructure);
    }


    @Test
    public void when_qrCode_is_exist_then_return_interaction() {
        LocalDateTime localDateTime = LocalDateTime.now();
        interaction.setMemberId("123456");
        interaction.setCreatedTime(localDateTime);
        interaction.setQrCode(qrCode);
        when(interactionRepository.findByQrCodeAndBrand(qrCode, "OLAY")).thenReturn(Collections.singletonList(interaction));
        Interaction record = operationService.findCodeUsedRecord(qrCode, BRAND_OLAY);
        assertEquals("123456", record.getMemberId());
        assertEquals(localDateTime, record.getCreatedTime());
    }

    @Test
    public void when_qrCode_not_exist_then_throw_exception() {
        when(interactionRepository.findByQrCodeAndBrand(qrCode, "OLAY")).thenReturn(new ArrayList<>());
        assertThatThrownBy(() -> operationService.findCodeUsedRecord(qrCode, BRAND_OLAY))
                .isInstanceOf(SystemException.class)
                .hasMessage(ResultCodeMapper.QRCODE_NOT_FOUND.name());
    }


    //AC1: source和target account都存在，将所有的积分记录都进行重算，返回target account信息；
    //AC2: source不存在，target account存在，将所有的积分记录都进行重算，返回target account信息；
    //AC3: source存在，target account不存在，创建一个新的账户，将source account的积分记录合并到target中，返回target account信息；
    //AC4: source和target account都不存在，创建一个target账户，返回target account信息；
    //AC5: 账户合并后积分都能续接上，计算后没有过期积分，回滚积分，重新计算；
    //AC6: 账户合并后积分部分能续接上，计算后有过期记录，回滚积分，重新计算；
    //AC7: 账户合并后续不上当前时间，计算后有过期记录，回滚积分，重新计算，账户可用积分全部清零；
    //两个账户都存在,只有注册记录且注册时间在一年内,合并后只剩下注册积分
    @Test
    public void given_source_and_target_account_when_registry_time_within_one_year_then_get_target_account_with_registry_point() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);
        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        String targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        String sourceTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(sourceAccount.loyaltyId());
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
            BRAND_SKII, LocalDateTime.now(), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        Assert.assertEquals(0, (int) result);
    }

    //退单变成负积分
    @Test
    public void given_all_records_when_exist_return_redemption_at_one_day_then_get_correct_account() {
        targetAccount.getSubAccountList().get(BRAND_SKII).setCreatedTime(LocalDateTime.now().minusHours(5));
        targetRegistryRecord.setCreatedTime(LocalDateTime.now().minusHours(5));

        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
//        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();

        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusHours(3), 0);
        createOrders(targetTransactions, orderInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusHours(2), 800);
        createRedemption(targetTransactions, redemptionInfo);

        String targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
//        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);

        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
                BRAND_SKII, LocalDateTime.now().minusHours(5), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        Assert.assertEquals(0, (int) result);
    }

    @Test
    public void given_all_records_when_exist_return_redemption_not_at_one_day_then_get_correct_account() {
        targetAccount.getSubAccountList().get(BRAND_SKII).setCreatedTime(LocalDateTime.now().minusDays(2));
        targetRegistryRecord.setCreatedTime(LocalDateTime.now().minusDays(2));

        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();

        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusHours(1), 0);
        createOrders(targetTransactions, orderInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusHours(2), 800);
        createRedemption(targetTransactions, redemptionInfo);

        String targetTransactionPartitionKey = PartitionKeyUtils.getTransactionPartitionKey(targetAccount.loyaltyId());
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
//        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);

        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
            BRAND_SKII, LocalDateTime.now().minusDays(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        Assert.assertEquals(0, (int) result);
    }

    //两个账户都存在,注册时间超过一年,合并后没有积分
    @Test
    public void given_source_and_target_account_when_registry_time_over_one_year_then_get_target_account_without_point() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);
        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
               BRAND_SKII, LocalDateTime.now().minusYears(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        Assert.assertEquals(0, (int) result);
    }

    //两个账户都存在,除了注册积分还存在订单积分兑换积分等,注册时间在最前面且积分都能续接上,合并后得到相应积分
    @Test
    public void given_source_target_with_all_type_transactions_when_call_api_then_get_target_account_info() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);
        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusYears(2), 200);
        orderInfo.put(LocalDateTime.now().minusYears(1), 100);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(targetTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(sourceTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 200);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(sourceTransactions, redemptionInfo);

        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
               BRAND_SKII, LocalDateTime.now().minusMonths(2).minusYears(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    //两个账户都存在,除了注册积分还存在订单积分兑换积分等,注册时间在最前面,订单部分能续接上,合并后得到相应积分
    @Test
    public void given_source_target_with_expired_transactions_when_order_not_continuity_then_get_target_account_info() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusYears(2), 200);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(targetTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(sourceTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(sourceTransactions, redemptionInfo);

        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
                BRAND_SKII, LocalDateTime.now().minusMonths(2).minusYears(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    //只存在target账户,若是注册时间不变
    @Test
    public void given_target_when_registry_time_unchanged_then_get_target_account_info() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusYears(2), 200);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(targetTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(targetTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(targetTransactions, redemptionInfo);

        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(null);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        sourceTransactions.clear();
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
               BRAND_SKII, LocalDateTime.now().minusMonths(2).minusYears(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    //只存在target账户,若是注册时间往后推了一段时间
    @Test
    public void given_target_when_registry_time_plus_one_year_then_get_target_account_info() {
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusYears(2), 200);
        orderInfo.put(LocalDateTime.now().minusYears(1).plusHours(1), 100);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(targetTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(targetTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(targetTransactions, redemptionInfo);

        sourceTransactions.clear();
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(null);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
              BRAND_SKII, LocalDateTime.now().minusYears(1), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    @Test
    public void given_target_when_registry_time_plus_one_year_exist_order_before_registry_time_an_hour_then_get_target_account_info() {
        //存在一个订单记录的时间早于注册时间一小时
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusYears(2), 200);
        orderInfo.put(LocalDateTime.now().minusYears(1).minusHours(1), 100);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(targetTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(targetTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(targetTransactions, redemptionInfo);

        sourceTransactions.clear();
        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(null);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
               BRAND_SKII, LocalDateTime.now().minusYears(1), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    @Test
    public void given_source_when_registry_time_unchanged_then_get_target_account_info() {
        //  2018.01.24  registry     300
        //  2018.12.24  interaction  300
        //  2019.01.24  order        200
        //  2019.12.24  interaction  400
        //  2020.01.22  redemption   -800
        //  2020.01.24  order        100
        //  2020.12.24  interaction  500
        //  2021.01.22  redemption   -500
        //  2021.01.24  order        300
        List<Transaction> targetTransactions =
                createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions =
                createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        LocalDateTime firstPurchaseTime = LocalDateTime.now().minusYears(2);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(firstPurchaseTime, 200);
        orderInfo.put(LocalDateTime.now().minusYears(1), 100);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(sourceTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(sourceTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(sourceTransactions, redemptionInfo);
        targetTransactions.clear();

        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
                BRAND_SKII, LocalDateTime.now().minusMonths(2).minusYears(2), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertEquals(6, targetTransactions.size());
    }

    @Test
    public void given_source_when_registry_time_plus_one_year_then_get_target_account_info() {
        //  2018.01.24  registry     300
        //  2018.12.24  interaction  300
        //  2019.01.24  order        200
        //  2019.12.24  interaction  400
        //  2020.01.22  redemption   -800
        //  2020.01.24  order        100
        //  2020.12.24  interaction  500
        //  2021.01.22  redemption   -500
        //  2021.01.24  order        300
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        List<Transaction> sourceTransactions = createRegistryRecord(sourceRegistryRecord);

        String sourceMemberId = sourceAccount.getMemberId();
        String targetMemberId = targetAccount.getMemberId();
        List<String> sourceMemberIds = new ArrayList<>();
        sourceMemberIds.add(sourceMemberId);
        LocalDateTime firstPurchaseTime = LocalDateTime.now().minusYears(2);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(firstPurchaseTime, 200);
        orderInfo.put(LocalDateTime.now().minusYears(1).plusHours(1), 100);
        orderInfo.put(LocalDateTime.now(), 300);
        createOrders(sourceTransactions, orderInfo);
        //创建交互记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(2), 300);
        interactionInfo.put(LocalDateTime.now().minusMonths(1).minusYears(1), 400);
        interactionInfo.put(LocalDateTime.now().minusMonths(1), 500);
        createInteractions(sourceTransactions, interactionInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(2).minusYears(1), 800);
        redemptionInfo.put(LocalDateTime.now().minusDays(2), 500);
        createRedemption(sourceTransactions, redemptionInfo);
        targetTransactions.clear();

        when(accountService.fetchAccountByMemberId(loyaltyStructure, targetMemberId)).thenReturn(targetAccount);
        when(accountService.fetchAccountByMemberId(loyaltyStructure, sourceMemberId)).thenReturn(sourceAccount);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(sourceTransactionPartitionKey,
                sourceAccount.loyaltyId())).thenReturn(sourceTransactions);
        when(transactionRepository.findTransactionsByPartitionKeyAndLoyaltyId(targetTransactionPartitionKey,
                targetAccount.loyaltyId())).thenReturn(targetTransactions);
        when(accountRepository.save(targetAccount)).thenReturn(targetAccount);
        Account account = operationService.mergeAccount4Skii(sourceMemberIds, targetMemberId, REGION_JP,
                BRAND_SKII, LocalDateTime.now().minusYears(1), ChannelV2.LINE, "bind001", null, null);
        Integer result = account.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(0, (int) result);
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
    }

    @Test
    public void should_return_null_when_target_account_opt_is_null_and_request_to_merge_opt_in(){
        LocalDateTime optTime = LocalDateTime.now();
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(null);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_IN, optTime);
        assertNull(result);
    }

    @Test
    public void should_return_opt_out_when_target_account_opt_is_null_and_request_to_merge_opt_out(){
        LocalDateTime optTime = LocalDateTime.now();
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(null);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_OUT, optTime);
        assertEquals(AccountOpt.OptType.OPT_OUT, result.currentOptNode().optType());
    }

    @Test
    public void should_return_opt_in_when_target_account_opt_is_opt_in_and_request_to_merge_opt_in(){
        LocalDateTime optTime = LocalDateTime.now();
        AccountOpt accountOpt = new AccountOpt("memberId", loyaltyStructure.getMarketingProgramId(),
                "loyaltyId");
        List<AccountOpt.OptNode> opts = new ArrayList<>(Arrays.asList(new AccountOpt.OptNode(AccountOpt.OptType.OPT_IN,
                optTime.minusDays(10))));
        accountOpt.setOpts(opts);
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(accountOpt);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_IN, optTime);
        assertEquals(AccountOpt.OptType.OPT_IN, result.currentOptNode().optType());
    }

    @Test
    public void should_return_opt_out_when_target_account_opt_is_opt_in_and_request_to_merge_opt_out(){
        LocalDateTime optTime = LocalDateTime.now();
        AccountOpt accountOpt = new AccountOpt("memberId", loyaltyStructure.getMarketingProgramId(),
                "loyaltyId");
        List<AccountOpt.OptNode> opts = new ArrayList<>(Arrays.asList(new AccountOpt.OptNode(AccountOpt.OptType.OPT_OUT,
                optTime.minusDays(10)), new AccountOpt.OptNode(AccountOpt.OptType.OPT_IN,
                optTime.minusDays(5))));
        accountOpt.setOpts(opts);
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(accountOpt);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_OUT, optTime);
        assertEquals(AccountOpt.OptType.OPT_OUT, result.currentOptNode().optType());
    }

    @Test
    public void should_return_opt_out_when_target_account_opt_is_opt_out_and_request_to_merge_opt_out(){
        LocalDateTime optTime = LocalDateTime.now();
        AccountOpt accountOpt = new AccountOpt("memberId", loyaltyStructure.getMarketingProgramId(),
                "loyaltyId");
        List<AccountOpt.OptNode> opts = new ArrayList<>(Arrays.asList(new AccountOpt.OptNode(AccountOpt.OptType.OPT_OUT,
                optTime.minusDays(10))));
        accountOpt.setOpts(opts);
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(accountOpt);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_OUT, optTime);
        assertEquals(AccountOpt.OptType.OPT_OUT, result.currentOptNode().optType());
    }

    @Test
    public void should_return_opt_in_when_target_account_opt_is_opt_out_and_request_to_merge_opt_in(){
        LocalDateTime optTime = LocalDateTime.now();
        AccountOpt accountOpt = new AccountOpt("memberId", loyaltyStructure.getMarketingProgramId(),
                "loyaltyId");
        List<AccountOpt.OptNode> opts = new ArrayList<>(Arrays.asList(new AccountOpt.OptNode(AccountOpt.OptType.OPT_OUT,
                optTime.minusDays(10))));
        accountOpt.setOpts(opts);
        when(accountOptRepository.fetchAccountOptByLoyaltyId(anyString())).thenReturn(accountOpt);
        AccountOpt result = operationService.mergeAccountOpt(loyaltyStructure, "memberId", "loyaltyId",
                AccountOpt.OptType.OPT_IN, optTime);
        assertEquals(AccountOpt.OptType.OPT_IN, result.currentOptNode().optType());
    }


    public void createOrders(List<Transaction> transactions, Map<LocalDateTime, Integer> params) {
        if (params.size() <= 0) {
            Assert.fail("the number must greater than 0");
        }
        String loyaltyId = transactions.get(0).getLoyaltyId();
        String memberId = transactions.get(0).getMemberId();
        params.keySet().forEach(key -> {
            Order order = new Order(loyaltyId, BRAND_SKII, ChannelV2.INTERNAL, loyaltyStructure, memberId);
            order.setCreatedTime(key);
            order.setPoint(params.get(key));
            order.setOrderDateTime(key);
            transactions.add(order);
        });
    }

    public void createInteractions(List<Transaction> transactions, Map<LocalDateTime, Integer> params) {
        if (params.size() <= 0) {
            Assert.fail("the number must greater than 0");
        }
        String loyaltyId = transactions.get(0).getLoyaltyId();
        String memberId = transactions.get(0).getMemberId();
        params.keySet().forEach(key -> {
            Interaction interaction = new Interaction(loyaltyId,
                    BRAND_SKII, ChannelV2.INTERNAL, loyaltyStructure, memberId);
            interaction.setCreatedTime(key);
            interaction.setPoint(params.get(key));
            transactions.add(interaction);
        });
    }

    public void createRedemption(List<Transaction> transactions, Map<LocalDateTime, Integer> params) {
        if (params.size() <= 0) {
            Assert.fail("the number must greater than 0");
        }
        String memberId = transactions.get(0).getMemberId();
        params.keySet().forEach(key -> {
            Redemption interaction = new Redemption(BRAND_SKII, ChannelV2.INTERNAL, "vip001",
                    "13000001111", "广东省", "广州市", "天河区", "黄埔大道",
                    "AAABBBCCC", "0001111", memberId, 12.00, null, null, ValueType.DEFAULT);
            interaction.setCreatedTime(key);
            interaction.setPoint(params.get(key));
            transactions.add(interaction);
        });
    }

    public List<Transaction> createRegistryRecord(Interaction interaction) {
        List<Transaction> sourceTransactions = new ArrayList<>();
        sourceTransactions.add(interaction);
        return sourceTransactions;
    }


    /**
     * ----------------------------------
     * SKII账户积分回滚
     * 验证内容：
     * 1、可用积分
     * 2、即将过期积分
     * 3、总积分
     * 4、过期积分
     * 5、使用积分
     * <p>
     * 验收标准：
     * 1、退单不影响积分积分流水，account传进去前后，积分不变
     * 2、退单影响积分过期，部分积分过期
     * 3、插单不影响积分流水，account传进去前后，积分不变
     * 4、插单影响积分过期，部分积分回滚
     * ----------------------------------
     */

    private static final String MEMBER_ID = "1234567";
    private static final String LOYALTY_ID = UUIDUtil.generateLoyaltyId(MEMBER_ID, loyaltyStructure);
    private static final String SYSTEM_EXPIRED_POINT = "SYSTEM_EXPIRED_POINT";
    private static final String brand_SKII = BRAND_SKII;
    private static final String CHANNEL_SPA = "SPA";
    private static final LocalDateTime NOW = LocalDateTime.now();

    /**
     * 1、退单不影响积分积分流水，account传进去前后，积分不变
     */
    @Test
    public void given_history_order_when_refund_not_effect_history_point_then_account_not_change() {
        Account account = setupAccount();
        List<Transaction> transactionList = setUpHistoryTransactions();
        setupAccountPointWithHistoryOrder(transactionList, account);
        //退最后一单
        refundOrderWhenNotEffect(account, transactionList);
        //重算前的账号
        SubAccount expectSubAccount = new SubAccount();
        BeanUtils.copyProperties(account.getSubAccountList().get(BRAND_SKII), expectSubAccount);
        //因为订单重算账号需要初始化账号，所以这里加一样的步骤
        account.resetInfo(BRAND_SKII);
        //积分重算
        operationService.rollbackPoint(loyaltyStructure,transactionList, account);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);

        assertEquals(expectSubAccount.getTotalPoint(), subAccount.getTotalPoint());
        assertEquals(expectSubAccount.getPointAvailable(), subAccount.getPointAvailable());
        assertEquals(expectSubAccount.getPointUsed(), subAccount.getPointUsed());
        assertEquals(expectSubAccount.getPointAboutExpire(), subAccount.getPointAboutExpire());
        assertEquals(expectSubAccount.getPointExpired(), subAccount.getPointExpired());
    }

    /**
     * 2、退单影响积分过期，部分积分过期
     */
    @Test
    public void given_history_order_when_refund_effect_history_point_then_expired_point() {
        Account account = setupAccount();
        List<Transaction> transactionList = setUpHistoryTransactions();
        setupAccountPointWithHistoryOrder(transactionList, account);
        //退单不影响积分流水
        refundOrderWhenEffect(account, transactionList);
        //重算前的账号
        SubAccount expectSubAccount = new SubAccount();
        BeanUtils.copyProperties(account.getSubAccountList().get(BRAND_SKII), expectSubAccount);
        //因为订单重算账号需要初始化账号，所以这里加一样的步骤
        account.resetInfo(BRAND_SKII);
        //积分重算
        operationService.rollbackPoint(loyaltyStructure,transactionList, account);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);

        assertEquals(expectSubAccount.getTotalPoint(), subAccount.getTotalPoint());
        assertEquals(expectSubAccount.getPointAvailable(), subAccount.getPointAvailable());
        assertEquals(expectSubAccount.getPointUsed(), subAccount.getPointUsed());
        assertEquals(expectSubAccount.getPointAboutExpire(), subAccount.getPointAboutExpire());
        assertEquals(expectSubAccount.getPointExpired(), subAccount.getPointExpired());
    }


    /**
     * 3、插单不影响积分积分流水，account传进去前后，积分不变
     */
    @Test
    public void given_history_order_when_alert_not_effect_history_point_then_account_not_change() {
        Account account = setupAccount();
        List<Transaction> transactionList = setUpHistoryTransactions();
        setupAccountPointWithHistoryOrder(transactionList, account);
        alertOrderWhenNotEffect(account, transactionList);
        //重算前的账号
        SubAccount expectSubAccount = new SubAccount();
        BeanUtils.copyProperties(account.getSubAccountList().get(BRAND_SKII), expectSubAccount);
        //因为订单重算账号需要初始化账号，所以这里加一样的步骤
        account.resetInfo(BRAND_SKII);
        //积分重算
        operationService.rollbackPoint(loyaltyStructure,transactionList, account);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);

        assertEquals(expectSubAccount.getTotalPoint(), subAccount.getTotalPoint());
        assertEquals(expectSubAccount.getPointAvailable(), subAccount.getPointAvailable());
        assertEquals(expectSubAccount.getPointUsed(), subAccount.getPointUsed());
        assertEquals(expectSubAccount.getPointAboutExpire(), subAccount.getPointAboutExpire());
        assertEquals(expectSubAccount.getPointExpired(), subAccount.getPointExpired());
    }

    /**
     * 4、插单影响积分过期，部分积分回滚
     */
    @Test
    public void given_history_order_when_alert_effect_history_point_then_expired_point() {
        Account account = setupAccount();
        List<Transaction> transactionList = setUpHistoryTransactionsForAlertCase();
        setupAccountPointWithHistoryOrderForAlertCase(transactionList, account);
        //插单影响积分流水
        alertOrderWhenEffect(account, transactionList);
        //重算前的账号
        SubAccount expectSubAccount = new SubAccount();
        BeanUtils.copyProperties(account.getSubAccountList().get(BRAND_SKII), expectSubAccount);
        //因为订单重算账号需要初始化账号，所以这里加一样的步骤
        account.resetInfo(BRAND_SKII);
        //积分重算
        operationService.rollbackPoint(loyaltyStructure,transactionList, account);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);

        assertEquals(expectSubAccount.getTotalPoint(), subAccount.getTotalPoint());
        assertEquals(expectSubAccount.getPointAvailable(), subAccount.getPointAvailable());
        assertEquals(expectSubAccount.getPointUsed(), subAccount.getPointUsed());
        assertEquals(expectSubAccount.getPointAboutExpire(), subAccount.getPointAboutExpire());
        assertEquals(expectSubAccount.getPointExpired(), subAccount.getPointExpired());
    }

    //1.兑换后退单导致积分为负数
    @Test
    public void given_order_and_redemption_when_refund_order_then_get_negative_available() {
        //  2021.04.21  registry     300
        //  2021.04.23  order        300
        //  2021.04.24  redemption   500
        //  2021.04.25  refund       -300
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(LocalDateTime.now().minusDays(3), 300);
        createOrders(targetTransactions, orderInfo);
        //创建兑换记录
        HashMap<LocalDateTime, Integer> redemptionInfo = new HashMap<>();
        redemptionInfo.put(LocalDateTime.now().minusDays(1), 500);
        createRedemption(targetTransactions, redemptionInfo);
        refundOrder(targetTransactions);

        operationService.rollbackPoint(loyaltyStructure,targetTransactions, targetAccount);
        Integer result = targetAccount.getSubAccountList().get(BRAND_SKII).getPointAvailable();
        SubAccount subAccount = targetAccount.getSubAccountList().get(BRAND_SKII);
        Assert.assertEquals(-200, (int) result);
        Assert.assertEquals(300, (int) subAccount.getTotalPoint());
        Assert.assertEquals(0, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(0, (int) subAccount.getTotalPurchaseTimes());
    }

    //2.过期记录被失效  先前存在过期记录，然后来了一笔插单  导致过期记录被回滚
    @Test
    public void given_expired_record_when_given_order_cause_expired_roll_then_all_point() {
        //  2020.01.21  registry     300
        //  2021.01.22  expired      -300
        //  2021.02.24  insert order(2021.01.21)   500
        List<Transaction> targetTransactions = createRegistryRecord(targetRegistryRecord);
        LocalDateTime firstPurchaseTime = LocalDateTime.now().minusMonths(3).minusDays(4);
        SubAccount subAccount = targetAccount.getSubAccountList().get(BRAND_SKII);
        subAccount.setCreatedTime(LocalDateTime.now().minusYears(1).minusMonths(3).minusDays(4));
        targetAccount.setCreatedTime(LocalDateTime.now().minusYears(1).minusMonths(3).minusDays(4));
        //创建订单
        HashMap<LocalDateTime, Integer> orderInfo = new HashMap<>();
        orderInfo.put(firstPurchaseTime, 500);
        createOrders(targetTransactions, orderInfo);
        //创建过期记录
        HashMap<LocalDateTime, Integer> interactionInfo = new HashMap<>();
        interactionInfo.put(LocalDateTime.now().minusMonths(3).minusDays(3), -300);
        createInteractions(targetTransactions, interactionInfo);
        Optional<Transaction> optional = targetTransactions.stream().filter(t -> t.point() < 0).findFirst();
        if (optional.isPresent()) {
            Interaction interaction = (Interaction)optional.get();
            interaction.setPointType("SYSTEM_EXPIRED_POINT");
        }
        Optional<Transaction> optional1 = targetTransactions.stream().filter(t -> t.getPointType().equalsIgnoreCase("REGISTER")).findFirst();
        if (optional1.isPresent()) {
            Interaction interaction = (Interaction)optional1.get();
            interaction.setCreatedTime(LocalDateTime.now().minusYears(1).minusMonths(3).minusDays(4));
        }

        operationService.rollbackPoint(loyaltyStructure,targetTransactions, targetAccount);
        Integer result = subAccount.getPointAvailable();

        Assert.assertEquals(800, (int) result);
        Assert.assertEquals(800, (int) subAccount.getTotalPoint());
        Assert.assertEquals(800, (int) subAccount.getPointAboutExpire());
        Assert.assertEquals(1, (int) subAccount.getTotalPurchaseTimes());
        Assert.assertSame(firstPurchaseTime.toLocalDate(), subAccount.getFirstPurchaseTime().toLocalDate());
    }

    private void refundOrder(List<Transaction> targetTransactions) {
        Optional<Transaction> optional = targetTransactions.stream().filter(t -> t instanceof Order).findFirst();
        if (optional.isPresent()) {
            Order order = (Order)optional.get();
            order.setRealTotalAmount(0.0);
            order.setRefund(true);
            order.setOriginalPoint(300);
            order.setPoint(0);
            order.setAvailablePoint(0);
        }
    }

    /**
     * 退单不影响积分过期
     */
    public void refundOrderWhenNotEffect(Account account, List<Transaction> transactionList) {
        Transaction refundOrder = transactionList.get(transactionList.size() - 1);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(subAccount.getTotalPoint() - refundOrder.getPoint());
        subAccount.setPointAvailable(subAccount.getPointAvailable() - refundOrder.getPoint());
        subAccount.setTotalPurchaseTimes(subAccount.getTotalPurchaseTimes() - 1);
        subAccount.setPointAboutExpire(subAccount.getPointAboutExpire() - refundOrder.getPoint());
        transactionList.remove(refundOrder);
    }

    /**
     * 退单引起积分过期
     */
    public void refundOrderWhenEffect(Account account, List<Transaction> transactionList) {
        Transaction refundOrder = transactionList.remove(transactionList.size() - 3);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(subAccount.getTotalPoint() - refundOrder.getPoint());
        subAccount.setPointAvailable(0);
        subAccount.setPointAboutExpire(0); //最后一笔是订单，而且积分续上了，所以没有过期积分
        subAccount.setPointExpired(1000);
    }

    /**
     * 根据历史订单计算积分
     */
    private void setupAccountPointWithHistoryOrder(List<Transaction> transactionList, Account account) {
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(1500);
        subAccount.setPointAvailable(1000);
        subAccount.setTotalPurchaseTimes(4);
        subAccount.setPointUsed(200);
        subAccount.setPointAboutExpire(1000);
        subAccount.setPointExpired(300);
        subAccount.setPointAboutExpiredDate(transactionList.get(transactionList.size() - 1).getCreatedTime().toLocalDate());
    }

    private Account setupAccount() {
        Account account = new Account(MEMBER_ID, loyaltyStructure);
        SubAccount subAccount = new SubAccount();
        subAccount.setTotalPoint(0);
        subAccount.setPointAvailable(0);
        subAccount.setPointUsed(0);
        subAccount.setPointExpired(0);
        subAccount.setPointAboutExpire(0);
        subAccount.setTotalPurchaseTimes(0);
        subAccount.setUpdatedTime(NOW);
        subAccount.setCreatedTime(NOW.minusYears(3));
        SubAccounts subAccountList = new SubAccounts();
        subAccountList.put(BRAND_SKII, subAccount);
        account.setSubAccountList(subAccountList);
        return account;
    }

    /**
     * 初始化积分时间流水
     * 特别提醒：改动这里面的内容，会导致SKII积分回滚测试用例错误，慎重改动。
     */
    private List<PointInfo> setUpPointInfo() {
        List<PointInfo> pointInfoList = new ArrayList<>();
        //3-2年前的记录
        PointInfo i209 = new PointInfo(NOW.minusYears(3).plusMonths(9).minusDays(1), 100, TransactionType.INTERACTION);
        PointInfo o2010 = new PointInfo(NOW.minusYears(3).plusMonths(10).minusDays(1), 200, TransactionType.ORDER);
        PointInfo i2011 = new PointInfo(NOW.minusYears(3).plusMonths(11).minusDays(1), 300, TransactionType.INTERACTION);
        pointInfoList.add(i209);
        pointInfoList.add(o2010);
        pointInfoList.add(i2011);
        //2-1年前的记录
        PointInfo i109 = new PointInfo(NOW.minusYears(2).plusMonths(9).minusDays(1), 100, TransactionType.INTERACTION);
        //第二天过期，过期积分300分
        PointInfo e1010 = new PointInfo(NOW.minusYears(2).plusMonths(10), -300, TransactionType.INTERACTION, true);
        PointInfo o1011 = new PointInfo(NOW.minusYears(2).plusMonths(10), 300, TransactionType.ORDER);
        pointInfoList.add(i109);
        pointInfoList.add(e1010);
        pointInfoList.add(o1011);
        //近1年前的记9
        PointInfo i009 = new PointInfo(NOW.minusYears(1).plusMonths(9).minusDays(1), 100, TransactionType.INTERACTION);
        PointInfo o0010 = new PointInfo(NOW.minusYears(1).plusMonths(10).minusDays(1), 300, TransactionType.ORDER);
        PointInfo r0010 = new PointInfo(NOW.minusYears(1).plusMonths(10).plusDays(1), 200, TransactionType.REDEMPTION);
        PointInfo oNow = new PointInfo(NOW, 100, TransactionType.ORDER);
        pointInfoList.add(i009);
        pointInfoList.add(r0010);
        pointInfoList.add(o0010);
        pointInfoList.add(oNow);

        return pointInfoList;
    }


    /**
     * 初始化积分流水
     */
    private List<Transaction> setUpHistoryTransactions() {
        List<PointInfo> pointInfoList = setUpPointInfo(); //初始化积分流水
        List<Transaction> transactionList = new ArrayList<>();
        pointInfoList.forEach(pointInfo -> transactionList.add(setUpHistoryTransaction(pointInfo)));
        transactionList.sort(Comparator.comparing(Transaction::getCreatedTime));
        return transactionList;
    }

    private Transaction setUpHistoryTransaction(PointInfo pointInfo) {
        if (pointInfo.getTransactionType() == TransactionType.ORDER) {
            Order order = new Order(LOYALTY_ID, BRAND_SKII, CHANNEL_SPA, UUIDUtil.generator(), loyaltyStructure,
                    pointInfo.getCreatedTime(), new HashSet<>(), MEMBER_ID, UUIDUtil.generator());
            order.setCreatedTime(pointInfo.createdTime);
            order.setPoint(pointInfo.point);
            order.setExpiredTime(pointInfo.createdTime.plusYears(loyaltyStructure.pointExpire().getPointEffectiveYear()));
            return order;
        }
        if (pointInfo.getTransactionType() == TransactionType.INTERACTION) {
            Interaction interaction = new Interaction(LOYALTY_ID, BRAND_SKII, CHANNEL_SPA, loyaltyStructure, MEMBER_ID);
            interaction.setCreatedTime(pointInfo.createdTime);
            interaction.setPoint(pointInfo.point);
            if (pointInfo.isExpiredRecord()) {
                interaction.setPointType(SYSTEM_EXPIRED_POINT);
            }
            interaction.setExpiredTime(pointInfo.createdTime.plusYears(loyaltyStructure.pointExpire().getPointEffectiveYear()));
            return interaction;
        }
        Redemption redemption = new Redemption(BRAND_SKII, CHANNEL_SPA, "张三",
                "13424000000", "广东",
                "广州", "天河区", "", "body.getReceivingStoreCode()",
                " body.getPostalCode()", MEMBER_ID, 10D, null, null, ValueType.DEFAULT);
        redemption.setCreatedTime(pointInfo.createdTime);
        redemption.setPoint(pointInfo.point);
        redemption.setExpiredTime(pointInfo.createdTime.plusYears(loyaltyStructure.pointExpire().getPointEffectiveYear()));
        return redemption;

    }


    @Data
    public static class PointInfo {
        private LocalDateTime createdTime;
        private int point;
        private TransactionType transactionType;
        private boolean expiredRecord;

        public PointInfo(LocalDateTime createdTime, int point, TransactionType transactionType) {
            this.createdTime = createdTime;
            this.point = point;
            this.transactionType = transactionType;
            this.expiredRecord = false;
        }

        public PointInfo(LocalDateTime createdTime, int point, TransactionType transactionType, boolean expiredRecord) {
            this.createdTime = createdTime;
            this.point = point;
            this.transactionType = transactionType;
            this.expiredRecord = expiredRecord;
        }
    }


    /**
     * 初始化积分时间流水
     * 特别提醒：改动这里面的内容，会导致SKII积分回滚测试用例错误，慎重改动。
     */
    private List<PointInfo> setUpPointInfoForAlertCase() {
        List<PointInfo> pointInfoList = new ArrayList<>();
        PointInfo o2010 = new PointInfo(NOW.minusYears(3).plusMonths(11).withDayOfMonth(1), 100, TransactionType.ORDER);
        pointInfoList.add(o2010);
        PointInfo o1010 = new PointInfo(NOW.minusYears(2).plusMonths(11).withDayOfMonth(1), 200, TransactionType.ORDER);
        pointInfoList.add(o1010);
        PointInfo e1010 = new PointInfo(NOW.minusYears(1).plusMonths(11).withDayOfMonth(2), -300, TransactionType.INTERACTION, true);
        pointInfoList.add(e1010);
        PointInfo i0002 = new PointInfo(NOW.minusDays(2), 300, TransactionType.INTERACTION);
        pointInfoList.add(i0002);

        return pointInfoList;
    }

    private void alertOrderWhenEffect(Account account, List<Transaction> transactionList) {
        PointInfo o1010 = new PointInfo(NOW.minusYears(1).plusMonths(11).withDayOfMonth(1), 300, TransactionType.ORDER);
        Transaction alertOrder = setUpHistoryTransaction(o1010);
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(900);
        subAccount.setPointAvailable(900);
        subAccount.setTotalPurchaseTimes(3);
        subAccount.setPointExpired(0);
        subAccount.setPointAboutExpire(600);
        transactionList.add(alertOrder);
    }

    /**
     * 根据历史订单计算积分
     */
    private void setupAccountPointWithHistoryOrderForAlertCase(List<Transaction> transactionList, Account account) {
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(600);
        subAccount.setPointAvailable(300);
        subAccount.setTotalPurchaseTimes(2);
        subAccount.setPointUsed(0);
        subAccount.setPointAboutExpire(300); //最后一笔是订单，而且积分续上了，所以没有过期积分
        subAccount.setPointExpired(300);
        subAccount.setPointAboutExpiredDate(transactionList.get(transactionList.size() - 1).getCreatedTime().toLocalDate());
    }

    /**
     * 初始化积分流水
     */
    private List<Transaction> setUpHistoryTransactionsForAlertCase() {
        List<PointInfo> pointInfoList = setUpPointInfoForAlertCase(); //初始化积分流水
        List<Transaction> transactionList = new ArrayList<>();
        pointInfoList.forEach(pointInfo -> transactionList.add(setUpHistoryTransaction(pointInfo)));
        transactionList.sort(Comparator.comparing(Transaction::getCreatedTime));
        return transactionList;
    }

    private void alertOrderWhenNotEffect(Account account, List<Transaction> transactionList) {
        Transaction alertOrder = setUpHistoryTransaction(new PointInfo(NOW.minusYears(1).plusMonths(10).minusDays(2), 500, TransactionType.ORDER));
        SubAccount subAccount = account.getSubAccountList().get(BRAND_SKII);
        subAccount.setTotalPoint(subAccount.getTotalPoint() + alertOrder.getPoint());
        subAccount.setPointAvailable(subAccount.getPointAvailable() + alertOrder.getPoint());
        subAccount.setTotalPurchaseTimes(subAccount.getTotalPurchaseTimes() - 1);
        subAccount.setPointAboutExpire(subAccount.getPointAboutExpire() + alertOrder.getPoint());
        transactionList.add(alertOrder);
    }


}
