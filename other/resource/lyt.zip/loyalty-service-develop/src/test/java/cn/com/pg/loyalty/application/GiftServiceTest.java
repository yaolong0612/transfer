package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.gift.Gift;
import cn.com.pg.loyalty.domain.gift.GiftCoupon;
import cn.com.pg.loyalty.domain.gift.GiftCouponService;
import cn.com.pg.loyalty.domain.gift.GiftRepository;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.PageableResult;
import cn.com.pg.loyalty.domain.shared.SystemException;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.interfaces.dto.FetchRedemptionDTO;
import cn.com.pg.loyalty.interfaces.dto.GiftCouponCommand;
import cn.com.pg.loyalty.interfaces.dto.RedemptionGiftDTO;
import cn.com.pg.loyalty.interfaces.facade.ParamValidator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.*;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class GiftServiceTest {

    @InjectMocks
    GiftService giftService;

    @Mock
    GiftRepository giftRepository;

    @Mock
    CacheService cacheService;

    @Mock
    ActivityRepository activityRepository;

    @Mock
    GiftCouponService giftCouponService;

    List<Gift> giftList = new ArrayList<>(2);

    Gift expectedValue = null;

    private final static LocalDate NOW = LocalDate.now();

    private GiftCoupon giftCoupon;

    LoyaltyStructure structure = StructureConfig.getMLOlayStructure();
    private static final String REGION_ML = "ML";

    @Before
    public void init() {
        giftCoupon = new GiftCoupon.Builder("01", "1", "1234", "a", "ss")
                .validityDate(NOW.minusDays(2), NOW.plusDays(2))
                .belong("HK", BRAND_PAMPERS)
                .status(GiftCoupon.CouponStatus.ALIVE).build();

        List<GiftCoupon.GiftCouponDisplayMsg> displayLanguages = new ArrayList<>();
        GiftCoupon.GiftCouponDisplayMsg displayMsg = new GiftCoupon.GiftCouponDisplayMsg();
        displayMsg.setLanguage(ParamValidator.validateLanguage("en_US"));
        displayMsg.setStoreName("englishStoreName");
        displayLanguages.add(displayMsg);
        giftCoupon.setDisplayLanguages(displayLanguages);

        expectedValue = new Gift();
        expectedValue.setId("123456789");
        expectedValue.setPoint(100);
        expectedValue.setName("OLAY");
        expectedValue.setMarketPrice(BigDecimal.valueOf(100));
        expectedValue.setItems(new ArrayList<>());
        expectedValue.setImageUri("imageUri");
        expectedValue.setDescription("description");
        expectedValue.setLoyaltyStructure(structure.name());
        giftList.add(expectedValue);

        Mockito.when(cacheService.findLoyaltyStructure("ML", BRAND_OLAY))
                .thenReturn(structure);
    }


    @Test
    public void addGift() {
        Gift gift = expectedValue;
        when(giftRepository.save(any(Gift.class))).thenReturn(gift);
        Gift testedValue = giftService.addGift(gift);
        Assert.assertThat(testedValue, is(gift));
    }

    @Test
    public void updateGift() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(giftList);
        when(giftRepository.save(any(Gift.class))).thenReturn(giftList.get(0));
        doNothing().when(cacheService).removeGiftById(any(String.class));
        Gift testedValue = giftService.updateGift(giftList.get(0));

        Assert.assertThat(testedValue.getId(), is("123456789"));


    }

    @Test(expected = SystemException.class)
    public void updateGiftAndOpenException() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(null);
        giftService.updateGift(giftList.get(0));
    }

    @Test(expected = SystemException.class)
    public void deleteByGiftIdButNotFound() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(null);
        giftService.deleteGiftById("12345678");
    }

    @Test(expected = SystemException.class)
    public void deleteByGiftIdButGiftDistribute() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(null);
        giftService.deleteGiftById("123456789");
    }

    @Test
    public void deleteByGiftId() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(giftList);
        doNothing().when(cacheService).removeGiftById(any(String.class));
        Gift testedValue = giftService.deleteGiftById("123efvbgt");
        Assert.assertThat(testedValue, is(expectedValue));
    }

    @Test
    public void fetchGiftListAndNameIsNullTest() {
        Gift gift = new Gift();
        gift.setItems(new ArrayList<>());
        gift.setMarketPrice(BigDecimal.valueOf(100));

        ArrayList<Gift> gifts = new ArrayList<>(8);
        gifts.add(gift);
        PageableResult pageableResult = new PageableResult<>(1, gifts);
        when(giftRepository.findByLoyaltyStructure(anyString())).thenReturn(gifts);
        when(cacheService.generatePage(any(), any(), any(), any())).thenReturn(pageableResult);
        PageableResult<Gift> giftPageableResult = giftService.fetchGiftList(BRAND_OLAY, REGION_ML, null, null, 10, 1);

        Assert.assertThat(gifts, is(giftPageableResult.getRecords()));
    }

    @Test
    public void fetchGiftListAndTest() {
        Gift gift = new Gift();
        gift.setItems(new ArrayList<>());
        gift.setMarketPrice(BigDecimal.valueOf(100));

        ArrayList<Gift> gifts = new ArrayList<>(8);
        gifts.add(gift);
        PageableResult pageableResult = new PageableResult<>(1, gifts);
        when(giftRepository.findByNameIsStartingWithAndLoyaltyStructure(any(String.class), anyString())).thenReturn(gifts);
        when(cacheService.generatePage(any(), any(), any(), any())).thenReturn(pageableResult);
        PageableResult<Gift> giftPageableResult = giftService.fetchGiftList(BRAND_OLAY, REGION_ML, "Olay", null, 10, 1);

        Assert.assertThat(gifts, is(giftPageableResult.getRecords()));
    }

    @Test
    public void findGiftByIdTest() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(giftList);
        Gift gift = giftService.findGiftById("123456789");
        Assert.assertThat(gift.getId(), is(expectedValue.getId()));
    }

    @Test(expected = SystemException.class)
    public void findGiftByIdAndOpenExceptionTest() {
        when(giftRepository.findGiftById(any(String.class))).thenReturn(null);
        Gift gift = giftService.findGiftById("123456789");
    }

    @Test
    public void translateGiftCouponForHkPampersRedemption() {
        List<FetchRedemptionDTO> fetchRedemptionDTOList = new ArrayList<>();
        FetchRedemptionDTO fetchRedemptionDTO = new FetchRedemptionDTO();
        fetchRedemptionDTO.setRedeemCode("1234");
        fetchRedemptionDTO.setStoreName("测试");
        fetchRedemptionDTOList.add(fetchRedemptionDTO);
        when(giftCouponService.findByRegionAndBrandAndCouponCode(any(), any(), any())).thenReturn(giftCoupon);
        giftService.translateGiftCouponForHkPampersRedemption("en_US", "HK", "PAMPERS", fetchRedemptionDTOList);
        Assert.assertEquals("englishStoreName", fetchRedemptionDTOList.get(0).getStoreName());

    }

    @Test
    public void addGiftCouponTest(){
        GiftCouponCommand command = new GiftCouponCommand();
        command.setRegion("HK");
        command.setBrand(BRAND_PAMPERS);
        command.setSku("100_209910");
        command.setGiftName("test");
        command.setCouponCode("123456");
        command.setPrice("100");
        command.setStoreName("HK帮宝适官方旗舰店");
        command.setStartAt(LocalDate.now().minusDays(50));
        command.setEndAt(LocalDate.now().minusDays(50));
        command.setEnglishStoreName("HK PAMPERS OFFICIAL STORE");
        giftService.addGiftCoupon(command);
        verify(giftCouponService).addCoupon(any());
    }

    @Test
    public void findOneGiftCouponByBagSkuTest(){
        when(giftCouponService.findGiftCouponByBagSku(any(),any(),any())).thenReturn(giftCoupon);
        giftService.findOneGiftCouponByBagSku(any(),any(),any());
        verify(giftCouponService).findGiftCouponByBagSku(any(),any(),any());
    }

    @Test
    public void findByGiftBagSku_return_null(){
        LoyaltyStructure structure = getTWStructure();
        when(giftRepository.findByBagSkuAndLoyaltyStructure("123",structure.name())).thenReturn(null);
        Gift gift = giftService.findByGiftBagSku("123",structure);
        Assert.assertNull(gift);
    }

    @Test
    public void findByGiftBagSku_return_not_null(){
        LoyaltyStructure structure = getTWStructure();
        when(giftRepository.findByBagSkuAndLoyaltyStructure("123",structure.name())).thenReturn(giftList);
        Gift gift = giftService.findByGiftBagSku("123",structure);
        Assert.assertNotNull(gift);
    }

    @Test
    public void translateGiftCouponForHkPampersTest(){
        RedemptionGiftDTO redemptionGiftDTO = new RedemptionGiftDTO();
        redemptionGiftDTO.setStoreName("HK PAMPERS OFFICIAL STORE");
        redemptionGiftDTO.setGiftId("1234");
        List<RedemptionGiftDTO> records = new ArrayList<>();
        records.add(redemptionGiftDTO);
        findGiftByIdTest();
        findOneGiftCouponByBagSkuTest();
        giftService.translateGiftCouponForHkPampers("en_US","HK","PAMPERS",records);
    }
}
