package cn.com.pg.loyalty.application;

/**
 * @author Simon
 * @date 2019/6/14 6:55
 * @description
 **/

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import org.junit.Assert;
import org.junit.Test;

/**
 * 为了测试覆盖率
 */
public class AccountTransactionResultTest {

    @Test
    public void test() {
        AccountTransactionResult accountTransactionResult =
                new AccountTransactionResult();
        accountTransactionResult.setAccount(new Account());
        accountTransactionResult.setTransaction(new Transaction());
        accountTransactionResult.getTransaction();
        accountTransactionResult.getAccount();
        Assert.assertNotNull(accountTransactionResult);
    }
}
