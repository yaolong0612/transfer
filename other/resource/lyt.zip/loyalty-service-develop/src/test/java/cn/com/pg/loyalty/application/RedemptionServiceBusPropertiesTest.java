package cn.com.pg.loyalty.application;

import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class RedemptionServiceBusPropertiesTest {

    @Test
    public void setGetMethodTest(){
        RedemptionServiceBusProperties properties = new RedemptionServiceBusProperties();
        properties.setActivityId("123456789");
        properties.setMemberId("123456");
        properties.setPartitionKey("IO");
        properties.setRedemptionId("1234566");
        properties.setGiftIdStockMap(new HashMap<>());

        Assert.assertThat("123456",is(properties.getMemberId()));
    }

}