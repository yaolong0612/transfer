package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.activity.ActivityRepository;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.activity.PointTypeRepository;
import cn.com.pg.loyalty.domain.activity.RuleTemplate;
import cn.com.pg.loyalty.domain.shared.CacheService;
import cn.com.pg.loyalty.domain.shared.JwtUtils;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.TransactionType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.BRAND_OLAY;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
@RunWith(MockitoJUnitRunner.class)
public class PointTypeServiceTest {

    @InjectMocks
    private PointTypeService pointTypeService;
    @Mock
    private PointTypeRepository pointTypeRepository;

    @Mock
    private ActivityRepository activityRepository;

    @Mock
    private CacheService cacheService;
    private static final String token = "eyJhbGciOiJSUzUxMiIsImtpZCI6IjEifQ.eyJzY29wZSI6WyJvcGVuaWQiLCJwcm9maWxlIl0sImNsaWVudF9pZCI6IkNoaW5hIFBhYVMgUGxhdGZvcm0gQjJDIFFBIiwiVWlkIjoiRFIyMDY4IiwiU2hvcnROYW1lIjoiaHVhbmcuZGguMyIsIkxhc3ROYW1lIjoiaHVhbmciLCJVc2VybmFtZSI6Imh1YW5nLmRoLjMiLCJGaXJzdE5hbWUiOiJoYWRlIiwiZXhwIjoxNTYwMzU2NzYwfQ.bvNAxcWkL7IMkGukgUil1ZDO6zaq-9Uwspc5l7WjOGwAcEBUJcV7x0hr3nSlqzA7TmxP-O8vckeClvH-5DG0IIAuCRfvD1V6GLLljYHJbPFGFqclTwTYu8J4IiMTrsLlb4XTGcwDrO9oO1EgA5R8TjWUKTuJo8K0PXjNUbXRehn9t7QHTgO7d1mThgjRKmTEHwBqqLN9RVo4VM1qjocXuWimSlWTEHY4jFmN5AOlaa9i8Iq4gcaicc_jFJrS3UnoIrnC2-6WL1h9NB7eXwqxLdUCUHG-xc7cqS9nlcl8fYXB8S1xwAzWBi1zqMTWoQcEvRADUAmSMfuKMXP67qdDNQ";//建议写成静态变量。
    private String region = "ML";
    private String status= PointType.PointTypeStatus.ACTIVATED.name();
    private String creator= JwtUtils.getUsernameFromToken(token);
    private TransactionType transcationType= TransactionType.ORDER;
    private LoyaltyStructure loyaltyStructure= StructureConfig.getMLOlayStructure();
    private PointType pointType=null;
    private String pointTypeStr="pointType";
    private String description="description";
    private String remark="remark";
    private Optional<PointType> pointTypeOptional;
    private String id=null;
    private RuleTemplate ruleTemplate = null;


    @Before
    public void setUp()  {
        ruleTemplate = RuleTemplate.INTERACTION_ADJUST_POINT_BY_CLIENT;
        pointType = new PointType(pointTypeStr, description, remark, loyaltyStructure.name(), creator, transcationType, ruleTemplate);
        id=pointType.getId();
        pointTypeOptional=Optional.of(pointType);
        Mockito.when(cacheService.findLoyaltyStructure(region, BRAND_OLAY))
                .thenReturn(loyaltyStructure);
    }

    @Test
    public void fetchPointTypeList() {
        List<PointType> pointTypes = new ArrayList<>(3);
        pointTypes.add(pointType);
        when(pointTypeRepository.findByLoyaltyStructureAndStatus(loyaltyStructure.name(), PointType.PointTypeStatus.ACTIVATED)).thenReturn(pointTypes);

        List<PointType> testValues= pointTypeService.fetchPointTypeList(BRAND_OLAY,region, PointType.PointTypeStatus.ACTIVATED);
        Assert.assertEquals(pointTypes,testValues);

    }

    @Test
    public void addPointType() {
        PointType pointType = pointTypeOptional.get();
        when(pointTypeRepository.save(any(PointType.class))).thenReturn(pointType);

        PointType testValue = pointTypeService.addPointType(pointType);
        Assert.assertEquals(pointType,testValue);
    }

    @Test
    public void deleteById() {
        List<PointType> pointTypeList = new ArrayList<>();
        pointTypeList.add(pointType);
        when(pointTypeRepository.findPointTypeById(id)).thenReturn(pointTypeList);
        when(activityRepository.findByLoyaltyStructureAndPointType(
                pointType.getLoyaltyStructure(),
                pointType.pointType())).thenReturn(new ArrayList<>());
        pointType.delete(creator);
        pointTypeService.deleteById(id,creator);
        Assert.assertNotNull(pointTypeList);
    }
}
