package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.application.dto.HktwNotificationDTO;
import cn.com.pg.loyalty.domain.account.*;
import cn.com.pg.loyalty.domain.transaction.Interaction;
import cn.com.pg.loyalty.domain.transaction.InteractionRepository;
import cn.com.pg.loyalty.domain.transaction.Transaction;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Slf4j
public class HktwNotificationServiceTest {

    @InjectMocks
    HktwNotificationService hktwNotificationService;

    @Mock
    AccountService accountService;

    @Mock
    InteractionRepository interactionRepository;

    @Mock
    AccountRepository accountRepository;

    @Mock
    StringRedisTemplate stringRedisTemplate;

    @Mock
    ValueOperations<String, String> operations;

    private HktwNotificationDTO hktwNotificationMessage;

    @Before
    public void setUp() {
        hktwNotificationMessage = new HktwNotificationDTO();
        hktwNotificationMessage.setBrand("PAMPERS");
        hktwNotificationMessage.setPointType("REGISTER");
        hktwNotificationMessage.setLoyaltyId("a2405fc359f548d5c9ab9055cbdf0c1bJ");
        hktwNotificationMessage.setMemberId("JR1a4LMSLV4J");
        hktwNotificationMessage.setTransactionId("e27b1fc2afb341469d741e8505b281b1");
        Assert.assertNotNull(hktwNotificationMessage);
    }

    @Test
    public void testJudgeMessageType(){
        Assert.assertNotNull(hktwNotificationMessage);
    }

    @Test
    public void testNotify() {
        Assert.assertNotNull(hktwNotificationMessage);
    }
}
