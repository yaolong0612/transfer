package cn.com.pg.loyalty.application;

import cn.com.pg.loyalty.domain.account.Account;
import cn.com.pg.loyalty.domain.account.AccountRepository;
import cn.com.pg.loyalty.domain.account.SubAccount;
import cn.com.pg.loyalty.domain.activity.Activity;
import cn.com.pg.loyalty.domain.activity.ActivityStatus;
import cn.com.pg.loyalty.domain.activity.PointType;
import cn.com.pg.loyalty.domain.pool.ValueType;
import cn.com.pg.loyalty.domain.service.MessageService;
import cn.com.pg.loyalty.domain.shared.*;
import cn.com.pg.loyalty.domain.structure.LoyaltyStructure;
import cn.com.pg.loyalty.domain.structure.StructureConfig;
import cn.com.pg.loyalty.domain.transaction.*;
import cn.com.pg.loyalty.interfaces.assembler.AccountAssembler;
import cn.com.pg.loyalty.interfaces.dto.AccountTierDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static cn.com.pg.loyalty.domain.structure.StructureConfig.*;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AccountServiceTest {

    @InjectMocks
    private AccountService accountService;
    @Mock
    private AccountRepository accountRepository;
    @Mock
    private CacheService cacheService;

    @Mock
    private RedemptionRepository redemptionRepository;

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private OrderRepository orderRepository;
    @Mock
    private StringRedisTemplate stringRedisTemplate;

    @Mock
    ValueOperations<String, String> operations;
    @Mock
    private MessageService messageService;
    @Mock
    private TransactionRepositoryV2 transactionRepositoryV2;

    @Spy
    private PointType pointType;

    private static final LoyaltyStructure mlStructure = StructureConfig.getMLOlayStructure();

    private static final LoyaltyStructure mlPampersStructure = StructureConfig.getMLPampersStructure();

    private static final LoyaltyStructure twStructure = StructureConfig.getTWStructure();

    private static final LoyaltyStructure jpStructure = StructureConfig.getJPStructure();

    @Before
    public void setUp() throws Exception {
        Mockito.when(cacheService.findLoyaltyStructure("ML", BRAND_OLAY)).thenReturn(mlStructure);
        Mockito.when(cacheService.findLoyaltyStructure("TW", BRAND_PAMPERS)).thenReturn(twStructure);

        Mockito.when(cacheService.findLoyaltyStructure("ML", "OLAY")).thenReturn(mlStructure);

    }

    @Test
    public void registerTwPampersAsNewMember() {
        final String memberId = "m-001";
        final String bindId = "line-001";
        final String babyBirthYearAndMonth = "201901";
        PointType pointType = new PointType();
        pointType.setId(UUIDUtil.generator());
        pointType.setPointType("REGISTER");
        Optional<PointType> optionalPointType = Optional.of(pointType);
        when(stringRedisTemplate.opsForValue()).thenReturn(operations);
        when(stringRedisTemplate.opsForValue().setIfAbsent(anyString(), anyString(), anyLong(), any(TimeUnit.class))).thenReturn(true);
        when(cacheService.findByPointTypeAndLoyaltyStructureAndTransactionType(pointType.pointType(), twStructure.name(), TransactionType.INTERACTION)).thenReturn(optionalPointType);

        Account account = accountService.register(memberId, BRAND_PAMPERS, "LINE", bindId, null, "TW",
                "babyBirthYearAndMonth",
                Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT);
        Assert.assertThat(account, notNullValue());
        Assert.assertThat(account.availablePoint(twStructure.accountTypeOfDefault()), is(0));
    }

    @Test
    public void bindTwPampersAsOldMember() {
        final String memberId = "m-001";
        final String bindId = "line-001";
        final String babyBirthYearAndMonth = "201901";
        final String loyaltyId = "l-001";
        when(stringRedisTemplate.opsForValue()).thenReturn(operations);
        when(stringRedisTemplate.opsForValue().setIfAbsent(anyString(), anyString(), anyLong(), any(TimeUnit.class))).thenReturn(true);
        when(cacheService.fetchLoyaltyId(mlStructure.marketingProgramId(), memberId)).thenReturn(loyaltyId);
        Account account = registeredAccount(memberId, mlStructure, BRAND_OLAY, CHANNEL_JD);
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        PointType pointType = new PointType();
        pointType.setId(UUIDUtil.generator());
        pointType.setPointType("REGISTER");
        Optional<PointType> optionalPointType = Optional.of(pointType);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(cacheService.findByPointTypeAndLoyaltyStructureAndTransactionType(pointType.pointType(), mlStructure.name(), TransactionType.INTERACTION)).thenReturn(optionalPointType);

        Account bindedAccount = accountService.register(memberId, BRAND_OLAY, "WECHAT", bindId, null, "ML",
                babyBirthYearAndMonth,
                Account.RegistryEvent.BRAND_MEMBER_REGISTRY_EVENT);
        Assert.assertThat(bindedAccount, notNullValue());
        Assert.assertThat(bindedAccount.availablePoint(twStructure.accountTypeOfDefault()), is(0));
        Assert.assertThat(bindedAccount.subAccount(BRAND_OLAY).bindList().size(), is(2));
    }



    /**
     * 用来测试绑定
     *
     * @param memberId
     * @return
     */
    public static Account registeredAccount(String memberId, LoyaltyStructure loyaltyStructure, String brand,
                                            String anotherChannel) {
        Account account = new Account(memberId, loyaltyStructure);
        //另外一个渠道注册
        account.register(loyaltyStructure, brand, anotherChannel, "ob-001", null);
        return account;
    }

    @Test
    public void findPointHistory() {
        //params prepared
        String brand = BRAND_PAMPERS;
        final String memberId = "m-001";
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusDays(30);
        int pageSize = 10;
        int page = 2;
        Account account = registeredAccount(memberId, twStructure, BRAND_PAMPERS, CHANNEL_JD);
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        String partitionKey = PartitionKeyUtils.getAccountPartitionKey(account.loyaltyId());
        when(accountRepository.findByPartitionKeyAndId(partitionKey, account.loyaltyId())).thenReturn(accounts);
        //开始结束时间为空
        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction = new Transaction(brand, CHANNEL_JD, "123");
        transactions.add(transaction);

        AccountTierDTO accountTierDTO = AccountAssembler.toAccountTierDTO(account, twStructure, 100,new HashMap<>());

        PageableResult<Transaction> pageableResult = new PageableResult<>(1, transactions);
        PageableResult<Transaction> resultData =
                accountService.findPointHistory(memberId, null, pageSize, page, null, null, twStructure, AccountService.PointCategory.EARN, null);
        PageableResult<Transaction> resultData2 =
                accountService.findPointHistory(memberId, "TRANSIT", null, null, start, end, twStructure, AccountService.PointCategory.BURN, null);
        PageableResult<Transaction> resultData3 =
                accountService.findPointHistory(memberId, "TRANSIT", null, null, start, end, twStructure, null, null);
        Assert.assertNotNull(pageableResult);
    }

    @Test
    public void findPointHistoryMlPampers() {
        //params prepared
        String brand = BRAND_PAMPERS;
        final String memberId = "m-001";
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusDays(30);
        int pageSize = 10;
        int page = 2;
        Account account = registeredAccount(memberId, mlPampersStructure, BRAND_PAMPERS, CHANNEL_JD);
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        String partitionKey = PartitionKeyUtils.getAccountPartitionKey(account.loyaltyId());
        when(accountRepository.findByPartitionKeyAndId(partitionKey, account.loyaltyId())).thenReturn(accounts);
        //开始结束时间为空
        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction = new Transaction(brand, CHANNEL_JD, "123");
        transactions.add(transaction);

        AccountTierDTO accountTierDTO = AccountAssembler.toAccountTierDTO(account, mlPampersStructure, 100, new HashMap<>());

        PageableResult<Transaction> pageableResult = new PageableResult<>(1, transactions);
        PageableResult<Transaction> resultData =
                accountService.findPointHistory(memberId, null, pageSize, page, null, null, mlPampersStructure, AccountService.PointCategory.EARN, null);
        PageableResult<Transaction> resultData2 =
                accountService.findPointHistory(memberId, "TRANSIT", null, null, start, end, mlPampersStructure, AccountService.PointCategory.BURN, null);
        PageableResult<Transaction> resultData3 =
                accountService.findPointHistory(memberId, "TRANSIT", null, null, start, end, mlPampersStructure, null, null);
        Assert.assertNotNull(pageableResult);
    }

    @Test
    public void findPointHistoryUseDate() {
        //params prepared
        String brand = BRAND_PAMPERS;
        String region = "TW";
        final String memberId = "m-001";
        final String loyaltyId = "l-001";
        LocalDateTime start = LocalDateTime.now();
        LocalDateTime end = start.plusDays(30);
        int pageSize = 10;
        int page = 2;
        Account account = registeredAccount(memberId, twStructure, BRAND_PAMPERS, CHANNEL_JD);
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        String partitionKey = account.partitionKey();
//        when(accountRepository.findByPartitionKeyAndId(partitionKey, loyaltyId)).thenReturn(accounts);
        //开始结束时间为空

        List<Transaction> transactions = new ArrayList<>();
        Transaction transaction = new Transaction(brand, CHANNEL_JD, "123");
        transactions.add(transaction);
        PageableResult<Transaction> pageableResult = new PageableResult<>(1, transactions);
//        PageableResult<Transaction> resultData =
//                accountService.findPointHistory(memberId, pageSize, page, null, null, loyaltyStructure, null);
        Assert.assertNotNull(pageableResult);
    }

    @Test
    public void fetchAndInitialInExistSubAccount() {
        final String memberId = "m-001";
        when(cacheService.fetchLoyaltyId(mlStructure.marketingProgramId(), memberId)).thenReturn(null);
        Account mockAccount = registeredAccount(memberId, mlStructure, BRAND_OLAY, "WECHAT");
        List<Account> accounts = new ArrayList<>();
        accounts.add(mockAccount);
        when(accountRepository.findByMemberIdAndMarketingProgramId(memberId,
                mlStructure.marketingProgramId())).thenReturn(accounts);
        Account account = accountService.fetchAndInitialInExistSubAccount(memberId, mlStructure, BRAND_OLAY, "WECHAT");
        Assert.assertThat(account, notNullValue());
        Assert.assertThat(account.subAccount(BRAND_OLAY), notNullValue());
    }

    @Test(expected = SystemException.class)
    public void fetchAndInitialInExistSubAccountMemberIsNotExist() {
        final String memberId = "m-001";
        when(cacheService.fetchLoyaltyId(mlStructure.marketingProgramId(), memberId)).thenReturn(null);
        when(accountRepository.findByMemberIdAndMarketingProgramId(memberId,
                mlStructure.marketingProgramId())).thenReturn(null);
        Account account = accountService.fetchAndInitialInExistSubAccount(memberId, mlStructure, BRAND_OLAY, "WECHAT");
    }

    @Test(expected = SystemException.class)
    public void fetchAccountByMemberIdAndCheckIsNotExist() {
        final String memberId = "m-001";
        when(cacheService.fetchLoyaltyId(mlStructure.marketingProgramId(), memberId)).thenReturn(null);
        accountService.fetchAccountByMemberIdAndCheck(mlStructure, memberId);
    }

    public static Redemption getRedemption(String loyaltyId) {
        Redemption redemption =
                new Redemption(BRAND_OLAY, CHANNEL_JD, "Ynson", "18766778899",
                        "广东", "广州", "天河", "富力盈隆2313", null, "374711", "123", null, null, null, ValueType.DEFAULT);
        return redemption;
    }

    public static Order getOrder(String loyaltyId) {
        Order o = new Order(loyaltyId, BRAND_OLAY, CHANNEL_JD, mlStructure, "123");
        o.setPartitionKey(o.partitionKey());
        List<String> list = new ArrayList<String>();
        list.add(UUIDUtil.generator());
        o.setPoint(3000);
        Set<OrderItem> items = new HashSet<OrderItem>();
        OrderItem i = new OrderItem();
        i.setSku(UUIDUtil.generator());
        i.setPurchaseQty(3);
        i.setRealAmount(20.3);
        i.setRetailAmount(34.8);
        items.add(i);
        o.setOrderItems(items);
        o.setTransactionType(TransactionType.ORDER);
        return o;
    }

    @Test
    public void findRedemptionHistoryAndTimeNoNullTest() {
        Account account = new Account();
        account.setId("1234566");
        List<Redemption> redemptionList = new ArrayList<>(2);
        Redemption redemption = new Redemption();
        redemption.setActivityId("12345");
        redemptionList.add(redemption);
        Activity activity = new Activity();
        activity.setStatus(ActivityStatus.INITIAL);
        PageableResult<Redemption> redemptionPageableResult = new PageableResult<>(redemptionList.size(), redemptionList);

        when(cacheService.fetchLoyaltyId(anyString(), anyString())).thenReturn("123445");
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(
                anyString(), anyString(), anyString(), anyString(),
                any(TransactionType.class))).thenReturn(redemptionList);
        when(cacheService.generatePage(any(Integer.class), any(Integer.class), any(List.class), any())).thenReturn(redemptionPageableResult);

        PageableResult<Redemption> result = accountService.findRedemptionHistory("1234", "OLAY", "ML", LocalDateTime.now(), LocalDateTime.now(), 10, 1, "activityId", null);


        Assert.assertThat(1, is(result.getTotalSize()));
    }

    @Test
    public void findRedemptionHistoryTest() {
        Account account = new Account();
        account.setId("12344");
        List<Redemption> redemptionList = new ArrayList<>(2);
        Redemption redemption = new Redemption();

        List<GiftItem> giftItemList = new ArrayList<>();
        GiftItem item = new GiftItem();
        item.setGiftStatus(GiftItem.GiftStatus.NOT_RECEIVED);
        giftItemList.add(item);
        redemption.setGiftItemList(giftItemList);
        redemptionList.add(redemption);
        Activity activity = new Activity();
        activity.setStatus(ActivityStatus.INITIAL);


        PageableResult<Redemption> redemptionPageableResult = new PageableResult<>(redemptionList.size(), redemptionList);
        when(cacheService.fetchLoyaltyId(anyString(), anyString())).thenReturn("123445");
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(cacheService.generatePage(any(Integer.class), any(Integer.class), any(List.class), any())).thenReturn(redemptionPageableResult);
        when(redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(anyString(), anyString(), anyString(), anyString(),
                any(TransactionType.class))).thenReturn(redemptionList);

        PageableResult<Redemption> result = accountService.findRedemptionHistory("1234", "OLAY", "ML", LocalDateTime.now().plusDays(-1), LocalDateTime.now(), 10, 1, "", null);
        Assert.assertThat(1, is(result.getTotalSize()));
    }

    @Test
    public void findRedemptionHistory() {
        Account account = new Account();
        account.setId("12344");
        List<Redemption> redemptionList = new ArrayList<>(2);
        Redemption redemption = new Redemption();

        List<GiftItem> giftItemList = new ArrayList<>();
        GiftItem item = new GiftItem();
        item.setGiftStatus(GiftItem.GiftStatus.NOT_RECEIVED);
        giftItemList.add(item);
        redemption.setGiftItemList(giftItemList);
        redemptionList.add(redemption);
        Activity activity = new Activity();
        activity.setStatus(ActivityStatus.INITIAL);


        PageableResult<Redemption> redemptionPageableResult = new PageableResult<>(redemptionList.size(), redemptionList);
        when(cacheService.fetchLoyaltyId(anyString(), anyString())).thenReturn("123445");
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(cacheService.generatePage(any(Integer.class), any(Integer.class), any(List.class), any())).thenReturn(redemptionPageableResult);
        when(redemptionRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(anyString(), anyString(), anyString(), anyString(),
                any(TransactionType.class))).thenReturn(redemptionList);

        PageableResult<Redemption> result = accountService.findRedemptionHistoryForC2("1234", "OLAY", "ML", LocalDateTime.now().plusDays(-1), LocalDateTime.now(), 10, 1, false);
        Assert.assertThat(1, is(result.getTotalSize()));
    }

    @Test
    public void findOrdersHistoryAndTimeNoNullTest() {
        Account account = new Account();
        account.setId("12345677");
        List<Order> orderList = new ArrayList<>(2);
        Order order = new Order();
        orderList.add(order);
        PageableResult<Order> orderPageableResult = new PageableResult<>(orderList.size(), orderList);

        when(cacheService.fetchLoyaltyId(anyString(), anyString())).thenReturn("123445");
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(orderRepository.findByPartitionKeyAndLoyaltyIdAndCreatedTimeBetweenAndTransactionType(
                anyString(), anyString(), anyString(), anyString(),
                any(TransactionType.class))).thenReturn(orderList);
        when(cacheService.generatePage(any(Integer.class), any(Integer.class), any(List.class), any())).thenReturn(orderPageableResult);

        PageableResult<Order> result = accountService.findOrdersHistory("1234", "OLAY", "ML", LocalDateTime.now(), LocalDateTime.now(), 10, 1);


        Assert.assertThat(1, is(result.getTotalSize()));
    }

    @Test
    public void findOrdersHistoryTest() {
        Account account = new Account();
        account.setId("123445");
        List<Order> orderList = new ArrayList<>(2);
        Order order = new Order();
        orderList.add(order);
        PageableResult<Order> orderPageableResult = new PageableResult<>(orderList.size(), orderList);

        when(cacheService.fetchLoyaltyId(anyString(), anyString())).thenReturn("123445");
        List<Account> accounts = new ArrayList<>();
        accounts.add(account);
        when(accountRepository.findByPartitionKeyAndId(any(String.class), any(String.class))).thenReturn(accounts);
        when(cacheService.generatePage(any(Integer.class), any(Integer.class), any(List.class), any())).thenReturn(orderPageableResult);

        PageableResult<Order> result = accountService.findOrdersHistory("1234", "OLAY", "ML", null, null, 10, 1);
        Assert.assertThat(1, is(result.getTotalSize()));
    }

    @Test(expected = SystemException.class)
    public void findPointHistoryWithPointTypeAndTransactionTypeWithException() {
        accountService.findPointHistoryWithPointTypeAndTransactionType(
                "1", jpStructure, "DONATE", TransactionType.REDEMPTION, LocalDateTime.MIN, LocalDateTime.now());
    }

    @Test
    public void findPointHistoryWithPointTypeAndTransactionType() {
        List<Account> accounts = new ArrayList<>();
        Account account = new Account();
        account.setId(UUIDUtil.generator());
        accounts.add(account);
        Mockito.when(accountRepository.findByPartitionKeyAndId(Mockito.anyString(), Mockito.anyString())).thenReturn(accounts);
        Mockito.when(cacheService.validatePointType(Mockito.anyString(), Mockito.any(), Mockito.any()))
                .thenReturn(pointType);
        List<Transaction> transactions = new ArrayList<>();
        Redemption redemption = new Redemption();
        redemption.setCreatedTime(LocalDateTime.now());
        transactions.add(redemption);
        Mockito.when(transactionRepository.findByPartitionKeyAndLoyaltyIdAndPointType(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyString()
        )).thenReturn(transactions);
        List<Redemption> redemptionList = accountService.findPointHistoryWithPointTypeAndTransactionType(
                "1", jpStructure, "DONATE", TransactionType.REDEMPTION, LocalDateTime.MIN, LocalDateTime.now().plusSeconds(1L));
        Assert.assertEquals(1, redemptionList.size());

        redemptionList = accountService.findPointHistoryWithPointTypeAndTransactionType(
                "1", jpStructure, "DONATE", TransactionType.REDEMPTION, LocalDateTime.now(), LocalDateTime.now());
        Assert.assertEquals(0, redemptionList.size());
    }

    @Test(expected = SystemException.class)
    public void when_account_not_fount() {
        Mockito.when(accountRepository.findByPartitionKeyAndId(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(new ArrayList<>());
        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(2));
    }

    @Test
    public void when_structure_no_lock_time_return(){
        LoyaltyStructure structure = getMLOlayStructure();
        SubAccount subAccount = createLockedTimeAccount(structure);
        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(2));
        Assert.assertEquals(400, subAccount.getPointAvailable().intValue());
        Assert.assertEquals(200, subAccount.getPointLocked());
    }

    @Test
    public void when_unlock_time_not_after_sub_account() {
        LoyaltyStructure structure = getMLPampersStructure();
        SubAccount subAccount = createLockedTimeAccount(structure);

        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(2));
        Assert.assertEquals(400, subAccount.getPointAvailable().intValue());
        Assert.assertEquals(200, subAccount.getPointLocked());
    }

    @Test
    public void when_unlock_time_after_sub_account() {
        LoyaltyStructure structure = getMLPampersStructure();
        SubAccount subAccount = createLockedTimeAccount(structure);
        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(1));
        Assert.assertEquals(600, subAccount.getPointAvailable().intValue());
        Assert.assertEquals(0, subAccount.getPointLocked());
    }


    @Test
    public void when_unlock_time_after_sub_account_with_not_unlock_point() {
        LoyaltyStructure structure = getMLPampersStructure();
        SubAccount subAccount = createLockedTimeAccount(structure);
        List<Transaction> transactions = new ArrayList<>();
        Order order = new Order();
        order.setPoint(100);
        order.setTransactionType(TransactionType.ORDER);

        Interaction interaction = new Interaction();
        interaction.setPoint(50);
        interaction.setTransactionType(TransactionType.INTERACTION);
        Interaction interaction1 = new Interaction();
        interaction1.setPoint(-100);
        interaction1.setTransactionType(TransactionType.INTERACTION);

        Redemption redemption = new Redemption();
        redemption.setPoint(100);
        redemption.setTransactionType(TransactionType.REDEMPTION);


        transactions.add(order);
        transactions.add(interaction);
        transactions.add(interaction1);
        transactions.add(redemption);
        Mockito.when(transactionRepositoryV2
                .fetchByUnlockTimeAfter("472aba70b92f45258700903afa2e18c6",
                        LocalDate.now().minusDays(1))).thenReturn(transactions);
        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(1));
        Assert.assertEquals(450, subAccount.getPointAvailable().intValue());
        Assert.assertEquals(150, subAccount.getPointLocked());
    }

    @Test
    public void when_unlock_time_after_sub_account_with_not_unlock_point_200() {
        LoyaltyStructure structure = getMLPampersStructure();
        SubAccount subAccount = createLockedTimeAccount(structure);
        List<Transaction> transactions = new ArrayList<>();
        Order order = new Order();
        order.setPoint(100);
        order.setTransactionType(TransactionType.ORDER);

        Interaction interaction = new Interaction();
        interaction.setPoint(100);
        interaction.setTransactionType(TransactionType.INTERACTION);
        Interaction interaction1 = new Interaction();
        interaction1.setPoint(-100);
        interaction1.setTransactionType(TransactionType.INTERACTION);

        Redemption redemption = new Redemption();
        redemption.setPoint(100);
        redemption.setTransactionType(TransactionType.REDEMPTION);


        transactions.add(order);
        transactions.add(interaction);
        transactions.add(interaction1);
        transactions.add(redemption);
        Mockito.when(transactionRepositoryV2
                .fetchByUnlockTimeAfter("472aba70b92f45258700903afa2e18c6",
                        LocalDate.now().minusDays(1))).thenReturn(transactions);
        accountService.unlockPointAndAddPointAvailable("472aba70b92f45258700903afa2e18c6",
                "PAMPERS", LocalDate.now().minusDays(1));
        Assert.assertEquals(400, subAccount.getPointAvailable().intValue());
        Assert.assertEquals(200, subAccount.getPointLocked());
    }

    private SubAccount createLockedTimeAccount(LoyaltyStructure structure) {
        List<Account> accounts = new ArrayList<>();
        Account account = registeredAccount("01", structure, "PAMPERS", "WECHAT");
        SubAccount subAccount = account.subAccount("PAMPERS", structure.accountTypeOfDefault());
        subAccount.setUnlockTime(LocalDate.now().minusDays(2));
        subAccount.setPointAvailable(400);
        subAccount.setPointLocked(200);
        accounts.add(account);
        Mockito.when(accountRepository.findByPartitionKeyAndId(Mockito.anyString(), Mockito.anyString())).thenReturn(accounts);
        Mockito.when(cacheService.findLoyaltyStructure(account)).thenReturn(structure);
        return subAccount;
    }


}
