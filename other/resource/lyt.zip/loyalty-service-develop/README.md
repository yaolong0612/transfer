#  Loyalty Service Help Document

- Before you start up application, please config profile as:
   tw/ml & dev/qa/prod
   需要同时选择2个profile
   tw/ml 代表部署地区，tw: 台湾 taiwan，ml: 大陆 mainland（默认）
   dev/qa/prod 代表部署环境，开发/QA/Production
- 台湾部署和本地开发，需要配置关闭Eureka Client，Spring Cloud Config Client
   * spring.cloud.config.enabled   false
   * spring.cloud.config.discovery.enabled   false
   * eureka.client.enabled  false
- H2 console:
   * URL: http://localhost:8088/h2-console/login.jsp
   * JDBC URL: jdbc:h2:mem:testdb
   * Username/password: sa/sa
- Banner 生成:
   * http://patorjk.com/software/taag/
   * Font：3D-ASCII
- Env变量：
    * service_springcloud_eureka
    * http://127.0.0.1:8761/eureka/
- Env变量: 
    * service_springcloud_configserver
    * CONFIG-SPRINGCLOUD spring cloud config 在eureka中的应用名称
- 生成的代码:
    * 路径：target/generated-sources/swagger/src/main
- API实现：
    * implements 生成的 xxxDelegate
    * test
- Swagger edit的使用：
    * 可以使用swagger edit在线版本：
        http://editor.swagger.io/
    * 可以自己安装local swagger edit
        https://github.com/swagger-api/swagger-editor
- OAS 文档：
    https://swagger.io/specification/
- Get Set 空构造方法使用约定：
    Domain中的Get，Set，空构造方法一般只允许在repository中使用，是用来持久化对象或者反序列化使用的。不允许在其它地方使用。
    如果其它地方需要使用类的属性，需要自己封装业务方法。
- Domain定义规范：
    1. 必须要标准@Id
    2. 必须要标准@PartitionKey
    3. 必须要使用Lombok生成：Getter，Setter，NoArgsConstructor，这些参数建议不要使用，是专门给Repository序列化时使用的。
    4. LocalDateTime上面必须加注解：@JsonFormat(pattern = DateTimeUtils.UNIFORM_DATE_TIME_PATTERN),否则数据持久化到数据是数组格式
    5. 主表中的ID如果在其它类使用，必须写全名称，例如TransactionId
- Repository查询规范：
    1. 所有查询必须带分区键，分区键放到第一个参数
    2. 查询避免使用Like
    3. Between会左右包含
    4. 查询时日期需要先转换为字符串，格式参照DateUtils中格式
    5. 查询时，数据格式需要相符，否则无法查询出结果
    6. 任何查询都需要检查SQL，查询所耗费的RU。
- API设计规范：
    1. 文档中不允许出现JSON html特殊字符：< > { } 等
    2. Enum类型，不使用default值
    3. 所有的参数限制，都在API层进行限制
    4. Get方式调用，参数必填，参数正则会自动验证。但是空字符串，Enum格式不会验证，需要手动验证. 如果参数定义了正则表达式，也不需要验证空字符串
    5. admin调用的接口,分页参数必传。非admin调用的，不用必传
- 敏感信息加密
    1. 代码中的敏感信息需要加密
    2. 加密方法使用test 包中的加密类进行加密：PasswordEncryptUtil
    3. 将加密的字符串copy到配置文件中即可，代码不用做任何改动
    4. 参考文件：https://github.com/ulisesbocchio/jasypt-spring-boot
- 线上敏感信息加密解密，未加密文件的git history移除
    1.加解密：
    https://confluence-wiki.pg.com.cn/pages/viewpage.action?spaceKey=GIPCKD&title=CONFIG+SERVER+TUTORIAL
    2.git历史记录清理
    https://confluence-wiki.pg.com.cn/pages/viewpage.action?spaceKey=CC&title=7.5+Clean+up+Git+history 
